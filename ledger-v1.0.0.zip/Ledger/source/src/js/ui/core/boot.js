/* ---- ui/core/boot.js ---- */
(function () {
  'use strict';
  const U = window.UI;
  function boot() {
    try {
      if (U.loadSaved()) {
        U.ui.view = { n: 'home', p: {} };
      } else {
        S = null;
      }
    } catch (e) {
      S = null;
    }
    /* opening the game: the main menu when there is a game to continue or a saved one, otherwise a new game */
    U.ui.menu = !!(S || (window.R56saves && R56saves.any()));
    U.render(true);
    /* leaving the page: save now (a big, packed save is written at once instead of a moment later) */
    document.addEventListener('visibilitychange', () => {
      if (document.hidden && S) { U.save(); U.flushSave(); }
    });
    window.addEventListener('pagehide', () => {
      if (S) { U.save(); U.flushSave(); }
    });
  }
  /* the app first reads its files and iCloud (ui/core/base.js diskReady, features/player/saves.js cloudIn) */
  const start = () => window.LedgerApp ? U.diskReady().then(r => {
    if (r && window.R56saves) R56saves.cloudIn(r);
    boot();
    /* iCloud brought something while the app is open: with no game running yet it opens the menu with it */
    LedgerApp.disk.onCloud(r2 => { R56saves.cloudIn(r2); if (!S && U.loadSaved()) U.ui.menu = 1; if (U.ui.menu) U.render(true); });
  }) : boot();
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();


/* ---- ui/core/base.js ---- */
(function () {
  'use strict';
  const KEY = 'ledger-v3';
  /* the name and version players see (Settings › About, the main menu); the app's own version is the same (ios-app) */
  const NAME = 'Ledger | Business Tycoon Simulator', PATCH = 'Patch V. 1.0.0', SUPPORT = 'matas1114@gmail.com';
  const ui = {
    tab: 'home',
    stack: [],
    view: { n: 'home', p: {} },
    sheet: null,
    inp: {},
    toastT: 0,
    scroll: {},
    advMode: 'week'
  };
  const V = {}, ACT = {};
  V.titles = {};
  const $ = id => document.getElementById(id);
  function esc(t) {
    return String(t == null ? '' : t).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }
  const nok = n => money(n);
  const tone = t => t === 'good' ? 'var(--green)' : t === 'bad' ? 'var(--red)' : 'var(--muted)';
  const sgn = n => n > 0 ? 'pos' : n < 0 ? 'neg' : '';

/* ---------- persistence ---------- */
  /* A normal game is stored as it is, at once. A big one (over PACK_AT characters) is stored packed (about a sixth of
     the size, engine/core/state.js packText) a moment after the last change, and at once when the page is hidden or
     closed. If the browser still refuses (storage full), the player is told once and offered a save file. */
  const PACK_AT = 1200000, PACK_WAIT = 700;
  let packT = 0;
  function store(t) {
    try { localStorage.setItem(KEY, t); disk(KEY, t); return true; } catch (e) { return false; }
  }
  /* The iPhone app (window.LedgerApp, ios-app/native/app-bridge.js) keeps every game key in a file on the phone too,
     and the game, the slots and their list in iCloud, so a game survives cleared web storage and moves to a new
     phone. localStorage stays the quick copy the game reads. Files follow a moment after the last change, iCloud
     half a minute after; both at once when the app is hidden. v null deletes the key. */
  const APP = window.LedgerApp && LedgerApp.disk ? LedgerApp : null;
  const toCloud = k => k === KEY || k === KEY + ':meta' || k.indexOf(KEY + ':slot:') === 0;
  const dueF = {}, dueC = {};
  let fT = 0, cT = 0, cloudOn = false;
  function disk(k, v) {
    if (!APP) return;
    dueF[k] = v;
    if (!fT) fT = setTimeout(diskFlush, 1500);
    if (toCloud(k)) { dueC[k] = 1; if (!cT) cT = setTimeout(cloudFlush, 30000); }
  }
  function diskFlush() {
    clearTimeout(fT); fT = 0;
    Object.keys(dueF).forEach(k => { const v = dueF[k]; delete dueF[k]; APP.disk.write({ key: k, value: v, t: Date.now() }).catch(() => { }); });
  }
  function cloudFlush() {
    clearTimeout(cT); cT = 0;
    if (!cloudOn) return;
    Object.keys(dueC).forEach(k => {
      delete dueC[k];
      let v = null; try { v = localStorage.getItem(k); } catch (e) { }
      APP.disk.cloud({ key: k, value: v, t: Date.now(), about: k === KEY && S && window.R56saves ? Object.assign(R56saves.about(), { dev: dev() }) : null }).catch(() => { });
    });
  }
  /* this device, so a game it sent to iCloud itself is not offered back to it (saves.js cloudIn) */
  function dev() {
    let d = null; try { d = localStorage.getItem(KEY + ':dev'); } catch (e) { }
    if (!d) { d = Math.random().toString(36).slice(2, 10); try { localStorage.setItem(KEY + ':dev', d); } catch (e) { } disk(KEY + ':dev', d); }
    return d;
  }
  /* at the start: what web storage lost comes back from the files; iCloud is handed to the main menu (saves.js) */
  function diskReady() {
    if (!APP) return Promise.resolve(null);
    const wait = new Promise(r => setTimeout(() => r(null), 10000));
    return Promise.race([APP.disk.load(), wait]).then(r => {
      if (!r) return null;
      const L = r.local || {};
      Object.keys(L).forEach(k => { try { if (localStorage.getItem(k) == null) localStorage.setItem(k, L[k].v); } catch (e) { } });
      cloudOn = !!r.cloud;
      return r;
    }, () => null);
  }
  function writeNow() {
    packT = 0;
    if (!S) return true;
    const t = serialize();
    let ok = t.length < PACK_AT && store(t);
    if (!ok) {
      const p = 'LZ1:' + packText(t);
      ok = store(p);
      /* still no room: the monthly backup (features/player/saves.js) gives way to the game itself */
      if (!ok) { try { localStorage.removeItem(KEY + ':auto'); disk(KEY + ':auto', null); } catch (e) { } ok = store(p); }
    }
    if (ok) ui.saveErr = 0; else saveTrouble();
    return ok;
  }
  function save() {
    if (!S) return;
    const t = serialize();
    if (t.length < PACK_AT) {
      if (packT) { clearTimeout(packT); packT = 0; }
      if (store(t)) { ui.saveErr = 0; return; }
    }
    if (packT) clearTimeout(packT);
    packT = setTimeout(writeNow, PACK_WAIT);
  }
  const flush = () => { if (packT) { clearTimeout(packT); writeNow(); } if (APP) { diskFlush(); cloudFlush(); } };
  window.addEventListener('pagehide', flush);
  document.addEventListener('visibilitychange', () => { if (document.hidden) flush(); });
  function saveTrouble() {
    ui.saveErr = 1;
    if (ui.saveWarned) return;
    ui.saveWarned = 1;
    setTimeout(() => openSheet('<h2>The game could not save</h2><p class="lead">Your browser has no room left to store this game. Progress since the last save is only kept while this page is open.</p><p class="muted small">Save to a file now and keep it safe. You can load it again under Settings, on this or another device. Clearing other sites\' data in the browser settings can make room.</p><div class="btnrow col">' + btn('Save to a file', 'savefile', undefined, 'primary wide') + btn('Later', 'sheetclose', undefined, 'ghost wide') + '</div>'), 50);
  }
  function loadSaved() {
    try {
      const t = localStorage.getItem(KEY);
      if (t && deserialize(t)) return true;
    } catch (e) { }
    return false;
  }

/* ---------- icons ---------- */
  const IC = {
    home: '<path d="M3.5 11 12 4l8.5 7M6 9.5V20h12V9.5M10 20v-5h4v5"/>',
    biz: '<rect x="5" y="3" width="10" height="18" rx="1"/><path d="M15 9h4v12h-4M8.5 7h3M8.5 11h3M8.5 15h3"/>',
    phone: '<rect x="7" y="2.5" width="10" height="19" rx="2.5"/><path d="M11 18.5h2"/>',
    chat: '<path d="M4 5.5h16v10H10l-4 3.5v-3.5H4z"/>',
    chart: '<path d="M4 19V5M4 19h16M8 15l3-4 3 2 5-6"/>',
    back: '<path d="M14.5 5 7.5 12l7 7"/>',
    gov: '<path d="M3 9.5 12 4l9 5.5zM5.5 10v7M10 10v7M14 10v7M18.5 10v7M3 20h18"/>',
    tax: '<path d="M7 3.5h7l4 4V20.5H7zM14 3.5v4h4M9.5 13h6M9.5 16.5h4"/>',
    bank: '<path d="M3 9.5 12 4l9 5.5M5 10v8M9.5 10v8M14.5 10v8M19 10v8M3 20h18"/>',
    invest: '<path d="M3.5 17 9 11.5l3.5 3L20 6.5M15 6.5h5v5"/>',
    rocket: '<path d="M12 3c3 2 5 5 5 9l-2 3H9l-2-3c0-4 2-7 5-9zM9 15l-2 4 3-1M15 15l2 4-3-1"/><circle cx="12" cy="10" r="1.6"/>',
    people: '<circle cx="9" cy="8.5" r="3"/><path d="M3.5 19c.6-3.2 2.9-5 5.5-5s4.9 1.8 5.5 5"/><circle cx="17" cy="9.5" r="2.3"/><path d="M16.5 14.2c2.2.2 3.7 1.7 4.2 4.3"/>',
    tie: '<path d="M9 4h6l-1 4 2 11-4 2-4-2 2-11z"/>',
    book: '<path d="M5 4.5h10a3 3 0 0 1 3 3V20H8a3 3 0 0 1-3-3zM5 17a3 3 0 0 1 3-3h10"/>',
    mega: '<path d="M4 10v4h3l8 4V6L7 10zM18 9.5a3.5 3.5 0 0 1 0 5"/>',
    shield: '<path d="M12 3.5 19 6v5.5c0 4-3 7-7 9-4-2-7-5-7-9V6z"/>',
    truck: '<path d="M3 6.5h11v9H3zM14 9.5h4l3 3v3h-7M7 18.5a1.5 1.5 0 1 0 .01 0M17 18.5a1.5 1.5 0 1 0 .01 0"/>',
    house: '<path d="M4 20V10l8-6 8 6v10zM9.5 20v-6h5v6"/>',
    office: '<rect x="4" y="4" width="16" height="16" rx="1.5"/><path d="M8 8h2M14 8h2M8 12h2M14 12h2M8 16h2M14 16h2"/>',
    deal: '<path d="M4 12l5-5 4 3 3-3 4 4-7 7-4-3-3 3zM8 15l2 1.5"/>',
    globe: '<circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17M12 3.5c3 3 3 14 0 17M12 3.5c-3 3-3 14 0 17"/>',
    cog: '<circle cx="12" cy="12" r="3"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M18.4 5.6l-2.1 2.1M7.7 16.3l-2.1 2.1"/>',
    coin: '<circle cx="12" cy="12" r="8"/><path d="M9.5 9.5c.5-1 1.5-1.5 2.5-1.5 1.5 0 2.5.8 2.5 2s-1 1.7-2.5 2-2.5.8-2.5 2 1 2 2.5 2c1 0 2-.5 2.5-1.5M12 6.5V8M12 16v1.5"/>',
    bag: '<path d="M5.5 8h13l-1 12h-11zM9 8V6.5a3 3 0 0 1 6 0V8"/>',
    grad: '<path d="M2.5 9 12 5l9.5 4-9.5 4zM6.5 11.5V16c0 1.5 2.5 3 5.5 3s5.5-1.5 5.5-3v-4.5"/>',
    doc: '<path d="M7 3.5h7l4 4V20.5H7zM14 3.5v4h4M9.5 12h6M9.5 15.5h6"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    alert: '<path d="M12 4 21 19H3zM12 10v4M12 16.5v.5"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
    mail: '<rect x="3.5" y="5.5" width="17" height="13" rx="2"/><path d="M4 7l8 6 8-6"/>',
    search: '<circle cx="11" cy="11" r="6"/><path d="M16 16l4 4"/>',
    tool: '<path d="M14.5 6.5a4 4 0 0 0-5 5L4 17l3 3 5.5-5.5a4 4 0 0 0 5-5l-2.5 2.5-2.5-.5-.5-2.5z"/>',
    star: '<path d="M12 4l2.5 5 5.5.8-4 3.9 1 5.5-5-2.7-5 2.7 1-5.5-4-3.9 5.5-.8z"/>',
    lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
    fire: '<path d="M12 3c1 3 5 5 5 10a5 5 0 0 1-10 0c0-2 1-3 2-4 0 2 1 3 2 3 0-3-1-6 1-9z"/>',
    bolt: '<path d="M13 3 5 13h6l-1 8 8-10h-6z"/>',
    news: '<path d="M5 5h11v14H7a2 2 0 0 1-2-2zM16 8h3v9a2 2 0 0 1-2 2M8 9h5M8 12h5"/>',
    chev: '<path d="M9.5 5l7 7-7 7"/>'
  };
  function svg(n, s) {
    return '<svg class="ic" width="' + (s || 22) + '" height="' + (s || 22) + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (IC[n] || IC.doc) + '</svg>';
  }

/* ---------- components ---------- */
  function bar(p, t) {
    return '<div class="bar"><i style="width:' + Math.max(0, Math.min(100, p)) + '%;background:' + (t || 'var(--blue)') + '"></i></div>';
  }
  function row(l, r, cls) {
    return '<div class="kv ' + (cls || '') + '"><span>' + l + '</span><b>' + r + '</b></div>';
  }
  function btn(label, act, p, cls) {
    return '<button class="btn ' + (cls || '') + '" data-a="' + act + '"' + (p !== undefined ? ' data-p="' + esc(JSON.stringify(p)) + '"' : '') + '>' + label + '</button>';
  }
  function card(inner, cls) {
    return '<div class="card ' + (cls || '') + '">' + inner + '</div>';
  }
  function sec(t, first) {
    return '<h2 class="sec' + (first ? ' first' : '') + '">' + t + '</h2>';
  }
  function noteBox(t, bad) {
    return '<div class="note' + (bad ? ' bad' : '') + '">' + t + '</div>';
  }
  function badge(t, c) {
    return '<span class="badge ' + (c || '') + '">' + t + '</span>';
  }
  function contact(icon, title, sub, act, p, bdg) {
    return '<button class="contact" data-a="' + act + '"' + (p !== undefined ? ' data-p="' + esc(JSON.stringify(p)) + '"' : '') + '><span class="cic" style="background:var(--surface2)">' + svg(icon) + '</span><span class="ctext"><b>' + title + '</b><small>' + sub + '</small></span>' + (bdg || '') + '<i>›</i></button>';
  }
  function seg(items, cur, act, p0) {
    return '<div class="seg" style="grid-template-columns:repeat(' + items.length + ',1fr)">' + items.map(it => '<button class="' + (it[0] === cur ? 'on' : '') + '" data-a="' + act + '" data-p="' + esc(JSON.stringify(Object.assign({}, p0 || {}, { v: it[0] }))) + '">' + it[1] + '</button>').join('') + '</div>';
  }
  function chips(items, cur, act, p0) {
    /* round 37: money labels without empty decimals, and a row of choices must fit on one line or it becomes a list */
    items = items.map(it => [it[0], typeof it[1] === 'string' ? it[1].replace(/(\d)\.0+ (?=[kMB])/g, '$1 ') : it[1]]);
    if (items.length > 5 || items.reduce((n, it) => n + String(it[1]).replace(/<[^>]*>/g, '').length * 7.4 + 26, 0) > 330) return ddown(items, cur, act, p0);
    return '<div class="chips">' + items.map(it => '<button class="btn chip ' + (it[0] === cur ? 'primary' : '') + '" data-a="' + act + '" data-p="' + esc(JSON.stringify(Object.assign({}, p0 || {}, { v: it[0] }))) + '">' + it[1] + '</button>').join('') + '</div>';
  }
  const NONMONEY = { name: 1, prm: 1, eqq: 1, frroy: 1, age: 1 };
  function inp(key, ph, val, type) {
    if (ui.inp[key] == null && val != null) ui.inp[key] = (type === 'text' || NONMONEY[key]) ? val : Math.round(val / fxr(CC()));
    return '<input class="inp" type="' + (type || 'number') + '" inputmode="' + (type === 'text' ? 'text' : 'numeric') + '" data-k="' + key + '" placeholder="' + esc(ph || '') + '" value="' + esc(ui.inp[key] == null ? '' : ui.inp[key]) + '">';
  }
  function inum(key, def) {
    const v = ui.inp[key];
    const typed = !(v == null || v === '');
    const n = parseFloat(String(typed ? v : def).replace(/\s/g, ''));
    if (isNaN(n)) return def || 0;
    return typed && !NONMONEY[key] ? n * fxr(CC()) : n;
  }
  function quick(key, vals) {
    return '<div class="chips">' + vals.map(v0 => {
      const v = NONMONEY[key] ? v0 : (window.niceAmt ? window.niceAmt(v0) : rl(v0));
      return '<button class="btn chip" data-a="setinp" data-p="' + esc(JSON.stringify({ k: key, v: v })) + '">' + (NONMONEY[key] ? v : mshort(v)) + '</button>';
    }).join('') + '</div>';
  }
  /* 25/50/75/100% of a total, exact (rounded down to whole local units) */
  function pctChips(key, total) {
    const f0 = fxr(CC()), tl = Math.max(0, Math.floor((total || 0) / f0));
    return '<div class="chips">' + [25, 50, 75, 100].map(pc => {
      const loc = Math.floor(tl * pc / 100);
      return '<button class="btn chip" data-a="setinp" data-p="' + esc(JSON.stringify({ k: key, v: loc * f0 })) + '"' + (loc > 0 ? '' : ' disabled') + '>' + pc + '% · ' + mshort(loc * f0) + '</button>';
    }).join('') + '</div>';
  }
  function stepper(label, val, act, p, min, max) {
    return '<div class="kv"><span>' + label + '</span><span class="stp"><button class="btn chip" data-a="' + act + '" data-p="' + esc(JSON.stringify(Object.assign({ d: -1 }, p))) + '"' + (min != null && val <= min ? ' disabled' : '') + '>−</button><b>' + (typeof val === 'number' ? val : val) + '</b><button class="btn chip" data-a="' + act + '" data-p="' + esc(JSON.stringify(Object.assign({ d: 1 }, p))) + '"' + (max != null && val >= max ? ' disabled' : '') + '>+</button></span></div>';
  }
  function tabsRow(items, cur, act, p0) {
    return '<div class="subtabs">' + items.map(it => '<button class="' + (it[0] === cur ? 'on' : '') + '" data-a="' + act + '" data-p="' + esc(JSON.stringify(Object.assign({}, p0 || {}, { v: it[0] }))) + '">' + it[1] + '</button>').join('') + '</div>';
  }
  function spark(vals, w, h) {
    w = w || 96;
    h = h || 30;
    if (!vals || vals.length < 2) return '';
    const mn = Math.min.apply(null, vals), mx = Math.max.apply(null, vals), rg = (mx - mn) || 1;
    const pts = vals.map((v, i) => [(i / (vals.length - 1)) * (w - 4) + 2, h - 3 - ((v - mn) / rg) * (h - 6)]);
    const up = vals[vals.length - 1] >= vals[0], col = up ? 'var(--green)' : 'var(--red)';
    const d = pts.map(p => p[0].toFixed(1) + ',' + p[1].toFixed(1)).join(' ');
    return '<svg class="spark" width="' + w + '" height="' + h + '" viewBox="0 0 ' + w + ' ' + h + '"><polygon points="2,' + h + ' ' + d + ' ' + (w - 2) + ',' + h + '" fill="' + col + '" opacity="0.13"/><polyline points="' + d + '" fill="none" stroke="' + col + '" stroke-width="1.8" stroke-linejoin="round"/></svg>';
  }
  function lineChart(vals, label) {
    const W = window.innerWidth > 960 ? 640 : 340, H = 150, pl = 8, pr = 8, pt = 14, pb = 22;
    if (!vals || vals.length < 2) return '<div class="muted small">The chart appears after your first week.</div>';
    let mn = Math.min.apply(null, vals), mx = Math.max.apply(null, vals);
    if (mx - mn < 1) {
      mx += 1;
      mn -= 1;
    }
    const pad = (mx - mn) * 0.08;
    mn -= pad;
    mx += pad;
    const X = i => pl + (i / (vals.length - 1)) * (W - pl - pr), Y = v => pt + (1 - (v - mn) / (mx - mn)) * (H - pt - pb);
    const d = vals.map((v, i) => X(i).toFixed(1) + ',' + Y(v).toFixed(1)).join(' ');
    const last = vals[vals.length - 1], col = last >= vals[0] ? 'var(--green)' : 'var(--red)';
    const zero = (mn < 0 && mx > 0) ? '<line x1="' + pl + '" x2="' + (W - pr) + '" y1="' + Y(0).toFixed(1) + '" y2="' + Y(0).toFixed(1) + '" stroke="var(--line)" stroke-dasharray="3 4"/>' : '';
    return '<svg class="chart" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="' + esc(label || 'chart') + '">' + zero + '<polygon points="' + X(0).toFixed(1) + ',' + (H - pb) + ' ' + d + ' ' + X(vals.length - 1).toFixed(1) + ',' + (H - pb) + '" fill="' + col + '" opacity="0.12"/><polyline points="' + d + '" fill="none" stroke="' + col + '" stroke-width="2.2" stroke-linejoin="round" stroke-linecap="round"/><circle cx="' + X(vals.length - 1).toFixed(1) + '" cy="' + Y(last).toFixed(1) + '" r="3.6" fill="' + col + '"/><text x="' + pl + '" y="' + (H - 6) + '" class="ax">Week 1</text><text x="' + (W - pr) + '" y="' + (H - 6) + '" text-anchor="end" class="ax">Week ' + vals.length + '</text><text x="' + (W - pr) + '" y="' + (Y(last) - 9).toFixed(1) + '" text-anchor="end" class="ax strong">' + mshort(last) + '</text></svg>';
  }

/* ---------- navigation ---------- */
/* Main window sections (rail) and their root views. The phone has its own page stack. */
  const SECS = [['home', 'Home', 'home'], ['cos', 'Companies', 'biz'], ['hq', 'Group', 'office'], ['phone', 'Phone', 'phone'], ['meet', 'Inbox', 'chat']];
  const onTab = (k) => ui.tab === k;
  const ROOT = { home: 'home', cos: 'cos', hq: 'hq', meet: 'meetings' };
  const ROOTV = Object.keys(ROOT).map(k => ROOT[k]);
  const SEC_OF = {
    office: 'hq',
    group: 'hq',
    dealroom: 'hq',
    mgmt56: 'hq',
    fr56: 'hq',
    hq: 'hq',
    hqhire: 'hq',
    hqmk: 'hq',
    managers: 'hq',
    suppliers: 'hq',
    cos: 'cos',
    home: 'home',
    meetings: 'meet',
    co: 'cos',
    newbiz: 'cos',
    newco: 'cos',
    franchises: 'cos',
    brandneg: 'cos',
    hire: 'cos',
    mgrhire: 'cos'
  };
  const ALIAS = {
    office: ['hq', { t: 'office' }],
    group: ['hq', { t: 'group' }],
    dealroom: ['hq', { t: 'dealroom' }],
    world: ['news', { t: 'world' }],
    worldhub: ['news', {}]
  };
  const PHONE_APPS = [
    'bank',
    'pacct',
    'tax',
    'invest',
    'pe56',
    'startups',
    'rivals',
    'news',
    'reviews',
    'rvdetail',
    'msgs',
    'mail',
    'meet',
    'stats',
    'settings',
    'clubs',
    'registry',
    'lux'
  ];
  const MEET_APPS = { msgs: 'msgs', mail: 'mail', meet: 'meet' };
  ui.ph = { n: 'home', p: {} };
  ui.phStack = [];
  ui.phoneOn = window.innerWidth > 960;
  ui.inPhone = false;
  function isMobile() {
    return window.innerWidth <= 960;
  }
  function phoneGo(n, p) {
    if (MEET_APPS[n]) {
      if (ui.tab !== 'meet') ui.stack = [];
      ui.tab = 'meet';
      ui.mtab = MEET_APPS[n];
      ui.view = { n: 'meetings', p: {} };
      ui.inp = {};
      render(true);
      return;
    }
    if (ui.tab !== 'phone') {
      ui.phFrom = { tab: ui.tab, view: ui.view, stack: ui.stack.slice() };
      ui.phStack = [];
      ui.tab = 'phone';
    } else if (ui.ph.n !== 'home') ui.phStack.push(ui.ph);
    ui.ph = { n, p: p || {} };
    ui.phoneOn = true;
    ui.inp = {};
    render(true);
  }
  function phBack() {
    if (ui.thread != null && (ui.ph.n === 'mail' || ui.ph.n === 'msgs')) {
      ui.thread = null;
      ui.threadCo = null;
      render(true);
      return;
    }
    ui.thread = null;
    ui.threadCo = null;
    if (!ui.phStack.length && ui.phFrom) {
      const f = ui.phFrom;
      ui.phFrom = null;
      ui.ph = { n: 'home', p: {} };
      ui.tab = f.tab;
      ui.view = f.view;
      ui.stack = f.stack;
      ui.inp = {};
      render();
      return;
    }
    ui.ph = ui.phStack.length ? ui.phStack.pop() : { n: 'home', p: {} };
    ui.inp = {};
    render(true);
  }
  function go(n, p) {
    p = p || {};
    if (ALIAS[n]) {
      const a = ALIAS[n];
      n = a[0];
      p = Object.assign({}, a[1], p);
    }
    if (PHONE_APPS.indexOf(n) >= 0) {
      phoneGo(n, p);
      return;
    }
    if (ROOTV.indexOf(n) >= 0) {
      const t = Object.keys(ROOT).filter(k => ROOT[k] === n)[0];
      ui.tab = t;
      ui.stack = [];
      ui.view = { n, p };
      ui.inp = {};
      render(true);
      return;
    }
    if (ui.tab === 'phone') {
      ui.stack.push(Object.assign({}, ui.view, { tab: 'phone', ph: ui.ph, phStack: ui.phStack.slice(), phFrom: ui.phFrom }));
      ui.tab = SEC_OF[n] || 'cos';
      if (ui.tab === 'phone') ui.tab = 'cos';
    } else {
      ui.stack.push(Object.assign({}, ui.view, { tab: ui.tab }));
      if (SEC_OF[n]) ui.tab = SEC_OF[n];
    }
    ui.view = { n, p };
    ui.inp = {};
    render(true);
  }
  function back() {
    if (ui.inPhone && ui.ph.n !== 'home') {
      phBack();
      return;
    }
    if (ui.stack.length) {
      const v = ui.stack.pop();
      ui.tab = v.tab || ui.tab;
      ui.view = { n: v.n, p: v.p };
      if (v.ph) {
        ui.ph = v.ph;
        ui.phStack = v.phStack || [];
        ui.phFrom = v.phFrom || null;
      }
    } else ui.view = { n: ROOT[ui.tab] || 'home', p: {} };
    ui.inp = {};
    render();
  }
  function tabTo(t) {
    if (t === 'phone') {
      ui.tab = 'phone';
      ui.ph = { n: 'home', p: {} };
      ui.phStack = [];
      ui.phFrom = null;
      ui.thread = null;
      ui.inp = {};
      render(true);
      return;
    }
    if (t !== 'meet' && MEET_APPS[t]) {
      phoneGo(t, {});
      return;
    }
    if (t !== 'meet' && PHONE_APPS.indexOf(t) >= 0) {
      ui.tab = 'phone';
      ui.phStack = [];
      ui.phFrom = null;
      ui.ph = { n: 'home', p: {} };
      phoneGo(t, {});
      return;
    }
    if (t === 'meet' && ui.tab === 'meet') ui.mtab = 'dec';
    if (t === 'meet') ui.thread = null;
    ui.tab = t;
    ui.stack = [];
    ui.view = { n: ROOT[t] || t, p: {} };
    ui.inp = {};
    if (isMobile() && ui.phoneOn) ui.phoneOn = false;
    render(true);
  }
  function setView(n, p) {
    ui.view = { n, p: p || {} };
    render();
  }

/* ---------- sheets, confirm, toast ---------- */
  function ddown(items, cur, act, p0) {
    const c = items.find(it => it[0] === cur) || items[0];
    return '<button class="pick" data-a="ddopen" data-p="' + esc(JSON.stringify({ items, cur, act, p0 })) + '"><span>' + c[1] + '</span><i>▾</i></button>';
  }
  function openSheet(html, cls) {
    ui.sheet = { html, cls: cls || '' };
    render();
  }
  function closeSheet() {
    /* the next decision pops up only after another pop-up, or when days passed while a sheet was open (ui.popDue,
       ui/screens/home.js showPop); closing an ordinary sheet (a sale, a confirm) does not bring one up */
    const wasPop = !!(ui.sheet && ui.sheet.cls === 'msgpop');
    if (wasPop && ui.popId && S) {
      const m = S.inbox.find(x => x.id === ui.popId);
      if (m) m.snz = S.week;
    }
    ui.sheet = null;
    render();
    if ((wasPop || ui.popDue) && window.showPop && !ui.skipPop) window.showPop();
  }
  function confirmThen(title, body, label, fn, danger) {
    if (!S.settings.confirm && !danger) {
      fn();
      return;
    }
    const _c = CTXCO;
    ui.confirmFn = () => {
      setCtx(_c);
      try {
        fn();
      } finally {
        setCtx(null);
      }
    };
    openSheet('<h2>' + title + '</h2><p class="lead">' + body + '</p><div class="btnrow">' + btn('Cancel', 'sheetclose', undefined, 'ghost') + btn(label || 'Yes, do it', 'confirmgo', undefined, 'primary' + (danger ? ' danger' : '')) + '</div>');
  }
  function toast(t, bad) {
    clearTimeout(ui.toastT);
    ui.toast = { t, bad };
    render();
    ui.toastT = setTimeout(() => {
      ui.toast = null;
      const el = document.querySelector('.toast');
      if (el) el.remove();
    }, 3200);
  }
  ACT.ddopen = p => {
    openSheet('<h2>Choose</h2><div class="pklist pkgrid' + (p.items.length > 8 ? ' many' : '') + '">' + p.items.map(it => '<button class="opt pk ' + (it[0] === p.cur ? 'on' : '') + '" data-a="ddset" data-p="' + esc(JSON.stringify({ act: p.act, p0: p.p0, v: it[0] })) + '"><span>' + it[1] + '</span>' + (it[0] === p.cur ? '<i>✓</i>' : '') + '</button>').join('') + '</div>');
  };
  ACT.ddset = p => {
    ui.sheet = null;
    ACT[p.act](Object.assign({}, p.p0 || {}, { v: p.v }));
  };
  const ERR = {
    locked: 'This role is not available to a group of your size yet.',
    brand: 'Your brand is too weak to take abroad yet (reputation 35+).',
    nofr: 'Launch your franchise first.',
    already: 'Already done.',
    banned: 'That business is illegal in this country.',
    homeoffice: 'At home there is room for your personal assistant only. Move your main office to a coworking space or bigger to hire more.',
    desks: 'No free desk. Rent a bigger office.',
    office: 'Rent an office first.',
    cash: 'Not enough cash.',
    bad: 'That is not possible.',
    have: 'Already done.',
    small: 'Amount too small.',
    declined: 'The bank declined.',
    refuse: 'They refused that offer.',
    taken: 'No longer available.',
    desks: 'Not enough desks in the office.',
    office: 'Rent an office first.',
    missing: 'Checklist is not complete.',
    pickacc: 'Pick an accountant first.',
    loan: 'The bank will not lend that much.',
    noequity: 'Not enough equity to pay out.',
    divonly: 'Only dividends are possible from an AS.',
    notAS: 'Only an AS can do that.',
    acc: 'Pick an accountant.'
  };
  function res(r, okMsg) {
    if (r === 'ok' || r === true) {
      if (okMsg) toast(okMsg);
      return true;
    }
    const t = typeof r === 'string' ? (ERR[r] || (r.indexOf('stock:') === 0 ? 'You need ' + money(+r.split(':')[1]) + ' in the company for opening stock.' : r.indexOf('locked:') === 0 ? 'Locked for ' + r.split(':')[1] + ' more weeks.' : r)) : 'That did not work.';
    toast(t, true);
    return false;
  }

/* ---------- rendering ---------- */
  const AGE0 = 18, AGE1 = 110;
  function render(top) {
    const app = $('app');
    const sc = app.querySelector('.screen');
    if (sc && !top && ui._sk) ui.scroll[ui._sk] = sc.scrollTop;
    if (S && !S.over) S.cos.forEach(c => {
      if (c.st === 'setup' && typeof tryAutoOpen === 'function' && tryAutoOpen(c)) {
        ui.toast = { t: c.name + ' is open!' };
        clearTimeout(ui.toastT);
        ui.toastT = setTimeout(() => {
          ui.toast = null;
          render();
        }, 3000);
      }
    });
    let html;
    /* the main menu comes first when there is a game to continue or a saved one (features/player/saves.js V.menu) */
    if (ui.menu && V.menu) html = V.menu(); else if (!S) html = V.start(); else if (S.over) html = V.over(); else html = shell();
    app.innerHTML = locText(html + (ui.menu ? '' : sheetHtml())) /* pop-ups wait until you leave the main menu */ + (ui.toast ? '<div class="toast' + (ui.toast.bad ? ' bad' : '') + '">' + esc(ui.toast.t) + '</div>' : '');
    ui._sk = ui.tab === 'phone' ? 'ph:' + ui.ph.n + JSON.stringify(ui.ph.p) : ui.tab + ':' + ui.view.n + JSON.stringify(ui.view.p) + (ui.view.n === 'meetings' ? ui.mtab : '');
    const s2 = app.querySelector('.screen');
    if (s2) s2.scrollTop = top ? 0 : (ui.scroll[ui._sk] || 0);
  }
  function safe(f, p) {
    try {
      return f ? f(p) : '<div class="card">Unknown screen.</div>';
    } catch (e) {
      console.error(e);
      return '<div class="card"><h3>Screen error</h3><p class="muted small">' + esc(e.message) + '</p></div>';
    }
  }
  function ctxFromView() {
    const v = ui.view;
    if (v && v.n === 'newco' && ui.nc) return { country: ui.nc.country || S.country };
    if (v && v.p && v.p.id) {
      const c = getCo(v.p.id);
      if (c && c.country) return c;
    }
    return null;
  }
  function vhead(title, sub, right, act) {
    return '<header class="vh"><button class="bk" data-a="' + (act || 'back') + '" aria-label="Back">' + svg('back', 18) + '</button><div class="vht"><h1>' + esc(title) + '</h1>' + (sub ? '<p>' + sub + '</p>' : '') + '</div>' + (right || '') + '</header>';
  }
  function isRoot() {
    return ui.tab !== 'phone' && ROOT[ui.tab] === ui.view.n && !ui.stack.length;
  }
  function navbar() {
    const n = (typeof meetCount === 'function') ? meetCount() : unreadBadge();
    return '<nav class="nb" aria-label="Main">' + SECS.map(t => '<button class="' + (onTab(t[0]) ? 'on' : '') + '" data-a="tab" data-p="' + t[0] + '">' + svg(t[2], 24) + '<span>' + t[1] + '</span>' + (t[0] === 'meet' && n ? '<b class="nbd">' + n + '</b>' : '') + '</button>').join('') + '</nav>';
  }
  function mainBody() {
    if (ui.tab === 'phone') {
      if (ui.ph.n === 'home') return safe(V.phonehome) + (window.bkView ? bkView() : '');
      const ht = V.phtitle ? V.phtitle(ui.ph) : null;
      return vhead((ht && ht.t) || V.titles[ui.ph.n] || '', ht && ht.sub, ht && ht.right, 'phback') + safe(V[ui.ph.n], ui.ph.p);
    }
    setCtx(ctxFromView());
    let h;
    try {
      const body = safe(V[ui.view.n], ui.view.p);
      /* a main screen: a way back to the tab you came from (features/people/salary_talks.js), and a bankruptcy
         notice over it until it is read (features/company/chain_registration_and_boards.js) */
      if (isRoot()) h = (window.backToBtn ? body.replace('<header class="hh">', '<header class="hh">' + backToBtn()) : body) + (window.bkView ? bkView() : '');
      else {
        const hd = V.heads && V.heads[ui.view.n] ? V.heads[ui.view.n](ui.view.p) : {};
        h = vhead(hd.t || V.title(ui.view), hd.sub, hd.right) + body;
      }
      h = locText(h);
    } finally {
      setCtx(null);
    }
    return h;
  }
  function shell() {
    const k = ui.tab === 'phone' ? 'ph-' + ui.ph.n : 'v-' + ui.view.n;
    const root = ui.tab === 'phone' ? ui.ph.n === 'home' : isRoot();
    return '<div class="os2"><main class="screen ' + k + (root ? ' root' : '') + '">' + mainBody() + '</main>' + navbar() + '</div>';
  }
  function rail() {
    const un = unreadBadge();
    return '<nav class="rail" aria-label="Main"><div class="logo">L</div>' + SECS.map(t => '<button class="ri' + (onTab(t[0]) ? ' on' : '') + '" data-a="tab" data-p="' + t[0] + '">' + svg(t[2], 22) + '<span>' + t[1] + '</span></button>').join('') +
    '<button class="ri' + (ui.phoneOn ? ' on' : '') + '" data-a="tab" data-p="phone">' + svg('phone', 22) + '<span>Phone</span>' + (un ? '<b class="dot">' + un + '</b>' : '') + '</button>' +
    '<div class="gap"></div><button class="ri' + (ui.tab === 'settings' ? ' on' : '') + '" data-a="tab" data-p="settings">' + svg('cog', 22) + '<span>Settings</span></button></nav>';
  }
  function crumbs() {
    const lab = ui.tab === 'settings' ? 'Settings' : (SECS.filter(t => t[0] === ui.tab)[0] || [0, 'Home'])[1];
    const items = [];
    ui.stack.forEach((e, i) => {
      if (ROOTV.indexOf(e.n) < 0) items.push([i, V.title(e)]);
    });
    const cur = ROOTV.indexOf(ui.view.n) >= 0 ? null : V.title(ui.view);
    let h = '<button data-a="crumbroot">' + esc(lab) + '</button>';
    const all = items.map(x => '<button data-a="crumb" data-p="' + x[0] + '">' + esc(x[1]) + '</button>');
    if (cur) all.push('<b>' + esc(cur) + '</b>');
    if (!cur) return '<div class="crumbs"><b>' + esc(lab) + '</b></div>';
    return '<div class="crumbs">' + h + all.map(x => '<i>/</i>' + x).join('') + '</div>';
  }
  function sheetHtml() {
    return ui.sheet ? (window.sheet36 ? window.sheet36(ui.sheet) : '<div class="scrim" data-a="scrim"><div class="sheet ' + ui.sheet.cls + '" role="dialog" aria-modal="true">' + ui.sheet.html + '</div></div>') : '';
  }

/* ---------- events ---------- */
  document.addEventListener('click', e => {
    const t = e.target.closest('[data-a]');
    if (!t) return;
    const a = t.getAttribute('data-a');
    if (a === 'scrim') return; /* round 36: a pop-up closes only with its own buttons */
    if (t.disabled) return;
    ui.inPhone = ui.tab === 'phone' && !t.closest('.scrim');
    let p = t.getAttribute('data-p');
    try {
      p = p != null ? JSON.parse(p) : undefined;
    } catch (er) {
      /* plain string */
      p = t.getAttribute('data-p');
    }
    const f = ACT[a];
    if (f) {
      try {
        if (S) setCtx(ui.inPhone ? null : ((p && typeof p === 'object' && p.id && getCo(p.id)) || ctxFromView()));
        f(p, t);
      } catch (er) {
        console.error(er);
        toast('Error: ' + er.message, true);
      } finally {
        setCtx(null);
      }
    } else console.warn('no action', a);
  });
  document.addEventListener('input', e => {
    const k = e.target.getAttribute && e.target.getAttribute('data-k');
    if (k) ui.inp[k] = e.target.value;
  });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && ui.sheet && document.querySelector('.sheet > .x36')) closeSheet();
  });
  window.addEventListener('resize', () => {
    const m = isMobile();
    if (ui._m !== m) {
      ui._m = m;
      if (!m) ui.phoneOn = ui.phoneOn || false;
      if (S) render();
    }
  });

  V.title = function (v) {
    const n = v.n, p = v.p || {};
    const T = { newbiz: 'New business', newco: 'Set up business', co: p.id && getCo(p.id) ? getCo(p.id).name : 'Company' };
    return (n === 'co' && T.co) || (V.titles && V.titles[n]) || T[n] || n;
  };
  ACT.back = back;
  ACT.tab = p => tabTo(p);
  ACT.sheetclose = closeSheet;
  ACT.confirmgo = () => {
    const f = ui.confirmFn;
    ui.confirmFn = null;
    closeSheet();
    if (f) f();
  };
  ACT.setinp = p => {
    ui.inp[p.k] = String(Math.round(NONMONEY[p.k] ? p.v : p.v / fxr(CC())));
    render();
  };
  ACT.go = p => go(p.n, p.p);
  ACT.phone = () => tabTo('phone');
  ACT.phapp = p => phoneGo(p.n || p, {});
  ACT.phback = phBack;
  ACT.crumbroot = () => tabTo(ui.tab);
  ACT.crumb = i => {
    const e = ui.stack[i];
    if (!e) return;
    ui.stack.length = i;
    ui.tab = e.tab || ui.tab;
    ui.view = { n: e.n, p: e.p };
    ui.inp = {};
    render(true);
  };
  window.UI = {
    ddown,
    ui,
    V,
    ACT,
    esc,
    nok,
    tone,
    sgn,
    svg,
    bar,
    row,
    btn,
    card,
    sec,
    noteBox,
    badge,
    contact,
    seg,
    chips,
    inp,
    inum,
    quick,
    pctChips,
    stepper,
    tabsRow,
    spark,
    lineChart,
    go,
    back,
    tabTo,
    setView,
    openSheet,
    closeSheet,
    confirmThen,
    toast,
    res,
    render,
    save,
    flushSave: () => { const ok = packT ? (clearTimeout(packT), writeNow()) : true; if (APP) { diskFlush(); cloudFlush(); } return ok; },
    loadSaved,
    NAME,
    PATCH,
    SUPPORT,
    disk,
    diskReady,
    dev,
    inCloud: () => cloudOn,
    ERR,
    KEY,
    phoneGo,
    vhead,
    AGE0,
    AGE1
  };
})();

(function () {
  function fitH() {
    try {
      const vv = window.visualViewport;
      const h = Math.min(window.innerHeight, vv && vv.height ? vv.height + (vv.offsetTop || 0) : 1e9);
      document.documentElement.style.setProperty('--app-h', Math.round(h) + 'px');
    } catch (e) { }
  }
  fitH();
  window.addEventListener('resize', fitH);
  if (window.visualViewport) {
    window.visualViewport.addEventListener('resize', fitH);
    window.visualViewport.addEventListener('scroll', fitH);
  }
})();

function unreadBadge() {
  const u = unreadSplit();
  return u.msgs + u.mail;
}


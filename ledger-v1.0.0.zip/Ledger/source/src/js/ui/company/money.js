/* ---- ui/company/money.js ---- */
(function () {
  'use strict';
  const U = window.UI, { ui, V, ACT, esc, nok, tone, sgn, svg, bar, row, btn, card, sec, noteBox, badge, contact, seg, chips, inp, inum, quick, pctChips, stepper, tabsRow, go, setView, openSheet, closeSheet, confirmThen, toast, res, render, save } = U;
  const CT = window.CT;
  const FIN_SUB = {
    books: ['Accounts', 'chart'],
    value: ['Ownership and value', 'coin'],
    sell: ['Sell company or shares', 'deal'],
    owner: ['Move money and salary', 'coin'],
    loans: ['Loans', 'bank'],
    legal: ['Accountant and legal form', 'tax'],
    tx: ['Transactions', 'doc'],
    close: ['Close down', 'check']
  };
  function finPart(co, bd, k) {
    if (window.R6FIN && window.R6FIN[k]) { const r6 = window.R6FIN[k](co, bd); if (r6 != null) return r6; }
    if (k === 'value') return '<div class="triple"><div class="stack">' + dealPart(co, bd, 'value') + dealPart(co, bd, 'sell') + '</div><div class="stack">' + ownedThrough(co) + (CT.marketRow || CT.ownersRow ? '<div class="lrows">' + (CT.marketRow ? CT.marketRow(co) : '') + (CT.ownersRow ? CT.ownersRow(co) : '') + '</div>' : '') + '</div></div>';
    if (k === 'sell' || k === 'close') return dealPart(co, bd, k);
    const loans = S.loans.filter(l => l.co === co.id);
    const recv = sum(co.recv, r => r.a);
    const pay = co.pay.wages + co.pay.other + co.pay.rent + co.pay.tax;
    const eq = companyAssets(co) - companyDebts(co);
    let h = '';
    if (k === 'books') {
      h += card('<h3>Balance</h3>' + row('Cash', nok(co.cash)) + row('Customers owe', nok(recv)) + (BD[co.type].b2b > 0 ? row('Credit checks on customers', co.flags.ccheck ? 'On' : 'Off') + btn(co.flags.ccheck ? 'Stop credit checks' : 'Check customers before invoicing', 'ccheck', { id: co.id }, 'chip') + '<p class="muted small">Costs about 0.4% of invoices and cuts unpaid invoices a lot.</p>' : '') + row('Stock', nok(co.inv)) + row('Equipment and vehicles', nok(eqBook(co))) + (co.prem && co.prem.owned ? row('Property', nok(co.prem.val)) : '') + (co.props && co.props.length ? row('Rental properties', nok(sum(co.props, p => p.val))) : '') + (co.fm && co.fm.assets ? row('Other assets', nok(co.fm.assets)) : '') + row('Debts and accruals', '<span class="neg">' + nok(companyDebts(co)) + '</span>') + row('Equity', '<span class="' + sgn(eq) + '">' + nok(eq) + '</span>', 'total') + (co.form === 'AS' ? row('Tax to pay (accrued)', nok(co.pay.tax)) + (co.lossCarry > 0 ? row('Tax loss carried forward', nok(co.lossCarry)) : '') : '') + row('VAT to settle', nok(co.vatAcc)));
      const b = ui.books || 'm';
      h += tabsRow([['w', 'Week'], ['m', 'Month'], ['y', 'Year'], ['ly', 'Last year']], b, 'books', { id: co.id });
      h += CT.plCard(co.bk[b] || {}, { w: 'This week', m: 'This month', y: 'Year to date', ly: 'Last year' }[b]);
    } else if (k === 'owner') {
      const outMax = co.form === 'ENK' ? Math.max(0, co.cash) : divMax(co);
      h += card('<h3>Put money in</h3><p class="muted small">From your own account (' + nok(Math.max(0, liquid())) + ' available).</p>' + inp('amtIn', 'Amount', null) + pctChips('amtIn', liquid()) + '<div class="btnrow">' + btn('Put money in', 'cinject', { id: co.id }, 'primary') + '</div>');
      h += card('<h3>' + (co.form === 'ENK' ? 'Take money out' : 'Pay a dividend') + '</h3><p class="muted small">' + (co.form === 'ENK' ? 'As a sole proprietor you can take out the company cash freely. It is your income either way.' : 'Can be paid from profits kept in the company (equity over share capital), keeping two weeks of costs as cash. Up to ' + nok(outMax) + ' now. Dividends are taxed at ' + pc(CO[co.country].divTax, 2) + ' for you personally.') + '</p>' + inp('amtOut', 'Amount', null) + pctChips('amtOut', outMax) + '<div class="btnrow">' + (co.form === 'ENK' ? btn('Take out', 'cdraw', { id: co.id }, 'primary') : btn('Pay dividend', 'cdiv', { id: co.id }, 'primary')) + '</div>');
      if (co.form === 'AS') h += card('<h3>Your salary</h3><p class="muted small">Salary is a cost for the company and taxed as income for you. Dividends have a different tax. Currently ' + money(co.ownerSalary) + ' per month.</p>' + chips([0, 20000, 40000, 60000, 80000].map(niceAmt).map(v => [v, v ? mshort(v) : 'None']), co.ownerSalary, 'cosal', { id: co.id }));
    } else if (k === 'loans') {
      h += '<div class="card"><h3>Loans</h3>' + (loans.length ? loans.map(l => '<div class="opt"><div class="bhead"><div><b>' + esc(l.name) + '</b><small>' + pc(loanRate(l), 1) + ' · ' + money(l.pay) + ' per month' + (l.guar ? ' · you guarantee' : '') + '</small></div><div class="rt"><b>' + money(l.bal) + '</b>' + btn('Repay', 'repaysheet', { id: l.id }, 'chip') + '</div></div></div>').join('') : '<p class="muted small">No loans.</p>') + btn('Borrow for this company', 'loansheet', { id: co.id }, 'wide') + '</div>';
    } else if (k === 'legal') {
      h += card('<h3>Accountant and legal form</h3>' + (co.acc ? row('Accountant', esc(co.acc.name)) + row('Rating', stars(co.acc.rating || 4)) + row('Fee', money(co.acc.fee) + ' / month') : '<p class="muted small">' + (co.form === 'ENK' ? 'Sole proprietors use basic bookkeeping software (' + money(KC(480, co.country)) + ' per month).' : 'No accountant yet.') + '</p>') + (co.form === 'ENK' ? btn('Convert to ' + (CC().forms.AS || 'limited company') + '…', 'tcAS', { id: co.id }, 'wide') : ''));
      h += CT.advisers(co);
    } else if (k === 'tx') {
      h += card('<h3>Recent transactions</h3>' + (co.tx.length ? co.tx.slice(0, 14).map(t => '<div class="kv tx"><span><em>W' + t.w + '</em>' + esc(t.l) + '</span><b class="' + sgn(t.a) + '">' + (t.a > 0 ? '+' : '') + npadL(t.a) + '</b></div>').join('') : '<p class="muted small">Nothing yet.</p>'));
    }
    return h;
  }
  /* selling unpaid invoices to the bank (invoiceSale / sellInvoices in engine/money/money.js) */
  CT.invSale = function (co) {
    const q = invoiceSale(co);
    if (!q.n) return '';
    return '<div class="card"><div class="bhead"><b>Sell unpaid invoices</b><small>' + q.n + (q.n > 1 ? ' invoices · ' : ' invoice · ') + mshort(q.a) + '</small></div><span class="tipt">The bank pays you now, less a fee of ' + money(q.fee) + ', and collects the invoices itself, also from customers who never pay. Useful when the company is profitable but short of cash.</span>' + btn('Get ' + money(q.get) + ' now', 'sellinv', { id: co.id }, 'wide') + '</div>';
  };
  ACT.invsheet = p => { const co = getCo(p.id); if (co) U.openSheet(CT.invSale(co) || '<p class="muted">No unpaid invoices.</p>'); };
  ACT.sellinv = p => {
    const co = getCo(p.id);
    if (!co) return;
    const r = sellInvoices(co);
    if (r === 'none') { toast('No unpaid invoices to sell.', true); return; }
    ui.sheet = null;
    toast('The bank paid ' + money(r.get) + ' for ' + r.n + (r.n > 1 ? ' invoices' : ' invoice') + ' (fee ' + money(r.fee) + ').');
    save();
    render();
  };
  /* who owns it: you directly or a holding company of yours */
  function ownedThrough(co) {
    if (co.form !== 'AS' || co.type === 'hold') return '';
    const holds = S.cos.filter(x => x.type === 'hold' && x.st === 'open'), hc = co.hold && getCo(co.hold);
    return '<h2 class="sec">Owned through</h2><div class="card">' + (hc ? row('Holding company', esc(hc.name)) + '<span class="tipt">Dividends go to the holding company, taxed far lower.</span>' : holds.length ? '<span class="tipt">Move it under a holding company to collect its dividends there, taxed far lower.</span>' + holds.map(x => btn('Move under ' + esc(x.name), 'tohold', { id: co.id, h: x.id }, 'wide')).join('') : '<span class="tipt">You own it directly. A holding company (Group › Holding companies) collects dividends taxed far lower.</span>' + btn('Holding companies', 'go', { n: 'holdings' }, 'wide')) + '</div>';
  }
  /* the line under each money page's name on the Money tab (ui/company/view.js) */
  function finSummary(co, bd, k) {
    const loans = S.loans.filter(l => l.co === co.id);
    return {
      books: 'Profit and loss, balance',
      owner: co.form === 'AS' ? 'Put in, take out, salary' : 'Put in or take out money',
      loans: loans.length ? loans.length + (loans.length > 1 ? ' loans' : ' loan') : 'No loans',
      legal: (co.acc ? co.acc.name : 'No accountant') + ' · ' + ((CO[co.country] || CC()).forms[co.form + 's'] || co.form),
      tx: co.tx.length ? 'Latest ' + Math.min(14, co.tx.length) + ' entries' : 'Nothing yet',
      value: dealSummary(co, bd, 'value') + ' · sell, move money',
      sell: 'Offers for the company or shares',
      close: 'Wind the company down'
    }[k] || '';
  }
  CT.FIN_SUB = FIN_SUB;
  CT.finPart = finPart;
  CT.finSummary = finSummary;
  ACT.cofin = p => {
    ui.view = { n: 'co', p: { id: p.id, t: 'fin', s: p.s || '' } };
    render(true);
  };
  ACT.books = p => {
    ui.books = p.v;
    render();
  };
  ACT.ccheck = p => {
    const co = getCo(p.id);
    co.flags.ccheck = co.flags.ccheck ? 0 : 1;
    save();
    render();
  };
  ACT.cinject = p => {
    const co = getCo(p.id), a = inum('amtIn', 0);
    if (a <= 0) return;
    if (!injectCash(co, a)) {
      toast('You do not have that much.', true);
      return;
    }
    ui.inp.amtIn = '';
    save();
    render();
    toast(money(a) + ' moved into the company.');
  };
  ACT.cdraw = p => {
    const co = getCo(p.id), a = inum('amtOut', 0);
    if (a <= 0) return;
    if (res(withdrawCash(co, a), money(a) + ' taken out.')) {
      ui.inp.amtOut = '';
      save();
      render();
    }
  };
  ACT.cdiv = p => {
    const co = getCo(p.id), a = inum('amtOut', 0);
    if (a <= 0) return;
    const eq = companyAssets(co) - companyDebts(co) - co.capital;
    confirmThen('Pay a dividend of ' + money(a) + '?', 'Equity available for dividends: ' + money(Math.max(0, eq)) + '. You will pay about ' + money(a * co.own / 100 * CO[co.country].divTax) + ' tax on it at year-end.', 'Pay dividend', () => {
      if (res(payDividend(co, a), 'Dividend paid.')) {
        ui.inp.amtOut = '';
        save();
        render();
      }
    });
  };
  ACT.cosal = p => {
    setOwnerSalary(getCo(p.id), p.v);
    save();
    render();
  };
  ACT.tcAS = p => {
    const co = getCo(p.id), c = CC();
    ui.convAcc = poolFor(co.country).acc[1].id;
    openSheet('<h2>Convert to ' + CC().forms.AS + '</h2><div class="card sense"><b>' + esc(co.name) + ' (' + esc(CC().forms.ENK) + ') becomes ' + esc(co.name) + ' ' + esc(CC().forms.AS) + '</b><p>You get limited liability and an accountant. Past profit this year is taxed as your income.</p></div>' +
      '<h3 class="gap">Step 1 of 2 · Share capital</h3><div class="card ctr"><span class="lab">You put into the company</span><b class="huge">' + nok(c.asCapital) + '</b><span class="lab">It stays in the company as cash it can spend</span>' + row('Paid from', 'Personal · ' + mshort(S.cash)) + '</div>' +
      '<h3 class="gap">What happens</h3><div class="card">' + row('Existing clients and equipment', '<span class="pos">Move over</span>') + row('Registration fee', nok(c.asConvFee)) + row('Accounting duty', '<span class="amb">Required</span>') + row('Tax', pc(c.corp, 0) + ' company tax, then dividend tax') + row('Your liability', '<span class="pos">Limited to share capital</span>') + '</div>' +
      '<h3 class="gap">Step 2 of 2 · Pick an accountant</h3><p class="muted small">Picking one pays ' + nok(c.asConvFee + c.asCapital) + ' and converts the company.</p>' + poolFor(co.country).acc.map(a => provRow(a, 'acc', null, { a: 'convgo', p: { id: co.id, a: a.id } })).join('') + btn('Cancel', 'sheetclose', undefined, 'ghost wide'));
  };
  ACT.convgo = p => {
    const co = getCo(p.id);
    closeSheet();
    if (res(convertToAS(co, p.a), 'Now a limited company.')) {
      save();
      render();
    }
  };
/* loans */
  ACT.loansheet = p => {
    const co = getCo(p.id);
    ui.loanTerm = ui.loanTerm || 60;
    const off = loanOffer('biz', 100000, co);
    openSheet('<h2>Borrow for ' + esc(co.name) + '</h2><p class="muted small">The bank looks at the company’s profit, assets and your own wealth. Credit band ' + off.band + '. Margin ' + pc(off.margin, 1) + ' above the policy rate ' + pc(policy(), 2) + '. Maximum now: <b>' + money(off.max) + '</b>.' + (off.ownBank ? ' Your own bank gives a discount.' : '') + '</p>' + inp('lamt', 'Amount') + '<div class="chips">' + [100000, 500000, 1000000, 5000000].map(v => '<button class="btn chip" data-a="setinp" data-p="' + esc(JSON.stringify({ k: 'lamt', v: v })) + '">' + mshort(v) + '</button>').join('') + '</div>' + chips([12, 36, 60, 120].map(m => [m, m / 12 + ' yr']), ui.loanTerm, 'loanterm', { id: co.id }) + '<label class="opt"><input type="checkbox" data-a="noop" id="guar" ' + (co.form === 'ENK' ? 'checked disabled' : '') + '> <span>Personal guarantee ' + (co.form === 'ENK' ? '(always for sole proprietors)' : '(lowers risk for the bank, risky for you)') + '</span></label>' + btn('Apply', 'loango', { id: co.id }, 'primary wide') + btn('Cancel', 'sheetclose', undefined, 'ghost wide'));
  };
  ACT.loanterm = p => {
    ui.loanTerm = p.v;
    ACT.loansheet({ id: p.id });
  };
  ACT.loango = p => {
    const co = getCo(p.id), a = Math.round(inum('lamt', 0));
    const g = document.getElementById('guar');
    const r = takeLoan('biz', a, ui.loanTerm || 60, co, g ? g.checked : false);
    closeSheet();
    if (r === 'ok') {
      toast('Loan approved: ' + money(a));
      save();
      render();
    } else res(r);
  };
  ACT.repaysheet = p => {
    const l = S.loans.find(x => x.id === p.id);
    if (!l) return;
    openSheet('<h2>Repay ' + esc(l.name) + '</h2><p class="muted small">Balance ' + money(l.bal) + '. Paying early saves interest.</p>' + inp('ramt', 'Amount', Math.min(l.bal, 100000)) + '<div class="chips"><button class="btn chip" data-a="setinp" data-p="' + esc(JSON.stringify({ k: 'ramt', v: l.bal })) + '">All</button>' + [100000, 500000].map(v => '<button class="btn chip" data-a="setinp" data-p="' + esc(JSON.stringify({ k: 'ramt', v: v })) + '">' + mshort(v) + '</button>').join('') + '</div>' + btn('Repay', 'repaygo', { id: l.id }, 'primary wide') + btn('Cancel', 'sheetclose', undefined, 'ghost wide'));
  };
  ACT.repaygo = p => {
    const l = S.loans.find(x => x.id === p.id);
    if (!l) return;
    const a = Math.round(inum('ramt', 0));
    closeSheet();
    if (a <= 0) return;
    if (repayLoan(l, a)) {
      toast('Repaid.');
      save();
      render();
    } else toast('Not enough money.', true);
  };
})();


/* ---- ui/company/headquarters.js ---- */
/* ===== Round 56: every company has a headquarters, its Staff › Management (and its own screen from Group › Group,
   V.mgmt56). It shows who runs the company and who works above the shop floor, with its own dashboard, and it is
   where each management role is hired: a vacancy opens the step screen for that role, always through the agency
   (ui/screens/hiring.js V.mgrhire).
   Four pages: Overview (the dashboard and everyone who works here) · Manager (this month's targets and the budget,
   features/people/targets_and_budgets.js, and what they may decide and look after: features/people/manager_duties.js) · Assistant (the assistant manager and their two jobs) · Team (the managing
   director, department heads and regional managers: features/people/management_team.js; for a chain, the levels of
   the chain above the store: features/company/org_chart.js). ===== */
window.HQ56 = window.HQ56 || {};
(function () {
  'use strict';
  const U = window.UI, { ui, V, ACT, esc, svg, btn, render } = U;
  const H = window.HQ56;
  const P = o => esc(JSON.stringify(o));
  const AUTHW = ['Asks you first', 'Within limits', 'Full control'];
  const ini2 = nm => String(nm || '?').split(/\s+/).slice(0, 2).map(x => x[0]).join('').toUpperCase();
  const tabOf = co => ((ui.hq56 || {})[co.id]) || 'ov';
  ACT.hq56t = p => { (ui.hq56 = ui.hq56 || {})[p.id] = p.v; render(); };
  H.open = (co, v) => { (ui.hq56 = ui.hq56 || {})[co.id] = v; (ui.stt56 = ui.stt56 || {})[co.id] = 'mgmt'; };
  const tabBtn = (co, v) => ['hq56t', { id: co.id, v }];
  const hire = (co, r) => ['go', { n: 'mgrhire', p: { id: co.id, r } }];
  const ch0 = co => window.R12 && R12.chainOf ? R12.chainOf(co) : null;
  /* a person: face, name, what they are; the action opens their page */
  const who = (n, sub, go, right) => '<button class="lrow" data-a="' + go[0] + '" data-p="' + P(go[1]) + '">' + (n && window.faceAv ? faceAv(n) : '<span class="av">' + esc(ini2(n && n.name)) + '</span>') + '<span class="ctext"><b>' + esc(n ? n.name : '') + '</b><small>' + sub + '</small></span>' + (right || '<i>›</i>') + '</button>';
  const vac = (title, sub, go) => '<button class="lrow vac56" data-a="' + go[0] + '" data-p="' + P(go[1]) + '"><span class="av dim">＋</span><span class="ctext"><b>' + esc(title) + '</b><small>' + esc(sub) + '</small></span><span class="pill">Hire ›</span></button>';
  /* everyone who works at the headquarters, and what they cost a month */
  function people(co) {
    const L = [], m = co.mgr && S.npcs[co.mgr], a = co.asst && S.npcs[co.asst.npc];
    if (m) L.push({ k: 'mgr', n: m, w: (co.mgrWage || 0) + (co.mgrBonusLast || 0) });
    if (a) L.push({ k: 'asst', n: a, w: co.asst.wage || 0 });
    (window.TEAM56 && TEAM56.slots ? TEAM56.slots(co) : []).forEach(([k, x]) => { if (x && S.npcs[x.npc]) L.push({ k, n: S.npcs[x.npc], w: x.wage || 0, x }); });
    return L;
  }
  H.people = people;

  /* ---------- Overview ---------- */
  function overview(co, bd) {
    const L = people(co), D = window.DASH56, m = co.mgr && S.npcs[co.mgr], ac = window.actingMgr ? actingMgr(co) : null, an = ac && S.npcs[ac.id];
    let h = '';
    /* nobody yet: the roles to choose from, straight away */
    if (!L.length && !an) {
      const slots = window.TEAM56 && TEAM56.slots ? TEAM56.slots(co) : [];
      h += '<span class="lab">Who do you want to hire?</span><div class="pickrole56">' +
        '<button data-a="go" data-p="' + P({ n: 'mgrhire', p: { id: co.id, r: 'mgr' } }) + '"><b>' + esc(titleFor(co, 'mgr')) + '</b><small>Runs ' + esc(co.name) + ' day to day: hires, prices, stock, IT security, insurance and the premises. You set what they may decide.</small><em>~' + mshort(window.mgrCostHint ? mgrCostHint(co) : 0) + '/mo</em></button>' +
        '<button data-a="go" data-p="' + P({ n: 'mgrhire', p: { id: co.id, r: 'asst' } }) + '"><b>Assistant manager</b><small>Works alongside the team and takes up to two jobs off your plate. You stay in charge.</small><em>cheaper than a manager</em></button>' +
        slots.map(([k]) => '<button data-a="go" data-p="' + P({ n: 'mgrhire', p: { id: co.id, r: k } }) + '"><b>' + esc(TEAM56.title(co, k)) + '</b><small>' + esc(window.MR56 && MR56[k] ? MR56[k].d(co, {}) : '') + '</small><em>through the agency</em></button>').join('') + '</div>';
      return h + (window.HIRE56 ? HIRE56.mgrVerdict(co) : '');
    }
    const pay = L.reduce((t, x) => t + x.w, 0);
    const cy = window.CY56 ? CY56.st(co) : null, ins = Object.keys(co.ins || {}).filter(k => co.ins[k]).length;
    const bo = co.dbg && co.dbg.botObj, small = bo && bo.kind === 'space', up = typeof chainOf === 'function' ? chainOf(co).find(x => x.kind !== 'mgr') : null;
    const T = D ? [
      D.tile('Manager', m ? esc(m.name.split(' ')[0]) : an ? esc(an.name.split(' ')[0]) : 'Vacant', m ? (co.mgrNotice ? 'leaves ' + dateStr(co.mgrNotice.w) : esc(titleLow(titleFor(co, 'mgr')))) : an ? 'acting manager' : 'you run it', tabBtn(co, 'mgr'), m && !co.mgrNotice ? '' : 'warn'),
      D.tile('Decides', m ? ['Asks you', 'Limits', 'Alone'][co.auth.lvl || 0] : 'You', m ? ['every decision', 'up to ' + mshort(co.auth.buy), 'full control'][co.auth.lvl || 0] : 'everything', tabBtn(co, 'mgr')),
      ...(window.TG58 && TG58.tile(co) ? [(x => D.tile('Targets', x.v, x.sub, ['go', { n: 'tg58', p: { id: co.id } }], x.tone))(TG58.tile(co))] : []),
      D.tile('Reports to', up ? esc(up.npc.name.split(' ')[0]) : 'You', up ? esc(titleLow(titleFor(co, up.kind))) : 'the owner', ch0(co) ? ['go', { n: 'org56', p: { id: ch0(co).id } }] : tabBtn(co, 'team')),
      D.tile('IT security', cy ? CY56.LV[cy.lvl || 0][0] : '–', cy && window.MD56 ? MD56.secBy(co) : '', ['go', { n: 'cy56', p: { id: co.id } }], cy && !(cy.lvl || 0) ? 'warn' : ''),
      D.tile('Insurance', ins ? ins + (ins === 1 ? ' policy' : ' policies') : 'None', window.MD56 ? MD56.insBy(co) : '', ['go', { n: 'co', p: { id: co.id, t: 'ops', s: 'ins' } }], ins ? '' : 'warn'),
      D.tile('Premises', co.prem && co.prem.m2 ? co.prem.m2 + ' m²' : '–', small ? 'too small for the customers' : 'room enough', ['go', { n: 'co', p: { id: co.id, t: 'ops', s: 'assets' } }], small ? 'warn' : '')
    ] : [];
    h += D && D.card ? D.card('Headquarters', L.length + (L.length === 1 ? ' person' : ' people'), 'management pay ' + mshort(pay) + ' a month', '', T) : '';
    h += '<h2 class="sec">Who works here</h2><div class="lrows">';
    h += who({ name: (S.player && S.player.name) || 'You' }, 'Owner · ' + (m ? 'sees every number, decides the big things' : 'runs it · ' + (co.ohrs || 0) + ' h a week') + ' · pay yourself', ['go', { n: 'payself', p: { id: co.id } }]);
    /* above the store: the chain's levels and the group's managing director (features/company/org_chart.js) */
    const ch = ch0(co);
    if (typeof chainOf === 'function') chainOf(co).filter(x => ch ? x.kind !== 'mgr' && x.kind !== 'mdir' : x.kind === 'md').reverse().forEach(x => { h += who(x.npc, esc(titleFor(co, x.kind)) + ' · for ' + (x.kind === 'md' ? 'the whole group' : esc(ch.name)), ch ? ['go', { n: 'org56', p: { id: ch.id } }] : ['go', { n: 'hq', p: { t: 'grp' } }]); });
    L.filter(x => x.k !== 'mgr' && x.k !== 'asst').forEach(x => { h += who(x.n, esc(TEAM56.title(co, x.k)) + ' · ' + mshort(x.w) + '/mo', tabBtn(co, 'team')); });
    h += m ? who(m, esc(titleFor(co, 'mgr')) + ' · ' + mshort(co.mgrWage || 0) + '/mo' + (co.mgrBonus > 0 ? ' + ' + Math.round(co.mgrBonus * 100) + '% of profit' : ''), tabBtn(co, 'mgr'), '<span class="badge amber">' + AUTHW[co.auth.lvl || 0] + '</span>')
      : an ? who(an, 'Acting manager · ' + skillBand(an.skill), tabBtn(co, 'mgr')) : vac(titleFor(co, 'mgr'), 'Runs it day to day', hire(co, 'mgr'));
    const a = co.asst && S.npcs[co.asst.npc];
    h += a ? who(a, 'Assistant manager · ' + mshort(co.asst.wage) + '/mo · ' + co.asst.duties.length + ' of 2 jobs', tabBtn(co, 'asst')) : vac('Assistant manager', 'Takes two jobs off ' + (m ? esc(m.name.split(' ')[0]) + '’s' : 'your') + ' plate', hire(co, 'asst'));
    (window.TEAM56 && TEAM56.slots ? TEAM56.slots(co) : []).filter(s => !s[1]).forEach(([k]) => { h += vac(TEAM56.title(co, k), window.MR56 && MR56[k] ? MR56[k].d(co, {}) : '', hire(co, k)); });
    return h + '</div>';
  }

  /* ---------- Manager ---------- */
  function mgrPage(co, bd) {
    const m = co.mgr && S.npcs[co.mgr], ac = window.actingMgr ? actingMgr(co) : null, an = ac && S.npcs[ac.id];
    if (!m) {
      let h = an ? '<div class="lrows"><div class="lrow solo">' + faceAv(an) + '<span class="ctext"><b>' + esc(an.name) + '</b><small>Acting manager · ' + skillBand(an.skill) + ' · the team lead keeps it running</small></span>' + btn('Promote', 'promoteact', { id: co.id }, 'chip primary') + '</div></div>' : '';
      h += '<div class="pickrole56"><button data-a="go" data-p="' + P({ n: 'mgrhire', p: { id: co.id, r: 'mgr' } }) + '"><b>Hire a ' + esc(titleLow(titleFor(co, 'mgr'))) + '</b><small>Runs ' + esc(co.name) + ' day to day and looks after IT security, insurance and the premises. You set what they may decide.</small><em>~' + mshort(window.mgrCostHint ? mgrCostHint(co) : 0) + '/mo · through the agency</em></button></div>';
      return h + (window.HIRE56 ? HIRE56.mgrVerdict(co) : '');
    }
    let h = window.CT && CT.mgrCard ? CT.mgrCard(co, bd) : '';
    if (window.TG58) h += TG58.card(co); /* the month's targets and the year's budget */
    if (window.MD56) h += MD56.card(co);
    h += '<div class="lrows"><button class="lrow" data-a="go" data-p="' + P({ n: 'pr11', p: { id: co.id, m: 1 } }) + '"><span class="lic">' + svg('star', 20) + '</span><span class="ctext"><b>Promote ' + esc(m.name.split(' ')[0]) + '</b><small>To another company or up the chain</small></span><i>›</i></button>' +
      '<button class="lrow" data-a="go" data-p="' + P({ n: 'mgrhire', p: { id: co.id, r: 'mgr' } }) + '"><span class="lic">' + svg('people', 20) + '</span><span class="ctext"><b>Find a successor</b><small>Through the agency' + (co.mgrNotice ? ' · ' + esc(m.name.split(' ')[0]) + ' leaves ' + dateStr(co.mgrNotice.w) : '') + '</small></span><i>›</i></button></div>';
    return h;
  }

  /* ---------- Assistant ---------- */
  const asstPage = co => '<div class="chain">' + (window.asstRow ? asstRow(co) : '') + '</div>';

  /* ---------- Team ---------- */
  function teamPage(co) {
    let h = window.TEAM56 && TEAM56.card ? TEAM56.card(co) : '';
    const ch = ch0(co);
    if (ch) h += '<div class="lrows"><button class="lrow" data-a="go" data-p="' + P({ n: 'org56', p: { id: ch.id } }) + '"><span class="lic">' + svg('people', 20) + '</span><span class="ctext"><b>' + esc(ch.name) + '’s organisation</b><small>CEO, chain manager and regional managers above the stores: hired there</small></span><i>›</i></button></div>';
    return h;
  }

  /* the headquarters of one company */
  H.page = function (co) {
    const bd = BD[co.type], t = tabOf(co), a = co.asst && S.npcs[co.asst.npc], m = co.mgr && S.npcs[co.mgr];
    const T = [['ov', 'Overview'], ['mgr', 'Manager', m ? 1 : 0], ['asst', 'Assistant', a ? 1 : 0], ['team', 'Team', (window.TEAM56 && TEAM56.slots ? TEAM56.slots(co).filter(s => s[1]).length : 0)]];
    const bar = '<div class="seg56 hq56">' + T.map(x => '<button class="' + (x[0] === t ? 'on' : '') + '" data-a="hq56t" data-p="' + P({ id: co.id, v: x[0] }) + '">' + x[1] + '</button>').join('') + '</div>';
    return bar + (t === 'mgr' ? mgrPage(co, bd) : t === 'asst' ? asstPage(co) : t === 'team' ? teamPage(co) : overview(co, bd));
  };

  /* its own screen, from Group › Group and the company dashboard */
  V.titles.mgmt56 = 'Headquarters';
  V.heads = V.heads || {};
  V.heads.mgmt56 = p => { const co = getCo(p.id); return co ? { t: 'Headquarters', sub: esc(co.name) + ' · ' + esc(BD[co.type].n) } : { t: 'Headquarters' }; };
  V.mgmt56 = function (p) {
    const co = getCo(p.id);
    if (!co || co.st === 'sold' || co.st === 'bust') return '<div class="calm">This company is no longer yours.</div>';
    return H.page(co) + btn('Open ' + esc(co.name), 'go', { n: 'co', p: { id: co.id } }, 'ghost wide');
  };
})();

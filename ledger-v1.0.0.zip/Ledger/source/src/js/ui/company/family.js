/* ---- ui/company/family.js ---- */
(function () {
  'use strict';
  const U = window.UI, { ui, V, ACT, esc, nok, tone, sgn, svg, bar, row, btn, card, sec, noteBox, badge, chips, inp, inum, go, setView, openSheet, closeSheet, confirmThen, toast, res, render, save } = U;
  const CT = window.CT;
  CT.famOv = function (co, bd) {
    const fm = co.fm || {}, tw = bd.tw;
    let h = '';
    if (tw.stock && co.st === 'open') h += card('<h3>Stock</h3>' + row('Stock value', nok(co.inv)) + (co.lastW && co.lastW.cogs > 0 ? row('Stock lasts about', (Math.round(co.inv / co.lastW.cogs * 10) / 10) + ' weeks of sales') : '') + row('Policy', ['Lean', 'Normal', 'Safe stock'][co.stockPol]) + '<p class="muted small">Shortages lose sales. Too much stock ties up cash and may spoil.</p>');
    if (tw.sub && fm.memb != null) h += card('<h3>Members</h3>' + row('Active members', Math.round(fm.memb)) + row('Monthly churn (base)', pc(tw.churn, 1)) + '<p class="muted small">Quality and equipment condition keep members. New year brings a rush.</p>');
    if (tw.variance && fm.lastHold != null) h += card('<h3>House result</h3>' + row('Last week vs expectation', '<span class="' + (fm.lastHold >= 1 ? 'pos' : 'neg') + '">×' + fm.lastHold.toFixed(2) + '</span>') + '<p class="muted small">Casino results swing. High limits mean bigger swings and bigger risk of a bad week.</p>');
    if (bd.fam === 'project' && !tw.dev) {
      const jobs = fm.jobs || [];
      h += card('<h3>Order book</h3>' + row('Backlog', nok(fm.backlog || 0)) + row('Weeks of work', (fm.backlogWk || 0).toFixed(1)) + row('Jobs won / finished', (fm.won || 0) + ' / ' + (fm.done || 0)) + jobs.slice(0, 6).map(j => '<div class="kv"><span>' + esc(j.client) + ' · ' + mshort(j.v) + (j.delay > 0 ? ' <small style="color:var(--red)">delayed</small>' : '') + '</span><b>' + Math.round(j.p * 100) + '%</b></div>' + bar(j.p * 100, 'var(--green)')).join('') + (jobs.length > 6 ? '<p class="muted small">+' + (jobs.length - 6) + ' more jobs</p>' : '') + '<p class="muted small">Too big a backlog turns away new work. Delays hurt reputation. Bids are won by price and reputation.</p>');
    }
    if (tw.dev) h += devPanel(co, bd);
    if (bd.fam === 'rent') {
      const ps = co.props || [];
      const val = sum(ps, p => p.val), units = sum(ps, p => p.units);
      h += card('<h3>Portfolio</h3>' + row('Properties', ps.length) + row('Units', units) + row('Total value', nok(val)) + row('Rent per week', nok(co.lastW ? co.lastW.rev : 0)) + (val ? row('Gross yield', pc((co.lastW ? co.lastW.rev : 0) * 52 / val, 1)) : '') + (co.dbg && co.dbg.cover != null ? row('Staff cover', pc(Math.min(1, co.dbg.cover), 0)) : '') + '<p class="muted small">Housing prices rise and fall with the economy and interest rates. Debt magnifies both.</p>');
    }
    if (bd.fam === 'fin') h += finPanel(co, bd);
    if (bd.fam === 'energy') h += energyPanel(co, bd);
    if (bd.id === 'salmon') h += salmonPanel(co, bd);
    return h;
  };
  function salmonPanel(co, bd) {
    const fm = co.fm;
    const coh = fm.coh || [];
    return card('<h3>Fish cycle</h3>' + (coh.length ? coh.map((c, i) => '<div class="kv"><span>Cohort ' + (i + 1) + ' · week ' + c.age + '</span><b>' + Math.round(c.n / 1000) + 'k fish · ' + c.kg.toFixed(1) + ' kg</b></div>' + bar(Math.min(100, c.kg / 5.3 * 100), 'var(--green)')).join('') : '<p class="muted small">No fish in the pens. A new cohort is stocked when you have cash.</p>') + row('Salmon price (kg)', money(fm.price || 0)) + '<p class="muted small">Cohorts take about ' + bd.tw.grow + ' weeks to grow. Disease and lice can wipe out part of a cohort. Prices swing with the market.</p>' + chips([[1, 'Auto-stock new fish'], [0, 'Pause stocking']], co.flags.autoStock === 0 ? 0 : 1, 'autostock', { id: co.id }));
  }
  ACT.autostock = p => {
    getCo(p.id).flags.autoStock = p.v;
    save();
    render();
  };
  function finPanel(co, bd) {
    const fm = co.fm, tw = bd.tw;
    let h = '<h3>' + (tw.ins ? 'Insurance book' : tw.bank ? 'Bank' : 'Fund') + '</h3>';
    if (tw.ins) h += row('Policies', Math.round(fm.pol || 0)) + row('Premium per week', nok(fm.premW || 0)) + row('Loss ratio', pc(fm.lossR || 0, 0)) + row('Solvency', (fm.sol || 0).toFixed(2) + ' (needs 1.0)') + (co.flags.reg ? noteBox('The regulator restricts you. Add capital.', true) : '') + '<p class="muted small">Premium minus claims is your profit. Big storms and floods can hit many policies at once. Your other companies can buy insurance here.</p>';
  else if (tw.bank) h += row('Deposits', nok(fm.dep || 0)) + row('Loans to customers', nok(fm.book || 0)) + row('Loans to your group', nok(fm.gb || 0)) + row('Capital ratio', pc(fm.cr || 0, 1) + ' (min ' + pc(tw.capitalReq, 0) + ')') + (co.flags.reg ? noteBox('The regulator warns about capital. Add equity or shrink.', true) : '') + '<p class="muted small">You earn the gap between loan and deposit rates. Bad loans reduce capital. Your other companies borrow cheaper here.</p>';
  else h += row('Assets under management', nok(fm.aum || 0)) + row('Unit value', (fm.nav || 1).toFixed(3)) + '<p class="muted small">You earn a fee on assets and a performance fee after a good year.</p>';
    return card(h);
  }
  function energyPanel(co, bd) {
    const fm = co.fm, tw = bd.tw;
    let h = '';
    if (tw.power) {
      const mw = co.dbg && co.dbg.mw != null ? co.dbg.mw : 0, inb = co.dbg && co.dbg.inb || 0;
      h = '<h3>Power plant</h3>' + row('Producing', mw + ' MW') + row('Under construction', inb + ' MW') + row('Output last week', Math.round(co.lastW ? co.lastW.units : 0) + ' MWh') + row('Average price', money(co.lastW && co.lastW.units ? co.lastW.rev / co.lastW.units : 0) + ' / MWh') + '<p class="muted small">Build turbines under Assets. Construction takes ' + (['wind', 'hydro', 'solar'][co.knob.src || 0] === 'wind' ? '52' : ['wind', 'hydro', 'solar'][co.knob.src || 0] === 'hydro' ? '78' : '26') + ' weeks. Output follows the weather and season, and prices follow the power market. Hedging fixes some of the price.</p>';
    }
  else h = '<h3>Oil and gas</h3>' + row('Fields', (fm.fields || []).length) + row('Production last week', Math.round((co.lastW ? co.lastW.units : 0)) + ' kbbl') + row('Oil price', money(780 * S.econ.oil) + ' / bbl') + '<p class="muted small">Explore for new fields or buy stakes in producing ones. Fields decline each year. Taxes on oil are very high (78%). This business is fictional but shaped on the real sector.</p>';
    return card(h);
  }
  CT.famOps = function (co, bd) {
    if (!(bd.fam === 'fin' && bd.tw.ins)) return '';
    let h = '<div class="card"><h3>Insurance products<small>Choose what you sell. Each needs approval, and each salesperson must be verified per product.</small></h3>';
    Object.keys(INS_PRODS).forEach(k => {
      const P = INS_PRODS[k], on = prodOn(co, k), d = co.docs[P[1].doc], st = on ? (d && d.st === 'ok' ? '<span class="pos">Live</span>' : d && d.st === 'applied' ? 'Approval in ' + Math.max(0, d.done - S.week) + ' wk' : 'Needs approval') : 'Not offered';
      const nv = on ? verAgents(co, k) : 0;
      h += '<div class="opt ' + (on ? 'on' : '') + '"><div class="bhead"><div><b>' + esc(P[0]) + '</b><small>' + st + (on ? ' · verified sellers: ' + Math.round(nv * 10) / 10 : '') + '</small><small>Approval ' + money(docDef(P[1].doc)[2]) + '</small></div><div class="rt">' + btn(on ? 'Stop selling' : 'Offer', 'prodtog', { id: co.id, k: k }, 'chip' + (on ? '' : ' primary')) + '</div></div></div>';
    });
    return h + '</div>';
  };
  ACT.prodtog = p => {
    const co = getCo(p.id);
    const r = setProd(co, p.k, !prodOn(co, p.k));
    if (res(r, prodOn(co, p.k) ? 'Applied for approval.' : 'Stopped.')) {
      save();
      render();
    }
  };
  CT.famAssets = function (co, bd) {
    const tw = bd.tw, fm = co.fm;
    let h = '';
    if (bd.fam === 'rent') h += propPanel(co, bd);
    if (tw.oil) h += oilPanel(co, bd);
    if (tw.dev) h += devAssets(co, bd);
    return h;
  };
/* property */
  function propPanel(co, bd) {
    const ps = co.props || [];
    let h = '<div class="card"><h3>Properties</h3>' + (ps.length ? ps.map(p => '<div class="opt"><div class="bhead"><div><b>' + esc(p.name) + '</b><small>' + p.units + ' ' + (p.kind === 'com' ? 'm2' : 'units') + (p.lu ? ' (' + p.lu + ' let long-term)' : '') + ' · rent ' + money(p.rentU) + '/wk each · vacancy ' + pc(p.vac, 0) + ' · ' + condWord(p.cond).toLowerCase() + '</small><small>Value ' + money(p.val) + ' · bought for ' + money(p.cost) + '</small></div><div class="rt">' + btn('Renovate', 'renprop', { id: co.id, p: p.id }, 'chip') + (p.kind === 'com' ? btn('Tenants and buyers', 'marketprop', { id: co.id, p: p.id }, 'chip') : '') + btn('Sell', 'sellprop', { id: co.id, p: p.id }, 'chip ghost danger') + '</div></div></div>').join('') : '<p class="muted small">No property yet.</p>') + btn('＋ Buy property', 'propsheet', { id: co.id }, 'primary wide') + '</div>';
    return h;
  }
  ACT.propsheet = p => {
    const co = getCo(p.id);
    const ls = propListings(co);
    ui.ltv = ui.ltv == null ? 0.5 : ui.ltv;
    openSheet('<h2>Properties for sale</h2><p class="muted small">Listings in ' + esc(cityOf(co.city).name) + ' change every month. Pick your financing.</p>' + chips([[0, 'No loan'], [0.4, '40% loan'], [0.6, '60% loan']], ui.ltv, 'setltv', { id: co.id }) + ls.map(L => '<div class="opt"><b>' + esc(L.name) + '</b><small>' + money(L.price) + ' · rent ' + money(L.rentU) + '/wk per unit · gross yield ' + pc(L.yieldG, 1) + ' · ' + condWord(L.cond).toLowerCase() + '</small>' + btn('Buy', 'buyprop', { id: co.id, i: L.i }, 'chip primary') + '</div>').join('') + btn('Close', 'sheetclose', undefined, 'ghost wide'));
  };
  ACT.marketprop = p => {
    const co = getCo(p.id);
    const pr = co.props.find(x => x.id === p.p);
    const ts = propTenants(co, pr);
    openSheet('<h2>Tenants and buyers</h2><p class="muted small">' + esc(pr.name) + ' · ' + (pr.units - (pr.lu || 0)) + ' m2 free. Offers change every month.</p>' + (pr.leases && pr.leases.length ? '<h3>Current tenants</h3>' + pr.leases.map(l => row(l.co ? esc(getCo(l.co).name) : esc(l.name), l.m2 + ' m2')).join('') : '') + (ts.length ? '<h3 class="gap">Wants to lease</h3>' + ts.map(o => '<div class="opt"><b>' + esc(o.name) + '</b><small>' + o.m2 + ' m2 · ' + money(o.m2 * o.rw) + ' /wk · ' + o.yrs + ' year lease</small>' + btn('Lease to them', 'leaseprop', { id: co.id, p: pr.id, i: o.i }, 'chip primary') + '</div>').join('') + '<h3 class="gap">Wants to buy the building</h3>' + ts.slice(0, 2).map(o => '<div class="opt"><b>' + esc(o.name) + '</b><small>Offers ' + money(pr.val * o.buyPct) + ' (' + pc(o.buyPct - 1, 0) + ' over market value)</small>' + btn('Sell to them', 'sellto', { id: co.id, p: pr.id, i: o.i }, 'chip ghost danger') + '</div>').join('') : '<p class="muted small">No space free to let, or no interest right now.</p>') + btn('Close', 'sheetclose', undefined, 'ghost wide'));
  };
  ACT.leaseprop = p => {
    const co = getCo(p.id);
    const pr = co.props.find(x => x.id === p.p);
    const o = propTenants(co, pr)[p.i];
    if (res(leaseTo(co, pr.id, o), 'Leased.')) {
      closeSheet();
      save();
      render();
    }
  };
  ACT.sellto = p => {
    const co = getCo(p.id);
    const pr = co.props.find(x => x.id === p.p);
    const o = propTenants(co, pr)[p.i];
    confirmThen('Sell ' + esc(pr.name) + '?', 'You receive ' + money(pr.val * o.buyPct) + ' minus any loan.', 'Sell', () => {
      const r = sellPropTo(co, pr.id, o);
      if (r === 'leased') {
        toast('A company of yours leases it. End that first.', true);
        return;
      }
      closeSheet();
      save();
      render();
      toast('Sold.');
    });
  };
  ACT.setltv = p => {
    ui.ltv = p.v;
    ACT.propsheet({ id: p.id });
  };
  ACT.buyprop = p => {
    const co = getCo(p.id);
    const L = propListings(co)[p.i];
    confirmThen('Buy ' + esc(L.name) + '?', 'Price ' + money(L.price) + ' plus 2.5% costs. Loan ' + Math.round((ui.ltv || 0) * 100) + '%. Rates are ' + pc(policy(), 1) + ' plus a margin, so cheap rent returns can be lower than loan costs.', 'Buy', () => {
      closeSheet();
      if (res(buyProp(co, L, ui.ltv || 0), 'Property bought.')) {
        save();
        render();
      }
    });
  };
  ACT.sellprop = p => {
    const co = getCo(p.id);
    confirmThen('Sell this property?', 'You receive about 97.5% of market value minus any loan.', 'Sell', () => {
      sellProp(co, p.p);
      save();
      render();
    });
  };
  ACT.renprop = p => {
    const co = getCo(p.id);
    if (res(renovateProp(co, p.p), 'Renovated.')) {
      save();
      render();
    }
  };
/* oil */
  function oilPanel(co, bd) {
    const fm = co.fm, fields = fm.fields || [];
    return '<div class="card"><h3>Fields</h3>' + (fields.length ? fields.map(f => '<div class="opt"><b>' + esc(f.name) + '</b><small>' + ({ dev: 'In development · ' + f.wl + ' weeks to production', prod: 'Producing', depleted: 'Depleted' }[f.st]) + ' · ' + Math.round(f.res / 1000 * 10) / 10 + ' M bbl left</small></div>').join('') : '<p class="muted small">No fields yet.</p>') + '<p class="muted small">How you earn: buy a stake in a producing field for income right away, or drill. A successful well takes about three years to come into production, so expect no income from drilling until then.</p>' + '<div class="btnrow col">' + btn('Drill an exploration well · ' + mshort(300e6 * Math.pow(1 + S.econ.infl, S.week / 52)), 'oilexp', { id: co.id }) + btn('Buy a stake in a producing field', 'oilacq', { id: co.id }) + '</div><p class="muted small">Exploration is a gamble (14–28% hit rate by risk level). Developing a field takes about 3 years and a lot of capital.</p></div>';
  }
  ACT.oilexp = p => {
    const co = getCo(p.id);
    confirmThen('Drill an exploration well?', 'Costs about ' + money(300e6 * Math.pow(1 + S.econ.infl, S.week / 52)) + '. Most wells find nothing.', 'Drill', () => {
      const r = oilExplore(co);
      if (r === 'cash') toast('Not enough cash.', true); else {
        save();
        render();
        toast(r === 'hit' ? 'Discovery!' : 'Dry well.', r !== 'hit');
      }
    }, true);
  };
  ACT.oilacq = p => {
    const co = getCo(p.id);
    openSheet('<h2>Buy a stake</h2><p class="muted small">Producing fields give cash right away but decline every year.</p>' + [2000, 5000, 10000].map(k => btn(Math.round(k / 1000) + ' M bbl remaining · ' + mshort(Math.round(k * 1000 * 190 * Math.sqrt(S.econ.oil))), 'oilbuy', { id: co.id, k: k })).join('') + btn('Cancel', 'sheetclose', undefined, 'ghost wide'));
  };
  ACT.oilbuy = p => {
    const co = getCo(p.id);
    closeSheet();
    const r = oilAcquire(co, p.k);
    if (res(r, 'Stake acquired.')) {
      save();
      render();
    }
  };
/* development */
  function devPanel(co, bd) {
    const proj = (co.fm.proj || []);
    return card('<h3>Projects</h3>' + (proj.length ? proj.map(p => '<div class="kv"><span>' + esc(p.name) + '<br><small>' + ({ zoning: 'Zoning: ' + p.wl + ' wk', build: 'Building: ' + p.wl + ' wk left', sell: 'Selling', done: 'Done' }[p.st]) + '</small></span><b>' + p.sold + ' / ' + p.units + ' sold</b></div>').join('') : '<p class="muted small">No projects yet. Start one under Assets.</p>') + '<p class="muted small">How you earn: <b>1.</b> buy land and wait for zoning (about 6 months, it can be refused) · <b>2.</b> build (about ' + Math.round(bd.tw.wks / 4.33) + ' months) · <b>3.</b> sell the units. Your first income arrives roughly ' + Math.round((22 + bd.tw.wks * 0.7) / 4.33 / 12 * 10) / 10 + ' years after you start a project, so keep cash for the wait.</p>');
  }
  function devAssets(co, bd) {
    const proj = (co.fm.proj || []);
    return '<div class="card"><h3>Development projects</h3>' + proj.map(p => '<div class="opt"><b>' + esc(p.name) + '</b><small>Land ' + mshort(p.land) + ' · build ' + mshort(p.build) + ' · price per unit ' + mshort(p.price * p.priceMult) + '</small>' + (p.st !== 'done' ? chips([[0.9, 'Price −10%'], [1, 'Standard'], [1.1, 'Price +10%']], p.priceMult, 'devprice', { id: co.id, p: p.id }) : '') + '</div>').join('') + btn('＋ Start a project', 'devsheet', { id: co.id }, 'primary wide') + '<p class="muted small">Zoning can be rejected or delayed. Building costs overrun. Sales depend on the housing market.</p></div>';
  }
  ACT.devprice = p => {
    const co = getCo(p.id);
    co.fm.proj.find(x => x.id === p.p).priceMult = p.v;
    save();
    render();
  };
  ACT.devsheet = p => {
    const co = getCo(p.id), tw = BD[co.type].tw;
    const city = cityOf(co.city);
    openSheet('<h2>New project</h2><p class="muted small">Buying land, zoning and then building. Pay for it with cash or a construction loan (the bank decides).</p>' + [0.5, 1, 2].map(sz => {
      const land = tw.land * sz * city.rent * S.econ.housing;
      const bld = tw.build * sz * city.price * S.econ.mat;
      return '<div class="opt"><b>' + Math.max(4, Math.round(tw.units * sz)) + ' units</b><small>Land ' + mshort(land) + ' · build ' + mshort(bld) + '</small><div class="btnrow">' + btn('Pay with cash', 'devgo', { id: co.id, s: sz, d: 0 }, 'chip') + btn('Construction loan', 'devgo', { id: co.id, s: sz, d: 1 }, 'chip') + '</div></div>';
    }).join('') + btn('Cancel', 'sheetclose', undefined, 'ghost wide'));
  };
  ACT.devgo = p => {
    const co = getCo(p.id);
    closeSheet();
    const r = FAM.dev.start(co, BD[co.type], { size: p.s, debt: !!p.d });
    if (res(r, 'Project started.')) {
      save();
      render();
    }
  };
})();


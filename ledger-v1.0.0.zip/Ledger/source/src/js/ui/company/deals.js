/* ---- ui/company/deals.js ---- */
(function () {
  'use strict';
  const U = window.UI, { ui, V, ACT, esc, nok, tone, sgn, svg, bar, row, btn, card, sec, noteBox, badge, contact, seg, chips, inp, inum, quick, stepper, tabsRow, go, setView, openSheet, closeSheet, confirmThen, toast, res, render, save } = U;
  const CT = window.CT;
  const DEAL_SUB = {
    value: ['Ownership and value', 'coin'],
    supply: ['Suppliers', 'truck'],
    cust: ['Business customers', 'tie'],
    sell: ['Sell', 'deal'],
    reach: ['Chain and reach', 'globe'],
    rivals: ['Competitors', 'fire'],
    grow: ['Expand', 'rocket'],
    close: ['Close down', 'check'],
    insight: ['Insight and analytics', 'chart']
  };
  function dealPart(co, bd, k) {
    if (window.R7DEAL && window.R7DEAL[k]) { const r7 = window.R7DEAL[k](co, bd); if (r7 != null) return r7; }
    let h = '';
    const V0 = companyValue(co);
    if (k === 'value') {
      h += card('<h3>Value</h3>' + row('Estimated value', nok(V0)) + row('Your share', co.own.toFixed(co.own % 1 ? 1 : 0) + '%') + row('Worth to you', nok(V0 * co.own / 100)) + (co.holders.length ? co.holders.map(x => row('Investor ' + esc(x.name), x.pct.toFixed(1) + '%')).join('') : '') + (co.flags.boardSeat ? '<p class="muted small">Outside shareholders have a board seat.</p>' : ''));
      if (co.franchise && co.franchise.fran) h += card('<h3>You are a franchisee</h3>' + row('Royalty', pc(co.franchise.roy, 0) + ' of revenue') + row('Marketing fund', pc(co.franchise.mkt, 0)) + row('Brand', brandWord(co.franchise.brand)) + (window.R24 && R24.fbCard ? R24.fbCard(co) : '') + '<p class="muted small">Poor quality can get you a warning from the franchisor.</p>');
    } else if (k === 'supply') {
      h += CT.supply(co, bd);
      /* your own companies supplying each other (features/company/intercompany_supply.js) */
      if (V.chain27) { const sc = V.chain27({ id: co.id }); if (sc && sc.indexOf('class="calm"') < 0) h += '<h2 class="sec">Supply chain</h2>' + sc; }
    }
  else if (k === 'cust') {
      /* companies that buy from you regularly (engine/company/key_accounts.js, terms in features/company/small_team_and_rewards.js),
         and the contracts and bookings your trade's ways of selling bring (features/sales/trade_sales_mechanics.js) */
      const ac = (co.accts || []).map(a => window.R39 && R39.acc ? R39.acc(a) : a);
      const sw = co.sw33 || {}, ct = sw.ct || [], one = (sw.one || []).filter(o => o.w >= S.week);
      const perW = u => window.rateW ? rateW(u, bd.unit) : Math.round(u) + ' a week';
      const ini = t => esc(String(t).split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase());
      const pl = (t, c) => '<span class="pill ' + (c || '') + '">' + t + '</span>';
      h += '<p class="muted small">Companies that buy from you regularly. They pay your price at first and ask for better terms as you get to know each other. Bigger companies come to you once your name is known.</p>';
      h += '<h2 class="sec">Regular customers</h2>' + (ac.length ? '<div class="lrows">' + ac.map(a => '<button class="lrow" data-a="acc39" data-p="' + esc(JSON.stringify({ id: co.id, a: a.id })) + '"><span class="av">' + ini(a.name) + '</span><span class="ctext"><b>' + esc(a.name) + '</b><small>' + esc(BD[a.t] ? BD[a.t].n : 'Business') + ' · ' + esc(relWord(a.rel)) + (a.lastU ? ' · ' + esc(perW(a.lastU)) : '') + '</small></span>' + pl(a.disc ? '−' + a.disc + '%' : 'Full price', a.disc ? 'amb' : '') + '</button>').join('') + '</div>' : card('<p class="muted small">None yet. ' + (acctOk(co) ? 'A bigger company asks to buy in bulk once your name is known; you decide in the inbox.' : 'This kind of business sells to companies through its contracts.') + '</p>'));
      if (window.TND56 && TND56.eligible(co)) h += '<div class="lrows"><button class="lrow" data-a="go" data-p="' + esc(JSON.stringify({ n: 'tnd56', p: { id: co.id } })) + '"><span class="lic">' + svg('house', 20) + '</span><span class="ctext"><b>Tenders</b><small>' + esc(TND56.summary(co)) + '</small></span><i>›</i></button></div>';
      if (ct.length || one.length) h += '<h2 class="sec">Contracts and bookings</h2><div class="lrows">' + ct.map((c, ci) => '<button class="lrow" data-a="ct56" data-p="' + esc(JSON.stringify({ id: co.id, i: ci })) + '"><span class="av">' + ini(c.who) + '</span><span class="ctext"><b>' + esc(c.who) + '</b><small>' + (c.tnd ? (c.pub ? 'Public contract · ' : 'Tender won · ') : '') + esc(c.n) + ' · ' + esc(perW(c.u)) + ' · until ' + dateStr(c.end) + '</small></span>' + pl(c.d > 0 ? '−' + Math.round(c.d * 100) + '%' : c.d < 0 ? '+' + Math.round(-c.d * 100) + '%' : 'Full price', c.d > 0 ? 'amb' : '') + '</button>').join('') + one.map(o => '<div class="lrow"><span class="av">' + ini(o.who) + '</span><span class="ctext"><b>' + esc(o.who) + '</b><small>One order · ' + Math.round(o.u) + ' ' + esc(unitPl(bd.unit, o.u)) + ' · week of ' + dateStr(o.w) + '</small></span></div>').join('') + '</div>';
    }
  else if (k === 'sell') {
      h += '<div class="card"><h3>Sell the whole company</h3>' + saleOffers(co).map(o => '<div class="opt"><div class="bhead"><div><b>' + esc(o.buyer) + '</b><small>' + esc(o.note) + '</small></div><div class="rt"><b>' + money(o.price * co.own / 100) + '</b>' + (o.later ? '<small>+ ' + money(o.later * co.own / 100) + ' later</small>' : '') + btn('Accept', 'sellco', { id: co.id, o: o.id }, 'chip') + '</div></div></div>').join('') + '<p class="muted small">Offers change every month. Gains are taxed at ' + pc(CC().divTax, 2) + '.</p></div>';
      if (co.form === 'AS') h += '<div class="card"><h3>Shares: company / you</h3><p class="muted small">Sell part of the company and keep running it. 20% or more gives the investor a board seat. "New shares" brings money into the company, "Sell yours" pays you personally.</p>' + shareOffers(co).map(o => '<div class="opt"><b>' + o.pct + '%</b><div class="btnrow">' + btn('Company ' + mshort(o.primary), 'sellsh', { id: co.id, p: o.pct, m: 'primary' }, 'chip') + btn('You ' + mshort(o.secondary * co.own / 100), 'sellsh', { id: co.id, p: o.pct, m: 'secondary' }, 'chip') + '</div></div>').join('') + '</div>';
    } else if (k === 'reach') {
      if (bd.fam !== 'club') {
        if (co.type === 'cardealer' && vehPlant(co)) h += card('<h3>Supplied by your own plant</h3><p class="muted small">' + esc(vehPlant(co).name) + ' supplies this dealership: about 6% cheaper stock, and your plant earns 4% of the sales. The brand name carries over.</p>');
        const rc = reachOf(co);
        h += card('<h3>Brand reach: ' + rc.label + '</h3>' + row('Outlets under your name', rc.n) + row('Countries', rc.k) + '<p class="muted small">' + (rc.n < 3 ? 'One site stays a local name.' : 'More outlets make the name known, which lifts demand and lowers buying costs.') + (rc.next ? ' Next level at ' + rc.next + ' outlets.' : '') + '</p>');
      }
    }
  else if (k === 'insight') h += CT.ana(co, bd);
  else if (k === 'rivals') {
      if (bd.fam !== 'club') h += CT.rivalsCard(co, bd);
    }
  else if (k === 'grow') {
      if (bd.fam !== 'club') {
        h += dealPart(co, bd, 'reach'); /* how far the name reaches, then the ways to reach further */
        if (CT.chainGrow) h += CT.chainGrow(co, bd); /* register as a chain: more stores under one name */
        /* franchising is a step for a registered chain: stores you own 100% are chain stores, franchise units belong to
           the franchisees (round 56) */
        const ch59 = window.R12 && R12.chainOf ? R12.chainOf(co) : null;
        if (canFranchise(co.type) && ch59 && !(co.fr && co.fr.on)) h += '<div class="card"><div class="bhead"><b>Franchise your concept</b></div><span class="tipt">New stores and franchising are run from the chain page, for every store at once.</span>' + btn('Open ' + esc(ch59.name) + ' ›', 'go', { n: 'chain12', p: { id: ch59.id, t: 'fr' } }, 'wide') + '</div>';
        else if (canFranchise(co.type)) h += co.fr && co.fr.on ? CT.franchisor(co, bd) : '<div class="card"><div class="bhead"><b>Franchise your concept</b><span class="pill">After a chain</span></div><span class="tipt">Once your stores are a registered chain, others can open units under its name for a fee and royalties. Stores you own yourself are chain stores, not franchises.</span></div>';
        h += CT.abroad(co, bd);
        if (window.RD56 && RD56.card) h += RD56.card(co); /* develop something new (features/company/product_development.js) */
      }
    } else if (k === 'close') {
      h += card('<h3>Close down</h3><p class="muted small">Sells off assets at a discount, pays debts and gives you what is left. Sole proprietors cover any shortfall personally.</p>' + btn('Close ' + esc(co.name), 'winduo', { id: co.id }, 'ghost danger wide'));
    }
    return h;
  }
  /* one line for the Business customers row: regular customers, contracts, what they buy a week */
  function custSummary(co) {
    const bd = BD[co.type], n = (co.accts || []).length, sw = co.sw33 || {}, c = (sw.ct || []).length + (sw.one || []).filter(o => o.w >= S.week).length;
    const u = (co.accts || []).reduce((t, a) => t + (a.lastU || 0), 0) + (sw.ct || []).reduce((t, x) => t + (x.u || 0), 0);
    if (!n && !c) return 'None yet · bigger companies come to you once your name is known';
    return [n ? n + (n > 1 ? ' regular customers' : ' regular customer') : '', c ? c + (c > 1 ? ' contracts' : ' contract') : '', u ? 'about ' + (window.rateW ? rateW(u, bd.unit) : Math.round(u) + ' a week') : ''].filter(x => x).join(' · ');
  }
  window.custSummary = custSummary;
  function dealSummary(co, bd, k) {
    if (k === 'value') return mshort(companyValue(co)) + ' · you own ' + co.own.toFixed(co.own % 1 ? 1 : 0) + '%';
    if (k === 'supply') {
      const g = goodsEff(co);
      return g.v ? g.v.name : 'Market prices';
    }
    if (k === 'cust') return custSummary(co);
    if (k === 'sell') return 'Offers for the company or shares';
    if (k === 'reach') return reachOf(co).label;
    if (k === 'rivals') return 'Who competes with you';
    if (k === 'insight') return analystAcc() ? 'Analyst briefing and forecast' : 'Traffic and basics';
    if (k === 'grow') {
      /* the chain comes first: it is how most companies grow (features/company/chain_registration_and_boards.js) */
      const ch = window.R12 && R12.chainOf ? R12.chainOf(co) : null, d = co.docs && co.docs.chain;
      const chain = ch ? 'Part of ' + ch.name : d && d.st === 'applied' ? 'Chain registration under way' : d && d.st === 'ok' ? 'Chain approved: name it' : 'Register a chain';
      return chain + (canFranchise(co.type) ? ', franchise' : '') + ', expand abroad';
    }
    return 'Wind the company down';
  }
  /* a contract customer's profile (round 56): who they are, what they take, what it is worth and how it is going */
  ACT.ct56 = p => {
    const co = getCo(p.id), c = co && co.sw33 && (co.sw33.ct || [])[p.i];
    if (!c) return;
    const bd = BD[co.type], tk = ticketEff(co, bd), price = tk * (1 - (c.d || 0)), left = Math.max(0, c.end - S.week);
    const perW = u => window.rateW ? rateW(u, bd.unit) : Math.round(u) + ' a week';
    let h = '<h2>' + esc(c.who) + '</h2><p class="muted small">' + (c.pub ? 'Public buyer' : 'Company') + ' · ' + esc(c.n) + (c.tnd ? ' · won in a tender' : '') + '</p>';
    h += '<div class="tri"><div><span>Takes</span><b>' + esc(perW(c.u)) + '</b></div><div><span>Price</span><b>' + mshort(price) + '</b></div><div><span>Worth a year</span><b>' + mshort(price * c.u * 52) + '</b></div></div>';
    h += row('Their price', c.d > 0 ? Math.round(c.d * 100) + '% below your list price' : c.d < 0 ? Math.round(-c.d * 100) + '% above your list price' : 'Your list price');
    h += row('Runs until', dateStr(c.end) + ' · ' + (left >= 8 ? Math.round(left / 4.33) + ' months left' : left + ' weeks left'));
    if (c.ext) h += row('Extended', c.ext + (c.ext > 1 ? ' times' : ' time'));
    if (c.q) h += row('Quality you promised', 'Higher than standard');
    h += row('How it is going', c.warn ? '<span class="neg">' + c.warn + (c.warn > 1 ? ' warnings' : ' warning') + ' for late or short deliveries</span>' : '<span class="pos">No complaints</span>');
    h += '<span class="tipt">' + (c.tnd ? 'At the end the buyer puts the work out to tender again; delivering well makes you the favourite.' : 'At the end they decide whether to renew. Delivering on time and in full keeps them.') + '</span>';
    h += btn('Close', 'sheetclose', undefined, 'ghost wide');
    openSheet(h, 'acc39s');
  };
  window.dealPart = dealPart;
  window.dealSummary = dealSummary;
  /* the deal pages a company has, in the order its trade needs them */
  CT.dealKeys = function (co, bd) {
    const ORD = {
      svc: ['cust', 'rivals', 'grow', 'reach'],
      venue: ['rivals', 'supply', 'grow', 'reach'],
      retail: ['supply', 'cust', 'rivals', 'grow', 'reach'],
      prod: ['supply', 'cust', 'grow', 'reach', 'rivals']
    };
    return bd.fam === 'club' ? ['rivals'] : (ORD[bd.fam] || ['supply', 'grow', 'rivals', 'reach']).filter(k => (k !== 'cust' || acctOk(co)) && (k !== 'supply' || goodsEff(co).v !== undefined && hasGoods(co)));
  };
  CT.DEAL_SUB = DEAL_SUB;
  CT.dealPart = dealPart;
  ACT.acctmeet = p => {
    const r = acctMeet(getCo(p.id), p.a);
    if (r === 'wait') toast('You met recently.', true); else if (r === 'cash') toast('Not enough cash.', true); else if (r === 'ok') {
      toast('A good dinner.');
      save();
      render();
    }
  };
  ACT.acctdrop = p => confirmThen('End this contract?', 'They will find another supplier.', 'End it', () => {
    acctDrop(getCo(p.id), p.a);
    save();
    render();
  });
  ACT.codeal = p => {
    ui.view = { n: 'co', p: { id: p.id, t: 'deal', s: p.s || '' } };
    render(true);
  };
  ACT.sellco = p => {
    const co = getCo(p.id);
    const o = saleOffers(co).find(x => x.id === p.o);
    confirmThen('Sell ' + esc(co.name) + '?', 'You receive ' + money(o.price * co.own / 100) + ' from ' + esc(o.buyer) + (o.later ? ' and ' + money(o.later * co.own / 100) + ' later if profits hold' : '') + '. This cannot be undone.', 'Sell', () => {
      const r = acceptSale(co, o);
      if (r === 'ok') {
        save();
        ui.stack = [];
        ui.view = { n: 'cos', p: {} };
        ui.tab = 'cos';
        render(true);
        toast('Sold!');
      } else res(r);
    }, true);
  };
  ACT.sellsh = p => {
    const co = getCo(p.id);
    confirmThen('Sell ' + p.p + '% of ' + esc(co.name) + '?', p.m === 'primary' ? 'New shares are issued and the money goes into the company. Your share falls to ' + (co.own * (1 - p.p / 100)).toFixed(1) + '%.' : 'You sell part of your own shares and receive the cash personally.', 'Sell', () => {
      const r = sellShares(co, p.p, p.m);
      if (typeof r === 'number') {
        save();
        render();
        toast('Sold for ' + money(r));
      } else res(r === 'toomuch' ? 'You must keep at least 1%.' : r);
    });
  };
  ACT.tohold = p => {
    const co = getCo(p.id);
    if (moveToHolding(co, p.h)) {
      save();
      render();
      toast('Moved under holding.');
    }
  };
  ACT.winduo = p => {
    const co = getCo(p.id);
    confirmThen('Close ' + esc(co.name) + '?', 'Everything is sold at a discount and workers are released. This cannot be undone.', 'Close it', () => {
      windUp(co);
      save();
      ui.stack = [];
      ui.tab = 'cos';
      ui.view = { n: 'cos', p: {} };
      render(true);
      toast('Company closed.');
    }, true);
  };

/* franchisor panel */
  CT.franchisor = function (co, bd) {
    const f = co.fr;
    let h = '<div class="card"><h3>Franchise your concept</h3>';
    /* V.1.0.0: first the chain proves itself (engine/world/deals.js frReq) */
    if ((!f || !f.on) && frReq(co).some(x => !x.ok)) { const L = frReq(co); return h + '<span class="tipt">Others open units under your name for a fee and royalties, once the chain has proven itself. ' + L.filter(x => x.ok).length + ' of ' + L.length + ' ready.</span>' + R12.reqRows(L) + '</div>'; }
    if (!f || !f.on) {
      const ok = docOk(co, 'fran');
      h += '<p class="muted small">Let others open units under your name. They pay a fee and royalties. You can cover their setup in part or fully (and share profit then).</p>' + (ok ? '' : noteBox('You need the franchise documents first (' + money(DOCS.fran[2]) + ', ' + DOCS.fran[3] + ' weeks).')) +
      (ok ? '<div class="kv"><span>Entry fee</span><b>' + money(inum('frfee', 150000)) + '</b></div>' + chips([50000, 150000, 300000].map(niceAmt).map(v => [v, mshort(v)]), inum('frfee', 150000), 'frset', { k: 'frfee' }) + '<div class="kv"><span>Royalty of revenue</span><b>' + pc(inum('frroy', 0.06), 0) + '</b></div>' + chips([0.04, 0.06, 0.08, 0.1].map(v => [v, pc(v, 0)]), inum('frroy', 0.06), 'frset', { k: 'frroy' }) + '<div class="kv"><span>Who pays setup</span><b></b></div>' + chips([[0, 'Franchisee pays'], [1, 'Half covered']], Math.min(1, inum('frsup', 0)), 'frset', { k: 'frsup' }) + btn('Launch franchise', 'frlaunch', { id: co.id }, 'primary wide') : btn('Apply for franchise documents', 'applydoc', { id: co.id, d: 'fran' }, 'wide'));
    } else {
      h += row('Brand', brandWord(f.brand)) + row('Units open', f.units.length) + row('Income last week', nok(f.income || 0)) + row('Fee / royalty', money(f.fee) + ' / ' + pc(f.roy, 0)) + ['Franchisee pays setup', 'Half covered by you', 'Fully covered by you (profit share)'].filter((x, i) => i === f.supp).map(x => row('Support', x)).join('');
      f.units.forEach(u => {
        h += '<div class="kv"><span>' + esc(u.name) + ' · ' + esc(cityOf(u.city).name) + (window.R24 && R24.frUnitRow ? R24.frUnitRow(u) : '') + '</span><b class="' + sgn(u.prof) + '">' + mshort(u.rev || 0) + ' /wk</b>' + btn('End', 'fr24term', { id: co.id, u: u.id }, 'chip ghost danger') + '</div>';
      });
      if (f.app.length) {
        h += '<h3 class="gap">Applicants</h3>';
        f.app.forEach(a => {
          h += '<div class="opt"><div class="bhead"><div><b>' + esc(a.name) + '</b><small>' + esc(cityOf(a.city).name) + ' · ' + (a.exp != null ? a.exp + ' yr experience · ' : '') + skillBand(a.skill) + ' · own money ' + mshort(a.capital) + '</small></div>' + btn('Talk', 'go', { n: 'frtalk56', p: { id: co.id, a: a.id } }, 'chip primary') + '</div></div>';
        });
      }
    else h += '<p class="muted small">No applicants right now. Brand strength attracts more.</p>';
    }
    return h + '</div>';
  };
  const vlabel = (v, sc) => v.name + ' ★' + vendRating(v).toFixed(1) + ' · ' + relWord(vrel(v.id)) + (vdisc(sc, v.id) ? ' · ' + Math.round(vdisc(sc, v.id) * 100) + '% off' : '');
  CT.supply = function (co, bd) {
    if (!bd || co.st === 'closed' || bd.fam === 'club') return '';
    const ge = goodsEff(co), hasG = bd.cogs >= 0.03 && ['fin', 'energy', 'rent'].indexOf(bd.fam) < 0;
    const n = brandN(co);
    let h = '<div class="card"><h3>Suppliers</h3>';
    if (hasG) {
      const gl = vendorsFor('goods:' + co.type, n, co.country);
      const cur = co.src && co.src.v ? co.src.v : 'auto';
      h += '<div class="kv"><span>Goods and imports from</span><b>' + (ge.v ? esc(ge.v.name) : 'Market') + '</b></div>' + chips([['auto', co.mgr ? 'Manager decides' : 'Market'].concat([])].concat(gl.map(v => [v.id, vlabel(v, 'goods')])), cur, 'srcv', { id: co.id });
      h += '<div class="kv"><span>Quality class</span><b></b></div>' + chips([[0, 'Basic'], [1, 'Standard'], [2, 'Premium']], co.src && co.src.c != null ? co.src.c : 1, 'srcc', { id: co.id });
      h += '<p class="muted small">' + (S.agree && S.agree.goods && cur === 'auto' ? 'The board has agreed to buy through ' + esc(vendById(S.agree.goods).name) + '. ' : '') + (ge.v ? 'Your goods cost about ' + (ge.m < 0.995 ? Math.round((1 - ge.m) * 100) + '% less' : ge.m > 1.005 ? Math.round((ge.m - 1) * 100) + '% more' : 'the market price') + ' with ' + esc(ge.v.owner) + ' (' + relWord(vrel(ge.v.id)).toLowerCase() + ').' : 'You pay the market price.') + (cur === 'auto' && co.mgr && buyerSkill(co) < 0.55 ? ' Your manager is not always good at finding the best deal.' : '') + '</p>';
    }
    const fl = vendorsFor('fix:' + co.type, n, co.country), fc = co.fixv || 'auto';
    h += '<div class="kv"><span>Repairs and service by</span><b>' + (fixPick(co) ? esc(fixPick(co).name) : 'Whoever is free') + '</b></div>' + chips([['auto', 'Whoever is free']].concat(fl.map(v => [v.id, vlabel(v, 'fix')])), fc, 'fixv', { id: co.id }) + '</div>';
    return h;
  };
  ACT.srcv = p => {
    const co = getCo(p.id);
    co.src = Object.assign({ c: 1 }, co.src, { v: p.v });
    save();
    render();
  };
  ACT.srcc = p => {
    const co = getCo(p.id);
    co.src = Object.assign({ v: 'auto' }, co.src, { c: +p.v });
    save();
    render();
  };
  ACT.fixv = p => {
    getCo(p.id).fixv = p.v;
    save();
    render();
  };
  CT.rivalsCard = function (co, bd) {
    if (co.st !== 'open' || bd.fam === 'fin' || bd.fam === 'energy') return '';
    const rs = rivalsOf(co);
    const sz = r => r.size >= 1.15 ? 'Large' : r.size >= 0.7 ? 'Medium' : 'Small';
    let h = '<div class="card"><h3>Rivals in ' + esc(cityOf(co.city).name) + '</h3><p class="muted small">Good relations can bring you discounts when you buy through them. Some owners will sell, if the price and the relationship are right.</p>';
    rs.forEach(r => {
      h += '<div class="opt"><div class="bhead"><div><b>' + esc(r.name) + '</b>' + (r.listed ? ' <span class="badge">For sale</span>' : '') + '<small>' + esc(r.owner) + ' · ' + sz(r) + ' · relationship ' + relLabel(r) + '</small></div><div class="rt">' + btn('Meet', 'rivmeet', { id: co.id, r: r.id }, 'chip') + btn('Offer to buy', 'rivbuy', { id: co.id, r: r.id }, 'chip primary') + '</div></div></div>';
    });
    return h + '</div>';
  };
  ACT.rivmeet = p => {
    const co = getCo(p.id);
    const r = rivalsOf(co).find(x => x.id === p.r);
    const x = res(meetRival(co, r), 'You had a good conversation.');
    if (x) {
      save();
      render();
    }
  };
  ACT.rivbuy = p => {
    const co = getCo(p.id);
    const r = rivalsOf(co).find(x => x.id === p.r);
    const V = rivalValue(co, r);
    ui.rivres = null;
    /* you name the price: an owner who wants out may take well below value, one who does not wants far more */
    delete ui.inp.rivamt;
    openSheet('<h2>Offer for ' + esc(r.name) + '</h2><p class="muted small">Rough value: ' + money(V) + (r.listed ? '. The owner wants to sell.' : '. A rival that is not for sale rarely sells, and lowball offers sour the relationship.') + '</p>' + '<span class="lab">Your offer</span>' + inp('rivamt', 'Amount') + btn('Send offer', 'rivoffer', { id: co.id, r: r.id }, 'primary wide') + btn('Cancel', 'sheetclose', undefined, 'ghost wide'));
  };
  ACT.rivoffer = p => {
    const co = getCo(p.id);
    const r = rivalsOf(co).find(x => x.id === p.r);
    if (!co || !r) return;
    const amt = inum('rivamt', 0);
    if (!(amt > 0)) { toast('Type the amount you offer.', true); return; }
    const x = proposeBuy(co, r, amt / Math.max(1, rivalValue(co, r)));
    save();
    const no = x.price && S.cash < x.price;
    openSheet('<h2>' + esc(r.name) + '</h2><div class="note ' + (x.r === 'accept' ? 'good' : x.r === 'counter' ? '' : 'bad') + '">' + esc(x.msg) + '</div>' + (x.price ? btn(x.r === 'accept' ? 'Buy for ' + money(x.price) : 'Accept ' + money(x.price), 'rivclose', { id: co.id, r: r.id, price: x.price }, 'primary wide' + (no ? ' cant' : '')) + (no ? '<p class="muted small">You have ' + mshort(S.cash) + ' in your account.</p>' : '') : '') + btn('Close', 'sheetclose', undefined, 'ghost wide'));
  };
  ACT.rivclose = p => {
    const co = getCo(p.id);
    const r = rivalsOf(co).find(x => x.id === p.r);
    const n = acquireRival(co, r, p.price);
    if (typeof n === 'string') {
      res(n);
      return;
    }
    closeSheet();
    save();
    ui.stack = [];
    ui.tab = 'cos';
    ui.view = { n: 'co', p: { id: n.id, t: 'ov' } };
    render(true);
    toast('You now own ' + n.name + '.');
  };
  CT.abroad = function (co, bd) {
    if (co.st !== 'open' || (co.franchise && co.franchise.fran)) return '';
    const others = CO_ORDER.filter(k => k !== co.country);
    let h = '<div class="card"><h3>Expand abroad</h3><p class="muted small">Open a subsidiary in another country. It needs foreign registration and local permits, follows local tax and wages, and starts with part of your brand. Each country with operations can have its own compliance desk at your main office.</p>';
    h += chips(others.filter(k => legalStatus(co.type, k).ok).map(k => [k, CO[k].flag + ' ' + CO[k].name]), ui.abr || '', 'abrset', {});
    const k = ui.abr;
    if (k && CO[k]) {
      const lg = legalStatus(co.type, k);
      if (!lg.ok) h += noteBox('Not allowed in ' + esc(CO[k].name) + '. ' + esc(lg.why), true); else {
        const prev = CTXCO;
        setCtx({ country: k });
        const est = setupEstimate(co.type, { country: k, city: CO[k].cities[0].id, size: 1, form: 'AS' });
        const tot = est.total;
        setCtx(prev);
        h += row('Estimated start cost', money(tot)) + row('Registration', 'about ' + Math.ceil(DOCS.forreg[3] * CO[k].bur * (deskFor(k) ? 0.6 : 1.4)) + ' weeks') + btn('Open in ' + esc(CO[k].name), 'abrgo', { id: co.id, k }, 'primary wide');
      }
    }
    const f = co.fr;
    if (f && f.on) {
      h += '<h3 class="gap">Master franchise</h3><p class="muted small">Sell the whole country to a local partner. You get a big fee up front and half the royalties. Legal work is slower and costlier in complex countries.</p>';
      (f.masters || []).forEach(m => {
        h += row(CO[m.c].flag + ' ' + CO[m.c].name, S.week < m.ready ? 'registering, ' + (m.ready - S.week) + ' wk' : m.n + ' units · ' + mshort(m.rev) + '/wk');
      });
      if (k && CO[k] && legalStatus(co.type, k).ok && !(f.masters || []).some(m => m.c === k)) h += btn('Sell master franchise for ' + esc(CO[k].name), 'frmast', { id: co.id, k }, 'chip primary');
    }
    return h + '</div>';
  };
  ACT.abrset = p => {
    ui.abr = p.v;
    render();
  };
  ACT.abrgo = p => {
    const co = getCo(p.id);
    confirmThen('Open in ' + esc(CO[p.k].name) + '?', 'A new subsidiary is created there. Share capital and fees come from your personal cash. You then register and fund it.', 'Open', () => {
      const r = expandAbroad(co, p.k);
      if (typeof r === 'string') {
        res(r);
        return;
      }
      save();
      ui.abr = '';
      ui.stack = [];
      ui.tab = 'cos';
      ui.view = { n: 'co', p: { id: r.id, t: 'doc' } };
      render(true);
      toast('Subsidiary created.');
    });
  };
  ACT.frmast = p => {
    const co = getCo(p.id);
    const r = frMaster(co, p.k);
    if (res(r, 'Master franchise signed.')) {
      save();
      render();
    }
  };
  ACT.frset = p => {
    ui.inp[p.k] = String(p.v);
    render();
  };
  ACT.frlaunch = p => {
    const co = getCo(p.id);
    const r = frSetup(co, { fee: inum('frfee', 150000), roy: inum('frroy', 0.06), supp: Math.min(1, inum('frsup', 0)) });
    if (res(r, 'Franchise launched!')) {
      save();
      render();
    }
  };
})();


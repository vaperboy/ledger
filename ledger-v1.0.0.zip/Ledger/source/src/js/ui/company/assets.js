/* ---- ui/company/assets.js ---- */
(function () {
  'use strict';
  const U = window.UI, { ui, V, ACT, esc, nok, tone, sgn, svg, bar, row, btn, card, sec, noteBox, badge, contact, seg, chips, inp, inum, quick, stepper, tabsRow, go, setView, openSheet, closeSheet, confirmThen, toast, res, render, save } = U;
  const CT = window.CT;
  const docState = (co, id) => {
    const d = co.docs[id];
    if (!d) return ['none', 'Not applied', 'var(--muted)'];
    if (d.st === 'ok') return ['ok', 'Approved', 'var(--green)'];
    if (d.st === 'applied') return ['wait', 'Ready in ' + Math.max(0, d.done - S.week) + ' wk', 'var(--amber)'];
    return ['lapsed', 'Lapsed', 'var(--red)'];
  };

  /* the opening checklist (here and on the overview of a company being set up, ui/company/view.js CT.setupOv):
     V.1.0.0: every item still to do is one tap: a document is applied for, premises and equipment open their
     picker with that item chosen, missing cash for the opening stock is put in from your own cash. Several
     documents at once: one button applies for all of them. */
  const CL_DO = { doc: 'Apply', prem: 'Choose', eq: 'Choose', stockcash: 'Put in' };
  function clRows(co, items) {
    const todo = items.filter(x => !x.ok && x.k.indexOf('doc:') === 0 && !(co.docs[x.k.slice(4)] && co.docs[x.k.slice(4)].st === 'applied'));
    return items.map(it => {
      const kind = it.k.split(':')[0], go = !it.ok && !(kind === 'doc' && co.docs[it.k.slice(4)] && co.docs[it.k.slice(4)].st === 'applied');
      const inner = '<i>' + (it.ok ? '✓' : '') + '</i><div><div>' + esc(it.t) + '</div>' + (it.sub ? '<small>' + esc(it.sub) + '</small>' : '') + '</div>';
      return go ? '<button class="step go59" data-a="cldo" data-p="' + esc(JSON.stringify({ id: co.id, k: it.k })) + '">' + inner + '<span class="btn chip">' + (CL_DO[kind] || 'Open') + '</span></button>' : '<div class="step ' + (it.ok ? 'done' : '') + '">' + inner + '</div>';
    }).join('') + (todo.length > 1 ? btn('Apply for all ' + todo.length + ' documents' + (sum(todo, x => docCost(co, x.k.slice(4))) ? ' · ' + mshort(sum(todo, x => docCost(co, x.k.slice(4)))) : ''), 'docsall', { id: co.id }, 'primary wide') : '');
  }
  CT.clRows = clRows;
  ACT.cldo = p => {
    const co = getCo(p.id);
    if (!co) return;
    const k = p.k, kind = k.split(':')[0];
    if (kind === 'doc') return ACT.applydoc({ id: co.id, d: k.slice(4) });
    if (kind === 'prem' || kind === 'eq') { ui.eqsel = kind === 'prem' ? 'prem' : k.slice(3); return go('co', { id: co.id, t: 'ops', s: 'assets' }); }
    if (kind === 'stockcash') { const need = Math.max(0, initialStockCost(co, BD[co.type]) - co.cash); return ACT.cash41in({ id: co.id, a: rnl(need * 1.1, 5000) }); }
    go('co', { id: co.id });
  };
  /* every document still to apply for, in one go (the accountant's registration waits until one is picked) */
  ACT.docsall = p => {
    const co = getCo(p.id);
    if (!co) return;
    const L = docNeeds(co).filter(d => d !== 'mva_na' && !docOk(co, d) && !(co.docs[d] && co.docs[d].st === 'applied'));
    let n = 0, cost = 0, why = '';
    L.forEach(d => { const c = docCost(co, d), r = applyDoc(co, d); if (r === 'ok') { n++; cost += c; } else if (!why) why = r; });
    if (why === 'pickacc') { accPicker(co); }
    else if (why === 'cash') toast('Not enough cash in ' + co.name + ' for the rest. Put money in first.', true);
    if (n) toast('Applied for ' + n + (n === 1 ? ' document' : ' documents') + (cost ? ' · ' + mshort(cost) : '') + '.');
    save();
    render();
  };
  function setupCard(co) {
    if (co.st !== 'setup') return '';
    const items = openChecklist(co), miss = items.filter(x => !x.ok);
    return card('<h3>' + (miss.length ? miss.length + ' items left before opening' : 'Ready to open') + '</h3>' + clRows(co, items) + '<p class="muted small">' + (miss.length ? 'The company opens by itself as soon as everything above is in place.' : 'Everything is ready. It opens as soon as there is cash for the opening stock.') + '</p>' + (co.mgr ? btn('Let the manager set things up', 'autoset', { id: co.id }, 'wide') : ''));
  }
  CT.doc = function (co, bd) {
    return setupCard(co) + docsCard(co, bd);
  };
  function eqOverview(co, bd, sel) {
    const P = co.prem, need = stdEq(bd, co.size);
    const row_ = (id, t, v, cls) => '<button class="opt ovrow ' + (sel === id ? 'on' : '') + '" data-a="eqpick" data-p="' + esc(JSON.stringify({ e: id })) + '"><b>' + t + '</b><span class="' + (cls || '') + '">' + v + '</span></button>';
    let h = row_('prem', 'Premises', P && P.m2 ? P.m2 + ' m² · ' + (P.owned ? 'owned' : 'rented') : 'None');
    bd.eq.forEach(e => {
      const n = eqCount(co, e.id), std = need[e.id] || 0;
      const fl = [e.fl.indexOf('r') >= 0 ? 'Required' : '', e.fl.indexOf('c') >= 0 ? 'Capacity' : '', e.fl.indexOf('q') >= 0 ? 'Quality' : ''].filter(Boolean).join(' · ');
      h += row_(e.id, esc(e.n) + ' <small>' + fl + '</small>', n + ' / ' + (std || '–'), n < std ? 'neg' : 'pos');
    });
    return '<div class="card thin">' + h + '</div>';
  }
  ACT.eqpick = p => { ui.eqsel = p.e; window.UI.render(); };
  CT.eq = function (co, bd) {
    const sel = ui.eqsel === 'prem' || bd.eq.some(e => e.id === ui.eqsel) ? ui.eqsel : 'prem';
    return '<div class="split">' + eqOverview(co, bd, sel) + '<div>' + (sel === 'prem' ? premCard(co, bd) : eqCard(co, bd, sel)) + '</div></div>' + (CT.famAssets ? CT.famAssets(co, bd) : '');
  };
  function docsCard(co, bd) {
    const need = docNeeds(co).filter(d => d !== 'mva_na');
    const held = Object.keys(co.docs).filter(d => need.indexOf(d) < 0 && d !== 'mva_na');
    let h = '<div class="card"><h3>Documents and certificates<small>Each business type has its own requirements.</small></h3>';
    need.concat(held).forEach(id => {
      const dd = docDef(id);
      if (!dd) return;
      const st = docState(co, id);
      const cost = docCost(co, id);
      const optional = need.indexOf(id) < 0;
      h += '<div class="opt"><div class="bhead"><div><b>' + esc(dd[0]) + (optional ? ' <small>(extra)</small>' : '') + '</b><small>' + esc(dd[1]) + (dd[5] ? ' · ' + esc(dd[5]) : '') + (id === 'org' && co.form === 'ENK' && !cost ? ' Free for sole proprietors.' : '') + '</small><small style="color:' + st[2] + '">' + st[1] + (dd[4] ? ' · renews ' + money(renewCost(co, id)) + '/yr' : '') + '</small></div><div class="rt">' + (st[0] === 'none' || st[0] === 'lapsed' ? '<b>' + (cost ? money(cost) : 'Free') + '</b>' + btn(st[0] === 'lapsed' ? 'Renew' : 'Apply', 'applydoc', { id: co.id, d: id }, 'chip primary') : '') + '</div></div></div>';
    });
    h += btn('More documents…', 'moredocs', { id: co.id }, 'ghost wide') + '</div>';
    return h;
  }
  ACT.applydoc = p => {
    const co = getCo(p.id);
    if (p.d === 'acctr' && !co.acc) {
      accPicker(co);
      return;
    }
    const r = applyDoc(co, p.d);
    if (r === 'pickacc') accPicker(co); else if (res(r, 'Applied. Processing takes about ' + Math.max(1, docWeeks(co, p.d)) + (docWeeks(co, p.d) > 1 ? ' weeks.' : ' week.'))) {
      save();
      render();
    }
  };
  ACT.moredocs = p => {
    const co = getCo(p.id);
    const need = docNeeds(co);
    const list = Object.keys(DOCS).filter(d => need.indexOf(d) < 0 && !docSkipped(d, co.country) && !co.docs[d] && d !== 'mva_na' && d !== 'fran_op');
    openSheet('<h2>More documents</h2><p class="muted small">Optional certificates can unlock choices or protect you in inspections.</p>' + list.map(d => '<div class="opt"><div class="bhead"><div><b>' + esc(docDef(d)[0]) + '</b><small>' + esc(docDef(d)[1]) + '</small></div><div class="rt"><b>' + (docCost(co, d) ? money(docCost(co, d)) : 'Free') + '</b>' + btn('Apply', 'applydoc2', { id: co.id, d: d }, 'chip') + '</div></div></div>').join('') + btn('Close', 'sheetclose', undefined, 'wide'));
  };
  ACT.applydoc2 = p => {
    const co = getCo(p.id);
    if (res(applyDoc(co, p.d), 'Applied.')) {
      save();
      ACT.moredocs(p);
    }
  };
  function accPicker(co) {
    provSheet(co, 'acc');
  }
  ACT.pickacc = p => {
    const co = getCo(p.id);
    pickAccountant(co, p.a);
    save();
    closeSheet();
    toast('Accountant hired.');
  };
  window.accPicker = accPicker;

/* premises */
  function premCard(co, bd) {
    if (!bd.prem || bd.prem[0] === 'none' || bd.fam === 'rent' || bd.fam === 'fin' && false) {
      if (!bd.prem) return '';
    }
    if (bd.prem && bd.prem[0] === 'home' && !co.prem) {
      return '';
    }
    const P = co.prem;
    let h = '<div class="card"><h3>Premises</h3>';
    if (P && P.m2) h += row('Type', esc(PREM[P.kind][0])) + row('Size', P.m2 + ' m²') + (P.landlord ? row(P.lname || 'Location', esc(P.landlord)) : '') + row(P.owned ? 'Owned, value' : 'Rent per month', P.owned ? nok(P.val) : nok(P.rent * P.m2 / 12)) + (P.loan ? row('Mortgage', nok(P.loan)) : '');
  else h += '<p class="muted small">' + (bd.prem && bd.prem[0] === 'home' ? 'Works from home. No premises needed.' : 'No premises yet.') + '</p>';
    if (bd.prem && bd.prem[0] !== 'home' && bd.prem[0] !== 'none') h += btn(P && P.m2 ? 'Change premises' : 'Choose premises', 'premsheet', { id: co.id }, 'wide');
    return h + '</div>';
  }
  ACT.premsheet = p => {
    const co = getCo(p.id), bd = BD[co.type];
    const kind = bd.prem[0];
    const P = PREM[kind];
    const city = cityOf(co.city);
    const infl = Math.pow(1 + S.econ.infl, S.week / 52);
    const L = premListings(co);
    openSheet('<h2>Choose premises</h2><p class="muted small">' + esc(P[3]) + ' Five places are available in ' + esc(city.name) + '. Renting needs a 3 month deposit plus fit-out. Buying needs 35% down and a mortgage.</p>' + L.map(l => {
      const rent = rl(P[1] * l.rentF * city.rent * infl * l.m2 / 12);
      const price = Math.round(P[2] * l.rentF * Math.pow(city.rent, 0.9) * l.m2 * S.econ.housing);
      return '<div class="opt"><div class="bhead"><div><b>' + esc(l.n) + '</b><small>' + l.m2 + ' m² · ' + esc(l.landlord) + '</small><small>Rent ' + mshort(rent) + ' a month · buy ' + mshort(price) + ' · ' + (isFoot(kind) ? (l.loc > 1.03 ? 'more passing trade' : l.loc < 0.97 ? 'less passing trade' : 'normal passing trade') : (l.loc < 0.97 ? 'higher transport costs' : l.loc < 1 ? 'slightly higher transport costs' : 'short transport distances')) + '</small></div><div class="rt">' + btn('Rent', 'premset', { id: co.id, i: l.i, buy: 0 }, 'chip primary') + btn('Buy', 'premset', { id: co.id, i: l.i, buy: 1 }, 'chip') + '</div></div></div>';
    }).join('') + btn('Cancel', 'sheetclose', undefined, 'ghost wide'));
  };
  ACT.premset = p => {
    const co = getCo(p.id), bd = BD[co.type];
    const l = premListings(co)[p.i];
    const old = co.prem && co.prem.m2;
    const run = () => {
      const r = setPrem(co, bd.prem[0], l.m2, !!p.buy, l);
      closeSheet();
      if (res(r, 'Premises set.')) {
        save();
        render();
      }
    };
    if (old) confirmThen('Move premises?', 'You lose the old deposit and fit-out. Equipment stays.', 'Move', run); else run();
  };

/* equipment and vehicles */
  function eqCard(co, bd, only) {
    if (!bd.eq.length) return '';
    ui.eqmode = ui.eqmode || 'new';
    let h = '<div class="card"><h3>Equipment and vehicles</h3>' + chips([['new', 'New'], ['used', 'Used'], ['finance', 'Finance'], ['lease', 'Lease']], ui.eqmode, 'eqmode') + '<p class="muted small">' + ({
      new: 'Pay in full. Best condition.',
      used: '45% cheaper, worn from the start and may break down sooner.',
      finance: '20% down, the rest as a loan over 4–5 years.',
      lease: 'No capital, a monthly fee. You never own it.'
    })[ui.eqmode] + ' Pick a brand and model; ratings come from other buyers.</p></div>';
    const need = stdEq(bd, co.size);
    bd.eq.forEach(e => {
      if (only && e.id !== only) return;
      const n = eqCount(co, e.id), std = need[e.id] || 0, flags = [
        e.fl.indexOf('r') >= 0 ? 'Required' : '',
        e.fl.indexOf('c') >= 0 ? 'Capacity' : '',
        e.fl.indexOf('q') >= 0 ? 'Quality' : ''
      ].filter(Boolean);
      if (e.vo) {
        const mine = co.veh.filter(v => v.eq === e.id);
        h += '<div class="card"><div class="bhead"><div><h3>' + esc(e.n) + '</h3><small>' + flags.join(' · ') + (std ? ' · enough for a business this size: ' + std : '') + '</small></div><div class="rt"><b>' + mine.length + '</b></div></div>' + mine.map(v => '<div class="kv"><span>' + esc(v.name) + ' <small>' + (v.rating ? '★ ' + v.rating.toFixed(1) + ' · ' : '') + condWord(v.cond).toLowerCase() + ' · ' + ({ own: 'owned', fin: 'financed', lease: 'leased' }[v.mode]) + '</small></span><b>' + btn('Sell', 'sellveh', { id: co.id, v: v.id }, 'chip') + '</b></div>').join('') +
        '<div class="rowlist">' + e.vo.map(m => vehCat(m).map(c => {
          const vm = VEH[m];
          const pr = rnl(vm[1] * Math.pow(1 + S.econ.infl, S.week / 52) * c.f, 1000);
          const price = pr * (ui.eqmode === 'used' ? 0.52 : 1);
          return '<button class="opt" data-a="buyveh" data-p="' + esc(JSON.stringify({ id: co.id, e: e.id, m: m, b: c.i })) + '"><div class="bhead"><div><b>' + esc(c.brand + ' ' + c.model) + '</b><small>' + esc(vm[0]) + '</small><small>' + stars(c.rating, c.reviews) + '</small></div><div class="rt"><b>' + (ui.eqmode === 'lease' ? money(pr * 0.0215) + '/mo' : ui.eqmode === 'finance' ? money(price * 0.2) + ' down' : money(price)) + '</b></div></div></button>';
        }).join('')).join('') + '</div></div>';
      } else {
        const r = co.eq[e.id];
        const lease = co.lease[e.id] || 0;
        const cat = eqCat(co.type, e.id, brandN(co), co.country);
        let lastV = '';
        h += '<div class="card"><div class="bhead"><div><h3>' + esc(e.n) + '</h3><small>' + flags.join(' · ') + (std ? ' · enough for a business this size: ' + std : '') + '</small></div><div class="rt"><b>' + n + (lease ? ' <small>(' + lease + ' leased)</small>' : '') + '</b>' + (r ? '<small>' + condWord(r.cond) + '</small>' : '') + '</div></div>' +
        (r && r.mods && r.mods.length ? '<p class="muted small">' + r.mods.map(m => m.n + '× ' + esc(m.nm) + ' ★' + m.rt.toFixed(1)).join(' · ') + '</p>' : '') +
        '<div class="rowlist">' + brandRows(co, e, cat) + '</div>' +
        (r ? '<div class="btnrow">' + btn('Service ' + mcur(r.cost * 0.04 * (1 - fixDisc(co))), 'repaireq', { id: co.id, e: e.id }, 'chip') + btn('Sell all', 'selleq', { id: co.id, e: e.id }, 'chip ghost danger') + '</div>' : '') + '</div>';
      }
    });
    return h;
  }
  function brandRows(co, e, cat) {
    const seen = {};
    return cat.filter(c => !seen[c.vid] && (seen[c.vid] = 1)).map(c => {
      const v = vendById(c.vid), vr = vendRating(v), mine = cat.filter(x => x.vid === c.vid);
      const lo = Math.min.apply(null, mine.map(x => eqPrice(co, e, null, x))) * (ui.eqmode === 'used' ? 0.55 : 1);
      const dc = vdisc('eq', c.vid);
      return '<button class="opt" data-a="eqbrand" data-p="' + esc(JSON.stringify({ id: co.id, e: e.id, v: c.vid })) + '"><div class="bhead"><div><b>' + esc(c.brand) + '</b><small>' + esc(mine.map(x => x.brand).join(', ')) + '</small><small>' + esc(v.owner) + ' · ' + relWord(vrel(c.vid)) + (dc ? ' · ' + Math.round(dc * 100) + '% off' : '') + '</small><small>' + stars(vr) + ' · ' + esc(rvComment(vr)) + '</small></div><div class="rt"><small>from</small><b>' + (ui.eqmode === 'lease' ? money(lo * 0.0235 / (ui.eqmode === 'used' ? 0.55 : 1)) + '/mo' : money(lo)) + '</b></div></div></button>';
    }).join('');
  }
  ACT.eqbrand = p => {
    const co = getCo(p.id), bd = BD[co.type], e = bd.eq.find(x => x.id === p.e), cat = eqCat(co.type, e.id, brandN(co), co.country).filter(c => c.vid === p.v);
    const v = vendById(p.v);
    openSheet('<h2>' + esc(v.name) + '</h2><p class="lead">' + esc(e.n) + ' · ' + esc(v.owner) + ' · ' + relWord(vrel(p.v)) + '</p><div class="rowlist">' + cat.map(c => {
      const lp = eqPrice(co, e, null, c), unit = lp * (ui.eqmode === 'used' ? 0.55 : 1);
      return '<button class="opt" data-a="eqsheet" data-p="' + esc(JSON.stringify({ id: co.id, e: e.id, i: c.i })) + '"><div class="bhead"><div><b>' + esc(c.tier) + ' · ' + esc(c.brand + ' ' + c.model) + '</b><small>' + stars(c.rating, c.reviews) + ' · ' + esc(c.cm) + '</small></div><div class="rt"><b>' + (ui.eqmode === 'lease' ? money(lp * 0.0235) + '/mo' : money(unit)) + '</b><small>per unit</small></div></div></button>';
    }).join('') + '</div>' + btn('Back', 'sheetclose', undefined, 'ghost wide'));
  };
  ACT.eqsheet = p => {
    const co = getCo(p.id), bd = BD[co.type], e = bd.eq.find(x => x.id === p.e), c = eqCat(co.type, e.id, brandN(co), co.country)[p.i];
    const n = eqCount(co, e.id), std = stdEq(bd, co.size)[e.id] || 0;
    ui.inp.eqq = String(Math.max(1, std - n));
    const lp = eqPrice(co, e, null, c), unit = lp * (ui.eqmode === 'used' ? 0.55 : 1);
    openSheet('<h2>' + esc(c.brand + ' ' + c.model) + '</h2><p class="lead">' + esc(e.n) + ' · ' + esc(c.tier) + (c.seller ? ' · sold by ' + esc(c.seller) : '') + '</p><div class="kv"><span>Buyer rating</span><b>' + stars(c.rating, c.reviews) + ' · ' + esc(c.cm) + '</b></div>' + row('Output', (c.perf >= 1 ? '+' : '') + Math.round((c.perf - 1) * 100) + '%') + row('Reliability', c.rel < 0.85 ? 'Excellent' : c.rel < 1.05 ? 'Good' : c.rel < 1.25 ? 'Fair' : 'Poor') + row('Price per unit', ui.eqmode === 'lease' ? money(lp * 0.0235) + ' / month' : money(unit)) + row('You have', n + (std ? ' · enough for a business this size: ' + std : '')) + inp('eqq', 'Quantity', ui.inp.eqq) + '<div class="btnrow">' + btn('Cancel', 'sheetclose', undefined, 'ghost') + btn('Buy', 'buyeq', { id: co.id, e: e.id, i: p.i }, 'primary') + '</div>');
  };
  ACT.eqmode = p => {
    ui.eqmode = p.v;
    render();
  };
  ACT.buyeq = p => {
    const co = getCo(p.id), bd = BD[co.type], e = bd.eq.find(x => x.id === p.e);
    const q = Math.max(1, Math.round(inum('eqq', 1)));
    const c = eqCat(co.type, e.id, brandN(co), co.country)[p.i];
    const unit = eqPrice(co, e, null, c);
    const tot = (ui.eqmode === 'used' ? unit * 0.55 : unit) * q;
    confirmThen('Buy ' + q + ' × ' + esc(c.brand + ' ' + c.model) + '?', ui.eqmode === 'lease' ? 'Monthly lease about ' + money(unit * 0.0235 * q) + '.' : ui.eqmode === 'finance' ? '20% down (' + money(tot * 0.2) + ') and a loan for the rest.' : 'You pay ' + money(tot) + '.', 'Buy', () => {
      closeSheet();
      if (res(buyEq(co, e.id, q, ui.eqmode, c), 'Bought.')) {
        save();
        render();
      }
    });
  };
  ACT.buyveh = p => {
    const co = getCo(p.id);
    const m = VEH[p.m];
    const c = vehCat(p.m)[p.b];
    confirmThen('Get ' + esc(c.brand + ' ' + c.model) + '?', ui.eqmode === 'lease' ? 'Monthly lease.' : ui.eqmode === 'finance' ? '20% down and a 5-year loan.' : 'You pay the price in full.', 'Confirm', () => {
      if (res(buyVeh(co, p.e, p.m, ui.eqmode, c), 'Vehicle added.')) {
        save();
        render();
      }
    });
  };
  ACT.sellveh = p => {
    const co = getCo(p.id);
    confirmThen('Sell this vehicle?', 'You get roughly 78% of its book value.', 'Sell', () => {
      sellVeh(co, p.v);
      save();
      render();
    });
  };
  ACT.selleq = p => {
    const co = getCo(p.id), e = BD[co.type].eq.find(x => x.id === p.e);
    confirmThen('Sell all ' + esc(e.n) + '?', 'You get about 70% of book value. Capacity may collapse.', 'Sell', () => {
      sellEq(co, p.e);
      save();
      render();
    }, false);
  };
  ACT.repaireq = p => {
    const co = getCo(p.id);
    const r = co.eq[p.e];
    const c = Math.round(r.cost * 0.04 * (1 - fixDisc(co)));
    if (!payCo(co, c, 'oth', 'Equipment service') && co.cash < -coOverdraft(co)) {
      toast('Not enough cash.', true);
    }
    r.cond = Math.min(1, r.cond + 0.3);
    save();
    render();
    toast('Serviced.');
  };
})();


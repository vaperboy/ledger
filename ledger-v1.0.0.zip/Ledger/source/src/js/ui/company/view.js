/* ---- ui/company/view.js ---- */
(function () {
  'use strict';
  const U = window.UI, { ui, V, ACT, esc, nok, tone, sgn, svg, bar, row, btn, card, sec, noteBox, badge, contact, seg, chips, inp, inum, quick, stepper, tabsRow, spark, go, tabTo, setView, openSheet, closeSheet, confirmThen, toast, res, render, save } = U;
  const CT = {};
  window.CT = CT; // company tabs
  /* ---------- the company screen: Overview · Sales · Manage · Money ----------
     (V.1.0.0: the old Staff and Company tabs are one, Manage: the team first, then running the company and the
     paperwork; Close down sits with the other money decisions. A football club: Overview · Squad · Money · Company). Each tab is built here from the parts it shows. Its rows open
     pages of their own (p.t ops, fin or deal with p.s, built by opsPart, CT.finPart and CT.dealPart), and a page's back
     arrow returns to the tab the page belongs to. Older links (t: mk, ppl, eq, doc, ana, set, mon …) land where they meant.
     The tabs' numbers at the top are features/screens/company_dashboards.js (DASH56). */
  const TABS = { ov: 'Overview', cli: 'Sales', st: 'Manage', money: 'Money', more: 'Company' };
  const tabOrder = bd => bd.fam === 'club' ? ['ov', 'st', 'money', 'more'] : ['ov', 'cli', 'st', 'money'];
  const P = o => esc(JSON.stringify(o));
  /* where a link lands: { tab, t, s }: t and s name a page (ops, fin, deal), or s alone a page of the Sales tab (mk, hys, cmp) */
  function route(p, bd) {
    const t = p.t || 'ov', s = p.s || '';
    let r;
    if (t === 'cli' || t === 'mk' || t === 'mkt') r = { tab: 'cli', s: s || (t === 'cli' ? '' : 'mk') };
    else if (t === 'st' || t === 'ppl') r = { tab: 'st' };
    else if (t === 'money' || t === 'mon') r = { tab: 'money' };
    else if (t === 'eq' || t === 'set') r = { tab: 'more', t: 'ops', s: 'assets' };
    else if (t === 'doc') r = { tab: 'more', t: 'ops', s: 'docs' };
    else if (t === 'ana') r = { tab: 'more', t: 'deal', s: 'insight' };
    else if (t === 'ops') r = s === 'people' ? { tab: 'st' } : s === 'marketing' ? { tab: 'cli', s: 'mk' } : s === 'prices' ? { tab: 'cli', t, s } : s ? { tab: 'more', t, s } : { tab: 'more' };
    else if (t === 'fin') r = s ? { tab: s === 'close' && bd.fam === 'club' ? 'more' : 'money', t, s } : { tab: 'money' };
    else if (t === 'deal') r = s ? { tab: s === 'value' || s === 'sell' ? 'money' : s === 'cust' || s === 'rivals' ? 'cli' : 'more', t, s } : { tab: 'more' };
    else r = { tab: t === 'more' ? 'more' : 'ov' };
    if (bd.fam === 'club' && r.tab === 'cli') r = r.t ? Object.assign(r, { tab: 'more' }) : { tab: 'ov' };
    if (bd.fam !== 'club' && r.tab === 'more') r.tab = 'st'; /* the Company tab is part of Manage */
    return r;
  }
  CT.route = route;
  function tabBar(co, bd, cur) {
    return '<div class="ptabs tabs35">' + tabOrder(bd).map(k => '<button class="' + (k === cur ? 'on' : '') + '" data-a="cotab" data-p="' + P({ id: co.id, v: k }) + '">' + (bd.fam === 'club' && k === 'st' ? 'Squad' : TABS[k]) + '</button>').join('') + '</div>';
  }
  /* a company with a manager: one slim line says who runs it; you can still open and change everything, and the
     manager follows your changes (the manager's own decisions are in features/people/managers_keep_it_working.js) */
  function mgrBanner(co, bd) {
    if (!co.mgr || co.st !== 'open' || bd.fam === 'club') return '';
    const n = S.npcs[co.mgr], nm = n ? n.name : 'Your manager';
    return '<div class="mgrbar">' + (n && window.faceAv ? faceAv(n) : '') + '<span><b>' + esc(nm) + '</b> ' + (co.mgrNotice ? '<em class="neg">leaves ' + dateStr(co.mgrNotice.w) + '</em>' : 'runs it day to day' + (window.OA59 ? '<small class="' + (OA59.drift(co) > 0 ? 'neg' : '') + '">' + OA59.word(co).replace(/^./, x => x.toUpperCase()) + '</small>' : '')) + '</span>' +
      (co.mgrNotice ? btn('Find a successor', 'go', { n: 'mgrhire', p: { id: co.id } }, 'chip primary') : window.OA59 && OA59.since(co) >= 6 ? btn('Meet', 'oa59meet', { id: co.id }, 'chip primary') : btn('Contact', 'askmgr', { id: co.id }, 'chip')) + '</div>'; /* V.1.0.0: how it stands since your last meeting, and the meeting in one tap (features/people/owner_attention.js) */
  }
  CT.mgrBanner = mgrBanner;
  /* one tappable row; R() keeps its key and what it opens for the dashboards */
  function lrow(a, p, ic, t, sub, right) {
    return '<button class="lrow" data-a="' + a + '" data-p="' + P(p) + '"><span class="lic">' + svg(ic, 20) + '</span><span class="ctext"><b>' + t + '</b>' + (sub ? '<small>' + esc(sub) + '</small>' : '') + '</span>' + (right || '<i>›</i>') + '</button>';
  }
  CT.lrow = lrow;
  const R = (key, a, p, ic, t, sub, right) => ({ key, a, p, html: lrow(a, p, ic, t, sub, right) });
  const lrows = L => { const h = L.filter(x => x).map(r => typeof r === 'string' ? r : r.html).join(''); return h ? '<div class="lrows">' + h + '</div>' : ''; };
  function subhead(co, bd, tab, title, s) {
    return '<div class="subhead"><button class="iconbtn" data-a="cotab" data-p="' + P({ id: co.id, v: tab }) + '" aria-label="Back">' + svg('back', 18) + '</button><h2>' + title + '</h2></div>' + (s && window.DASH56 ? DASH56.subCard(co, bd, s) : '');
  }

  /* --- Sales: the numbers, then competitors and business customers, the ways to sell, marketing, how you sell and
     complaints (each of the last three on a page of its own) --- */
  const SALES_SUB = { mk: 'Marketing', hys: 'How you sell', cmp: 'Complaints' };
  function salesTab(co, bd, s) {
    if (SALES_SUB[s]) {
      const body = s === 'mk' ? opsPart(co, bd, 'marketing') : s === 'hys' ? (window.HYS56 ? HYS56.page(co, bd) : '') : CT.complaints ? CT.complaints(co, bd) : '';
      return mgrBanner(co, bd) + subhead(co, bd, 'cli', SALES_SUB[s]) + (body || '<div class="calm">Nothing here for ' + esc(bd.n.toLowerCase()) + '.</div>');
    }
    let n = 0;
    try { n = rivalsOf(co).length; } catch (e) { }
    const s33 = co.sw33 || {}, b2b = acctOk(co) || (co.accts || []).length || (s33.ct || []).length || (s33.one || []).length || (window.R33 && R33.ways && R33.ways(co).some(w => ['contract', 'offer'].indexOf(w[0]) >= 0));
    const A = [R('rivals', 'codeal', { id: co.id, s: 'rivals' }, 'fire', 'Competitors', n ? n + ' rivals in ' + cityOf(co.city).name + ' · meet them, buy them, watch their prices' : 'Who you compete with')];
    if (b2b && window.custSummary) A.push(R('cust', 'codeal', { id: co.id, s: 'cust' }, 'tie', 'Business customers', custSummary(co)));
    if (window.TND56 && TND56.eligible(co)) A.push(R('tnd56', 'go', { n: 'tnd56', p: { id: co.id } }, 'house', 'Tenders', TND56.summary(co)));
    const B = [R('mk', 'cotab', { id: co.id, v: 'cli', s: 'mk' }, 'mega', 'Marketing', (mktCost(co) > 0 ? mshort(mktCost(co)) + ' a week on ads · ' : 'No ads running · ') + awWord(co.aware).toLowerCase())];
    if (bd.knobs && bd.knobs.length && window.HYS56) B.push(R('hys', 'cotab', { id: co.id, v: 'cli', s: 'hys' }, 'cog', 'How you sell', HYS56.summary(co, bd)));
    if (CT.complaints && CT.complaints(co, bd) && (!window.SEEN57 || SEEN57.cmp(co))) {
      const open = (co.compl || []).filter(c => c.st === 'open').length;
      B.push(R('cmp', 'cotab', { id: co.id, v: 'cli', s: 'cmp' }, 'chat', 'Complaints', open ? open + ' waiting for an answer' : co.mgr ? 'Your manager answers them' : 'None open', open ? '<span class="pill red">' + open + '</span>' : ''));
    }
    return mgrBanner(co, bd) + (window.DASH56 ? DASH56.sales(co, bd) : '') + lrows(A) + (window.R33 && R33.salesCard ? R33.salesCard(co) || '' : '') + lrows(B);
  }

  /* --- Staff: the numbers, you next to your manager, the team, courses and perks (features/people/perks_and_hosting.js),
     and payroll with the people it pays --- */
  function staffTab(co, bd) {
    let h = (window.DASH56 ? DASH56.staff(co, bd) : '') + (co.mgr && co.st === 'open' && bd.fam !== 'club' && window.R45 && R45.youCard ? R45.youCard(co) : '') + mgrBanner(co, bd) + opsPart(co, bd, 'people');
    h += lrows([V.academy && bd.crs && bd.crs.length ? R('acad', 'acad36', { id: co.id }, 'grad', 'Courses', 'Train your people: better work, more pay, more loyalty') : '', window.PK58 ? PK58.row(co) : '']);
    if (window.R29 && R29.on && R29.on() && V.payroll29 && R29.row) h += '<h2 class="sec">Payroll</h2>' + lrows([R29.row(co)]);
    if (bd.fam !== 'club') h += companyTab(co, bd, 1); /* Manage: the running rows follow the team */
    return h;
  }

  /* --- Money: pay yourself first, then results, unpaid invoices, loans, ownership and value, accountant --- */
  function moneyTab(co, bd) {
    const L = [];
    if (bd.fam !== 'club' && window.R6FIN && R6FIN.payselfRow) L.push(R6FIN.payselfRow(co));
    let sub = 'Months, accounts, transactions, bills';
    try { if (window.R30 && R30.monthOf) { const mo = R30.monthOf(co), last = (co.hist || [])[co.hist.length - 1], pl = v => (v >= 0 ? '+' : '−') + mshort(Math.abs(v)); sub = 'This month ' + pl(mo.p) + (last ? ' · last month ' + pl(last.profit) : ''); } } catch (e) { }
    L.push(R('res36', 'go', { n: 'res36', p: { id: co.id } }, 'chart', 'Results', sub));
    { const q = invoiceSale(co); if (q.n) L.push(R('inv', 'invsheet', { id: co.id }, 'coin', 'Sell unpaid invoices', 'Customers owe ' + mshort(q.a) + ' · get ' + mshort(q.get) + ' now')); }
    ['loans', 'value', 'legal'].forEach(k => L.push(R(k, 'cofin', { id: co.id, s: k }, CT.FIN_SUB[k][1], CT.FIN_SUB[k][0], CT.finSummary(co, bd, k))));
    if (bd.fam !== 'club') L.push(R('close', 'cofin', { id: co.id, s: 'close' }, 'check', 'Close down', 'Wind the company down'));
    return '<div class="cols">' + (window.DASH56 ? DASH56.money(co, bd, L) : '') + lrows(L) + '</div>';
  }

  /* --- Company: running and growing first, then protection, paperwork and closing --- */
  function opsRow(co, bd, k) {
    const miss = k === 'docs' && docNeeds(co).some(d => d !== 'mva_na' && !docOk(co, d));
    return R(k, 'cosub', { id: co.id, s: k }, OPS_SUB[k][1], OPS_SUB[k][0], opsSummary(co, bd, k), miss ? '<i class="rdot"></i>' : '');
  }
  function companyTab(co, bd, inManage) {
    const dk = CT.dealKeys(co, bd), ops = opsKeys0(co, bd).filter(k => ['people', 'marketing', 'prices'].indexOf(k) < 0);
    const dl = k => R(k, 'codeal', { id: co.id, s: k }, CT.DEAL_SUB[k][1], CT.DEAL_SUB[k][0], dealSummary(co, bd, k));
    const A = [], B = [];
    if (dk.indexOf('supply') >= 0) A.push(dl('supply'));
    else if (CT.supplyChainRow) A.push(CT.supplyChainRow(co)); /* the supply chain lives inside Suppliers when there is a Suppliers page */
    if (ops.indexOf('assets') >= 0) A.push(opsRow(co, bd, 'assets'));
    if (dk.indexOf('grow') >= 0) A.push(dl('grow'));
    if (window.R12 && R12.boardRow) A.push(R12.boardRow(co));
    ops.filter(k => ['assets', 'docs', 'ins'].indexOf(k) < 0).forEach(k => A.push(opsRow(co, bd, k)));
    if (window.RN56 && co.type !== 'hold') A.push(RN56.row(co));
    if (window.CY56 && bd.fam !== 'club') B.push(CY56.row(co));
    ['docs', 'ins'].forEach(k => { if (ops.indexOf(k) >= 0) B.push(opsRow(co, bd, k)); });
    if (inManage) return '<h2 class="sec">Running the company</h2>' + lrows(A) + '<h2 class="sec">Paperwork and protection</h2>' + lrows(B);
    B.push(R('close', 'cofin', { id: co.id, s: 'close' }, 'check', 'Close down', 'Wind the company down'));
    const rows = A.concat(B).filter(x => x && typeof x === 'object');
    return (window.DASH56 ? DASH56.company(co, bd, rows) : '') + lrows(A) + '<h2 class="sec">Protection, paperwork and closing</h2>' + lrows(B);
  }

  /* --- a page (ops, fin or deal): the manager line on the running pages, the title with a way back, its numbers --- */
  function page(co, bd, r) {
    const T = r.t === 'ops' ? OPS_SUB : r.t === 'fin' ? CT.FIN_SUB : CT.DEAL_SUB;
    if (!T[r.s]) return null;
    const body = r.t === 'ops' ? opsPart(co, bd, r.s) : r.t === 'fin' ? CT.finPart(co, bd, r.s) : CT.dealPart(co, bd, r.s);
    return (r.t === 'ops' ? mgrBanner(co, bd) : '') + subhead(co, bd, r.tab, T[r.s][0], r.s) + body;
  }

  V.co = function (p) {
    const co = getCo(p.id);
    if (!co) return card('This company no longer exists.');
    if (co.st === 'sold' || co.st === 'bust') return card('<h3>' + esc(co.name) + '</h3><p class="muted">' + (co.st === 'bust' ? 'This company went bankrupt.' : 'This company is sold or closed.') + '</p>');
    const bd = BD[co.type], r = route(p, bd);
    let body = r.t ? page(co, bd, r) : null;
    if (body == null) body = r.tab === 'cli' ? salesTab(co, bd, r.s) : r.tab === 'st' ? staffTab(co, bd) : r.tab === 'money' ? moneyTab(co, bd) : r.tab === 'more' ? companyTab(co, bd) : '<div class="cols">' + CT.ov(co, bd) + '</div>';
    return tabBar(co, bd, r.tab) + body;
  };
  V.heads = V.heads || {};
  V.heads.co = function (p) {
    const co = getCo(p.id);
    if (!co) return {};
    const bd = BD[co.type];
    const m = co.mgr && S.npcs[co.mgr];
    return {
      t: co.name,
      sub: esc(bd.n) + ' · ' + CO[co.country].forms[co.form + 's'] + ' · ' + CO[co.country].flag + ' ' + esc(cityOf(co.city).name) + (co.franchise && co.franchise.fran ? ' · franchise' : '') + (m ? ' · run by ' + esc(m.name) : ''),
      right: '<span class="badge ' + (co.st === 'open' ? 'green' : co.st === 'closed' ? 'red' : 'amber') + '">' + ({ setup: 'Setting up', open: 'Open', closed: 'Closed' }[co.st] || '') + '</span>'
    };
  };
  V.titles.co = 'Company';
  ACT.cotab = p => {
    ui.view = { n: 'co', p: p.s ? { id: p.id, t: p.v, s: p.s } : { id: p.id, t: p.v } };
    render(true);
  };

/* ---------- helpers ---------- */
  function plCard(b, title) {
    const rev = b.rev || 0;
    const lines = [
      ['cogs', 'Cost of goods'],
      ['wages', 'Wages and payroll costs'],
      ['rent', 'Rent'],
      ['mkt', 'Marketing'],
      ['ins', 'Insurance'],
      ['acc', 'Accounting'],
      ['dep', 'Depreciation'],
      ['int', 'Interest'],
      ['oth', 'Other costs'],
      ['fine', 'Fines'],
      ['loss', 'Losses and write-offs']
    ];
    let h = '<h3>' + title + '</h3>' + row('Revenue', nok(rev));
    lines.forEach(l => {
      if (b[l[0]]) h += row(l[1], '<span class="muted">−' + npadL(b[l[0]]) + '</span>');
    });
    const prof = rev - sumExp(b);
    h += row('Result before tax', '<span class="' + sgn(prof) + '">' + nok(prof) + '</span>', 'total');
    if (b.tax) h += row('Corporate tax accrued', '<span class="muted">−' + npadL(b.tax) + '</span>');
    return card(h);
  }
  CT.plCard = plCard;
  const DPL = {
    base: 'Base market',
    city: 'City size',
    season: 'Season',
    marketing: 'Awareness',
    reputation: 'Reputation',
    price: 'Your price',
    choices: 'Your choices',
    economy: 'Economy',
    rivals: 'Rivals',
    own: 'Your other outlets nearby',
    chain: 'Chain reach',
    buzz: 'Short-term buzz',
    events: 'Events'
  };
  function why(co) {
    if (!co.dbg || !co.dbg.dp) return '';
    const dp = co.dbg.dp;
    const ks = Object.keys(dp).filter(k => k !== 'base' && DPL[k]);
    if (!ks.length) return '';
    let h = '<h3>What drives demand</h3><div class="why">' + ks.map(k => {
      const ac = analystAcc();
      const v = dp[k] * (1 + (hrng(S.seed + ':why:' + co.id + k + Math.floor(S.week / 13))() - 0.5) * 2 * (1 - ac) * 0.25);
      const cls = v > 1.03 ? 'pos' : v < 0.97 ? 'neg' : 'muted';
      return '<div class="kv"><span>' + DPL[k] + '</span><b class="' + cls + '">' + (v >= 1.15 ? 'Big boost' : v > 1.03 ? 'Helps' : v >= 0.97 ? 'Neutral' : v > 0.85 ? 'Holds back' : 'Holds back a lot') + '</b></div>';
    }).join('') + '</div>';
    if (co.dbg.cp && co.dbg.cp.length) {
      h += '<h3 class="gap">What limits capacity</h3>';
      co.dbg.cp.forEach(c => {
        const ratio = c.need ? c.have / c.need : 1;
        h += '<div class="kv"><span>' + esc(c.label) + '</span><b class="' + (ratio < 0.9 ? 'neg' : '') + '">' + (c.kind === 'gate' ? 'missing' : (Math.round(c.have * 10) / 10) + ' / ' + (Math.round(c.need * 10) / 10)) + '</b></div>';
      });
      if (co.dbg.bot) h += noteBox('Weakest link: <b>' + esc(co.dbg.bot) + '</b>');
    }
    return h;
  }

/* ---------- overview ---------- */
  function demandLevel(w) {
    const r = w.cap ? w.D / w.cap : 1;
    return r > 1.25 ? 'Overflowing' : r > 1.0 ? 'Very busy' : r > 0.75 ? 'Busy' : r > 0.5 ? 'Steady' : r > 0.25 ? 'Quiet' : 'Very quiet';
  }
  CT.demandLevel = demandLevel;
  /* the overview fits one phone screen: the storefront (features/player/moments_and_trophies.js shopCard), cash with
     this week and this month, what the trade did this week (features/sales/trades_in_hours.js weekCard), the target
     (features/people/targets_and_budgets.js TG58.row) and the trade's own card (CT.famOv). Everything else has its tab. */
  const MN3 = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const plusS = v => (v >= 0 ? '+' : '−') + mshort(Math.abs(v));
  CT.ov = function (co, bd) {
    if (co.st === 'setup') return CT.setupOv(co, bd);
    const al = coAlerts(co), bw = co.bk.w || {};
    const c41 = S.cc41, sofar = c41 && c41.w === S.week && c41.start && c41.start[co.id] != null;
    const dW = sofar ? co.cash - c41.start[co.id] : co.wkD != null ? co.wkD : (bw.rev || 0) - sumExp(bw);
    const bm = co.bk.m || {}, mp = (bm.rev || 0) - sumExp(bm), last = co.hist[co.hist.length - 1], unpaid = sum(co.recv || [], r => r.a);
    let h = window.R28 && R28.shopCard ? R28.shopCard(co) : '';
    if (window.R12 && R12.storeBanner) h += R12.storeBanner(co); /* a chain store names its chain */
    h += '<button class="card ovhero ov56" data-a="go" data-p="' + esc(JSON.stringify({ n: 'month30', p: { id: co.id } })) + '"><span class="lab">Company cash</span>' +
      '<b class="huge ' + (co.cash < 0 ? 'neg' : '') + '">' + nok(co.cash) + '</b><small class="mo56">' + MN3[monthIdx(S.week) % 12] + ' so far <b class="' + sgn(mp) + '">' + plusS(mp) + '</b>' + (last ? ' · last month ' + plusS(last.profit) : '') + ' ›</small><span class="pills"><span class="pl ' + (dW >= 0 ? 'g' : 'r') + '">' + plusS(dW) + (sofar ? ' so far this week' : ' this week') + '</span>' + al.slice(0, 2).map(a => '<span class="pl ' + (a[1] === 'bad' ? 'r' : '') + '">' + esc(a[0]) + '</span>').join('') + (al.length > 2 ? '<span class="pl r">+' + (al.length - 2) + '</span>' : '') + (unpaid > 0 ? '<span class="pl a">' + mshort(unpaid) + ' unpaid</span>' : '') + '</span></button>';
    if (window.R41 && R41.weekCard) h += R41.weekCard(co, bd);
    if (window.TG58) h += TG58.row(co); /* this month's targets */
    const fm = CT.famOv ? CT.famOv(co, bd) : '';
    if (fm) h += fm;
    const evs = S.inbox.filter(x => x.co === co.id && x.status === 'open');
    if (evs.length) h += btn('Open ' + evs.length + ' decision' + (evs.length > 1 ? 's' : ''), 'opendec', { id: co.id }, 'primary wide');
    return h;
  };
  CT.setupOv = function (co, bd) {
    const items = openChecklist(co);
    const miss = items.filter(x => !x.ok);
    let h = card('<h3>Opening checklist</h3>' + CT.clRows(co, items) + (miss.length ? '<p class="muted small">Tap an item to do it. Some documents take weeks: carry on playing while you wait. Staff are hired under Manage.</p>' : '<p class="muted small">Everything is in place.</p>') + (!miss.length ? '<p class="muted small">The doors open by themselves. If it does not happen, the company needs more cash for opening stock.</p>' : ''));
    h += co.mgr ? btn('Let the manager set things up', 'autoset', { id: co.id }, 'wide') : card('<h3>Setup by hand</h3><p class="muted small">Nothing happens automatically. Apply for documents, choose premises, buy equipment and hire people yourself. Hire a manager first if you want automatic setup.</p>');
    h += card(row('Cash in company', nok(co.cash)) + row('Weekly fixed costs (est.)', nok(coWeekCost(co))));
    return h;
  };
  ACT.autoset = p => {
    const co = getCo(p.id);
    confirmThen('Automatic setup?', 'Your manager applies for all required documents, chooses standard premises and buys standard new equipment. Staff are hired by the manager over time. It can cost a lot.', 'Do it', () => {
      const log = autoSetup(co);
      save();
      render();
      if (log.length) toast('Some steps failed: ' + log.slice(0, 2).join('; '), true); else toast('Done. Press Next week while documents are processed.');
    });
  };

/* ---------- operations ---------- */
  const OPS_SUB = {
    table: ['League and budget', 'chart'],
    people: ['People and manager', 'people'],
    assets: ['Premises and equipment', 'tool'],
    marketing: ['Marketing', 'mega'],
    prices: ['Prices', 'cog'],
    time: ['Staffing and your time', 'people'],
    upkeep: ['Stock', 'tool'],
    choices: ['Business choices', 'biz'],
    special: ['Special', 'chart'],
    ins: ['Insurance', 'check'],
    docs: ['Documents and permits', 'doc']
  };
  OPS_SUB.biz = ['Prices, upkeep, choices', 'biz'];
  const OPS_ST = ['Minimal', 'Normal', 'Thorough'], OPS_SK = ['Lean', 'Normal', 'Safe stock'];
  function actingMgr(co) {
    if (co.mgr) return null;
    return co.staff.filter(x => x.role === 'lead' && S.npcs[x.id]).sort((a, b) => S.npcs[b.id].skill - S.npcs[a.id].skill)[0] || null;
  }
  window.actingMgr = actingMgr;
  const promoAsk = (co, a) => Math.round(15 + S.npcs[a.id].skill * 0.5 + (hrng(S.seed + ':pm:' + a.id)() - 0.5) * 10);
  function doPromote(co, a, pct) {
    const n = S.npcs[a.id], w = Math.round(a.wage * (1 + pct / 100));
    n.stats = n.stats || { ops: n.skill, people: n.skill, sales: n.skill, fin: n.skill, risk: n.skill };
    n.mtype = n.mtype || 'gen'; n.ask = w; n.hired = 0;
    const r = hireManager(co, n, w);
    if (r === 'ok') { co.staff = co.staff.filter(x => x.id !== a.id); closeSheet(); save(); render(); } else res(r);
  }
  function promoSheet(id, pct, msg) {
    const co = getCo(id), a = actingMgr(co); if (!a) return;
    const n = S.npcs[a.id], above = !!(S.group && (S.group.ceo || (S.group.regional || []).length));
    openSheet('<h2>Promote ' + esc(n.name) + '</h2><small>' + skillBand(n.skill) + ' · now ' + money(a.wage) + '/mo</small>' + (msg ? '<div class="note">' + msg + '</div>' : '') + '<div class="opt"><b>Raise</b><div class="chips">' + [15, 25, 40, 60].map(v => btn('+' + v + '%', 'promoset', { id, v }, v === pct ? 'chip primary' : 'chip')).join('') + '<input class="pin" type="number" min="0" value="' + pct + '" onchange="UI.ACT.promoset({id:' + id + ',v:+this.value})"></div></div><div class="chips">' + btn('Offer +' + pct + '%', 'promogo', { id, v: pct }, 'primary') + (above ? btn('Let management decide', 'promoboss', { id }, 'chip') : '') + btn('Close', 'sheetclose', undefined, 'ghost') + '</div>', 'plan');
  }
  ACT.promoset = p => promoSheet(p.id, Math.max(0, Math.min(200, Math.round(p.v) || 0)), '');
  ACT.promogo = p => {
    const co = getCo(p.id), a = actingMgr(co); if (!a) return;
    const ask = promoAsk(co, a), nm = esc(S.npcs[a.id].name);
    if (p.v >= ask) doPromote(co, a, p.v);
    else if (p.v >= ask * 0.8) promoSheet(p.id, ask, nm + ': "I would need +' + ask + '%." Offer set to that.');
    else promoSheet(p.id, p.v, nm + ' declines. Too low.');
  };
  ACT.promoboss = p => {
    const co = getCo(p.id), a = actingMgr(co); if (!a) return;
    if (S.npcs[a.id].skill >= 55) doPromote(co, a, promoAsk(co, a)); else promoSheet(p.id, 30, 'Management: not ready yet.');
  };
  function opsPart(co, bd, k) {
    let h = '';
    if (k === 'biz') return '<div class="triple">' + ['prices', 'upkeep', 'choices'].filter(x => x !== 'choices' || bd.knobs.length > 0).map(x => opsPart(co, bd, x)).join('') + '</div>';
    const ticket = ticketEff(co, bd);
    if (k === 'prices') {
      h += card('<h3>Prices</h3>' + '<div class="kv"><span>Your prices</span><b></b></div>' + chips(PRICE_NAMES.map((n, i) => [i - 3, n]), co.price, 'pricestep', { id: co.id }) + row('Average ticket now', nok(ticket) + ' / ' + esc(bd.unit)) + '<p class="muted small">Higher prices earn more per sale but lose customers. ' + (hasHQ('ana') && co.price > 0 ? (brandPull(co) < 0.5 ? 'Your analyst: customers hardly know you, so few will pay these prices yet. ' : 'Your analyst: your name is strong enough to carry these prices. ') : '') + 'Rivals react to large changes.</p>');
    } else if (k === 'time') {
      if (!co.mgr) h += window.ownerHoursRow ? window.ownerHoursRow(co) : card('<h3>Your time here</h3>' + chips([[10, '10 h'], [20, '20 h'], [40, '40 h'], [50, '50 h'], [60, '60 h']], co.ohrs, 'ownhrs', { id: co.id }) + '<p class="muted small">You work ' + co.ohrs + ' hours a week in this company. Your skill is ' + Math.round(co.oskill) + '. Over 46 hours hurts quality. Hire a manager to free your time.</p>');
    else h += card('<h3>Manager runs it</h3><p class="muted small">' + esc(S.npcs[co.mgr] ? S.npcs[co.mgr].name : '') + ' manages this company. See People.</p>');
    } else if (k === 'upkeep') {
      if (bd.tw.stock || bd.fam === 'retail' || bd.fam === 'prod') h += card('<h3>Stock policy</h3>' + chips([[0, 'Lean'], [1, 'Normal'], [2, 'Safe stock']], co.stockPol, 'stockpol', { id: co.id }) + '<p class="muted small">Lean stock saves money but runs out. Safe stock costs storage and may spoil.</p>');
    } else if (k === 'choices') {
      bd.knobs.forEach(k => {
        const cur = co.knob[k.id] || 0, on = i => k.multi ? !!(cur & (1 << i)) : cur === i;
        h += '<div class="card"><h3>' + esc(k.n) + (k.d ? '<small>' + esc(k.d) + '</small>' : '') + '</h3>' + k.opts.map((o, i) => {
          if (!knobOk(co, o) && !on(i)) return '';
          const miss = knobReqMissing(co, k, i);
          return '<button class="opt ' + (on(i) ? 'on' : '') + '" data-a="setknob" data-p="' + esc(JSON.stringify({ id: co.id, k: k.id, i: i })) + '"><b>' + esc(o.n) + '</b>' + (o.d ? '<small>' + esc(o.d) + '</small>' : '') + (miss.length ? '<small style="color:var(--red)">Needs: ' + miss.map(d => docDef(d)[0]).join(', ') + '</small>' : '') + '</button>';
        }).join('') + '</div>';
      });
    } else if (k === 'special') {
      h += CT.famOps ? CT.famOps(co, bd) : '';
    }
  else if (k === 'ins') {
      h += CT.insurance(co, bd);
    }
  else if (k === 'docs') {
      h += CT.doc(co, bd);
    }
  else if (k === 'people') {
      h += (co.mgr || actingMgr(co) || bd.fam === 'club' ? '' : opsPart(co, bd, 'time')) + CT.ppl(co, bd);
    }
  else if (k === 'assets') {
      h += CT.eq(co, bd);
    }
  else if (k === 'marketing') {
      h += CT.mkt(co, bd);
    }
  else if (k === 'table') {
      h += CT.clubTable(co);
    }
    return h;
  }
  function opsSummary(co, bd, k) {
    if (k === 'prices') return PRICE_NAMES[pLvl(co) + 3];
    if (k === 'time') return co.mgr ? 'Manager runs it' : 'You, ' + co.ohrs + ' h a week';
    if (k === 'upkeep') return 'Stock ' + OPS_SK[co.stockPol].toLowerCase();
    if (k === 'choices') return window.HYS56 ? HYS56.summary(co, bd) : '';
    if (k === 'ins') {
      const n = Object.keys(co.ins || {}).filter(x => co.ins[x]).length;
      return n ? n + (n > 1 ? ' policies' : ' policy') : 'No policies';
    }
    if (k === 'people') return (co.mgr && S.npcs[co.mgr] ? S.npcs[co.mgr].name + ' · ' : '') + co.staff.length + (co.staff.length === 1 ? ' worker' : ' workers');
    if (k === 'assets') {
      const n = Object.keys(co.eq || {}).length + (co.veh ? co.veh.length : 0);
      return (co.prem && co.prem.m2 ? co.prem.m2 + ' m² · ' : '') + n + ' kinds of equipment';
    }
    if (k === 'marketing') {
      const n = Object.keys(co.mkt || {}).filter(x => co.mkt[x] && co.mkt[x].b).length;
      return n ? n + (n > 1 ? ' campaigns running' : ' campaign running') : 'No campaigns';
    }
    if (k === 'table') return 'Table, wages, tickets';
    if (k === 'docs') {
      const m = docNeeds(co).filter(d => d !== 'mva_na' && !docOk(co, d)).length;
      return m ? m + ' missing or pending' : 'All in order';
    }
    return '';
  }
  const OPS_ORD = {
    svc: ['people', 'prices', 'marketing', 'choices', 'assets', 'upkeep', 'docs', 'ins'],
    venue: ['prices', 'people', 'assets', 'marketing', 'choices', 'upkeep', 'docs', 'ins'],
    retail: ['prices', 'marketing', 'people', 'assets', 'upkeep', 'choices', 'docs', 'ins'],
    prod: ['assets', 'people', 'upkeep', 'choices', 'prices', 'marketing', 'docs', 'ins'],
    logi: ['assets', 'people', 'upkeep', 'prices', 'choices', 'marketing', 'docs', 'ins'],
    project: ['people', 'choices', 'assets', 'marketing', 'prices', 'upkeep', 'docs', 'ins'],
    rent: ['special', 'assets', 'prices', 'people', 'upkeep', 'docs', 'ins', 'marketing'],
    fin: ['special', 'people', 'choices', 'prices', 'marketing', 'docs', 'ins'],
    energy: ['assets', 'special', 'people', 'upkeep', 'choices', 'docs', 'ins'],
    club: ['table', 'people', 'assets']
  };
  function opsKeys0(co, bd) {
    const has = {
      prices: 0,
      time: 0,
      upkeep: bd.fam !== 'club' && !!(bd.tw.stock || bd.fam === 'retail' || bd.fam === 'prod'),
      choices: 0,
      special: !!(CT.famOps && bd.fam !== 'club' && CT.famOps(co, bd)),
      ins: bd.fam !== 'club',
      docs: bd.fam !== 'club',
      people: 1,
      assets: 1,
      marketing: bd.fam !== 'club',
      table: bd.fam === 'club'
    };
    let keys = (OPS_ORD[bd.fam] || OPS_ORD.svc).filter(k => has[k]);
    if (co.st === 'setup' && keys.indexOf('docs') >= 0) {
      keys = keys.filter(k => k !== 'docs');
      keys.unshift('docs');
    }
    return keys;
  }
  CT.opsPart = opsPart;
  CT.OPS_SUB = OPS_SUB;
  ACT.askmgr = p => {
    const co = getCo(p.id);
    const n = co && co.mgr ? S.npcs[co.mgr] : null;
    if (!n) return;
    ui.thread = n.name;
    ui.threadCo = co.id;
    tabTo('msgs');
  };
  ACT.cosub = p => {
    ui.view = { n: 'co', p: { id: p.id, t: 'ops', s: p.s || '' } };
    render(true);
  };
  ACT.pricestep = p => {
    const co = getCo(p.id);
    co.price = clamp(p.v, -3, 3);
    save();
    render();
  };
  ACT.ownhrs = p => {
    const co = getCo(p.id);
    co.ohrs = p.v;
    save();
    render();
  };
  ACT.maint = p => {
    getCo(p.id).maint = p.v;
    save();
    render();
  };
  ACT.stockpol = p => {
    getCo(p.id).stockPol = p.v;
    save();
    render();
  };
  ACT.setknob = p => {
    const co = getCo(p.id), bd = BD[co.type], k = bd.knobs.find(x => x.id === p.k);
    if (!knobOk(co, k.opts[p.i])) return;
    const miss = knobReqMissing(co, k, p.i);
    const run = () => {
      co.knob[k.id] = k.multi ? ((co.knob[k.id] || 0) ^ (1 << p.i)) : p.i;
      save();
      render();
    };
    if (miss.length) {
      const cost = sum(miss, d => docCost(co, d));
      confirmThen('Documents needed', 'This choice only works with: ' + miss.map(d => docDef(d)[0]).join(', ') + '. Apply now for ' + money(cost) + '? The choice takes effect when approved.', 'Apply and choose', () => {
        miss.forEach(d => {
          const r = applyDoc(co, d);
          if (r !== 'ok' && r !== 'have') res(r);
        });
        run();
      });
      return;
    }
    run();
  };

/* ---------- marketing ---------- */
  CT.marketing = function (co, bd) {
    const keys = Object.keys(CH).filter(k => chOk(co, k));
    const rc = reachOf(co);
    const dec = awareDecay(co);
    let h = '<div class="card"><h3>Brand awareness in ' + esc(CO[co.country].name) + '<small>Ads only work in the country they run in.</small></h3>' + row('How well known', awWord(co.aware)) + (hasHQ('mkt') ? row('Marketing director', 'Campaigns work about 10% better') : '') + (dec < 0.95 ? '<p class="muted small">Your name is fading faster than it should: weak reviews or quality.</p>' : '') + row('Total ad spend per week', nok(mktCost(co))) + (co.hype > 3 ? row('Buzz right now', buzzWord(co.hype)) : '') + ((S.cos.filter(x => x.type === co.type && x.st === "open" && x.country !== co.country).length) ? S.cos.filter(x => x.type === co.type && x.st === 'open' && x.country !== co.country).map(x => row(CO[x.country].flag + ' ' + esc(CO[x.country].name), awWord(x.aware))).join('') : '') + '<p class="muted small">National TV moments reach everyone but cost a fortune; they pay off for brands with many outlets.</p></div>';
    const sorted = keys.slice().sort((a, b) => ((CH[b].b2b * bd.b2b + (1 - bd.b2b)) * CH[b].eff) - ((CH[a].b2b * bd.b2b + (1 - bd.b2b)) * CH[a].eff));
    const chanRow = k => {
      let h = '';
      const c = CH[k], cur = co.mkt[k] ? co.mkt[k].b : 0;
      const lock = co.mkt[k] && co.mkt[k].lock && co.mkt[k].lock > S.week;
      h += '<div class="opt ' + (cur ? 'on' : '') + '"><b>' + esc(c.n) + (cur ? ' · ' + money(cur) + '/wk' : '') + '</b><small>' + esc(c.note) + (c.mw ? ' Minimum ' + c.mw + ' weeks.' : '') + (lock ? ' Locked for ' + (co.mkt[k].lock - S.week) + ' more weeks.' : '') + '</small><div class="chips">' + c.opts.map(o => '<button class="btn chip ' + (o === cur ? 'primary' : '') + '" data-a="setmkt" data-p="' + esc(JSON.stringify({ id: co.id, ch: k, b: o })) + '">' + (o ? mcur(o) : 'Off') + '</button>').join('') + '</div></div>';
      return h;
    };
    const on = sorted.filter(k => co.mkt[k] && co.mkt[k].b), off = sorted.filter(k => !(co.mkt[k] && co.mkt[k].b));
    const chanCard = k => {
      const c = CH[k], m = co.mkt[k], cur = m.b, since = m.since != null ? m.since : S.week, lock = m.lock && m.lock > S.week;
      const wks = Math.max(0, S.week - since);
      const meter = c.slow ? ['Build-up', Math.min(1, wks / 26), wks >= 26 ? 'Full effect' : Math.round(wks / 26 * 100) + '%'] : c.mw ? ['Minimum term', Math.min(1, wks / c.mw), lock ? (m.lock - S.week) + ' wk left' : 'Done'] : null;
      return '<div class="card chcard"><div class="bhead"><div class="cchd"><span class="lic">' + svg('mega', 18) + '</span><span class="ctext"><b>' + esc(c.n) + '</b><small>' + esc(c.note) + '</small></span></div><span class="badge ' + (lock ? 'amber' : 'green') + '">' + (lock ? 'Locked' : 'Running') + '</span></div>' + row('Weekly cost', money(cur)) + row('Running for', wks + (wks === 1 ? ' week' : ' weeks')) + (meter ? row(meter[0], meter[2]) + bar(meter[1] * 100, meter[1] >= 1 ? 'var(--green)' : 'var(--amber)') : '') + '<div class="chips">' + c.opts.map(o => '<button class="btn chip ' + (o === cur ? 'primary' : '') + '" data-a="setmkt" data-p="' + esc(JSON.stringify({ id: co.id, ch: k, b: o })) + '">' + (o ? mcur(o) : 'Off') + '</button>').join('') + '</div></div>';
    };
    h = h.replace('<div class="card"><h3>Brand awareness in ', '<div class="card"><div class="kv bigkv"><span>Weekly budget</span><b>' + money(mktCost(co)) + '</b></div><h3>Brand awareness in ');
    h += '<h2 class="sec">Active channels</h2>' + (on.length ? on.map(chanCard).join('') : '<div class="calm">No campaigns running.</div>');
    h += btn('Plan a campaign', 'plopen', { id: co.id }, 'primary wide');
    return h;
  };
  CT.mkt = function (co, bd) {
    return bd.fam === 'club' ? card('<p class="muted small">Your fans are your marketing. Results and ticket prices do the work.</p>') : CT.marketing(co, bd);
  };
  ACT.setmkt = p => {
    const co = getCo(p.id);
    const r = setMkt(co, p.ch, p.b);
    if (r === 'ok') {
      if (ui.sheet) closeSheet();
      save();
      render();
    } else res(r);
  };

/* ---------- campaign planner ---------- */
  const PL = { id: 0, ch: null, b: 0, w: 0, ag: 2 };
  const lux = co => (co.price > 0 ? 0.6 : co.price < 0 ? 0.15 : 0.35);
  const fitAg = (co, i) => Math.pow(window.AGX.SPD[i], 0.3 + 1.2 * lux(co));
  const spW = f => (f < 0.35 ? 'Tight' : f < 0.6 ? 'Modest' : f < 0.85 ? 'Comfortable' : 'Deep pockets');
  const chScore = (bd, k) => window.R30 && R30.chScore ? R30.chScore(bd, k) : (CH[k].b2b * bd.b2b + (1 - bd.b2b)) * CH[k].eff;
  const nice = n => { const m = Math.pow(10, Math.max(0, Math.floor(Math.log10(Math.max(1, n))) - 1)); return Math.max(1, Math.round(n / m) * m); };
  const minB = (co, k) => nice(CH[k].opts.filter(o => o)[0] * 0.6 * ((CO[co.country] || {}).wage || 1));
  const bW = (co, k, b) => { const r = b / minB(co, k); return r <= 1.5 ? 'Light' : r <= 6 ? 'Steady' : 'Heavy'; };
  const mgrAcc = st => { const n = S.npcs[st.id] || {}; return clamp((((n.skill || 40) - 30) / 60) + Math.min(0.2, (S.week - (st.w0 || 0)) / 52 * 0.03 + (n.exp || 0) * 0.01), 0.1, 1); };
  const bestMgr = co => (S.office ? S.office.staff.filter(x => (x.role === 'perf' || x.role === 'mkt') && (x.cos || []).indexOf(co.id) >= 0) : []).sort((x, y) => mgrAcc(y) - mgrAcc(x))[0];
  function guess(co, i) {
    const m = bestMgr(co); if (!m) return null;
    const a = mgrAcc(m), R = hrng(S.seed + ':sp:' + co.id + ':' + i + ':' + Math.floor(S.week / 13)), t = fitAg(co, i);
    let v = t + (R() - 0.5) * 2 * (1 - a) * 0.6;
    if (a < 0.4 && R() < 0.2) v = t;
    if (a > 0.85 && R() < 0.12) v = t + (R() < 0.5 ? -1 : 1) * (0.3 + R() * 0.2);
    return clamp(v, 0, 1);
  }
  function advise(co) {
    const bd = BD[co.type], keys = Object.keys(CH).filter(k => chOk(co, k) && !CH[k].prem).sort((x, y) => chScore(bd, y) - chScore(bd, x));
    const x = reviewList('mine').find(y => y.key === 'c' + co.id), st = x && x.n >= RV_MIN ? window.AGX.ageStats(x).g : null;
    const sc = i => { const g = guess(co, i); return g == null ? null : g * (st && st[i].n >= 3 ? st[i].avg / 5 : 0.8); };
    const ag = [0, 1, 2, 3].filter(i => sc(i) != null).sort((u, v) => sc(v) - sc(u))[0];
    return ag == null ? null : { ch: keys[0], ag, b: minB(co, keys[0]) * 5, w: 12, st };
  }
  window.PLX = { guess, spW, bestMgr, mgrAcc, advise, bW, minB };
  function planEst(co, bd) {
    const c = CH[PL.ch], scale = Math.max(0.5, bd.Dc * bd.ticket / 8000), sc = c.sc * Math.max(0.4, Math.min(8, scale * 0.9));
    const fit = (1 - bd.aud) * (c.loc || 0.5) + bd.aud * (c.b2b || 0.5);
    const g = Math.min(60, c.eff * (1 - Math.exp(-PL.b / sc)) * (0.45 + fit) * (PL.w || 13) * (0.85 + 0.35 * fitAg(co, PL.ag)));
    return Math.round((((cityOf(co.city) || {}).pop || 150000) * Math.min(0.6, g / 100)) / 100) * 100;
  }
  function planSheet() {
    const co = getCo(PL.id), bd = BD[co.type], X = window.AGX, cf = fxr(CC());
    const keys = Object.keys(CH).filter(k => chOk(co, k) && !CH[k].prem).sort((a, b) => chScore(bd, b) - chScore(bd, a));
    if (PL.ch === null || keys.indexOf(PL.ch) < 0) { PL.ch = keys[0]; PL.b = 0; }
    const c = CH[PL.ch], mn = minB(co, PL.ch);
    if (PL.b < mn) PL.b = mn * 2;
    if (PL.w && PL.w < (c.mw || 0)) PL.w = c.mw;
    const adv = advise(co);
    const chip = (t, k, v, on) => btn(t, 'plset', { k, v }, on ? 'chip primary' : 'chip');
    let h = '<h2>Campaign</h2><div class="opt"><b>Channel</b><select class="sel" onchange="UI.ACT.plset({k:\'ch\',v:this.value})">' + keys.map(k => '<option value="' + k + '"' + (k === PL.ch ? ' selected' : '') + '>' + esc(CH[k].n) + '</option>').join('') + '</select><small>' + esc(CH[PL.ch].note) + '</small></div>';
    h += '<div class="opt"><b>Per week · ' + bW(co, PL.ch, PL.b) + '</b><div class="chips">' + [1, 2, 5, 10, 25].map(m => chip(mcur(mn * m), 'b', mn * m, PL.b === mn * m)).join('') + '<input class="pin" type="number" min="1" value="' + Math.round(PL.b / cf) + '" onchange="UI.ACT.plset({k:\'bx\',v:+this.value})"></div></div>';
    h += '<div class="opt"><b>For</b><div class="chips">' + [4, 12, 26, 52].filter(w => w >= (c.mw || 0)).map(w => chip(w + ' wk', 'w', w, w === PL.w)).join('') + chip('Ongoing', 'w', 0, PL.w === 0) + '<input class="pin" type="number" min="1" placeholder="weeks" onchange="UI.ACT.plset({k:\'wx\',v:+this.value})"></div></div>';
    h += '<div class="opt"><b>Aim at</b><div class="ags">' + X.AGL.map((l, i) => { const g = guess(co, i); return '<button class="opt ag ' + (i === PL.ag ? 'on' : '') + '" data-a="plset" data-p="' + esc(JSON.stringify({ k: 'ag', v: i })) + '"><b>' + l + '</b><small>' + (g == null ? '?' : spW(g)) + '</small></button>'; }).join('') + '</div>' + (adv ? '<div class="chips"><small>Advice: ' + esc(CH[adv.ch].n) + ', ' + X.AGL[adv.ag] + '</small>' + btn('Use', 'plset', { k: 'adv', v: 1 }, 'chip') + '</div>' : '<small>? = no analyst or marketing manager assigned</small>') + '</div>';
    h += '<div class="chips" style="justify-content:space-between"><small>' + (PL.w ? money(PL.b * PL.w) + ' total' : 'No end date') + (window.R19 && R19.planTxt ? R19.planTxt(co, PL) : ' · reach ~' + planEst(co, bd).toLocaleString('en-US').replace(/,/g, ' ') + (PL.w ? '' : ' per quarter')) + '</small></div>';
    openSheet(h + '<div class="chips">' + btn('Start', 'plgo', undefined, 'primary') + btn('Close', 'sheetclose', undefined, 'ghost') + '</div>', 'plan');
  }
  ACT.plopen = p => { PL.id = p.id; PL.ch = p.ch || null; PL.b = p.b || 0; PL.ag = p.ag == null ? PL.ag : p.ag; PL.w = p.w == null ? 0 : p.w; planSheet(); };
  ACT.plset = p => {
    const co = getCo(PL.id);
    if (p.k === 'adv') { const a = advise(co); if (a) { PL.ch = a.ch; PL.b = a.b; PL.ag = a.ag; PL.w = a.w; } }
    else if (p.k === 'bx') PL.b = Math.max(minB(co, PL.ch), Math.round(p.v * fxr(CC())));
    else if (p.k === 'wx') PL.w = Math.max(CH[PL.ch].mw || 1, Math.round(p.v) || 1);
    else { PL[p.k] = p.v; if (p.k === 'ch') PL.b = 0; }
    planSheet();
  };
  ACT.plgo = () => {
    const co = getCo(PL.id), r = setMkt(co, PL.ch, PL.b);
    if (r !== 'ok') { res(r); return; }
    co.mktEnd = co.mktEnd || {};
    if (PL.w) co.mktEnd[PL.ch] = S.week + PL.w; else delete co.mktEnd[PL.ch];
    co.mktT = { ag: PL.ag };
    closeSheet(); save(); render();
  };
  addStep('mktWeek.before', 30, 'campaigns end on their date', (co, bd, ctx) => {
    if (co.mktEnd) for (const k in co.mktEnd) if (S.week >= co.mktEnd[k]) { delete co.mkt[k]; delete co.mktEnd[k]; }
    if (co.mktT && !Object.keys(co.mkt).length) delete co.mktT;
    ctx.a0v = co.aware;
  });
  addStep('mktWeek.after', 10, 'the age group you target', (co, bd, ctx) => {
    if (co.mktT && co.aware > ctx.a0v) co.aware = clamp(ctx.a0v + (co.aware - ctx.a0v) * clamp(0.85 + 0.35 * fitAg(co, co.mktT.ag), 0.85, 1.2), 0, 100);
  });

/* ---------- insurance ---------- */
  CT.insurance = function (co, bd) {
    const own = co.insr && co.insr.own ? getCo(co.insr.own) : null, ir = co.insr;
    const premW = m => m > 1.05 ? 'premiums above market' : m < 0.95 ? 'premiums below market' : 'premiums around market';
    const payW = m => m >= 0.9 ? 'pays out almost always' : m >= 0.8 ? 'usually pays out' : 'often argues about claims';
    /* the insurer is one row (the list of insurers opens as a sheet), the policies are one row each. With a manager
       who keeps the insurance (features/people/manager_duties.js), the policies the business needs are marked */
    const m = co.mgr && S.npcs[co.mgr], byM = m && window.MD56 && mgrDuty(co, 'ins'), need = window.MD56 ? MD56.insNeed(co) : [];
    let h = byM ? '<div class="mgrbar">' + (window.faceAv ? faceAv(m) : '') + '<span><b>' + esc(m.name.split(' ')[0]) + '</b> keeps the insurance</span></div><span class="tipt">What the business needs is taken out at the month end. A policy you switch stays as you leave it.</span>' : '';
    h += '<div class="lrows"><button class="lrow" data-a="provsheet" data-p="' + esc(JSON.stringify({ id: co.id, k: 'ins' })) + '"><span class="lic">' + svg('shield', 20) + '</span><span class="ctext"><b>' + (ir ? esc(ir.name) : 'Choose an insurer') + '</b><small>' + (ir ? stars(ir.rating) + ' · ' + premW(ir.premM || 1) + ' · ' + payW(ir.payM || 0.9) : 'Each insurer prices and pays out differently. Policies can be bought once you have one.') + '</small></span>' + (ir ? '<i>›</i>' : '<span class="pill amb">Choose</span>') + '</button></div>';
    h += '<h2 class="sec">Policies</h2><div class="lrows">' + Object.keys(INSP).map(k => {
      const p = INSP[k], on = !!co.ins[k];
      return '<button class="lrow' + (ir || on ? '' : ' cant') + '" data-a="toggleins" data-p="' + esc(JSON.stringify({ id: co.id, k })) + '"><span class="ctext"><b>' + esc(p[0]) + (need.indexOf(k) >= 0 && !on ? ' <span class="pill amb">Needed</span>' : '') + (co.insOwn && co.insOwn[k] && byM ? ' <span class="pill">Your choice</span>' : '') + '</b><small>' + esc(p[2]) + ' You pay the first ' + money(p[4]) + '.</small></span><span class="pill ' + (on ? 'green' : '') + '">' + (on ? 'On · ' : '') + mshort(insPremium(co, k)) + '/wk</span></button>';
    }).join('') + '</div>';
    return h + (own ? '<p class="muted small">Your own insurance company gets these premiums and pays the claims.</p>' : '');
  };
  ACT.toggleins = p => {
    const co = getCo(p.id);
    if (!co.ins[p.k] && !co.insr) { toast('Choose an insurer first.', true); return; }
    co.ins[p.k] = co.ins[p.k] ? 0 : 1;
    if (co.mgr) (co.insOwn = co.insOwn || {})[p.k] = 1; /* the manager leaves a policy you switched as it is */
    save();
    render();
  };

/* ---------- analytics ---------- */
  CT.ana = function (co, bd) {
    let h = '';
    const tr = co.trf || [];
    const an = hasHQ('ana');
    if (!co.ga) h += card('<h3>Web analytics</h3><p class="muted small">Connect analytics to see basic traffic for this company. It is free.</p>' + btn('Connect', 'gaon', { id: co.id }, 'primary wide'));
  else h += card('<h3>Traffic<small>Basic web analytics view</small></h3>' + (tr.length > 2 ? '<div style="display:flex;justify-content:center">' + spark(tr, 300, 70) + '</div>' + row('Last 4 weeks vs before', (() => {
      const a = sum(tr.slice(-4), x => x) / Math.max(1, tr.slice(-4).length), b = sum(tr.slice(-8, -4), x => x) / Math.max(1, tr.slice(-8, -4).length);
      return b ? '<span class="' + (a >= b ? 'pos' : 'neg') + '">' + (a >= b ? '+' : '') + Math.round((a / b - 1) * 100) + '%</span>' : '–';
    })()) : '<p class="muted small">Needs a few weeks of data.</p>') + btn('Disconnect', 'gaoff', { id: co.id }, 'ghost wide'));
    const ol = an ? marketOutlook(co) : null;
    if (ol) {
      const pr = x => (x[1] - x[0] < 0.012 ? '+' + pc((x[0] + x[1]) / 2, 0) : '+' + pc(x[0], 0) + ' to +' + pc(x[1], 0));
      h += '<div class="card"><h3>Analyst briefing<small>Prepared for the board' + (ol.top ? ' · one of the best in the field' : ol.a < 0.45 ? ' · an inexperienced read' : '') + '</small></h3>' + row('Brand effect on demand', pr(ol.lift)) + row('Cheaper supplies from size', pc(ol.save[0], 1) + (ol.save[1] - ol.save[0] > 0.004 ? ' to ' + pc(ol.save[1], 1) : '')) + (ol.fc.length ? '<p class="muted small">Weekly sales, last ' + ol.hist.length + ' weeks and the next 8 as forecast.</p><div style="display:flex;justify-content:center">' + spark(ol.hist.concat(ol.fc), 300, 80) + '</div>' : '<p class="muted small">Too little history for a forecast yet.</p>') + '<p class="muted small">' + (ol.top ? 'Reads the market almost exactly and calls turns early.' : ol.a < 0.45 ? 'Treat the numbers as rough guesses. A sharper analyst gives tighter ranges.' : 'Good, but the forecast has a margin of error.') + '</p></div>';
    }
    if (an) {
      h += card(why(co) || '<p class="muted small">Nothing to show yet.</p>');
    }
  else h += card('<h3>Detailed analytics</h3><p class="muted small">Demand drivers, capacity limits and bottlenecks need a data analyst in one of your offices. ' + (hqUnlocked('ana') ? 'Hire one under HQ.' : 'HQ analysts open up when you run ' + hqUnlockText('ana') + '.') + '</p>' + (hqUnlocked('ana') ? btn('Open HQ', 'go', { n: 'office', p: {} }, 'wide') : ''));
    return h;
  };
})();


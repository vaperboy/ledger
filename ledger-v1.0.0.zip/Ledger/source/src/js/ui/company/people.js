/* ---- ui/company/people.js ---- */
(function () {
  'use strict';
  const U = window.UI, { ui, V, ACT, esc, nok, tone, sgn, svg, bar, row, btn, card, sec, noteBox, badge, contact, seg, chips, inp, inum, quick, stepper, tabsRow, go, setView, openSheet, closeSheet, confirmThen, toast, res, render, save } = U;
  const CT = window.CT;
  const band = v => v >= 80 ? 'Outstanding' : v >= 65 ? 'Strong' : v >= 45 ? 'Capable' : v >= 28 ? 'Developing' : 'Entry level';
  const TIERN = { young: 'Young, early career', mid: 'Mid-career', senior: 'Senior, experienced' };
  const TRAITS = {
    late: 'Often late',
    lazy: 'Lazy streak',
    conflict: 'Causes conflict',
    sick: 'High sick leave',
    theft: 'Sticky fingers'
  };
  const FLAGN = {
    late: 'is often late',
    lazy: 'is under-performing',
    conflict: 'is causing conflict',
    sick: 'has high sick leave',
    theft: 'is suspected of stealing'
  };
  window.skillBand = band;

  function tenure(s) {
    const wk = Math.max(0, S.week - (s.w0 || S.week));
    return wk >= 52 ? Math.floor(wk / 52) + ' yr' + (wk >= 104 ? 's' : '') : wk >= 9 ? Math.round(wk / 4.35) + ' mo' : wk + ' wk';
  }
  function staffTag(s) {
    if (s.flag) return ['PROBLEM', 'red'];
    if (s.notice > 0) return ['Leaving', 'red'];
    if (sickNow(s)) return ['Off sick', 'red'];
    if ((s.tired || 0) >= 60) return ['Worn out', 'red'];
    if ((s.tired || 0) >= 40) return ['Tired', 'amber'];
    if (s.nr > 0) return ['New', 'blue'];
    if (rampF(s) < 1) return ['Learning', 'blue'];
    if ((s.skillGain || 0) >= 5) return ['Rising', 'blue'];
    return ['Fine', 'green'];
  }
  /* the Staff tab: Team · Management (ui.stt56[company]). Management is the company's headquarters: its manager,
     assistant manager and the team above, each hired from there (ui/company/headquarters.js) */
  ACT.stt56 = p => { (ui.stt56 = ui.stt56 || {})[p.id] = p.v; render(); };
  CT.ppl = function (co, bd) {
    const std = stdStaff(bd, co.size);
    const short = std.filter(s => co.staff.filter(x => x.role === s[0]).length < s[1]);
    const m = co.mgr ? S.npcs[co.mgr] : null;
    const t = (ui.stt56 || {})[co.id] || 'team';
    let h = '<div class="ptabs">' + [['team', 'Team', co.staff.length], ['mgmt', 'Management']].map(x => '<button class="' + (t === x[0] ? 'on' : '') + '" data-a="stt56" data-p="' + esc(JSON.stringify({ id: co.id, v: x[0] })) + '">' + x[1] + (x[2] ? ' · ' + x[2] : '') + '</button>').join('') + '</div>';
    if (t === 'mgmt' && window.HQ56) return h + HQ56.page(co);
    h += '<div class="bhead"><b>' + (co.staff.length ? co.staff.length + ' staff' : 'No staff') + (short.length ? ' · <span class="neg">missing: ' + short.map(s => esc(ROLES[s[0]][0])).join(', ') + '</span>' : '') + '</b><div class="chips">' + btn('＋ Find workers', 'hirego', { id: co.id }, 'chip primary') + '</div></div>';
    if (co.staff.length) h += '<div class="lrows">' + co.staff.map(s => {
      const n = S.npcs[s.id];
      if (!n) return '';
      const tg = staffTag(s);
      return '<details class="srow" data-sid="' + esc(String(s.id)) + '"' + (String(ui.openStaff) === String(s.id) ? ' open' : '') + '><summary class="lrow">' + faceAv(n) + '<span class="ctext"><b>' + esc(n.name) + '</b><small>' + esc(ROLES[s.role][0]) + workTag(s) + ' · ' + esc(tenure(s)) + ' · ' + money(s.wage) + '/mo</small></span><span class="badge ' + tg[1] + '">' + tg[0] + '</span></summary>' + staffCard(co, s) + hoursCard(co, s) + '</details>';
    }).join('') + '</div>';
    co.staff.filter(s => s.flag && S.npcs[s.id]).slice(0, 2).forEach(s => {
      const n = S.npcs[s.id];
      h += '<div class="card probcard"><b>Problem: ' + esc(n.name) + '</b><p>' + esc(n.name.split(' ')[0]) + ' ' + FLAGN[s.flag] + '. Talk to them, let them go, or leave it to ' + (m ? esc(m.name.split(' ')[0]) : 'later') + '.</p><div class="two">' + btn('Warn', 'warnstaff', { id: co.id, s: s.id }, 'wide') + btn('Let go', 'firestaff', { id: co.id, s: s.id }, 'wide') + '</div></div>';
    });
    const ob = co.staff.filter(x => onbMissing(x).length).length;
    if (ob) h += '<div class="note bad">Paperwork open: ' + ob + '</div>';
    return h;
  };
  /* how much someone works, in a few words: their hours a week (seasonal staff between seasons: when they are back) */
  const MON3 = ['', 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  const fmtH = h => String(Math.round(h * 10) / 10);
  function backIn(s) {
    const m0 = wMonth(S.week) + 1; let m = 0;
    for (let i = 1; i <= 12 && !m; i++) { const x = (m0 - 1 + i) % 12 + 1; if (s.seas.indexOf(x) >= 0) m = x; }
    return MON3[m];
  }
  function workTag(s) {
    if (s.seas && s.off) return ' · seasonal, back in ' + backIn(s);
    return ' · ' + fmtH(weekHours(s)) + ' h a week' + (s.seas ? ', seasonal' : '');
  }
  /* their working week in plain words: hours a week, then about how many hours a day and days a week */
  function workRows(s) {
    if (s.seas && s.off) return row('Works', 'between seasons') + row('Back in', backIn(s));
    const h = weekHours(s), d = h >= 30 ? 5 : Math.max(1, Math.min(5, Math.round(h / 7)));
    return row('Works', fmtH(h) + ' h a week') + row('A normal day', 'about ' + fmtH(h / d) + ' h · ' + d + (d > 1 ? ' days a week' : ' day a week'));
  }
  /* the week they really had, when the place was busier than their hours */
  const lastWeek = s => s.hw && !s.off && Math.abs(s.hw - weekHours(s)) >= 2 ? '<span class="tipt">Worked about ' + s.hw + ' h last week' + (s.hw > weekHours(s) ? ': the place was busier than their hours.' : '.') + '</span>' : '';
  /* with a manager, hours paid by the hour follow the manager's forecast for the week (features/people/seasons_and_hours.js) */
  function planLine(co) {
    const hp = co.hp54, m = co.mgr && S.npcs[co.mgr];
    if (!m || !hp || S.week - hp.w > 1) return '';
    return '<span class="tipt">' + esc(m.name.split(' ')[0]) + ' sets these hours each week from what they expect to sell: about ' + esc(window.rateW ? rateW(hp.F, BD[co.type].unit) : Math.round(hp.F) + ' a week') + ' this week.</span>';
  }
  function hoursCard(co, s) {
    if (!s.hrs && !(s.basis === 'hour' && payFollowsHours(s))) return '';
    const rate = payFollowsHours(s) ? s.wage / (weekHours(s) * 52 / 12) : 0;
    if (!s.hrs) return '<div class="card"><div class="bhead"><b>Paid by the hour</b><small>' + money(Math.round(rate)) + ' an hour</small></div><span class="tipt">Full time, paid for the hours worked. A fixed salary is what most people hope for; giving it to someone who does well makes them likelier to stay.</span>' + planLine(co) + btn('Offer a fixed salary', 'stfix', { id: co.id, s: s.id }, 'wide') + '</div>';
    const max = s.maxH || 60;
    let h = '<div class="card"><div class="bhead"><b>' + (s.seas ? 'Seasonal' : 'Part time') + '</b><small>' + (rate ? money(Math.round(rate)) + ' an hour' : 'fixed pay and commission') + (s.maxH ? ' · studies, at most ' + s.maxH + ' h' : '') + '</small></div>';
    h += planLine(co);
    if (s.seas && window.R54) h += '<div class="chips">' + R54.SEASONS.map(x => { const on = x[2].every(m => s.seas.indexOf(m) >= 0); return '<button class="btn chip' + (on ? ' primary' : '') + '" data-a="stseas" data-p="' + esc(JSON.stringify({ id: co.id, s: s.id, v: x[0] })) + '">' + x[1] + '</button>'; }).join('') + '</div><span class="tipt">Works ' + esc(R54.seasText(s.seas)) + (s.off ? ', off and unpaid until then' : ', off and unpaid the rest of the year') + '. The hours are for the weeks they work.</span>';
    h += '<div class="chips hrs">' + [10, 20, 30, 40, 50, 60].concat([10, 20, 30, 40, 50, 60].indexOf(s.hrs) < 0 ? [s.hrs] : []).sort((a, b) => a - b).map(v => '<button class="btn chip' + (s.hrs === v ? ' primary' : '') + '" data-a="sthrs" data-p="' + esc(JSON.stringify({ id: co.id, s: s.id, v })) + '"' + (v > max ? ' disabled' : '') + '>' + v + ' h</button>').join('') + '</div>';
    /* the last offer they turned down, and why */
    if (s.wishNo && S.week - s.wishNo < 52) h += '<p class="cap47">' + esc(wishWhy(s, s.wish)) + '</p>';
    const full = !s.maxH || s.maxH >= FULL_H;
    return h + (s.seas ? btn('Offer part time all year', 'stpart', { id: co.id, s: s.id }, 'wide') : '') + (full ? btn('Offer full time', 'stfull', { id: co.id, s: s.id }, 'wide') : '') + '</div>';
  }
  ACT.stseas = p => {
    const co = getCo(p.id), s = co && co.staff.find(x => String(x.id) === String(p.s)), S0 = window.R54 && R54.SEASONS.find(x => x[0] === p.v);
    if (!s || !s.seas || !S0) return;
    const all = S0[2].every(m => s.seas.indexOf(m) >= 0);
    const ms = all ? s.seas.filter(m => S0[2].indexOf(m) < 0) : s.seas.concat(S0[2].filter(m => s.seas.indexOf(m) < 0));
    if (!ms.length) { toast('A seasonal worker needs at least one season.', true); return; }
    s.seas = ms.sort((a, b) => a - b);
    s.off = s.seas.indexOf(wMonth(S.week) + 1) < 0;
    ui.openStaff = s.id;
    save(); render();
  };
  ACT.stpart = p => {
    const co = getCo(p.id), s = co && co.staff.find(x => String(x.id) === String(p.s));
    if (!s) return;
    const n = S.npcs[s.id], r = offerPartTime(co, s, 20);
    ui.openStaff = s.id;
    toast(r === 'ok' ? n.name + ' said yes: part time all year, ' + s.hrs + ' h a week.' : wishWhy(s, 'season'), r !== 'ok');
    save(); render();
  };
  ACT.stfix = p => {
    const co = getCo(p.id), s = co && co.staff.find(x => String(x.id) === String(p.s));
    if (!s) return;
    setFixedPay(co, s);
    s.happy = Math.max(s.happy || 0, S.week + 26);
    ui.openStaff = s.id;
    toast(S.npcs[s.id].name + ' now has a fixed salary of ' + money(s.wage) + ' a month.');
    save(); render();
  };
  ACT.sthrs = p => {
    const co = getCo(p.id), s = co && co.staff.find(x => String(x.id) === String(p.s));
    if (!s) return;
    if (s.maxH && p.v > s.maxH) { toast(S.npcs[s.id].name + ' studies and can work at most ' + s.maxH + ' h a week.', true); return; }
    ui.openStaff = s.id;
    setStaffHours(co, s, p.v);
    save(); render();
  };
  ACT.stfull = p => {
    const co = getCo(p.id), s = co && co.staff.find(x => String(x.id) === String(p.s));
    if (!s) return;
    const n = S.npcs[s.id], r = offerFullTime(co, s);
    ui.openStaff = s.id;
    toast(r === 'ok' ? n.name + ' said yes: full time from now on, ' + money(s.wage) + ' a month.' : wishWhy(s, s.wish), r !== 'ok');
    save(); render();
  };
  /* how far a new person has come, and how much they have left in them */
  const LEARNW = { quick: 'learns quickly', normal: 'learns at a normal pace', slow: 'learns slowly' };
  function energyBlock(s) {
    let h = '';
    const r = rampF(s), t = s.tired || 0;
    if (r < 1) h += '<div class="kv"><span>Up to speed</span><b>' + Math.round(r * 100) + '% · ' + LEARNW[learnOf(s)] + '</b></div>';
    if (sickNow(s)) h += '<div class="note bad">Off sick this week.</div>';
    if (t >= 20) h += '<div class="kv"><span>Energy</span><b class="' + (t >= 60 ? 'neg' : '') + '">' + (t >= 60 ? 'Worn out' : t >= 40 ? 'Tired' : 'A bit tired') + (stamOf(s) === 'quick' ? ' · tires quickly' : '') + '</b></div><span class="tipt">' + (t >= 40 ? 'Tired people work slower; worn out, they fall sick or leave. Shorter weeks or another pair of hands let them recover.' : 'Long weeks add up.') + '</span>';
    else if (stamOf(s) === 'never' && (s.hw || 0) > 44) h += '<div class="kv"><span>Energy</span><b>Fresh · never seems to tire</b></div>';
    return h;
  }
  /* the worker's profile, in depth: their working week, their mood and why, and who they are (Profile screen) */
  const capF = t => String(t).replace(/^./, x => x.toUpperCase());
  const PERSW = { driven: 'Driven: wants to do well and move up', steady: 'Steady: calm and reliable', loyal: 'Loyal: sticks with you', arrogant: 'Arrogant: knows best, clashes now and then', lazy: 'Complacent: does what is asked, not more', restless: 'Restless: always looking at the next thing' };
  function moodOf(co, s) {
    const n = S.npcs[s.id], good = [], bad = [];
    const gap = n ? ((wageFor(s.role, co) * (s.pt || 1)) * (0.7 + n.skill / 160) - effW(s)) / ((wageFor(s.role, co) * (s.pt || 1)) || 1) : 0;
    const lr = s.lr != null ? s.lr : s.w0;
    if (s.happy && S.week < s.happy) good.push('pleased with a recent raise or their pay');
    if (staffFit(co, s) <= 0.3) good.push('really likes this kind of work');
    else if (staffFit(co, s) >= 2) bad.push('this job is not really for them');
    if (gap > 0.1) bad.push('paid less than the job usually pays');
    if (s.denied && S.week - s.denied < 26) bad.push('was turned down for a raise ' + (S.week - s.denied) + ' weeks ago');
    else if (lr != null && S.week - lr >= 52) bad.push('no raise for over a year');
    if ((s.tired || 0) >= 40) bad.push('tired from long weeks');
    if (s.flag) bad.push('there is a problem to sort out');
    if (co.mood != null && co.mood < 40) bad.push('the mood in the team is low');
    else if (co.mood != null && co.mood >= 75) good.push('the team gets on well');
    const w = s.notice > 0 ? ['Leaving', 'neg'] : bad.length >= 2 || (bad.length && !good.length && gap > 0.1) ? ['Unhappy', 'neg'] : good.length && !bad.length ? ['Happy', 'pos'] : bad.length ? ['Mixed', ''] : ['Content', ''];
    return { w, good, bad };
  }
  CT.staffProfile = function (co, s) {
    const n = S.npcs[s.id];
    if (!n) return '';
    const mo = moodOf(co, s), wk = Math.max(0, S.week - (s.w0 || S.week)), lr = s.lr != null ? s.lr : null;
    let h = '<div class="card"><h3>Working week</h3>' + workRows(s) + lastWeek(s) +
      row('Pay', money(s.wage) + ' a month') + row('Paid', s.basis === 'fix' ? 'fixed salary' : money(Math.round(s.wage / (weekHours(s) * 52 / 12))) + ' an hour') +
      (s.seas ? row('Seasons', esc(window.R54 ? R54.seasText(s.seas) : '')) : '') + (s.maxH ? row('Can work', 'at most ' + s.maxH + ' h a week (studies)') : '') + energyBlock(s) + '</div>';
    h += '<div class="card"><div class="bhead"><b>Mood</b><b class="' + mo.w[1] + '">' + mo.w[0] + '</b></div>' + (mo.good.length || mo.bad.length ? mo.good.map(x => '<div class="kv"><span>' + esc(capF(x)) + '</span><b class="pos">Good</b></div>').join('') + mo.bad.map(x => '<div class="kv"><span>' + esc(capF(x)) + '</span><b class="neg">Bothers them</b></div>').join('') : '<span class="tipt">Nothing in particular on their mind.</span>') + (s.notice > 0 ? '<span class="tipt">Leaving in ' + s.notice + (s.notice > 1 ? ' weeks' : ' week') + '. A decent raise may make them stay.</span>' : '') + '</div>';
    h += '<div class="card"><h3>About ' + esc(n.name.split(' ')[0]) + '</h3>' + row('Age', n.age) + (n.pers && PERSW[n.pers] ? row('Personality', esc(PERSW[n.pers].split(':')[0])) + '<span class="tipt">' + esc(capF(PERSW[n.pers].split(': ')[1])) + '.</span>' : '') + row('Performance', band(staffSkill(s)) + ((s.skillGain || 0) >= 3 ? ' <small class="pos">better since they started</small>' : '')) +
      row('Learns', LEARNW[learnOf(s)].replace('learns ', '')) + row('Long weeks', stamOf(s) === 'never' ? 'never seems to tire' : stamOf(s) === 'quick' ? 'tires quickly' : 'tires after a while') +
      ((s.hrs || s.seas) ? row('Wants', workWish(s) === 'season' ? 'only seasonal work' : workWish(s) === 'part' ? 'part time, not full time' : 'would take full time') : s.basis === 'hour' && wantsFix(n) ? row('Hopes for', 'a fixed salary') : '') +
      row('With you since', dateStr(s.w0 || S.week) + ' · ' + (wk >= 52 ? Math.floor(wk / 52) + ' yr ' : '') + (wk % 52) + ' wk') + row('Last raise', lr != null && lr !== s.w0 ? dateStr(lr) : 'none yet') + '</div>';
    if (window.workBlock) { const wb = window.workBlock(co, s); if (wb) h += '<div class="card">' + wb + '</div>'; }
    return h;
  };
  function staffCard(co, s) {
    const n = S.npcs[s.id];
    if (!n) return '';
    const sk = staffSkill(s);
    const gap = n ? ((wageFor(s.role, co) * (s.pt || 1)) * (0.7 + n.skill / 160) - s.wage) / s.wage : 0;
    const wk = S.week - s.w0;
    return '<div class="card"><div class="bhead"><div><h3>' + esc(n.name) + '</h3><small>' + esc(ROLES[s.role][0]) + ' · age ' + n.age + ' · ' + (wk >= 52 ? Math.floor(wk / 52) + ' yr ' : '') + (wk % 52) + ' wk here</small></div><div class="rt"><b>' + money(s.wage) + '</b><small>per month</small></div></div>' +
    (s.notice > 0 ? '<div class="note bad"><b>Leaving in ' + s.notice + (s.notice > 1 ? ' weeks' : ' week') + '.</b> A decent raise may make them stay.</div>' : '') + '<div class="kv"><span>Performance</span><b>' + band(sk) + '</b></div>' + bar(sk, sk > 65 ? 'var(--green)' : sk < 35 ? 'var(--red)' : 'var(--blue)') + workRows(s) + lastWeek(s) + energyBlock(s) +
    onbBlock(co, s) + payBlock(co, s) + verBlock(co, s) + (s.nr > 0 ? '<p class="muted small">New in role. Performance is lower for a few weeks.</p>' : '') + (s.flag ? '<div class="note bad"><b>PROBLEM:</b> ' + esc(n.name) + ' ' + FLAGN[s.flag] + '.</div>' : '') + (gap > 0.1 ? '<p class="muted small" style="color:var(--amber)">Underpaid compared to the market. May leave.</p>' : '') +
    '<div class="btnrow">' + btn('Profile', 'go', { n: 'staffman', p: { id: co.id, s: s.id } }, 'chip primary') + btn('Raise', 'raisesheet', { id: co.id, s: s.id }, 'chip') + btn('Promote', 'promosheet', { id: co.id, s: s.id }, 'chip') + btn('Course', 'coursesheet', { id: co.id, s: s.id }, 'chip') + (s.flag ? btn('Talk to them', 'talkstaff', { id: co.id, s: s.id }, 'chip primary') : '') + btn('Dismiss', 'firestaff', { id: co.id, s: s.id }, 'chip ghost danger') + '</div></div>';
  }
  const RATES = [0.01, 0.02, 0.03, 0.05, 0.08, 0.12];
  function payBlock(co, s) {
    if (!SALES_ROLES[s.role]) return '';
    const pm = s.pay || { m: 'fix', rate: 0 };
    return '<h3 class="gap">Pay model</h3>' + chips(Object.keys(PAY_M).map(k => [k, PAY_M[k]]), pm.m, 'setpay', { id: co.id, s: s.id }) + (pm.m !== 'fix' ? '<div class="kv"><span>Commission on their sales</span><b>' + pc(pm.rate, 1) + '</b></div>' + chips(RATES.map(r => [r, pc(r, 0)]), pm.rate, 'setrate', { id: co.id, s: s.id }) : '') + '<div class="kv"><span>Fixed + average bonus</span><b>' + money(s.wage) + (pm.m !== 'fix' ? ' + ' + money(Math.round((s.commEma || 0) * 52 / 12)) : '') + '</b></div><p class="muted small">' + ({
      fix: 'Steady, but no extra push to sell.',
      mix: 'Lower salary plus commission. Sellers push harder.',
      com: 'No salary. Sellers push hardest, but may cut corners and quit in slow months.'
    })[pm.m] + '</p>';
  }
  ACT.setpay = p => {
    const co = getCo(p.id), s = co.staff.find(x => x.id === p.s);
    const rate = p.v === 'fix' ? 0 : p.v === 'mix' ? 0.03 : 0.06;
    const n = S.npcs[s.id];
    const run = () => {
      if (p.v === 'com' && (n.sec || 0) > 0.65 && chance(0.6)) {
        toast(n.name + ' will not work on commission only and resigns.', true);
        fireStaff(co, s.id, 1);
      } else {
        setPay(co, s.id, p.v, rate);
        toast('Pay model changed.');
      }
      save();
      render();
    };
    if (p.v !== 'fix' && (!s.pay || s.pay.m === 'fix')) confirmThen('Change pay model?', 'Lower fixed pay can upset people who want security. Some may quit.', 'Change', run); else run();
  };
  ACT.setrate = p => {
    const co = getCo(p.id), s = co.staff.find(x => x.id === p.s);
    s.pay.rate = p.v;
    save();
    render();
  };
  function verBlock(co, s) {
    const bd = BD[co.type];
    if (!(bd.tw.ins && s.role === 'agent')) return '';
    const ks = Object.keys(INS_PRODS).filter(k => prodOn(co, k));
    if (!ks.length) return '<p class="muted small">Choose insurance products under Operations, then verify this salesperson for each.</p>';
    return '<h3 class="gap">Verified for</h3>' + ks.map(k => {
      const v = s.ver && s.ver[k];
      const st = v ? (v.done <= S.week ? '<span class="pos">Verified</span>' : 'Ready in ' + (v.done - S.week) + ' wk') : btn('Verify · ' + money(INS_PRODS[k][1].ver), 'verifyag', { id: co.id, s: s.id, k: k }, 'chip');
      return '<div class="kv"><span>' + esc(INS_PRODS[k][0]) + '</span><b>' + st + '</b></div>';
    }).join('') + '<p class="muted small">A salesperson can only sell products they are verified for.</p>';
  }
  ACT.verifyag = p => {
    const co = getCo(p.id);
    if (res(verifyAgent(co, p.s, p.k), 'Verification started.')) {
      save();
      render();
    }
  };
  function onbBlock(co, s) {
    const miss = onbMissing(s);
    if (!s.onb || !miss.length) return '';
    const all = onbItems(s.role);
    return '<div class="note bad"><b>Paperwork: ' + (all.length - miss.length) + ' of ' + all.length + ' done.</b> Missing items can be fined in an inspection.</div>' + all.map(it => '<div class="step ' + (s.onb[it[0]] ? 'done' : '') + '"><i>' + (s.onb[it[0]] ? '✓' : '') + '</i><div>' + esc(it[1]) + '</div>' + (s.onb[it[0]] ? '' : btn('Done', 'onbtick', { id: co.id, s: s.id, k: it[0] }, 'chip')) + '</div>').join('');
  }
  ACT.onbtick = p => {
    onbTick(getCo(p.id), p.s, p.k);
    save();
    render();
  };
  ACT.raisesheet = p => {
    const co = getCo(p.id), s = co.staff.find(x => x.id === p.s);
    openSheet('<h2>Raise for ' + esc(S.npcs[s.id].name) + '</h2><p class="lead">Now ' + money(s.wage) + ' per month.</p><div class="btnrow col">' + [0.03, 0.06, 0.1].map(f => btn('+' + Math.round(f * 100) + '% → ' + money(rnl(s.wage * (1 + f), 100)), 'doraise', { id: co.id, s: s.id, f: f })).join('') + '</div>' + btn('Cancel', 'sheetclose', undefined, 'ghost wide'));
  };
  ACT.doraise = p => {
    raiseStaff(getCo(p.id), p.s, p.f);
    closeSheet();
    save();
    render();
    toast('Raise given.');
  };
  ACT.talkstaff = p => {
    const co = getCo(p.id), s = co.staff.find(x => x.id === p.s);
    if (chance(0.5)) {
      s.flag = null;
      toast('The talk helped. The problem is gone.');
    } else {
      s.warn = (s.warn || 0) + 1;
      toast('It did not help. Consider dismissing.', true);
    }
    save();
    render();
  };
  ACT.coursesheet = p => {
    const co = getCo(p.id), bd = BD[co.type];
    const owner = p.s === 'owner';
    const nm = owner ? 'you' : S.npcs[p.s].name;
    openSheet('<h2>Course for ' + esc(nm) + '</h2><p class="muted small">Results are uncertain. Some courses change nothing, some help a lot, and a trained person may get poached.</p><div class="btnrow col">' + bd.crs.map(c => btn('<b>' + esc(c[1]) + '</b><br><small>' + money(c[2]) + ' · up to +' + c[4] + ' skill</small>', 'docourse', { id: co.id, s: p.s, c: c[0] })).join('') + '</div>' + btn('Cancel', 'sheetclose', undefined, 'ghost wide'));
  };
  ACT.docourse = p => {
    const co = getCo(p.id);
    const r = takeCourse(co, p.s, p.c);
    closeSheet();
    if (r === 'cash') toast('Not enough cash.', true); else {
      toast(r);
      save();
      render();
    }
  };

/* ---------- hiring ---------- */
  ACT.candopen = p => {
    ui.cand = p.n;
    render(true);
  };
  ACT.candback = () => {
    ui.cand = null;
    render(true);
  };
  ACT.candpass = p => {
    ui.passed = ui.passed || {};
    ui.passed[p.n] = 1;
    ui.cand = null;
    render(true);
  };
  ACT.hirego = p => {
    ui.hrole = null;
    go('hire', { id: p.id });
  };
  const ROLE_FX = {
    helper: 'Covers busy spells and picks up odd jobs',
    cleaner: 'Keeps premises clean, which protects reputation',
    guard: 'Fewer thefts and incidents',
    recept: 'Answers customers, fewer missed enquiries',
    sales: 'Wins more customers and orders',
    marketer: 'Steady stream of new customers',
    ittech: 'Keeps systems running, fewer outages',
    safety: 'Fewer accidents and inspection findings',
    lead: 'Runs the shift so you and the manager have to step in less',
    caretaker: 'Keeps buildings in order, slower wear',
    handy: 'Small repairs done in-house instead of paid call-outs',
    mech: 'Repairs done in-house, less downtime',
    driver: 'More deliveries and trips',
    cashier: 'Serves customers faster at the till',
    cook: 'Better and faster food',
    mktan: 'Measures this company’s market share and reports every month',
    cleaner2: ''
  };
  const ROLE_GEN = [
    'helper',
    'cleaner',
    'guard',
    'recept',
    'sales',
    'marketer',
    'ittech',
    'safety',
    'lead',
    'caretaker',
    'handy',
    'mktan'
  ];
  function moreRoles(co, bd) {
    const have = stdStaff(bd, co.size).map(s => s[0]);
    const own = (bd.std || []).map(x => x[0]);
    const base = own.concat(ROLE_GEN);
    return base.filter((r, i) => base.indexOf(r) === i && ROLES[r] && have.indexOf(r) < 0 && !(hqRoleKey && hqRoleKey(r)));
  }
  function hqRoleKey(r) {
    return r === 'hr' || r === 'analyst2' || r === 'acct' || r === 'buyer' || r === 'compl';
  }
  ACT.hrole = p => {
    if (p.v === '_more') {
      const co = getCo(p.id), bd = BD[co.type];
      openSheet('<h2>Other roles</h2><p class="muted small">HR, analysts and accountants work at your main office; these work in this company.</p><div class="roles56">' + moreRoles(co, bd).map(r => '<button data-a="hrole2" data-p="' + esc(JSON.stringify({ id: co.id, r })) + '"><b>' + esc(ROLES[r][0]) + '</b><small>' + esc(ROLE_FX[r] || '') + '</small><em>' + mshort(wageFor(r, co)) + '/mo</em></button>').join('') + '</div>' + btn('Cancel', 'sheetclose', undefined, 'ghost wide'), 'roles56s');
      return;
    }
    ui.hrole = p.v;
    render();
  };
  ACT.hrole2 = p => {
    ui.hrole = p.r;
    closeSheet();
  };
  ACT.hmode = p => {
    ui.hmode = p.v;
    render();
  };
  ACT.hsearch = p => {
    const co = getCo(p.id);
    const c = ui.hmode === 'ad' ? KC(1500) : ui.hmode === 'agency' ? KC(12000) : 0;
    if (c && !payCo(co, c, 'oth', 'Recruiting')) {
      if (co.cash < -coOverdraft(co)) {
        moveCash(co, c);
        toast('Not enough cash in the company.', true);
        return;
      }
    }
    ui.cands = ui.cands || {};
    ui.cands[co.id + ':' + ui.hrole] = searchWorkers(co, ui.hrole, ui.hmode).map(n => n.id);
    (ui.hstep = ui.hstep || {})[co.id] = 2;
    save();
    render();
  };
  ACT.paysel = p => {
    ui.pay = ui.pay || {};
    const o = ui.pay[p.n] || { m: 'fix', rate: 0.03 };
    o.m = p.v;
    o.rate = p.v === 'com' ? Math.max(o.rate, 0.05) : o.rate;
    ui.pay[p.n] = o;
    render();
  };
  ACT.payrate = p => {
    ui.pay = ui.pay || {};
    const o = ui.pay[p.n] || { m: 'fix', rate: 0.03 };
    o.rate = p.v;
    ui.pay[p.n] = o;
    render();
  };
  ACT.refcheck = p => {
    const co = getCo(p.id);
    payCo(co, KC(600), 'oth', 'Reference check');
    S.npcs[p.n].checked = 1;
    save();
    render();
  };
  ACT.trial = p => {
    const co = getCo(p.id), n = S.npcs[p.n];
    payCo(co, Math.round(n.ask / 4), 'wages', 'Trial week');
    n.trialRes = trialWeek(n);
    save();
    render();
  };
  ACT.offer = p => {
    const co = getCo(p.id), n = S.npcs[p.n];
    let w = rnl(inum('w' + n.id, n.ask), 100);
    const pm = SALES_ROLES[n.role] && ui.pay && ui.pay[n.id];
    let r;
    if (pm && pm.m !== 'fix') {
      const est = (pm.m === 'mix' ? n.ask * 0.6 : 0) + commEstimate(co) * pm.rate;
      if (pm.m === 'com' && (n.sec || 0) > 0.65) {
        toast(n.name + ' wants a fixed income and declines commission only.', true);
        return;
      }
      if (est < n.ask * 0.9) {
        toast(n.name + ' does not think that pay plan earns enough. Raise the commission.', true);
        return;
      }
      r = hireWorker(co, n, n.ask);
      if (r === 'ok') setPay(co, n.id, pm.m, pm.rate);
    }
  else r = hireWorker(co, n, w);
    if (r === 'ok') {
      toast(n.name + ' accepted. Complete the paperwork under People.');
      ui.hrole = null;
      ui.stack.length && ui.stack.pop();
      ui.view = { n: 'co', p: { id: co.id, t: 'ppl' } };
      save();
      render();
    } else if (r === 'refuse') toast(n.name + ' declined that offer. Try more.', true); else res(r);
  };

/* ---------- manager: the Manager page of the company's headquarters (ui/company/headquarters.js) ---------- */
  const AUTHL = [[0, 'Asks you'], [1, 'Within limits'], [2, 'Full control']];
  function mgrCard(co, bd) {
    const m = co.mgr ? S.npcs[co.mgr] : null;
    if (!m) return '';
    const q = mgrQual(co), P = o => esc(JSON.stringify(o));
    let h = '<div class="card"><div class="cand56">' + faceAv(m) + '<div><b>' + esc(m.name) + '</b><small>' + esc(titleFor(co, 'mgr')) + ' · age ' + m.age + ' · ' + m.exp + ' yr</small></div><div class="rt56"><b>' + mshort(co.mgrWage) + '</b><small>a month' + (co.mgrBonus > 0 ? ' + ' + Math.round(co.mgrBonus * 100) + '% of profit' : '') + '</small></div></div>' +
      '<div class="kv"><span>Overall results</span><b>' + band(q * 100) + '</b></div>' + bar(q * 100, 'var(--green)') + (m.mtype !== bd.mgr ? noteBox('Not the ideal type for ' + esc(bd.n) + '.') : '') +
      (hasHQ('perf') || co.lastRev ? '<div class="trio">' + MQ.map(x => '<div><span>' + x[1].split(' ')[0] + '</span><b>' + band(m.stats[x[0]]) + '</b></div>').join('') + '</div>' : '<small class="muted">Detailed skills show with a performance analyst or an outside review. Judge by results.</small>');
    h += '<span class="lab">Decides</span><div class="seg56">' + AUTHL.map(x => '<button class="' + ((co.auth.lvl || 0) === x[0] ? 'on' : '') + '" data-a="authlvl" data-p="' + P({ id: co.id, v: x[0] }) + '">' + x[1] + '</button>').join('') + '</div><small class="muted">' + ['Every decision and spend comes to you as a message.', 'Handles things up to the limits you set; bigger things come to you.', 'Decides everything and sends you a monthly board pack.'][co.auth.lvl || 0] + '</small>';
    if (co.auth.lvl === 1) h += '<details class="lim56"><summary class="lrow"><span class="ctext"><b>Limits</b><small>pay ' + mshort(co.auth.hire) + '/mo · buys up to ' + mshort(co.auth.buy) + ' · ads ' + mshort(co.auth.ad) + '/wk</small></span><i>›</i></summary>' +
      '<div class="kv"><span>Pay and promotions a month</span><b>' + money(co.auth.hire) + '</b></div>' + chips([0, 3000, 8000, 15000, 30000].map(niceAmt).map(v => [v, v ? mshort(v) : 'None']), co.auth.hire, 'authhire', { id: co.id }) +
      '<div class="kv"><span>Purchases</span><b>' + money(co.auth.buy) + '</b></div>' + chips([10000, 25000, 50000, 100000, 250000].map(v => [v, mshort(v)]), co.auth.buy, 'authbuy', { id: co.id }) +
      '<div class="kv"><span>Ads a week</span><b>' + money(co.auth.ad) + '</b></div>' + chips([0, 1500, 3000, 7000].map(v => [v, mshort(v)]), co.auth.ad, 'authad', { id: co.id }) + '</details>';
    h += '<div class="btnrow">' + btn('Give raise', 'mgrraise', { id: co.id }, 'chip') + btn('Move', 'mgrmove', { id: co.id }, 'chip') + btn('Replace', 'mgrfire', { id: co.id }, 'chip ghost danger') + '</div></div>';
    return h;
  }
  CT.mgrCard = mgrCard;
  /* the owner choosing a level on purpose keeps it (set22: the round 22 defaults leave it alone) */
  ACT.authlvl = p => {
    setAuth(getCo(p.id), p.v);
    getCo(p.id).auth.set22 = 1;
    save();
    render();
  };
  ACT.authbuy = p => {
    setAuth(getCo(p.id), getCo(p.id).auth.lvl, p.v);
    getCo(p.id).auth.set22 = 1;
    save();
    render();
  };
  ACT.authhire = p => {
    const c = getCo(p.id);
    setAuth(c, c.auth.lvl, null, p.v);
    c.auth.set22 = 1;
    save();
    render();
  };
  ACT.authad = p => {
    const c = getCo(p.id);
    setAuth(c, c.auth.lvl, null, null, p.v);
    c.auth.set22 = 1;
    save();
    render();
  };
  ACT.mgrraise = p => {
    const c = getCo(p.id);
    c.mgrWage = rnl(c.mgrWage * 1.08, 100);
    c.mood = Math.min(100, (c.mood != null ? c.mood : 60) + 8);
    save();
    render();
    toast('Raise given.');
  };
  ACT.mgrfire = p => {
    const c = getCo(p.id);
    confirmThen('Replace the manager?', 'You pay three months of salary as severance and run the company yourself until you hire someone new.', 'Dismiss', () => {
      fireManager(c);
      save();
      render();
    }, true);
  };
  ACT.mgrgo = p => {
    ui.mgrC = null;
    go('mgrhire', { id: p.id });
  };
  V.titles.mgrhire = 'Find a manager';
  ACT.mgrask = p => {
    const n = S.npcs[p.n];
    if ((n.qLeft == null ? 3 : n.qLeft) <= 0) return;
    interview(n, p.k);
    n.qLeft = (n.qLeft == null ? 3 : n.qLeft) - 1;
    save();
    render();
  };
  ACT.mgrref = p => {
    const co = getCo(p.id), n = S.npcs[p.n];
    payCo(co, KC(2500), 'oth', 'Reference check');
    n.ref = 1;
    save();
    render();
  };
  /* a manager weighs a profit bonus at most of what the last months' profit would pay, less for the risk */
  const bonusWorth = (co, b) => b > 0 ? Math.max(0, sum((co.hist || []).slice(-3), x => x.profit || 0) / Math.max(1, Math.min(3, (co.hist || []).length))) * b * 0.7 : 0;
  window.bonusWorth = bonusWorth;
  ACT.mgrhirego = p => {
    const co = getCo(p.id), n = S.npcs[p.n];
    const w = rnl(inum('m' + n.id, n.ask), 500), b = (ui.mb56 && ui.mb56[n.id]) || 0;
    const r = hireManager(co, n, w + bonusWorth(co, b));
    if (r === 'ok') {
      co.mgrWage = w;
      co.mgrBonus = b;
      toast(n.name + ' is now manager of ' + co.name + '.');
      /* back to where the search started: the company's headquarters (Staff › Management, or its own screen) */
      if (window.HQ56) HQ56.open(co, 'mgr');
      save();
      ACT.back();
    } else if (r === 'refuse') toast('They declined. Offer more.', true); else res(r);
  };
})();


/* ---- ui/screens/club.js ---- */
(function () {
  'use strict';
  const U = window.UI, { svg, ui, V, ACT, esc, row, btn, card, sec, noteBox, badge, chips, go, openSheet, closeSheet, confirmThen, toast, res, render, save } = U;
  const CT = window.CT;
  V.titles = V.titles || {};
  const nok = U.nok;
/* ---------- entry: a card at the bottom of New business ---------- */
  window.sportEntry = function () {
    return '<button class="contact" data-a="go" data-p="' + esc(JSON.stringify({ n: 'clubs', p: {} })) + '"><span class="cic" style="background:var(--surface2)">' + svg('fire') + '</span><span class="ctext"><b>Football club</b><small>Buy a club in the top league of a country, or found a new one.</small></span><span class="badge">Large capital</span></button>';
  };
  V.titles.clubs = 'Football clubs';
  V.clubs = function () {
    ui.clc = ui.clc && LEAGUES[ui.clc] ? ui.clc : (LEAGUES[S.country] ? S.country : Object.keys(LEAGUES)[0]);
    const k = ui.clc;
    const L = LEAGUES[k];
    const cl = clubsOf(k);
    let h = card('<h3>League</h3>' + chips(Object.keys(LEAGUES).map(x => [x, CO[x].flag + ' ' + CO[x].name]), k, 'clcset', {}) + '<p class="muted small">' + esc(L[0]) + ' · ' + L[1] + ' clubs. Values are rough market estimates. Many owners will not sell at any price, and a few clubs are never for sale.</p>');
    h += '<div class="card"><h3>Clubs' + (window.PRO ? PRO.tag('clubs') : '') + '</h3>' + cl.map(c => '<div class="opt"><div class="bhead"><div><b>' + esc(c.name) + '</b>' + (c.owner === 'you' ? ' <span class="badge">Yours</span>' : c.listed ? ' <span class="badge">Open to offers</span>' : '') + '<small>About ' + money(c.val) + '</small></div><div class="rt">' + (c.owner === 'you' ? '' : btn('Make an offer', 'clubbuy', { c: c.id, k }, 'chip primary')) + '</div></div></div>').join('') + '</div>';
    const val = Math.round(L[2][0] * 10.5 * 1e6 * 0.5 / 100000) * 100000;
    h += card('<h3>Found a new club</h3><p class="muted small">Start a club in the second tier. It costs about ' + money(val * 0.4) + ' and must earn promotion to the top league (finish in the top three).</p>' + btn('Found a club in ' + esc(CO[k].name) + (window.PRO ? PRO.tag('clubs') : ''), 'clubfound', { k }, 'wide'));
    return h;
  };
  ACT.clcset = p => {
    ui.clc = p.v;
    render();
  };
  ACT.clubbuy = p => {
    const c = clubsOf(p.k).find(x => x.id === p.c);
    openSheet('<h2>Offer for ' + esc(c.name) + '</h2><p class="muted small">Rough value ' + money(c.val) + '. A bad offer can end the talks for a year.</p>' + [0.9, 1.2, 1.8, 3].map(f => '<button class="opt" data-a="clubofferx" data-p="' + esc(JSON.stringify({ c: c.id, k: p.k, f })) + '"><b>' + money(Math.round(c.val * f / 100000) * 100000) + '</b><small>' + Math.round(f * 100) + '% of value</small></button>').join('') + btn('Cancel', 'sheetclose', undefined, 'ghost wide'));
  };
  ACT.clubofferx = p => {
    const c = clubsOf(p.k).find(x => x.id === p.c);
    const x = proposeClub(c, p.f);
    save();
    openSheet('<h2>' + esc(c.name) + '</h2><div class="note ' + (x.r === 'accept' ? 'good' : x.r === 'counter' ? '' : 'bad') + '">' + esc(x.msg) + '</div>' + (x.price ? btn(x.r === 'accept' ? 'Buy for ' + money(x.price) : 'Accept ' + money(x.price), 'clubclose', { c: c.id, k: p.k, price: x.price }, 'primary wide') : '') + btn('Close', 'sheetclose', undefined, 'ghost wide'));
  };
  ACT.clubclose = p => {
    const c = clubsOf(p.k).find(x => x.id === p.c);
    const r = buyClub(c, p.price);
    if (typeof r === 'string') {
      res(r);
      return;
    }
    closeSheet();
    save();
    ui.stack = [];
    ui.tab = 'cos';
    ui.view = { n: 'co', p: { id: r.id, t: 'ov' } };
    render(true);
    toast('You now own ' + r.name + '.');
  };
  ACT.clubfound = p => confirmThen('Found a new club?', 'You pay about 40% of its starting value and fund the early seasons yourself.', 'Found it', () => {
    const r = foundClub(p.k);
    if (typeof r === 'string') {
      res(r);
      return;
    }
    save();
    ui.stack = [];
    ui.tab = 'cos';
    ui.view = { n: 'co', p: { id: r.id, t: 'ov' } };
    render(true);
  });
/* ---------- company tabs for a club ---------- */
  const lbl = r => r === 'W' ? '<span class="pos">W</span>' : r === 'L' ? '<span class="neg">L</span>' : '<span class="muted">D</span>';
  function seasonCard(co) {
    const fm = co.fm, lg = leagueOf(co.country), L = LEAGUES[co.country];
    const rank = tableRank(lg, fm.club), N = lg.t.length;
    const me = lg.t.find(x => x.id === fm.club) || { pts: 0, gp: 0 };
    return card('<h3>' + esc(L[0]) + ' · season ' + lg.season + '</h3>' + row('Division', fm.div === 1 ? 'Top flight' : 'Second tier') + row('Position', rank + ' of ' + N) + row('Points', me.pts + ' from ' + me.gp + ' games') + row('Squad strength', qualWord(fm.s)) + row('Recent form', fm.last.length ? fm.last.slice(-8).map(lbl).join(' ') : 'Season not started') + row('Titles', fm.titles) + row('Club value', nok(fm.val)) + '<p class="muted small">The manager picks and sells the players. You set the budget, sponsors and prices.</p>');
  }
  function budgetCard(co) {
    const fm = co.fm;
    const R = fm.R || clubRev(clubOf(co), fm);
    return '<div class="card"><h3>Budget</h3><div class="kv"><span>Player wages, share of revenue</span><b></b></div>' + chips([[0.55, '55%'], [0.65, '65%'], [0.8, '80%']], fm.wage, 'clubwage', { id: co.id }) + '<div class="kv"><span>Ticket prices</span><b></b></div>' + chips([[-1, 'Low'], [0, 'Normal'], [1, 'High']], fm.tix, 'clubtix', { id: co.id }) + row('Yearly revenue (about)', nok(R)) + row('Wage bill per week', nok(fm.wage * R / 52)) + '<p class="muted small">A bigger wage budget buys a stronger squad, but eats the profit. Cheaper tickets fill the stadium and build the fan base.</p></div>';
  }
  CT.clubSp = function (co) {
    const fm = co.fm;
    let h = '<div class="card"><h3>Sponsors</h3>';
    Object.keys(SP_SLOTS).forEach(k => {
      const cur = fm.sp[k];
      h += '<div class="opt"><b>' + esc(SP_SLOTS[k][0]) + '</b>' + (cur && cur.until > S.week ? '<small>' + esc(cur.name) + ' · ' + money(cur.wk) + ' per week · ' + Math.ceil((cur.until - S.week) / 52 * 10) / 10 + ' years left</small>' : (fm.offers[k] || []).length ? (fm.offers[k] || []).map(o => '<div class="bhead"><div><small>' + esc(o.name) + ' · ' + money(o.wk) + '/wk · ' + o.yrs + ' yr</small></div>' + btn('Sign', 'clubspon', { id: co.id, k, o: o.id }, 'chip') + '</div>').join('') : '<small>No offers right now.</small>') + '</div>';
    });
    return h + '</div>';
  };
  ACT.clubwage = p => {
    getCo(p.id).fm.wage = +p.v;
    save();
    render();
  };
  ACT.clubtix = p => {
    getCo(p.id).fm.tix = +p.v;
    save();
    render();
  };
  ACT.clubspon = p => {
    if (res(takeSponsor(getCo(p.id), p.k, +p.o), 'Sponsor signed.')) {
      save();
      render();
    }
  };
  CT.clubPeople = function (co) {
    const fm = co.fm;
    const person = (c, kind, title) => '<div class="opt"><div class="bhead"><div><b>' + title + '</b>' + (c ? '<small>' + esc(c.name) + (c.interim ? ' (interim)' : '') + ' · quality ' + (c.skill >= 80 ? 'Outstanding' : c.skill >= 65 ? 'Strong' : c.skill >= 45 ? 'Capable' : 'Developing') + ' · ' + money(c.wage) + '/wk</small>' : '<small>Vacant</small>') + '</div><div class="rt">' + (c ? btn('Dismiss', 'clubfire', { id: co.id, k: kind }, 'chip ghost danger') : '') + btn(c ? 'Replace' : 'Find one', 'clubfind', { id: co.id, k: kind }, 'chip primary') + '</div></div></div>';
    return '<div class="card"><h3>Football staff</h3><p class="muted small">You do not pick players. The manager does that. Every club needs a manager and an assistant. If the manager is sacked, the assistant steps in until you hire a new one.</p>' + person(fm.coach, 'coach', 'Manager') + person(fm.asst, 'asst', 'Assistant manager') + '</div>';
  };
  ACT.clubfire = p => {
    const co = getCo(p.id);
    confirmThen('Dismiss?', 'The club pays no compensation, but results may suffer.', 'Dismiss', () => {
      if (p.k === 'coach') clubSack(co, 'your decision'); else co.fm.asst = null;
      save();
      render();
    }, true);
  };
  ACT.clubfind = p => {
    const co = getCo(p.id);
    ui.clcands = clubCands(co, p.k);
    openSheet('<h2>' + (p.k === 'coach' ? 'Manager' : 'Assistant') + ' candidates</h2>' + ui.clcands.map((c, i) => '<div class="opt"><div class="bhead"><div><b>' + esc(c.name) + '</b><small>Age ' + c.age + ' · ' + (c.skill >= 80 ? 'Outstanding' : c.skill >= 65 ? 'Strong' : c.skill >= 45 ? 'Capable' : 'Developing') + ' · asks ' + money(c.wage) + '/wk</small></div>' + btn('Hire', 'clubhire', { id: co.id, k: p.k, i }, 'chip primary') + '</div></div>').join('') + btn('Cancel', 'sheetclose', undefined, 'ghost wide'));
  };
  ACT.clubhire = p => {
    const co = getCo(p.id);
    const c = ui.clcands[p.i];
    hireCoach(co, c, p.k);
    closeSheet();
    save();
    render();
    toast(c.name + ' hired.');
  };
  CT.clubTable = function (co) {
    const lg = leagueOf(co.country);
    const t = lg.t.slice().sort((a, b) => b.pts - a.pts || b.s - a.s);
    const cl = clubsOf(co.country);
    return '<div class="card"><h3>Table</h3>' + t.slice(0, 20).map((r, i) => {
      const c = cl.find(x => x.id === r.id);
      return '<div class="kv"><span>' + (i + 1) + '. ' + esc(c ? c.name : r.id) + (r.id === co.fm.club ? ' (you)' : '') + '</span><b>' + r.pts + '</b></div>';
    }).join('') + '</div>';
  };
  /* a football club has its own overview, people, ground and history tabs */
  CT.ov = pipeView('CT.ov', CT.ov, 2);
  addStep('CT.ov.route', 10, 'football clubs: season, budget and squad', (co, bd) => bd.fam === 'club' ? seasonCard(co) + budgetCard(co) + CT.clubSp(co) : undefined);
  CT.ppl = pipeView('CT.ppl', CT.ppl, 2);
  addStep('CT.ppl.route', 10, 'football clubs: the people of the club', (co, bd) => bd.fam === 'club' ? CT.clubPeople(co) : undefined);
  CT.eq = pipeView('CT.eq', CT.eq, 2);
  addStep('CT.eq.route', 10, 'football clubs: the ground', (co, bd) => bd.fam === 'club' ? card('<h3>Stadium and training ground</h3><p class="muted small">The club owns its ground and training facilities. Running costs are in the budget.</p>') : undefined);
  CT.ana = pipeView('CT.ana', CT.ana, 2);
  addStep('CT.ana.route', 10, 'football clubs: past seasons', (co, bd) => bd.fam === 'club' ? card('<h3>Past seasons</h3>' + (co.fm.hist.length ? co.fm.hist.map(h => row('Season ' + h.season, 'Position ' + h.rank + (h.div === 2 ? ' (second tier)' : ''))).join('') : '<p class="muted small">No finished season yet.</p>')) : undefined);
})();


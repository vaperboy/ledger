/* ---- ui/screens/group_tab.js ---- */
/* ===== The Group tab, round 56: three pages, each with one job.
   - You: you as a person. Your ambition and next goal, the deal of the week, how people see you, who you know,
     trophies and awards, giving back.
   - Group: what you own and how it is run. The organisation (features/company/org_chart.js ORG56.groupCard), the
     deals that come to you, holding companies and franchises, boards, manager reviews, group suppliers, the
     market and maps, then each company's management (ui/screens/group.js V.group).
   - Main office: one office from the kitchen table up, and the people who work for the whole group, your personal
     assistant (your right hand) first (ui/screens/group.js V.office).
   Franchises (V.fr56) has both sides: the brands you franchise out, and brands you can join. ===== */
(function () {
  'use strict';
  const U = window.UI, { ui, V, ACT, esc, svg, btn, render } = U;
  const R35 = window.R35 = window.R35 || {};
  const P = o => esc(JSON.stringify(o));
  const live = () => S.cos.filter(c => c.st !== 'sold' && c.st !== 'bust');
  const row = (p, ic, title, sub, right) => '<button class="lrow" data-a="go" data-p="' + P(p) + '"><span class="lic">' + svg(ic, 20) + '</span><span class="ctext"><b>' + title + '</b>' + (sub ? '<small>' + esc(sub) + '</small>' : '') + '</span>' + (right || '<i>›</i>') + '</button>';
  const rows = L => { L = L.filter(Boolean); return L.length ? '<div class="lrows">' + L.join('') + '</div>' : ''; };
  const sec = t => '<h2 class="sec">' + t + '</h2>';
  const sub = n => { try { const x = V.heads && V.heads[n] ? V.heads[n]() : null; return x && x.sub ? String(x.sub).replace(/<[^>]+>/g, '') : ''; } catch (e) { return ''; } };
  const hasMgr = () => live().some(c => c.mgr && S.npcs[c.mgr]);
  R35.hasMgr = hasMgr;

  /* ---------- You ---------- */
  const on = k => !window.SEEN57 || SEEN57.on(k); /* parts appear once they matter (features/screens/show_when_used.js) */
  function youPage() {
    /* the next goal opens your ambition, so it is the ambition row (with no companies yet there is no goal: the row) */
    const goal = window.GA56 && GA56.goalRow ? GA56.goalRow() : '';
    const deal = window.GA56 && GA56.dealRow ? GA56.dealRow() || '' : '';
    let h = goal + (goal ? '' : rows([V.amb27 && row({ n: 'amb27' }, 'star', 'Ambition', sub('amb27') || 'Choose what you want to build')]));
    if (deal) h += '<div class="lrows">' + deal + '</div>';
    if (on('people')) h += sec('How people see you') + rows([
      V.img31 && row({ n: 'img31' }, 'star', 'Public image', window.R31 && R31.imageSub ? R31.imageSub() : ''),
      V.net31 && row({ n: 'net31', p: {} }, 'people', 'People you know', window.R31 && R31.netSub ? R31.netSub() : '')
    ]);
    const rec = rows([
      V.trophies28 && on('trophies') && row({ n: 'trophies28' }, 'star', 'Trophies', sub('trophies28') || 'Your firsts'),
      V.awards56 && on('awards') && row({ n: 'awards56' }, 'star', 'Business awards', S.aw56 && S.aw56.won.length ? S.aw56.won.length + ' won' : 'Held every year end'),
      V.give28 && on('give') && row({ n: 'give28' }, 'house', 'Giving back', sub('give28') || 'What your money can do for others')
    ]);
    if (rec) h += sec('Recognition') + rec;
    if (!h) h = '<div class="calm">Start your first company: your goals, your public image and the people you meet show up here.</div>';
    return h;
  }

  /* ---------- Group ---------- */
  const frBrands = () => live().filter(c => c.fr && c.fr.on);
  function groupPage() {
    let h = window.ORG56 && ORG56.groupCard ? ORG56.groupCard() : '';
    const hs = live().filter(c => c.type === 'hold' && c.st === 'open'), under = live().filter(c => c.hold).length;
    const fb = frBrands(), units = fb.reduce((t, c) => t + c.fr.units.length, 0), apps = fb.reduce((t, c) => t + c.fr.app.length, 0);
    const joinN = window.fbAll ? (() => { try { return fbAll().length; } catch (e) { return 0; } })() : 0;
    if (!on('cos1')) return h + '<div class="calm">Your group starts with your first company: how it is run, the market and each company’s headquarters show up here.</div>';
    h += sec('What you own') + rows([
      on('hold') && row({ n: hs.length ? 'holdings' : 'newhold' }, 'bank', 'Holding companies', hs.length ? hs.length + (hs.length > 1 ? ' holding companies' : ' holding company') + ' · ' + under + ' companies under them' : 'Own your companies through one, pay less tax on dividends'),
      row({ n: 'fr56' }, 'biz', 'Franchises', fb.length ? fb.length + (fb.length > 1 ? ' brands' : ' brand') + ' · ' + units + ' units' + (apps ? ' · ' + apps + ' waiting' : '') : joinN ? joinN + ' brands take franchisees' : 'Franchise your own concept, or join a brand', apps ? '<span class="pill amb">' + apps + '</span>' : '')
    ]);
    const nCr = window.crisisCount ? window.crisisCount() : 0, bi = window.R12 && R12.boardsInfo ? R12.boardsInfo() : null;
    h += sec('How it is run') + rows([
      nCr && V.crisis && row({ n: 'crisis' }, 'alert', 'Crisis centre', nCr + ' open', '<span class="pill red">' + nCr + '</span>'),
      V.boards12 && window.R12 && R12.anyBoard && R12.anyBoard() && row({ n: 'boards12', p: {} }, 'people', 'Boards', bi ? bi.sub : 'Seats, meetings, your right hand', bi && bi.nE ? '<span class="pill red">' + bi.nE + ' emergency</span>' : ''),
      V.managers && hasMgr() && row({ n: 'managers' }, 'people', 'Manager reviews', 'Scorecards and reviews for every manager'),
      V.suppliers && row({ n: 'suppliers' }, 'truck', 'Group suppliers', 'Deals that every company buys through')
    ]);
    h += sec('The market') + rows([
      V.mkt36 && row({ n: 'mkt36' }, 'fire', 'Market', 'Your share, your rivals, the economy'),
      V.map31 && row({ n: 'map31', p: {} }, 'chart', 'Maps', 'Ownership, presence, influence')
    ]);
    /* the deals that come to you, each company's management, anyone hired for the whole group earlier */
    return h + sec('Management') + (V.group ? V.group() : '');
  }

  /* ---------- Franchises: your brands, and brands you can join ---------- */
  V.titles.fr56 = 'Franchises';
  V.fr56 = function () {
    const fb = frBrands(), grow = c => ({ n: 'co', p: { id: c.id, t: 'deal', s: 'grow' } });
    let h = sec('Your brands');
    h += rows(fb.map(c => { const f = c.fr; return row(grow(c), 'biz', esc(c.name), f.units.length + (f.units.length === 1 ? ' unit' : ' units') + ' · ' + mshort(f.income || 0) + ' last week' + (f.app.length ? ' · ' + f.app.length + (f.app.length > 1 ? ' applicants waiting' : ' applicant waiting') : ''), f.app.length ? '<span class="pill amb">' + f.app.length + '</span>' : ''); }))
      || '<div class="calm">You do not franchise a concept yet. Others pay you a fee and royalties to open units under your name.</div>';
    /* franchising is a step for a registered chain (ui/company/deals.js): the chains that could, and how to get there */
    const can = live().filter(c => c.type !== 'hold' && !(c.fr && c.fr.on) && typeof canFranchise === 'function' && canFranchise(c.type));
    const seen = {}, chains = can.filter(c => { const ch = window.R12 && R12.chainOf ? R12.chainOf(c) : null; if (!ch || seen[ch.id]) return false; seen[ch.id] = 1; return true; });
    if (chains.length) h += rows(chains.map(c => row(grow(c), 'plus', 'Franchise ' + esc(R12.chainOf(c).name), 'Set the fee, the royalty and your help with the setup')));
    else if (can.length) h += '<div class="calm">Register a chain first (a company › Manage › Expand): franchising is the step after a chain.</div>';
    h += sec('Join a brand') + '<div class="frjoin56">' + (V.franchises ? V.franchises() : '<div class="calm">No brand is looking for franchisees right now.</div>') + '</div>';
    return h;
  };

  /* ---------- the tab ---------- */
  const PAGES = [['you', 'You'], ['grp', 'Group'], ['office', 'Main office']];
  /* old links: Structure, managers, suppliers and the deal room open Group; the office opens Main office */
  const OLD = { group: 'grp', managers: 'grp', suppliers: 'grp', dealroom: 'grp', deals: 'grp', office: 'office' };
  V.titles.hq = 'Group';
  V.titles.managers = 'Manager reviews';
  V.titles.suppliers = 'Group suppliers';
  V.hq = function (p) {
    let t = (p && p.t) || ui.hqt || 'you';
    const old = OLD[t] ? t : null;
    if (old) t = OLD[t];
    if (!PAGES.find(x => x[0] === t)) t = 'you';
    ui.hqt = t;
    const root = ui.tab === 'hq' && !ui.stack.length, nCr = window.crisisCount ? window.crisisCount() : 0;
    const body = (old === 'managers' || old === 'suppliers' || old === 'dealroom') && V[old] ? V[old]() : t === 'grp' ? groupPage() : t === 'office' ? (V.office ? V.office() : '') : youPage();
    return (root ? '<header class="hh"><h1>Group</h1>' + (nCr ? '<button class="pill red" data-a="go" data-p="' + P({ n: 'crisis' }) + '">Crisis · ' + nCr + '</button>' : '') + '</header>' : '') +
      '<div class="ptabs">' + PAGES.map(x => '<button class="' + (t === x[0] ? 'on' : '') + '" data-a="hqtab" data-p="' + x[0] + '">' + x[1] + '</button>').join('') + '</div><div class="fill">' + body + '</div>';
  };
  ACT.hqtab = p => {
    const v = typeof p === 'string' ? p : p && p.v;
    ui.hqt = OLD[v] || v;
    ui.view = { n: 'hq', p: { t: ui.hqt } };
    render(true);
  };
})();

/* ---- ui/screens/group.js ---- */
(function () {
  'use strict';
  const U = window.UI, { ui, V, ACT, esc, nok, tone, sgn, svg, bar, row, btn, card, sec, noteBox, badge, contact, seg, chips, inp, inum, quick, stepper, tabsRow, spark, lineChart, go, tabTo, setView, openSheet, closeSheet, confirmThen, toast, res, render, save } = U;
/* ---------- group structure ---------- */
  V.titles.group = 'Structure';
  /* the limits snap to the round amounts the chips offer */
  const snap = (v, list) => list.reduce((b, x) => Math.abs(Math.log((x || 1) / (v || 1))) < Math.abs(Math.log((b || 1) / (v || 1))) ? x : b, list[0]);
  V.group = function () {
    const G = S.group;
    if (G) {
      G.big = snap(G.big, [1000000, 5000000, 20000000, 100000000].map(niceAmt));
      if (G.ceo) G.ceo.buy = snap(G.ceo.buy, [100000, 500000, 2000000, 10000000].map(niceAmt));
      (G.regional || []).forEach(r => { r.buy = snap(r.buy, [50000, 250000, 1000000].map(niceAmt)); });
    }
    const cos = liveCos().filter(c => c.st !== 'sold');
    /* the one limit for the whole group: bigger deals always come to you */
    let h = '<div class="card dec37"><div class="bhead"><b>Deals that come to you</b><small>above ' + esc(mshort(G.big)) + '</small></div>' + chips([1000000, 5000000, 20000000, 100000000].map(niceAmt).map(v => [v, mshort(v)]), G.big, 'setbig') + '<span class="tipt">Each company decides within what you give its manager and its management team.</span></div>';
    /* each company's headquarters on its own screen (ui/company/headquarters.js V.mgmt56) */
    h += sec('Headquarters by company');
    if (!cos.length) h += card('<p class="muted small">No companies yet.</p>');
    else h += '<div class="lrows">' + cos.map(c => {
      const m = c.mgr ? S.npcs[c.mgr] : null, t = window.TEAM56 ? TEAM56.summary(c) : '';
      return '<button class="lrow" data-a="go" data-p="' + esc(JSON.stringify({ n: 'mgmt56', p: { id: c.id } })) + '">' + (m && window.faceAv ? faceAv(m) : '<span class="av">' + esc(String(c.name).slice(0, 2).toUpperCase()) + '</span>') + '<span class="ctext"><b>' + esc(c.name) + '</b><small>' + (m ? esc(m.name) + ' · ' + ['asks first', 'within limits', 'full control'][c.auth.lvl] : 'No manager. You run it.') + (t ? ' · ' + esc(t) : '') + '</small></span><i>›</i></button>';
    }).join('') + '</div>';
    /* a group CEO or a group-wide regional manager hired before round 56 keeps working until let go */
    const old = G.regional.filter(r => !r.payCo && S.npcs[r.npc]);
    if ((G.ceo && S.npcs[G.ceo.npc]) || old.length) {
      h += sec('Hired for the whole group earlier');
      if (G.ceo && S.npcs[G.ceo.npc]) {
        const n = S.npcs[G.ceo.npc];
        h += card('<div class="bhead"><div><h3>' + esc(n.name) + '</h3><small>' + esc(titleFor(null, 'ceo')) + '</small></div><div class="rt"><b>' + money(G.ceo.wage) + '</b><small>per month</small></div></div>' + chips([[0, 'Ask me first'], [1, 'Within limits'], [2, 'Full control']], G.ceo.lvl, 'ceolvl') + (G.ceo.lvl === 1 ? '<div class="kv"><span>Spending limit</span><b>' + money(G.ceo.buy) + '</b></div>' + chips([100000, 500000, 2000000, 10000000].map(niceAmt).map(v => [v, mshort(v)]), G.ceo.buy, 'ceobuy') : '') + btn('Dismiss CEO', 'fireceo', undefined, 'chip ghost danger'));
      }
      old.forEach(r => {
        const n = S.npcs[r.npc], under = cos.filter(c => c.region === r.id);
        h += card('<div class="bhead"><div><h3>' + esc(n.name) + '</h3><small>' + esc(titleFor({ country: S.country }, 'region')) + ' · ' + (r.scope === 'all' ? 'All companies' : esc(r.scope)) + ' · ' + under.length + ' companies</small></div><div class="rt"><b>' + money(r.wage) + '</b><small>per month</small></div></div>' + chips([[0, 'Ask me first'], [1, 'Within limits'], [2, 'Full control']], r.lvl, 'reglvl', { id: r.id }) + (r.lvl === 1 ? chips([50000, 250000, 1000000].map(niceAmt).map(v => [v, mshort(v)]), r.buy, 'regbuy', { id: r.id }) : '') + btn('Dismiss', 'fireregional', { id: r.id }, 'chip ghost danger'));
      });
    }
    return h;
  };
  V.titles.suppliers = 'Suppliers';
  V.suppliers = function () {
    let h = hasHQ('proc') ? card('<h3>Procurement manager</h3><p class="muted small">Your procurement manager finds the best offer for every company and keeps supplier relationships warm.</p>') : '';
    {
      const al = S.agree || {}, vs = knownVendors().map(v => [v.id, v.name + ' · ' + relWord(vrel(v.id))]);
      const sc = [['goods', 'Goods and imports'], ['eq', 'Equipment'], ['fix', 'Repairs and service']];
      h += '<div class="card"><h3>Board agreement</h3><p class="muted small">Call the whole board together, tell them you struck a deal with one supplier, and every company buys through them. ' + (liveCos().length < 2 ? 'Needs at least two companies.' : 'Costs a meeting and dinner. Framework deals give an extra 3% off.') + '</p>' + (liveCos().length >= 2 ? sc.map(x => '<div class="kv"><span>' + x[1] + '</span><b>' + (al[x[0]] ? esc(vendById(al[x[0]]).name) : 'No agreement') + '</b></div>' + chips([[0, 'None']].concat(vs), al[x[0]] || 0, 'boarddeal', { s: x[0] })).join('') : '') + '</div>';
      const known = knownVendors().filter(v => vrel(v.id) > 0.5 || (S.vr && S.vr[v.id])).sort((a, b) => vrel(b.id) - vrel(a.id));
      h += '<div class="card"><h3>People you buy from</h3>' + (known.length ? known.map(v => '<div class="opt"><div class="bhead"><div><b>' + esc(v.name) + '</b><small>' + esc(v.owner) + ' · ' + relWord(vrel(v.id)) + (relDisc(vrel(v.id)) ? ' · ' + Math.round(relDisc(vrel(v.id)) * 100) + '% off' : ' · same price as everyone') + '</small></div><div class="rt">' + btn('Lunch', 'vmeet', { v: v.id }, 'chip') + '</div></div></div>').join('') : '<p class="muted small">Buy from a supplier and you start to know them. The better you know each other, the better the price.</p>') + '</div>';
    }
    return h;
  };
  ACT.setbig = p => {
    S.group.big = p.v;
    save();
    render();
  };
  ACT.ceolvl = p => {
    S.group.ceo.lvl = p.v;
    save();
    render();
  };
  ACT.ceobuy = p => {
    S.group.ceo.buy = p.v;
    save();
    render();
  };
  ACT.reglvl = p => {
    S.group.regional.find(x => x.id === p.id).lvl = p.v;
    save();
    render();
  };
  ACT.regbuy = p => {
    S.group.regional.find(x => x.id === p.id).buy = p.v;
    save();
    render();
  };
  ACT.fireceo = () => confirmThen('Dismiss the CEO?', 'Decisions come back to you or the regional managers.', 'Dismiss', () => {
    fireExec('ceo');
    save();
    render();
  }, true);
  ACT.fireregional = p => confirmThen('Dismiss this regional manager?', 'Their companies report to the CEO or to you.', 'Dismiss', () => {
    fireExec('region', p.id);
    save();
    render();
  }, true);
/* ---------- your main office ---------- */
  V.titles.office = 'Main office';
  /* Group › Main office: one place from the kitchen table up (engine/management/office.js OFFICE_T). The office you
     rent (tap it to move), its floor plan, and the people who work for the whole group. Your personal assistant is
     your right hand on every board (features/company/shelf_stock_chains_boards.js); hiring is a step screen
     (ui/screens/hiring.js V.hqhire). How reports reach you is in Settings › Reports and timing. */
  const OPHOTO = { cow: 'pictures/offices/of2-office-rooms.webp', small: 'pictures/offices/of3-brick-office.webp', floor: 'pictures/offices/of4-office-building.webp', hq: 'pictures/offices/of5-headquarters.webp' };
  V.office = function () {
    const o = S.office, P = x => esc(JSON.stringify(x)), pillp = t => '<span class="pill">' + t + '</span>';
    if (!o) return '<button class="card opt2" data-a="officepop"><div class="cchd">' + pic('house', 'none') + '<span class="ctext"><b>Main office</b><small>You work from your phone and kitchen table. Choose where your main office is.</small></span></div><span class="chg">Tap to choose ›</span></button>';
    const t = officeTier(), idx = OFFICE_T.findIndex(x => x.id === t.id), nx = OFFICE_T[idx + 1], city = o.city || S.player.city;
    const used = deskUse(), desks = staffDesks(t);
    let h = '<button class="card opt2" data-a="officepop"><div class="cchd">' + picPhoto(t.id === 'home' ? 'house' : 'building', t.id + ':' + o.city, OPHOTO[t.id] || '') + '<span class="ctext"><b>' + esc(t.n) + ', ' + esc(cityOf(city).name) + '</b><small>' + esc(t.note) + '</small></span>' + pillp(t.rentM ? mshort(officeRent(t, o.city)) + '/mo' : 'Free') + '</div>' + (nx ? row('Next size up', esc(nx.n) + ' · ' + mshort(officeRent(nx, city)) + '/mo · ' + nx.desks + ' desks') : '') + '<span class="chg">Tap to move ›</span></button>';
    h += '<div class="fplan"><div><span>Desks</span><b>' + used + ' of ' + desks + ' used</b></div><div><span>Meeting rooms</span><b>' + (t.rooms || 'None') + '</b></div><div><span>Your desk</span><b>' + (t.id === 'home' ? 'Kitchen table' : t.id === 'cow' ? 'Hot desk' : 'Corner office') + '</b></div><div><span>Free desks</span><b class="' + (desks - used > 0 ? 'pos' : 'amb') + '">' + Math.max(0, desks - used) + '</b></div></div>';
    const keys = hqRoleKeys().filter(k => hqUnlocked(k) || hasHQ(k)), hired = keys.filter(k => hasHQ(k)), open = keys.filter(k => !hasHQ(k));
    const title = k => k === 'pa' ? 'Personal assistant · your right hand' : hqRole(k)[0];
    h += sec('Who works here');
    h += hired.map(k => {
      const r = hqRole(k), st = o.staff.find(x => x.role === k), n = S.npcs[st.id];
      return '<div class="card"><div class="cchd">' + (n && window.faceAv ? faceAv(n) : '') + '<span class="ctext"><b>' + esc(st.name) + '</b><small>' + esc(title(k)) + ' · ' + mshort(st.wage) + '/mo' + (n ? ' · ' + skillBand(n.skill) : '') + '</small></span></div><small class="hqres"><b>Now:</b> ' + esc(hqResult(k)) + '</small>' +
        (k === 'pa' && window.R12 && R12.lhSettings ? R12.lhSettings() : '') + hqOnb(st) + '<div class="btnrow">' + ((k === 'perf' || k === 'mkt') ? btn('Open', 'go', { n: 'hqmk', p: { r: k } }, 'chip primary') : '') + btn(k === 'pa' ? 'Let go' : 'Dismiss', k === 'pa' ? 'lh12fire' : 'firehq', { id: st.id }, 'chip ghost danger') + '</div></div>';
    }).join('') || '<div class="calm">Only you so far.</div>';
    if (open.length) {
      h += sec(t.id === 'home' ? 'Room at home for one' : 'Roles you can fill') + '<div class="lrows">' + open.map(k => {
        const r = hqRole(k), why = hqRoom(k), can = why === 'ok';
        return '<button class="lrow' + (can ? '' : ' cant') + '" data-a="hirehq" data-p="' + P({ r: k }) + '"><span class="lic">' + svg(k === 'pa' ? 'star' : 'people', 20) + '</span><span class="ctext"><b>' + esc(title(k)) + '</b><small>' + esc(r[2]) + '</small></span><span class="rt56"><b>~' + mshort(rl(r[1] * fameSalary())) + '</b><small>' + (can ? 'a month' : why === 'homeoffice' ? 'needs an office' : why === 'desks' ? 'no free desk' : 'not yet') + '</small></span></button>';
      }).join('') + '</div><p class="muted small center">You are: ' + fameLabel() + '. Better people apply as you become better known, and they ask for more. More roles open as the group grows.</p>';
    }
    return h;
  };
  V.titles.hqmk = 'Team screen';
  ACT.hqas = p => {
    const st = S.office.staff.find(x => x.role === p.r); if (!st) return;
    st.cos = st.cos || [];
    const i = st.cos.indexOf(p.id); if (i >= 0) st.cos.splice(i, 1); else st.cos.push(p.id);
    save(); render();
  };
  V.hqmk = function (p) {
    const st = S.office.staff.find(x => x.role === p.r);
    if (!st) return card('<p class="muted">Not hired.</p>');
    const n = S.npcs[st.id], X = window.PLX, G = window.AGX, mk = p.r === 'mkt';
    let h = card('<h3>' + esc(st.name) + '</h3><small>' + esc(hqRole(p.r)[0]) + (n ? ' · ' + skillBand(n.skill) : '') + '</small>');
    liveCos().filter(c => c.st === 'open' && c.type !== 'hold').forEach(co => {
      const on = (st.cos || []).indexOf(co.id) >= 0;
      let b = '<div class="bhead"><div><b>' + esc(co.name) + '</b></div>' + btn(on ? 'Assigned' : 'Assign', 'hqas', { r: p.r, id: co.id }, on ? 'chip primary' : 'chip') + '</div>';
      if (on) {
        const x = reviewList('mine').find(y => y.key === 'c' + co.id), as = x && x.n >= RV_MIN ? G.ageStats(x).g : null;
        b += '<div class="ags">' + G.AGL.map((l, i) => '<div class="opt ag"><b>' + l + '</b><small>' + X.spW(X.guess(co, i)) + '</small>' + (as && as[i].n ? stars(as[i].avg) : '') + '</div>').join('') + '</div>';
        b += row('Known', awWord(co.aware)) + row('Campaigns', Object.keys(co.mkt || {}).length ? Object.keys(co.mkt).map(k => esc(CH[k].n) + ' ' + X.bW(co, k, co.mkt[k].b)).join(', ') : 'None');
        const a = mk ? X.advise(co) : null;
        if (a) b += '<div class="bhead"><small>Plan: ' + esc(CH[a.ch].n) + ' · ' + X.bW(co, a.ch, a.b) + ' · ' + G.AGL[a.ag] + '</small>' + btn('Open', 'plopen', { id: co.id, ch: a.ch, b: a.b, ag: a.ag, w: a.w }, 'chip') + '</div>';
      }
      h += card(b);
    });
    return h;
  };
  ACT.rentoffice = p => {
    const t = OFFICE_T.find(x => x.id === p.t);
    confirmThen('Rent ' + esc(t.n) + '?', (t.rentM ? 'About ' + money(officeRent(t, S.player.city)) + ' per month.' : '') + (S.office ? ' Moving costs one month of rent as a deposit.' : ''), 'Rent', () => {
      if (res(rentOffice(p.t, S.player.city), 'Done.')) {
        save();
        render();
      }
    });
  };
  function hqOnb(st) {
    const role = 'hq_' + st.role;
    const all = onbItems(role), miss = onbMissing({ role, onb: st.onb });
    if (!st.onb || !miss.length) return '';
    return '<div class="note bad"><b>Paperwork: ' + (all.length - miss.length) + ' of ' + all.length + ' done.</b> Missing items can be fined.</div><details><summary class="muted small">Show checklist</summary>' + all.map(it => '<div class="step ' + (st.onb[it[0]] ? 'done' : '') + '"><i>' + (st.onb[it[0]] ? '✓' : '') + '</i><div>' + esc(it[1]) + '</div>' + (st.onb[it[0]] ? '' : btn('Done', 'hqtick', { id: st.id, k: it[0] }, 'chip')) + '</div>').join('') + '</details>';
  }
  ACT.hqtick = p => {
    const st = S.office.staff.find(x => x.id === p.id);
    if (st) st.onb[p.k] = 1;
    save();
    render();
  };
  ACT.firehq = p => {
    fireHQ(p.id);
    save();
    render();
  };
  ACT.repset = p => {
    const o = {};
    o[p.k] = p.v;
    setReports(o);
    save();
    render();
  };

/* ---------- deal room ---------- */
  V.titles.dealroom = 'Deal room';
  V.dealroom = function () {
    const cos = liveCos().filter(c => c.st === 'open' || c.st === 'closed');
    const holds = S.cos.filter(c => c.type === 'hold' && c.st === 'open');
    let h = '<p class="muted">Sell companies, bring in investors, franchise, and structure your group.</p>';
    h += sec('Your companies', true) + (cos.filter(c => c.type !== 'hold').length ? cos.filter(c => c.type !== 'hold').map(c => '<button class="contact" data-a="go" data-p="' + esc(JSON.stringify({ n: 'co', p: { id: c.id, t: 'deal' } })) + '"><span class="ctext"><b>' + esc(c.name) + '</b><small>Value ' + mshort(companyValue(c)) + ' · you own ' + c.own.toFixed(0) + '%</small></span><i>›</i></button>').join('') : '<div class="card empty"><p class="muted">Open a business first.</p></div>');
    h += sec('Holding companies');
    h += holds.map(x => card('<h3>' + esc(x.name) + '</h3>' + row('Cash', nok(x.cash)) + row('Index fund', nok((x.fm.idxU || 0) * fundPx('idx'))) + row('Companies under it', S.cos.filter(c => c.hold === x.id && c.st !== 'sold' && c.st !== 'bust').length) + '<p class="muted small">Dividends from companies below it are taxed far lower (the exemption method). Park cash and invest through it.</p>' + inp('hamt' + x.id, 'Amount') + '<div class="btnrow">' + btn('Invest in index', 'holdin', { id: x.id }, 'chip') + btn('Sell index', 'holdout', { id: x.id }, 'chip') + btn('Put in cash', 'injhold', { id: x.id }, 'chip') + '</div>')).join('');
    h += btn('＋ Create a holding company', 'newhold', undefined, 'wide');
    h += sec('Your own service firms');
    h += card('<p class="muted small">Start your own law firm, marketing agency, insurance company or bank. Your companies use them automatically: faster permits, cheaper ads, discounted insurance, cheaper loans. The profit flows into the firm you own.</p><div class="btnrow">' + ['law', 'mktg', 'insco', 'bank', 'acctfirm'].map(id => btn(esc(BD[id].n), 'go', { n: 'newco', p: { bd: id } }, 'chip')).join('') + '</div>');
    const frs = cos.filter(c => c.fr && c.fr.on);
    if (frs.length) {
      h += sec('Franchises you run');
      h += frs.map(c => card('<h3>' + esc(c.name) + '</h3>' + row('Units', c.fr.units.length) + row('Brand', brandWord(c.fr.brand)) + row('Weekly income', nok(c.fr.income || 0)))).join('');
    }
    return h;
  };
  ACT.holdin = p => {
    const x = getCo(p.id), a = inum('hamt' + p.id, 0);
    if (a > 0 && holdInvest(x, a)) {
      save();
      render();
    } else toast('Not enough cash in the holding.', true);
  };
  ACT.holdout = p => {
    const x = getCo(p.id), a = inum('hamt' + p.id, 0);
    if (a > 0 && holdDivest(x, a)) {
      save();
      render();
    } else toast('Nothing to sell.', true);
  };
  ACT.injhold = p => {
    const x = getCo(p.id), a = inum('hamt' + p.id, 0);
    if (a > 0 && injectCash(x, a)) {
      save();
      render();
    } else toast('Not enough money.', true);
  };
  ACT.boarddeal = p => {
    const r = boardDeal(p.s, p.v ? p.v : null);
    if (r === 'few') toast('You need at least two companies.', true); else if (r === 'cash') toast('Not enough cash.', true); else {
      toast('The board agrees.');
      save();
      render();
    }
  };
  ACT.vmeet = p => {
    const r = vmeet(p.v);
    if (r === 'wait') toast('You met recently.', true); else if (r === 'cash') toast('Not enough cash.', true); else {
      toast('A good lunch.');
      save();
      render();
    }
  };

})();


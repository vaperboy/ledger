/* ---- ui/screens/mockup.js ---- */
/* Mockup layout: Home, Companies, Office, Phone, Meetings, Luxury, Start, Game over.
   Main tabs are locked to the screen; only their list area scrolls. Game numbers and actions come from the existing code. */
(function () {
  'use strict';
  const U = window.UI, { ui, V, ACT, esc, nok, sgn, svg, bar, row, btn, card, noteBox, badge, chips, inp, go, tabTo, render, save, openSheet, closeSheet, confirmThen, toast } = U;

  const ini = n => String(n || '?').replace(/[^A-Za-zÀ-ÿ0-9 ]/g, ' ').trim().split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase() || '?';
  const av = (t, cls) => '<span class="av ' + (cls || '') + '">' + esc(t) + '</span>';
  const P = o => esc(JSON.stringify(o));
  const live = () => S.cos.filter(c => c.st !== 'sold' && c.st !== 'bust');
  const plus = n => (n >= 0 ? '+' : '−') + mshort(Math.abs(n));
  const lastProfit = co => co.hist.length ? co.hist[co.hist.length - 1].profit : null;
  const badAlerts = co => coAlerts(co).filter(a => a[1] === 'bad');
  window.meetCount = function () {
    return S ? unreadBadge() : 0;
  };

/* ---------- calendar: days on top of the weekly simulation ---------- */
  const DN = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  function today() {
    return new Date(wDate(S.week).getTime() + (S.day || 0) * 86400000);
  }
  function weekOfYear(d) {
    return Math.floor((d.getTime() - Date.UTC(d.getUTCFullYear(), 0, 1)) / 86400000 / 7) + 1;
  }
  function dayStr(d) {
    return DN[(d.getUTCDay() + 6) % 7] + ' ' + d.getUTCDate() + ' ' + MN[d.getUTCMonth()] + ' ' + d.getUTCFullYear();
  }
  window.todayLabel = function () {
    const d = today();
    return 'Week ' + weekOfYear(d) + ' · ' + dayStr(d);
  };
/* ---------- daily pacing ----------
   The economy is still calculated in weekly steps (the existing simulation, unchanged). A company's week is then
   paid out over the seven days (its one-off payments on the first day), and messages and news land on random days
   of that week. Your own money is not spread: every payment the week made waits as one statement line
   (engine/money/ledger.js S.stage) and lands whole, with its line, on one day of the week. */
  function stageWeek() {
    const meB = S.cash, coB = {}, txB = {};
    S.cos.forEach(c => {
      coB[c.id] = c.cash;
      txB[c.id] = c.tx && c.tx[0];
    });
    const inB = new Set(S.inbox.map(m => m.id)), newsB = new Set(S.news);
    S.stage = [];
    let rows;
    try { advance('week'); } catch (e) { (S.stage || []).forEach(stmtLine); throw e; } finally { rows = S.stage || []; S.stage = null; }
    const rep = Object.assign({}, S.rep, { bw: {}, cos: [], meD: 0, w: S.week });
    S.cos.forEach(c => {
      if (c.st === 'sold' || c.st === 'bust') return;
      const b = c.bk.w || {};
      for (const k in b) rep.bw[k] = (rep.bw[k] || 0) + b[k];
      rep.cos.push({ id: c.id, name: c.name, rev: b.rev || 0, profit: (b.rev || 0) - sumExp(b), units: c.lastW ? c.lastW.units : 0, unit: BD[c.type].unit });
    });
    rep.meD = S.cash - meB;
    if (S.over) {
      rows.forEach(stmtLine);
      S.pend = null;
      S.lastRep = rep;
      return;
    }
    const P = { me: S.cash - meB, rows: [], co: [], msgs: [], news: [], rep };
    const R = hrng(S.seed + ':day:' + S.week);
    /* each payment of the week on its own day; anything the lines do not explain (there should be nothing) on day one */
    const left = P.me - sum(rows, x => x.a);
    if (Math.abs(left) >= 1) rows.push({ a: left, l: 'Other', co: 0 });
    const RM = hrng(S.seed + ':me:' + S.week);
    P.rows = rows.map(x => Object.assign(x, { d: Math.floor(RM() * 7) }));
    if (P.me) cashRaw(ME, -P.me);
    S.cos.forEach(c => {
      if (coB[c.id] == null) return;
      const d = c.cash - coB[c.id];
      c.wkD = d;
      if (d) {
        let one = 0;
        for (const x of (c.tx || [])) { if (x === txB[c.id]) break; if (x.a < 0) one += x.a; }
        P.co.push([c.id, d, Math.round(one)]);
        moveCash(c, -d);
      }
    });
    S.inbox = S.inbox.filter(m => {
      if (inB.has(m.id)) return true;
      P.msgs.push({ m, d: Math.floor(R() * 7) });
      return false;
    });
    S.news = S.news.filter(n => {
      if (newsB.has(n)) return true;
      P.news.push({ n, d: Math.floor(R() * 7) });
      return false;
    });
    S.pend = P;
  }
  function releaseDay(day) {
    const P = S.pend;
    if (!P) return [];
    const part = tot => Math.round(tot * (day + 1) / 7) - Math.round(tot * day / 7);
    /* a game saved mid-week before the statement existed: what was left of the week arrives today as one line */
    if (!P.rows) P.rows = P.me ? [{ a: Math.round(P.me) - Math.round(P.me * day / 7), l: 'Rest of last week', co: 0, d: day }] : [];
    P.rows.filter(x => x.d === day).forEach(x => { cashRaw(ME, x.a); stmtLine(x); });
    P.co.forEach(x => {
      const one = (x[2] || 0) + Math.min(0, x[1] - (x[2] || 0)), c = getCo(x[0]), v = part(x[1] - one) + (day === 0 ? one : 0);
      if (c && v) moveCash(c, v);
    });
    const got = [];
    P.msgs.filter(x => x.d === day).reverse().forEach(x => {
      S.inbox.unshift(x.m);
      got.push(x.m);
    });
    P.news.filter(x => x.d === day).reverse().forEach(x => S.news.unshift(x.n));
    return got;
  }
  /* one day forward; returns what arrived and, at the end of a week, the report of the week just finished */
  function dayStep() {
    if (S.day == null) S.day = 0;
    /* what arrives during the day itself (payday, daily work) counts as news of that day too */
    const top = S.inbox[0], during = () => { const i = top ? S.inbox.indexOf(top) : S.inbox.length; return S.inbox.slice(0, i < 0 ? 0 : i); };
    if (S.day < 6) {
      S.day++;
      if (window.R10DAY) window.R10DAY(S.day);
      const now = during();
      return { got: releaseDay(S.day).concat(now), done: null };
    }
    const done = S.pend ? S.pend.rep : null;
    S.pend = null;
    S.day = 0;
    stageWeek();
    const top0 = S.inbox[0];
    if (!S.over && window.R10DAY) window.R10DAY(0);
    const i0 = top0 ? S.inbox.indexOf(top0) : S.inbox.length, now = S.inbox.slice(0, i0 < 0 ? 0 : i0);
    const got = S.over ? [] : releaseDay(0).concat(now);
    if (done) S.lastRep = done;
    return { got, done };
  }
  window.dayStep = dayStep;
  ACT.weekrep = () => go('weekreport');

/* ---------- home ---------- */
  V.home = function () {
    const nw = netWorth(), hist = S.hist.nw;
    const prev = hist.length > 5 ? hist[hist.length - 5] : hist[0];
    const d = nw.total - (prev || 0);
    const cos = live();
    const alertCos = cos.filter(c => badAlerts(c).length); /* what needs you comes up as pop-ups (features/screens/tidier_screens_and_monthly_bills.js) */
    const c0 = CO[S.country] || CC();
    let h = '<header class="hh"><div><small>' + todayLabel() + '</small><h1>' + esc(S.player && S.player.name ? S.player.name : 'Home') + '</h1></div><span class="hhr">' + (window.PRO && !PRO.on ? '<button class="pill amb" data-a="prostore">Pro</button>' : '') + (window.WX56 ? WX56.pill(S.country) : '<span class="pill">' + c0.flag + ' ' + esc(c0.name) + '</span>') + '</span></header>'; /* Pro: the store, one tap from Home until everything is yours */
    /* one compact net worth card */
    const inCos = sum(S.cos.filter(c => c.st !== 'sold' && c.st !== 'bust'), c => Math.max(0, c.cash || 0));
    h += '<div class="card nw56"><button class="nwc" data-a="phapp" data-p="' + P({ n: 'stats' }) + '"><span class="lab">Net worth</span><b class="huge">' + nok(nw.total) + '</b><span class="pills"><span class="pl ' + (d >= 0 ? 'g' : 'r') + '">' + (d >= 0 ? '▲ ' : '▼ ') + mshort(Math.abs(d)) + ' last 4 weeks</span>' + (nw.debt > 0 ? '<span class="pl">Debt ' + mshort(nw.debt) + '</span>' : '') + '</span></button>' +
      '<div class="nwl56"><button data-a="phapp" data-p="' + P({ n: 'bank' }) + '">Cash <b class="' + (S.cash < 0 ? 'neg' : '') + '">' + mshort(S.cash) + '</b></button><button data-a="phapp" data-p="' + P({ n: 'invest' }) + '">Invested <b>' + mshort(nw.personal - S.cash + nw.inv + nw.crypto + nw.funds) + '</b></button><button data-a="go" data-p="' + P({ n: 'cos' }) + '">In companies <b>' + mshort(inCos) + '</b></button></div></div>';
    if (S.cash < 0) h += '<button class="bill29 od56" data-a="paysrc56"><span>Overdrawn <b class="neg">' + mshort(-S.cash) + '</b></span><span>Take money out of a company</span><i>›</i></button>';
    /* your companies in one line; the list itself is the Companies tab (ui/screens/companies_list.js V.cos) */
    const fs = window.FS58 ? FS58.card() : ''; /* a new game's first steps (features/player/first_steps.js) */
    if (!cos.length) { if (!fs) h += '<button class="banner blue" data-a="go" data-p="' + P({ n: 'newbiz' }) + '"><div><b>Start your first business</b><span>Pick any of ' + BD_ORDER.length + ' business types</span></div><i>＋</i></button>'; }
    else {
      const ops = cos.filter(c => c.type !== 'hold'), tot = sum(ops, c => lastProfit(c) || 0);
      h += '<button class="lrow cosum56" data-a="tab" data-p="cos">' + av(String(ops.length)) + '<span class="ctext"><b>Companies</b><small>' + (alertCos.length ? '<em class="neg">' + alertCos.length + (alertCos.length > 1 ? ' need you' : ' needs you') + '</em>' : ops.filter(c => c.mgr).length + ' of ' + ops.length + ' run by managers') + '</small></span><b class="num ' + sgn(tot) + '">' + plus(tot) + '<small>/mo</small></b><i>›</i></button>';
    }
    h += (cos.length && window.NEXT59 ? NEXT59.card() : '') + fs; /* the next thing to do, one tap (features/player/next_step.js) */
    h += '<div class="fill"></div>';
    h += '<div class="advbar">' + '<button class="btn untl" data-a="untilneeded">Until needed' + (window.PRO ? PRO.tag('untl') : '') + '</button><button class="btn primary go" data-a="nextday">Next day ›</button></div>';
    return h;
  };

  V.heads = V.heads || {};

/* ---------- news: one page. This week's front page of the local paper (one tap opens the paper, features/people/
     staff_stories_and_nemesis.js V.paper40), the headlines, then the economy ---------- */
  V.news = function () {
    let h = '';
    const I = V.paper40 && window.R28 && R28.frontPage ? R28.frontPage() : null;
    if (I) h += '<button class="card opt2 paper40" data-a="phapp" data-p="' + P({ n: 'paper40' }) + '"><div class="bhead"><b>' + esc(window.R31 && R31.paperName ? R31.paperName() : 'The local paper') + '</b><span class="pill blue">Read ›</span></div><span class="tipt">' + esc(I.head) + '</span></button>';
    h += '<h2 class="sec">Headlines</h2><div class="lrows">' + (S.news.slice(0, 40).map(n => '<div class="lrow"><span class="ctext"><b class="wrap">' + esc(n.t) + '</b><small>' + dateStr(n.w) + '</small></span></div>').join('') || '<div class="lrow"><small>Quiet.</small></div>') + '</div>';
    return h + '<h2 class="sec">Economy</h2>' + V.world();
  };

/* ---------- phone: one grid, every app once (other files add theirs to PHAPPS, e.g. features/world/private_equity.js) ---------- */
  const TINT = { g: 'tg', a: 'ta', b: 'tb', r: 'tr', n: 'tn' };
  const APPS = window.PHAPPS = [['bank', 'bank', 'Bank', 'g'], ['invest', 'invest', 'Investing', 'b'], ['news', 'news', 'News', 'n'], ['reviews', 'star', 'Reviews', 'a'], ['stats', 'chart', 'Stats', 'n'], ['lux', 'star', 'Luxury', 'a'], ['settings', 'cog', 'Settings', 'n']];
  V.phonehome = function () {
    return '<header class="hh"><h1>Phone</h1><small>' + todayLabel().split(' · ')[1] + '</small></header><div class="pgrid">' + APPS.filter(a => V[a[0]] && (!window.SEEN57 || SEEN57.app(a[0]))).map(a => '<button class="app2" data-a="phapp" data-p="' + P({ n: a[0] }) + '"><span class="tile ' + TINT[a[3]] + '">' + svg(a[1], 24) + '</span><span>' + a[2] + '</span></button>').join('') + '</div>';
  };

/* ---------- meetings ---------- */
  V.titles.meetings = 'Inbox';
  V.meetings = function () {
    /* Meetings is for your managers: it shows once you have one (features/screens/show_when_used.js), or always with
       the test switch Settings › Ledger Pro › Screens */
    const meetOk = window.SEEN57 ? SEEN57.on('meet') && (!!S.seen57 || (window.PRO && PRO.showAll) || (window.R35 && R35.hasMgr && R35.hasMgr())) : true;
    if (ui.mtab === 'meet' && !meetOk) ui.mtab = 'dec';
    const t = ui.mtab || 'dec';
    const us = unreadSplit();
    const open = S.inbox.filter(m => m.status === 'open');
    const alertCos = live().filter(c => badAlerts(c).length);
    const nW = open.length + alertCos.length;
    /* a conversation or a letter fills the screen with its own header (ui/screens/home.js) */
    if (t === 'msgs' && ui.thread != null) return '<div class="fill thr">' + V.msgs() + '</div>';
    if (t === 'mail' && ui.mail != null) return '<div class="fill">' + V.mail() + '</div>';
    let h = '<header class="hh"><h1>Inbox</h1>' + (nW ? '<span class="pill amb">' + nW + ' waiting</span>' : '') + '</header>';
    h += '<div class="ptabs">' + [['dec', 'To do', nW], ['msgs', 'Messages', us.msgs], ['mail', 'Email', us.mail], ['meet', 'Meetings', 0]].filter(x => x[0] !== 'meet' || meetOk).map(x => '<button class="' + (t === x[0] ? 'on' : '') + '" data-a="mtab" data-p="' + x[0] + '">' + x[1] + (x[2] ? ' <b class="cnt">' + x[2] + '</b>' : '') + '</button>').join('') + '</div>';
    if (t === 'msgs') return h + '<div class="fill">' + V.msgs() + '</div>';
    if (t === 'mail') return h + '<div class="fill">' + V.mail() + '</div>';
    if (t === 'meet') return h + '<div class="fill">' + V.meet(ui.mtp || {}) + '</div>';
    h += '<div class="fill">';
    /* a big offer on the table (features/player/selling_startups_and_crisis.js) */
    if (V.bigmeet && S.bigOff) { const o = S.bigOff; h += '<div class="lrows"><button class="lrow" data-a="go" data-p="' + P({ n: 'bigmeet' }) + '"><span class="lic">' + svg('deal', 20) + '</span><span class="ctext"><b>Big meeting</b><small>' + esc(o.pct + '% of ' + o.tgt + ' · on the table until ' + dateStr(o.exp)) + '</small></span><span class="pill amb">Offer</span></button></div>'; }
    if (alertCos.length) h += '<div class="lrows">' + alertCos.map(co => '<button class="lrow" data-a="go" data-p="' + P({ n: 'co', p: { id: co.id } }) + '">' + av(ini(co.name)) + '<span class="ctext"><b>' + esc(co.name) + '</b><small class="neg">' + badAlerts(co).map(a => esc(a[0])).join(' · ') + '</small></span><i>›</i></button>').join('') + '</div>';
    h += open.map(m => '<div class="dcard">' + window.msgCard(m) + '</div>').join('');
    if (!nW) h += '<div class="calm">Nothing is waiting.</div>';
    const done = S.inbox.filter(m => m.status !== 'open').sort((a, b) => b.w - a.w).slice(0, 6);
    const rep = S.lastRep ? (S.lastRep.ev || []).length || 1 : 0;
    if (done.length || rep) h += '<h2 class="sec">Earlier</h2><div class="lrows">' + (rep ? '<button class="lrow" data-a="weekrep"><span class="ctext"><b>Week report</b><small>' + rep + (rep === 1 ? ' thing' : ' things') + ' happened</small></span><i>›</i></button>' : '') + done.map(m => '<button class="lrow" data-a="openmsg" data-p="' + P({ id: m.id }) + '"><span class="ctext"><b>' + esc(m.title) + '</b><small>' + esc(m.from || '') + ' · ' + dateStr(m.w) + '</small></span><b class="pos small">Done</b></button>').join('') + '</div>';
    return h + '</div>';
  };
  ACT.mtab = p => {
    ui.mtab = p;
    ui.thread = null;
    ui.mail = null;
    ui.threadCo = null;
    render(true);
  };

/* ---------- luxury: private collection ---------- */
  /* [id, name, detail, price (NOK), upkeep per year (share of price), expected value change per year, swing per year] */
  const LUX = {
    /* the car range has photographs (src/assets/cars, built into the game); ids c1-c5 are kept so old saves still match */
    cars: { n: 'Cars', ic: 'truck', items: [
      ['c15', 'Hyperion Zenith Tourer', 'Electric estate, seats five', 1300000, 0.02, -0.14, 0.04],
      ['c1', 'Aurelion S saloon', 'Chauffeur-grade comfort, loses value quickly', 1800000, 0.03, -0.12, 0.04],
      ['c11', 'Bavaria 8 Apex coupé', 'Four seats, 625 hp', 2700000, 0.03, -0.1, 0.04],
      ['c10', 'Apex V10 GT', 'One of the last naturally aspirated V10s', 3000000, 0.03, 0.01, 0.08],
      ['c7', 'Vanguard Artemis', 'Light hybrid supercar in papaya', 3300000, 0.035, -0.08, 0.06],
      ['c8', 'Vanguard Sovereign GT', 'Grand tourer in racing green', 3600000, 0.03, -0.07, 0.05],
      ['c9', 'Vanguard Sovereign GT Black Edition', 'Midnight blue, black chrome', 4100000, 0.03, -0.06, 0.05],
      ['c2', 'Brandt 912 GT RS', 'A track car with number plates', 4200000, 0.03, -0.02, 0.07],
      ['c4', 'Ravenna Tempesta', 'Mid-engine V6 hybrid', 4500000, 0.04, -0.05, 0.1],
      ['c3', 'Aurelion GT Noir', 'Matte black, built for the track', 4800000, 0.035, 0, 0.09],
      ['c14', 'Hyperion Zenith One', 'V12 hybrid flagship', 7500000, 0.035, -0.03, 0.09],
      ['c13', 'Apex Apexian SUV', 'The most expensive way to go off-road', 8000000, 0.03, -0.06, 0.05],
      ['c12', 'Monarch Regent limousine', 'Hand-built, starlight headliner', 9500000, 0.03, -0.05, 0.05],
      ['c5', 'Halvorsen Hyper 99', 'One of 99 built, 1,500 hp', 38000000, 0.03, 0.03, 0.18],
      ['c6', 'Ravenna Fulmine 63', 'One of 63, carbon and bronze', 42000000, 0.03, 0.04, 0.2]
    ] },
    /* photographs in pictures/watches; w3 keeps its id for old saves */
    watches: { n: 'Watches and jewellery', ic: 'star', items: [
      ['w2', 'Voltara Éther Chronograph', 'Grade 5 titanium, monopusher', 140000, 0.01, -0.02, 0.05],
      ['w1', 'Aethelred Vanguard Régulateur Grand Feu', 'Enamel dial, regulator movement', 380000, 0.01, 0.02, 0.05],
      ['w5', 'Aethelred Monarch Solstice Celestial', 'Aventurine night sky, moon phase', 650000, 0.01, 0.03, 0.07],
      ['w3', 'Vescovi Rivière diamond necklace', 'Certified stones', 900000, 0.015, 0.01, 0.05],
      ['w4', 'Aethelred Hyperion Horizon Tourbillon', 'Flying tourbillon, cosmic blue dial', 1500000, 0.01, 0.04, 0.1],
      ['w6', 'Aethelred Apexian Zenith Split-Seconds', 'Skeleton rattrapante, titanium and rose gold', 2600000, 0.01, 0.04, 0.12],
      ['w7', 'Aethelred Sovereign Astrolabe', 'Engraved rose gold, minute repeater', 6500000, 0.01, 0.05, 0.14],
      ['w8', 'Aethelred Aetherius Infinite Complication', 'Grand sonnerie, perpetual calendar, tourbillon', 9800000, 0.01, 0.05, 0.15]
    ] },
    art: { n: 'Art and collectibles', ic: 'grad', items: [
      ['a1', 'Oil painting by Mira Halden', 'Emerging artist. Could rise a lot, or not at all', 120000, 0.01, 0.06, 0.3],
      ['a2', 'Captain Polar #1, first issue', 'Graded, sealed comic', 250000, 0.005, 0.06, 0.2],
      ['a3', 'Château Ormel cellar, 120 bottles', 'Fine vintages, stored properly', 600000, 0.02, 0.04, 0.08],
      ['a4', 'Jules Arnaud print set', 'Signed modernist edition', 400000, 0.01, 0.03, 0.1],
      ['a5', 'Canvas by Otto Brehm', 'Blue-chip, museum-grade, insured', 18000000, 0.015, 0.05, 0.14]
    ] },
    yachts: { n: 'Yachts', ic: 'globe', items: [
      ['y1', 'Sundqvist 40 day cruiser', 'Weekends on the water', 5000000, 0.08, -0.08, 0.05],
      ['y2', 'Marenco 80 motor yacht', 'Needs a captain', 38000000, 0.1, -0.07, 0.06],
      ['y3', 'Halcyon 50 m superyacht', 'Full crew all year', 320000000, 0.1, -0.05, 0.08]
    ] },
    jets: { n: 'Private jets', ic: 'rocket', items: [
      ['j1', 'Corvane Light 4 jet', 'Four seats, short trips', 60000000, 0.09, -0.08, 0.05],
      ['j2', 'Stratos Noir midsize jet', 'Nine seats, coast to coast', 160000000, 0.09, -0.07, 0.05],
      ['j4', 'Aerion Long Range 650', 'Fourteen seats, ocean crossings', 380000000, 0.085, -0.06, 0.05],
      ['j3', 'Stratos Global 8000 jet', 'Any continent, non-stop', 520000000, 0.08, -0.06, 0.06],
      ['j5', 'Zephyr Celestia Grand', 'An airliner fitted out as a home', 900000000, 0.08, -0.05, 0.06]
    ] },
    /* photographs in pictures/luxury-houses */
    homes: { n: 'Homes', ic: 'house', items: [
      ['h3', 'Forest pavilion near Kyoto', 'Concrete, glass and moss, a pond under the floor', 45000000, 0.012, 0.03, 0.06],
      ['h4', 'Basalt house above a black beach', 'Iceland, on the cliff edge', 70000000, 0.014, 0.03, 0.07],
      ['h1', 'Cliff house on the Big Sur coast', 'Glass on three sides, the Pacific below', 260000000, 0.012, 0.035, 0.07],
      ['h2', 'Villa on the Amalfi cliffs', 'Private funicular down to the sea', 420000000, 0.012, 0.04, 0.08]
    ] },
    /* round 56: estates that earn and give perks (features/player/estates.js); photographs in pictures/estates */
    estates: { n: 'Estates', ic: 'house', items: [
      ['e4', 'Forest and lake, 900 hectares', 'Pine forest, a lake and a timber cabin', 40000000, 0.003, 0.035, 0.03],
      ['e3', 'Highland estate', 'Moorland, a river, a hunting lodge and two tenant farms', 55000000, 0.01, 0.03, 0.04],
      ['e1', 'Hillside vineyard and château', '30 hectares of vines and a small stone château', 85000000, 0.015, 0.03, 0.06],
      ['e5', 'Castle and event venue', 'Restored, with a courtyard for weddings and dinners', 140000000, 0.022, 0.025, 0.05],
      ['e2', 'Private island', 'A villa, a jetty and turquoise water', 260000000, 0.025, 0.035, 0.07]
    ] }
  };
  const LUXI = {};
  Object.keys(LUX).forEach(c => LUX[c].items.forEach(x => {
    LUXI[x[0]] = { cat: c, id: x[0], n: x[1], d: x[2], price: x[3], up: x[4], g: x[5], vol: x[6] };
  }));
  const SELL_FEE = 0.08; window.LUX47 = { LUX, LUXI, SELL_FEE };
  const luxList = () => (S.lux = S.lux || []);
  /* what you own yourself; a company car or jet (x.co) is the company's and sits in its books (co.luxBV) */
  const luxValue = () => sum(luxList().filter(x => !x.co), x => x.val);
  window.luxValue = luxValue;
  addStep('netWorth', 10, 'your luxury collection', r => {
    const v = S && S.lux ? luxValue() : 0;
    if (v) {
      r.lux = v;
      r.personal += v;
      r.total += v;
    }
  });
  addStep('week.after', 10, 'luxury: values move, upkeep is paid', () => {
    {
      if (S && !S.over && S.lux && S.lux.length) {
        let cost = 0;
        S.lux.forEach(x => {
          const it = LUXI[x.k];
          if (!it) return;
          const z = (hrng(S.seed + ':lux:' + x.id + ':' + S.week)() - 0.5) * 3.4;
          x.val = Math.max(it.price * 0.05, Math.round(x.val * (1 + it.g / 52 + z * it.vol / Math.sqrt(52))));
          const co = x.co && getCo(x.co);
          if (co) payCo(co, Math.round(it.up * x.price / 52), 'oth', 'Upkeep: ' + it.n); else cost += it.up * x.price / 52;
        });
        cost = Math.round(cost);
        if (cost > 0) {
          moveCash(ME, -cost, 'Upkeep: private collection');
        }
      }
    }
  });
  V.titles.lux = 'Luxury';
  ACT.luxbuygo = p => {
    const it = LUXI[p.k];
    if (!it) return;
    const price = Math.round(it.price * (window.GA56 ? GA56.luxOff(it.id) : 1)); /* a private sale (deal of the week) */
    if (S.cash < price) {
      toast('Not enough cash.', true);
      return;
    }
    moveCash(ME, -price, 'Bought: ' + it.n);
    luxList().push({ id: uid(), k: it.id, price, val: Math.max(price, it.price), w: S.week });
    ui.sheet = null;
    save();
    render(true);
    toast('Bought: ' + it.n);
  };
  ACT.luxsell = p => {
    const x = luxList().find(y => y.id === p.id);
    if (!x) return;
    const it = LUXI[x.k] || { n: x.k };
    const get = Math.round(x.val * (1 - SELL_FEE));
    const co = x.co && getCo(x.co);
    confirmThen('Sell ' + esc(it.n) + '?', (co ? esc(co.name) + ' receives ' : 'You receive ') + money(get) + ' after selling costs.', 'Sell', () => {
      S.lux = luxList().filter(y => y.id !== p.id);
      if (co) {
        /* a company car or jet: the money goes to the company; the difference to its book value is a gain or a loss */
        const bv = Math.round(x.bv || 0);
        coIn(co, get, null, 'Sold: ' + it.n);
        co.luxBV = Math.max(0, (co.luxBV || 0) - bv);
        if (get > bv) bk(co, 'rev', get - bv); else bk(co, 'loss', bv - get);
      } else {
        moveCash(ME, get, 'Sold: ' + it.n);
        if (get > x.price) S.tax.gain = (S.tax.gain || 0) + get - x.price; /* a gain on a collectible is taxed with your other gains */
      }
      save();
      render();
    });
  };

/* ---------- game over ---------- */
  V.over = function () {
    const o = S.over, nw = netWorth();
    return '<div class="splash st2"><div><div class="eyebrow red">Game over · ' + todayLabel() + '</div><h1 class="hero">' + (o.reason === 'insolvent' ? 'You could not pay your debts and the creditors took everything.' : 'You ran out of money and have no business left to build on.') + '</h1>' +
      '<div class="card"><span class="lab">Final net worth</span><b class="huge ' + sgn(nw.total) + '">' + mshort(nw.total) + '</b></div>' +
      '<div class="tri"><div><span>Weeks played</span><b>' + S.week + '</b></div><div><span>Peak net worth</span><b>' + mshort(S.stats.peak) + '</b></div><div><span>Businesses failed</span><b>' + S.stats.bankrupt + '</b></div></div>' +
      '<div class="stbtns">' + btn('Start a new game', 'newgame', undefined, 'primary wide go') + '</div></div></div>';
  };

/* ---------- week report: full screen ---------- */
  V.titles.weekreport = 'Week report';
  V.heads = V.heads || {};
  V.heads.weekreport = function () {
    const r = S.lastRep;
    const d = r ? (r.nw1 != null ? r.nw1 : netWorth().total) - (r.nw0 || 0) : 0;
    return { t: 'Week report', sub: r ? 'Week of ' + dateStr((r.w || S.week)) : '', right: r ? '<span class="pill ' + (d >= 0 ? 'grn' : 'amb') + '">' + (d >= 0 ? '+' : '−') + mshort(Math.abs(d)) + '</span>' : '' };
  };

/* ---------- interviews: keep the salary talk as chat bubbles ---------- */
  ACT.offer = pipeView('ACT.offer', ACT.offer, 1);
  addStep('ACT.offer.around', 10, '---------- interviews: keep the salary talk as chat bubbles ----------', (p, next) => {
    const n = S.npcs[p.n];
    if (!n) return next();
    const w = rnl(U.inum('w' + n.id, n.ask), 100);
    const L = ((ui.talk = ui.talk || {})[n.id] = (ui.talk || {})[n.id] || []);
    L.push({ me: 1, t: 'I can offer ' + money(w) + ' a month.' });
    next();
    if (n.hired) L.push({ me: 0, t: 'Deal. I can start right away.' });
    else {
      L.push({ me: 0, t: w < n.ask ? 'That is below what I asked. Could you come closer to ' + money(n.ask) + '?' : 'I need to think about the terms.' });
      render();
    }
  });

/* ---------- 1B: salary talk has a patience meter ---------- */
  addStep('ACT.offer.around', 20, '---------- 1B: salary talk has a patience meter ----------', (p, next) => {
    const n = S.npcs[p.n];
    if (!n) return next();
    if (n.pat == null) n.pat = n.pers === 'driven' ? 2 : n.pers === 'loyal' || n.pers === 'steady' ? 4 : 3;
    if (n.gone) {
      toast(n.name + ' has taken another job.', true);
      return;
    }
    const w = rnl(U.inum('w' + n.id, n.ask), 100);
    next();
    if (n.hired) return;
    n.pat -= w < n.ask * 0.9 ? 2 : 1;
    const L = ui.talk && ui.talk[n.id];
    if (n.pat <= 0) {
      n.gone = 1;
      if (L) L.push({ me: 0, t: 'I have accepted another offer. Good luck.' });
      ui.cand = null;
      toast(n.name + ' is no longer interested.', true);
    }
    render();
  });
  window.patDots = n => {
    const max = n.pers === 'driven' ? 2 : n.pers === 'loyal' || n.pers === 'steady' ? 4 : 3;
    const left = n.pat == null ? max : Math.max(0, n.pat);
    return '<span class="pdots">' + Array.from({ length: max }, (x, i) => '<i class="' + (i < left ? 'on' : '') + '"></i>').join('') + '</span>';
  };

/* ---------- 6B: the manager follows a focus and explains the plan by text ---------- */
  const FOCUS_ACT = window.FOCUS_ACT = {
    price_up: 'raise prices a little',
    price_down: 'lower prices a little',
    hire: 'hire one more person',
    cut: 'trim staff costs',
    mkt_more: 'spend more on marketing',
    mkt_less: 'cut weak marketing',
    quality: 'step up maintenance and quality',
    save: 'reduce running costs'
  };
  const FOCUS_N = { profit: 'Profit', growth: 'Growth', quality: 'Quality' };
  function planFor(co, focus, skip) {
    const w = co.lastW || {}, util = w.util || 0;
    const mk = Object.keys(co.mkt || {}).filter(k => co.mkt[k] && co.mkt[k].b).length;
    const std = stdStaff(BD[co.type], co.size || 1);
    const short = std.some(x => co.staff.filter(s => s.role === x[0] && !s.notice).length < x[1]);
    const c = [];
    const add = (k, why, ok) => {
      if (ok && c.every(x => x[0] !== k)) c.push([k, why]);
    };
    if (focus === 'profit') {
      add('price_up', 'we are busy most days, so a small price rise costs few customers', util > 0.85 && co.price < 2);
      add('mkt_less', 'some of the ad money is not bringing customers back', mk > 0 && co.aware > 55);
      add('save', 'upkeep is higher than the business needs right now', co.maint > 1);
      add('cut', 'we have more people than work', util < 0.5 && co.staff.length > 1);
      add('price_up', 'our prices are below what the market pays', co.price < 0);
      add('save', 'every small saving goes straight to profit', co.maint > 0);
    } else if (focus === 'growth') {
      add('hire', 'we turn customers away for lack of hands', util > 0.9 || short);
      add('mkt_more', 'more people need to know about us', co.aware < 60);
      add('price_down', 'demand is soft and a lower price wins customers', util < 0.6 && co.price > -2);
      add('mkt_more', 'growth comes from new customers', true);
    } else {
      add('quality', 'better upkeep means fewer breakdowns and happier customers', co.maint < 2);
      add('hire', 'the team is stretched and quality slips when we rush', util > 0.95 || short);
      add('price_up', 'better quality lets us charge a little more', co.maint >= 2 && co.price < 1);
    }
    const q = mgrQual(co);
    let list = c.filter(x => !skip || skip.indexOf(x[0]) < 0);
    if (q < 0.45 && list.length > 1 && chance(0.35)) list = list.slice(1).concat(list.slice(0, 1));
    return list.slice(0, 2);
  }
  function planText(co, plan) {
    return plan.length ? 'For ' + co.name + ' I would ' + plan.map((x, i) => (i ? 'then ' : '') + FOCUS_ACT[x[0]] + ', because ' + x[1]).join('; ') + '.' : 'Honestly, I would not change anything at ' + co.name + ' right now.';
  }
  function sendPlan(co, focus, plan, alt) {
    const n = S.npcs[co.mgr];
    addMsg({
      kind: 'ask',
      from: n.name,
      role: titleFor(co, 'mgr'),
      title: (alt ? 'Another idea' : 'My plan') + ': ' + FOCUS_N[focus],
      body: planText(co, plan),
      co: co.id,
      opts: [{ l: 'Sounds smart', d: 'Go ahead', fx: {} }, { l: alt ? 'Keep the first plan' : 'Let us discuss', d: '', fx: {} }],
      act: 'focusplan',
      data: { id: co.id, focus, plan: plan.map(x => x[0]), alt: alt ? 1 : 0, first: co.focusDraft || null },
      exp: S.week + 2
    });
  }
  ACT.setfocus = p => {
    const co = getCo(p.id);
    if (!co || !co.mgr || !S.npcs[co.mgr]) return;
    co.focus = p.v;
    const plan = planFor(co, p.v);
    co.focusDraft = plan.map(x => x[0]);
    sendPlan(co, p.v, plan, false);
    save();
    render();
  };
  function runStep(co, k) {
    const ids = new Set(S.inbox.map(m => m.id));
    co.askW = null;
    askManager(co, k);
    const said = S.inbox.filter(m => !ids.has(m.id));
    S.inbox = S.inbox.filter(m => ids.has(m.id));
    return said.length ? said[0].body : '';
  }
  ACTS.focusplan = (m, idx) => {
    const co = getCo(m.data.id);
    if (!co || !co.mgr || !S.npcs[co.mgr]) return true;
    const n = S.npcs[co.mgr];
    if (idx === 0 || m.data.alt) {
      const plan = idx === 0 ? m.data.plan : (m.data.first || []);
      co.focusPlan = plan.slice();
      co.focusW = S.week;
      const said = plan.length ? runStep(co, plan[0]) : '';
      if (plan.length) co.focusPlan.shift();
      addMsg({ kind: 'info', from: n.name, role: titleFor(co, 'mgr'), title: 'Re: ' + FOCUS_N[m.data.focus], body: (plan.length ? 'Good. ' + said + (co.focusPlan.length ? ' Next I will ' + FOCUS_ACT[co.focusPlan[0]] + '.' : '') : 'Then we keep things as they are.'), co: co.id, tone: 'n', status: 'done' });
      return true;
    }
    const alt = planFor(co, m.data.focus, m.data.plan);
    sendPlan(co, m.data.focus, alt, true);
    return true;
  };
  /* every four weeks the manager carries out the next step, and re-plans when a step is done */
  function focusWeek() {
    S.cos.forEach(co => {
      if (!co.focus || !co.mgr || !S.npcs[co.mgr] || co.st !== 'open') return;
      if (S.week - (co.focusW || 0) < 4) return;
      co.focusW = S.week;
      if (!co.focusPlan || !co.focusPlan.length) co.focusPlan = planFor(co, co.focus).map(x => x[0]);
      const k = co.focusPlan.shift();
      if (!k) return;
      const said = runStep(co, k);
      if (said) note(S.npcs[co.mgr].name + ' (' + FOCUS_N[co.focus] + '): ' + said, 'n', co.id);
    });
  }

/* ---------- 13A: long, strong service earns better titles ---------- */
  function titleWeek() {
    if (S.week % 4 !== 1) return;
    S.cos.forEach(co => {
      if (co.st !== 'open') return;
      co.staff.forEach(s => {
        const n = S.npcs[s.id];
        if (!n || s.flag || s.notice) return;
        const ten = S.week - (s.w0 || S.week);
        if (ten < 156 || staffSkill(s) < 72) return;
        if (s.titleW && S.week - s.titleW < 52) return;
        const lad = ladderFor(co, s);
        if (!lad || !lad.length) return;
        const to = lad[0];
        s.titleW = S.week;
        const mn = co.mgr && S.npcs[co.mgr];
        addMsg({
          kind: 'ask',
          from: mn ? mn.name : n.name,
          role: mn ? titleFor(co, 'mgr') : ROLES[s.role][0],
          title: 'Promotion: ' + n.name + ' at ' + co.name,
          body: (mn ? n.name + ' has ' + Math.floor(ten / 52) + ' years here with strong results and deserves a step up to ' : 'After ' + Math.floor(ten / 52) + ' years of good work I would like a step up to ') + esc(ROLES[to] ? ROLES[to][0] : to) + '.',
          co: co.id,
          opts: [{ l: 'Promote', d: 'Better title and pay', fx: {} }, { l: 'Not now', d: 'May lower motivation', fx: {} }],
          act: 'titleask',
          data: { id: co.id, sid: s.id, role: to },
          exp: S.week + 3
        });
      });
    });
  }
  ACTS.titleask = (m, idx) => {
    const co = getCo(m.data.id);
    if (!co) return true;
    if (idx === 0) {
      const r = promoteStaff(co, m.data.sid, m.data.role);
      if (r && r !== 'ok' && r !== true) note('The promotion could not go through: ' + r, 'n', co.id);
    } else {
      const s = co.staff.find(x => x.id === m.data.sid);
      if (s) s.happy = 0;
    }
    return true;
  };
  addStep('week.after', 20, 'manager focus and job titles', () => {
    if (S && !S.over) {
      focusWeek();
      titleWeek();
    }
  });

/* ---------- staff card stays open while you work on it ---------- */
  document.addEventListener('toggle', e => {
    const d = e.target;
    if (!d || !d.classList || !d.classList.contains('srow')) return;
    const sid = d.getAttribute('data-sid');
    if (d.open) ui.openStaff = sid;
    else if (String(ui.openStaff) === sid) ui.openStaff = null;
  }, true);

/* ---------- 14B: the week report opens every week, Until needed sums the skipped weeks ---------- */
  function mergeReps(list) {
    if (list.length === 1) return list[0];
    const o = { ev: [], bw: {}, cos: [], meD: 0, nw0: list[0].nw0, w: list[list.length - 1].w, weeks: list.length };
    const byCo = {};
    list.forEach(r => {
      o.ev = o.ev.concat(r.ev || []);
      o.meD += r.meD || 0;
      for (const k in r.bw || {}) o.bw[k] = (o.bw[k] || 0) + r.bw[k];
      (r.cos || []).forEach(c => {
        const x = byCo[c.id] || (byCo[c.id] = { id: c.id, name: c.name, rev: 0, profit: 0, units: 0, unit: c.unit });
        x.rev += c.rev;
        x.profit += c.profit;
        x.units += c.units || 0;
      });
    });
    o.cos = Object.keys(byCo).map(k => byCo[k]);
    return o;
  }
  function showWeekReport() {
    ui.repLock = Date.now();
    ui.repAnim = 1;
    go('weekreport');
    setTimeout(() => {
      ui.repLock = 0;
      const b = document.querySelector('.repgo');
      if (b) {
        b.disabled = false;
        b.classList.remove('wait');
      }
    }, 1400);
  }
  ACT.nextday = () => {
    if (ui.repLock) return;
    const r = dayStep();
    save();
    if (S.over) return render(true);
    if (r.done) {
      showWeekReport();
      return;
    }
    render();
    if (r.got.some(m => m.status === 'open') && window.showPop) window.showPop();
  };
  ACT.untilneeded = () => {
    if (ui.repLock) return;
    const reps = [];
    let hit = false;
    for (let i = 0; i < 26 * 7 && !S.over; i++) {
      const r = dayStep();
      if (r.done) reps.push(r.done);
      if (r.got.some(m => m.status === 'open' || !m.read)) {
        hit = true;
        break;
      }
    }
    if (reps.length) S.lastRep = mergeReps(reps);
    ui.popAfterRep = hit;
    save();
    if (S.over) return render(true);
    if (reps.length) {
      showWeekReport();
      return;
    }
    render();
    if (hit && window.showPop) window.showPop();
  };
  ACT.repdone = () => {
    if (ui.repLock) return;
    ui.repAnim = 0;
    U.back();
    if (window.showPop) window.showPop(true);
  };

/* ---------- pop-ups never scroll: overflowing content is split into pages ---------- */
  let fitting = false;
  function fitSheet() {
    const sh = document.querySelector('#app .sheet');
    if (!sh || fitting) return;
    fitting = true;
    try {
      const kids = Array.prototype.slice.call(sh.children).filter(x => !x.classList.contains('pager'));
      kids.forEach(x => {
        x.style.display = '';
        Array.prototype.forEach.call(x.children, y => { if (y.style && y.style.display === 'none') y.style.display = ''; });
      });
      const old = sh.querySelector('.pager');
      if (old) old.remove();
      sh.style.overflowY = 'hidden';
      if (sh.scrollHeight <= sh.clientHeight + 2) return;
      /* round 41: forms are never split across pages, nor are long lists: they scroll instead */
      if (sh.querySelector('input,textarea,select,.chips,.knob,.ichat') || sh.scrollHeight > sh.clientHeight * 2.6) return;
      const head = kids[0] && kids[0].tagName === 'H2' ? kids[0] : null;
      const lastBtn = kids[kids.length - 1];
      const foot = lastBtn && lastBtn !== head && (lastBtn.classList.contains('btnrow') || lastBtn.classList.contains('btn') || (lastBtn.classList.contains('chips') && lastBtn.querySelector('.btn.primary'))) ? lastBtn : null;
      const body = kids.filter(x => x !== head && x !== foot);
      const cs = getComputedStyle(sh);
      const gap = parseFloat(cs.rowGap || cs.gap) || 8;
      const room = sh.clientHeight - parseFloat(cs.paddingTop) - parseFloat(cs.paddingBottom) - (head ? head.offsetHeight + gap : 0) - (foot ? foot.offsetHeight + gap : 0) - 52;
      const items = [];
      body.forEach(x => {
        if (x.offsetHeight > room * 0.6 && x.children.length > 1) Array.prototype.forEach.call(x.children, y => { y.style.display = ''; items.push({ el: y, box: x, h: y.offsetHeight + (parseFloat(getComputedStyle(x).rowGap || getComputedStyle(x).gap) || 6) }); });
        else items.push({ el: x, box: null, h: x.offsetHeight + gap });
      });
      const pages = [[]];
      let used = 0;
      items.forEach(it => {
        const cur = pages[pages.length - 1];
        const onlySmall = cur.length && cur.every(z => z.h < 60);
        if (cur.length && used + it.h > room && !onlySmall) {
          pages.push([]);
          used = 0;
        }
        pages[pages.length - 1].push(it);
        used += it.h;
      });
      if (pages.length < 2) return;
      const key = (ui.sheet && ui.sheet.html || '').length;
      if (ui.pgKey !== key) {
        ui.pgKey = key;
        ui.pg = 0;
      }
      const pg = Math.min(ui.pg || 0, pages.length - 1);
      const boxes = new Set();
      pages.forEach((p, i) => p.forEach(it => {
        it.el.style.display = i === pg ? '' : 'none';
        if (it.box) boxes.add(it.box);
      }));
      boxes.forEach(bx => { bx.style.display = pages[pg].some(it => it.box === bx) ? '' : 'none'; });
      const nav = document.createElement('div');
      nav.className = 'pager';
      nav.innerHTML = '<button type="button" class="btn chip" ' + (pg ? '' : 'disabled') + '>‹ Back</button><span>' + (pg + 1) + ' / ' + pages.length + '</span><button type="button" class="btn chip primary" ' + (pg < pages.length - 1 ? '' : 'disabled') + '>Next ›</button>';
      const b = nav.querySelectorAll('button');
      b[0].onclick = ev => {
        ev.stopPropagation();
        ui.pg = Math.max(0, pg - 1);
        fitting = false;
        fitSheet();
      };
      b[1].onclick = ev => {
        ev.stopPropagation();
        ui.pg = Math.min(pages.length - 1, pg + 1);
        fitting = false;
        fitSheet();
      };
      if (foot) sh.insertBefore(nav, foot); else sh.appendChild(nav);
    } finally {
      if (sh.scrollHeight > sh.clientHeight + 2) sh.style.overflowY = 'auto';
      fitting = false;
    }
  }
  new MutationObserver(() => {
    if (!fitting) requestAnimationFrame(fitSheet);
  }).observe(document.getElementById('app') || document.body, { childList: true });


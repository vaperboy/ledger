/* ---- ui/screens/home.js ---- */
(function () {
  'use strict';
  const U = window.UI, { ui, V, ACT, esc, nok, tone, sgn, svg, bar, row, btn, card, sec, noteBox, badge, contact, seg, chips, inp, inum, spark, lineChart, go, tabTo, openSheet, closeSheet, confirmThen, toast, res, render, save } = U;

  ACT.noop = () => { };

  ACT.newgame = () => {
    S = null;
    try {
      localStorage.removeItem(U.KEY);
    } catch (e) { }
    U.disk(U.KEY, null);
    ui.inp = {};
    render(true);
  };

/* ---------- alerts ---------- */
  function coAlerts(co) {
    const out = [];
    if (co.st === 'bust') return [['Bankrupt', 'bad']];
    if (co.st === 'sold') return [];
    const bd = BD[co.type];
    if (co.st === 'setup') {
      const m = openChecklist(co).filter(x => !x.ok).length;
      out.push([m ? 'Setup: ' + m + ' items left' : 'Ready to open', m ? 'n' : 'good']);
    }
    if (co.st === 'closed') out.push([co.closeW >= 9000 ? 'Closed until you reopen it' : 'Closed for ' + co.closeW + ' wk', 'bad']);
    if (co.st === 'open') {
      if (co.cash < 0) out.push(['Negative cash', 'bad']); else if (co.cash < coWeekCost(co) * 2.5) out.push(['Low cash', 'bad']);
      const miss = docsMissing(co).filter(d => d !== 'mva_na');
      if (miss.length && co.st === 'open') out.push(['Missing documents', 'bad']);
      const prob = co.staff.filter(s => s.flag).length;
      if (prob) out.push([prob + ' staff problem' + (prob > 1 ? 's' : ''), 'bad']);
      if (co.unpaid) out.push(['Unpaid bills', 'bad']);
      if (co.lastW && co.lastW.D > co.lastW.cap * 1.2 && co.lastW.cap > 0) out.push(['Turning customers away', 'n']);
      if (co.dbg && co.dbg.bot && co.lastW && co.lastW.util > 0.95) out.push(['Bottleneck: ' + co.dbg.bot, 'n']);
    }
    return out;
  }
  window.coAlerts = coAlerts;
  function coLine(co) {
    const bd = BD[co.type];
    const h = co.hist.map(x => x.profit);
    const al = coAlerts(co);
    const last = co.hist.length ? co.hist[co.hist.length - 1] : null;
    return '<button class="contact" data-a="go" data-p="' + esc(JSON.stringify({ n: 'co', p: { id: co.id } })) + '"><span class="cic" style="background:var(--surface2)">' + svg('biz') + '</span><span class="ctext"><b>' + esc(co.name) + '</b><small>' + bd.n + ' · ' + ((CO[co.country || S.country] || CC()).forms[co.form + 's'] || co.form) + ' · ' + cityOf(co.city).name + '</small>' + (al.length ? '<small style="color:' + tone(al[0][1]) + '">' + esc(al[0][0]) + '</small>' : '') + '</span><span class="rt"><b>' + mshort(co.cash) + '</b>' + (last ? '<small class="' + sgn(last.profit) + '">' + (last.profit >= 0 ? '+' : '') + mshort(last.profit) + '/mo</small>' : '') + '</span></button>';
  }
  window.coLine = coLine;

  function coCard(co) {
    const bd = BD[co.type];
    const hs = co.hist.map(x => x.profit);
    const al = coAlerts(co);
    const last = co.hist.length ? co.hist[co.hist.length - 1] : null;
    return '<button class="cc" data-a="go" data-p="' + esc(JSON.stringify({ n: 'co', p: { id: co.id } })) + '"><div class="bhead"><b>' + esc(co.name) + '</b>' + (al.length ? '<span class="badge ' + (al[0][1] === 'bad' ? 'red' : al[0][1] === 'good' ? 'green' : '') + '">' + esc(al[0][0]) + '</span>' : '') + '</div><small>' + esc(bd.n) + ' · ' + ((CO[co.country || S.country] || CC()).forms[co.form + 's'] || co.form) + ' · ' + esc(cityOf(co.city).name) + '</small>' + (hs.length > 1 ? spark(hs, 180, 34) : '') + '<div class="bhead"><small>' + (co.mgr ? 'Manager' : 'You') + '</small><b class="' + (last ? sgn(last.profit) : '') + '">' + (last ? (last.profit >= 0 ? '+' : '') + mshort(last.profit) + '/mo' : mshort(co.cash)) + '</b></div></button>';
  }
  window.coCard = coCard;
  ACT.advance = () => {
    const nw0 = netWorth().total;
    const before = S.week;
    const r = advance(ui.advMode);
    save();
    if (S.over) {
      render(true);
      return;
    }
    const nw1 = netWorth().total;
    ui.last = { weeks: r.weeks, d: nw1 - nw0, why: r.why };
    if (S.rep && S.rep.ev.length && (r.weeks > 1 || S.rep.ev.some(e => e.tone !== 'n'))) {
      showReport();
    } else {
      render();
      showPop();
    }
  };
  function showReport() {
    const ev = (S.rep && S.rep.ev) || [];
    const l = ui.last || {};
    openSheet('<h2>' + (l.weeks > 1 ? l.weeks + ' weeks passed' : 'Week report') + '</h2><div class="trio sm"><div><span>Net worth</span><b class="' + sgn(l.d) + '">' + (l.d >= 0 ? '+' : '') + mshort(l.d || 0) + '</b></div><div><span>Cash</span><b>' + mshort(S.cash) + '</b></div><div><span>Waiting</span><b>' + unreadCount() + '</b></div></div>' + (l.why === 'decision' ? '<div class="note">Stopped because something needs your decision.</div>' : '') + '<div class="evs">' + ev.slice(0, 40).map(e => '<div class="news"><i style="background:' + tone(e.tone) + '"></i><p>' + esc(e.t) + '</p></div>').join('') + '</div><div class="btnrow">' + (unreadCount() ? btn('Open messages', 'repmsgs', undefined, 'primary') : '') + btn('Close', 'sheetclose', undefined, unreadCount() ? '' : 'primary') + '</div>');
  }
  ACT.repmsgs = () => {
    ui.sheet = null;
    const kn = knownNames();
    const un = S.inbox.filter(m => m.status === 'open');
    const m1 = un.find(m => needsPop(m));
    if (m1) {
      m1.snz = null;
      showPop(true);
      return;
    }
    if (un.length === 1) {
      ACT.openmsg({ id: un[0].id });
      return;
    }
    tabTo(un.some(m => (m.ch || (isKnownMsg(m, kn) ? 'msg' : 'mail')) === 'msg') ? 'msgs' : 'mail');
  };

/* ---------- messages and email (round 56) ----------
   Two channels, fixed when a message arrives (m.ch, engine/events/engine.js): Messages are texts from people you
   work with and know (your managers and their teams, head office, the people in your network, family); Email is
   everyone else (authorities, banks, insurers, the press, brokers, offers and invitations from people you do not
   know yet). Messages are conversations, one per person, oldest at the top and newest at the bottom, with your
   answers as your own bubbles. Email is a mailbox: one letter at a time. */
  V.titles.msgs = 'Messages';
  V.titles.mail = 'Email';
  V.titles.meet = 'Call a meeting';
  V.titles.stats = 'Stats';
  const chOf = m => m.ch || (isKnownMsg(m) ? 'msg' : 'mail');
  const unread = m => m.status === 'open' || !m.read;
  const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const dnOf = m => m.dn != null ? m.dn : m.w * 7;
  function whenTxt(m) {
    const now = S.week * 7 + (S.day || 0), d = dnOf(m);
    if (d >= now) return 'Today';
    if (d === now - 1) return 'Yesterday';
    if (now - d < 7) return DAYS[((d % 7) + 7) % 7];
    return dateStr(Math.floor(d / 7)).replace(/ \d{4}$/, m.w >= S.week - 40 ? '' : '$&');
  }
  const npcNamed = nm => { for (const id in S.npcs) if (S.npcs[id] && S.npcs[id].name === nm) return S.npcs[id]; return null; };
  const avOf = nm => { const n = npcNamed(nm); return n && window.faceAv ? faceAv(n) : '<span class="av">' + esc(String(nm || '?').replace(/[^A-Za-zÀ-ÿ0-9 ]/g, ' ').trim().split(/\s+/).slice(0, 2).map(x => x[0]).join('').toUpperCase() || '?') + '</span>'; };
  /* the people you text with: everyone who wrote to you, and the people you know who have not yet */
  function people() {
    const by = {};
    S.inbox.filter(m => chOf(m) === 'msg').forEach(m => { const k = m.from || 'Other'; (by[k] = by[k] || []).push(m); });
    const R = {};
    contactRoster().forEach(c => { R[c.name] = { name: c.name, role: c.role, co: c.co, msgs: by[c.name] || [] }; });
    Object.keys(by).forEach(k => {
      if (!R[k]) { const c = liveCos().find(x => x.name === k); R[k] = { name: k, role: by[k][0].role || (c ? 'The team at your company' : ''), co: '', msgs: by[k] }; }
      else if (!R[k].role) R[k].role = by[k][0].role || '';
    });
    return Object.values(R).map(x => { x.un = x.msgs.filter(unread).length; x.last = x.msgs.length ? dnOf(x.msgs[0]) : -1; return x; });
  }
  function msgList() {
    const L = people();
    const talk = L.filter(x => x.msgs.length).sort((a, b) => (b.un > 0) - (a.un > 0) || b.last - a.last || S.inbox.indexOf(a.msgs[0]) - S.inbox.indexOf(b.msgs[0]));
    const quiet = L.filter(x => !x.msgs.length);
    if (!L.length) return card('<p class="muted">Nobody texts you yet. Your managers, their teams and the people you get to know show up here.</p>', 'empty');
    const row = x => {
      const m0 = x.msgs[0];
      const prev = m0 ? (m0.status === 'open' ? 'Needs your answer: ' : m0.pick != null && m0.opts && m0.opts[m0.pick] ? 'You: ' + m0.opts[m0.pick].l + ' · ' : '') + (m0.title || m0.body || '') : (x.role || '');
      return '<button class="cv56 lrow' + (x.un ? ' un' : '') + '" data-a="thread" data-p="' + esc(JSON.stringify({ k: x.name })) + '">' + avOf(x.name) + '<span class="ctext"><b>' + esc(x.name) + '</b><small>' + esc((x.role || '') + (x.co ? ' · ' + x.co : '')) + '</small>' + (m0 ? '<small class="pv">' + esc(prev) + '</small>' : '') + '</span><span class="cvr">' + (m0 ? '<small>' + esc(whenTxt(m0)) + '</small>' : '') + (x.un ? '<b class="cnt">' + x.un + '</b>' : '') + '</span></button>';
    };
    let h = '';
    if (talk.length) h += '<div class="lrows">' + talk.map(row).join('') + '</div>';
    if (quiet.length) h += '<h2 class="sec">People you know</h2><div class="lrows">' + quiet.map(row).join('') + '</div>';
    return h;
  }
  /* one conversation: day by day, their messages and decisions, and what you answered */
  function convo(k) {
    const ms = S.inbox.filter(m => chOf(m) === 'msg' && (m.from || 'Other') === k).slice().reverse();
    const ct = contactRoster().find(c => c.name === k) || {};
    const role = (ms.length && ms[ms.length - 1].role) || ct.role || '';
    let h = '<div class="ichat cv56c"><div class="vh"><button class="bk" data-a="threadback" aria-label="Back">‹</button>' + avOf(k) + '<div class="vht"><h1>' + esc(k) + '</h1><p>' + esc(role + (ct.co ? ' · ' + ct.co : '')) + '</p></div></div>';
    h += '<div class="clog"><div class="cfill"></div>';
    if (!ms.length) h += '<div class="bub sys">No messages yet.</div>';
    let day = null;
    ms.forEach(m => {
      const d = whenTxt(m);
      if (d !== day) { day = d; h += '<div class="bub sys">' + esc(d) + '</div>'; }
      if (m.status === 'open' && m.opts && m.opts.length) { h += '<div class="dcard">' + msgCard(m) + '</div>'; return; }
      const go = m.go && (!m.go.p || !m.go.p.b || ((S.fbApps || {})[m.go.p.b] || {}).st === 'invited') ? btn(esc(m.go.l || 'Open'), m.go.a, m.go.p, 'chip') : '';
      h += '<div class="bub them' + (m.tone === 'bad' ? ' bad' : m.tone === 'good' ? ' good' : '') + '"><b>' + esc(m.title || '') + '</b>' + (m.body ? '<br>' + esc(m.body).replace(/\n/g, '<br>') : '') + (go ? '<br>' + go : '') + '</div>';
      if (m.opts && m.pick != null && m.opts[m.pick]) h += '<div class="bub me">' + esc(m.opts[m.pick].l) + (m.auto ? ' <small>(no answer in time)</small>' : '') + '</div>';
    });
    h += '</div><div class="composer">';
    const mco = liveCos().find(c => (ui.threadCo ? c.id === ui.threadCo : true) && c.mgr && S.npcs[c.mgr] && S.npcs[c.mgr].name === k) || liveCos().find(c => c.mgr && S.npcs[c.mgr] && S.npcs[c.mgr].name === k);
    if (mco) h += '<span class="lab">Focus for ' + esc(mco.name) + '</span>' + chips([['profit', 'Profit'], ['growth', 'Growth'], ['quality', 'Quality']], mco.focus || '', 'setfocus', { id: mco.id }) + '<div class="chips qk">' + btn('Meeting', 'cv56meet', { id: mco.id }, 'chip') + btn('Open ' + esc(mco.name), 'go', { n: 'co', p: { id: mco.id } }, 'chip') + '</div>';
    const vv = knownVendors().find(v => v.owner === k);
    if (vv) h += '<small class="muted">' + esc(vv.name) + ' · ' + relWord(vrel(vv.id)) + (relDisc(vrel(vv.id)) ? ' · ' + Math.round(relDisc(vrel(vv.id)) * 100) + '% off every order' : '') + '</small><div class="chips qk">' + btn('Take ' + esc(k.split(' ')[0]) + ' to lunch', 'vmeet', { v: vv.id }, 'chip') + '</div>';
    if (!mco && !vv) h += '<small class="muted">' + (ms.some(m => m.status === 'open') ? 'Answer above.' : 'Up to date.') + '</small>';
    ms.forEach(m => { if (m.status !== 'open') m.read = 1; });
    return h + '</div></div>';
  }
  /* the mailbox */
  function mailList() {
    const L = S.inbox.filter(m => chOf(m) === 'mail');
    const f = ui.mailf || 'all';
    const show = L.filter(m => f === 'all' || (f === 'un' && unread(m)) || (f === 'act' && m.status === 'open'));
    let h = chips([['all', 'All · ' + L.length], ['un', 'Unread · ' + L.filter(unread).length], ['act', 'To answer · ' + L.filter(m => m.status === 'open').length]], f, 'mailf');
    if (!show.length) return h + card('<p class="muted">' + (L.length ? 'Nothing here.' : 'No email yet. Authorities, banks, insurers, the press, brokers and people you have not met write here.') + '</p>', 'empty');
    return h + '<div class="lrows">' + show.slice(0, 120).map(m => '<button class="ml56 lrow' + (unread(m) ? ' un' : '') + '" data-a="mailopen" data-p="' + esc(JSON.stringify({ id: m.id })) + '"><span class="ctext"><b>' + esc(m.from || 'Ledger') + '</b><small class="sj">' + esc(m.title || '') + '</small><small class="pv">' + esc(String(m.body || '').slice(0, 90)) + '</small></span><span class="cvr"><small>' + esc(whenTxt(m)) + '</small>' + (m.status === 'open' ? '<b class="cnt">!</b>' : '') + '</span></button>').join('') + '</div>';
  }
  function mailView(id) {
    const m = S.inbox.find(x => x.id === id);
    if (!m) { ui.mail = null; return mailList(); }
    m.read = 1;
    const co = m.co ? getCo(m.co) : null;
    let h = '<div class="vh"><button class="bk" data-a="mailback" aria-label="Back">‹</button><div class="vht"><h1>' + esc(m.title || '') + '</h1><p>' + esc(m.from || '') + (co ? ' · about ' + esc(co.name) : '') + ' · ' + esc(dateStr(m.w)) + '</p></div></div>';
    if (m.status === 'open' && m.opts && m.opts.length) return h + msgCard(m);
    h += '<div class="card ml56b"><p>' + esc(m.body || '').replace(/\n/g, '<br>') + '</p>' + (m.stats ? m.stats.map(x => row(esc(x[0]), esc(x[1]))).join('') : '') + (m.opts && m.pick != null && m.opts[m.pick] ? '<small class="muted">You answered: ' + esc(m.opts[m.pick].l) + (m.auto ? ' (no answer in time)' : '') + '</small>' : '') + '</div>';
    if (m.go && (!m.go.p || !m.go.p.b || ((S.fbApps || {})[m.go.p.b] || {}).st === 'invited')) h += btn(esc(m.go.l || 'Open'), m.go.a, m.go.p, 'primary wide');
    return h;
  }
  V.msgs = function () {
    if (ui.thread != null) return convo(ui.thread);
    return msgList();
  };
  V.mail = function () {
    if (ui.mail != null) return mailView(ui.mail);
    return mailList();
  };
  ACT.thread = p => {
    ui.thread = p.k;
    render(true);
  };
  ACT.threadback = () => {
    ui.thread = null;
    ui.threadCo = null;
    render(true);
  };
  ACT.mailopen = p => { ui.mail = p.id; render(true); };
  ACT.mailback = () => { ui.mail = null; render(true); };
  ACT.mailf = p => { ui.mailf = p.v; render(); };
  ACT.cv56meet = p => { ui.mtw = p.id; ui.thread = null; ui.mtab = 'meet'; render(true); };
  function msgCard(m) {
    const co = m.co ? getCo(m.co) : null;
    const left = m.exp ? Math.max(0, m.exp - S.week) : 0;
    const from = m.from || (co ? co.name : '');
    const ini = String(from || '?').replace(/[^A-Za-zÀ-ÿ0-9 ]/g, ' ').trim().split(/\s+/).slice(0, 2).map(x => x[0]).join('').toUpperCase() || '?';
    let h = '<div class="card dc"><div class="cchd"><span class="av">' + esc(ini) + '</span><span class="ctext"><b>' + esc(m.title) + '</b><small>' + esc(from) + (co && co.name !== from ? ' · ' + esc(co.name) : '') + '</small></span>' + (m.exp ? '<span class="badge ' + (left <= 1 ? 'red' : 'amber') + '">' + (left <= 0 ? 'Now' : left + ' wk') + '</span>' : (m.status === 'open' ? '<span class="badge amber">New</span>' : '')) + '</div>' + (m.pa && m.exp ? '<small>One week extra from your assistant</small>' : '') + (m.body ? '<div class="bub them">' + esc(m.body) + '</div>' : '');
    if (m.ask && m.mgrName) h += noteBox(esc(m.mgrName) + ' recommends: <b>' + esc(m.opts[m.rec].l) + '</b>');
    const opts = m.opts || [];
    const money2 = opts.filter(o => o.fx && (o.fx.cash || o.fx.loss || o.fx.fine)).slice(0, 2);
    if (m.stats) h += '<div class="duo">' + m.stats.map(x => '<div><span>' + esc(x[0]) + '</span><b class="' + (/^~?−/.test(x[1]) ? 'neg' : /revenue/i.test(x[0]) ? 'pos' : '') + '">' + esc(x[1]) + '</b></div>').join('') + '</div>';
    else if (money2.length) h += '<div class="duo">' + money2.map(o => {
      const v = (o.fx.cash || 0) - Math.abs(o.fx.loss || 0) - (o.fx.fine || 0);
      return '<div><span>' + esc(o.l) + '</span><b class="' + (v >= 0 ? 'pos' : 'neg') + '">' + (v >= 0 ? '+' : '−') + mshort(Math.abs(v)) + '</b></div>';
    }).join('') + '</div>';
    h += '<div class="dbtns">' + opts.map((o, i) => '<button class="btn' + (m.rec === i || (m.rec == null && i === 0 && opts.length > 1) ? ' primary' : '') + (optBlock(m, i) ? ' off' : '') + '" data-a="msgpick" data-p="' + esc(JSON.stringify({ id: m.id, i: i })) + '"><b>' + esc(o.l) + '</b>' + (o.d || (o.fx && fxText(o.fx)) ? '<small>' + esc(o.d || fxText(o.fx)) + '</small>' : '') + (optBlock(m, i) ? '<small class="neg">' + esc(optBlock(m, i)) + '</small>' : '') + '</button>').join('') + '</div>';
    if (m.go) h += btn(esc(m.go.l || 'Open'), m.go.a, m.go.p, 'primary wide');
    if (m.exp) h += '<small class="muted">If you do nothing, the cheapest option is chosen when time runs out.</small>';
    return h + '</div>';
  }

/* decisions you must take yourself pop up; messages from people you know arrive as texts on the phone */
  function needsPop(m) {
    return m.status === 'open' && m.opts && m.opts.length && !isKnownMsg(m);
  }
  function showPop(force) {
    if (!S || S.over) return;
    if (ui.sheet) { ui.popDue = 1; return; } /* shown when that sheet closes */
    ui.popDue = 0;
    const m = S.inbox.find(x => needsPop(x) && (force || x.snz !== S.week));
    if (!m) return;
    ui.popId = m.id;
    openSheet(msgCard(m) + btn('Later', 'msglater', { id: m.id }, 'ghost wide'), 'msgpop');
  }
  window.showPop = showPop;
  ACT.msglater = p => {
    const m = S.inbox.find(x => x.id === p.id);
    if (m) m.snz = S.week;
    ui.popId = null;
    closeSheet();
  };
  ACT.openmsg = p => {
    const m = S.inbox.find(x => x.id === p.id);
    if (!m) return;
    if (needsPop(m)) {
      m.snz = null;
      ui.sheet = null;
      showPop(true);
    } else if ((m.ch || (isKnownMsg(m) ? 'msg' : 'mail')) === 'msg') {
      ui.mail = null;
      ui.thread = m.from || null;
      U.phoneGo('msgs', {});
    } else {
      ui.thread = null;
      ui.mail = m.id;
      U.phoneGo('mail', {});
    }
  };
  ACT.opendec = p => {
    const m = S.inbox.find(x => x.co === p.id && x.status === 'open');
    if (m) ACT.openmsg({ id: m.id });
  };
  ACT.msgpick = p => {
    const m = S.inbox.find(x => x.id === p.id);
    const o = m && m.opts && m.opts[p.i];
    const why = m ? optBlock(m, p.i) : '';
    if (why) return toast(why, true);
    const risky = o && o.fx && (o.fx.coord || (o.fx.cash && Math.abs(o.fx.cash) > 100000) || (o.fx.gamble && o.fx.gamble.p < 0.5));
    const run = () => {
      if (resolveMsg(p.id, p.i)) {
        save();
        ui.sheet = null;
        render();
        showPop(true);
      } else toast('Could not do that.', true);
    };
    if (risky) confirmThen('Are you sure?', esc(o.l) + (o.d ? '. ' + esc(o.d) : '') + (o.fx.coord ? ' This is illegal and can be fined heavily.' : ''), 'Yes', run, !!o.fx.coord); else run();
  };
  window.showReport = showReport;
  window.msgCard = msgCard;
})();


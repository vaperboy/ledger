/* ---- ui/screens/hubs.js ---- */
(function () {
  'use strict';
  const U = window.UI, { ui, V, ACT, tabsRow, render } = U;
  V.titles.hq = 'HQ';
})();


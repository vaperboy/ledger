/* ---- ui/screens/companies_list.js ---- */
(function () {
  'use strict';
  const U = window.UI, { ui, V, ACT, esc, nok, tone, sgn, svg, bar, row, btn, card, sec, noteBox, badge, contact, seg, chips, inp, inum, quick, pctChips, tabsRow, go, tabTo, openSheet, closeSheet, confirmThen, toast, res, render, save } = U;
  V.titles = V.titles || {};

/* ---------- the Companies tab ----------
   One compact list. A registered chain (features/company/shelf_stock_chains_boards.js R12) and stores under one name
   (features/company/branches_and_addresses.js BR56) are one row each that opens their folder; then single companies,
   then those still setting up, then holdings and startups, then closed ones (folded). Within each part, the ones
   that need you come first, then the most profitable. The filter chips narrow every part at once. */
  ACT.cofilter = p => {
    ui.cof = p.v;
    render();
  };
  ACT.cosold = () => {
    ui.cosOld = !ui.cosOld;
    render();
  };
  {
    const ini = n => String(n || '?').replace(/[^A-Za-zÀ-ÿ0-9 ]/g, ' ').trim().split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase() || '?';
    const av = (t, cls) => '<span class="av ' + (cls || '') + '">' + esc(t) + '</span>';
    const P = o => esc(JSON.stringify(o));
    const plus = n => (n >= 0 ? '+' : '−') + mshort(Math.abs(n));
    const lastProfit = co => co.hist.length ? co.hist[co.hist.length - 1].profit : null;
    const badAlerts = co => coAlerts(co).filter(a => a[1] === 'bad');
    const lp = c => lastProfit(c) || 0;
    const needs = c => badAlerts(c).length > 0;
    const sites = (type, n) => window.siteW ? siteW(type, n) : (n === 1 ? 'store' : 'stores');
    const flag = c => (c.country && c.country !== S.country && CO[c.country]) ? CO[c.country].flag + ' ' : '';
    const FILT = { all: () => true, attn: needs, me: c => !c.mgr, mgr: c => !!c.mgr };
    /* the folder a company sits in: a registered chain first, otherwise stores under one name */
    function folderOf(co) {
      const ch = window.R12 && R12.chainOf ? R12.chainOf(co) : null;
      if (ch) return { k: 'ch:' + ch.id, go: { n: 'chain12', p: { id: ch.id } }, name: ch.name, chain: true };
      const g = window.BR56 && BR56.groupOf ? BR56.groupOf(co) : null;
      return g ? { k: 'br:' + g.k, go: { n: 'brand56', p: { k: g.k } }, name: BR56.nameOf ? BR56.nameOf(g) : g.L[0].name } : null;
    }
    /* who runs a chain for you: the highest person above the store managers (engine/management/managers.js chainOf) */
    function bossOf(co) {
      try { const L = typeof chainOf === 'function' ? chainOf(co).filter(x => x.kind !== 'mgr' && x.npc) : []; return L.length ? L[L.length - 1].npc.name.split(' ')[0] : ''; } catch (e) { return ''; }
    }
    const order = (a, b) => (needs(b) - needs(a)) || (lp(b) - lp(a));
    function groupRow(g) {
      const L = g.L, tot = sum(L, lp), bad = L.filter(needs).length, boss = g.chain ? bossOf(L[0]) : '';
      const sub = bad ? '<em class="neg">' + bad + ' ' + sites(L[0].type, bad) + (bad > 1 ? ' need you' : ' needs you') + '</em>'
        : (g.chain ? 'Chain · ' : '') + L.length + ' ' + sites(L[0].type, L.length) + (boss ? ' · ' + esc(boss) + ' runs it' : '');
      return '<button class="lrow" data-a="go" data-p="' + P(g.go) + '">' + av(ini(g.name), 'grp') + '<span class="ctext"><b>' + flag(L[0]) + esc(g.name) + '</b><small>' + sub + '</small></span><b class="num ' + sgn(tot) + '">' + plus(tot) + '<small>/mo</small></b></button>';
    }
    function coRow(co) {
      const al = badAlerts(co), m = co.mgr && S.npcs[co.mgr], p = lastProfit(co);
      const sub = al.length ? '<em class="neg">' + esc(al[0][0]) + '</em>'
        : esc(BD[co.type].n) + ' · ' + esc(cityOf(co.city).name) + ' · ' + (co.st === 'setup' ? 'setting up' : m ? esc(m.name.split(' ')[0]) + ' manages' : 'you run it');
      let right;
      if (co.st === 'setup') { const cl = openChecklist(co), ok = cl.filter(x => x.ok).length; right = '<b class="amb">' + ok + '/' + cl.length + '</b>'; }
      else right = p != null ? '<b class="num ' + sgn(p) + '">' + plus(p) + '<small>/mo</small></b>' : '<b class="num">' + mshort(co.cash) + '</b>';
      return '<button class="lrow" data-a="go" data-p="' + P({ n: 'co', p: { id: co.id } }) + '">' + av(ini(co.name)) + '<span class="ctext"><b>' + flag(co) + esc(co.name) + '</b><small>' + sub + '</small></span>' + right + '</button>';
    }
    const part = (t, rows) => rows ? (t ? '<h2 class="sec">' + t + '</h2>' : '') + '<div class="lrows">' + rows + '</div>' : '';
    V.cos = pipeView('V.cos', function () {
      const all = S.cos.filter(c => c.st !== 'sold' && c.st !== 'bust');
      const ops = all.filter(c => c.type !== 'hold'), old = S.cos.filter(c => c.type !== 'hold' && (c.st === 'sold' || c.st === 'bust'));
      const holds = all.filter(c => c.type === 'hold' && c.st === 'open'), su = (S.founded || []).filter(x => x.st === 'live');
      const f = FILT[ui.cof] ? ui.cof : 'all', pick = FILT[f];
      const na = ops.filter(needs).length;
      let h = '<header class="hh"><h1>Companies</h1><button class="pill" data-a="go" data-p="' + P({ n: 'newbiz' }) + '">＋ New</button></header>';
      if (!ops.length && !holds.length && !su.length) {
        h += '<div class="fill"><div class="card empty"><h3>No companies yet</h3><p class="lead">Start a business of any kind. You only need the money and the paperwork.</p></div></div>';
        return h + '<div class="advbar">' + btn('＋ New company', 'go', { n: 'newbiz' }, 'wide') + '</div>';
      }
      const tot = sum(ops, lp);
      h += '<div class="card nw56"><div class="nwl56"><span>Profit a month <b class="' + sgn(tot) + '">' + plus(tot) + '</b></span><span>Cash <b>' + mshort(sum(ops, c => c.cash)) + '</b></span><span>People <b>' + sum(ops, c => c.staff.length + (c.mgr ? 1 : 0)) + '</b></span></div></div>';
      const chip = (k, t) => '<button class="' + (f === k ? 'on' : '') + '" data-a="cofilter" data-p="' + P({ v: k }) + '">' + t + '</button>';
      h += '<div class="cf56 cosf56">' + chip('all', 'All · ' + ops.length) + chip('attn', 'Need you' + (na ? ' · ' + na : '')) + chip('me', 'Run by me') + chip('mgr', 'Managers') + '</div>';
      /* folders: a folder shows when any of its stores fits the filter */
      const G = {}, singles = [], setup = [];
      ops.forEach(co => {
        const g = co.st === 'setup' ? null : folderOf(co);
        if (g) (G[g.k] = G[g.k] || Object.assign({ L: [] }, g)).L.push(co);
        else if (pick(co)) (co.st === 'setup' ? setup : singles).push(co);
      });
      Object.keys(G).forEach(k => { if (!G[k].chain && G[k].L.length < 2) { if (pick(G[k].L[0])) singles.push(G[k].L[0]); delete G[k]; } });
      const groups = Object.keys(G).map(k => G[k]).filter(g => g.L.some(pick)).sort((a, b) => (b.L.filter(needs).length - a.L.filter(needs).length) || (sum(b.L, lp) - sum(a.L, lp)));
      let body = part('Chains and groups · ' + groups.length, groups.map(groupRow).join('')) +
        part(groups.length ? 'Companies · ' + singles.length : '', singles.sort(order).map(coRow).join('')) +
        part('Setting up · ' + setup.length, setup.map(coRow).join(''));
      if (!body) body = '<div class="calm">None in this filter.</div>';
      if (f === 'all') {
        body += part('Holdings and startups',
          (holds.length ? '<button class="lrow" data-a="go" data-p="' + P({ n: 'holdings' }) + '">' + av('H', 'grp') + '<span class="ctext"><b>Holding companies · ' + holds.length + '</b><small>' + holds.map(x => esc(x.name)).join(', ') + '</small></span><b class="num">' + mshort(sum(holds, x => window.R7 && R7.holdValue ? R7.holdValue(x) : x.cash)) + '</b></button>' : '') +
          (su.length ? '<button class="lrow" data-a="go" data-p="' + P({ n: 'found36' }) + '">' + av('S', 'grp') + '<span class="ctext"><b>Your startups · ' + su.length + '</b><small>' + su.slice(0, 3).map(x => esc(x.name)).join(', ') + '</small></span><i>›</i></button>' : ''));
        if (old.length) body += '<button class="sec secbtn" data-a="cosold">Closed and failed · ' + old.length + ' <i>' + (ui.cosOld ? '▾' : '▸') + '</i></button>' +
          (ui.cosOld ? '<div class="lrows">' + old.map(c => '<div class="lrow">' + av(ini(c.name), 'dim') + '<span class="ctext"><b>' + esc(c.name) + '</b><small>' + esc(BD[c.type].n) + '</small></span>' + badge(c.st === 'bust' ? 'Bankrupt' : 'Sold or closed', c.st === 'bust' ? 'red' : '') + '</div>').join('') + '</div>' : '');
      }
      return h + '<div class="fill">' + body + '</div>';
    }, 0);
  }

/* ---------- new business: pick type ---------- */
  const CAT_ORDER = [
    'Services',
    'Food and leisure',
    'Retail',
    'Sport',
    'Building and projects',
    'Production and primary',
    'Transport and logistics',
    'Property',
    'Finance',
    'Energy'
  ];
  const CAT_IC = {
    'Services': 'tie',
    'Food and leisure': 'star',
    'Retail': 'bag',
    'Sport': 'fire',
    'Building and projects': 'tool',
    'Production and primary': 'biz',
    'Transport and logistics': 'truck',
    'Property': 'house',
    'Finance': 'bank',
    'Energy': 'bolt'
  };
  const CATS = () => {
    const o = [];
    BD_ORDER.forEach(id => {
      const c = BD[id].cat;
      if (o.indexOf(c) < 0) o.push(c);
    });
    if (o.indexOf('Sport') < 0) o.push('Sport');
    return o.sort((a, b) => (CAT_ORDER.indexOf(a) + 99) % 99 - (CAT_ORDER.indexOf(b) + 99) % 99 || 0);
  };
  /* the groups show once one trade in them is open (features/player/trade_unlocks.js UNL57); in a group, the locked
     trades show the net worth you must earn first, the next ones to open on top */
  V.newbiz = function () {
    const U57 = window.UNL57, okT = id => !U57 || U57.ok(id);
    const cats = CATS().filter(c => c === 'Sport' ? !U57 || U57.sportOk() : BD_ORDER.some(id => BD[id].cat === c && okT(id)));
    ui.cat = ui.cat && cats.indexOf(ui.cat) >= 0 ? ui.cat : cats[0];
    const nx = U57 ? U57.next() : null, earned = U57 ? U57.earned() : 0;
    const lr = (a, p, ic, t, sub) => '<button class="lrow" data-a="' + a + '" data-p="' + esc(JSON.stringify(p)) + '"><span class="lic">' + svg(ic, 20) + '</span><span class="ctext"><b>' + t + '</b><small>' + esc(sub) + '</small></span><i>›</i></button>';
    let h = '';
    /* the ready-made ways in first: a franchise, a startup (features/screens/fewer_places.js V.found36), a new store of your chain */
    const J = [];
    if (V.franchises) J.push(lr('go', { n: 'franchises' }, 'biz', 'Join a franchise', 'A known brand, their rules, a fee'));
    if (V.startups) J.push(lr('go', { n: 'found36' }, 'rocket', 'Start a startup', 'Build a product, raise money'));
    if (J.length) h += '<h2 class="sec">Join or build</h2><div class="lrows">' + J.join('') + '</div>';
    const CH = ACT.ch12new && window.R12 && R12.storesOf ? (S.chains || []).filter(ch => R12.storesOf(ch).length) : [];
    if (CH.length) h += '<h2 class="sec">A new store in your chain</h2><div class="lrows">' + CH.map(ch => lr('ch12new', { id: ch.id }, 'biz', esc(ch.name), R12.storesOf(ch).length + ' stores · same name, rules and paperwork')).join('') + '</div>';
    if (h) h += '<h2 class="sec">Start from scratch</h2>';
    h += '<p class="muted">Bigger businesses need more money and stricter documents.</p>';
    if (nx) h += '<div class="card unl57"><div class="bhead"><b>Next to open</b><span class="pill">' + mshort(nx.v) + ' earned</span></div><div class="bar56"><i style="width:' + Math.round(Math.min(1, earned / nx.v) * 100) + '%"></i></div><small class="muted">' + esc(nx.L.slice(0, 4).map(t => BD[t].n).join(', ') + (nx.L.length > 4 ? ' and ' + (nx.L.length - 4) + ' more' : '')) + ' · you have earned ' + mshort(Math.max(0, earned)) + ' since you started. A bank lends the rest once about a third of the start-up cost is yours.</small></div>';
    h += '<div class="catgrid">' + cats.map(c => '<button class="cg' + (c === ui.cat ? ' on' : '') + '" data-a="setcat" data-p="' + esc(JSON.stringify(c)) + '">' + svg(CAT_IC[c] || 'biz', 20) + '<span>' + esc(c) + '</span></button>').join('') + '</div>';
    if (ui.cat === 'Sport') return h + (window.sportEntry ? window.sportEntry() : '');
    const ids = BD_ORDER.filter(id => BD[id].cat === ui.cat), open = ids.filter(okT), shut = ids.filter(id => !okT(id)).sort((a, b) => U57.need(a) - U57.need(b));
    open.forEach(id => {
      const bd = calib(BD[id]);
      const idea = bd.fam === 'fin' || bd.fam === 'energy' || bd.fam === 'rent' ? 'Large capital' : bd.open > 400000 ? 'Big start' : bd.open > 60000 ? 'Medium start' : 'Small start';
      h += '<button class="contact" data-a="go" data-p="' + esc(JSON.stringify({ n: 'newco', p: { bd: id } })) + '"><span class="cic" style="background:var(--surface2)">' + svg(bd.fam === 'fin' ? 'bank' : bd.fam === 'energy' ? 'bolt' : bd.fam === 'rent' ? 'house' : bd.fam === 'logi' ? 'truck' : bd.fam === 'retail' ? 'bag' : 'biz') + '</span><span class="ctext"><b>' + esc(bd.n) + (window.PRO && !PRO.typeOk(id) ? PRO.tag('tycoon') : '') + '</b><small>' + esc(bd.blurb) + '</small></span><span class="badge' + (U57 && U57.isNew(id) ? ' green' : '') + '">' + (U57 && U57.isNew(id) ? 'New' : idea) + '</span></button>';
    });
    /* a locked trade says what opens it; with Ledger Pro or Time savers every trade is open at once (tap to see) */
    if (shut.length) h += '<h2 class="sec">Opens as you grow</h2><div class="lrows">' + shut.map(id => '<button class="lrow lock57" data-a="proask" data-p="' + esc(JSON.stringify({ k: 'trades' })) + '"><span class="lic">' + svg('lock', 18) + '</span><span class="ctext"><b>' + esc(BD[id].n) + '</b><small>When you have earned ' + mshort(U57.need(id)) + ', or now with Pro</small></span><i class="pro56">Pro</i></button>').join('') + '</div>';
    return h;
  };
  ACT.setcat = p => {
    ui.cat = p;
    render(true);
  };

/* ---------- new business: details ---------- */
  /* your own outlets of this trade in the chosen city share its customers with the new one (ownShare in engine/company/model.js) */
  function mineHere(bdId, st) {
    const L = S.cos.filter(c => c.st === 'open' && c.type === bdId && c.city === st.city && (c.country || S.country) === st.country);
    if (!L.length) return '';
    const ov = cityOverlap(st.city), cut = Math.round((1 - 1 / (1 + ov)) * 100);
    return '<div class="note">You already have ' + L.map(c => esc(c.name)).join(', ') + ' here. Your own outlets share the city\'s customers: each loses roughly ' + cut + '% to each other one, more if both are in the centre, less in different neighbourhoods.</div>';
  }
  V.newco = function (p) {
    const bd = calib(BD[p.bd]);
    const st = ui.nc && ui.nc.bd === p.bd ? ui.nc : (ui.nc = {
      bd: p.bd,
      country: S.country,
      city: S.player.city,
      form: bd.needAS ? 'AS' : 'ENK',
      acc: null,
      fran: 0
    });
    if (ui.ncPre && ui.ncPre.bd === p.bd) {
      st.fran = ui.ncPre.fran;
      st.deal = ui.ncPre.deal;
      st.indep = 0;
      if (ui.ncPre.country && CO[ui.ncPre.country]) {
        st.country = ui.ncPre.country;
        st.city = ui.ncPre.city;
        st.acc = null;
      }
      ui.ncPre = null;
    }
    setCtx({ country: st.country });
    const CCc = CO[st.country];
    if (!CCc.cities.some(x => x.id === st.city)) st.city = CCc.cities[0].id;
    const lg = legalStatus(p.bd, st.country);
    const city = cityOf(st.city);
    const bsr = brandStrength(p.bd);
    const size = startSize(p.bd, st.city, bsr.v, st.fran);
    const est = setupEstimate(p.bd, {
      city: st.city,
      size,
      form: st.form,
      country: st.country,
      fee: st.deal ? st.deal.fee : 0,
      cover: st.deal ? st.deal.cover : 0,
      fitMult: st.fran && fbBrand(st.fran) ? fbBrand(st.fran).fitMult : 1,
      solo: 1 /* you start alone; a trade that can work from home needs no staff or premises yet */
    });
    let h = card('<h3>' + esc(bd.n) + (window.PRO && !PRO.typeOk(p.bd) ? PRO.tag('tycoon') : '') + '</h3><p class="lead">' + esc(bd.blurb) + '</p>' + row('Typical price', nok(bd.ticket) + ' per ' + bd.unit) + row('Manager type', MGR_TYPES[bd.mgr] || 'General') + '<p class="muted small">Needs: ' + bd.docs.filter(d => d !== 'mva_na').map(d => docDef(d) ? docDef(d)[0] : d).join(', ') + '</p>');
    h += card('<h3>Country</h3>' + chips(CO_ORDER.filter(k => k === st.country || legalStatus(p.bd, k).ok).map(k => [k, CO[k].flag + ' ' + CO[k].name + (k !== S.country && window.PRO && !PRO.ccOk(k) ? ' · Pro' : '')]), st.country, 'ncset', { k: 'country' }) + (lg.ok ? '<p class="muted small">' + (st.country === S.country ? 'Your home country.' : 'Abroad: needs foreign registration and a local presence. Taxes, VAT and wages follow ' + esc(CCc.name) + '. Amounts are shown in ' + CCc.cur + '.') + '</p>' : '<div class="note bad"><b>Not allowed in ' + esc(CCc.name) + '.</b> ' + esc(lg.why) + ' Pick another country.</div>'));
    h += card('<h3>City</h3>' + chips(CC().cities.map(c => [c.id, c.name]), st.city, 'ncset', { k: 'city' }) + '<p class="muted small">Demand ' + (city.dem >= 1 ? 'high' : city.dem >= 0.8 ? 'average' : 'low') + ' · rent ' + (city.rent >= 1.15 ? 'high' : city.rent >= 0.9 ? 'average' : 'low') + ' · wages ' + (city.wage >= 1.1 ? 'high' : city.wage >= 0.92 ? 'average' : 'low') + '</p>' + mineHere(p.bd, st));
    h += card('<h3>Legal form</h3>' + chips([['ENK', CCc.forms.ENK], ['AS', CCc.forms.AS]], st.form, 'ncset', { k: 'form' }) + '<p class="muted small">' + (st.form === 'ENK' ? 'Simple and cheap, but you are personally liable for all debts. Profit is taxed as your personal income.' : 'Limited liability. Needs share capital of ' + money(CC().asCapital) + ', which stays in the company as its cash, and a ' + money(CC().asFee) + ' fee, an accountant, and pays ' + pc(CC().corp, 0) + ' company tax. Dividends are taxed again.') + '</p>' + (bd.needAS && st.form === 'ENK' ? noteBox('This business normally needs a limited company (' + CC().forms.ASs + ').', true) : ''));
    if (st.form === 'AS') h += card('<h3>Accountant</h3>' + S.cos.filter(c => c.type === 'acctfirm' && c.st === 'open').map(o => provRow(ownProv('acc', o), 'acc', st.acc, { a: 'ncset', p: { k: 'acc', v: 'own' + o.id } })).join('') + poolFor(st.country).acc.map(a => provRow(a, 'acc', st.acc, { a: 'ncset', p: { k: 'acc', v: a.id } })).join('') + '<p class="muted small">Better accountants make fewer mistakes with tax and VAT.</p>');
    h += CT_brandCard(p.bd, st);
    h += card('<h3>Estimated start cost</h3>' + row('Permits and documents', nok(est.docs)) + row('Equipment', nok(est.eq)) + (est.veh ? row('Vehicles (20% down)', nok(est.veh)) : '') + (est.prem ? row('Premises (3 months deposit + fit-out)', nok(est.prem)) : row('Premises', 'From home, free')) + (est.fee ? row('Franchise entry fee', nok(est.fee)) : '') + row('Opening stock', nok(est.stock)) + row('First month of wages', nok(est.hires)) + (st.form === 'AS' ? row('Registration fee', nok(CC().asFee)) : '') + row(est.capLbl || 'Cash buffer (recommended)', nok(est.buffer)) + row('Total', nok(est.total), 'total') + '<p class="muted small">Used equipment, leasing and financing can lower the cash needed. You choose in the next step.</p>');
    const rec = rnl(Math.max(0, est.total - (st.form === 'AS' ? CC().asCapital + CC().asFee : 0)), 5000);
    const outlay = startOutlay(p.bd, { country: st.country, form: st.form });
    const have = Math.max(0, S.cash + S.sav.bal - outlay);
    h += card('<h3>Money to put in</h3><p class="muted small">You have ' + nok(have) + ' available' + (outlay ? ' after ' + nok(outlay) + ' for registration and share capital' : '') + '. The percentages are of that.</p>' + inp('fund', 'Amount', Math.min(rl(rec), Math.floor(have))) + pctChips('fund', have) + (S.loans.length ? '<p class="muted small">You can also borrow for the company in Phone › Bank.</p>' : ''));
    h += card('<h3>Name</h3>' + inp('name', 'Company name', coName(bd.fam, st.city, bd.id), 'text'));
    const fbOpen = brandsFor(p.bd).some(b => fbStatus(b).ok) && !st.deal && !st.indep;
    const shut57 = window.UNL57 && !UNL57.ok(p.bd);
    h += shut57 ? '<button class="btn wide" disabled>Opens when you have earned ' + mshort(UNL57.need(p.bd)) + '</button>' : fbOpen ? '<button class="btn wide" disabled>Talk to a brand or choose to start your own first</button>' : lg.ok ? btn('Create company', 'ncgo', { bd: p.bd }, 'primary wide') : '<button class="btn wide" disabled>Not allowed here</button>';
    return h;
  };
  ACT.ncset = p => {
    const st = ui.nc;
    st[p.k] = p.v;
    if (p.k === 'fran' && !p.v) st.deal = null;
    if (p.k === 'country') {
      st.indep = 0;
      st.acc = null;
      st.fran = 0;
      st.deal = null;
      st.city = CO[p.v].cities[0].id;
      ui.inp.fund = null;
    }
    render();
  };
  ACT.ncgo = p => {
    const st = ui.nc, bd = BD[p.bd];
    if (window.UNL57 && !UNL57.ok(p.bd)) { toast(bd.n + ' opens when you have earned ' + mshort(UNL57.need(p.bd)) + '.', true); return; }
    if (st.form === 'AS' && !st.acc) {
      toast('Pick an accountant first.', true);
      return;
    }
    setCtx({ country: st.country });
    let amt = Math.round(inum('fund', 0));
    const nm = (ui.inp.name || '').trim() || coName(bd.fam, st.city, bd.id);
    if (amt > S.cash + S.sav.bal - startOutlay(p.bd, { country: st.country, form: st.form }) + fxr(CC())) {
      toast('You do not have that much.', true);
      return;
    }
    const run = () => {
      const co = startCompany(p.bd, {
        city: st.city,
        form: st.form,
        country: st.country,
        fran: st.fran,
        name: nm,
        acc: st.form === 'AS' ? st.acc : null
      });
      if (typeof co === 'string') {
        res(co);
        return;
      }
      amt = Math.min(amt, Math.floor(liquid()));
      if (amt > 0 && !injectCash(co, amt)) {
        toast('Could not move the money.', true);
      }
      if (st.fran && st.deal) {
        const b = fbBrand(st.fran);
        if (b && co.cash >= st.deal.fee) {
          payCo(co, st.deal.fee, 'oth', 'Franchise entry fee: ' + b.name);
          applyBrand(co, b, st.deal);
          if (S.fbApps && S.fbApps[b.id]) delete S.fbApps[b.id];
        } else {
          toast('Not enough funding for the franchise fee, so you start independent.', true);
        }
      }
      ui.nc = null;
      ui.stack = [];
      ui.tab = 'cos';
      ui.view = { n: 'co', p: { id: co.id, t: 'doc' } };
      ui.inp = {};
      save();
      render(true);
    };
    const warn = bd.needAS && st.form === 'ENK' ? ' This business normally needs a limited company (' + CC().forms.ASs + '). A sole proprietor carries all the risk.' : '';
    confirmThen('Create ' + esc(nm) + '?', 'Putting in ' + nok(amt) + ' as ' + (st.form === 'AS' ? 'a ' + CO[st.country].forms.AS : 'a sole proprietorship') + ' in ' + cityOf(st.city).name + '.' + warn, 'Create', run);
  };

  function CT_brandCard(bdId, st) {
    const bs = brandsFor(bdId).filter(b => fbStatus(b).ok);
    let h = '<div class="card"><h3>Start independent or join a brand</h3>';
    if (!bs.length) return '';
    h += '<p class="muted small">A known brand costs more to start (entry fee, their fit-out, royalties) but brings customers from day one.</p>';
    if (st.fran && st.deal) {
      const b = fbBrand(st.fran);
      h += '<div class="note good"><b>Deal agreed with ' + esc(b.name) + '.</b> Entry fee ' + money(st.deal.fee) + ', royalty ' + pc(st.deal.roy, 1) + ' plus ' + pc(st.deal.mkt, 0) + ' marketing' + dealCover(st.deal) + '.</div>' + btn('Start independent instead', 'brandpick', { bd: bdId, v: 0 }, 'chip');
      return h + '</div>';
    }
    h += (st.indep ? '<div class="note good"><b>You start your own.</b> No brand, no royalties.</div>' : btn('Start my own, no brand', 'brandpick', { bd: bdId, v: 0 }, 'chip wide'));
    bs.forEach(b => {
      const a = (S.fbApps || {})[b.id];
      let act = '', sub = '';
      if (!a || a.st === 'expired') {
        act = btn('Apply', 'brandapply', { b: b.id, bd: bdId }, 'chip primary');
        sub = fbTn(b) + ' · ' + b.units + ' units';
      }
    else if (a.st === 'pending') {
        sub = 'Application sent. Answer expected in about ' + Math.max(1, a.due - S.week) + ' weeks.';
      }
    else if (a.st === 'invited') {
        act = btn('Meet the ' + fbRole(b), 'brandopen', { b: b.id }, 'chip primary');
        sub = 'They want to talk. Invitation open for ' + Math.max(0, a.exp - S.week) + ' more weeks.';
      }
    else if (a.st === 'agreed') {
        act = btn('Use this deal', 'branduse', { b: b.id }, 'chip primary') + btn('Talk again', 'brandopen', { b: b.id }, 'chip');
        sub = 'Terms agreed. Entry fee ' + money(a.terms.fee) + ', royalty ' + pc(a.terms.roy, 1) + '.';
      }
      h += '<div class="opt"><div class="bhead"><div><b>' + esc(b.name) + '</b><small>' + esc(sub) + '</small></div><div class="rt">' + act + '</div></div></div>';
    });
    return h + '</div>';
  }
  function dealCover(t) {
    const a = [];
    if (t.cover) a.push('about ' + ['0%', '40%', '70%'][t.cover] + ' of setup');
    if (t.rent) a.push([0, 6, 12][t.rent] + ' months of rent');
    if (t.veh) a.push('half of the vehicles');
    if (t.bld) a.push('a building from them at 15% under market');
    if (t.prem) a.push('premises from your own building');
    return a.length ? ', they cover ' + a.join(', ') : '';
  }
  ACT.brandpick = p => {
    const st = ui.nc;
    if (!p.v) {
      st.fran = 0;
      st.deal = null;
      st.indep = 1;
    }
    render();
  };
  ACT.brandapply = p => {
    const b = fbBrand(p.b);
    const r = fbApply(b, ui.nc ? ui.nc.country : S.country, ui.nc ? ui.nc.city : S.player.city);
    if (res(r, 'Application sent. Expect an answer in a week or three.')) {
      save();
      render();
    }
  };
  ACT.branduse = p => {
    const a = S.fbApps[p.b];
    ui.nc.indep = 0;
    ui.nc.fran = p.b;
    ui.nc.deal = a.terms;
    render();
  };
  ACT.brandopen = p => {
    if (window.innerWidth <= 960) ui.phoneOn = false;
    ui.neg = { b: p.b, ask: { fee: 0, roy: 0, cover: 0, rent: 0, veh: 0, bld: 0, prem: null }, res: null, rounds: 0 };
    go('brandneg', { b: p.b });
  };
  V.titles.brandneg = 'Franchise meeting';
  function negTerms(b, ng, a, st) {
    const bd2 = BD[b.bd];
    const m2 = bd2.prem && bd2.prem[1] > 0 ? Math.round(bd2.prem[1]) : 0;
    const hasVeh = bd2.eq.some(e => e.vo);
    const T = [
      [
        'fee',
        'Entry fee',
        [-.3, -.2, -.1, 0, .05, .1, .15, .2, .25, .3].map(v => [v, v < 0 ? 'Pay ' + Math.round(-v * 100) + '% more' : v ? Math.round(v * 100) + '% off' : 'Standard'])
      ],
      [
        'roy',
        'Royalty',
        [-.03, -.02, -.01, 0, .005, .01, .015, .02, .025, .03].map(v => [v, pc(Math.max(0, b.roy - v), 1) + (v ? '' : ' (standard)')])
      ],
      ['cover', 'Fit-out covered', [[0, 'None'], [1, '40%'], [2, '70%']]]
    ];
    if (m2) {
      T.push(['rent', 'Rent covered', [[0, 'None'], [1, '6 months'], [2, '12 months']]]);
      T.push(['bld', 'Building', [[0, 'Your own'], [1, 'Theirs, 15% under market']]]);
    }
    if (hasVeh) T.push(['veh', 'Vehicles', [[0, 'You buy'], [1, 'They cover half']]]);
    const city = (a && a.city) || (st ? st.city : S.player.city);
    const fp = m2 ? fbFreeProps(b.bd, city, m2) : [];
    if (m2 && fp.length) T.push(['prem', 'Location', [[0, 'They approve one']].concat(fp.map((x, i) => [i + 1, 'Yours: ' + x.name]))]);
    return { T, fp };
  }
  V.brandneg = function (p) {
    const b = fbBrand(p.b);
    const st = ui.nc;
    const a = (S.fbApps || {})[b.id];
    const ng = ui.neg && ui.neg.b === b.id ? ui.neg : (ui.neg = { b: b.id, ask: { fee: 0, roy: 0, cover: 0, rent: 0, veh: 0, bld: 0, prem: null }, res: null, rounds: 0 });
    const sx = fbStatus(b);
    const head = '<div class="card tight"><div class="bhead"><div><h3>' + esc(b.name) + '</h3><small>' + esc(fbTn(b)) + ' · ' + esc(brandWord(b.str)) + '</small></div><div class="rt">' + btn('Facts', 'brandfacts', { b: b.id }, 'chip') + '</div></div></div>';
    if (!sx.ok) return head + noteBox(esc(sx.why), true);
    if (!a || (a.st !== 'invited' && a.st !== 'agreed')) return head + noteBox('Apply first. They will invite you when they have looked at your application.');
    const nt = negTerms(b, ng, a, st);
    const cur = k => k === 'prem' ? (ng.ask.prem ? 1 + nt.fp.findIndex(x => x.pid === ng.ask.prem.pid) : 0) : ng.ask[k];
    const r = ng.res;
    const say = r ? '<div class="note ' + (r.r === 'accept' ? 'good' : r.r === 'counter' || r.r === 'push' ? '' : 'bad') + '">' + esc(r.msg) + '</div>' : '<div class="note">' + esc(fbWho(b).replace(/,$/, '')) + ' is listening. Standard terms are below. Ask for what would make this work for you.</div>';
    let h = head + say;
    h += '<div class="card tight negrows">' + nt.T.map(t => {
      const i = Math.max(0, t[2].findIndex(o => o[0] === cur(t[0])));
      const lab = t[2][i][1];
      return '<div class="nrow' + (ng.mark && ng.mark[t[0]] ? ' ' + ng.mark[t[0]] : '') + '"><span>' + t[1] + '</span><span class="nst">' + btn('‹', 'negstep', { k: t[0], d: -1 }, 'chip') + '<b>' + esc(lab) + '</b>' + btn('›', 'negstep', { k: t[0], d: 1 }, 'chip') + '</span></div>';
    }).join('') + '</div>';
    h += '<div class="btnrow">' + (r && r.terms ? btn('Sign this deal', 'negsign', { b: b.id }, 'primary wide') : '') + btn(r && r.terms ? 'Propose again' : 'Propose these terms', 'negsend', { b: b.id }, (r && r.terms ? '' : 'primary ') + 'wide') + '</div>';
    return h;
  };
  ACT.negstep = p => {
    const b = fbBrand(ui.neg.b);
    const a = S.fbApps[b.id];
    const nt = negTerms(b, ui.neg, a, ui.nc);
    const t = nt.T.find(x => x[0] === p.k);
    const cur = p.k === 'prem' ? (ui.neg.ask.prem ? 1 + nt.fp.findIndex(x => x.pid === ui.neg.ask.prem.pid) : 0) : ui.neg.ask[p.k];
    let i = Math.max(0, t[2].findIndex(o => o[0] === cur)) + (+p.d);
    i = (i + t[2].length) % t[2].length;
    const v = t[2][i][0];
    if (p.k === 'prem') ui.neg.ask.prem = v ? { co: nt.fp[v - 1].co, pid: nt.fp[v - 1].pid } : null; else ui.neg.ask[p.k] = v;
    ui.neg.res = null;
    if (ui.neg.mark) delete ui.neg.mark[p.k];
    render();
  };
  ACT.brandfacts = p => {
    const b = fbBrand(p.b);
    const us = fbUnitStats(b);
    openSheet('<h2>' + esc(b.name) + '</h2>' + row('Brand', brandWord(b.str)) + row('Units open', b.units) + row('Entry fee', money(fbFee(b))) + row('Royalty', pc(b.roy, 1) + ' of revenue') + row('Marketing fund', pc(b.mkt, 0)) + row('Setup support', ['None, you pay everything', 'They cover about 40%', 'They cover about 70%'][b.supp]) + row('Contract length', b.term + ' years') + row('Typical unit revenue', money(us.rev) + ' /wk') + row('Margin after fees', pc(us.mu, 0)) + row('Units failing in 5 years', b.fail + '%') + row('Quality standard', qualWord(b.std)) + btn('Close', 'sheetclose', undefined, 'ghost wide'));
  };
  ACT.negsend = p => {
    const b = fbBrand(p.b);
    ui.neg.rounds++;
    const prev = Object.assign({}, ui.neg.ask);
    const r = fbNegotiate(b, ui.neg.ask, ui.neg.rounds);
    ui.neg.res = r;
    ui.neg.mark = {};
    if (r.cask) {
      Object.keys(prev).forEach(k => {
        const x = k === 'prem' ? (prev.prem && prev.prem.pid) : prev[k], y = k === 'prem' ? (r.cask.prem && r.cask.prem.pid) : r.cask[k];
        if (x) ui.neg.mark[k] = x === y ? 'ok' : 'no'; else if (y && x !== y) ui.neg.mark[k] = 'no';
      });
      ui.neg.ask = r.cask;
    }
    save();
    render();
  };
  ACT.negsign = p => {
    const b = fbBrand(p.b);
    const a = S.fbApps[b.id];
    a.st = 'agreed';
    a.terms = ui.neg.res.terms;
    a.exp = S.week + 16;
    ui.neg = null;
    if (ui.nc && ui.nc.bd === b.bd) {
      ui.nc.fran = b.id;
      ui.nc.deal = a.terms;
      ui.nc.indep = 0;
      save();
      U.back();
    } else {
      ui.ncPre = { bd: b.bd, fran: b.id, deal: a.terms, country: a.country, city: a.city };
      ui.nc = null;
      save();
      ui.stack = [];
      ui.view = { n: 'newco', p: { bd: b.bd } };
      ui.tab = 'cos';
      render(true);
    }
  };


/* ---------- franchises: apply any time, not only while starting a company ---------- */
  function fbAll() {
    const out = [];
    /* only the brands of trades that are open to you (features/player/trade_unlocks.js) */
    BD_ORDER.filter(id => !window.UNL57 || UNL57.ok(id)).forEach(id => {
      brandsFor(id).forEach(b => {
        const a = (S.fbApps || {})[b.id];
        if (fbStatus(b).ok || (a && ['pending', 'invited', 'agreed'].indexOf(a.st) >= 0)) out.push(b);
      });
    });
    return out;
  }
  function fbAny() {
    try {
      return fbAll().length > 0;
    } catch (e) {
      return false;
    }
  }
  window.fbAny = fbAny;
  window.fbAll = fbAll; /* Group › Franchises counts them */
  V.titles.franchises = 'Franchises';
  V.franchises = function () {
    const L = fbAll();
    if (!L.length) return card('<p class="muted">No brand is looking for franchisees right now.</p>', 'empty');
    let h = '<p class="muted small">Brands that take new franchisees. You apply, they answer in a week or three, then you meet them to agree terms. When terms are agreed you can start the company with them.</p>';
    const by = {};
    L.forEach(b => {
      (by[b.bd] = by[b.bd] || []).push(b);
    });
    Object.keys(by).forEach(id => {
      h += sec(BD[id].n) + by[id].map(b => {
        const a = (S.fbApps || {})[b.id];
        let act = '', sub = fbTn(b) + ' · ' + b.units + ' units';
        if (!a || a.st === 'expired') act = btn('Apply', 'brandapply', { b: b.id, bd: id }, 'chip primary');
    else if (a.st === 'pending') sub = 'Application sent. Answer in about ' + Math.max(1, a.due - S.week) + ' weeks.';
    else if (a.st === 'invited') {
          act = btn('Meet the ' + fbRole(b), 'brandopen', { b: b.id }, 'chip primary');
          sub = 'They want to talk. Open for ' + Math.max(0, a.exp - S.week) + ' more weeks.';
        }
    else if (a.st === 'agreed') {
          act = btn('Start with this deal', 'brandstart', { b: b.id }, 'chip primary') + btn('Talk again', 'brandopen', { b: b.id }, 'chip');
          sub = 'Terms agreed. Entry fee ' + money(a.terms.fee) + ', royalty ' + pc(a.terms.roy, 1) + '.';
        }
        return '<div class="opt"><div class="bhead"><div><b>' + esc(b.name) + '</b><small>' + esc(sub) + '</small></div><div class="rt">' + act + '</div></div></div>';
      }).join('');
    });
    return h;
  };
  ACT.brandstart = p => {
    const b = fbBrand(p.b);
    const a = S.fbApps[b.id];
    ui.ncPre = { bd: b.bd, fran: b.id, deal: a.terms, country: a.country, city: a.city };
    ui.nc = null;
    ui.stack = [];
    ui.view = { n: 'newco', p: { bd: b.bd } };
    ui.tab = 'cos';
    render(true);
  };
})();


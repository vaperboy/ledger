/* ---- ui/screens/providers.js ---- */
(function () {
  'use strict';
  const U = window.UI, { ui, V, ACT, esc, nok, sgn, row, btn, card, chips, go, openSheet, closeSheet, confirmThen, toast, res, render, save } = U;
  const CT = window.CT;
  window.stars = function (r, n) {
    return '<span class="stars" style="--w:' + Math.round(r / 5 * 100) + '%"></span> <b>' + r.toFixed(1) + '</b>' + (n != null ? ' <small>(' + n.toLocaleString('en-US').replace(/,/g, ' ') + ')</small>' : '');
  };
  const KIND = {
    acc: ['Accountant', 'Accountant', 'acc'],
    law: ['Law firm', 'Advokatfirma', 'law'],
    ins: ['Insurance company', 'Forsikringsselskap', 'ins']
  };
  function provRow(a, kind, cur, data) {
    const ini = String(a.name).replace(/[^A-Za-zÀ-ÿ ]/g, ' ').trim().split(/\s+/).slice(0, 2).map(x => x[0]).join('').toUpperCase();
    const acc = kind === 'acc' ? (a.err < 0.05 ? ['High', 'pos'] : a.err < 0.09 ? ['Medium', 'amb'] : ['Low', 'neg']) : null;
    const rows = kind === 'acc' ? row('Accuracy', '<span class="' + acc[1] + '">' + acc[0] + '</span>') + row('Error rate', Math.round(a.err * 100) + '%') : kind === 'law' ? row('Record', a.q > 0.8 ? '<span class="pos">Wins most cases</span>' : a.q > 0.6 ? 'Solid record' : '<span class="amb">Mixed record</span>') : row('Premiums', a.premM < 0.97 ? '<span class="pos">Below market</span>' : a.premM > 1.03 ? '<span class="neg">Above market</span>' : 'Around market') + row('Pays out', a.payM > 0.93 ? '<span class="pos">Reliably</span>' : a.payM > 0.82 ? 'Usually' : '<span class="neg">Reluctantly</span>');
    return '<div class="card offer' + (cur === a.id ? ' on' : '') + '"><div class="cchd"><span class="av">' + esc(ini) + '</span><span class="ctext"><b>' + esc(a.name) + '</b><small>' + stars(a.rating, a.reviews) + '</small></span>' + (a.fee ? '<span class="badge' + (cur === a.id ? ' amber' : '') + '">' + mshort(a.fee) + '/mo</span>' : '') + '</div>' + rows + '<button class="btn wide' + (cur === a.id ? '' : ' primary') + '" data-a="' + data.a + '" data-p="' + esc(JSON.stringify(data.p)) + '">' + (cur === a.id ? 'Current choice' : 'Hire') + '</button></div>';
  }
  function provSheet(co, kind) {
    const pool = poolFor(co.country)[kind] || [];
    const cur = kind === 'acc' ? (co.acc && co.acc.id) : kind === 'law' ? (co.law && co.law.id) : (co.insr && co.insr.id);
    const own = ownFirms(co, kind);
    /* your own firms first, judged on the same numbers as everyone else */
    const mine = own.length ? '<h3>Your own</h3><p class="muted small">' + (kind === 'ins' ? 'The premium is paid to your own insurer, and it pays the claims.' : 'The fee is paid to your own firm, so the money stays in your group.') + '</p><div class="rowlist">' + own.map(o => provRow(ownProv(kind, o), kind, cur, { a: 'ownpick', p: { id: co.id, k: kind, o: o.id } })).join('') + '</div><h3 class="gap">Other providers</h3>' : '';
    openSheet('<h2>' + KIND[kind][0] + '</h2>' + mine + '<p class="muted small">Ratings are from other business owners.</p><div class="rowlist">' + pool.map(a => provRow(a, kind, cur, { a: 'provpick', p: { id: co.id, k: kind, a: a.id } })).join('') + '</div>' + (cur && kind !== 'acc' ? btn('Remove', 'provpick', { id: co.id, k: kind, a: 0 }, 'wide ghost') : '') + btn('Cancel', 'sheetclose', undefined, 'ghost wide'));
  }
  window.provSheet = provSheet;
  ACT.provpick = p => {
    const co = getCo(p.id);
    if (p.k === 'acc') {
      pickAccountant(co, p.a);
      toast('Accountant chosen.');
    } else if (p.k === 'law') {
      if (p.a) pickLaw(co, p.a); else co.law = null;
      toast(p.a ? 'Law firm retained.' : 'Law firm removed.');
    } else {
      if (p.a) pickInsurer(co, p.a); else co.insr = null;
      toast(p.a ? 'Insurer chosen.' : 'Insurer removed.');
    }
    save();
    closeSheet();
  };
  ACT.ownpick = p => {
    pickOwn(getCo(p.id), p.k, getCo(p.o));
    toast('Using your own firm.');
    save();
    closeSheet();
  };
  ACT.provsheet = p => provSheet(getCo(p.id), p.k);
  window.provRow = provRow;
  CT.advisers = function (co) {
    const line = (k, label, cur, effect) => '<div class="opt"><div class="bhead"><div><b>' + label + '</b>' + (cur ? '<small>' + esc(cur.name) + '</small><small>' + stars(cur.rating) + (cur.fee != null && k !== 'ins' ? ' · ' + money(cur.fee) + '/mo' : '') + '</small>' : '<small>' + effect + '</small>') + '</div><div class="rt">' + btn(cur ? 'Change' : 'Choose', 'provsheet', { id: co.id, k: k }, 'chip' + (cur ? '' : ' primary')) + '</div></div></div>';
    return '<div class="card"><h3>Advisers<small>Pick providers by their star rating.</small></h3>' + line('acc', 'Accountant', co.acc, 'Needed for ' + CC().forms.AS.toLowerCase().replace(/ \(.*\)/, '') + 's') + line('law', 'Law firm', co.law, 'Cuts fines and legal costs. Better firms cut more.') + line('ins', 'Insurance company', co.insr, 'Sets premiums and how reliably claims are paid.') + '</div>';
  };
})();


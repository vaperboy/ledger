/* ---- ui/screens/hiring.js ---- */
/* ===== Hiring, round 56: step by step, every step on one screen.
   Workers (V.hire): 1 Terms (role, hours, pay basis, where to look) · 2 Candidates · 3 Offer (a short talk, references,
   a trial week, the offer).
   Management (V.mgrhire, every management role, p.r): 1 Role · 2 Shortlist (always found by the agency) ·
   3 Interview · 4 Offer (a fixed salary; a store manager can also have a monthly profit bonus). Which roles a company
   has, and who fills them, is its headquarters (ui/company/headquarters.js).
   Main office staff (V.hqhire): 1 Role and where to look · 2 Candidates · 3 Offer.
   Whether the hire pays is said in words: a role that is the bottleneck will probably pay for itself. Only with an
   analyst (main office data analyst, or a market analyst in the company) do you hear how sure that is.
   The logic is the game's own: searchWorkers, ACT.offer7 / ACT.offer (patience, meeting in the middle, hours and
   pay basis), refCheck, trialWeek, genManager / ACT.mgrsearch, interview, hireManager, the assistant's hireAsst. ===== */
(function () {
  'use strict';
  const U = window.UI, { ui, V, ACT, esc, btn, render } = U;
  const P = o => esc(JSON.stringify(o));
  const step = (o, k, v) => { (ui[k] = ui[k] || {})[o] = v; };
  const bar = (L, cur, act, id) => '<div class="steps56">' + L.map((x, i) => '<button class="' + (i + 1 === cur ? 'on' : i + 1 < cur ? 'done' : '') + '"' + (i + 1 < cur ? ' data-a="' + act + '" data-p="' + P({ id, s: i + 1 }) + '"' : '') + '><i></i>' + (i + 1) + ' ' + x + '</button>').join('') + '</div>';
  const seg = (items, cur, act, p0) => '<div class="seg56">' + items.map(x => '<button class="' + (x[0] === cur ? 'on' : '') + '" data-a="' + act + '" data-p="' + P(Object.assign({}, p0, { v: x[0] })) + '">' + x[1] + (x[2] ? '<small>' + x[2] + '</small>' : '') + '</button>').join('') + '</div>';
  const tile = (lab, val, sub, go) => { const x = '<span>' + lab + '</span><b>' + val + '</b>' + (sub ? '<small>' + sub + '</small>' : ''); return go ? '<button class="t56" data-a="' + go[0] + '" data-p="' + P(go[1]) + '">' + x + '</button>' : '<div class="t56">' + x + '</div>'; };
  const talk = L => '<div class="talk56 clog">' + L.map(x => '<div class="bub ' + (x.sys ? 'sys' : x.me ? 'me' : 'them') + '">' + esc(x.t) + '</div>').join('') + '</div>';
  const talkOf = id => ((ui.talk = ui.talk || {})[id] = (ui.talk || {})[id] || []);
  const verdict = (ok, t, s) => '<div class="vd56 ' + (ok === true ? 'ok' : ok === false ? 'no' : 'mid') + '"><span>' + (ok === true ? '✓' : ok === false ? '!' : '~') + '</span><div><b>' + t + '</b><small>' + s + '</small></div></div>';
  /* the analyst who can tell how sure: the main office data analyst, or a market analyst in this company */
  function analyst(co) {
    const a = window.R7 && R7.anaInfo ? R7.anaInfo() : null;
    if (a) return a;
    const m = co.staff.find(s => s.role === 'mktan' && S.npcs[s.id]);
    return m ? { name: S.npcs[m.id].name, s: 0.6 } : null;
  }
  const sure = (co, x, scale) => { const p = Math.max(0.03, Math.min(0.97, 0.5 + x / Math.max(1, scale) * 0.6)); return Math.round(p * 20) * 5; };

  /* ---------------- workers ---------------- */
  function workerVerdict(co, role) {
    if (role === 'mktan' && window.R26 && R26.mktanHire) { const m = R26.mktanHire(co); return verdict(m.ok ? null : false, m.t, m.s); }
    const x = window.R23 && R23.hireImpact ? R23.hireImpact(co, role) : null;
    if (!x || co.st !== 'open') return '';
    const nm = ROLES[role][0].toLowerCase(), a = analyst(co);
    const ok = x.full && x.bottleneck ? true : x.newCust > 0.05 ? null : false;
    const t = ok === true ? 'This hire will probably pay for itself' : ok === null ? 'It might pay for itself' : 'It probably does not pay for itself yet';
    let s = ok === true ? 'You are turning customers away and ' + nm + 's are the bottleneck.' : ok === null ? 'A ' + nm + ' brings in some customers of their own.' : x.full ? nm.charAt(0).toUpperCase() + nm.slice(1) + 's are not what limits your sales.' : 'You are not turning customers away now.';
    if (a) s += ' ' + esc(a.name.split(' ')[0]) + ', your analyst, is ' + sure(co, x.net, x.pay) + '% sure it pays.';
    return verdict(ok, t, s);
  }
  V.titles.hire = 'Find workers';
  V.heads = V.heads || {};
  V.heads.hire = p => { const co = p && getCo(p.id), r = ui.hrole && ROLES[ui.hrole] ? ROLES[ui.hrole][0] : 'worker'; return { t: 'Find a ' + r.toLowerCase(), sub: co ? esc(co.name) + ' · Staff' : '' }; };
  ACT.hstep56 = p => { step(p.id, 'hstep', p.s); if (p.s < 3) ui.cand = null; render(true); };
  V.hire = function (p) {
    const co = getCo(p.id), bd = BD[co.type];
    const roles = stdStaff(bd, co.size).map(s => s[0]);
    ui.hrole = ui.hrole && ROLES[ui.hrole] ? ui.hrole : roles[0];
    ui.hmode = ui.hmode || 'network';
    const role = ui.hrole, rn = ROLES[role][0];
    const place = window.R47 && R47.placeFirst ? R47.placeFirst(co) : '';
    const list = ((ui.cands && ui.cands[co.id + ':' + role]) || []).map(id => S.npcs[id]).filter(n => n && !n.hired && !n.gone && !(ui.passed && ui.passed[n.id]));
    const sel = list.find(n => n.id === ui.cand);
    let st = sel ? 3 : ((ui.hstep || {})[co.id] === 2 && list.length ? 2 : 1);
    let h = bar(['Terms', 'Candidates', 'Offer'], st, 'hstep56', co.id);
    if (place) return h + place;
    if (st === 1) {
      const o = window.HK54 ? HK54(co.id) : { k: 'full' }, hh = o.h || (o.k === 'sea' ? 25 : 20);
      h += '<div class="card hs56"><div class="bhead"><b>Role</b><button class="pill" data-a="hrole" data-p="' + P({ id: co.id, v: '_more' }) + '">Other roles ▾</button></div>' + U.chips(roles.filter((r, i) => roles.indexOf(r) === i).map(r => [r, ROLES[r][0]]).concat(roles.indexOf(role) < 0 ? [[role, rn]] : []), role, 'hrole', { id: co.id });
      h += '<span class="lab">Hours</span>' + seg([['full', 'Full time'], ['part', 'Part time'], ['sea', 'Seasonal']], o.k, 'hk54k', { id: co.id });
      if (o.k !== 'full') h += U.chips([10, 15, 20, 25, 30].map(v => [v, v + ' h a week']), hh, 'hk54h', { id: co.id });
      if (o.k === 'sea' && window.R54) { const ms = o.ms || []; h += '<div class="chips">' + R54.SEASONS.map(s => '<button class="btn chip' + (s[2].every(m => ms.indexOf(m) >= 0) ? ' primary' : '') + '" data-a="hk54s" data-p="' + P({ id: co.id, v: s[0] }) + '">' + s[1] + '</button>').join('') + '</div>'; }
      if (o.k === 'full') { const norm = FIX_NORM[role] ? 'fix' : 'hour'; h += '<span class="lab">Pay</span>' + seg([['hour', 'By the hour'], ['fix', 'Fixed salary']], o.basis || norm, 'hk54b', { id: co.id }) + '<small class="muted">Usual for a ' + esc(rn.toLowerCase()) + ': ' + (norm === 'fix' ? 'a fixed salary.' : 'by the hour first, a salary once they stay.') + '</small>'; }
      h += '</div>' + workerVerdict(co, role);
      const cd = Math.max(0, ((S.netCD || {})['w:' + co.id + ':' + role] || 0) - S.week);
      h += '<span class="lab">Where to look</span>' + seg([['network', 'Network', cd ? 'in ' + cd + ' wk' : 'free'], ['ad', 'Job ad', mshort(KC(1500))], ['agency', 'Agency', mshort(KC(12000))]], ui.hmode, 'hmode', { id: co.id });
      h += btn(list.length ? 'Search again' : 'Search', 'hsearch', { id: co.id }, 'primary wide go') + (list.length ? btn('See the ' + list.length + ' you found', 'hstep56', { id: co.id, s: 2 }, 'ghost wide') : '');
      return h;
    }
    if (st === 2) {
      h += '<span class="lab">' + list.length + ' found · tap one</span><div class="lrows cl56">' + list.map(n => {
        const norm = wageFor(n.role, co), tag = n.checked ? 'references checked' : n.age < 25 ? 'young' : n.tier === 'senior' ? 'senior' : 'mid-career';
        return '<button class="lrow" data-a="candopen" data-p="' + P({ n: n.id }) + '">' + faceAv(n) + '<span class="ctext"><b>' + esc(n.name) + ', ' + n.age + '</b><small>Claims ' + n.claimExp + ' yr · ' + esc(claimLabel(n)) + '</small></span><span class="rt56"><b class="' + (norm && n.ask > norm * 1.2 ? 'neg' : norm && n.ask < norm * 0.9 ? 'pos' : '') + '">' + mshort(n.ask) + '</b><small>' + tag + '</small></span></button>';
      }).join('') + '</div>' + btn('Search again', 'hstep56', { id: co.id, s: 1 }, 'ghost wide');
      return h;
    }
    /* 3: offer */
    const n = sel, k = 'w' + n.id, sales = !!SALES_ROLES[n.role], pm = (ui.pay && ui.pay[n.id]) || { m: 'fix', rate: 0.03 };
    const ref = n.checked ? refCheck(n) : null;
    h += '<div class="cand56">' + faceAv(n) + '<div><b>' + esc(n.name) + ', ' + n.age + '</b><small>Claims ' + n.claimExp + ' yr · ' + esc(claimLabel(n)) + (ref ? ' · really ' + esc(ref.skillBand.toLowerCase()) : '') + '</small></div><div class="rt56"><b>' + mshort(n.ask) + '</b><small>asks · ' + (window.patDots ? window.patDots(n) : '') + '</small></div></div>';
    h += talk([{ t: '“' + n.resume + '” I am asking ' + money(n.ask) + ' a month.' }].concat(talkOf(n.id)));
    h += '<div class="t56grid">' + tile('References', n.checked ? (ref.skillBand !== claimLabel(n) ? 'Do not match' : 'Match') : mshort(KC(600)), n.checked ? 'checked' : 'check the claim', n.checked ? null : ['refcheck', { id: co.id, n: n.id }]) +
      tile('Trial week', n.trial ? band56(n.trialRes != null ? n.trialRes : n.skill) : mshort(n.ask / 4), n.trial ? 'how they worked' : 'see them work', n.trial ? null : ['trial', { id: co.id, n: n.id }]) + tile('Profile', 'More', 'cost per year', ['candinfo', { id: co.id, n: n.id }]) + '</div>';
    if (sales) h += seg([['fix', 'Fixed'], ['mix', 'Base + bonus'], ['com', 'Commission']], pm.m, 'pay7', { n: n.id, k: 'm' });
    if (window.carOffer && window.carOffer(co, n)) h += seg([['co', 'Company car'], ['own', 'Own car + mileage']], (ui.carc || {})[n.id] || 'co', 'car7', { n: n.id });
    if (sales && pm.m !== 'fix') h += U.chips([0.01, 0.02, 0.03, 0.05, 0.08, 0.12].map(r => [r, Math.round(r * 100) + '%']), pm.rate, 'pay7', { n: n.id, k: 'rate' });
    else h += '<div class="chips">' + [0.9, 1, 1.05, 1.15].map(f => { const v = rnl(n.ask * f, 100); return '<button class="btn chip' + (rnl(U.inum(k, n.ask), 100) === v ? ' primary' : '') + '" data-a="setinp" data-p="' + P({ k, v }) + '">' + Math.round(f * 100) + '% · ' + mshort(n.ask * f) + '</button>'; }).join('') + '</div>';
    h += '<div class="crow56">' + (sales && pm.m !== 'fix' ? '<span class="muted small">' + (pm.m === 'mix' ? mshort(n.ask * 0.6) + ' fixed + ' : '') + Math.round(pm.rate * 100) + '% of sales</span>' : U.inp(k, 'Monthly pay', n.ask)) + btn('Send', 'offer7', { id: co.id, n: n.id }, 'primary') + btn('Pass', 'candpass', { n: n.id }, 'ghost') + '</div>';
    return h;
  };
  const band56 = v => v >= 80 ? 'Outstanding' : v >= 65 ? 'Strong' : v >= 45 ? 'Capable' : v >= 28 ? 'Developing' : 'Entry level';

  /* ---------------- management: every management role, always through the agency ----------------
     p.r is the role: 'mgr' (the company's own manager) and 'asst' (assistant manager) keep their own search and hire
     (ui/company/people.js, features/people/owner_hours_clients_assistants.js); the management team registers its
     roles in MR56 (features/people/management_team.js: 'ceo' managing director of the company, department heads,
     'reg' regional manager), and so do the levels of a chain (features/company/org_chart.js: 'md' for the whole
     group, 'ceo56', 'chainmgr', 'region' with p.ch and p.city). A role: { t(co, p) title, d(co, p) what they do,
     fee(co, p), me: paid from your own account, gen(co, p) a candidate, hire(co, n, wage, p) }. ===== */
  const MR = window.MR56 = window.MR56 || {};
  const R5 = () => window.R5m || { typeFit: () => 1, mgrStyle: () => null };
  const prof3 = co => { const H = (co.hist || []).slice(-3); return H.length ? H.reduce((a, x) => a + (x.profit || 0), 0) / H.length : 0; };
  function mgrVerdict(co) {
    const cost = window.mgrCostHint ? mgrCostHint(co) : 0, pr = prof3(co), a = analyst(co);
    const ok = pr >= cost * 1.2 ? true : pr >= 0 ? null : false;
    let s = ok === true ? 'It earns enough to carry a manager.' : ok === null ? 'A manager costs about what it earns now, unless they grow sales.' : 'It earns less than a manager costs, unless they grow sales.';
    if ((co.ohrs || 0) > 0) s += ' Frees your ' + co.ohrs + ' h a week.';
    if (a) s += ' ' + esc(a.name.split(' ')[0]) + ' is ' + sure(co, pr - cost * 0.5, cost) + '% sure it pays.';
    return verdict(ok, ok === true ? 'It can carry a manager' : ok === null ? 'Tight' : 'It may not carry a manager', s);
  }
  window.HIRE56 = { mgrVerdict };
  const own = r => r === 'mgr' || r === 'asst';
  /* who the store manager reports to: the first level above them (engine/management/managers.js chainOf), or you */
  const upName = co => { const u = typeof chainOf === 'function' ? chainOf(co).find(x => x.kind !== 'mgr') : null; return u ? u.npc.name + ', ' + titleLow(titleFor(co, u.kind)) : 'you'; };
  const coOf = p => getCo(p.id) || (p.ch && window.R12 && R12.chainById(p.ch) ? R12.storesOf(R12.chainById(p.ch))[0] : null) || null;
  const keyOf = p => own(p.r) ? p.id : p.r + ':' + (p.id || 0) + ':' + (p.ch || '') + ':' + (p.city || '');
  const titleOf = (co, p) => p.r === 'asst' ? 'Assistant manager' : p.r === 'mgr' ? titleFor(co, 'mgr') : MR[p.r] ? MR[p.r].t(co, p) : 'Management';
  const listOf = (co, p) => p.r === 'asst' ? (((ui.asstC || {})[co.id]) || []).map(id => S.npcs[id]).filter(n => n && !n.hired)
    : p.r === 'mgr' ? (((ui.mgrC || {})[co.id]) || []).map(id => S.npcs[id]).filter(n => n && n.stats && !n.hired)
    : (((ui.mc56 || {})[keyOf(p)]) || []).map(id => S.npcs[id]).filter(n => n && !n.hired);
  const selOf = p => p.r === 'asst' ? ui.acand : p.r === 'mgr' ? ui.mcand : ui.gcand;
  V.titles.mgrhire = 'Management';
  V.heads.mgrhire = p => { const co = coOf(p || {}); p = Object.assign({ r: 'mgr' }, p); const ch = p.ch && window.R12 ? R12.chainById(p.ch) : null; return { t: co || p.r === 'md' ? titleOf(co, p) : 'Management', sub: ch ? esc(ch.name) + (p.city ? ' · ' + esc(cityOf(p.city).name) : '') : p.r === 'md' ? 'The whole group' : co ? esc(co.name) + ' · Management' : '' }; };
  ACT.mstep56 = p => { step(p.id, 'mstep', p.s); if (p.s < 3) { ui.mcand = null; ui.acand = null; ui.gcand = null; } if (p.s !== 4) step(p.id, 'moffer', 0); render(true); };
  ACT.mb56 = p => { (ui.mb56 = ui.mb56 || {})[p.n] = p.v; render(); };
  ACT.moffer56 = p => { step(p.id, 'moffer', 1); render(true); };
  ACT.gcandopen = p => { ui.gcand = p.n; render(true); };
  V.mgrhire = function (p0) {
    const p = Object.assign({ r: 'mgr' }, p0), r = p.r, co = coOf(p), K = keyOf(p), asst = r === 'asst', R = MR[r];
    if (!own(r) && !R) return '<div class="calm">This role is not open.</div>';
    if (!co && !(R && R.me)) return '<div class="calm">This company is no longer yours.</div>';
    const place = own(r) && window.R47 && R47.placeFirst ? R47.placeFirst(co) : '';
    const title = titleOf(co, p), list = listOf(co, p), sel = list.find(n => n.id === selOf(p));
    const st = sel ? ((ui.moffer || {})[K] ? 4 : 3) : ((ui.mstep || {})[K] === 2 && list.length ? 2 : 1);
    let h = bar(['Role', 'Shortlist', 'Interview', 'Offer'], st, 'mstep56', K);
    if (place) return h + place;
    const F = R5().typeFit, bd = co ? BD[co.type] : null;
    if (st === 1) {
      ui.mtype = ui.mtype || {};
      h += '<div class="card hs56"><span class="lab">The role</span><b class="big56">' + esc(title) + '</b><small class="muted">' + (asst ? 'Takes up to two jobs off the plate of whoever runs it: complaints, paperwork and insurance, or equipment and stock.' : r === 'mgr' ? 'Runs it day to day: hires, prices, stock, IT security, insurance and the premises, within what you allow. Reports to ' + esc(window.aboveMgrName ? aboveMgrName(co) : 'you') + '.' : esc(R.d(co, p))) + '</small>';
      if (r === 'mgr') { const t = ui.mtype[co.id] || bd.mgr; h += '<span class="lab">Looking for</span>' + U.ddown(Object.keys(MGR_TYPES).sort((a, b) => F(co, b) - F(co, a)).map(x => [x, MGR_TYPES[x] + ' · fit ' + Math.round(F(co, x) * 100) + '%']), t, 'mtypeset', { id: co.id }); }
      h += '</div>' + (r === 'mgr' ? mgrVerdict(co) : '');
      const fee = asst ? KC(2500) : r === 'mgr' ? KC(15000) : R.fee ? R.fee(co, p) : KC(15000);
      h += '<div class="box56"><span>The agency finds them' + (R && R.me ? ', paid by you' : '') + '</span><b>' + mshort(fee) + ' a search</b></div>' + btn(list.length ? 'Ask the agency again' : 'Ask the agency', asst ? 'asstsearch56' : r === 'mgr' ? 'mgrsearch56' : 'msearch56', p, 'primary wide go') + (list.length ? btn('See the shortlist', 'mstep56', { id: K, s: 2 }, 'ghost wide') : '');
      return h;
    }
    const sub = n => r === 'mgr' ? esc(MGR_TYPES[n.mtype] || 'Manager') + ' · ' : R && R.st ? esc(R.st[1]) + ' ' + ((n.claimed || n.stats)[R.st[0]] || 55) + ' on the CV · ' : '';
    if (st === 2) {
      h += '<span class="lab">The agency’s shortlist · tap one</span><div class="lrows cl56">' + list.map(n => '<button class="lrow" data-a="' + (asst ? 'acandopen' : r === 'mgr' ? 'mcandopen' : 'gcandopen') + '" data-p="' + P({ n: n.id }) + '">' + faceAv(n) + '<span class="ctext"><b>' + esc(n.name) + ', ' + n.age + '</b><small>' + sub(n) + n.exp + ' yr experience</small></span><span class="rt56"><b>' + mshort(n.ask) + '</b>' + (r === 'mgr' ? '<small class="' + (F(co, n.mtype) >= 0.9 ? 'pos' : 'amb') + '">fit ' + Math.round(F(co, n.mtype) * 100) + '%</small>' : '<small>a month</small>') + '</span></button>').join('') + '</div>' + btn('Back to the role', 'mstep56', { id: K, s: 1 }, 'ghost wide');
      return h;
    }
    const n = sel, k = 'm' + n.id;
    n.qLeft = n.qLeft == null ? 3 : n.qLeft;
    h += '<div class="cand56">' + faceAv(n) + '<div><b>' + esc(n.name) + ', ' + n.age + '</b><small>' + (r === 'mgr' ? esc(MGR_TYPES[n.mtype] || 'Manager') + ' · fit ' + Math.round(F(co, n.mtype) * 100) + '%' : esc(title)) + ' · ' + n.exp + ' yr</small></div><div class="rt56"><b>' + mshort(n.ask) + '</b><small>asks</small></div></div>';
    if (st === 3) {
      const asked = MQ.filter(x => n.q && n.q[x[0]] != null), left = MQ.filter(x => !(n.q && n.q[x[0]] != null)), sty = R5().mgrStyle(n);
      const msgs = [{ t: 'Hi. ' + n.resume + ' I am asking ' + money(n.ask) + ' a month.' }];
      asked.forEach(x => { msgs.push({ me: 1, t: QTXT[x[0]][0].replace(/[“”]/g, '') }); msgs.push({ t: answerText(x[0], n.q[x[0]]) }); });
      if (n.ref) msgs.push({ sys: 1, t: 'References checked: the CV holds up.' });
      h += talk(msgs.concat(talkOf(n.id)));
      if (sty) h += '<div class="sty56">' + sty.map(x => '<span><small>' + x[0] + '</small> ' + esc(x[1]) + '</span>').join('') + '</div>';
      h += '<span class="lab">Ask · ' + n.qLeft + ' left</span><div class="qs56">' + (n.qLeft > 0 ? left.map(x => '<button data-a="mgrask" data-p="' + P({ n: n.id, k: x[0] }) + '">' + esc(QTXT[x[0]][0].replace(/[“”]/g, '')) + '</button>').join('') : '<span class="muted small">No questions left.</span>') + '</div>';
      h += '<div class="crow56">' + (n.ref ? '' : btn('References · ' + mshort(KC(2500)), 'mgrref', { id: co ? co.id : 0, n: n.id }, 'ghost')) + btn('Make an offer', 'moffer56', { id: K }, 'primary') + '</div>';
      return h;
    }
    /* 4: offer: a fixed salary, or (a store manager) a salary plus a share of the monthly profit */
    const b = (ui.mb56 && ui.mb56[n.id]) || 0, mix = r === 'mgr' && b > 0;
    if (r === 'mgr') h += '<span class="lab">Pay</span>' + seg([[0, 'Fixed salary'], [0.05, 'Salary + profit bonus']], b > 0 ? 0.05 : 0, 'mb56', { n: n.id }) + (mix ? U.chips([[0.02, '2% of profit'], [0.05, '5%'], [0.1, '10%']], b, 'mb56', { n: n.id }) + '<small class="muted">Paid each month there is a profit, on top of the salary. ' + ((window.bonusWorth ? bonusWorth(co, b) : 0) > 0 ? 'They count it as about ' + mshort(bonusWorth(co, b)) + ' a month at recent profit.' : 'Recent months made no profit, so they count it as nothing for now: the salary has to do.') + '</small>' : '');
    h += '<div class="chips">' + [0.95, 1, 1.1].map(f => { const v = rnl(n.ask * f, 500); return '<button class="btn chip' + (rnl(U.inum(k, n.ask), 500) === v ? ' primary' : '') + '" data-a="setinp" data-p="' + P({ k, v }) + '">' + Math.round(f * 100) + '% · ' + mshort(n.ask * f) + '</button>'; }).join('') + '</div>';
    h += '<div class="crow56">' + U.inp(k, mix ? 'Monthly salary' : 'Salary a month', n.ask) + btn(asst ? 'Offer' : 'Hire', asst ? 'asstgo' : r === 'mgr' ? 'mgrhirego' : 'mhire56', Object.assign({}, p, { id: own(r) ? co.id : p.id, n: n.id }), 'primary') + btn('Back', 'mstep56', { id: K, s: 3 }, 'ghost') + '</div>';
    if (talkOf(n.id).length) h += talk(talkOf(n.id).slice(-2));
    return h;
  };
  /* the searches lead to the shortlist */
  ACT.mgrsearch56 = p => { ACT.mgrsearch(p); step(p.id, 'mstep', 2); render(true); };
  ACT.asstsearch56 = p => { ACT.asstsearch(p); step(p.id, 'mstep', 2); render(true); };
  ACT.msearch56 = p => {
    const R = MR[p.r], co = coOf(p);
    if (!R) return;
    const t = titleOf(co, p), fee = R.fee ? R.fee(co, p) : KC(15000);
    if (R.me) { if (S.cash < fee) { U.res('cash'); return; } payMe(fee, 'Executive search: ' + t); }
    else { if (co.cash < fee && liquid() < fee) { toast('Not enough cash for the search.', true); return; } payCo(co, fee, 'oth', 'Executive search: ' + t); }
    (ui.mc56 = ui.mc56 || {})[keyOf(p)] = [0, 1, 2].map(() => { const n = R.gen(co, p); S.npcs[n.id] = n; return n.id; });
    ui.gcand = null;
    step(keyOf(p), 'mstep', 2);
    save();
    render(true);
  };
  /* a fair offer is taken; below what they ask, the closer it is the likelier (as for a store manager) */
  ACT.mhire56 = p => {
    const R = MR[p.r], co = coOf(p), n = S.npcs[p.n];
    if (!R || !n || n.hired) return;
    const w = rnl(U.inum('m' + n.id, n.ask), 500), t = titleOf(co, p), L = talkOf(n.id);
    L.push({ me: 1, t: 'I can offer ' + money(w) + ' a month.' });
    if (w < n.ask && !chance(clamp((w / n.ask - 0.88) / 0.14, 0, 1))) { L.push({ t: 'That is below what I earn today. Could you come closer to ' + money(n.ask) + '?' }); render(); return; }
    const r = R.hire(co, n, w, p);
    if (r !== 'ok') { U.res(r); return; }
    if (ui.mc56) delete ui.mc56[keyOf(p)];
    ui.gcand = null;
    step(keyOf(p), 'mstep', 1);
    addMsg({ kind: 'info', from: n.name, role: t, title: 'Starting as ' + titleLow(t), body: 'Thank you for the trust. I start on Monday.', co: co ? co.id : null, tone: 'good', status: 'done', ch: 'msg' });
    save();
    toast(n.name + ' starts as ' + titleLow(t) + '.');
    ACT.back();
  };

  /* ---------------- the main office: 1 Role and where to look · 2 Candidates · 3 Offer ---------------- */
  const NETCD = 4;
  V.titles.hqhire = 'Main office';
  V.heads.hqhire = p => ({ t: hqRole(p.r) ? (p.r === 'pa' ? 'Personal assistant' : hqRole(p.r)[0]) : 'Main office', sub: 'Main office · ' + esc(officeTier() ? officeTier().n : '') });
  ACT.hirehq = p => { const r = hqRoom(p.r); if (r !== 'ok') { U.res(r); return; } ui.hqC = null; ui.hqcand = null; ui.hqmode = ui.hqmode || 'network'; step('hq', 'hqstep', 1); U.go('hqhire', { r: p.r }); };
  ACT.hqmode = p => { ui.hqmode = p.v; render(); };
  ACT.hqstep56 = p => { step('hq', 'hqstep', p.s); if (p.s < 3) ui.hqcand = null; render(true); };
  ACT.hqcandopen = p => { ui.hqcand = p.n; render(true); };
  V.hqhire = function (p) {
    const role = hqRole(p.r);
    if (!role) return '<div class="calm">This role is not open.</div>';
    ui.hqmode = ui.hqmode || 'network';
    const list = (ui.hqC || []).map(id => S.npcs[id]).filter(n => n && !n.hired), sel = list.find(n => n.id === ui.hqcand);
    const st = sel ? 3 : ((ui.hqstep || {}).hq === 2 && list.length ? 2 : 1);
    let h = bar(['Role', 'Candidates', 'Offer'], st, 'hqstep56', 'hq');
    if (st === 1) {
      const cd = Math.max(0, ((S.netCD || {})['hq:' + p.r] || 0) - S.week);
      h += '<div class="card hs56"><span class="lab">The role</span><b class="big56">' + esc(p.r === 'pa' ? 'Personal assistant · your right hand' : role[0]) + '</b><small class="muted">' + esc(role[2]) + '</small><span class="lab">Usual pay</span><b>~' + money(rl(role[1] * fameSalary())) + ' a month</b><small class="muted">You are ' + esc(fameLabel()) + ': better known, better people, higher asks.</small></div>';
      h += '<span class="lab">Where to look</span>' + seg([['network', 'Network', cd ? 'in ' + cd + ' wk' : 'free'], ['ad', 'Job ad', mshort(KC(1500))], ['agency', 'Agency', mshort(KC(12000))]], ui.hqmode, 'hqmode', {});
      h += btn(list.length ? 'Search again' : 'Search', 'hqsearch', { r: p.r }, 'primary wide go') + (list.length ? btn('See the ' + list.length + ' you found', 'hqstep56', { s: 2 }, 'ghost wide') : '');
      return h;
    }
    if (st === 2) {
      h += '<span class="lab">' + list.length + ' found · tap one</span><div class="lrows cl56">' + list.map(n => '<button class="lrow" data-a="hqcandopen" data-p="' + P({ n: n.id }) + '">' + faceAv(n) + '<span class="ctext"><b>' + esc(n.name) + ', ' + n.age + '</b><small>Claims ' + n.claimExp + ' yr · ' + esc(claimLabel(n)) + '</small></span><span class="rt56"><b>' + mshort(n.ask) + '</b><small>' + (n.checked ? 'references checked' : n.tier === 'senior' ? 'senior' : n.tier === 'young' ? 'young' : 'mid-career') + '</small></span></button>').join('') + '</div>' + btn('Search again', 'hqstep56', { s: 1 }, 'ghost wide');
      return h;
    }
    const n = sel, k = 'h' + n.id, ref = n.checked ? refCheck(n) : null;
    h += '<div class="cand56">' + faceAv(n) + '<div><b>' + esc(n.name) + ', ' + n.age + '</b><small>Claims ' + n.claimExp + ' yr · ' + esc(claimLabel(n)) + (ref ? ' · really ' + esc(ref.skillBand.toLowerCase()) : '') + '</small></div><div class="rt56"><b>' + mshort(n.ask) + '</b><small>asks</small></div></div>';
    h += talk([{ t: '“' + n.resume + '” I am asking ' + money(n.ask) + ' a month.' }].concat(talkOf(n.id)));
    h += '<div class="t56grid">' + tile('References', n.checked ? (ref.skillBand !== claimLabel(n) ? 'Do not match' : 'Match') : mshort(KC(600)), n.checked ? 'checked' : 'check the claim', n.checked ? null : ['hqref', { n: n.id }]) + tile('Cost per year', mshort(U.inum(k, n.ask) * 12 * (1 + CC().empNI)), 'with employer tax') + '</div>';
    h += '<div class="chips">' + [0.9, 1, 1.05, 1.15].map(f => { const v = rnl(n.ask * f, 100); return '<button class="btn chip' + (rnl(U.inum(k, n.ask), 100) === v ? ' primary' : '') + '" data-a="setinp" data-p="' + P({ k, v }) + '">' + Math.round(f * 100) + '% · ' + mshort(n.ask * f) + '</button>'; }).join('') + '</div>';
    h += '<div class="crow56">' + U.inp(k, 'Monthly pay', n.ask) + btn('Send', 'hqoffer', { r: p.r, n: n.id }, 'primary') + btn('Pass', 'hqstep56', { s: 2 }, 'ghost') + '</div>';
    return h;
  };
  ACT.hqsearch = p => {
    const c = KC(ui.hqmode === 'ad' ? 1500 : ui.hqmode === 'agency' ? 12000 : 0);
    if (ui.hqmode === 'network') {
      const cd = Math.max(0, ((S.netCD || {})['hq:' + p.r] || 0) - S.week);
      if (cd) { toast('Your network has nobody new for ' + cd + (cd > 1 ? ' weeks' : ' week') + '. Try a job ad or an agency.', true); return; }
      (S.netCD = S.netCD || {})['hq:' + p.r] = S.week + NETCD;
    }
    if (c && S.cash < c) { toast('Not enough cash.', true); return; }
    if (c) payMe(c, 'Recruiting');
    ui.hqC = searchWorkers(null, 'hq_' + p.r, ui.hqmode).map(n => n.id);
    ui.hqcand = null;
    step('hq', 'hqstep', 2);
    save();
    render(true);
  };
  ACT.hqref = p => {
    if (S.cash < KC(600)) { toast('Not enough cash.', true); return; }
    payMe(KC(600), 'Reference check');
    const n = S.npcs[p.n];
    n.checked = 1;
    const ref = refCheck(n);
    talkOf(n.id).push({ sys: 1, t: 'References: real level ' + ref.skillBand + ', ' + ref.exp + ' yr experience' + (ref.skillBand !== claimLabel(n) ? '. The CV does not match.' : '. Matches the CV.') });
    save();
    render();
  };
  ACT.hqoffer = p => {
    const n = S.npcs[p.n], w = rnl(U.inum('h' + n.id, n.ask), 100), L = talkOf(n.id);
    L.push({ me: 1, t: 'I can offer ' + money(w) + ' a month.' });
    const r = hireHQnpc(p.r, n, w);
    if (r === 'ok') {
      toast(n.name + ' accepted. Complete the paperwork at the main office.');
      ui.hqC = null; ui.hqcand = null;
      ACT.back();
      save();
    } else if (r === 'refuse') { L.push({ t: 'That is less than I hoped for. Could you come closer to ' + money(n.ask) + '?' }); render(); } else U.res(r);
  };
})();

/* ---- ui/screens/review.js ---- */
(function () {
  'use strict';
  const U = window.UI, { ui, V, ACT, esc, nok, sgn, bar, row, btn, card, sec, chips, go, toast, res, render, save, confirmThen } = U;
  V.titles.managers = 'Reviews';
  const verdict = s => s >= 80 ? 'Excellent' : s >= 65 ? 'Good' : s >= 50 ? 'Acceptable' : s >= 35 ? 'Weak' : 'Poor';
  function revCard(co, r, live) {
    if (!r) return '';
    return '<div class="card"><div class="bhead"><div><h3>' + esc(co.name) + '</h3><small>' + esc(r.mgr) + ' · ' + Math.floor(r.tenure / 52) + ' yr ' + (r.tenure % 52) + ' wk in role</small></div><div class="rt"><b>' + verdict(r.score) + '</b></div></div>' + bar(r.score, r.score >= 65 ? 'var(--green)' : r.score < 40 ? 'var(--red)' : 'var(--blue)') +
    row(co.form === 'ENK' ? 'Your pay before tax, share of sales (3 months)' : 'Profit margin (3 months)', r.hasHist ? '<span class="' + sgn(r.margin) + '">' + Math.round(r.margin * 100) + '%</span>' : '–') + row('Reputation', repWord(r.rep)) + row('Quality', qualWord(r.q)) + row('Costly mistakes', r.mist) + row('Staff with open paperwork', r.paper) + (r.fraud ? row('Unexplained costs', '<span class="neg">' + nok(r.fraud) + '</span>') : '') + row('Salary', nok(r.wage) + ' / month') +
    '<p class="muted small">Reviewed ' + dateStr(r.w) + (live ? '' : ' (' + (S.week - r.w) + ' weeks ago)') + '.</p>' + btn(live ? 'Review now' : 'External review · {m:25000}', 'reviewnow', { id: co.id }, 'chip') + '</div>';
  }
  V.managers = function () {
    const an = hasHQ('perf');
    const L = S.cos.filter(c => (c.st === 'open' || c.st === 'closed') && c.mgr);
    let h = '';
    if (!an) h += card('<h3>No performance analyst</h3><p class="muted small">With a performance analyst in your office, every manager gets a scorecard each month and you can review any of them whenever you like. Without one you can order an external review per manager for ' + money(KC(25000)) + '.' + (hqUnlocked('perf') ? '' : ' Analysts open up when you run ' + hqUnlockText('perf') + '.') + '</p>' + (hqUnlocked('perf') ? btn('Open office', 'go', { n: 'office', p: {} }, 'wide') : ''));
  else h += card('<h3>Performance analyst on staff</h3>' + chips([[1, 'Monthly scorecards'], [0, 'Only when I ask']], (S.office.perfAuto === false ? 0 : 1), 'perfauto') + btn('Review all now', 'reviewall', undefined, 'wide'));
    if (!L.length) return h + card('<p class="muted">No company has a manager yet.</p>');
    L.sort((a, b) => ((b.lastRev ? b.lastRev.score : -1) - (a.lastRev ? a.lastRev.score : -1)));
    L.forEach(co => {
      const r = an ? (co.lastRev && S.week - co.lastRev.w < 4 ? co.lastRev : runReview(co)) : co.lastRev;
      h += r ? revCard(co, r, an) : card('<h3>' + esc(co.name) + '</h3><p class="muted small">Manager ' + esc(S.npcs[co.mgr].name) + '. Not reviewed yet.</p>' + btn('External review · {m:25000}', 'reviewnow', { id: co.id }, 'chip'));
    });
    return h;
  };
  ACT.perfauto = p => {
    S.office.perfAuto = !!p.v;
    save();
    render();
  };
  ACT.reviewall = () => {
    S.cos.filter(c => c.mgr && (c.st === 'open' || c.st === 'closed')).forEach(runReview);
    save();
    render();
  };
  ACT.reviewnow = p => {
    const co = getCo(p.id);
    if (!hasHQ('perf')) {
      if (S.cash < KC(25000)) {
        toast('Not enough cash.', true);
        return;
      }
      payMe(KC(25000), 'External manager review');
    }
    runReview(co);
    save();
    render();
  };
})();


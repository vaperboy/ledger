/* ---- ui/screens/start.js ---- */
/* ===== The start screen (profile creator), round 56. Everything fits on one screen:
   - your name, and your age (− and + or type it)
   - Country: one row, guessed from your phone's language when that country is open to you; if it is Pro and Pro is
     off, nothing is picked and the row asks you to choose. Tapping it opens a list: Suggested are the free countries
     (features/player/pro.js PRO.FREE_CC: the UK, the US, Germany and France); every other country is Pro, grouped by
     region (the country packs' region) with the regions and the countries in them by population, largest first.
     A search box filters the list by country, currency or city.
   - City: one row; tapping it opens the same kind of list with the country's cities, largest first.
   - Your story: heir, laid off, student, investor's kid or the start-up loan (features/player/life_stories.js)
   - the chosen country at a glance: wages, company tax, VAT and the start-up loan
   Start playing checks the city belongs to the country and that the country is open to you (Pro). ===== */
(function () {
  'use strict';
  const U = window.UI, { ui, V, ACT, esc, nok, btn, openSheet, closeSheet, render } = U;
  const P = o => esc(JSON.stringify(o));
  const AGE_START = 25;

  /* the country of the phone's language, if the game has it */
  function guessCountry() {
    try {
      const ls = (navigator.languages || [navigator.language || '']).join(',');
      const m = ls.match(/-([A-Za-z]{2})\b/g) || [];
      for (let i = 0; i < m.length; i++) {
        let c = m[i].slice(1).toUpperCase();
        if (c === 'GB') c = 'UK';
        if (CO[c]) return c;
      }
      const L = { nb: 'NO', nn: 'NO', no: 'NO', sv: 'SE', pl: 'PL', lt: 'LT', de: 'DE', fr: 'FR', es: 'ES', nl: 'NL', ja: 'JP', ko: 'KR', pt: 'BR', it: 'IT', da: 'DK', fi: 'FI', ga: 'IE' };
      const l = (navigator.language || '').slice(0, 2).toLowerCase();
      if (L[l] && CO[L[l]]) return L[l];
    } catch (e) { }
    return CO.US ? 'US' : CO_ORDER[0];
  }
  const free = () => Object.keys(window.PRO ? PRO.FREE_CC : {}).filter(k => CO[k]);
  const open = k => !window.PRO || PRO.ccOk(k);
  const proTag = k => window.PRO && !PRO.FREE_CC[k] ? '<i class="pro56">Pro</i>' : '';
  const loanOf = c => c.cur + ' ' + nfmt(Math.round(c.loan / c.fx / 1000) * 1000);
  const nfmt = n => String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
  const pct = x => Math.round(x * 1000) / 10 + '%';
  const level = x => x >= 1.15 ? 'Very high' : x >= 0.9 ? 'High' : x >= 0.6 ? 'Medium' : 'Low';
  const people = k => { const p = CO[k].pop || 0; return (p >= 10 ? Math.round(p) : Math.round(p * 10) / 10) + ' M people'; };
  const cityPeople = n => n >= 1000 ? (Math.round(n / 100) / 10) + ' M people' : n >= 50 ? Math.round(n) + ' k people' : 'Small place';
  const cityRent = (r, top) => r >= top * 0.85 ? 'high rent' : r >= top * 0.6 ? 'medium rent' : 'low rent'; /* next to the dearest city */
  const town = x => /^small/.test(x.id);

  /* ---------- the screen ---------- */
  V.start = function () {
    /* the phone's country is picked when it is open to you; a Pro country is not: then you choose (ui.scAsk) */
    if (!ui.sc && !ui.scAsk) { const g = guessCountry(); ui.scGuess = g; if (open(g)) ui.sc = g; else ui.scAsk = 1; }
    const c = CO[ui.sc];
    if (ui.age == null) ui.age = AGE_START;
    if (ui.inp.age == null) ui.inp.age = String(ui.age);
    let h = '<div class="splash st2 st56"><div>' +
      '<div class="eyebrow">Ledger · Business Tycoon Simulator</div><h1 class="hero">Build companies, hire people, invest.</h1>' +
      '<div class="card">' + U.inp('name', 'Your name', null, 'text') +
      '<div class="agerow"><span class="lab">Age</span><div class="step56"><button data-a="age56" data-p="-1" aria-label="Younger">−</button><input type="number" inputmode="numeric" data-k="age" value="' + esc(ui.inp.age) + '" aria-label="Age"><button data-a="age56" data-p="1" aria-label="Older">+</button></div></div>';
    if (!c) {
      const g = CO[ui.scGuess];
      h += '<button class="pick56 ask56" data-a="ccsheet"><span class="fl">🌍</span><span class="t"><span>Country</span><b>Choose where you start</b></span><i>›</i></button>' +
        (g ? '<span class="hint56 pro">Your phone says ' + esc(g.name) + ', which is part of Pro. Pick a free country, or unlock Pro to start there.</span>' : '') + '</div>' +
        '<div class="stbtns">' + btn('Choose a country', 'ccsheet', undefined, 'primary wide go');
    } else {
      setCtx({ country: ui.sc });
      const city = c.cities.find(x => x.id === ui.city) || c.cities[0];
      ui.city = city.id;
      h += '<button class="pick56" data-a="ccsheet"><span class="fl">' + c.flag + '</span><span class="t"><span>Country</span><b>' + esc(c.name) + ' · ' + esc(c.cur) + '</b></span>' + proTag(ui.sc) + '<i>›</i></button>' +
        '<button class="pick56" data-a="citysheet"><span class="fl">📍</span><span class="t"><span>City</span><b>' + esc(city.name) + '</b></span><i>›</i></button>' +
        (window.STORY57 ? '<button class="pick56" data-a="storysheet"><span class="fl">📖</span><span class="t"><span>Your story</span><b>' + esc(STORY57.get(ui.story || 'loan')[1]) + '</b></span><i>›</i></button>' : '') +
        (ui.sc === ui.scGuess ? '<span class="hint56">Picked from your phone’s language. Tap Country to change it.</span>' : '') + '</div>' +
        '<div class="card glance56"><span class="sec">' + esc(c.name) + ' at a glance</span><div class="kv56"><div><span>Wages</span><b>' + level(c.wage) + '</b></div><div><span>Company tax</span><b>' + pct(c.corp) + '</b></div><div><span>VAT</span><b>' + pct(c.vat.std) + '</b></div></div><small class="muted">Start-up loan ' + loanOf(c) + ' over ' + c.loanTermM / 12 + ' years.</small></div>' +
        '<div class="stbtns">' + btn(open(ui.sc) ? 'Start playing' : 'Unlock ' + c.name + ' with Pro', 'startgame', undefined, 'primary wide go');
      setCtx(null);
    }
    return h + (window.R56saves && R56saves.any() ? btn('Back to the menu', 'menuback', undefined, 'ghost wide') : btn('Load from a file', 'loadfile', undefined, 'ghost wide')) + '</div></div></div>';
  };
  ACT.age56 = d => {
    const now = parseInt(ui.inp.age, 10);
    ui.age = Math.max(U.AGE0, Math.min(U.AGE1, (isFinite(now) ? now : ui.age || AGE_START) + (+d || 0)));
    ui.inp.age = String(ui.age);
    render();
  };

  /* ---------- the lists ---------- */
  const li = (a, p, on, flag, name, sub, right, search) => '<button class="li56' + (on ? ' on' : '') + '" data-a="' + a + '" data-p="' + P(p) + '"' + (search ? ' data-s="' + esc(search.toLowerCase()) + '"' : '') + '><span class="fl">' + flag + '</span><span class="t"><b>' + esc(name) + '</b><small>' + sub + '</small></span>' + (right || '') + (on ? '<span class="ok56">✓</span>' : '') + '</button>';
  const words = k => { const c = CO[k]; return [c.name, c.cur, k].concat(c.cities.map(x => x.name)).join(' ').toLowerCase(); };
  const countryRow = (k, r) => { const c = CO[k]; return li('setcountry', { v: k }, k === ui.sc, c.flag, c.name, esc(c.cur) + ' · ' + people(k), '', words(k)).replace('class="li56', 'data-r56="' + esc(r) + '" class="li56'); };
  ACT.ccsheet = () => {
    const fr = free(), rest = CO_ORDER.filter(k => fr.indexOf(k) < 0);
    const G = {};
    rest.forEach(k => { const r = CO[k].region || 'Other'; (G[r] = G[r] || []).push(k); });
    const pop = k => CO[k].pop || 0;
    const regs = Object.keys(G).sort((a, b) => G[b].reduce((s, k) => s + pop(k), 0) - G[a].reduce((s, k) => s + pop(k), 0));
    let h = '<h2>Where do you start?</h2><div class="srch56"><input class="inp" type="search" data-flt56 placeholder="Search country, currency or city"></div>';
    h += '<div class="list56"><div class="grp56" data-g56="free">Suggested · free</div><div class="sug56" data-g56="free">' + fr.map(k => '<button class="' + (k === ui.sc ? 'on' : '') + '" data-a="setcountry" data-p="' + P({ v: k }) + '" data-s="' + esc(words(k)) + '" data-r56="free"><span class="fl">' + CO[k].flag + '</span>' + esc(k === 'UK' ? 'UK' : k === 'US' ? 'USA' : CO[k].name) + '</button>').join('') + '</div>';
    h += '<div class="grp56 pro" data-g56="' + esc(regs.join('|')) + '">Pro</div>';
    regs.forEach(r => { h += '<div class="sub56" data-g56="' + esc(r) + '">' + esc(r) + '</div>' + G[r].sort((a, b) => pop(b) - pop(a)).map(k => countryRow(k, r)).join(''); });
    h += '<p class="muted small none56" hidden>No country matches.</p></div>';
    openSheet(h + btn('Close', 'sheetclose', undefined, 'ghost wide'), 'pick56s');
  };
  ACT.setcountry = p => {
    const k = p.v || p;
    if (!CO[k]) return;
    if (!open(k)) { closeSheet(); return PRO.sheet('world', () => ACT.setcountry(k)); } /* bought: the country is picked */
    if (k !== ui.sc) ui.city = null;
    ui.sc = k;
    closeSheet();
  };
  ACT.citysheet = () => {
    const c = CO[ui.sc];
    const L = c.cities.filter(x => !town(x)).sort((a, b) => (b.pop || 0) - (a.pop || 0)).concat(c.cities.filter(town));
    const top = Math.max.apply(null, c.cities.map(x => x.rent || 1));
    openSheet('<h2>Where in ' + esc(c.name) + '?</h2><div class="list56">' + L.map(x => li('setcity', { v: x.id }, x.id === ui.city, town(x) ? '🏡' : '🏙️', x.name, (town(x) ? 'Small place' : cityPeople(x.pop || 0)) + ' · ' + cityRent(x.rent || 1, top))).join('') + '</div>' + btn('Close', 'sheetclose', undefined, 'ghost wide'), 'pick56s');
  };
  ACT.setcity = p => {
    ui.city = p.v || p;
    closeSheet();
  };
  /* Your story (features/player/life_stories.js): what you start with; the amounts in the chosen country's money */
  const storyLine = (k, d) => { setCtx({ country: ui.sc }); try { return k === 'kid' ? d.replace('2 M', mshort(KC(2000000))) : k === 'laid' && CO[ui.sc] ? d + ' About ' + mshort(CO[ui.sc].pack.economy.medianWage * fxr(CO[ui.sc]) * 12 * 0.72) + '.' : k === 'student' ? d + ' About ' + mshort(KC(30000)) + '.' : k === 'loan' && CO[ui.sc] ? d + ' ' + mshort(CO[ui.sc].loan) + '.' : d; } finally { setCtx(null); } };
  ACT.storysheet = () => {
    openSheet('<h2>Who are you?</h2><div class="list56">' + STORY57.L.map(x => li('setstory', { v: x[0] }, x[0] === (ui.story || 'loan'), { heir: '🏠', laid: '📦', student: '🎓', kid: '💼', loan: '🏦' }[x[0]], x[1] + (x[0] === 'heir' ? ' · easiest' : ''), esc(storyLine(x[0], x[2])), '')).join('') + '</div>' + btn('Close', 'sheetclose', undefined, 'ghost wide'), 'pick56s');
  };
  ACT.setstory = p => {
    const k = p.v || p, x = STORY57.get(k);
    ui.story = x[0];
    if (x[3]) { ui.age = x[3]; ui.inp.age = String(x[3]); }
    closeSheet();
  };
  /* the search box filters the country list as you type, without redrawing the sheet */
  document.addEventListener('input', e => {
    const t = e.target;
    if (!t || !t.hasAttribute || !t.hasAttribute('data-flt56')) return;
    const q = t.value.trim().toLowerCase(), box = t.closest('.sheet');
    if (!box) return;
    let any = false;
    box.querySelectorAll('[data-s]').forEach(b => { const ok = !q || b.getAttribute('data-s').indexOf(q) >= 0; b.hidden = !ok; any = any || ok; });
    /* a heading (and the Suggested tiles) shows while anything under it does */
    box.querySelectorAll('[data-g56]').forEach(g => {
      g.hidden = !g.getAttribute('data-g56').split('|').some(r => box.querySelector('[data-r56="' + r + '"]:not([hidden])'));
    });
    const n = box.querySelector('.none56');
    if (n) n.hidden = any;
  });

  /* ---------- start ---------- */
  ACT.startgame = () => {
    if (!CO[ui.sc]) return ACT.ccsheet(); /* no country chosen yet */
    const k = ui.sc, c = CO[k];
    if (!open(k)) return PRO.sheet('world', () => ACT.startgame());
    const city = c.cities.some(x => x.id === ui.city) ? ui.city : c.cities[0].id;
    const a = parseInt(ui.inp.age, 10);
    const age = Math.max(U.AGE0, Math.min(U.AGE1, isFinite(a) ? a : ui.age || AGE_START));
    const nm = (ui.inp.name || '').trim() || 'You';
    newGame({ name: nm, age, city, country: k });
    setCtx(null);
    /* your story, then the trades you can start count from what you have now */
    if (window.STORY57) STORY57.apply(ui.story || 'loan');
    if (window.UNL57) UNL57.init();
    if (window.SEEN57) SEEN57.start();
    if (window.FS58) FS58.start(); /* the first-steps guide on Home */
    ui.inp = {};
    ui.tab = 'home';
    ui.stack = [];
    ui.view = { n: 'home', p: {} };
    U.save();
    render(true);
  };
})();

/* ---- ui/phone/stats_meetings.js ---- */
(function () {
  'use strict';
  const U = window.UI, { ui, V, ACT, esc, nok, row, btn, card, svg, spark, lineChart, render, toast, save, noteBox } = U;
/* ---------- Stats app: simple analytics, plus reports from your analyst ---------- */
  V.stats = function () {
    const nw = netWorth();
    const st = S.stats;
    const hist = S.hist.nw;
    const live = liveCos().filter(c => c.st === 'open');
    const an = hasHQ('ana');
    let h = card('<h3>Net worth</h3>' + lineChart(hist, 'Net worth') + row('Now', nok(nw.total)) + row('Peak', nok(st.peak)));
    h += card('<h3>Your record</h3>' + row('Years played', (S.week / 52).toFixed(1)) + row('Companies sold or closed', st.sold) + row('Bankruptcies', st.bankrupt) + row('Taxes paid', nok(st.taxPaid)) + row('Wages paid', nok(st.wagesPaid)) + row('Dividends received', nok(st.dividends)));
    if (live.length) h += card('<h3>Visitors<small>Simple analytics, free</small></h3>' + live.map(co => {
      const tr = co.trf || [];
      const a = tr.slice(-4).reduce((x, y) => x + y, 0), b = tr.slice(-8, -4).reduce((x, y) => x + y, 0);
      return '<div class="srow"><b>' + esc(co.name) + '</b>' + (co.ga ? (tr.length > 2 ? '<div style="display:flex;justify-content:center">' + spark(tr, 260, 54) + '</div>' + row('Last 4 weeks vs before', b > 0 ? (a >= b ? '+' : '−') + Math.round(Math.abs(a / b - 1) * 100) + '%' : 'Too early') : '<p class="muted small">Collecting data.</p>') + '<button class="btn ghost" data-a="gaoff" data-p="' + esc(JSON.stringify({ id: co.id })) + '">Disconnect</button>' : '<p class="muted small">Not connected.</p>' + btn('Connect analytics', 'gaon', { id: co.id }, 'primary')) + '</div>';
    }).join(''));
    if (an) h += '<div class="card"><h3>Ask your analyst</h3><p class="muted small">A report on all your companies, or one of them.</p><div class="btnrow col">' + btn('All companies', 'arep', { w: 'all' }, 'chip wide') + live.map(c => btn(esc(c.name), 'arep', { w: c.id }, 'chip wide')).join('') + '</div></div>';
  else h += card('<h3>Reports</h3><p class="muted small">A data analyst at your main office can write a report on any company, or all of them. ' + (hqUnlocked('ana') ? '' : 'Analysts open up when you run ' + hqUnlockText('ana') + '.') + '</p>' + (hqUnlocked('ana') ? btn('Open HQ', 'go', { n: 'office', p: {} }, 'wide') : ''));
    (S.areports || []).slice(0, 3).forEach(r => {
      h += '<div class="card"><h3>' + (r.who === 'all' ? 'All companies' : esc((r.items[0] || {}).name || '')) + '<small>' + dateStr(r.w) + '</small></h3>' + r.items.map(o => '<div class="srow"><b>' + esc(o.name) + '</b>' + (o.hist.length > 3 ? '<div style="display:flex;justify-content:center">' + spark(o.hist.concat(o.fc), 260, 56) + '</div><p class="muted small">Weekly sales and forecast</p>' : '') + o.lines.map(l => '<p class="small">' + esc(l) + '</p>').join('') + '</div>').join('') + '</div>';
    });
    return h;
  };
  ACT.arep = p => {
    const r = analystReport(p.w);
    if (r === 'ok') {
      save();
      render();
      toast('Report ready.');
    } else toast(r === 'noana' ? 'You need a data analyst in HQ.' : 'Nothing to report on.', true);
  };
  ACT.gaon = p => {
    getCo(p.id).ga = 1;
    save();
    render();
  };
  ACT.gaoff = p => {
    getCo(p.id).ga = 0;
    save();
    render();
  };
})();


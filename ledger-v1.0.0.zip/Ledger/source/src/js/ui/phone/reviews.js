/* ---- ui/phone/reviews.js ---- */
(function () {
  'use strict';
  const U = window.UI, { ui, V, ACT, esc, row, btn, card, sec, tabsRow, bar, svg, render } = U;
  V.titles.reviews = 'Reviews';
  V.titles.rvdetail = 'Reviews';
  ACT.rvopen = p => {
    ui.rvn = 10;
    U.setView('rvdetail', { k: p.k });
  };
  ACT.rvmore = () => {
    ui.rvn = (ui.rvn || 10) + 10;
    render(true);
  };
  const AG = [[18, 24], [25, 34], [35, 49], [50, 99]], AGL = ['18–24', '25–34', '35–49', '50+'], SPD = [0.35, 0.65, 1, 0.85];
  function ageStats(x) {
    const rv = reviewsOf(x.key, x.type, x.country, x.rt, x.n, x.price, Math.min(x.n, 150), x.per);
    return { rv, g: AG.map(g => { const r = rv.filter(v => v.a >= g[0] && v.a <= g[1]); return { n: r.length, avg: r.length ? r.reduce((t, v) => t + v.st, 0) / r.length : 0 }; }) };
  }
  window.AGX = { AG, AGL, SPD, ageStats };
  V.rvdetail = function (p) {
    const x = reviewList('all').find(y => y.key === p.k);
    if (!x) return card('<p class="muted">Not found.</p>', 'empty');
    const d = starDist(x.rt);
    const n = ui.rvn || 10;
    let h = card('<h3>' + esc(x.name) + '</h3><small>' + esc(BD[x.type].n) + ' · ' + esc(cityOf(x.city).name) + '</small><div class="big2">' + (x.n < RV_MIN ? '–' : x.rt.toFixed(1)) + ' ' + (x.n < RV_MIN ? '<span class="stars" style="--w:0%"></span>' : stars(x.rt)) + '</div><p class="muted small">' + (x.n < RV_MIN ? 'Not enough reviews yet to show a rating.' : x.n.toLocaleString('en-US').replace(/,/g, ' ') + ' reviews · ' + rvComment(x.rt)) + '</p>' + (x.n < RV_MIN ? [] : [5, 4, 3, 2, 1]).map(s => '<div class="kv"><span>' + s + ' ★</span><span style="flex:1;margin:0 10px">' + bar(d[s - 1] * 100, 'var(--accent)') + '</span><b>' + Math.round(d[s - 1] * 100) + '%</b></div>').join(''));
    const rv = reviewsOf(x.key, x.type, x.country, x.rt, x.n, x.price, n, x.per);
    if (x.n >= RV_MIN) {
      const A = ageStats(x), f = A.rv.filter(v => v.g === 'F').length, tot = Math.max(1, A.rv.length);
      h += card('<h3>Who rates you<small>By age, from recent reviews</small></h3>' + A.g.map((g, i) => row(AGL[i], g.n ? stars(g.avg) + ' <small>' + g.avg.toFixed(1) + ' · ' + g.n + '</small>' : '–')).join('') + row('♀ / ♂', Math.round(f / tot * 100) + '% / ' + Math.round((1 - f / tot) * 100) + '%'));
    }
    h += sec('Latest');
    h += rv.length ? rv.map(r => card('<div class="bhead"><div><b>' + (r.flag ? r.flag + ' ' : '') + esc(r.n) + ' <small>' + (r.g === 'F' ? '♀' : '♂') + ' ' + r.a + '</small></b><small>' + dateStr(r.w) + '</small></div><div class="rt">' + stars(r.st) + '</div></div><p class="lead">' + esc(r.tx) + '</p>')).join('') : card('<p class="muted small">No reviews yet. They arrive as customers come.</p>');
    if (x.n > n) h += btn('Show more', 'rvmore', undefined, 'wide');
    return h;
  };
})();


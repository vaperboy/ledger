/* ---- ui/phone/invest.js ---- */
(function () {
  'use strict';
  const U = window.UI, { ui, V, ACT, esc, nok, tone, sgn, svg, bar, row, btn, card, sec, noteBox, badge, contact, seg, chips, inp, inum, quick, stepper, tabsRow, spark, lineChart, go, tabTo, setView, openSheet, closeSheet, confirmThen, toast, res, render, save } = U;
  V.titles.invest = 'Investing';
  /* Investing: stocks, crypto, funds and startups (V.startups below: invest, your stakes, your own startups) */
  V.invest = function (p) {
    const t = ui.itab || (p && p.tab) || 'stocks';
    ui.itab = t;
    let h = tabsRow([['stocks', 'Stocks'], ['crypto', 'Crypto'], ['funds', 'Funds'], ['su', 'Startups']], t, 'itab');
    if (t === 'su') {
      /* your own startups stay here too, not only under New company */
      if (!ui.stab && (S.founded || []).some(f => f.st === 'live')) ui.stab = 'found';
      return h + V.startups();
    }
    if (t === 'stocks') {
      h += '<p class="muted small">Ten listed companies. Prices follow the market mood and their sector. Dividends arrive every quarter. Fee 0.1% (min {m:29}).</p>';
      Object.keys(S.stocks).forEach(k => {
        const s = S.stocks[k];
        const pos = S.inv.stocks[k];
        const ch = s.h.length > 1 ? s.p / s.h[s.h.length - 2] - 1 : 0;
        const val = pos ? pos.q * s.p : 0;
        h += '<button class="contact" data-a="trade" data-p="' + esc(JSON.stringify({ k: 'stock', s: k })) + '"><span class="ctext"><b>' + s.sym + ' <small>' + esc(s.n) + '</small></b><small>' + esc(s.sec) + ' · dividend ' + pc(s.dy, 1) + (pos ? ' · holding ' + mshort(val) : '') + '</small></span>' + spark(s.h.slice(-52), 72, 28) + '<span class="rt"><b>' + s.p.toFixed(1) + '</b><small class="' + sgn(ch) + '">' + (ch >= 0 ? '+' : '') + (ch * 100).toFixed(1) + '%</small></span></button>';
      });
    } else if (t === 'crypto') {
      h += '<p class="muted small">Very volatile. Small coins can collapse or be rug-pulled to zero. Fee 0.4% each way plus spread.</p>';
      Object.keys(S.crypto).forEach(k => {
        const s = S.crypto[k];
        const pos = S.inv.crypto[k];
        const ch = s.h.length > 1 ? s.p / s.h[s.h.length - 2] - 1 : 0;
        const val = pos ? pos.q * s.p : 0;
        h += '<button class="contact" data-a="trade" data-p="' + esc(JSON.stringify({ k: 'crypto', s: k })) + '"><span class="ctext"><b>' + s.sym + ' <small>' + esc(s.n) + '</small></b><small>' + (s.dead ? '<span style="color:var(--red)">Collapsed</span>' : (pos ? 'holding ' + mshort(val) : 'volatility ' + pc(s.vol, 0))) + '</small></span>' + spark(s.h.slice(-52), 72, 28) + '<span class="rt"><b>' + (s.p >= 100 ? Math.round(s.p) : s.p.toFixed(2)) + '</b><small class="' + sgn(ch) + '">' + (ch >= 0 ? '+' : '') + (ch * 100).toFixed(1) + '%</small></span></button>';
      });
    } else {
      h += '<p class="muted small">Funds spread risk. Fee is built into the price.</p>';
      Object.keys(FUNDS).forEach(k => {
        const pos = S.inv.funds[k];
        const px = fundPx(k);
        h += '<button class="contact" data-a="trade" data-p="' + esc(JSON.stringify({ k: 'fund', s: k })) + '"><span class="ctext"><b>' + esc(FUNDS[k][0]) + '</b><small>' + esc(FUNDS[k][1]) + (pos ? ' · holding ' + mshort(pos.q * px) : '') + '</small></span><span class="rt"><b>' + px.toFixed(1) + '</b></span></button>';
      });
      h += sec('Finance manager');
      h += fmCard();
    }
    return h;
  };
  ACT.itab = p => {
    ui.itab = p.v;
    render();
  };
  ACT.trade = p => {
    const bag = p.k === 'stock' ? S.inv.stocks : p.k === 'crypto' ? S.inv.crypto : S.inv.funds;
    const pos = bag[p.s];
    const val = pos ? posValue(p.k, p.s) : 0;
    const px = p.k === 'stock' ? S.stocks[p.s].p : p.k === 'crypto' ? S.crypto[p.s].p : fundPx(p.s);
    const nm = p.k === 'fund' ? FUNDS[p.s][0] : p.s;
    const h0 = p.k === 'stock' ? S.stocks[p.s].h : p.k === 'crypto' ? S.crypto[p.s].h : null;
    ui.inp.tamt = '';
    openSheet('<h2>' + esc(nm) + '</h2>' + (h0 ? '<div style="display:flex;justify-content:center">' + spark(h0.slice(-52), 280, 70) + '</div>' : '') + row('Price', px >= 100 ? Math.round(px) : px.toFixed(2)) + (pos ? row('Your holding', nok(val)) + row('Paid', nok(pos.cost)) + row('Result', '<span class="' + sgn(val - pos.cost) + '">' + nok(val - pos.cost) + '</span>') : '') + '<p class="muted small">You have ' + nok(liquid()) + ' available.</p>' + inp('tamt', 'Amount to buy') + quick('tamt', [10000, 50000, 100000, 500000]) + btn('Buy', 'buyasset', p, 'primary wide') + (pos ? '<div class="btnrow">' + [0.25, 0.5, 1].map(f => btn('Sell ' + Math.round(f * 100) + '%', 'sellasset', { k: p.k, s: p.s, f: f }, 'chip')).join('') + '</div><p class="muted small">Gains are taxed at ' + pc(CC().divTax, 2) + ' at year-end.</p>' : '') + btn('Close', 'sheetclose', undefined, 'ghost wide'));
  };
  ACT.buyasset = p => {
    const a = inum('tamt', 0);
    const r = buyAsset(p.k, p.s, a);
    if (r === 'ok') {
      closeSheet();
      save();
      toast('Bought.');
      render();
    } else res(r === 'dead' ? 'That coin has collapsed.' : r);
  };
  ACT.sellasset = p => {
    const v = sellAsset(p.k, p.s, p.f);
    closeSheet();
    if (v) {
      save();
      toast('Sold for ' + money(v));
      render();
    }
  };

  function fmCard() {
    const f = S.fm;
    if (f) {
      const n = S.npcs[f.npc];
      const ret = f.bal / f.cost - 1;
      return card('<h3>' + esc(n.name) + '</h3><small>' + ({ cons: 'Cautious', bal: 'Balanced', aggr: 'Aggressive' })[f.mandate] + ' mandate · fee ' + pc(f.fee, 1) + ' a year</small>' + row('Managed money', nok(f.bal)) + row('Put in', nok(f.cost)) + row('Result', '<span class="' + sgn(ret) + '">' + (ret >= 0 ? '+' : '') + pc(ret, 1) + '</span>') + '<p class="muted small">Your manager invests for you. Skill varies, and CVs can be exaggerated. Judge them by the results.</p>' + inp('fmamt', 'Amount') + '<div class="btnrow">' + btn('Add', 'fmadd', undefined, 'chip') + btn('Withdraw', 'fmwd', undefined, 'chip') + btn('Dismiss', 'fmfire', undefined, 'chip ghost danger') + '</div>');
    }
    if (!S.fmPool) S.fmPool = genFinManagers();
    return '<p class="muted small">Hand money to a professional. Three candidates:</p>' + S.fmPool.map(id => {
      const n = S.npcs[id];
      if (!n || n.hired) return '';
      return card('<div class="bhead"><div><h3>' + esc(n.name) + '</h3><small>age ' + n.age + ' · claims ' + n.track + ' years of strong results</small></div><div class="rt"><b>' + pc(n.fee, 1) + '</b><small>fee per year</small></div></div><p class="muted small">Claims to be ' + skillBand(n.claim).toLowerCase() + '.</p>' + btn('Hire…', 'fmhire', { n: id }, 'chip'));
    }).join('');
  }
  ACT.fmadd = () => {
    const a = inum('fmamt', 0);
    if (a > 0 && fmAdd(a)) {
      save();
      render();
    } else toast('Not enough cash.', true);
  };
  ACT.fmwd = () => {
    const a = inum('fmamt', 0);
    if (a > 0 && fmWithdraw(a)) {
      save();
      render();
    }
  };
  ACT.fmfire = () => confirmThen('Dismiss the finance manager?', 'All managed money returns to your account.', 'Dismiss', () => {
    fireFinManager();
    S.fmPool = null;
    save();
    render();
  }, true);
  ACT.fmhire = p => {
    openSheet('<h2>Hire ' + esc(S.npcs[p.n].name) + '</h2>' + chips([['cons', 'Cautious'], ['bal', 'Balanced'], ['aggr', 'Aggressive']], ui.fmm || 'bal', 'fmmand', { n: p.n }) + '<p class="muted small">Cautious aims for small steady returns, aggressive swings more with the market.</p>' + inp('fmin', 'Amount to manage') + quick('fmin', [100000, 500000, 1000000]) + btn('Hire and invest', 'fmgo', p, 'primary wide') + btn('Cancel', 'sheetclose', undefined, 'ghost wide'));
  };
  ACT.fmmand = p => {
    ui.fmm = p.v;
    ACT.fmhire({ n: p.n });
  };
  ACT.fmgo = p => {
    const r = hireFinManager(p.n, ui.fmm || 'bal', inum('fmin', 0));
    closeSheet();
    if (res(r, 'Hired.')) {
      save();
      render();
    }
  };

/* ---------- startups ---------- */
  V.titles.startups = 'Startups';
  V.startups = function () {
    const t = ui.stab === 'found' && !window.foundedPage ? 'deals' : ui.stab || 'deals';
    let h = tabsRow([['deals', 'Invest'], ['mine', 'My stakes']].concat(window.foundedPage ? [['found', 'My startups']] : []), t, 'stab');
    if (t === 'found') return h + foundedPage(); /* features/player/selling_startups_and_crisis.js */
    if (t === 'deals') {
      h += '<p class="muted small">Early-stage companies raising money. Most fail, a few return many times your money. With 20% or more you get a board seat and can help them.</p>';
      startupDeals().forEach(d => {
        h += card('<div class="bhead"><div><h3>' + esc(d.name) + '</h3><small>' + esc(d.sec) + '</small></div><div class="rt"><b>' + mshort(d.raise) + '</b><small>raising at ' + mshort(d.pre) + ' pre</small></div></div><p class="muted small">' + esc(d.blurb) + '</p><div class="trio"><div><span>Team</span><b>' + d.sig.team + '</b></div><div><span>Market</span><b>' + d.sig.market + '</b></div><div><span>Traction</span><b>' + d.sig.traction + '</b></div></div>' + btn('Invest…', 'sudeal', { id: d.id }, 'chip primary'));
      });
    } else {
      const live = S.startups.filter(s => s.st === 'live'), old = S.startups.filter(s => s.st !== 'live');
      if (!S.startups.length) return h + card('<p class="muted">No stakes yet.</p>', 'empty');
      live.forEach(s => {
        h += card('<div class="bhead"><div><h3>' + esc(s.name) + '</h3><small>' + esc(s.sec) + ' · ' + esc(SU_STAGES[s.stage]) + '</small></div><div class="rt"><b>' + mshort(s.val * s.pct / 100) + '</b><small>' + s.pct.toFixed(1) + '% · paid ' + mshort(s.in) + '</small></div></div>' + (s.seat ? badge('Board seat', 'amber') : '') + '<div class="btnrow">' + (s.seat ? btn('Help (board)', 'suhelp', { id: s.id }, 'chip') : '') + btn('Sell half', 'susell', { id: s.id, f: 0.5 }, 'chip') + btn('Sell all', 'susell', { id: s.id, f: 1 }, 'chip ghost danger') + '</div><p class="muted small">Selling private shares gives about 72% of fair value.</p>');
      });
      if (old.length) h += sec('Past') + card(old.map(s => row(esc(s.name), s.st === 'failed' ? '<span class="neg">failed</span>' : '<span class="pos">exited</span>')).join(''));
    }
    return h;
  };
  ACT.stab = p => {
    ui.stab = p.v;
    render();
  };
  ACT.sudeal = p => {
    const d = startupDeals().find(x => x.id === p.id);
    openSheet('<h2>Invest in ' + esc(d.name) + '</h2><p class="lead">Valuation after money in: ' + money(d.post) + '. Putting in ' + money(d.raise) + ' buys ' + (d.raise / d.post * 100).toFixed(1) + '%.</p>' + inp('suamt', 'Amount (min ' + money(KC(50000)) + ')') + '<div class="chips">' + [50000, 100000, 250000, d.raise].map(v => '<button class="btn chip" data-a="setinp" data-p="' + esc(JSON.stringify({ k: 'suamt', v: v })) + '">' + mshort(v) + '</button>').join('') + '</div><p class="muted small">You can lose everything. The percentage you buy decides your stake and board seat (20%).</p>' + btn('Invest', 'sugo', p, 'primary wide') + btn('Cancel', 'sheetclose', undefined, 'ghost wide'));
  };
  ACT.sugo = p => {
    const d = startupDeals().find(x => x.id === p.id);
    const a = inum('suamt', 0);
    confirmThen('Invest ' + money(a) + '?', 'Startups often fail. This money may be lost completely.', 'Invest', () => {
      const r = investStartup(d, a);
      closeSheet();
      if (res(r, 'Invested.')) {
        save();
        render();
      }
    });
  };
  ACT.suhelp = p => {
    const f = S.startups.find(x => x.id === p.id);
    if (helpStartup(f)) {
      toast('You spent a week helping on the board. It improves their odds.');
      save();
      render();
    } else toast('Already helped this week.', true);
  };
  ACT.susell = p => {
    const f = S.startups.find(x => x.id === p.id);
    confirmThen('Sell ' + Math.round(p.f * 100) + '% of your stake in ' + esc(f.name) + '?', 'Private shares sell at a 28% discount.', 'Sell', () => {
      const v = sellStartupStake(f, p.f);
      toast('Sold for ' + money(v));
      save();
      render();
    });
  };
})();


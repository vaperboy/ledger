/* ---- ui/phone/phone.js ---- */
(function () {
  'use strict';
  const U = window.UI, { ui, V, ACT, esc, nok, tone, sgn, svg, bar, row, btn, card, sec, noteBox, badge, contact, seg, chips, inp, inum, quick, stepper, tabsRow, spark, lineChart, go, tabTo, setView, openSheet, closeSheet, confirmThen, toast, res, render, save } = U;
  V.titles.news = 'News';
/* pick a company then go somewhere */
  V.titles.pickco = 'Choose company';
  V.pickco = function (p) {
    let list = liveCos().filter(c => c.st !== 'sold');
    if (p.fam) list = list.filter(c => BD[c.type].fam === p.fam);
    if (!list.length) return card('<p class="muted">' + (p.fam ? 'You have no company of that kind yet. Start a rental or property business first.' : 'You have no companies yet.') + '</p>' + btn('＋ New business', 'go', { n: 'newbiz' }, 'primary'), 'empty');
    if (list.length === 1) {
      setTimeout(() => ACT.pickgo({ id: list[0].id, to: p.to, tab: p.tab, back: 1 }), 0);
    }
    return '<p class="muted">' + esc(p.t || '') + ' for which company?</p>' + list.map(c => '<button class="contact" data-a="pickgo" data-p="' + esc(JSON.stringify({ id: c.id, to: p.to, tab: p.tab })) + '"><span class="cic" style="background:var(--surface2)">' + svg('biz') + '</span><span class="ctext"><b>' + esc(c.name) + '</b><small>' + BD[c.type].n + '</small></span><i>›</i></button>').join('');
  };
  ACT.pickgo = p => {
    if (p.back) {
      ui.view = ui.stack.pop() || ui.view;
    }
    const prm = p.to === 'co' ? { id: p.id, t: p.tab } : { id: p.id };
    if (p.to === 'hire') ui.hrole = null;
    go(p.to, prm);
  };

/* ---------- bank: every account in one view (with transfers); loans, credit and tax on their own tabs ---------- */
  V.titles.bank = 'Bank';
  V.bank = function () {
    const t = ui.btab || 'acc';
    const tabs = tabsRow([['acc', 'Accounts'], ['loans', 'Loans'], ['credit', 'Credit'], ['tax', 'Tax']], t, 'btab');
    if (t === 'tax') return tabs + V.tax();
    let h = tabs;
    if (t === 'acc') {
      const cos = S.cos.filter(c => c.st !== 'sold' && c.st !== 'bust' && (c.st !== 'setup' || c.cash));
      const deps = sum(S.inv.deposits, d => d.bal);
      const total = S.cash + S.sav.bal + deps + sum(cos, c => c.cash);
      h += '<div class="card ovhero"><span class="lab">Total across all accounts</span><b class="huge">' + nok(total) + '</b><div class="three">' + btn('Transfer', 'trsheet', undefined, 'primary') + btn('Pay', 'btab', { v: 'loans' }) + btn('Invest', 'phapp', { n: 'invest' }) + '</div></div>';
      h += '<h2 class="sec">Accounts</h2><div class="lrows">' +
        '<button class="lrow" data-a="go" data-p="' + esc(JSON.stringify({ n: 'pacct' })) + '"><span class="lic">' + svg('coin', 20) + '</span><span class="ctext"><b>Personal</b><small>' + (S.cash < 0 ? '<em class="neg">Overdrawn</em> · ' : '') + 'Statement and history</small></span><b class="num ' + (S.cash < 0 ? 'neg' : '') + '">' + mshort(S.cash) + '</b></button>' +
        '<button class="lrow" data-a="trsheet" data-p="' + esc(JSON.stringify({ from: 'me', to: 'sav' })) + '"><span class="lic">' + svg('bank', 20) + '</span><span class="ctext"><b>Savings</b><small>' + pc(Math.max(0.005, policy() - 0.012), 1) + ' interest</small></span><b class="num">' + mshort(S.sav.bal) + '</b></button>' +
        '<button class="lrow" data-a="depsheet"><span class="lic">' + svg('doc', 20) + '</span><span class="ctext"><b>Fixed deposits</b><small>' + (S.inv.deposits.length ? S.inv.deposits.length + ' open' : 'Lock money for a better rate') + '</small></span><b class="num">' + mshort(deps) + '</b></button>' +
        cos.map(c => '<button class="lrow" data-a="go" data-p="' + esc(JSON.stringify({ n: 'co', p: { id: c.id, t: 'more' } })) + '"><span class="lic">' + svg('biz', 20) + '</span><span class="ctext"><b>' + esc(c.name) + '</b><small>Business account</small></span><b class="num ' + (c.cash < 0 ? 'neg' : '') + '">' + mshort(c.cash) + '</b></button>').join('') + '</div>';
      const pl = S.loans.filter(l => !l.co);
      if (pl.length) h += '<h2 class="sec">Loan' + (pl.length > 1 ? 's' : '') + '</h2>' + pl.map(l => {
        const base = l.amt0 || (l.name === 'Start-up loan' ? (CO[S.country] || CC()).loan : 0) || l.bal;
        const paid = base > 0 ? Math.max(0, Math.min(1, 1 - l.bal / base)) : 0;
        return '<div class="card"><div class="bhead"><b>' + esc(l.name) + '</b><span class="badge amber">' + pc(loanRate(l), 1) + ' floating</span></div>' + row('Remaining', '<span class="neg">' + nok(l.bal) + '</span>') + row('Next payment', nok(l.pay) + ' · monthly') + bar(paid * 100, 'var(--amber)') + '<div class="two">' + btn('Pay extra', 'repaysheet', { id: l.id }, 'wide') + btn('Borrow more', 'btab', { v: 'loans' }, 'wide') + '</div></div>';
      }).join('');
      /* the last few lines of your statement; the whole history is Personal (ui/phone/personal_account.js) */
      h += '<h2 class="sec">Recent on your account</h2><div class="lrows">' + ((S.log || []).slice(0, 5).map(x => '<div class="lrow"><span class="ctext"><b>' + esc(x.l) + '</b><small>' + dateStr(x.w) + (x.co && getCo(x.co) ? ' · ' + esc(getCo(x.co).name) : '') + '</small></span><b class="num ' + sgn(x.a) + '">' + (x.a > 0 ? '+' : '−') + npadL(Math.abs(x.a)) + '</b></div>').join('') || '<div class="lrow"><small>Nothing yet.</small></div>') + '<button class="lrow" data-a="go" data-p="' + esc(JSON.stringify({ n: 'pacct' })) + '"><span class="ctext"><b>Full statement</b><small>Every payment in and out, day by day</small></span><i>›</i></button></div>';
    } else if (t === 'loans') {
      const pl = S.loans.filter(l => !l.co);
      h += '<div class="card"><h3>Your loans</h3>' + (pl.length ? pl.map(l => '<div class="opt"><div class="bhead"><div><b>' + esc(l.name) + '</b><small>' + pc(loanRate(l), 1) + ' · ' + money(l.pay) + ' / month</small></div><div class="rt"><b>' + money(l.bal) + '</b>' + btn('Repay', 'repaysheet', { id: l.id }, 'chip') + '</div></div></div>').join('') : '<p class="muted small">No personal loans.</p>') + '</div>';
      h += '<div class="card"><h3>Company loans</h3>' + (S.loans.filter(l => l.co).length ? S.loans.filter(l => l.co).map(l => {
        const c = getCo(l.co);
        return '<div class="kv"><span>' + esc(l.name) + '<br><small>' + (c ? esc(c.name) : '') + (l.guar ? ' · you guarantee' : '') + '</small></span><b>' + money(l.bal) + '</b></div>';
      }).join('') : '<p class="muted small">None.</p>') + '<p class="muted small">Borrow for a company from its Money tab.</p></div>';
      ['cons', 'mort'].concat(runSteps('collateral', 0) > 0 ? ['lomb'] : []).forEach(k => {
        const o = loanOffer(k, 0);
        h += card('<h3>' + LOANN[k] + '</h3><p class="muted small">' + (k === 'cons' ? 'Unsecured, expensive.' : k === 'lomb' ? 'Secured on your art, watches, homes, boats and estates. Sell one and the bank wants its share back.' : 'Secured on your net worth, cheaper.') + ' Rate ' + pc(policy() + o.margin, 2) + ' · up to <b>' + money(o.max) + '</b></p>' + btn('Borrow', 'perloan', { k: k }, 'wide'));
      });
    } else {
      const b = creditBand();
      h += card('<h3>Credit score</h3><div class="big2">' + creditWord() + '</div>' + bar(S.credit, S.credit > 65 ? 'var(--green)' : S.credit < 45 ? 'var(--red)' : 'var(--amber)') + '<p class="muted small">Pay loans on time to raise it. Missed payments and bankruptcies lower it. A better band means lower interest and larger loans.</p>' + row('Base margin over policy rate', pc(creditMargin(), 1)) + row('Policy rate', pc(policy(), 2)) + row('Inflation', pc(S.econ.infl, 1)));
    }
    return h;
  };
  ACT.btab = p => {
    ui.btab = p.v;
    render();
  };


  ACT.opendep = w => {
    const a = inum('damt', 0);
    if (a < KC(1000)) {
      toast('Enter an amount of at least ' + money(KC(1000)) + '.', true);
      return;
    }
    if (openDeposit(a, +w)) {
      ui.inp.damt = '';
      save();
      render();
      toast('Deposit opened.');
    } else toast('Not enough on the account.', true);
  };
  const LOANN = { cons: 'Consumer loan', mort: 'Mortgage-style loan', lomb: 'Loan against your collection' };
  ACT.perloan = p => {
    const o = loanOffer(p.k, 0);
    ui.ploan = p.k;
    openSheet('<h2>' + LOANN[p.k] + '</h2><p class="muted small">Up to ' + money(o.max) + ' at ' + pc(policy() + o.margin, 2) + '.</p>' + inp('pamt', 'Amount') + chips([12, 36, 60, 120].map(m => [m, m / 12 + ' yr']), ui.ploanT || 60, 'ploanT') + btn('Apply', 'perloango', { k: p.k }, 'primary wide') + btn('Cancel', 'sheetclose', undefined, 'ghost wide'));
  };
  ACT.ploanT = p => {
    ui.ploanT = p.v;
    ACT.perloan({ k: ui.ploan });
  };
  ACT.perloango = p => {
    const a = Math.round(inum('pamt', 0));
    const r = takeLoan(p.k, a, ui.ploanT || 60, null, false);
    closeSheet();
    if (r === 'ok') {
      toast('Loan approved.');
      save();
      render();
    } else res(r);
  };

  /* transfer between your accounts and into a company */
  function trSheet() {
    const tr = ui.tr = ui.tr || { from: 'me', to: 'sav' };
    const opts = [['me', 'Personal'], ['sav', 'Savings']].concat(S.cos.filter(c => c.st !== 'sold' && c.st !== 'bust').map(c => ['co:' + c.id, c.name]));
    const pick = (k, lab) => '<div class="lab">' + lab + '</div><div class="chips">' + opts.filter(o => k === 'from' ? o[0] === 'me' || o[0] === 'sav' : o[0] !== tr.from).map(o => btn(esc(o[1]), 'trset', { k: k, v: o[0] }, 'chip' + (tr[k] === o[0] ? ' primary' : ''))).join('') + '</div>';
    const toCo = tr.to.indexOf('co:') === 0;
    openSheet('<h2>Transfer</h2>' + pick('from', 'From') + pick('to', 'To') + inp('tamt', 'Amount') + quick('tamt', [10000, 50000, 100000, 500000]) +
      (toCo ? '<p class="muted small">Money you put into a company is recorded as share capital from you.</p>' : '') +
      '<p class="muted small">To take money out of a company, open the company and use Move money.</p><div class="btnrow">' + btn('Cancel', 'sheetclose', undefined, 'ghost') + btn('Send', 'trgo', undefined, 'primary') + '</div>');
  }
  ACT.trsheet = p => {
    ui.tr = Object.assign({ from: 'me', to: 'sav' }, ui.tr || {}, p && typeof p === 'object' ? p : {});
    trSheet();
  };
  ACT.trset = p => {
    ui.tr[p.k] = p.v;
    if (ui.tr.from === ui.tr.to) ui.tr.to = ui.tr.from === 'me' ? 'sav' : 'me';
    if (ui.tr.from === 'sav' && ui.tr.to.indexOf('co:') === 0) ui.tr.to = 'me';
    trSheet();
  };
  ACT.trgo = () => {
    const tr = ui.tr || {}, a = Math.round(inum('tamt', 0));
    if (!(a > 0)) {
      toast('Enter an amount.', true);
      return;
    }
    let ok = false;
    if (tr.from === 'me' && tr.to === 'sav') ok = saveMove(a);
    else if (tr.from === 'sav' && tr.to === 'me') ok = saveMove(-a);
    else if (tr.from === 'me' && tr.to.indexOf('co:') === 0) {
      const co = getCo(isNaN(+tr.to.slice(3)) ? tr.to.slice(3) : +tr.to.slice(3)) || S.cos.filter(c => c.st !== 'sold' && c.st !== 'bust').find(c => String(c.id) === tr.to.slice(3));
      ok = co ? injectCash(co, a) : false;
    }
    if (!ok) {
      toast('Not enough money for that transfer.', true);
      return;
    }
    ui.inp.tamt = '';
    ui.sheet = null;
    save();
    render();
    toast('Sent ' + money(a) + '.');
  };
  ACT.depsheet = () => {
    openSheet('<h2>Fixed deposits</h2><p class="muted small">Lock money for a better rate. You cannot touch it until it matures.</p>' + (S.inv.deposits.length ? '<div class="card">' + S.inv.deposits.map(d => row(money(d.bal) + ' at ' + pc(d.rate, 2), 'matures ' + dateStr(d.wEnd))).join('') + '</div>' : '') + inp('damt', 'Amount') + '<div class="chips">' + [13, 26, 52].map(w => '<button class="btn chip" data-a="depgo" data-p="' + w + '">' + w + ' weeks · ' + pc(Math.max(0.01, policy() - 0.002 + w / 52 * 0.004), 2) + '</button>').join('') + '</div>' + btn('Close', 'sheetclose', undefined, 'ghost wide'));
  };
  ACT.depgo = w => {
    ui.sheet = null;
    ACT.opendep(w);
  };

/* ---------- tax office ---------- */
  V.titles.tax = 'Tax authority';
  V.tax = function () {
    const t = S.tax, c = CC();
    const enk = Math.max(0, enkIncome());
    const est = personalTaxEstimate();
    const weeksLeft = (() => {
      let w = S.week;
      while (!isYearEnd(w)) w++;
      return w - S.week + 1;
    })();
    let h = '<div class="card ovhero"><span class="lab">Tax due this year</span><b class="huge">' + nok(est) + '</b><span class="pills"><span class="pl a">Assessment in ' + weeksLeft + ' wk</span><span class="pl">Withheld ' + mshort(t.withheld || 0) + '</span></span></div>';
    h += card('<h3>This year so far</h3>' + row('Sole-proprietor profit', nok(enk)) + row('Salary from your companies', nok(t.wage || 0)) + row('Dividends', nok(t.ytdDiv || 0)) + row('Investment gains realised', nok(t.gain || 0)) + row('Interest income', nok(t.int || 0)) + '<p class="muted small">The annual assessment is paid at year-end. Your sole-proprietor profit is taxed as personal income whether you take the money out or not.</p>');
    const as = S.cos.filter(x => x.form === 'AS' && x.st !== 'sold' && x.st !== 'bust');
    /* one row per company: what builds up (and what is due) on the right, the rate and any loss carried under the name */
    if (as.length) h += card('<h3>Company tax</h3>' + '<div class="lrows">' + as.map(x => {
      const prev = Math.min(x.taxPrev || 0, x.pay.tax || 0), build = Math.max(0, (x.pay.tax || 0) - prev);
      return '<div class="lrow"><span class="ctext"><b>' + esc(x.name) + '</b><small>at ' + pc(coTaxRate(x), 0) + (x.lossCarry > 0 ? ' · loss carried ' + mshort(x.lossCarry) : '') + '</small></span><span class="rt56"><b>' + mshort(prev > 0 ? prev : build) + '</b><small>' + (prev > 0 ? 'due ' + (x.taxDueW ? dateStr(x.taxDueW) : 'soon') + (build ? ' · +' + mshort(build) + ' building' : '') : 'building up') + '</small></span></div>';
    }).join('') + '</div><p class="muted small">Company tax builds up through the year and is paid about six months after year-end. ' + (c.salesTax ? 'Sales tax is settled ' : 'VAT is settled ') + ({ 1: 'every month', 2: 'every second month', 3: 'every quarter', 6: 'twice a year', 12: 'once a year' }[c.vatFreq || 2] || 'regularly') + '.</p>');
    const nw = netWorth();
    const taxable = Math.max(0, nw.total - sum(S.cos, x => x.st === 'sold' || x.st === 'bust' ? 0 : companyValue(x) * x.own / 100) * (1 - c.wealthShare) - c.wealthThr);
    h += c.wealthRate ? card('<h3>Wealth tax (estimate)</h3>' + row('Taxable wealth', nok(taxable)) + row('Estimated tax', nok(taxable * c.wealthRate)) + '<p class="muted small">' + pc(c.wealthRate, 1) + ' above about ' + mshort(c.wealthThr) + ', with unlisted company shares discounted.</p>') : ''; /* no wealth tax: one line under the rates below */
    h += card('<h3>Rates used in this game</h3>' + row('Company tax', pc(c.corp, 1)) + (c.wealthRate ? '' : row('Wealth tax', 'None in ' + esc(c.name))) + row('Dividend and gains', pc(c.divTax, 2)) + row('Employer payroll tax', pc(c.empNI, 1)) + row('Employee social contributions', pc(c.eeNI, 1)) + row('VAT', pc(c.vat.std, 0) + ' / ' + pc(c.vat.food, 0) + ' food / ' + pc(c.vat.low, 0) + ' low') + '<p class="muted small">These are the rates for ' + c.name + '. Income-tax brackets, the wealth-tax threshold, company capital and fees, and the fictional licences are approximations made for the game.</p>');
    return h;
  };

/* ---------- world: economy ---------- */
  V.titles.world = 'Economy';
  V.world = function () {
    const E = S.econ;
    const ph = { boom: 'Boom', steady: 'Steady', slowdown: 'Slowdown', recession: 'Recession' }[E.phase];
    let h = '<div class="trio"><div><span>Phase</span><b>' + ph + '</b></div><div><span>Policy rate</span><b>' + pc(E.rate, 2) + '</b></div><div><span>Inflation</span><b>' + pc(E.infl, 1) + '</b></div></div>';
    h += card('<h3>Indices</h3>' + [
      ['Consumer demand', E.dem],
      ['Fuel', E.fuel],
      ['Materials', E.mat],
      ['Power price', E.power],
      ['Oil price', E.oil],
      ['Housing', E.housing],
      ['Freight rates', E.freight]
    ].concat(legalStatus('salmon', S.country).ok || (S.cos||[]).some(c => c.type === 'salmon') ? [['Salmon price', E.salmon || 1]] : []).map(r => row(r[0], '<span class="' + (r[1] > 1.03 ? 'pos' : r[1] < 0.97 ? 'neg' : '') + '">' + r[1].toFixed(2) + '</span>').replace('×', '')).join('') + '<p class="muted small">1.00 is normal. Your businesses feel these differently: construction feels materials, haulage feels fuel, landlords feel housing and rates.</p>');
    h += card('<h3>Stock market</h3>' + row('Market mood', ({ bull: 'Rising', correction: 'Correcting', bear: 'Falling', recovery: 'Recovering', crash: 'Crashing' })[S.mkt.regime] || S.mkt.regime) + row('Index', (S.idx || 100).toFixed(1)));
    h += sec('News');
    h += card(S.news.slice(0, 20).map(n => '<div class="news"><i style="background:' + tone(n.tone) + '"></i><div><p>' + esc(n.t) + '</p><span>' + dateStr(n.w) + '</span></div></div>').join('') || '<p class="muted">Quiet.</p>');
    return h;
  };

/* ---------- rivals ---------- */
  V.titles.rivals = 'Rivals';

/* ---------- registry ---------- */
  V.titles.registry = 'Registry';
  V.registry = function () {
    const live = liveCos().filter(c => c.st !== 'sold');
    let h = '<p class="muted">The business registry and permits. Everything you hold across companies.</p>';
    h += btn('＋ Register a new business', 'go', { n: 'newbiz' }, 'primary wide');
    live.forEach(c => {
      const need = docNeeds(c).filter(d => d !== 'mva_na');
      const ok = need.filter(d => docOk(c, d)).length;
      h += '<button class="contact" data-a="go" data-p="' + esc(JSON.stringify({ n: 'co', p: { id: c.id, t: 'set' } })) + '"><span class="cic" style="background:var(--surface2)">' + svg('doc') + '</span><span class="ctext"><b>' + esc(c.name) + '</b><small>' + ((CO[c.country || S.country] || CC()).forms[c.form + 's'] || c.form) + ' · ' + ok + ' / ' + need.length + ' documents in order</small></span><i>›</i></button>';
    });
    return h;
  };

/* ---------- settings ---------- */
  V.titles.settings = 'Settings';
  /* Settings: reports and timing (features/screens/restyled_screens.js V.reports), the game, saving (with files and slots,
     features/player/saves.js), Ledger Pro (features/player/pro.js), starting over */
  V.settings = function () {
    return (V.reports ? '<div class="lrows"><button class="lrow" data-a="phapp" data-p="' + esc(JSON.stringify({ n: 'reports' })) + '"><span class="lic">' + svg('doc', 20) + '</span><span class="ctext"><b>Reports and timing</b><small>What reaches you, and when</small></span><i>›</i></button></div>' : '') +
    card('<h3>Game</h3>' + chips([[1, 'Ask before big actions'], [0, 'Do not ask']], S.settings.confirm ? 1 : 0, 'setconf') + '<p class="muted small">Dangerous or irreversible actions always ask.</p>') +
    card('<h3>Save</h3><p class="muted small">The game saves automatically ' + (U.inCloud() ? 'on this phone and in iCloud' : window.LedgerApp ? 'on this phone' : 'in this browser') + '. A file keeps a copy you can load again here or on another device.</p>' + (window.SAVES && SAVES.fileBtns ? SAVES.fileBtns() : '')) +
    (window.SAVES && SAVES.slotsCard ? SAVES.slotsCard() : '') + (window.PRO && PRO.card ? PRO.card() : '') +
    card('<h3>Start over</h3>' + btn('New game', 'newgame2', undefined, 'ghost danger wide')) +
    card('<h3>About</h3><p class="small"><b>' + esc(U.NAME) + '</b> · ' + U.PATCH + '</p><p class="muted small">Ledger is a simulation. All companies, people, events and prices are made up. Tax rates for company tax, dividends, payroll tax and VAT follow the real rules of the country you play in; income-tax brackets, wealth-tax thresholds, company capital and fees, and all special licences are approximations or fictional.</p>' + '<div class="two">' + btn('How to play', 'wel59', { i: 0 }) + btn('Contact support', 'prolink', { u: 'mailto:' + U.SUPPORT + '?subject=' + encodeURIComponent('Ledger · ' + U.PATCH) }) + '</div>' +
      '<div class="two">' + (window.LedgerApp && LedgerApp.reviewUrl ? btn('Rate Ledger', 'prolink', { u: LedgerApp.reviewUrl }) : '') + btn('Privacy', 'privacy') + '</div>');
  };
  /* the privacy policy, also on the web for the App Store (ios-app/privacy/index.html says the same) */
  ACT.privacy = () => openSheet('<h2>Privacy</h2><p class="lead">Ledger has no account, no ads, no tracking and no analytics.</p>' +
    [['Your game', 'It is saved on your device and, if iCloud is on, in your own iCloud. Only you can see it. Deleting the app deletes the copy on the phone; iCloud keeps its copy until you delete it under Settings › your name › iCloud.'],
     ['Purchases', 'Apple takes the payment; we never see your card or your Apple ID. RevenueCat, the service that checks purchases for us, gets a random ID made by the app, what you bought and basic device details (model, iOS version, country). Nothing else leaves the phone.'],
     ['Questions', 'Write to ' + U.SUPPORT + '.']].map(x => '<span class="lab">' + x[0] + '</span><p class="muted small">' + x[1] + '</p>').join('') +
    '<div class="btnrow col">' + btn('Close', 'sheetclose', undefined, 'wide') + '</div>');
  ACT.setconf = p => {
    S.settings.confirm = p.v;
    save();
    render();
  };
  /* a game loaded from a file (features/player/saves.js ACT.loadfile puts its text in ui.inp.imp2) */
  ACT.loadpaste = () => {
    const t = (ui.inp.imp2 || '').trim();
    if (deserialize(t)) {
      save();
      ui.stack = [];
      ui.tab = 'home';
      ui.view = { n: 'home', p: {} };
      render(true);
      toast('Loaded.');
    } else toast('That is not a valid save.', true);
  };
  ACT.newgame2 = () => confirmThen('Start a new game?', 'Your current game will be deleted.', 'Delete and restart', () => ACT.newgame(), true);
})();


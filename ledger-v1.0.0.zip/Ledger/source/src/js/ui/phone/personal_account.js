/* ===== Round 56: your personal account, like a real bank statement (Bank › Accounts › Personal).
   Every movement of your own money is a line (engine/money/ledger.js S.log): what it was, the company it concerns,
   the day it happened and the balance after it. Payments land whole on their day; nothing is spread over the week.
   - the balance, and what an overdraft costs
   - money in and money out for this month, last month or everything, and where the money went (largest first);
     moving money between your own accounts (savings, deposits, a fund manager) is shown but not counted
   - the statement itself, one day at a time, filtered to money in or money out ===== */
(function () {
  const U = window.UI;
  if (!U) return;
  const { ui, V, ACT, esc, nok, btn, bar, render } = U;
  const P = o => esc(JSON.stringify(o));
  const DN = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const dayOf = x => new Date(wDate(x.w).getTime() + (x.d || 0) * 86400000);
  const dayKey = x => x.w * 7 + (x.d || 0);
  const dayName = d => DN[d.getUTCDay()] + ' ' + d.getUTCDate() + ' ' + MN[d.getUTCMonth()] + ' ' + d.getUTCFullYear();
  const mon = d => d.getUTCFullYear() * 12 + d.getUTCMonth();
  const now = () => new Date(wDate(S.week).getTime() + (S.day || 0) * 86400000);
  const sg = a => Math.round(a) === 0 ? mshort(0) : (a > 0 ? '+' : '−') + mshort(Math.abs(a));
  /* moving your own money between your own accounts is not money in or out */
  const own = x => /^(To savings|From savings|Fixed deposit opened|To your fund manager|To .*, your fund manager|From your fund manager)$/.test(x.l || '');
  /* what a line is about, for "where it went": "Loan payment: Start-up loan" and "Salary from Kaffe Nord" are a loan
     payment and a salary */
  const kind = l => String(l || 'Other').split(/: | from | of | in | to | for | with /)[0];
  const st = () => (ui.pa = ui.pa || { per: 'm', f: 'all', n: 40 });
  ACT.pa56 = p => { Object.assign(st(), p, p.n ? {} : { n: 40 }); render(); };
  V.titles.pacct = 'Personal account';
  V.pacct = function () {
    const s = st(), L = S.log || [], m0 = mon(now());
    const inPer = x => s.per === 'all' || mon(dayOf(x)) === (s.per === 'm' ? m0 : m0 - 1);
    const per = L.filter(inPer), inn = per.filter(x => x.a > 0 && !own(x)), out = per.filter(x => x.a < 0 && !own(x));
    const tin = sum(inn, x => x.a), tout = sum(out, x => x.a);
    const chip = (k, v, t) => '<button class="' + (s[k] === v ? 'on' : '') + '" data-a="pa56" data-p="' + P({ [k]: v }) + '">' + t + '</button>';
    let h = '<div class="card ovhero"><span class="lab">Balance</span><b class="huge ' + (S.cash < 0 ? 'neg' : '') + '">' + nok(S.cash) + '</b>' +
      (S.cash < 0 ? '<span class="tipt">Overdrawn. The bank charges 16% a year on it, taken at each month end, and your credit score drops while it lasts.</span>' : '') +
      '<div class="two">' + btn('Transfer', 'trsheet', undefined, 'primary') + btn('Take money out', 'paysrc56') + '</div></div>';
    h += '<div class="cf56 cosf56">' + chip('per', 'm', 'This month') + chip('per', 'l', 'Last month') + chip('per', 'all', 'Everything') + '</div>';
    h += '<div class="card nw56"><div class="nwl56"><span>Money in <b class="pos">' + sg(tin) + '</b></span><span>Money out <b class="neg">' + sg(tout) + '</b></span><span>Change <b class="' + (tin + tout < 0 ? 'neg' : 'pos') + '">' + sg(tin + tout) + '</b></span></div></div>';
    /* where it went */
    if (out.length) {
      const G = {};
      out.forEach(x => { const k = kind(x.l); G[k] = (G[k] || 0) - x.a; });
      const K = Object.keys(G).sort((a, b) => G[b] - G[a]).slice(0, 5), top = G[K[0]];
      h += '<h2 class="sec">Where it went</h2><div class="card">' + K.map(k => '<div class="pa56r"><span>' + esc(k) + '</span><b>' + mshort(G[k]) + '</b></div>' + bar(G[k] / top * 100, 'var(--red)')).join('') + '</div>';
    }
    /* the statement, a day at a time */
    const F = per.filter(x => s.f === 'all' || (!own(x) && (s.f === 'in' ? x.a > 0 : x.a < 0)));
    h += '<div class="sh hcos56"><h2 class="sec">Statement</h2><div class="cf56">' + chip('f', 'all', 'All') + chip('f', 'in', 'In') + chip('f', 'out', 'Out') + '</div></div>';
    if (!F.length) return h + '<div class="calm">' + (L.length ? 'Nothing in this period.' : 'No payments yet. Everything that goes in or out of your own account shows here, on the day it happens.') + '</div>';
    let k0 = null, body = '';
    F.slice(0, s.n).forEach(x => {
      const k = dayKey(x);
      if (k !== k0) { body += (k0 != null ? '</div>' : '') + '<h3 class="pa56d">' + dayName(dayOf(x)) + '</h3><div class="lrows">'; k0 = k; }
      const co = x.co && getCo(x.co);
      body += '<div class="lrow"><span class="ctext"><b class="wrap">' + esc(x.l) + '</b><small>' + (own(x) ? 'between your accounts · ' : '') + (co ? esc(co.name) + ' · ' : '') + (x.bal != null ? 'balance ' + mshort(x.bal) : '') + '</small></span><b class="num ' + (own(x) ? '' : x.a > 0 ? 'pos' : 'neg') + '">' + sg(x.a) + '</b></div>';
    });
    h += body + '</div>';
    if (F.length > s.n) h += btn('Show more (' + (F.length - s.n) + ' older)', 'pa56', { n: s.n + 60 }, 'ghost wide');
    return h;
  };
})();

/* ===== Round 30: tidier screens, monthly bills and results, event bookings, marketing that behaves like marketing.
   1  Clients: every "How you sell" choice (positioning, project model, focus...) is a collapsed menu showing the current pick.
   2  "Prices follow inflation" sits inside the Prices and rivals box.
   3  A complaint alert leads straight to the complaint, not the overview.
   4  Staff: "Find a manager" and "Find workers" swap places.
   5  Overview: monthly result at the top, weekly cost table and owner block folded into one short list.
   6  The "N things need you" bar is gone: each new problem pops up once; "Do later" brings it back when it matters again.
   7  The day card only shows special moments (best day, fully booked, reviews, payday, bills, big sales).
   8  In day mode every recurring cost (insurance, leasing, marketing, accounting, other fixed costs) is billed monthly.
   9  Monthly results: income against expenses and the profit, for every month.
   10 Event agency: bookings also come from referrals and repeat clients; bookings and deliveries are whole events.
   11 Marketing: real benchmarks, chance-based results per campaign, channel fit per business, ranges on screen. ===== */
window.R30 = window.R30 || {};
(function () {
  const R30 = window.R30;
  const U = window.UI, { ui, V, ACT, esc, row, btn, card, go, render, save, toast, svg, openSheet, closeSheet } = U;
  const CT = window.CT;
  const P = o => esc(JSON.stringify(o));
  const pillp = (t, c) => '<span class="pill ' + (c || '') + '">' + t + '</span>';
  const live = () => S.cos.filter(c => c.st !== 'sold' && c.st !== 'bust');
  const sgn = v => v > 0 ? 'pos' : v < 0 ? 'neg' : '';
  const plus = v => (v >= 0 ? '+' : '−') + mshort(Math.abs(v));
  const mLabel = m => MN[m % 12] + ' ' + Math.floor(m / 12);
  /* the end index of the element that opens at i (counts nested divs/buttons/details of the same tag) */
  function blockEnd(h, i) {
    const tag = /^<(\w+)/.exec(h.slice(i))[1];
    const re = new RegExp('<' + tag + '[\\s>]|</' + tag + '>', 'g');
    re.lastIndex = i;
    let d = 0, m;
    while ((m = re.exec(h))) {
      if (m[0][1] === '/') { d--; if (d === 0) return m.index + m[0].length; } else d++;
    }
    return h.length;
  }
  R30.blockEnd = blockEnd;

  /* ---------- 1, 2: Clients tab ---------- */
  ui.k30 = ui.k30 || {};
  document.addEventListener('toggle', e => {
    const d = e.target;
    if (d && d.tagName === 'DETAILS' && d.dataset && d.dataset.k30) { if (d.open) ui.k30[d.dataset.k30] = 1; else delete ui.k30[d.dataset.k30]; }
  }, true);
  /* ---------- 3: go straight to the thing that needs you ---------- */
  function routeFor(co, text) {
    if (/complaint/i.test(text)) return { l: 'Answer the complaint', n: 'co', p: { id: co.id, t: 'cli', s: 'cmp' } };
    if (/document/i.test(text)) return { l: 'Open documents', n: 'co', p: { id: co.id, t: 'doc' } };
    if (/home office/i.test(text)) return { l: 'Find an office', n: 'co', p: { id: co.id, t: 'ops', s: 'assets', eqt: 'place' } };
    if (/staff problem/i.test(text)) return { l: 'See the staff', n: 'co', p: { id: co.id, t: 'st' } };
    if (/unpaid|negative cash|wages/i.test(text)) return { l: 'Payroll and bills', n: 'payroll29', p: { id: co.id } };
    return { l: 'Open ' + co.name, n: 'co', p: { id: co.id } };
  }
  R30.routeFor = routeFor;
  ACT.go30 = p => {
    go(p.n, p.p);
    if (p.sc) setTimeout(() => { const el = document.getElementById(p.sc); if (el) el.scrollIntoView({ block: 'start' }); }, 80);
  };

  /* ---------- 9: monthly results ---------- */
  const COST30 = { cogs: 'Materials and goods', wages: 'Wages and payroll', rent: 'Rent and power', mkt: 'Marketing', ins: 'Insurance', acc: 'Accounting and payroll service', dep: 'Depreciation', int: 'Loan interest', oth: 'Leasing and other costs', fine: 'Fines', loss: 'Refunds and losses', tax: 'Company tax' };
  const monthOf = co => { const b = co.bk.m || {}, inc = b.rev || 0, ex = sumExp(b); return { inc, ex, p: inc - ex, b }; };
  R30.monthOf = monthOf;
  V.titles.month30 = 'Monthly results';
  V.heads.month30 = p => { const co = getCo(p.id); return { t: 'Monthly results', sub: co ? esc(co.name) + ' · income against expenses' : '' }; };
  V.month30 = function (p) {
    const co = getCo(p.id);
    if (!co) return card('Company not found.');
    const now = monthOf(co), H = (co.hist || []).slice(-12).reverse();
    const yr = sum(H.filter(x => Math.floor(x.m / 12) === Math.floor(monthIdx(S.week) / 12)), x => x.profit) + now.p;
    let h = '<div class="tri"><div><span>This month</span><b class="' + sgn(now.p) + '">' + plus(now.p) + '</b></div><div><span>Last month</span><b class="' + (H[0] ? sgn(H[0].profit) : '') + '">' + (H[0] ? plus(H[0].profit) : '–') + '</b></div><div><span>This year</span><b class="' + sgn(yr) + '">' + plus(yr) + '</b></div></div>';
    const one = (lab, inc, ex, b, open) => {
      const ks = b ? Object.keys(COST30).filter(k => b[k]) : [];
      return '<details class="card mon30d"' + (open ? ' open' : '') + '><summary><span class="ctext"><b>' + lab + '</b><small>Income ' + mshort(inc) + ' · expenses ' + mshort(ex) + '</small></span><b class="' + sgn(inc - ex) + '">' + plus(inc - ex) + '</b></summary>' + row('Income', mshort(inc)) + (ks.length ? ks.map(k => row(COST30[k], '−' + mshort(b[k]))).join('') : '<span class="tipt">No breakdown kept for this month.</span>') + row('Profit', '<span class="' + sgn(inc - ex) + '">' + plus(inc - ex) + '</span>', 'total') + '</details>';
    };
    h += one(mLabel(monthIdx(S.week)) + ' so far', now.inc, now.ex, now.b, true);
    h += H.map(x => one(mLabel(x.m), x.rev, x.rev - x.profit, x.bk, false)).join('');
    h += '<div class="note">Income is what customers bought; expenses include wages, rent, goods, insurance, marketing and wear on equipment. Bills are paid on payday and on the last day of the month.</div>';
    return h;
  };


  /* ---------- 6: one popup per new problem instead of the "needs you" bar ---------- */
  const DAYN = () => S.week * 7 + (S.day || 0);
  const WHY = [
    [/complaint/i, 'A customer wrote in. Answer within two weeks, or they post a bad review.'],
    [/document/i, 'Something the authorities expect is missing. An inspection can bring a fine.'],
    [/staff problem/i, 'Someone on the team is causing trouble. Left alone, it spreads.'],
    [/wages/i, 'Staff have not been paid. Every day late hurts morale; people start to leave.'],
    [/unpaid bills/i, 'Suppliers and the landlord are waiting for money. Put money in or cut costs.'],
    [/negative cash/i, 'The company is in the red and running on its overdraft.'],
    [/home office/i, 'Four or more people round a kitchen table. Morale and quality slip every week until you get an office.'],
    [/closed/i, 'The company is closed and earns nothing until you reopen it.']
  ];
  addStep('window.coAlerts', 20, 'tidier_screens_and_monthly_bills window.coAlerts', (co, out) => {
    try {
      const c = co.pr29 && co.pr29.late;
      if (c && c.why !== 'slip' && co.st !== 'sold' && co.st !== 'bust') out.unshift([c.why === 'cash' ? 'Wages only partly paid' : 'Wages not paid', 'bad']);
    } catch (e) { }
    return out;
  });
  function sigOf(co, text) {
    if (/complaint/i.test(text)) { const due = (co.compl || []).some(c => c.st === 'open' && S.week - c.w >= 1); return text + (due ? ' · due' : ''); }
    return text;
  }
  function pending() {
    const out = [];
    S.al30 = S.al30 || {};
    const seen = {};
    live().forEach(co => (window.coAlerts(co) || []).filter(a => a[1] === 'bad').forEach(a => {
      const key = co.id + ':' + a[0].replace(/[0-9]+/g, '#'), sig = sigOf(co, a[0]);
      seen[key] = 1;
      const e = S.al30[key], now = DAYN();
      if (!e || e.sig !== sig || (e.later && now - e.t >= 7)) out.push({ co, text: a[0], key, sig });
    }));
    Object.keys(S.al30).forEach(k => { if (!seen[k]) delete S.al30[k]; }); /* solved: forget it, so it can pop up again if it returns */
    return out;
  }
  function maybeAlert() {
    try {
      if (!S || S.over || ui.sheet || ui.dayBusy || ui.untl || ui.repLock || ui.tab !== 'home' || (ui.view && ui.view.n && ui.view.n !== 'home')) return;
      const L = pending();
      if (!L.length) return;
      const a = L[0], r = routeFor(a.co, a.text), why = (WHY.find(w => w[0].test(a.text)) || [0, ''])[1];
      S.al30[a.key] = { sig: a.sig, t: DAYN(), later: 1 };
      openSheet('<div class="al30"><small>' + esc(a.co.name) + '</small><h2>' + esc(a.text) + '</h2>' + (why ? '<p class="lead">' + esc(why) + '</p>' : '') + (L.length > 1 ? '<span class="tipt">' + (L.length - 1) + ' more after this one.</span>' : '') + '<div class="btnrow col">' + btn(esc(r.l), 'al30go', { k: a.key, n: r.n, p: r.p, sc: r.sc }, 'primary wide') + btn('Do later', 'al30later', { k: a.key }, 'ghost wide') + '</div></div>', 'al30s');
    } catch (e) { console.error(e); }
  }
  R30.maybeAlert = maybeAlert;
  ACT.al30go = p => {
    if (S.al30[p.k]) S.al30[p.k].later = 0;
    ui.sheet = null;
    save();
    ACT.go30(p);
  };
  ACT.al30later = p => {
    if (S.al30[p.k]) { S.al30[p.k].later = 1; S.al30[p.k].t = DAYN(); }
    ui.sheet = null;
    save();
    render();
    setTimeout(maybeAlert, 60);
  };
  /* problem pop-ups wait until the days have finished ticking (outermost around-step on both buttons) */
  ['nextday', 'untilneeded'].forEach(k => addStep('ACT.' + k + '.around', 90, 'problem pop-ups wait until the days have finished', (next) => {
    const r = next();
    const wait = () => (ui.dayBusy || ui.untl || ui.repLock ? setTimeout(wait, 150) : maybeAlert());
    setTimeout(wait, 60);
    return r;
  }));
  addStep('V.home:2', 50, 'problems come up as pop-ups when Home shows', (h) => {
    if (!ui.sheet && !ui.al30t) { ui.al30t = 1; setTimeout(() => { ui.al30t = 0; maybeAlert(); }, 120); }
    return h;
  });


  /* ---------- 8: recurring costs are billed monthly (day mode) ---------- */
  const MONTHLY = { oth: 1, mkt: 1, ins: 1, acc: 1, rent: 1 };
  addStep('payCo.later', 10, 'monthly bills build up during the week', (co, amt, cat, label, done) => {
    if (WEEK_SIM && !label && MONTHLY[cat] && window.R29 && R29.on() && co && co.pay && co.st !== 'sold' && co.st !== 'bust') {
      amt = Math.round(amt);
      if (amt <= 0) return true;
      co.pay.other = (co.pay.other || 0) + amt;
      bk(co, cat, amt);
      co.f30 = co.f30 || {};
      co.f30[cat] = (co.f30[cat] || 0) + amt;
      return true;
    }
      return done;
  });
  CT.insurance = pipeView('CT.insurance', CT.insurance, 0); /* CT.insurance: the screen, then the steps below */
  addStep('CT.insurance', 10, 'premiums are billed with the month', (h) => h.replace('Premium is paid weekly.', window.R29 && R29.on() ? 'Premiums are billed with the other bills on the last day of the month.' : 'Premium is paid weekly.'));

  /* ---------- 10: event bookings ---------- */
  const EVN = {
    0: ['summer party', 'Christmas party', 'conference', 'product launch', 'staff kick-off', 'anniversary dinner', 'customer seminar'],
    1: ['summer concert', 'club night', 'outdoor festival', 'charity concert', 'album release show'],
    2: ['wedding', 'wedding', 'wedding', 'silver wedding']
  };
  const focusOf = co => (co.knob && co.knob.seg) || 0;
  function dress(co, j, src, from) {
    const f = focusOf(co);
    j.src = src;
    j.from = from || '';
    if (src === 'rep' && from) j.client = from;
    else j.client = f === 2 ? personName() : brandCoName(CO[co.country] || CC(), f === 1 ? 'venue' : 'svc');
    j.due = S.week + j.wks;
    const mo = wDate(j.due).getUTCMonth();
    const ok = (EVN[f] || EVN[0]).filter(w => /Christmas/.test(w) ? mo >= 10 : /summer|outdoor/.test(w) ? mo >= 4 && mo <= 7 : true);
    j.what = pick(ok.length ? ok : EVN[0]);
  }
  function newJob(co, bd, d) {
    const tick = bd.ticket * ticketMult(co, bd) * knobFx(co, 'tt');
    const v = rnl(tick * Math.exp(gauss() * 0.4 - 0.08), 1000), tw = bd.tw;
    const base = (tw.mat + tw.sub) * modProd(co, 'price') * (S.econ.mat * 0.5 + 0.5) * (1 + gauss() * tw.over);
    const j = { id: uid(), v, wks: Math.max(1, Math.round(tw.wks * rng(0.7, 1.4))), p: 0, cf: Math.max(0.05, base), delay: 0, w0: S.week };
    dress(co, j, d.src, d.from);
    return j;
  }
  const evName = j => (j.src === 'rep' ? j.client + '’s ' + j.what + ' again' : j.client + (/wedding/.test(j.what) ? '’s ' : ' ') + j.what);
  function booked(co, j) {
    const how = j.src === 'ref' ? 'Recommended by ' + j.from + '.' : j.src === 'rep' ? j.client + ' was happy last time and books again.' : 'Came from people who know your name.';
    addMsg({ kind: 'info', from: co.name, title: 'New booking: ' + evName(j), body: money(j.v) + ', to deliver around ' + dateStr(j.due) + '. ' + how + ' 30% deposit now, the rest after the event.', co: co.id, tone: 'good', status: 'done' });
  }
  function delivered(co, j, ev) {
    const q = co.q != null ? co.q : 55, happy = chance(clamp(0.45 + (q - 55) / 80, 0.15, 0.92));
    const f = focusOf(co);
    if (happy) {
      const r1 = f === 2 ? 0.6 : 0.45, r2 = f === 2 ? 0.25 : 0.15, rep = f === 0 ? 0.55 : f === 1 ? 0.45 : 0.03;
      if (chance(r1)) ev.due.push({ w: S.week + rint(3, 14), src: 'ref', from: j.client });
      if (chance(r2)) ev.due.push({ w: S.week + rint(6, 20), src: 'ref', from: j.client });
      if (chance(rep)) ev.due.push({ w: S.week + rint(44, 56), src: 'rep', from: j.client });
    }
    addMsg({ kind: 'info', from: co.name, title: 'Delivered: ' + (j.what ? evName(j) : 'an event'), body: (j.what ? '' : j.client + '. ') + (happy ? 'The client was delighted and will tell others about you.' : 'The client was not fully happy. Expect no recommendations from this one.') + ' Final invoice sent.', co: co.id, tone: happy ? 'good' : '', status: 'done' });
  }
  R30.ev = { dress, booked, delivered, evName };
  FAM.project.custom = pipeView('FAM.project.custom', FAM.project.custom, 3);
  addStep('FAM.project.custom.around', 10, 'tidier_screens_and_monthly_bills FAM.project.custom', (co, bd, ctx, next) => {
    if (bd.id !== 'event' || bd.tw.dev) return next();
    const fm = co.fm;
    fm.jobs = fm.jobs || [];
    const before = new Set(fm.jobs.map(j => j.id)), prev = fm.jobs.slice();
    const r = next();
    try {
      const ev = fm.ev30 = fm.ev30 || { due: [], m: -1, bm: 0, dm: 0, tot: 0 };
      const mi = monthIdx(S.week);
      if (ev.m !== mi) { ev.m = mi; ev.bm = 0; ev.dm = 0; }
      fm.jobs.forEach(j => { if (!before.has(j.id)) { dress(co, j, 'mkt'); ev.bm++; booked(co, j); } });
      const ids = new Set(fm.jobs.map(j => j.id));
      let nd = 0;
      prev.forEach(j => { if (!ids.has(j.id)) { nd++; ev.dm++; ev.tot++; delivered(co, j, ev); } });
      const room = Math.exp(-Math.max(0, (fm.backlogWk || 0) - 8) / 14);
      ev.due = ev.due.filter(d => {
        if (S.week < d.w) return true;
        if (co.st === 'open' && chance(room)) { const j = newJob(co, bd, d); fm.jobs.push(j); fm.won++; ev.bm++; booked(co, j); }
        return false;
      });
      ctx.units = nd; /* whole events delivered this week, not fractions of work done */
    } catch (e) { console.error(e); }
    return r;
  });


  /* ---------- 11: marketing ---------- */
  const X = window.R19 && R19.CHX;
  if (X) {
    /* real benchmarks (sources in the round notes), converted at about NOK 10.7 per USD */
    X.google.cpm = 50000; X.google.resp = 0.07;           /* WordStream 2024 search ads: CPC $4.66, conversion rate 6.96% */
    X.meta.cpm = 130;                                      /* Lebesgue: average Facebook CPM $12.15 in 2024 */
    X.flyer.cpm = 1200; X.flyer.resp = 0.005; X.flyer.conv = 0.25; /* JICMAIL 2024: door drops 0.6% response; NOK 1.20 a household is a game estimate */
    /* referral rewards: a new channel that only works once you have happy customers */
    CH.ref = { n: 'Referral rewards', eff: 3, sc: 2000, loc: 0.8, b2b: 1.2, mw: 0, note: 'Rewards customers who bring a friend or a client. Needs happy customers first.', opts: [0, 500, 1500, 4000] };
    X.ref = { cpm: 0, resp: 0.02, conv: 0.5, age: [1, 1, 1, 1], what: 'customers who could recommend you', loyal: 1 };
  }
  /* how well each channel suits each kind of business (game estimates), applied on top of the base table */
  const famAdj = { svc: { ref: 1.4 }, project: { ref: 1.8, flyer: 1, meta: 1, tiktok: 1 }, prod: { ref: 1.3 }, logi: { ref: 1.2 }, venue: { ref: 0.6, google: 2.2 }, retail: { ref: 0.5 }, fin: { ref: 1.4 }, rent: { ref: 0.8 } };
  Object.keys(famAdj).forEach(f => { CHAFF_FAM[f] = Object.assign(CHAFF_FAM[f] || {}, famAdj[f]); });
  const typeAdj = {
    photo: { meta: 1.5, tiktok: 1.5, ref: 1.5 },
    plumber: { google: 1.4, local: 1.3, flyer: 1.2, meta: 0.8 },
    webdev: { b2b: 1.2, google: 1.1, flyer: 0.4 },
    staffing: { b2b: 1.3, flyer: 0.4, tiktok: 0.6 },
    cons: { b2b: 1.3, ref: 1.5, flyer: 0.4, tiktok: 0.5 },
    carclean: { flyer: 1.3, local: 1.2, google: 1.2 }
  };
  Object.keys(typeAdj).forEach(t => { CHAFF_TYPE[t] = Object.assign(CHAFF_TYPE[t] || {}, typeAdj[t]); });
  /* an event agency's buyers depend on its focus: companies, concert-goers or couples */
  const AUD = { event: [0.85, 0.3, 0.1] };
  /* companies book through contacts, fairs and search; concert-goers through video and posters; couples through social, wedding fairs and friends */
  const EVFIT = [{ b2b: 1.4, fair: 1.3, google: 1.2, ref: 1.8, flyer: 0.6, meta: 0.8, tiktok: 0.5 }, { tiktok: 3.5, meta: 3, flyer: 2.5, bill: 1.5, b2b: 0.4, ref: 1.2 }, { meta: 2.8, tiktok: 2.2, flyer: 2, fair: 1.6, ref: 2, b2b: 0.2 }];
  CHAFF_TYPE.event = EVFIT[0];
  function withAud(co, fn) {
    const bd = co && BD[co.type], a = bd && AUD[bd.id];
    if (!a) return fn();
    const keep = bd.aud;
    const f = focusOf(co), tk = CHAFF_TYPE[bd.id];
    bd.aud = a[f] != null ? a[f] : keep;
    CHAFF_TYPE[bd.id] = EVFIT[f] || EVFIT[0];
    try { return fn(); } finally { bd.aud = keep; CHAFF_TYPE[bd.id] = tk; }
  }
  addStep('mktWeek.around', 10, 'an event agency reaches the audience of its focus', (co, run) => withAud(co, run));
  addStep('tune.around', 10, 'an event agency prices for the audience of its focus', (co, run) => withAud(co, run));
  /* how many people are actually shopping for this each week: few people buy a wedding or a car in any given week,
     so a big-ticket business runs out of interested buyers long before it runs out of people to show ads to (game estimate) */
  const UPP = { cons: 8, webdev: 40, cleaning: 3, hotel: 2, restaurant: 2 };
  R30.inMarket = (co, bd) => {
    const pop = ((cityOf(co.city) || {}).pop || 150) / 300;
    return Math.max(0.4, 3 * (bd.Dc || 1) / (UPP[bd.id] || 1) * Math.sqrt(Math.max(0.1, pop)));
  };
  /* what else decides a campaign's result: rivals and your price against theirs, and how long it has been running */
  window.R30M = function (co, bd, k) {
    let f = 1;
    try { f *= clamp(window.rivalMult ? window.rivalMult(co, bd) : 1, 0.3, 1.25); } catch (e) { }
    const m = co.mkt && co.mkt[k], wk = m ? S.week - (m.since != null ? m.since : S.week) : 0;
    f *= wk <= 0 ? 0.6 : wk === 1 ? 0.85 : wk > 26 ? 0.9 : 1; /* a new campaign starts slow; a long-running one gets tired */
    return f;
  };
  /* a likely range: campaign luck (creative, timing) and plain chance on top of the expected number */
  function range(mu, vol) {
    if (!(mu > 0)) return '0';
    const sl = vol ? 0.9 : 0.45, sh = vol ? 0.4 : 0.1;
    const lo = mu * Math.exp(-1.28 * sl - sh), hi = mu * Math.exp(1.28 * sl - sh);
    const L = Math.max(0, Math.floor(lo - 1.28 * Math.sqrt(lo))), H = Math.max(L + 1, Math.ceil(hi + 1.28 * Math.sqrt(hi)));
    return L + '–' + H;
  }
  R30.range = range;
  window.R30rng = (perWeek, k) => range(perWeek, X && X[k] && X[k].vol);
  if (window.R19) R19.planTxt = (co, PL) => {
    try {
      const bd = BD[co.type];
      if (!X || !X[PL.ch] || !bd.Dc) return '';
      return withAud(co, () => {
        const keep = co.mktT;
        co.mktT = { ag: PL.ag };
        const R = R19.chanCalc(co, bd, PL.ch, PL.b);
        co.mktT = keep;
        if (!R) return '';
        const w = PL.w || 13, ramp = w <= 1 ? 0.6 : (0.6 + 0.85 + Math.max(0, w - 2)) / w;
        let rv = 1;
        try { rv = clamp(window.rivalMult ? window.rivalMult(co, bd) : 1, 0.3, 1.25); } catch (e) { }
        const mu = R.cust * w * ramp * rv;
        return ' · reach ~' + Math.round(R.reach).toLocaleString('en-US').replace(/,/g, ' ') + '/wk · likely ' + range(mu, X[PL.ch].vol) + ' customers over ' + w + ' wk' + (PL.w ? '' : ' (13-wk view)');
      });
    } catch (e) { return ''; }
  };
  /* the marketing tab: one summary that keeps awareness, leads, new and repeat customers, revenue and profit apart */
  addStep('CT.marketing', 40, 'the marketing tab: one summary that keeps awareness, leads, new and repeat customers, revenue and profit apart', (co, bd, h) => {
    try {
      const s = co.mk19;
      if (!s || !s.ch || !Object.keys(s.ch).length) return h;
      const C = Object.keys(s.ch).map(k => s.ch[k]);
      const sp = sum(C, c => c.sp), le = sum(C, c => c.leads), nw = sum(C, c => c.cust), base = sum(C, c => c.base || 0), rev = sum(C, c => c.rev);
      const cm = Math.max(0.15, (bd.m || 0.1) + 0.25), prof = rev * cm - sp;
      h += '<h2 class="sec">All campaigns so far</h2><div class="card">' + row('Spent', money(sp)) + row('How well known', awWord(co.aware)) + row('Leads', le < 10 ? le.toFixed(1) : Math.round(le)) + row('New customers', Math.round(nw)) + row('Still buying from you', Math.round(base)) + row('Their purchases', money(rev)) + row('Profit after ad spend', '<span class="' + sgn(prof) + '">' + plus(prof) + '</span>', 'total') + '<span class="tipt">Profit is an estimate: their purchases times your usual margin, minus what the ads cost. Results vary: two identical campaigns can do very differently, and some weeks bring nobody.</span></div>';
    } catch (e) { console.error(e); }
    return h;
  });
  /* used by the planner to order channels: the real fit for this business, per krone */
  const FITB = { flyer: { svc: 1, venue: 1.1, retail: 1, project: 0.7, prod: 0.3, logi: 0.4 }, google: { svc: 1.2, venue: 0.8, retail: 0.9, project: 1.1, prod: 0.6, logi: 0.8 }, meta: { svc: 0.9, venue: 1.2, retail: 1.1, project: 0.5, prod: 0.5, logi: 0.5 }, tiktok: { svc: 0.6, venue: 1.2, retail: 1.1, project: 0.3, prod: 0.4, logi: 0.3 }, local: { svc: 1, venue: 1, retail: 1, project: 0.9, prod: 0.5, logi: 0.6 }, bill: { svc: 0.7, venue: 1, retail: 1.1, project: 0.6, prod: 0.5, logi: 0.6 }, seo: { svc: 1.1, venue: 0.8, retail: 1.1, project: 1, prod: 0.8, logi: 0.8 }, mail: { svc: 0.8, venue: 1.2, retail: 1.2, project: 0.4, prod: 0.6, logi: 0.5 }, b2b: { svc: 1, venue: 0.2, retail: 0.3, project: 1.1, prod: 1.2, logi: 1.1 }, fair: { svc: 0.6, venue: 0.3, retail: 0.4, project: 1, prod: 1.2, logi: 1 } };
  R30.chScore = (bd, k) => {
    const x = X && X[k];
    if (!x) return 0;
    const per = x.cpm ? 1000 / x.cpm * x.resp * x.conv * 1000 : x.resp * x.conv * 40;
    const aud = bd.aud || 0, aFit = x.b2b ? clamp(aud * 1.4, 0.08, 1.3) : clamp((1 - aud) + aud * ((CH[k] && CH[k].b2b) || 0.3), 0.15, 1);
    return ((FITB[k] || {})[bd.fam] || 0.5) * chAff(bd, k) * aFit * per;
  };
})();


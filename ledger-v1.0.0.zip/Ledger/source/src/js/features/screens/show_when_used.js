/* ---- features/screens/show_when_used.js ---- */
/* ===== Round 57: screens appear when they start to matter, so a new player is not met by everything at once.
   Each part shows from the first time it is used or becomes possible, and then stays (S.seen57). The triggers are
   broad on purpose (a first company, a first employee, a first complaint, a net worth), so nothing needs a
   particular path to unlock, and every page stays reachable from messages and links even while its row is hidden.
   Older saves (no S.seen57) show everything, and so does the test switch Settings › Ledger Pro › Screens (PRO.showAll).
   - Phone: Reviews once a company has been open a couple of weeks; Stats once you have a company; Luxury once you
     have a little money to spend; Private equity once you are a millionaire.
   - Inbox › Meetings once you have a manager.
   - Group › You: people and image once you have a company; trophies once you have won one; the business awards after
     the first year end; giving back once you are a millionaire. Group › Group: holding companies from two companies
     or a million; franchises, market, maps and each company's headquarters once you have a company.
   - A company's Complaints (the row on Sales and the dashboard box) once that company has had its first complaint. ===== */
window.SEEN57 = window.SEEN57 || {};
(function () {
  const Y = window.SEEN57;
  const live = () => (S.cos || []).filter(c => c.st !== 'sold' && c.st !== 'bust');
  const nw = () => { try { return netWorth().total; } catch (e) { return 0; } };
  const opened = () => live().some(c => c.st === 'open' || c.st === 'closed');
  const T = {
    stats: () => live().length > 0,
    reviews: () => live().some(c => c.st === 'open' && S.week - (c.wOpen != null ? c.wOpen : c.w0 || 0) >= 2),
    lux: () => S.cash >= KC(300000) || (S.lux && S.lux.length > 0),
    pe56: () => nw() >= KC(10e6),
    meet: () => !!(window.R35 && R35.hasMgr && R35.hasMgr()),
    people: () => opened() || S.week >= 8,
    trophies: () => !!(S.ach28 && Object.keys(S.ach28).length),
    awards: () => !!(S.aw56 && ((S.aw56.won || []).length || (S.aw56.years || []).length)),
    give: () => nw() >= KC(1e6),
    hold: () => live().filter(c => c.type !== 'hold').length >= 2 || nw() >= KC(1e6) || live().some(c => c.type === 'hold'),
    cos1: () => live().length > 0
  };
  Y.T = T;
  /* shown? the first time it is, it stays */
  Y.on = function (k) {
    const s = S && S.seen57;
    if (!s || (window.PRO && PRO.showAll)) return true; /* testing: Settings › Ledger Pro › Screens */
    if (s[k]) return true;
    let ok = false;
    try { ok = !T[k] || !!T[k](); } catch (e) { ok = true; }
    if (ok) s[k] = S.week || 1;
    return ok;
  };
  /* the phone's apps: Bank, Investing, News and Settings are always there */
  Y.app = n => n === 'reviews' || n === 'stats' || n === 'lux' || n === 'pe56' ? Y.on(n) : true;
  /* a company's complaints: from its first one */
  Y.cmp = co => !S.seen57 || (window.PRO && PRO.showAll) || !!(co && ((co.compl || []).length || co.cmp57)) && ((co.cmp57 = 1), true);
  Y.start = () => { S.seen57 = {}; };
})();

/* ===== Round 56: every company tab opens with its own dashboard, like the overview.
   The few numbers that matter for the tab sit in one card at the top, as tiles you can tap; what used to be long
   sections (marketing, how you sell, complaints) is one row each underneath and opens its own page. The tabs are
   put together in features/screens/menus_and_week_report.js (salesTab, staffTab, moneyTab, companyTab).
   - Sales: revenue last week and the last months, your price against the rivals, rating, how well known you are,
     what you sold, business customers, open complaints, and whether prices follow inflation
   - Staff: people and payroll, how busy the team is, skill, pay against the market, who is tired or leaving,
     your own hours or the manager
   - Money: cash, profit by month, margin, how long the cash lasts, what customers owe and what you owe
   - Company: what it is worth, premises and rent, equipment condition, paperwork, insurance and supplier ===== */
window.DASH56 = window.DASH56 || {};
(function () {
  const D = window.DASH56;
  const U = window.UI;
  if (!U) return;
  const { esc, chips } = U;
  const P = o => esc(JSON.stringify(o));
  const MN3 = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const plusS = v => (v >= 0 ? '+' : '−') + mshort(Math.abs(v));
  const sg = v => v > 0 ? 'pos' : v < 0 ? 'neg' : '';
  const pc = v => Math.round(v * 100) + '%';
  /* a tile: label, value, a line under it; a button when it opens something ([action, params]) */
  function tile(lab, val, sub, go, cls) {
    const inner = '<span>' + lab + '</span><b>' + val + '</b>' + (sub ? '<small>' + sub + '</small>' : '');
    return go ? '<button class="t56 ' + (cls || '') + '" data-a="' + go[0] + '" data-p="' + P(go[1]) + '">' + inner + '</button>' : '<div class="t56 ' + (cls || '') + '">' + inner + '</div>';
  }
  D.tile = tile;
  /* a tile about something further down the same page scrolls to its heading */
  U.ACT.sc56 = p => {
    const H = [...document.querySelectorAll('.screen h2.sec, .screen h3, .screen .bhead > b, .screen .lrow .ctext > b, .screen summary b')];
    const el = [].concat(p.h).map(h => String(h).toLowerCase()).map(h => H.find(e => e.textContent.toLowerCase().indexOf(h) >= 0)).find(Boolean); /* the first heading found, in the order given */
    if (el) (el.closest('.card, .lrow, details') || el).scrollIntoView({ block: 'start', behavior: 'smooth' });
  };
  const at = h => ['sc56', { h }];
  const page = (co, t, s) => ['go', { n: 'co', p: { id: co.id, t, s } }];
  /* the rating opens the company's reviews in the phone's Reviews app */
  U.ACT.rv56 = p => { try { U.ACT.phapp({ n: 'reviews' }); if (U.ACT.rvopen) U.ACT.rvopen({ k: 'c' + p.id }); } catch (e) { console.error(e); } };
  /* small bars for the last months; below the line when negative; the month still running is lighter */
  function bars(vals, labs) {
    if (vals.length < 2) return ''; /* one month alone is a block, not a trend: the chart waits for a second month */
    const mp = Math.max(0, ...vals), mn = Math.max(0, ...vals.map(v => -v)), tot = mp + mn || 1;
    const up = mp / tot * 100, dn = 100 - up;
    return '<div class="bars56">' + vals.map((v, i) => '<i' + (i === vals.length - 1 ? ' class="cur"' : '') + '><em style="height:' + up + '%"><b style="height:' + (v > 0 ? Math.max(4, v / (mp || 1) * 100) : 0) + '%"></b></em><em class="dn" style="height:' + dn + '%"><b style="height:' + (v < 0 ? Math.max(4, -v / (mn || 1) * 100) : 0) + '%"></b></em><u>' + labs[i] + '</u></i>').join('') + '</div>';
  }
  D.bars = bars;
  /* the last five finished months and the one running: [values, labels] */
  function months(co, f, now) {
    const H = (co.hist || []).slice(-5), L = H.map(x => MN3[((x.m % 12) + 12) % 12][0]);
    return [H.map(f).concat([now]), L.concat([MN3[monthIdx(S.week) % 12][0]])];
  }
  function card(lab, big, sub, right, tiles, foot, cls) {
    return '<div class="card dash56 ' + (cls || '') + '"><div class="dh56"><div><span class="lab">' + lab + '</span><b class="huge">' + big + '</b>' + (sub ? '<small class="mo56">' + sub + '</small>' : '') + '</div>' + (right || '') + '</div><div class="t56grid">' + tiles.join('') + '</div>' + (foot || '') + '</div>';
  }
  D.card = card;
  /* the line under a row's title, from rows found on a tab ({a, p, html}) */
  const subOf = r => r ? ((/<small>([\s\S]*?)<\/small>/.exec(r.html) || [])[1] || '').replace(/<[^>]+>/g, '') : '';
  const goOf = r => r ? [r.a, r.p] : null;

  /* ---------------- Sales ---------------- */
  D.sales = function (co, bd) {
    const w = co.lastW || {}, bm = co.bk.m || {}, last = co.hist[co.hist.length - 1];
    const [V, L] = months(co, x => x.rev || 0, bm.rev || 0);
    const pi = CT.priceInfo ? CT.priceInfo(co, bd) : { tk: ticketEff(co, bd), avg: 0, d: 0, n: 0 };
    const noP = window.R8 && R8.noPrice ? R8.noPrice(bd) : false;
    const T = [];
    if (!noP) T.push(tile('Your price', mshort(pi.tk), pi.avg ? (Math.abs(pi.d) < 0.03 ? 'level with rivals' : (pi.d > 0 ? '+' : '−') + Math.abs(Math.round(pi.d * 100)) + '% vs rivals') + (pi.pw ? ' · price war' : '') : 'no rivals near', ['go', { n: 'pricemoves', p: { id: co.id } }], pi.pw ? 'warn' : ''));
    const sold = window.soldLabel ? soldLabel(bd.unit) : unitPl(bd.unit, 2);
    T.push(tile(esc(sold) + ' last week', window.fmtU ? fmtU(w.units || 0, bd.unit).replace(/ .*/, '') : Math.round(w.units || 0), w.cap ? pc(Math.min(1, w.util || 0)) + ' of capacity' : '', ['go', { n: 'res36', p: { id: co.id } }]));
    T.push(tile('Rating', '★ ' + ratingOf(co).toFixed(1), esc(repWord(co.rep).toLowerCase()), ['rv56', { id: co.id }]));
    T.push(tile('Known', esc(awWord(co.aware)), mktCost(co) > 0 ? mshort(mktCost(co)) + ' ads a week' : 'no ads running', ['cotab', { id: co.id, v: 'cli', s: 'mk' }]));
    const nb = (co.accts || []).length + ((co.sw33 && co.sw33.ct) || []).length;
    T.push(tile('Business customers', nb, nb ? 'regular buyers' : 'none yet', ['codeal', { id: co.id, s: 'cust' }]));
    const open = (co.compl || []).filter(c => c.st === 'open').length;
    if (!noP && (!window.SEEN57 || SEEN57.cmp(co))) T.push(tile('Complaints', open, open ? 'waiting for an answer' : 'none open', ['cotab', { id: co.id, v: 'cli', s: 'cmp' }], open ? 'bad' : ''));
    let foot = '';
    if (!noP) {
      const gap = window.R8 && R8.inflGap ? R8.inflGap(co) : 0;
      foot = '<div class="bhead infl30"><span>Prices follow inflation</span>' + chips([[1, 'Yes'], [0, 'Hold']], co.inflHold ? 0 : 1, 'inflset', { id: co.id }) + '</div>' + (gap > 0.005 ? '<span class="tipt">You are about ' + Math.round(gap * 100) + '% cheaper than the market. It wins customers and squeezes weak rivals, but your costs keep rising.</span>' : '');
    }
    return card('Sales last week', mshort(w.rev || 0), MN3[monthIdx(S.week) % 12] + ' so far ' + mshort(bm.rev || 0) + (last ? ' · last month ' + mshort(last.rev || 0) : ''), bars(V, L), T, foot);
  };

  /* ---------------- Staff ---------------- */
  D.staff = function (co, bd) {
    const L = co.staff.filter(s => !s.gone), on = L.filter(s => !s.off), w = co.lastW || {};
    const last = co.hist[co.hist.length - 1];
    const pay = last && last.bk && last.bk.wages ? last.bk.wages : sum(L, s => s.wage || 0);
    const m = co.mgr && S.npcs[co.mgr];
    const roles = {};
    on.forEach(s => { roles[s.role] = (roles[s.role] || 0) + 1; });
    const rl = Object.keys(roles).sort((a, b) => roles[b] - roles[a]).slice(0, 3).map(r => roles[r] + ' ' + esc((window.roleName ? roleName(r, co) : (ROLES[r] ? ROLES[r][0] : r)).toLowerCase())).join(' · ');
    const T = [];
    const u = Math.min(1.2, w.util || 0);
    T.push(tile('Team busy', w.cap ? pc(Math.min(1, u)) : '–', u > 0.97 ? 'stretched, overtime' : u > 0.75 ? 'busy' : u > 0.35 ? 'room for more' : 'quiet', ['go', { n: 'hire', p: { id: co.id } }], u > 0.97 ? 'warn' : ''));
    const sk = on.length ? sum(on, s => staffSkill(s)) / on.length : 0;
    T.push(tile('Skill', on.length ? Math.round(sk) : '–', on.length ? (sk >= 70 ? 'strong team' : sk >= 50 ? 'decent' : 'learning') : 'no one yet', V_ACAD(co, bd) || at('staff')));
    const gap = co.payGap || 0;
    T.push(tile('Pay', gap > 0.06 ? 'Behind' : gap < -0.08 ? 'Generous' : 'Fair', gap > 0.06 ? 'people may leave' : 'against the market', ['go', { n: 'payroll29', p: { id: co.id, v: 'pay' } }], gap > 0.06 ? 'warn' : gap < -0.08 ? 'good' : ''));
    const tired = on.filter(s => (s.tired || 0) > 60).length, sick = on.filter(s => typeof sickNow === 'function' && sickNow(s)).length;
    T.push(tile('Tired or sick', tired + sick, sick ? sick + ' off sick' : tired ? 'working too long' : 'everyone fine', at('staff'), tired + sick ? 'warn' : ''));
    const lv = L.filter(s => s.notice > 0).length;
    T.push(tile('Leaving', lv, lv ? 'on notice' : 'no one', lv ? at('staff') : ['go', { n: 'hire', p: { id: co.id } }], lv ? 'bad' : ''));
    T.push(m ? tile('Manager', esc(m.name.split(' ')[0]), co.mgrNotice ? 'leaves ' + dateStr(co.mgrNotice.w) : mshort(co.mgrWage || 0) + ' a month', co.mgrNotice ? ['go', { n: 'mgrhire', p: { id: co.id } }] : ['go', { n: 'mgmt56', p: { id: co.id } }], co.mgrNotice ? 'bad' : '') : tile('Your hours', (co.ohrs || 0) + ' h', 'a week here', at('you (owner)')));
    return card('Team', on.length + (on.length === 1 ? ' person' : ' people') + (m ? ' + manager' : ''), (rl ? rl + ' · ' : '') + 'payroll ' + mshort(pay) + ' a month', '', T);
  };
  /* courses open from the skill tile when the trade has them */
  const V_ACAD = (co, bd) => (U.V.academy && bd.crs && bd.crs.length ? ['acad36', { id: co.id }] : null);

  /* ---------------- Money ---------------- */
  D.money = function (co, bd, R) {
    const bm = co.bk.m || {}, mp = (bm.rev || 0) - sumExp(bm), last = co.hist[co.hist.length - 1];
    const [V, L] = months(co, x => x.profit || 0, mp);
    const by = k => (R || []).find(r => r.key === k);
    const recv = sum(co.recv || [], r => r.a), bills = co.pay.wages + co.pay.other + co.pay.rent + co.pay.tax + Math.max(0, co.vatAcc || 0);
    const debt = sum(S.loans.filter(l => l.co === co.id), l => l.bal || 0);
    const T = [];
    const mg = last && last.rev > 0 ? last.profit / last.rev : null;
    T.push(tile('Margin', mg == null ? '–' : Math.round(mg * 100) + '%', 'last month', ['go', { n: 'res36', p: { id: co.id } }], mg != null && mg < 0 ? 'bad' : ''));
    const wc = coWeekCost(co), wks = wc > 0 ? co.cash / wc : 999;
    T.push(tile('Cash lasts', co.cash <= 0 ? 'Empty' : wks > 104 ? '2+ years' : wks >= 10 ? Math.round(wks) + ' weeks' : wks.toFixed(1) + ' weeks', 'of costs, with no sales', ['go', { n: 'payroll29', p: { id: co.id } }], co.cash <= 0 || wks < 4 ? 'bad' : wks < 10 ? 'warn' : ''));
    T.push(tile('Owed to you', mshort(recv), recv ? 'unpaid invoices' : 'nothing', recv ? ['invsheet', { id: co.id }] : ['go', { n: 'res36', p: { id: co.id } }]));
    T.push(tile('Bills to pay', mshort(bills), 'wages, rent, tax, VAT', ['go', { n: 'payroll29', p: { id: co.id } }]));
    T.push(tile('Loans', debt ? mshort(debt) : 'None', debt ? 'still to repay' : 'debt-free', goOf(by('loans')) || page(co, 'fin', 'loans')));
    T.push(tile('Worth', mshort(companyValue(co)), co.own < 100 ? 'you own ' + Math.round(co.own) + '%' : 'you own all of it', goOf(by('value')) || page(co, 'fin', 'value')));
    return card('Company cash', '<span class="' + (co.cash < 0 ? 'neg' : '') + '">' + nok(co.cash) + '</span>', MN3[monthIdx(S.week) % 12] + ' so far <b class="' + sg(mp) + '">' + plusS(mp) + '</b>' + (last ? ' · last month <b class="' + sg(last.profit) + '">' + plusS(last.profit) + '</b>' : ''), bars(V, L), T);
  };


  /* ---------------- the sub-pages: a few numbers on top of each (menus_and_week_report.js puts them under the title) ---------------- */
  D.sub = function (co, bd, k) {
    const T = [];
    const pr = co.prem || {};
    if (k === 'assets') {
      let n = 0, c = 0, val = 0, worn = 0;
      Object.keys(co.eq || {}).forEach(id => { const e = co.eq[id]; if (e && e.n > 0) { n += e.n; c += Math.min(1, e.cond || 0) * e.n; val += e.bv || 0; if ((e.cond || 1) < 0.5) worn++; } });
      (co.veh || []).forEach(v => { val += v.bv || v.val || 0; });
      T.push(tile('Premises', pr.m2 ? Math.round(pr.m2) + ' m²' : 'None', pr.owned ? 'owned, no rent' : pr.m2 ? mshort(pr.rent * pr.m2 / 12) + ' rent a month' : '', at('in place')));
      T.push(tile('Equipment worth', mshort(val), n + (n === 1 ? ' item' : ' items'), at('in place')));
      T.push(tile('Condition', n ? Math.round(c / n * 100) + '%' : '–', worn ? worn + ' worn out' : 'nothing worn out', at('condition'), worn ? 'warn' : ''));
      return T;
    }
    if (k === 'docs') {
      const need = docNeeds(co).filter(d => d !== 'mva_na');
      const ok = need.filter(d => docOk(co, d)).length, pend = need.filter(d => co.docs[d] && co.docs[d].st === 'applied').length, miss = need.length - ok - pend;
      T.push(tile('Approved', ok + ' of ' + need.length, 'documents', at('documents'), miss ? '' : 'good'));
      T.push(tile('Missing', miss, miss ? 'an inspection can fine you' : 'none', at('documents'), miss ? 'bad' : ''));
      T.push(tile('Being processed', pend, pend ? 'answer in a few weeks' : 'nothing waiting', at('documents')));
      return T;
    }
    if (k === 'rivals') {
      let rs = [];
      try { rs = rivalsOf(co); } catch (e) { }
      const pi = CT.priceInfo ? CT.priceInfo(co, bd) : { avg: 0, d: 0 };
      T.push(tile('Rivals', rs.length, 'in ' + esc(cityOf(co.city).name), at('rivals in')));
      T.push(tile('Their price', pi.avg ? mshort(pi.avg) : '–', pi.avg ? (Math.abs(pi.d) < 0.03 ? 'you are level' : 'you are ' + (pi.d > 0 ? '+' : '−') + Math.abs(Math.round(pi.d * 100)) + '%') : '', ['go', { n: 'pricemoves', p: { id: co.id } }]));
      T.push(tile('For sale', rs.filter(r => r.listed).length, 'owners ready to sell', at('rivals in')));
      return T;
    }
    if (k === 'loans') {
      const L = S.loans.filter(l => l.co === co.id), debt = sum(L, l => l.bal || 0), pay = sum(L, l => l.pay || 0);
      const rate = L.length && typeof policy === 'function' ? sum(L, l => (policy() + (l.margin || 0)) * (l.bal || 0)) / Math.max(1, debt) : 0;
      T.push(tile('Debt', debt ? mshort(debt) : 'None', L.length + (L.length === 1 ? ' loan' : ' loans'), at('loans')));
      T.push(tile('Repayments', pay ? mshort(pay) : '–', 'a month', at('loans')));
      T.push(tile('Interest', debt ? (rate * 100).toFixed(1) + '%' : '–', 'a year, on average', at('loans')));
      return T;
    }
    if (k === 'supply') {
      const ge = typeof goodsEff === 'function' ? goodsEff(co) : {}, last = co.hist[co.hist.length - 1], cogs = last && last.bk ? last.bk.cogs || 0 : (co.bk.m || {}).cogs || 0;
      T.push(tile('Goods from', ge.v ? esc(ge.v.name) : 'The market', ge.v ? '★ ' + (typeof vendRating === 'function' ? vendRating(ge.v).toFixed(1) : '') : 'whoever is cheapest', at('suppliers')));
      T.push(tile('Goods last month', mshort(cogs), last && last.rev ? Math.round(cogs / last.rev * 100) + '% of sales' : '', ['go', { n: 'res36', p: { id: co.id } }]));
      T.push(tile('Price against market', ge.m ? (ge.m < 0.995 ? '−' + Math.round((1 - ge.m) * 100) + '%' : ge.m > 1.005 ? '+' + Math.round((ge.m - 1) * 100) + '%' : 'Level') : '–', 'what you pay', at('supply chain'), ge.m && ge.m < 0.995 ? 'good' : ''));
      return T;
    }
    if (k === 'cust') {
      const A = co.accts || [], C = (co.sw33 && co.sw33.ct) || [];
      T.push(tile('Regular customers', A.length, A.length ? 'companies that buy often' : 'none yet', at('regular customers')));
      T.push(tile('Contracts', C.length, C.filter(c => c.pub).length ? C.filter(c => c.pub).length + ' public' : 'running now', at(['contract', 'regular customers'])));
      if (window.TND56) T.push(tile('Tenders', TND56.open ? TND56.open(co).length : 0, 'open to bid', ['go', { n: 'tnd56', p: { id: co.id } }]));
      return T;
    }
    if (k === 'ins') {
      const L = Object.keys(INSP).filter(x => co.ins[x]), prem = sum(L, x => typeof insPremium === 'function' ? insPremium(co, x) : 0) * 52;
      const gap = ['prop', 'liab', 'cyber', 'bi'].find(x => !co.ins[x]);
      T.push(tile('Policies', L.length + ' of ' + Object.keys(INSP).length, L.length ? 'running' : 'nothing insured', at('policies'), L.length ? '' : 'warn'));
      T.push(tile('Premiums', prem ? mshort(prem) : '–', 'a year', at('policies')));
      T.push(tile('Not covered', gap ? esc(INSP[gap][0].split(' ')[0]) : 'Nothing big', gap ? 'a loss here is all yours' : '', at(gap ? INSP[gap][0] : 'policies'), gap ? 'warn' : 'good'));
      return T;
    }
    return T;
  };
  D.subCard = (co, bd, k) => { const T = D.sub(co, bd, k); return T.length ? '<div class="card dash56 sub56"><div class="t56grid">' + T.join('') + '</div></div>' : ''; };

  /* ---------------- Company ---------------- */
  D.company = function (co, bd, R) {
    const by = k => (R || []).find(r => r.key === k);
    const pr = co.prem || {};
    const T = [];
    T.push(tile('Premises', pr.m2 ? Math.round(pr.m2).toLocaleString('en-US').replace(/,/g, ' ') + ' m²' : 'None', esc(pr.lname || (pr.m2 ? '' : 'find a place')), goOf(by('assets')) || page(co, 'ops', 'assets'), pr.m2 ? '' : 'bad'));
    T.push(tile('Rent', pr.owned ? 'Owned' : pr.m2 ? mshort(pr.rent * pr.m2 / 12) : '–', pr.owned ? 'no rent to pay' : pr.m2 ? 'a month' : '', goOf(by('assets')) || page(co, 'ops', 'assets')));
    let n = 0, c = 0;
    Object.keys(co.eq || {}).forEach(k => { const e = co.eq[k]; if (e && e.n > 0) { n += e.n; c += Math.min(1, e.cond || 0) * e.n; } });
    const cond = n ? c / n : null;
    T.push(tile('Equipment', cond == null ? 'None' : Math.round(cond * 100) + '%', cond == null ? '' : cond < 0.5 ? 'worn, breaks more' : 'condition', goOf(by('assets')) || page(co, 'ops', 'assets'), cond != null && cond < 0.5 ? 'warn' : ''));
    const ds = subOf(by('docs')), dbad = /missing|pending|expir|late/i.test(ds);
    T.push(tile('Paperwork', dbad ? ((/(\d+)/.exec(ds) || [])[1] || '!') + ' open' : 'In order', dbad ? esc(ds.replace(/^\d+\s*/, '')) : 'all documents valid', goOf(by('docs')) || page(co, 'ops', 'docs'), dbad ? 'bad' : ''));
    const ni = Object.keys(co.ins || {}).filter(k => co.ins[k]).length;
    T.push(tile('Insurance', ni ? ni + (ni === 1 ? ' policy' : ' policies') : 'None', ni ? 'claims are covered' : 'every loss is yours', goOf(by('ins')) || page(co, 'ops', 'ins'), ni ? '' : 'warn'));
    const sp = by('supply');
    T.push(sp ? tile('Supplier', esc(subOf(sp).split(' · ')[0] || '–'), 'buys for you', goOf(sp)) : tile('Founded', co.wOpen != null ? dateStr(co.wOpen) : 'Not open', esc(co.form), page(co, 'ops', 'docs')));
    const age = co.wOpen != null ? S.week - co.wOpen : 0;
    return card('Company value', mshort(companyValue(co)), esc(co.form) + ' · ' + (co.wOpen != null ? (age < 52 ? 'open ' + Math.max(1, age) + (age === 1 ? ' week' : ' weeks') : 'open ' + (age / 52).toFixed(1) + ' years') : 'not open yet') + (co.mgr ? ' · managed' : ' · you run it'), '', T);
  };
})();

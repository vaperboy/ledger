/* ===== Round 37: a newcomer nobody has heard of, premises that match the company, and everything on one line.
   - Chains: the chain screens no longer open stores; a new store is started from New company like any company.
   - Expand: the "More sites" box is gone (another site is simply a new company).
   - Rivals only know you once you take a real share of their market or cross them (round 27a/28b/31 sources).
   - People you know: relationship words on the 0-100 scale where 40 is a plain acquaintance (round 31 source).
   - Pop-ups and message cards show their whole title.
   - Companies that start at home can rent or buy an office; a team of four or more outgrows the kitchen table.
   - The overview picture follows the real premises (round 28a source).
   - Decision limits and other choice rows fit on one line. ===== */
window.R37 = window.R37 || {};
(function () {
  'use strict';
  const R37 = window.R37;
  const U = window.UI;
  if (!U) return;
  const { ui, V, ACT, esc, row, btn, card, go, render, save, svg, openSheet, closeSheet, toast } = U;
  const CT = window.CT;
  const P = o => esc(JSON.stringify(o));
  const live = () => S.cos.filter(c => c.st !== 'sold' && c.st !== 'bust');
  const rowBtn = (a, p, ic, title, sub, right) => '<button class="lrow" data-a="' + a + '" data-p="' + P(p) + '"><span class="lic">' + svg(ic, 20) + '</span><span class="ctext"><b>' + title + '</b>' + (sub ? '<small>' + esc(sub) + '</small>' : '') + '</span>' + (right || '<i>›</i>') + '</button>';

  /* ================= rivals you have never met ================= */
  if (typeof relLabel === 'function') {
  }

  /* ================= an office for companies that start at home ================= */
  const homeTrade = co => !!(co && BD[co.type] && BD[co.type].prem && BD[co.type].prem[0] === 'home');
  const heads = co => (co.staff || []).length + (co.mgr ? 1 : 0) + (!co.mgr && (co.ohrs || 0) > 0 ? 1 : 0);
  /* round 45: a trade that started at home moves into its natural kind of place (a workshop for a plumber, an office for an agency) */
  const baseKind = co => { const b = BD[co.type]; return b && b.prem45 ? b.prem45[0] : 'office'; };
  const placeW = co => ({ office: 'office', industrial: 'workshop', warehouse: 'warehouse', retail: 'shop', clinic: 'clinic' }[baseKind(co)] || 'place');
  R37.placeW = placeW;
  R37.homeTrade = homeTrade;
  const offM2 = co => { const b = BD[co.type]; const o = Math.max(20, Math.round(Math.max(3, heads(co) + 1) * 9 / 5) * 5); return b && b.prem45 && b.prem45[0] !== 'office' ? Math.max(o, Math.round(b.prem45[1] * Math.max(0.3, Math.min(1, (co.size || 1))) * 0.6 / 5) * 5) : o; };
  const atHome = co => homeTrade(co) && !(co.prem && co.prem.m2);
  R37.atHome = atHome;
  function asOffice(co, f) {
    const bd = BD[co.type], old = bd.prem;
    bd.prem = [baseKind(co), offM2(co)];
    try { return f(); } finally { bd.prem = old; }
  }
  /* listings for an office, kept apart from the home trade's own (empty) list */
  if (typeof premListings === 'function') {
    R37.homeListings = function (co) {
      const want = offM2(co), key = S.seed + ':pl37:' + co.type + ':' + co.city + ':' + want + ':' + Math.floor(S.week / 26);
      if (_catMemo[key]) return _catMemo[key];
      const R = hrng(key), C = CO[co.country || S.country] || CC();
      const L = PL_TIERS.map((t, i) => ({ i, n: PL_TIERS_B[i], m2: Math.max(15, Math.round(want * t[1] * (0.92 + R() * 0.16) / 5) * 5), rentF: t[2] * (0.94 + R() * 0.12), loc: t[3], landlord: C.nameA[Math.floor(R() * C.nameA.length)] + ' ' + PL_WORDS[Math.floor(R() * PL_WORDS.length)] }));
      _catMemo[key] = L;
      return L;
    };
  }
  if (ACT.premsheet) {
    ACT.premsheet = pipeView('ACT.premsheet:2', ACT.premsheet, 1);
    addStep('ACT.premsheet:2.around', 10, 'a home trade looks for an office', (p, next) => { const co = getCo(p && p.id); return homeTrade(co) ? asOffice(co, () => next()) : next(); });
  }
  if (ACT.premset) {
    ACT.premset = pipeView('ACT.premset:2', ACT.premset, 1);
    addStep('ACT.premset:2.around', 10, 'a home trade that signs for space gets an office', (p, next) => { const co = getCo(p && p.id); if (homeTrade(co)) co.off37 = Date.now(); return homeTrade(co) ? asOffice(co, () => next()) : next(); });
  }
  /* a home trade that signs for space gets an office, also when the move is confirmed later */
  if (typeof setPrem === 'function') {
    R37.placeKind = function (co, kind, m2) {
      if (homeTrade(co) && kind === 'home' && m2 > 0 && co.off37 && Date.now() - co.off37 < 6e5) { kind = baseKind(co); delete co.off37; }
      return kind;
    };
  }
  ACT.home37 = p => {
    const co = getCo(p.id);
    if (!co) return;
    U.confirmThen('Give up the ' + placeW(co) + '?', 'Everyone works from home again. ' + (co.prem && co.prem.owned ? 'The building is sold at today’s value and the mortgage paid off.' : 'The deposit comes back.'), 'Move home', () => {
      try {
        if (co.prem && co.prem.owned) {
          const l = S.loans.find(x => x.id === co.prem.loan);
          const val = co.prem.val || 0, debt = l ? l.bal : 0;
          if (l) S.loans.splice(S.loans.indexOf(l), 1);
          coIn(co, Math.max(0, val - debt), null, 'Office sold');
          if (debt > val) payCo(co, debt - val, null, 'Mortgage shortfall');
        }
        setPrem(co, 'home', 0, false);
        save(); render(true);
      } catch (e) { console.error(e); }
    });
  };
  /* the Premises tab: a home company can move into an office, and back */
  addStep('CT.eq:2', 10, 'the Premises tab: a home company can move into an office, and back', (co, bd, h) => {
    try {
      if (!homeTrade(co) || (ui.eqt || 'need') !== 'place') return h;
      const n = heads(co), big = n >= 4;
      const W = placeW(co), perk = window.R45 && R45.perks ? R45.perks(co) : 'Clients take you more seriously.';
      let x = '<div class="card"><div class="bhead"><b>' + (atHome(co) ? 'A ' + W + ' of your own' : 'Your ' + W) + '</b>' + (atHome(co) && big ? '<span class="pill red">Outgrown</span>' : '') + '</div>';
      if (atHome(co)) x += '<span class="tipt">' + (big ? n + ' people working out of your home: morale and quality slip every week. ' : 'Working from home costs nothing, but nobody else can work there: to hire anyone you need a place. From home, people only hear of you from happy customers. ') + 'A ' + W + ' of about ' + offM2(co) + ' m²: ' + perk + '</span>' + btn('Find a ' + W, 'premsheet', { id: co.id }, 'primary wide');
      else x += row('Room for', Math.floor(co.prem.m2 / 9) + ' people · you have ' + n) + btn('Move or buy another ' + W, 'premsheet', { id: co.id }, 'wide') + btn('Move back home', 'home37', { id: co.id }, 'ghost wide');
      return h + x + '</div>';
    } catch (e) { console.error(e); return h; }
  });
  /* a big team at home: morale and quality slip, clients notice */
  addStep('week.after', 55, 'newcomer_premises_one_line weekly', () => {
    try {
      live().filter(c => c.st === 'open' && atHome(c) && heads(c) >= 4).forEach(c => {
        const k = heads(c) >= 6 ? 2 : 1;
        c.mood = Math.max(25, (c.mood != null ? c.mood : 60) - k);
        c.q = Math.max(35, (c.q != null ? c.q : 50) - 0.3 * k);
      });
    } catch (e) { console.error(e); }
  });
  addStep('window.coAlerts', 30, 'newcomer_premises_one_line window.coAlerts', (co, out) => {
    try { if (co && co.st === 'open' && atHome(co) && heads(co) >= 4) out.push(['Outgrown the home office', heads(co) >= 6 ? 'bad' : 'warn']); } catch (e) { }
    return out;
  });
  /* a route can ask for a tab inside the equipment page once */
  V.co = pipeView('V.co:3', V.co, 1); /* V.co: the screen above, then the steps below and in later files */
  addStep('V.co:3.route', 10, 'a route can ask for a tab inside the equipment page once', (p) => { if (p && p.eqt && !p.eq37) { ui.eqt = p.eqt; p.eq37 = 1; } });

  /* ================= one line: rows of choices that would wrap are reshaped after each render ================= */
  function fitChips() {
    document.querySelectorAll('.chips:not(.pct37):not(.grid37):not(.col37)').forEach(c => {
      const k = [...c.children].filter(x => x.tagName === 'BUTTON');
      if (k.length < 2 || !c.offsetParent || c.closest('.sheet.plan') || c.closest('.ichat') || getComputedStyle(c).display === 'grid') return;
      const wraps = () => new Set(k.map(x => Math.round(x.getBoundingClientRect().top / 6))).size > 1;
      if (!wraps()) return;
      if (k.every(x => /^\d+% · /.test(x.textContent.trim()))) {
        k.forEach(x => { const m = /^(\d+%) · (.*)$/.exec(x.textContent.trim()); x.innerHTML = '<b>' + esc(m[1]) + '</b><small>' + esc(m[2]) + '</small>'; });
        c.classList.add('pct37');
        return;
      }
      /* short labels: an even grid, one row if it fits, otherwise rows of three; long labels: one per line */
      const short = k.every(x => x.textContent.trim().length <= 12);
      if (short || k.length <= 4) {
        c.classList.add('grid37'); c.style.setProperty('--n37', Math.min(k.length, 5));
        if (!k.some(x => x.scrollWidth > x.clientWidth + 1)) return;
        if (short && k.length > 3) { c.style.setProperty('--n37', 3); if (!k.some(x => x.scrollWidth > x.clientWidth + 1)) return; }
        c.classList.remove('grid37');
      }
      c.classList.add('col37');
    });
  }
  R37.fitChips = fitChips;
  let fitQ = 0;
  new MutationObserver(() => { if (fitQ) return; fitQ = 1; requestAnimationFrame(() => { fitQ = 0; try { fitChips(); } catch (e) { } }); }).observe(document.body, { childList: true, subtree: true });
  document.addEventListener('toggle', () => requestAnimationFrame(() => { try { fitChips(); } catch (e) { } }), true);

})();


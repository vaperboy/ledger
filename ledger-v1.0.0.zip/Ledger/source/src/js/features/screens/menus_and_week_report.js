/* ===== Round 35: every menu where you look for it, a one-screen week report.
   Company tabs: Overview · Sales · Staff · Money · Company (ui/company/view.js).
   Bottom bar: Office is now Group (You · Group · Deals · Office), Meetings is now Inbox (Waiting · Messages · Email · Meetings).
   Phone keeps only phone things: Bank, Investing, News, Reviews, Stats, Tax office, Luxury, Settings.
   Week report: one screen, no scrolling; every box opens the detail. Numbers count up once per week, not on every tap. ===== */
window.R35 = window.R35 || {};
(function () {
  'use strict';
  const R35 = window.R35;
  const U = window.UI;
  if (!U) return;
  const { ui, V, ACT, esc, row, btn, card, go, render, save, svg, openSheet, closeSheet } = U;
  const P = o => esc(JSON.stringify(o));
  const live = () => S.cos.filter(c => c.st !== 'sold' && c.st !== 'bust');
  const sgn = v => v > 0 ? 'pos' : v < 0 ? 'neg' : '';
  const plus = v => (v >= 0 ? '+' : '−') + mshort(Math.abs(v));
  /* the company tabs (Overview · Sales · Staff · Money · Company) are ui/company/view.js; boards are features/company/shelf_stock_chains_boards.js (R12.anyBoard) */
  ACT.acad36 = p => { ui.acad = { co: p.id }; go('academy'); };
  V.titles.academy = 'Courses';

  /* ================= week report: one screen ================= */
  const COSTN = { cogs: 'Materials and goods', wages: 'Wages and payroll', rent: 'Rent and power', mkt: 'Marketing', ins: 'Insurance', acc: 'Accounting', dep: 'Depreciation', int: 'Interest', oth: 'Leasing and other costs', fine: 'Fines', loss: 'Refunds and losses' };
  function nums() {
    const r = S.lastRep || {}, L = S.wk31 || [], a = L[L.length - 1], b = L[L.length - 2] || null;
    if (a) return { a: 1, nw: a.nw, cash: a.cash, rev: a.rev, profit: a.profit, sh: a.sh, p: b ? { nw: b.nw, cash: b.cash, rev: b.rev, profit: b.profit, sh: b.sh } : null };
    const bw = r.bw || {}, rev = bw.rev || 0, nw = netWorth().total;
    return { a: 0, nw, cash: S.cash, rev, profit: rev - sumExp(bw), sh: 0, p: r.nw0 != null ? { nw: r.nw0 } : null };
  }
  const NUMN = { nw: 'Net worth', cash: 'Cash', rev: 'Revenue', profit: 'Profit', sh: 'Shares' };
  function evTone(e) { return e.tone === 'good' ? 'g' : e.tone === 'bad' ? 'r' : ''; }
  V.weekreport = function () {
    const r = S.lastRep;
    if (!r) return '<div class="calm">The first report arrives at the end of your first full week.</div>';
    const n = nums();
    const key = (r.w || 0) + ':' + Math.round(r.nw0 || 0) + ':' + (S.wk31 ? S.wk31.length : 0);
    const anim = ui.wr35k !== key;
    ui.wr35k = key;
    const val = (k, cls) => anim ? '<b class="cnt28 ' + (cls || '') + '" data-to="' + Math.round(n[k] || 0) + '">' + mshort(0) + '</b>' : '<b class="' + (cls || '') + '">' + mshort(n[k] || 0) + '</b>';
    const dv = k => n.p && n.p[k] != null ? n[k] - n.p[k] : null;
    const tap = k => n.a ? ' data-a="fin31" data-p="' + P({ k }) + '"' : ' data-a="none"';
    const tile = k => { const d = dv(k); return '<button class="card wt35"' + tap(k) + '><span>' + NUMN[k] + '</span>' + val(k, k === 'profit' ? sgn(n.profit) : '') + '<em class="' + (d == null ? '' : sgn(d)) + '">' + (d == null ? '–' : plus(d)) + '</em></button>'; };
    const dnw = dv('nw');
    let h = '<button class="card wnw35"' + tap('nw') + '><span class="lab">Net worth</span>' + val('nw', 'huge') + '<em class="' + (dnw == null ? '' : sgn(dnw)) + '">' + (dnw == null ? 'First week' : plus(dnw) + ' vs last week') + '</em><i>›</i></button>';
    const ks = ['cash', 'rev', 'profit'].concat(n.sh || (n.p && n.p.sh) ? ['sh'] : []);
    h += '<div class="wtiles35 n' + ks.length + '">' + ks.map(tile).join('') + '</div>';
    /* companies, best and worst first */
    const cs = (r.cos || []).slice().sort((x, y) => Math.abs(y.profit) - Math.abs(x.profit));
    h += '<button class="card wbox35" data-a="wr35s" data-p="' + P({ k: 'cos' }) + '"><div class="bhead"><b>Companies</b><small>' + (cs.length ? cs.length + ' · see all ›' : '') + '</small></div>' + (cs.length ? cs.map(c => '<div class="wr35r"><span>' + esc(c.name) + '</span><small>' + mshort(c.rev) + '</small><b class="' + sgn(c.profit) + '">' + plus(c.profit) + '</b></div>').join('') : '<span class="tipt">No company traded this week.</span>') + '</button>';
    /* what happened: problems first */
    const ev = (r.ev || []).slice(), rank = e => e.tone === 'bad' ? 0 : e.tone === 'good' ? 1 : 2;
    ev.sort((x, y) => rank(x) - rank(y));
    const nb = ev.filter(e => e.tone === 'bad').length, ng = ev.filter(e => e.tone === 'good').length;
    h += '<button class="card wbox35" data-a="wr35s" data-p="' + P({ k: 'ev' }) + '"><div class="bhead"><b>What happened</b><small>' + (ev.length ? (nb ? nb + ' problem' + (nb > 1 ? 's' : '') + ' · ' : '') + (ng ? ng + ' good · ' : '') + 'all ' + ev.length + ' ›' : '') + '</small></div>' + (ev.length ? ev.map(e => { const co = e.co ? getCo(e.co) : null; return '<div class="wr35e"><i class="' + evTone(e) + '"></i><span>' + esc(e.t) + '</span>' + (co ? '<small>' + esc(co.name) + '</small>' : '') + '</div>'; }).join('') : '<span class="tipt">A quiet week.</span>') + '</button>';
    h += '<button class="btn primary wide go repgo' + (ui.repLock ? ' wait' : '') + '" data-a="repdone"' + (ui.repLock ? ' disabled' : '') + '>Continue</button>';
    return '<div class="wr35' + (anim ? ' repanim' : '') + '">' + h + '</div>';
  };
  /* the header shows the same change as the big number below it */
  V.heads.weekreport = pipeView('V.heads.weekreport', V.heads.weekreport || (() => ({ t: 'Week report' })), 0);
  addStep('V.heads.weekreport', 10, 'the header shows the same change as the big number below it', (o) => {
    try {
      if (!S.lastRep) return o;
      const n = nums(), d = n.p && n.p.nw != null ? n.nw - n.p.nw : null;
      o.right = d == null ? '' : '<span class="pill ' + (d >= 0 ? 'grn' : 'amb') + '">' + plus(d) + '</span>';
    } catch (e) { }
    return o;
  });
  ACT.wr35s = p => {
    const r = S.lastRep;
    if (!r) return;
    let h;
    if (p.k === 'cos') {
      const b = r.bw || {}, lines = Object.keys(COSTN).filter(k => b[k]);
      h = '<h2>Companies this week</h2><div class="lrows">' + (r.cos || []).map(c => '<button class="lrow" data-a="wr35co" data-p="' + P({ id: c.id }) + '"><span class="ctext"><b>' + esc(c.name) + '</b><small>' + esc(window.fmtU ? window.fmtU(c.units || 0, c.unit) : Math.round(c.units || 0) + ' ' + unitPl(c.unit, c.units || 0)) + ' · revenue ' + mshort(c.rev) + '</small></span><b class="num ' + sgn(c.profit) + '">' + plus(c.profit) + '</b></button>').join('') + '</div>';
      if (b.rev || lines.length) h += '<h3>Money in and out</h3>' + row('Revenue', mshort(b.rev || 0)) + lines.map(k => row(COSTN[k], '−' + mshort(b[k]))).join('') + (r.meD ? row('Your private account', '<span class="' + sgn(r.meD) + '">' + plus(r.meD) + '</span>') : '');
    } else {
      const ev = (r.ev || []);
      h = '<h2>What happened</h2><div class="lrows">' + (ev.length ? ev.map(e => { const co = e.co ? getCo(e.co) : null; const tg = e.tone === 'good' ? ['Good', 'green'] : e.tone === 'bad' ? ['Problem', 'red'] : ['Info', '']; return '<div class="lrow"><span class="ctext"><b class="wrap">' + esc(e.t) + '</b>' + (co ? '<small>' + esc(co.name) + '</small>' : '') + '</span><span class="badge ' + tg[1] + '">' + tg[0] + '</span></div>'; }).join('') : '<div class="lrow"><small>A quiet week.</small></div>') + '</div>';
    }
    openSheet(h + btn('Close', 'sheetclose', undefined, 'ghost wide'), 'wr35sh');
  };
  ACT.wr35co = p => { closeSheet(); go('co', { id: p.id }); };
  /* after Continue, problems may pop up one at a time again */
  ACT.repdone = pipeView('ACT.repdone', ACT.repdone, 0);
  addStep('ACT.repdone.around', 10, 'after Continue, problems may pop up one at a time again', (next) => {
    const r = next();
    setTimeout(() => { try { if (window.R30 && R30.maybeAlert && !ui.sheet) R30.maybeAlert(); } catch (e) { } }, 300);
    return r;
  });
})();


/* ===== Round 36: fewer places, each with a reason to exist.
   Pop-ups only close with their own buttons (a small × where there is nothing else).
   A menu that unlocks later (manager reviews, meetings, boards) announces itself once: Take a look or Not now.
   Money › Results holds months, accounts, transactions and bills. Group › Market is the market map and every rival
   (features/world/market_map_and_reviews.js V.market). New company › Start a startup is your own startups.
   Elsewhere at the source: News is one page (ui/screens/mockup.js), Startups sit in Investing (ui/phone/invest.js),
   Reports and timing in Settings (ui/phone/phone.js), the big meeting in the Inbox (ui/screens/mockup.js),
   franchises and chain stores in New company (ui/screens/companies_list.js). ===== */
window.R36 = window.R36 || {};
(function () {
  'use strict';
  const R36 = window.R36;
  const U = window.UI;
  if (!U) return;
  const { ui, V, ACT, esc, row, btn, card, go, render, save, svg, openSheet, closeSheet } = U;
  const CT = window.CT;
  const P = o => esc(JSON.stringify(o));
  const live = () => S.cos.filter(c => c.st !== 'sold' && c.st !== 'bust');
  const busy = () => ui.dayBusy || ui.untl || ui.repLock;

  /* ================= pop-ups: no tapping away ================= */
  const CLOSERS = /data-a="(sheetclose|al30later|unl36no|repdone|cancelsheet|confno)"|>\s*(Close|Cancel|Not now|Do later|Continue|OK|Done|No thanks|Back|Later|Not yet|Skip)\s*</i;
  window.sheet36 = sh => {
    let h = sh.html || '';
    if (!CLOSERS.test(h)) h = '<button class="x36" data-a="sheetclose" aria-label="Close">×</button>' + h;
    return '<div class="scrim" data-a="scrim"><div class="sheet ' + (sh.cls || '') + '" role="dialog" aria-modal="true">' + h + '</div></div>';
  };

  /* ================= menus that unlock later ================= */
  const UNL = [
    {
      k: 'mgr', ok: () => R35.hasMgr && R35.hasMgr(),
      items: [['Manager reviews', 'Group › Group', 'A scorecard for every manager, and a review whenever you want one.'], ['Meetings', 'Inbox', 'Call a manager in. They bring proposals with costs and expected revenue; you decide.']],
      look: () => { ACT.tab('hq'); ACT.hqtab('grp'); go('managers'); }
    },
    {
      k: 'board', ok: () => !!(window.R12 && R12.anyBoard && R12.anyBoard()),
      items: [['Boards', 'Group › Group, and Company in each company', 'Board members advise and vote on big decisions. Emergencies come to you.']],
      look: () => { ACT.tab('hq'); ACT.hqtab('grp'); go('boards12', {}); }
    }
  ];
  function unlState() {
    if (!S.unl36) { S.unl36 = {}; UNL.forEach(u => { try { if (u.ok()) S.unl36[u.k] = 1; } catch (e) { } }); }
    return S.unl36;
  }
  function unlCheck() {
    try {
      if (typeof S === 'undefined' || !S || !S.cos || S.over || ui.sheet || busy() || (ui.view && ui.view.n === 'weekreport')) return;
      const st = unlState(), L = UNL.filter(u => !st[u.k] && (() => { try { return u.ok(); } catch (e) { return false; } })());
      if (!L.length) return;
      L.forEach(u => { st[u.k] = 1; });
      save();
      const items = [].concat.apply([], L.map(u => u.items));
      openSheet('<div class="unl36"><small>Unlocked</small><h2>' + (items.length > 1 ? 'New in your game' : 'New: ' + esc(items[0][0])) + '</h2>' + items.map(x => '<div class="unli36"><b>' + esc(x[0]) + '</b><span class="where">' + esc(x[1]) + '</span><span>' + esc(x[2]) + '</span></div>').join('') + '<div class="btnrow col">' + btn('Take a look', 'unl36go', { k: L[0].k }, 'primary wide') + btn('Not now', 'unl36no', undefined, 'ghost wide') + '</div></div>', 'unl36s');
    } catch (e) { console.error(e); }
  }
  R36.unlCheck = unlCheck;
  ACT.unl36go = p => { closeSheet(); const u = UNL.find(x => x.k === p.k); if (u) u.look(); };
  ACT.unl36no = () => closeSheet();
  setInterval(unlCheck, 1500);

  /* ================= Money › Results ================= */
  const RT = [['m', 'Months'], ['acc', 'Accounts'], ['tx', 'Transactions'], ['bills', 'Bills']];
  V.titles.res36 = 'Results';
  V.heads.res36 = p => { const co = p && getCo(p.id); return { t: 'Results', sub: co ? esc(co.name) : '' }; };
  V.res36 = function (p) {
    const co = p && getCo(p.id);
    if (!co) return card('Company not found.');
    const bd = BD[co.type];
    let t = ui.res36 || 'm';
    if (t === 'bills' && !(window.R29 && R29.on && R29.on() && V.payroll29)) t = 'm';
    ui.res36 = t;
    const tabs = RT.filter(x => x[0] !== 'bills' || (window.R29 && R29.on && R29.on())).filter(x => x[0] !== 'm' || V.month30);
    let h = '<div class="ptabs">' + tabs.map(x => '<button class="' + (t === x[0] ? 'on' : '') + '" data-a="res36t" data-p="' + P({ v: x[0] }) + '">' + x[1] + '</button>').join('') + '</div>';
    try {
      if (t === 'm') h += V.month30({ id: co.id });
      else if (t === 'acc') h += CT.finPart(co, bd, 'books');
      else if (t === 'tx') h += CT.finPart(co, bd, 'tx');
      else h += V.payroll29({ id: co.id, v: 'bills' });
    } catch (e) { console.error(e); h += card('Nothing to show yet.'); }
    return h;
  };
  ACT.res36t = p => { ui.res36 = p.v; render(true); };

  /* ================= Group › Market: the market map and every rival in one place ================= */
  V.titles.mkt36 = 'Market';
  V.heads.mkt36 = () => { const o = V.heads.market ? V.heads.market() : {}; return Object.assign({}, o, { t: 'Market' }); };
  V.mkt36 = () => V.market ? V.market() : '';

  /* ================= New company: other ways in ================= */
  V.titles.found36 = 'Your startups';
  V.found36 = () => window.foundedPage ? foundedPage() : '';
  /* ================= Phone ================= */
})();


/* ===== Round 6c: mockup restyles. Pay yourself, Accounts, My office, Reports and timing, Academy,
   pictures in the Luxury app, and dated transactions. ===== */
{
  const P = o => esc(JSON.stringify(o));
  const pillp = (t, c) => '<span class="pill ' + (c || '') + '">' + t + '</span>';
  const neg = x => '<span class="neg">−' + npadL(Math.abs(x)) + '</span>';
  const sn = x => (x < 0 ? '−' : '') + npadL(Math.abs(x));
  const pcs = x => (x >= 0 ? '+' : '−') + Math.abs(Math.round(x * 100)) + '%';
  const R6FIN = window.R6FIN = window.R6FIN || {};
  /* group contribution on the tax card: the tax group, and this year's profit set against sister companies' losses */
  const gcRows = (co, corp) => {
    const L = taxGroup(co), g = co.gc || {}, ly = co.gcLy;
    if (!L) return co.hold && co.form === 'AS' ? '<p class="muted small">Owned less than 90% by the holding company, or in another country: not in its tax group, so profits and losses here stay on their own.</p>' : '';
    const h = L[0];
    return row('Tax group', esc(h.name) + ' · ' + L.length + ' companies') + (g.out > 0 ? row('Profit covering sister companies\' losses', nok(g.out)) + row('Tax saved by it', nok(g.out * corp)) : '') + (g.in > 0 ? row('Loss covered by sister companies', nok(g.in)) : '') + (ly ? row('Last year', (ly.out ? 'covered ' + mshort(ly.out) + ' of losses' : 'loss of ' + mshort(ly.in) + ' covered')) : '') + '<p class="muted small">Group contribution: within a holding company\'s group (owned 90% or more, same country), one company\'s profit can cover another\'s loss in the same year, so the group pays tax only on what it earns together.</p>';
  };


  /* ---------- Pay yourself ---------- */
  function availOut(co) {
    return co.form === 'AS' ? divMax(co) : Math.max(0, Math.floor(co.cash - coWeekCost(co) * 2));
  }
  V.titles.payself = 'Pay yourself';
  V.heads = V.heads || {};
  V.heads.payself = p => {
    const co = getCo(p.id);
    return { t: 'Pay yourself', sub: co ? esc(co.name) + ' · available ' + mshort(availOut(co)) : '' };
  };
  document.addEventListener('change', e => {
    const k = e.target && e.target.getAttribute && e.target.getAttribute('data-k');
    if ((k === 'amtOut' || k === 'amtIn') && ui.view && ui.view.n === 'payself') render();
  });
  /* the first row of a company's Money tab (ui/company/view.js) */
  R6FIN.payselfRow = co => {
    const avail = availOut(co);
    return '<button class="lrow" data-a="go" data-p="' + P({ n: 'payself', p: { id: co.id } }) + '"><span class="lic">' + svg('coin', 20) + '</span><span class="ctext"><b>Pay yourself</b><small>' + (co.form === 'AS' ? 'Salary ' + mshort(co.ownerSalary || 0) + '/mo · dividend up to ' + mshort(avail) : 'Take out up to ' + mshort(avail)) + ' · put money in</small></span><i>›</i></button>';
  };
  R6FIN.owner = co => '<div class="lrows">' + R6FIN.payselfRow(co) + '</div>';

  /* ---------- Accounts ---------- */
  const PL = [['cogs', 'Materials and goods'], ['wages', 'Wages and charges'], ['rent', 'Rent and premises'], ['mkt', 'Marketing'], ['ins', 'Insurance'], ['acc', 'Accounting'], ['dep', 'Depreciation of equipment'], ['int', 'Interest'], ['oth', 'Other costs'], ['fine', 'Fines'], ['loss', 'Losses and write-offs']];
  function compare(co) {
    const y = co.bk.y || {}, ly = co.bk.ly || {};
    if ((ly.rev || 0) > 0) {
      let w0 = S.week;
      while (w0 > 0 && wYear(w0 - 1) === wYear(S.week)) w0--;
      const f = Math.max(1, S.week - w0 + 1) / 52;
      return { lab: 'Compared with last year', r: (y.rev || 0) / (ly.rev * f) - 1, c: sumExp(y) / Math.max(1, sumExp(ly) * f) - 1 };
    }
    const hst = co.hist || [];
    if (hst.length >= 8) {
      const n = Math.min(13, Math.floor(hst.length / 2)), a = hst.slice(-n), b = hst.slice(-2 * n, -n);
      const ra = a.reduce((t, x) => t + (x.rev || 0), 0), rb = b.reduce((t, x) => t + (x.rev || 0), 0);
      const ca = a.reduce((t, x) => t + (x.rev || 0) - (x.profit || 0), 0), cb = b.reduce((t, x) => t + (x.rev || 0) - (x.profit || 0), 0);
      return { lab: 'Compared with the ' + n + ' weeks before', r: rb > 0 ? ra / rb - 1 : 0, c: cb > 0 ? ca / cb - 1 : 0 };
    }
    return null;
  }
  function accSays(co) {
    const out = [];
    const cm = compare(co), y = co.bk.y || {}, ly = co.bk.ly || {};
    if (cm && cm.c > cm.r + 0.05) out.push('Costs grew faster than sales (' + pcs(cm.c) + ' against ' + pcs(cm.r) + ').');
    if ((y.wages || 0) > (y.rev || 0) * 0.6 && (y.rev || 0) > 0) out.push('Wages take ' + Math.round(y.wages / y.rev * 100) + '% of revenue, which is high.');
    let worn = 0;
    for (const id in co.eq) ((co.units || {})[id] || []).forEach(u => { if (window.R6 && R6.seen(u) < 0.5) worn++; });
    co.veh.forEach(v => { if (window.R6 && R6.seen(v) < 0.5) worn++; });
    if (worn) out.push('Equipment is aging: ' + worn + (worn > 1 ? ' items look' : ' item looks') + ' worn and will need replacing within 18 months.');
    const recv = co.recv.reduce((t, r) => t + r.a, 0);
    if (recv > (y.rev || 0) / Math.max(1, (S.week % 52) || 1) * 8 && recv > KC(20000, co.country)) out.push('Customers owe you ' + mshort(recv) + '. Chase the slow payers.');
    if (co.cash < coWeekCost(co) * 4) out.push('Cash is thin, under a month of costs.');
    if (co.form === 'AS' && !co.acc) out.push('A limited company must have its accounts prepared. Pick an accountant under Accountant and legal form.');
    if (!out.length) out.push('The books look healthy. Nothing unusual this period.');
    return out.join(' ');
  }
  function dueWeeks(co) {
    let w = S.week + 1;
    while (w < S.week + 60 && !(wMonth(w) === 6 && wDate(w).getUTCDate() >= 24)) w++;
    return w - S.week;
  }
  R6FIN.books = (co, bd) => {
    const t = ui.acct || 'pl', b = ui.books || 'y', bk = co.bk[b] || {};
    const AS = co.form === 'AS', corp = (CO[co.country] || CC()).corp;
    const st = co.acc || !AS ? ['Up to date', 'grn'] : ['No accountant', 'red'];
    let h = '<div class="card"><div class="cchd"><span class="lic">' + svg('book', 20) + '</span><span class="ctext"><b>Accounts</b><small>Prepared by ' + esc(co.acc ? co.acc.name : AS ? 'nobody yet' : 'you, with bookkeeping software') + '</small></span>' + pillp(st[0], st[1]) + '</div></div>';
    h += '<div class="ptabs">' + [['pl', 'P&amp;L'], ['bal', 'Balance'], ['cf', 'Cash flow'], ['tax', 'Tax']].map(x => '<button class="' + (t === x[0] ? 'on' : '') + '" data-a="acct" data-p="' + P(x[0]) + '">' + x[1] + '</button>').join('') + '</div>';
    const per = { w: 'This week', m: 'This month', y: 'This year so far', ly: 'Last year' };
    const perChips = chips([['w', 'Week'], ['m', 'Month'], ['y', 'Year'], ['ly', 'Last year']], b, 'books', { id: co.id });
    if (t === 'pl') {
      const rev = bk.rev || 0, prof = rev - sumExp(bk);
      h += perChips + '<h2 class="sec">Profit and loss · ' + per[b].toLowerCase() + '</h2><div class="card">' + row('Revenue', '<b>' + npadL(rev) + '</b>') + PL.filter(l => bk[l[0]]).map(l => row(l[1], neg(bk[l[0]]))).join('') + row('Profit before tax', '<span class="' + sgn(prof) + '">' + sn(prof) + '</span>', 'total') + (AS ? row('Corporate tax, ' + pc(corp, 0), bk.tax ? neg(bk.tax) : '–') + row('Profit after tax', '<span class="' + sgn(prof - (bk.tax || 0)) + '">' + sn(prof - (bk.tax || 0)) + '</span>', 'total') : '') + '</div>';
      const cm = compare(co);
      const y = co.bk.y || {};
      if (cm) h += '<h2 class="sec">' + cm.lab + '</h2><div class="tri"><div><span>Revenue</span><b class="' + (cm.r >= 0 ? 'pos' : 'neg') + '">' + pcs(cm.r) + '</b></div><div><span>Costs</span><b class="' + (cm.c > cm.r ? 'amb' : '') + '">' + pcs(cm.c) + '</b></div><div><span>Margin</span><b>' + ((y.rev || 0) > 0 ? Math.round(((y.rev || 0) - sumExp(y)) / y.rev * 100) + '%' : '–') + '</b></div></div>';
      h += '<div class="card sense"><b>' + (co.acc ? 'Your accountant says' : 'What the numbers say') + '</b><span class="tipt">' + esc(accSays(co)) + '</span></div>';
      const dw = dueWeeks(co);
      h += '<div class="card"><div class="bhead"><b>' + (AS ? 'Annual accounts' : 'Tax return') + '</b>' + pillp('Due in ' + dw + ' weeks', dw <= 8 ? 'amb' : '') + '</div><span class="tipt">Late filing triggers a fine. A better accountant also finds tax savings.</span></div>';
    } else if (t === 'bal') {
      const recv = co.recv.reduce((x, r) => x + r.a, 0), eq = companyAssets(co) - companyDebts(co);
      h += '<div class="card">' + row('Cash', nok(co.cash)) + row('Customers owe', nok(recv)) + row('Stock', nok(co.inv)) + row('Equipment and vehicles', nok(eqBook(co))) + (co.prem && co.prem.owned ? row('Property', nok(co.prem.val)) : '') + (co.props && co.props.length ? row('Rental properties', nok(co.props.reduce((x, p) => x + p.val, 0))) : '') + (co.fm && co.fm.assets ? row('Other assets', nok(co.fm.assets)) : '') + row('Debts and accruals', '<span class="neg">' + nok(companyDebts(co)) + '</span>') + row('Equity', '<span class="' + sgn(eq) + '">' + nok(eq) + '</span>', 'total') + '</div>';
      h += CT.invSale ? CT.invSale(co) : '';
      if (BD[co.type].b2b > 0) h += '<div class="card"><div class="bhead"><b>Credit checks on customers</b>' + pillp(co.flags.ccheck ? 'On' : 'Off', co.flags.ccheck ? 'grn' : '') + '</div><span class="tipt">Costs about 0.4% of invoices and cuts unpaid invoices a lot.</span><div class="chips">' + btn(co.flags.ccheck ? 'Stop credit checks' : 'Check customers before invoicing', 'ccheck', { id: co.id }, 'chip') + '</div></div>';
    } else if (t === 'cf') {
      const rev = bk.rev || 0, cost = sumExp(bk) - (bk.dep || 0);
      const recv = co.recv.reduce((x, r) => x + r.a, 0), pay = co.pay.wages + co.pay.other + co.pay.rent + co.pay.tax;
      h += perChips + '<h2 class="sec">Cash flow · ' + per[b].toLowerCase() + '</h2><div class="card">' + row('Sales', npadL(rev)) + row('Costs paid (not depreciation)', neg(cost)) + row('Net from running the business', '<span class="' + sgn(rev - cost) + '">' + sn(rev - cost) + '</span>', 'total') + '</div><div class="tri"><div><span>Owed to you</span><b>' + mshort(recv) + '</b></div><div><span>Bills to pay</span><b>' + mshort(pay + Math.max(0, co.vatAcc)) + '</b></div><div><span>Cash now</span><b class="' + sgn(co.cash) + '">' + mshort(co.cash) + '</b></div></div>';
    } else {
      h += '<div class="card">' + (AS ? row('Corporate tax rate', pc(corp, 0)) + row('Tax to pay (accrued)', nok(co.pay.tax)) + (co.lossCarry > 0 ? row('Tax loss carried forward', nok(co.lossCarry)) : '') + gcRows(co, corp) : row('Taxed as', 'Your personal income')) + row('VAT to settle', nok(co.vatAcc)) + row('Payroll taxes', 'Included in wages') + '</div>' + btn('Open the Tax Office', 'phapp', { n: 'tax' }, 'wide');
    }
    return h;
  };
  ACT.acct = p => { ui.acct = p; render(); };
  R6FIN.tx = co => '<div class="lrows">' + (co.tx.length ? co.tx.slice(0, 20).map(t => '<div class="lrow"><span class="ctext"><b>' + esc(t.l) + '</b><small>' + dateStr(t.w) + '</small></span><b class="num ' + sgn(t.a) + '">' + (t.a > 0 ? '+' : '−') + npadL(Math.abs(t.a)) + '</b></div>').join('') : '<div class="lrow"><small>Nothing yet.</small></div>') + '</div>';

  /* ---------- Reports and timing ---------- */
  const pdd = (items, cur, act, p0, cls) => {
    const c = items.find(it => it[0] === cur) || items[0];
    return '<button class="pill ' + (cls || 'blue') + '" data-a="ddopen" data-p="' + P({ items, cur, act, p0 }) + '">' + c[1] + ' ▾</button>';
  };
  V.titles.reports = 'Reports and timing';
  V.heads.reports = () => ({ t: 'Reports and timing', sub: 'What reaches you, and when' });
  V.reports = function () {
    const rs = repSettings();
    const cos = S.cos.filter(c => c.st !== 'sold' && c.st !== 'bust');
    let h = '<div class="card sense"><span class="tipt">More reports mean you see problems sooner but spend more time reading them. Fewer reports are quieter, but you may notice trouble late.</span></div>';
    h += '<h2 class="sec">Reports</h2><div class="lrows">' +
      '<div class="lrow"><span class="ctext"><b>Week report</b><small>Cash and results, all companies</small></span>' + pillp('Weekly', 'blue') + '</div>' +
      '<div class="lrow"><span class="ctext"><b>Board pack</b><small>Profit and loss from companies with a manager</small></span>' + pdd([[4, 'Monthly'], [13, 'Quarterly'], [52, 'Yearly']], rs.freq, 'repset', { k: 'freq' }) + '</div>' +
      '<div class="lrow"><span class="ctext"><b>How much detail</b><small>Short summary or the full pack</small></span>' + pdd([['short', 'Short'], ['full', 'Full']], rs.detail, 'repset', { k: 'detail' }) + '</div>' +
      '<div class="lrow"><span class="ctext"><b>Which companies</b><small>Who sends a board pack</small></span>' + pdd([['all', 'All'], ['managed', 'Managed only'], ['big', 'Big ones only']], rs.only, 'repset', { k: 'only' }) + '</div>' +
      '<div class="lrow"><span class="ctext"><b>Risk and legal</b><small>Lawsuits, audits, licences</small></span>' + pillp('When it happens', 'amb') + '</div>' +
      (hasHQ('fin') ? '<div class="lrow"><span class="ctext"><b>Investments</b><small>From your finance manager</small></span>' + pillp('Monthly', 'blue') + '</div>' : '') +
      (hasHQ('ana') ? '<div class="lrow"><span class="ctext"><b>Analyst report</b><small>Forecasts on request</small></span>' + pillp('When asked') + '</div>' : '') + '</div>';
    h += '<h2 class="sec">How it reaches you</h2><div class="card">' + row('Board packs', 'In Meetings · Messages') + row('Urgent alerts', hasHQ('pa') ? 'Always, through your assistant' : 'Straight to Meetings') + row('Decisions', hasHQ('pa') ? 'Your assistant gives one extra week' : 'Due by the deadline') + '<span class="tipt">' + (hasHQ('pa') ? 'Your assistant filters small things so you see what matters.' : 'A personal assistant at your main office can filter small things and buy you time on decisions.') + '</span></div>';
    h += '<h2 class="sec">Who prepares them</h2><div class="lrows">' + (cos.length ? cos.map(co => '<div class="lrow"><span class="ctext"><b>' + esc(co.name) + '</b><small>' + (co.mgr && S.npcs[co.mgr] ? 'Manager: ' + esc(S.npcs[co.mgr].name) : 'You') + '</small></span><b>' + esc(co.acc ? co.acc.name : co.form === 'AS' ? 'No accountant' : 'Bookkeeping app') + '</b></div>').join('') : '<div class="lrow"><small>No companies yet.</small></div>') + '</div>';
    return h;
  };

  /* ---------- Academy ---------- */
  V.titles.academy = 'Academy';
  V.heads.academy = () => ({ t: 'Academy', sub: 'Courses for the people in your companies' });
  const tenure = s => { const w = S.week - (s.w0 || S.week); return w >= 52 ? Math.floor(w / 52) + ' yr' : Math.max(1, Math.round(w / 4.3)) + ' mo'; };
  function fitTag(s, n) {
    const sk = staffSkill(s);
    if (sk >= 80) return ['Little to gain', 'red'];
    if (s.flag === 'lazy' || s.flag === 'conflict' || s.flag === 'late') return ['Might ignore it', 'amb'];
    if (sk < 60 || (n && n.age < 26)) return ['Good fit', 'grn'];
    return ['Some gain', ''];
  }
  V.academy = function () {
    const cos = S.cos.filter(c => c.st !== 'sold' && c.st !== 'bust' && BD[c.type] && BD[c.type].crs && BD[c.type].crs.length);
    if (!cos.length) return '<div class="calm">Courses open up when you run a company.</div>';
    const A = ui.acad = ui.acad || {};
    let co = cos.find(c => c.id === A.co) || cos[0];
    A.co = co.id;
    const bd = BD[co.type];
    let h = cos.length > 1 ? (cos.length > 3 ? U.ddown(cos.map(c => [c.id, esc(c.name)]), co.id, 'acadco') : '<div class="ptabs">' + cos.map(c => '<button class="' + (c.id === co.id ? 'on' : '') + '" data-a="acadco" data-p="' + P({ v: c.id }) + '">' + esc(c.name) + '</button>').join('') + '</div>') : '';
    h += '<p class="muted small">Each business has its own courses. A good one lifts a worker\'s skill. A bad fit can do nothing and the money is gone.</p>';
    const c = bd.crs.find(x => x[0] === A.c) || bd.crs[0];
    A.c = c[0];
    h += bd.crs.map(x => '<button class="card opt2' + (x[0] === c[0] ? ' on' : '') + '" data-a="acadc" data-p="' + P({ v: x[0] }) + '"><div class="cchd"><span class="lic">' + svg('grad', 20) + '</span><span class="ctext"><b>' + esc(x[1]) + '</b><small>' + x[3] + (x[3] > 1 ? ' days' : ' day') + ' · ' + money(x[2]) + ' per person</small></span></div><div class="kv"><span>Typical gain</span><b class="pos">+ up to ' + x[4] + ' skill</b></div><div class="kv"><span>Chance it sticks</span><b class="amb">About 65%</b></div></button>').join('');
    const people = co.staff.map(s => ({ id: s.id, s, n: S.npcs[s.id] })).filter(x => x.n);
    const ow = !co.mgr;
    h += '<h2 class="sec">Send who?</h2><div class="lrows">' + (ow ? '<button class="lrow" data-a="acads" data-p="' + P({ v: 'owner' }) + '"><span class="av">' + esc((S.player.name || 'You').split(' ').map(w => w[0]).join('').slice(0, 2)) + '</span><span class="ctext"><b>You</b><small>Owner · skill ' + Math.round(co.oskill) + '</small></span>' + pillp(co.oskill >= 80 ? 'Little to gain' : 'Good fit', co.oskill >= 80 ? 'red' : 'grn') + '<span class="radio' + (A.s === 'owner' ? ' on' : '') + '"></span></button>' : '') +
      people.map(x => { const tg = fitTag(x.s, x.n); return '<button class="lrow" data-a="acads" data-p="' + P({ v: x.id }) + '">' + faceAv(x.n) + '<span class="ctext"><b>' + esc(x.n.name) + '</b><small>' + tenure(x.s) + ' · ' + esc(ROLES[x.s.role] ? ROLES[x.s.role][0] : '') + '</small></span>' + pillp(tg[0], tg[1]) + '<span class="radio' + (String(A.s) === String(x.id) ? ' on' : '') + '"></span></button>'; }).join('') + (!ow && !people.length ? '<div class="lrow"><small>No staff yet.</small></div>' : '') + '</div>';
    const who = A.s === 'owner' ? { name: 'yourself' } : people.find(x => String(x.id) === String(A.s));
    h += '<div class="card sense"><div class="bhead"><span>Total</span><b>' + money(c[2]) + '</b></div><span class="tipt">' + (who ? (A.s === 'owner' ? 'You are' : esc(who.n.name.split(' ')[0]) + ' is') + ' away for ' + c[3] + (c[3] > 1 ? ' days' : ' day') + ', so about ' + Math.round(c[3] * 7.5) + ' working hours are lost.' : 'Pick who to send.') + '</span></div>';
    if (who) h += btn('Send ' + (A.s === 'owner' ? 'yourself' : esc(who.n.name.split(' ')[0])) + ' · ' + mshort(c[2]), 'docourse', { id: co.id, s: A.s === 'owner' ? 'owner' : who.id, c: c[0] }, 'primary wide go');
    return h;
  };
  ACT.acadco = p => { ui.acad = { co: p.v }; render(); };
  ACT.acadc = p => { ui.acad.c = p.v; render(); };
  ACT.acads = p => { ui.acad.s = p.v; render(); };
}


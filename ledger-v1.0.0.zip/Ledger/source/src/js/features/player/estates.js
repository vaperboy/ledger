/* ===== Round 56: estates. Land and houses that earn money, cost upkeep and give perks. They are bought in the Aurum
   shop (collection "Estates", ui/screens/mockup.js LUX) like any piece, with the same value moves, upkeep and
   selling costs; this file adds what they earn and what they do. Income is capital income in your yearly tax.
   e4 Forest and lake  timber cut each winter (about 2.5% of the value) and a little from carbon credits; very steady
   e3 Highland estate  shooting and fishing lets in late summer and autumn, two tenant farms; steady (about 2%)
   e1 Vineyard         the year's wine depends on the vintage, set at harvest (weather); your restaurants, cafés,
                       hotels and bars pour your own wine: a little more demand there
   e5 Castle           open for weddings and dinners (about 4%, mostly May to September and before Christmas) or keep
                       it private; open, it makes you better known
   e2 Private island   let to guests in season (about 2%); once a quarter you can host a retreat for the people you
                       know, or take a week off there and come back rested
   Banks lend on estates (half their value). Estates are part of Ledger Pro (PRO 'estates'). ===== */
window.EST = window.EST || {};
(function () {
  const EST = window.EST;
  const LXI = () => (window.LUX47 || {}).LUXI || {};
  const mine = () => ((S && S.lux) || []).filter(x => !x.co && LXI()[x.k] && LXI()[x.k].cat === 'estates');
  const ofK = k => mine().filter(x => x.k === k);
  const SOUTH = { AU: 1, BR: 1 };
  const mon = () => { const m = monthIdx(S.week) % 12; return SOUTH[S.country] ? (m + 6) % 12 : m; }; /* the month as in the north */
  /* yearly yield on the value, and how it falls over the year (12 weights, January first) */
  const Y = {
    e4: { y: 0.028, w: [6, 4, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1], what: 'Timber and carbon credits' },
    e3: { y: 0.02, w: [1, 1, 1, 1, 1, 1, 1, 3, 3, 3, 2, 1], what: 'Shooting, fishing and farm rents' },
    e1: { y: 0.035, w: [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1], what: 'Wine sales' },
    e5: { y: 0.04, w: [0.3, 0.3, 0.5, 0.8, 1.6, 2, 2, 1.8, 1.4, 0.6, 0.8, 1.6], what: 'Weddings and dinners' },
    e2: { y: 0.02, w: [0, 0, 0, 0.6, 1.6, 2.4, 3, 3, 1.4, 0, 0, 0], what: 'Guests in season' }
  };
  const wk = (k, m) => { const w = Y[k].w; const t = w.reduce((a, b) => a + b, 0); return w[m] * 12 / t; };
  function weekIncome(x) {
    const d = Y[x.k];
    if (!d) return 0;
    if (x.k === 'e5' && x.mode === 'private') return 0;
    const v = x.k === 'e1' ? (x.vint == null ? 1 : x.vint) : 1;
    return Math.round(x.val * d.y * v * wk(x.k, mon()) / 52);
  }
  EST.weekIncome = weekIncome;
  /* the vintage: set at harvest, each autumn; good years and bad */
  const VINT = q => q >= 1.25 ? 'an exceptional vintage' : q >= 1.05 ? 'a good vintage' : q >= 0.85 ? 'an ordinary year' : q >= 0.6 ? 'a poor year: rain at harvest' : 'a disaster: hail in August';
  addStep('week.after', 14, 'estates: income, the vintage, perks', () => {
    if (!S || S.over) return;
    const L = mine();
    if (!L.length) return;
    let inc = 0;
    L.forEach(x => {
      if (x.k === 'e1' && mon() === 9 && x.vy !== wYear(S.week)) {
        x.vy = wYear(S.week);
        x.vint = Math.round(clamp(1 + gauss() * 0.28, 0.3, 1.5) * 100) / 100;
        info('Your vineyard', 'Harvest: ' + VINT(x.vint), 'This year’s wine will sell for about ' + Math.round(x.vint * 100) + '% of a normal year.', 0, x.vint >= 0.85 ? 'good' : 'bad');
      }
      inc += weekIncome(x);
    });
    if (inc > 0) { gainMe(inc, 'Estates'); S.tax.int = (S.tax.int || 0) + inc; }
    if (S.offW56 && S.week === S.offW56) S.fat = 0; /* back from a week on the island */
  });
  /* your own wine in your restaurants, cafés, hotels and bars */
  const POUR = { restaurant: 1, cafe: 1, hotel: 1, nightclub: 1, casino: 1 };
  addStep('demand', 75, 'your own wine on the menu', (co, bd, r) => {
    if (POUR[co.type] && co.country === S.country && r && r.D > 0 && ofK('e1').length) { r.D *= 1.015; if (r.parts) r.parts.wine56 = 1.015; }
  }, true);
  /* an open castle makes you better known */
  addStep('fame', 20, 'a castle open for events', f => f + (ofK('e5').some(x => x.mode !== 'private') ? 2 : 0));
  /* banks lend on estates */
  addStep('collateral', 20, 'estates', v => v + mine().reduce((t, x) => t + x.val * 0.5, 0));
  /* Ledger Pro: estates */
  ACT.lxbuy = pipeView('ACT.lxbuy', ACT.lxbuy, 1);
  addStep('ACT.lxbuy.around', 10, 'Pro: estates', (p, next) => { const i = p && LXI()[p.k]; if (i && i.cat === 'estates' && !PRO.ask('estates', () => ACT.lxbuy(p))) return; return next(); });

  /* ---------- the island: a retreat, or a week off ---------- */
  function retreat() {
    if (!ofK('e2').length) return 'none';
    if (S.ret56 && S.week - S.ret56 < 13) return 'wait';
    const cost = KC(120000);
    if (S.cash < cost) return 'cash';
    payMe(cost, 'Retreat on the island');
    S.ret56 = S.week;
    const R = window.R31 && R31.roster ? R31.roster().filter(c => c.role !== 'Executives') : [];
    const g = R.sort((a, b) => (b.rel || 0) - (a.rel || 0)).slice(0, 4);
    g.forEach(c => { try { R31.bumpRel(c, 8); } catch (e) { } });
    S.cos.filter(c => c.mgr && c.st === 'open').forEach(c => { c.mood = Math.min(100, (c.mood || 60) + 3); });
    info('The island', 'A retreat on the island', (g.length ? g.map(c => c.name.split(' ')[0]).join(', ') + ' and your managers came. ' : 'Your managers came. ') + 'Three days of talk, sailing and long dinners. People remember who invites them to a place like this.', 0, 'good');
    return 'ok';
  }
  function weekOff() {
    if (!ofK('e2').length) return 'none';
    if (S.offW56 && S.week < S.offW56) return 'wait';
    S.offW56 = S.week + 1;
    S.sickW = S.week + 1; /* you are not working next week (engine/people/owner_hours.js) */
    info('The island', 'A week off', 'You are away next week. Companies you run yourself manage without you; you come back rested.', 0, 'good');
    return 'ok';
  }
  EST.retreat = retreat;
  EST.weekOff = weekOff;

  /* ---------- Aurum: what an estate does, on its page and when you manage it ---------- */
  addStep('V.lux', 20, 'estates: what they earn and do', (p, h) => {
    const i = p && p.k && LXI()[p.k];
    if (!i || i.cat !== 'estates') return h;
    const d = Y[i.id];
    const extra = { e1: 'Your restaurants, cafés, hotels and bars pour your own wine.', e5: 'Open for events it makes you better known.', e2: 'Host a retreat once a quarter, or take a week off there.', e3: 'Steady income from the land and the river.', e4: 'Grows with the trees: the steadiest estate there is.' }[i.id];
    const spec = '<div class="lxspec"><div><span>' + esc(d.what) + '</span><b>about ' + mshort(i.price * d.y / 12) + ' a month</b></div><div><span>What it does</span><b>' + esc(extra) + '</b></div></div>';
    const at = h.indexOf('<div class="lxspec">');
    return at > 0 ? h.slice(0, at) + spec + h.slice(at) : h;
  });
  addStep('ACT.lx56.around', 10, 'estates: manage', (p, next) => {
    const x = mine().find(y => y.id === p.id);
    if (!x) return next();
    const i = LXI()[x.k], d = Y[x.k];
    let h = '<h2>' + esc(i.n) + '</h2>' + row('Worth today', money(x.val)) + row('Bought', dateStr(x.w) + ' for ' + mshort(x.price)) + row('Upkeep', money(i.up * x.price / 12) + ' a month') + row(d.what, 'about ' + money(Math.round(x.val * d.y / 12)) + ' a month on average') + row('The bank lends on it', money(x.val * 0.5));
    if (x.k === 'e1') h += row('This year', x.vint == null ? 'A normal year until the harvest' : VINT(x.vint));
    if (x.k === 'e5') h += '<h3 class="gap">Use</h3>' + chips([['open', 'Open for events'], ['private', 'Keep it private']], x.mode || 'open', 'est56mode', { id: x.id });
    h += '<div class="btnrow col">' + (x.k === 'e2' ? btn('Host a retreat', 'est56ret', {}, 'wide') + btn('Take a week off there', 'est56off', {}, 'wide') : '') + (window.PK58 ? PK58.manageBtns(x) : '') + btn('Sell', 'luxsell', { id: x.id }, 'wide ghost danger') + btn('Close', 'sheetclose', undefined, 'wide ghost') + '</div>';
    openSheet(h);
  });
  ACT.lx56 = pipeView('ACT.lx56', ACT.lx56, 1);
  ACT.est56mode = p => { const x = mine().find(y => y.id === p.id); if (!x) return; x.mode = p.v; save(); ACT.lx56({ id: x.id }); };
  ACT.est56ret = () => { const r = retreat(); closeSheet(); if (r === 'ok') { save(); render(); } else toast(r === 'wait' ? 'Your last retreat was less than three months ago.' : r === 'cash' ? 'Not enough cash for the retreat.' : 'You need the island.', true); };
  ACT.est56off = () => { const r = weekOff(); closeSheet(); if (r === 'ok') { save(); render(); } else toast('You are already taking next week off.', true); };
})();

/* ===== V.1.0.0: a reason to come back each day. Every real day (the phone's own date) brings one small goal that
   fits where you are: play two weeks, meet your managers, hire someone, answer the complaints, grow your net worth,
   or open your first business. Reach it and claim a small reward in cash. Days in a row make a streak (it counts up
   to seven and stays there) and the reward grows with it; a missed day starts it again. It lives in the save (S.dy59)
   and shows as a line in the Next card on Home (features/player/next_step.js). ===== */
window.DY59 = window.DY59 || {};
(function () {
  const D = window.DY59, U = window.UI, { ui, ACT, esc, btn, toast, save, render } = U;
  const ymd = t => { const d = new Date(t); return d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate(); };
  const today = () => ymd(Date.now()), yesterday = () => ymd(Date.now() - 864e5);
  const live = () => S.cos.filter(c => c.st === 'open' && c.type !== 'hold');
  const staff = () => sum(live(), c => (c.staff || []).length + (c.mgr ? 1 : 0));
  const cmp = () => sum(live(), c => (c.compl || []).filter(x => x.st === 'open').length);
  const meetMax = () => Math.max.apply(null, [-1].concat(S.cos.map(c => c.meetW != null ? c.meetW : -1)));
  /* [id, the goal, how far (b: the game at the start of the day), done?, fits now?, a button to get there] */
  const G = [
    ['start', 'Open your first business', b => live().length ? 'Open' : 'Not yet', b => live().length > 0, () => !live().length, ['go', { n: 'newbiz' }]],
    ['weeks', 'Play two weeks', b => Math.min(2, S.week - b.week) + ' of 2 weeks', b => S.week - b.week >= 2, () => live().length > 0, null],
    ['meet', 'Meet your managers', b => meetMax() > b.mt ? 'Done' : 'Not yet', b => meetMax() > b.mt, () => live().some(c => c.mgr), ['oa59meet', {}]],
    ['hire', 'Hire someone', b => staff() > b.staff ? 'Done' : 'Not yet', b => staff() > b.staff, () => live().some(c => !c.mgr), null],
    ['cmp', 'Answer the complaints waiting', b => cmp() + ' still open', b => cmp() < b.cmp, () => cmp() > 0, null],
    ['grow', 'Grow your net worth by 1%', b => (netWorth().total >= b.nw ? '+' : '−') + mshort(Math.abs(netWorth().total - b.nw)) + ' of ' + mshort(b.nw * 0.01) + ' so far', b => netWorth().total >= b.nw * 1.01 && b.nw > 0, () => live().length > 0, null]
  ];
  const st = () => {
    if (!S || S.over) return null;
    const d = S.dy59 = S.dy59 || { streak: 0, last: '' };
    if (d.d !== today()) {
      const fit = G.filter(g => { try { return g[4](); } catch (e) { return false; } });
      const h = today().split('-').reduce((a, x) => a * 31 + +x, 7);
      d.d = today(); d.got = 0;
      d.k = fit.length ? fit[h % fit.length][0] : 'weeks';
      d.b = { week: S.week, mt: meetMax(), staff: staff(), cmp: cmp(), nw: netWorth().total };
    }
    return d;
  };
  const goal = d => G.find(g => g[0] === d.k) || G[1];
  const done = d => { try { return goal(d)[3](d.b); } catch (e) { return false; } };
  const streakNow = d => d.last === yesterday() || d.last === today() ? d.streak : 0;
  const reward = d => rnl(Math.max(KC(2500), netWorth().total * 0.0005) * Math.min(7, streakNow(d) + 1), 500);
  /* the line in the Next card */
  D.row = function () {
    const d = st();
    if (!d || d.got) return '';
    const g = goal(d), ok = done(d), s = streakNow(d);
    return '<div class="fs58n dy59"><span class="ctext"><b>' + (ok ? '✓ ' : '') + 'Today: ' + esc(g[1]) + '</b><small>' + esc(ok ? 'Done · claim ' + mshort(reward(d)) : g[2](d.b)) + (s ? ' · ' + (s + 1) + ' days in a row' : '') + '</small></span>' +
      (ok ? btn('Claim', 'dy59claim', undefined, 'chip primary') : g[5] ? btn('Go', 'nx59do', { a: g[5][0], p: g[5][1] }, 'chip') : '') + '</div>';
  };
  ACT.dy59claim = () => {
    const d = st();
    if (!d || d.got || !done(d)) return;
    const r = reward(d);
    d.streak = streakNow(d) + 1; d.last = today(); d.got = 1;
    moveCash(ME, r, 'Daily goal reached');
    save(); render();
    toast('Daily goal: ' + mshort(r) + (d.streak > 1 ? ' · ' + d.streak + ' days in a row' : '') + '. A new goal comes tomorrow.');
  };
  D.state = st;
})();

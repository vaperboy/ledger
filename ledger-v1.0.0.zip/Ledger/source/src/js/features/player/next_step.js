/* ===== V.1.0.0: what to do next. One line on Home names the most useful next step and does it in one tap, or
   opens exactly the place where it is decided (premises, equipment). "1 of 4 ›" shows the whole list.
   Sources, most urgent first:
     a company being set up by you: the accountant, the documents (all at once), premises, required equipment,
       cash for the opening stock (ui/company/assets.js ACT.cldo and ACT.docsall do the work)
     an open company you run yourself: in the red (put money in), complaints waiting, a licence that lapsed
   Companies a manager runs are left to the manager, except the meeting they are due (features/people/owner_attention.js). With nothing to do the line is not shown; a new game without a
   company has First steps instead (features/player/first_steps.js). ===== */
window.NEXT59 = window.NEXT59 || {};
(function () {
  const N = window.NEXT59, U = window.UI, { ui, V, ACT, esc, btn, openSheet } = U;
  const P = o => esc(JSON.stringify(o));
  const live = () => S.cos.filter(c => c.st !== 'sold' && c.st !== 'bust' && c.type !== 'hold');
  /* money to put in: what it lacks plus two weeks of costs, as a round amount */
  const topUp = co => {
    const need = Math.max(0, -co.cash) + coWeekCost(co) * 2, mag = Math.pow(10, Math.floor(Math.log10(Math.max(1, need))));
    return ([1, 1.5, 2, 2.5, 3, 4, 5, 6, 8, 10].find(x => x * mag >= need) || 10) * mag;
  };
  function list() {
    const L = [];
    if (!S || S.over) return L;
    /* managers you have not met for two months start to slip (features/people/owner_attention.js) */
    const due = window.OA59 ? OA59.due() : [];
    if (due.length) L.push({ t: due.length === 1 ? 'Meet the manager of ' + due[0].name : 'Meet your managers · ' + due.length + ' companies', sub: 'Not met for ' + Math.round(Math.max.apply(null, due.map(c => OA59.since(c))) / 4.3) + ' months: things start to slip', l: 'Meet', a: 'oa59meet', p: due.length === 1 ? { id: due[0].id } : {} });
    live().forEach(co => {
      if (co.mgr) return;
      if (co.st === 'setup') {
        const miss = openChecklist(co).filter(x => !x.ok);
        const docs = miss.filter(x => x.k.indexOf('doc:') === 0 && !(co.docs[x.k.slice(4)] && co.docs[x.k.slice(4)].st === 'applied'));
        if (docs.some(x => x.k === 'doc:acctr') && !co.acc) L.push({ t: 'Pick an accountant for ' + co.name, sub: 'A limited company needs one.', l: 'Pick', a: 'cldo', p: { id: co.id, k: 'doc:acctr' } });
        const d2 = docs.filter(x => x.k !== 'doc:acctr' || co.acc), cost = sum(d2, x => docCost(co, x.k.slice(4)));
        if (d2.length) L.push({ t: 'Apply for ' + (d2.length === 1 ? d2[0].t : d2.length + ' documents') + ' · ' + co.name, sub: cost ? 'Costs ' + mshort(cost) + ' from the company' : 'Free', l: 'Apply', a: 'docsall', p: { id: co.id } });
        miss.filter(x => x.k === 'prem' || x.k.indexOf('eq:') === 0 || x.k === 'stockcash').slice(0, 2).forEach(x => L.push({
          t: (x.k === 'prem' ? 'Choose premises' : x.k === 'stockcash' ? 'Put in cash for the opening stock' : 'Buy: ' + x.t) + ' · ' + co.name,
          sub: x.k === 'stockcash' ? x.sub : 'Needed before it can open', l: x.k === 'stockcash' ? 'Put in' : 'Choose', a: 'cldo', p: { id: co.id, k: x.k }
        }));
        return;
      }
      if (co.st !== 'open') return;
      if (co.cash < 0) { const a = topUp(co); L.push({ t: co.name + ' is in the red', sub: 'Put ' + mshort(a) + ' in from your cash', l: 'Put in', a: 'cash41in', p: { id: co.id, a } }); }
      const cmp = (co.compl || []).filter(c => c.st === 'open').length;
      if (cmp) L.push({ t: (cmp === 1 ? 'A complaint waits' : cmp + ' complaints wait') + ' · ' + co.name, sub: 'An answer keeps the reviews kind', l: 'Answer', a: 'go', p: { n: 'co', p: { id: co.id, t: 'cli', s: 'cmp' } } });
      const lap = docNeeds(co).find(d => co.docs[d] && co.docs[d].st === 'lapsed');
      if (lap) L.push({ t: 'Renew ' + docDef(lap, co.country)[0] + ' · ' + co.name, sub: 'It lapsed', l: 'Renew', a: 'applydoc', p: { id: co.id, d: lap } });
    });
    return L;
  }
  N.list = list;
  const row = (x, cls) => '<div class="fs58n' + (cls || '') + '"><span class="ctext"><b>' + esc(x.t) + '</b><small>' + esc(x.sub || '') + '</small></span>' + btn(x.l, 'nx59do', { a: x.a, p: x.p }, 'chip primary') + '</div>';
  /* the line on Home (ui/screens/mockup.js V.home) */
  N.card = function () {
    const L = list(), dy = window.DY59 ? DY59.row() : ''; /* today's goal shares the card (features/player/daily_goals.js) */
    if (!L.length && !dy) return '';
    return '<div class="card fs58 nx59"><button class="fs58h" data-a="nx59all"><span class="lab">Next</span><span class="fill"></span>' + (L.length > 1 ? '<small>1 of ' + L.length + ' ›</small>' : '') + '</button>' + (L.length ? row(L[0]) : '') + dy + '</div>';
  };
  /* a step's button: close the list if it is open, then do it */
  ACT.nx59do = q => { if (ui.sheet) U.closeSheet(); if (ACT[q.a]) ACT[q.a](q.p); };
  ACT.nx59all = () => {
    const L = list();
    if (L.length < 2) return;
    openSheet('<h2>What to do next</h2><div class="lrows nx59l">' + L.map(x => row(x, ' lrow')).join('') + '</div><div class="btnrow col">' + btn('Close', 'sheetclose', undefined, 'wide') + '</div>');
  };
})();

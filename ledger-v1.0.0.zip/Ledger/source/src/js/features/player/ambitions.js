/* ===== Round 27b: ambitions. You pick what kind of empire you want to build; each path has its own milestones,
   tiers and a perk, so different routes are worth taking. A legacy score keeps the history of what you reached.
   Paths: Industrial titan, Family dynasty, Market dominator, Hidden champion, Financier, Global group. ===== */
(function () {
  const R27 = window.R27 = window.R27 || {};
  const U = window.UI, { toast, save, render, svg, row } = U;
  const P = o => esc(JSON.stringify(o));
  const pillp = (t, c) => '<span class="pill ' + (c || '') + '">' + t + '</span>';
  const sumF = (a, f) => a.reduce((t, x) => t + (f(x) || 0), 0);
  const ROMAN = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X'];
  const A = () => { S.amb27 = S.amb27 || { path: null, tier: {}, done: {}, score: 0, since: 0, cnt: { buy: 0, pw: 0, bankfin: 0, ipo: 0 }, hist: [], ask: 0 }; return S.amb27; };
  R27.amb = A;

  /* ---------- facts the milestones look at ---------- */
  const live = () => S.cos.filter(c => c.st === 'open' || c.st === 'closed');
  const ann = c => window.R26 && R26.annRev ? R26.annRev(c) : (c.lastW ? c.lastW.rev * 52 : 0);
  const K = v => KC(v, S.country); /* a round local amount */
  const F = {
    rev: () => sumF(live(), c => ann(c) * (c.own || 100) / 100),
    jobs: () => sumF(live(), c => (c.staff || []).length + (c.mgr ? 1 : 0)) + ((S.office && S.office.staff) ? S.office.staff.length : 0),
    nw: () => { try { return netWorth().total; } catch (e) { return 0; } },
    links: () => (window.R27 && R27.links ? R27.links().length : 0),
    fams: () => { const s = {}; live().forEach(c => { if (BD[c.type]) s[BD[c.type].fam] = 1; }); return Object.keys(s).length; },
    prodOwn: () => live().some(c => ['prod', 'project'].indexOf((BD[c.type] || {}).fam) >= 0),
    full: () => live().filter(c => c.type !== 'hold' && (c.own || 100) >= 99.9 && coEbit12(c) > 0).length,
    div: () => S.stats.dividends || 0,
    years: () => S.week / 52,
    bustRecent: () => (S.stats.bustW || -999),
    control: () => live().filter(c => c.type !== 'hold').every(c => (c.own || 100) >= 67),
    shareTop: () => { if (!window.R26) return { best: 0, no1: 0 }; let best = 0, no1 = 0; R26.markets().forEach(m => { const t = R26.truthOf(m); best = Math.max(best, t.share); if (t.riv.every(x => x.share < t.share)) no1++; }); return { best, no1 }; },
    rating: (min, n) => live().filter(c => (c.rvN || 0) >= n && ratingOf(c) >= min).length,
    marginBest: (minRev) => Math.max(0, ...live().map(c => { const r = ann(c); return r >= (minRev || 0) && r > 0 ? coEbit12(c) / r : 0; })),
    ppe: () => { const j = Math.max(1, F.jobs()); return sumF(live(), c => coEbit12(c) * (c.own || 100) / 100) / j; },
    abroad: () => live().some(c => c.country !== S.country),
    countries: () => { const s = {}; live().forEach(c => { s[c.country] = 1; }); return Object.keys(s).length; },
    abroadShare: () => { const t = F.rev(); return t > 0 ? sumF(live().filter(c => c.country !== S.country), c => ann(c) * (c.own || 100) / 100) / t : 0; },
    has: t => live().some(c => c.type === t && c.st === 'open'),
    listedHold: () => live().some(c => c.type === 'hold' && c.listed),
    portfolio: () => { try { const n = netWorth(); return (n.inv || 0) + (n.funds || 0) + (n.crypto || 0); } catch (e) { return 0; } },
    stakes: () => (S.startups || []).filter(f => f.st !== 'exit' && (f.pct || 0) > 0).length,
    depShare: () => { if (!window.R26) return 0; const m = R26.markets().find(x => x.type === 'bank'); return m ? R26.truthOf(m).share : 0; },
    rank: (f, s) => { const r = R27.myRank ? R27.myRank(f, s) : null; return r ? r.rank : 999; },
    franchAbroad: () => live().some(c => c.country !== S.country && (c.franchise || c.foreignOf || c.branch)) || S.cos.some(c => c.fr && c.fr.masters && c.fr.masters.length)
  };
  R27.F = F;

  /* ---------- the paths: each tier is a list of milestones [id, text(f), progress(f) -> [now, target]];
     f multiplies the targets past level III, so a path never runs out ---------- */
  const b = v => [v ? 1 : 0, 1];
  const ms = v => mshort(K(v));
  const PATHS = {
    titan: {
      n: 'Industrial titan', ic: 'tool', d: 'Build a chain of companies that feed each other: materials, production, transport, sales. Lower costs and steadier supply, but one weak link hurts the whole group.',
      perk: t => 'Group trade: your suppliers work ' + [5, 8, 12][Math.min(2, t)] + '% cheaper for your own companies.',
      tiers: [
        [['t1a', () => 'Own a production or building company', () => b(F.prodOwn())], ['t1b', () => 'Two of your companies supply each other', () => [F.links(), 2]], ['t1c', () => 'Group sales of ' + ms(30e6) + ' a year', () => [F.rev(), K(30e6)]], ['t1d', () => '50 people work for you', () => [F.jobs(), 50]]],
        [['t2a', () => 'Four supply links inside the group', () => [F.links(), 4]], ['t2b', () => 'Companies in three different kinds of business', () => [F.fams(), 3]], ['t2c', () => 'Group sales of ' + ms(200e6) + ' a year', () => [F.rev(), K(200e6)]], ['t2d', () => '300 people work for you', () => [F.jobs(), 300]]],
        [['t3a', f => (8 * f) + ' supply links inside the group', f => [F.links(), 8 * f]], ['t3b', f => 'Group sales of ' + ms(1e9 * f) + ' a year', f => [F.rev(), K(1e9 * f)]], ['t3c', f => (1500 * f).toLocaleString('en-US').replace(/,/g, ' ') + ' people work for you', f => [F.jobs(), 1500 * f]], ['t3d', f => f > 1 ? 'Top 3 by sales in your country' : 'Top 10 by sales in your country', f => { const n = f > 1 ? 3 : 10; return [F.rank('cc', 'rev') <= n ? 1 : 0, 1]; }]]
      ]
    },
    dynasty: {
      n: 'Family dynasty', ic: 'house', d: 'Own your companies outright, keep control, pay yourself well and never go bust. Slower, but nobody can take it from you.',
      perk: t => 'Loyalty: rivals find it harder to poach your managers, and lenders trust you (' + [0.2, 0.35, 0.5][Math.min(2, t)] + ' points lower interest).',
      tiers: [
        [['d1a', () => 'Own all of two profitable companies', () => [F.full(), 2]], ['d1b', () => 'Pay yourself ' + ms(2e6) + ' in dividends', () => [F.div(), K(2e6)]], ['d1c', () => 'Three years without a bankruptcy', () => [Math.min(3, (S.week - Math.max(0, F.bustRecent())) / 52), 3]], ['d1d', () => 'Keep at least two thirds of every company', () => b(F.control() && live().length > 0)]],
        [['d2a', () => 'Own all of four profitable companies', () => [F.full(), 4]], ['d2b', () => 'Pay yourself ' + ms(20e6) + ' in dividends', () => [F.div(), K(20e6)]], ['d2c', () => 'Ten years in business', () => [F.years(), 10]], ['d2d', () => 'Net worth of ' + ms(100e6), () => [F.nw(), K(100e6)]]],
        [['d3a', f => 'Pay yourself ' + ms(150e6 * f) + ' in dividends', f => [F.div(), K(150e6 * f)]], ['d3b', f => 'Net worth of ' + ms(1e9 * f), f => [F.nw(), K(1e9 * f)]], ['d3c', f => (25 + 10 * (f > 1 ? Math.log(f) / Math.log(3) : 0)) + ' years in business', f => [F.years(), 25 + 10 * (f > 1 ? Math.log(f) / Math.log(3) : 0)]], ['d3d', () => 'Still two thirds of every company (four or more)', () => b(F.control() && live().length >= 4)]]
      ]
    },
    dominator: {
      n: 'Market dominator', ic: 'fire', d: 'Be the biggest name in your markets: win share, buy rivals, outlast price wars. Watch the competition authority.',
      perk: t => 'Deal maker: rivals sell to you about ' + [5, 8, 12][Math.min(2, t)] + '% cheaper.',
      tiers: [
        [['m1a', () => '15% of one market', () => [F.shareTop().best * 100, 15]], ['m1b', () => 'No. 1 in one market', () => [F.shareTop().no1, 1]], ['m1c', () => 'Buy a rival', () => [A().cnt.buy, 1]]],
        [['m2a', () => 'No. 1 in three markets', () => [F.shareTop().no1, 3]], ['m2b', () => '30% of one market', () => [F.shareTop().best * 100, 30]], ['m2c', () => 'Win a price war', () => [A().cnt.pw, 1]], ['m2d', () => 'Buy three rivals', () => [A().cnt.buy, 3]]],
        [['m3a', f => 'No. 1 in ' + (6 * f) + ' markets', f => [F.shareTop().no1, 6 * f]], ['m3b', () => '45% of one market', () => [F.shareTop().best * 100, 45]], ['m3c', f => f > 1 ? 'No. 1 among groups in your industries' : 'Top 3 among groups in your industries', f => [F.rank('ind', 'rev') <= (f > 1 ? 1 : 3) ? 1 : 0, 1]]]
      ]
    },
    champion: {
      n: 'Hidden champion', ic: 'star', d: 'Small, excellent and very profitable. Few companies, the best reviews and margins nobody else gets.',
      perk: t => 'Craft: quality settles ' + [2, 3, 4][Math.min(2, t)] + ' points higher in all your companies.',
      tiers: [
        [['h1a', () => 'A company rated 4.3 or better (50+ reviews)', () => [F.rating(4.3, 50), 1]], ['h1b', () => 'A 20% profit margin over a year', () => [F.marginBest(K(1e6)) * 100, 20]], ['h1c', () => 'Profit of ' + ms(300000) + ' per person working for you', () => [F.ppe(), K(300000)]]],
        [['h2a', () => 'A company rated 4.6 or better (200+ reviews)', () => [F.rating(4.6, 200), 1]], ['h2b', () => 'A 30% margin with sales over ' + ms(10e6), () => [F.marginBest(K(10e6)) * 100, 30]], ['h2c', () => 'A company abroad', () => b(F.abroad())], ['h2d', () => 'Profit of ' + ms(700000) + ' per person', () => [F.ppe(), K(700000)]]],
        [['h3a', f => (3 * f) + ' companies rated 4.5 or better', f => [F.rating(4.5, 200), 3 * f]], ['h3b', f => 'A 35% margin with sales over ' + ms(50e6 * f), f => [F.marginBest(K(50e6 * f)) * 100, 35]], ['h3c', f => 'Profit of ' + ms(1.5e6 * f) + ' per person', f => [F.ppe(), K(1.5e6 * f)]]]
      ]
    },
    financier: {
      n: 'Financier', ic: 'bank', d: 'Make money with money: a holding company, a bank, investments and stakes. Leverage works both ways.',
      perk: t => 'Credit: you borrow ' + [0.3, 0.5, 0.8][Math.min(2, t)] + ' points cheaper.',
      tiers: [
        [['f1a', () => 'Own a holding company', () => b(F.has('hold'))], ['f1b', () => 'Investments worth ' + ms(5e6), () => [F.portfolio(), K(5e6)]], ['f1c', () => 'Own a bank, insurer or fund', () => b(F.has('bank') || F.has('insco') || F.has('fund'))]],
        [['f2a', () => 'Own a bank', () => b(F.has('bank'))], ['f2b', () => 'Finance a purchase through your own bank', () => [A().cnt.bankfin, 1]], ['f2c', () => 'A listed holding company', () => b(F.listedHold())], ['f2d', () => 'Investments worth ' + ms(100e6), () => [F.portfolio(), K(100e6)]]],
        [['f3a', f => (f > 1 ? 3 * f : 1) + '% of all bank deposits in your country', f => [F.depShare() * 100, f > 1 ? 3 * f : 1]], ['f3b', f => 'Net worth of ' + ms(2e9 * f), f => [F.nw(), K(2e9 * f)]], ['f3c', f => 'Stakes in ' + (5 * f) + ' startups', f => [F.stakes(), 5 * f]]]
      ]
    },
    global: {
      n: 'Global group', ic: 'globe', d: 'Plant your flag in many countries. More markets, more currencies, more rules to follow.',
      perk: t => 'Global reach: setting up abroad costs ' + [20, 35, 50][Math.min(2, t)] + '% less.',
      tiers: [
        [['g1a', () => 'Companies in two countries', () => [F.countries(), 2]], ['g1b', () => 'A franchise or branch abroad', () => b(F.franchAbroad())], ['g1c', () => 'Group sales of ' + ms(20e6) + ' a year', () => [F.rev(), K(20e6)]]],
        [['g2a', () => 'Companies in four countries', () => [F.countries(), 4]], ['g2b', () => '30% of sales from abroad', () => [F.abroadShare() * 100, 30]], ['g2c', () => 'Top 10 by sales in your country', () => [F.rank('cc', 'rev') <= 10 ? 1 : 0, 1]]],
        [['g3a', f => 'Companies in ' + Math.min(15, 8 + 3 * (f > 1 ? Math.log(f) / Math.log(3) : 0)) + ' countries', f => [F.countries(), Math.min(15, 8 + 3 * (f > 1 ? Math.log(f) / Math.log(3) : 0))]], ['g3b', f => f > 1 ? 'Top 10 by sales worldwide' : 'Top 25 by sales worldwide', f => [F.rank('world', 'rev') <= (f > 1 ? 10 : 25) ? 1 : 0, 1]], ['g3c', f => 'Group sales of ' + ms(2e9 * f) + ' a year', f => [F.rev(), K(2e9 * f)]]]
      ]
    }
  };
  R27.PATHS = PATHS;
  const PTS = [10, 25, 60], TIERB = [50, 150, 400];
  /* past tier III a path keeps going: the money and count targets triple each level */
  function tierList(k, t) {
    const p = PATHS[k], f = t < 3 ? 1 : Math.pow(3, t - 2), L = p.tiers[Math.min(2, t)];
    return L.map(m => [t < 3 ? m[0] : m[0] + '_' + t, m[1](f), () => m[2](f)]);
  }
  R27.tierList = tierList;
  const curTier = k => A().tier[k] || 0;
  /* perks: only for the path you follow, after you have settled in */
  R27.perk = function (k) {
    const a = A();
    if (a.path !== k || S.week < (a.settle || 0)) return -1;
    return Math.min(2, curTier(k) > 0 ? curTier(k) - 1 + (tierDone(k, curTier(k)) ? 1 : 0) : 0);
  };
  function tierDone(k, t) { return tierList(k, t).every(m => A().done[m[0]]); }
  function check() {
    const a = A();
    if (!a.path) return;
    const k = a.path, t = curTier(k);
    const L = tierList(k, t);
    L.forEach(m => {
      if (a.done[m[0]]) return;
      let r = [0, 1];
      try { r = m[2](); } catch (e) { }
      if (r[0] >= r[1] && r[1] > 0) {
        a.done[m[0]] = S.week;
        const pts = PTS[Math.min(2, t)] * (t > 2 ? t - 1 : 1);
        a.score += pts;
        a.hist.unshift({ w: S.week, t: m[1], path: k, pts });
        if (a.hist.length > 40) a.hist.length = 40;
        info('Ambition', 'Milestone: ' + m[1], PATHS[k].n + ' ' + ROMAN[t] + '. +' + pts + ' legacy points.', 0, 'good');
      }
    });
    if (L.every(m => a.done[m[0]])) {
      const bonus = TIERB[Math.min(2, t)] * (t > 2 ? t - 1 : 1);
      a.score += bonus;
      a.tier[k] = t + 1;
      a.hist.unshift({ w: S.week, t: PATHS[k].n + ' ' + ROMAN[t] + ' complete', path: k, pts: bonus });
      news(S.player.name + ' reaches ' + PATHS[k].n.toLowerCase() + ' level ' + ROMAN[t] + '.', 'good');
      addMsg({ kind: 'info', from: 'Ambition', title: PATHS[k].n + ' ' + ROMAN[t] + ' complete', body: '+' + bonus + ' legacy points. ' + (t < 2 ? 'Your perk grows: ' + PATHS[k].perk(t + 1) : 'The next level asks for three times as much.') + ' Next: ' + tierList(k, t + 1).map(m => m[1]).join('; ') + '.', tone: 'good', status: 'done', go: { l: 'Ambition', a: 'go', p: { n: 'amb27' } } });
    }
  }
  R27.ambCheck = check;
  addStep('week.after', 55, 'ambitions weekly', () => {
    try {
      const a = A();
      /* count wins: rivals pushed out by a price war */
      S.cos.forEach(co => {
        if (co.flags && co.flags.pw) co.pw27 = co.flags.pw.rid;
        else if (co.pw27) { if (!(rivalsOf(co) || []).some(r => r.id === co.pw27)) a.cnt.pw++; co.pw27 = 0; }
      });
      if (S.week % 4 === 0) check();
      /* a nudge to choose, once a business is running */
      if (!a.path && !a.ask && S.cos.some(c => c.st === 'open') && S.week > 4) {
        a.ask = S.week;
        addMsg({ kind: 'info', from: 'Ambition', title: 'What do you want to build?', body: 'Pick an ambition: an industrial group, a family dynasty, the market leader, a hidden champion, a financier or a global group. Each rewards a different way to play and gives a perk.', tone: 'n', status: 'done', go: { l: 'Choose', a: 'go', p: { n: 'amb27' } } });
      }
    } catch (e) { console.error(e); }
  });
  addStep('acquireRival.after', 20, 'ambitions: count the purchase', (co, r, price, ph) => { if (typeof ph.r === 'object') A().cnt.buy++; });
  addStep('bankrupt.before', 5, 'ambitions: the week of a bust', () => { S.stats.bustW = S.week; });

  /* ---------- perks ---------- */
  window.loanOffer = pipeView('window.loanOffer', window.loanOffer, 0); /* window.loanOffer: the screen above, then the steps below and in later files */
  addStep('window.loanOffer', 10, '---------- perks ----------', (o) => {
    try { const f = R27.perk('financier'), d = R27.perk('dynasty'); if (f >= 0) o.margin -= [0.003, 0.005, 0.008][f]; else if (d >= 0) o.margin -= [0.002, 0.0035, 0.005][d]; } catch (e) { }
    return o;
  });
  window.abroadFee = pipeView('window.abroadFee', window.abroadFee, 0); /* window.abroadFee: the screen above, then the steps below and in later files */
  addStep('window.abroadFee', 10, 'ambitions window.abroadFee', (v) => { const p = R27.perk('global'); return p >= 0 ? rnl(v * (1 - [0.2, 0.35, 0.5][p]), 5000) : v; });
  window.qualityTarget = pipeView('window.qualityTarget', window.qualityTarget, 0); /* window.qualityTarget: the screen above, then the steps below and in later files */
  addStep('window.qualityTarget', 10, 'ambitions window.qualityTarget', (v) => { const p = R27.perk('champion'); return p >= 0 ? Math.min(99, v + [2, 3, 4][p]) : v; });
  addStep('proposeBuy.terms', 10, 'ambitions: the dominator perk pays more', (co, r, t) => { const p = R27.perk('dominator'); if (p >= 0) t.mult *= [1.05, 1.08, 1.12][p]; });

  /* ---------- the screen ---------- */
  V.titles.amb27 = 'Ambition';
  V.heads = V.heads || {};
  V.heads.amb27 = () => { const a = A(); return { t: 'Ambition', sub: a.path ? PATHS[a.path].n + ' ' + ROMAN[curTier(a.path)] : 'Choose what you want to build', right: pillp('Legacy ' + a.score, 'amb') }; };
  const barP = (f, c) => '<div class="bar"><i style="width:' + Math.max(2, Math.min(100, f * 100)) + '%;background:' + (c || 'var(--amber)') + '"></i></div>';
  const progTxt = (r, txt) => r[1] === 1 ? (r[0] >= 1 ? 'Done' : 'Not yet') : /%|margin|market/.test(txt) && r[1] < 101 ? Math.round(r[0]) + ' / ' + r[1] : (r[1] > 5000 ? mshort(Math.max(0, r[0])) + ' / ' + mshort(r[1]) : Math.floor(r[0] * 10) / 10 + ' / ' + r[1]);
  V.amb27 = function () {
    const a = A();
    let h = '';
    if (a.path) {
      const k = a.path, t = curTier(k), p = PATHS[k], L = tierList(k, t);
      const n = L.filter(m => a.done[m[0]]).length;
      const pk = R27.perk(k);
      h += '<div class="card"><div class="bhead"><b>' + esc(p.n) + ' ' + ROMAN[t] + '</b>' + pillp(n + ' of ' + L.length, 'blue') + '</div><span class="tipt">' + esc(p.d) + '</span>' + barP(n / L.length) + '<span class="tipt">' + (pk >= 0 ? 'Perk: ' + esc(p.perk(pk)) : S.week < (a.settle || 0) ? 'Perk starts ' + dateStr(a.settle) + ', once you have settled into this path.' : 'Perk: ' + esc(p.perk(0))) + '</span></div>';
      h += '<h2 class="sec">Milestones</h2><div class="lrows">' + L.map(m => {
        let r = [0, 1]; try { r = m[2](); } catch (e) { }
        const d = a.done[m[0]];
        return '<div class="lrow"><span class="av' + (d ? ' me27' : '') + '">' + (d ? '✓' : '·') + '</span><span class="ctext"><b class="wrap">' + esc(m[1]) + '</b><small>' + (d ? 'Reached ' + dateStr(d) : progTxt(r, m[1])) + '</small>' + (d ? '' : barP(r[1] > 0 ? r[0] / r[1] : 0, 'var(--blue)')) + '</span></div>';
      }).join('') + '</div>';
    } else h += '<div class="card sense"><span class="tipt">Each path has its own milestones and a perk. You can switch later; the new perk starts after half a year.</span></div>';
    h += '<h2 class="sec">' + (a.path ? 'Other paths' : 'Paths') + '</h2><div class="lrows">' + Object.keys(PATHS).filter(k => k !== a.path).map(k => {
      const p = PATHS[k], t = curTier(k);
      return '<button class="lrow" data-a="amb27pick" data-p="' + P({ k }) + '"><span class="lic">' + svg(p.ic, 20) + '</span><span class="ctext"><b>' + esc(p.n) + (t ? ' <small>· level ' + ROMAN[t - 1] + ' done</small>' : '') + '</b><small>' + esc(p.d) + '</small></span><i>›</i></button>';
    }).join('') + '</div>';
    if (a.hist.length) h += '<h2 class="sec">Legacy</h2><div class="lrows">' + a.hist.slice(0, 8).map(x => '<div class="lrow"><span class="ctext"><b class="wrap">' + esc(x.t) + '</b><small>' + dateStr(x.w) + ' · ' + esc(PATHS[x.path] ? PATHS[x.path].n : '') + '</small></span><b>+' + x.pts + '</b></div>').join('') + '</div>';
    return h;
  };
  ACT.amb27pick = p => {
    const a = A(), k = p.k, P2 = PATHS[k];
    if (!P2) return;
    const go2 = () => {
      a.path = k;
      a.since = S.week;
      a.settle = a.hist.some(x => x.path) || a.was ? S.week + 26 : 0;
      a.was = 1;
      a.tier[k] = a.tier[k] || 0;
      check();
      save();
      render(true);
      toast('Your ambition: ' + P2.n + '.');
    };
    if (!a.path) { go2(); return; }
    confirmThen('Switch to ' + P2.n + '?', 'Milestones you reached stay in your legacy. The ' + PATHS[a.path].n.toLowerCase() + ' perk stops now, and the new perk starts in half a year.', 'Switch', go2);
  };

  /* ---------- where you find it ---------- */
  addStep('V.stats', 10, 'ambitions V.stats', (h) => {
    if ((ui.st27 || 'ov') !== 'ov') return h;
    const a = A();
    const c = '<button class="card opt2" data-a="go" data-p="' + P({ n: 'amb27' }) + '"><div class="bhead"><b>' + (a.path ? esc(PATHS[a.path].n) + ' ' + ROMAN[curTier(a.path)] : 'Choose your ambition') + '</b>' + pillp('Legacy ' + a.score, 'amb') + '</div><span class="tipt">' + (a.path ? tierList(a.path, curTier(a.path)).filter(m => a.done[m[0]]).length + ' of ' + tierList(a.path, curTier(a.path)).length + ' milestones on this level.' : 'Six ways to build an empire. Pick one for its milestones and perk.') + '</span></button>';
    const i = h.indexOf('</div>', h.indexOf('class="ptabs"'));
    return i > 0 ? h.slice(0, i + 6) + c + h.slice(i + 6) : c + h;
  });
})();


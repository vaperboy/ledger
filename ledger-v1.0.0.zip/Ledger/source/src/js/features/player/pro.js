/* ===== Round 56: Ledger Pro. Which features are paid, in one place. Round 59: sold in the app.
   PRO.has(k) is true when k is free, or bought (Pro, or a pack with k in it); PRO.ask(k) opens the offer for k and
   says false when k is locked.
   Paid features:
     untl     Until needed (days tick by themselves) and catch-up runs longer than three days
     slots    save slots 2 and 3 (slot 1 and the monthly backup stay free)
     tycoon   the big-money trades: bank, insurer, investment fund, oil and gas, regional airline, shipping, casino,
              indoor ski hall
     clubs    football clubs
     world    countries beyond the UK, the US, Germany and France, to start in or to open in
     estates  vineyards, islands, land, castles
     pe       private equity funds
     trades   every trade from the start (free players open them as their net worth grows: trade_unlocks.js)
   How it is sold: Ledger Pro (monthly, yearly or once for good) opens all of it; four packs, each bought once, open
   part of it (PACKS). In the iPhone app the App Store says what the player owns (LedgerApp.store, made by
   ios-app/native/app-bridge.js with RevenueCat); in the browser the test switch and test purchases do. What the
   player owns is kept on the device (KEY:own), never in the save, so a save file never carries a purchase.
   When a subscription ends, everything already bought, opened or built keeps working: only opening something new
   that is locked asks again.
   A second test switch (browser only) shows every screen at once, instead of each part appearing as you play
   (features/screens/show_when_used.js); kept in this browser (KEY:showall). ===== */
window.PRO = window.PRO || {};
(function () {
  const PRO = window.PRO, K = U.KEY + ':pro', KO = U.KEY + ':own', APP = window.LedgerApp && LedgerApp.store ? LedgerApp : null;
  const FEAT = {
    untl: ['Until needed', 'Let the days tick by until something needs you, and longer catch-up runs.'],
    slots: ['More save slots', 'Two extra save slots next to the free one and the monthly backup.'],
    tycoon: ['Tycoon trades', 'Banks, insurers, investment funds, oil and gas, airlines, shipping and casinos.'],
    clubs: ['Football clubs', 'Buy or found a club, run the squad and the season.'],
    world: ['The whole world', 'Start in or expand to every country in the game (the UK, the US, Germany and France are free).'],
    estates: ['Estates', 'Vineyards, a private island, land, forest and a castle that earn and give perks.'],
    pe: ['Private equity', 'Commit to buyout and growth funds: illiquid, ten years, the best returns.'],
    trades: ['Every trade from the start', 'Start any business at once, instead of opening them as your net worth grows.']
  };
  const TYCOON = { bank: 1, insco: 1, fund: 1, oilgas: 1, airline: 1, shipping: 1, casino: 1, indoorski: 1 };
  const FREE_CC = { UK: 1, US: 1, DE: 1, FR: 1 }; /* in this order on the start screen's Suggested row */
  /* the packs: name, the features in it, what it opens in a few words */
  const PACKS = {
    world: ['The whole world', ['world'], 'Every country, to start in or to open in'],
    tycoon: ['Tycoon', ['tycoon', 'pe'], 'Banks, insurers, oil, airlines, casinos and private equity'],
    estates: ['Estates and clubs', ['estates', 'clubs'], 'Vineyards, an island, a castle and football clubs'],
    time: ['Time savers', ['untl', 'slots', 'trades'], 'Until needed, two more save slots, every trade at once']
  };
  const PLANS = [['monthly', 'Monthly', 'a month'], ['yearly', 'Yearly', 'a year'], ['lifetime', 'Lifetime', 'once']];
  const EULA = 'https://www.apple.com/legal/internet-services/itunes/dev/stdeula/';
  /* launch prices in US dollars (App Store Connect has the same); the App Store shows each player their own
     country's price. Where there is no store (a browser) the game shows a close local price from these. */
  const USD = { monthly: 3.99, yearly: 24.99, lifetime: 49.99, world: 4.99, tycoon: 4.99, estates: 4.99, time: 4.99, skin_midnight: 1.99 };
  /* looks (V.1.0.0): colours only, bought one by one, not part of Pro; styles/05_skins.css has them.
     id: name, a few words, three colours for the little preview */
  const SKINS = {
    classic: ['Classic', 'Graphite and brass, the way Ledger looks', ['#111213', '#c4a47c', '#93b8a0']],
    skin_midnight: ['Midnight', 'Deep navy with silver blue', ['#0c1220', '#9bbcff', '#e3b96c']]
  };
  PRO.SKINS = SKINS;
  PRO.FEAT = FEAT;
  PRO.TYCOON = TYCOON;
  PRO.FREE_CC = FREE_CC;
  PRO.PACKS = PACKS;
  const get = k => { try { return localStorage.getItem(k); } catch (e) { return null; } };
  const put = (k, v) => { try { localStorage.setItem(k, v); } catch (e) { } };
  /* what the player owns: { pro: 'monthly' | 'yearly' | 'lifetime' | null, packs: { world: 1, ... }, renews: time } */
  let own = {}, price = {};
  try { own = JSON.parse(get(KO) || '{}') || {}; } catch (e) { }
  const setOwn = o => { own = o || {}; put(KO, JSON.stringify(own)); if (APP) PRO.on = !!own.pro; useSkin(); };
  PRO.on = APP ? !!own.pro : get(K) !== '0';
  const K2 = U.KEY + ':showall';
  PRO.showAll = !APP && get(K2) !== '0'; /* testing: every screen at once */
  const KS = U.KEY + ':skin';
  const hasSkin = id => id === 'classic' || !!(own.packs && own.packs[id]);
  /* the chosen look, if it is still yours (kept on the device, like purchases) */
  const useSkin = () => { const k = get(KS); const id = SKINS[k] && hasSkin(k) ? k : 'classic'; PRO.skin = id; if (id === 'classic') delete document.documentElement.dataset.skin; else document.documentElement.dataset.skin = id.replace('skin_', ''); };
  const packOf = k => Object.keys(PACKS).filter(p => PACKS[p][1].indexOf(k) >= 0)[0];
  const hasPack = p => PRO.on || !!(own.packs && own.packs[p]);
  PRO.has = k => !FEAT[k] || hasPack(packOf(k));
  PRO.typeOk = t => !TYCOON[t] || PRO.has('tycoon');
  PRO.ccOk = cc => !!FREE_CC[cc] || PRO.has('world');
  PRO.pill = '<span class="pill amb">Pro</span>';
  /* a small Pro mark next to anything locked, so it is clear before tapping (gone once it is yours) */
  PRO.tag = k => PRO.has(k) ? '' : '<i class="pro56">Pro</i>';
  const local = id => {
    const c = CO[(S && S.country) || ui.sc] || CO.UK, us = CO.US;
    if (!c || !us || !USD[id]) return '';
    const r = us.fx / c.fx; /* local money per dollar */
    let v = USD[id] * r;
    /* .99 where prices have pennies (dollar, pound, euro ...); whole numbers ending in 9 in krone, yen or won */
    v = r < 5 ? Math.ceil(v) - 0.01 : v < 1000 ? Math.ceil(v / 10) * 10 - 1 : Math.ceil(v / 100) * 100;
    const n = r < 5 ? v.toFixed(2) : String(v).replace(/\B(?=(\d{3})+(?!\d))/g, ' '), sy = c.symbol || c.currency;
    return /^(kr|zł|[A-Z]{3})$/.test(sy) ? n + ' ' + sy : sy + n;
  };
  /* the App Store's own price text, without empty decimals */
  const pr = id => price[id] ? price[id].replace(/[.,]00(?!\d)/, '') : APP ? '' : local(id);
  const plan = id => PLANS.filter(x => x[0] === id)[0] || PLANS[0];
  const status = () => {
    const p = Object.keys(PACKS).filter(x => own.packs && own.packs[x]).map(x => PACKS[x][0]);
    if (APP && own.pro) return 'Ledger Pro, ' + plan(own.pro)[1].toLowerCase() + (own.renews && own.pro !== 'lifetime' ? ' · renews ' + new Date(own.renews).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : '');
    if (!APP && PRO.on) return 'Everything is open for testing.';
    return p.length ? 'Your packs: ' + p.join(', ') : 'Free version: everything but the Pro features.';
  };
  const packRow = (id, cls) => '<div class="lrow"><span class="ctext"><b>' + esc(PACKS[id][0]) + '</b><small class="wrap">' + esc(PACKS[id][2]) + '</small></span>' +
    (hasPack(id) ? '<span class="pill green">Yours</span>' : btn(pr(id) || 'Buy', 'probuy', { id }, 'chip ' + (cls || ''))) + '</div>';
  const skinRow = id => '<div class="lrow"><span class="sw59">' + SKINS[id][2].map(c => '<i style="background:' + c + '"></i>').join('') + '</span><span class="ctext"><b>' + esc(SKINS[id][0]) + '</b><small class="wrap">' + esc(SKINS[id][1]) + '</small></span>' +
    (PRO.skin === id ? '<span class="pill green">In use</span>' : hasSkin(id) ? btn('Use', 'proskin', { id }, 'chip') : btn(pr(id) || 'Buy', 'probuy', { id }, 'chip')) + '</div>';
  ACT.proskin = p => { if (!hasSkin(p.id)) return; put(KS, p.id); useSkin(); if (ui.sheet && !S) PRO.store(); else render(); };
  /* what the player was doing when a lock stopped them: it carries on by itself once the purchase goes through */
  let again = null;
  /* the offer for one locked feature: its pack, or Pro */
  PRO.sheet = (k, then) => {
    const f = FEAT[k] || ['Ledger Pro', ''], pk = packOf(k);
    again = then ? { k, f: then } : null;
    openSheet('<h2>' + esc(f[0]) + PRO.pill + '</h2><p class="lead">' + esc(f[1]) + '</p><div class="lrows pro59">' + (pk ? packRow(pk, 'primary') : '') +
      '<div class="lrow"><span class="ctext"><b>Ledger Pro</b><small class="wrap">Everything in the game: monthly, yearly or once</small></span>' + btn('See', 'prostore', undefined, 'chip') + '</div></div>' +
      '<p class="muted small">Packs are bought once. Everything else in the game stays free.</p><div class="btnrow col">' + btn('Close', 'sheetclose', undefined, 'wide') + '</div>');
  };
  PRO.ask = (k, then) => { if (PRO.has(k)) return true; PRO.sheet(k, then); return false; };
  ACT.proask = p => PRO.sheet(p.k);
  /* the store: Pro's three plans, the four packs, restore, manage, privacy and terms; a sheet from anywhere, and
     the Ledger Pro app on the phone */
  const storeBody = () => {
    const sel = ui.proPlan || 'yearly', p = plan(sel);
    return '<p class="muted small">' + esc(status()) + '</p>' +
      (PRO.on ? '' : '<span class="lab">Everything in the game</span><div class="ags">' + PLANS.map(x => '<button class="opt ag' + (x[0] === sel ? ' on' : '') + '" data-a="proplan" data-p="' + esc(JSON.stringify({ v: x[0] })) + '"><b>' + x[1] + '</b><small>' + (pr(x[0]) ? esc(pr(x[0])) + ' ' : '') + x[2] + '</small></button>').join('') + '</div>' +
        btn('Get Ledger Pro' + (pr(sel) ? ' · ' + esc(pr(sel)) + ' ' + p[2] : ''), 'probuy', { id: sel }, 'primary wide')) +
      '<span class="lab">Packs, bought once</span><div class="lrows pro59">' + Object.keys(PACKS).map(id => packRow(id)).join('') + '</div>' +
      '<span class="lab">Looks</span><div class="lrows pro59">' + Object.keys(SKINS).map(skinRow).join('') + '</div>' +
      '<p class="muted small">' + (APP ? 'Paid with your Apple ID. Monthly and yearly renew by themselves until you cancel them in your App Store settings, at least a day before the period ends.' : 'Browser test: buying opens things in this browser only.') + '</p>' +
      '<div class="chips">' + btn('Restore purchases', 'prorestore', undefined, 'chip ghost') + (APP && own.pro && own.pro !== 'lifetime' ? btn('Manage subscription', 'promanage', undefined, 'chip ghost') : '') + btn('Privacy', 'privacy', undefined, 'chip ghost') + btn('Terms of use', 'prolink', { u: EULA }, 'chip ghost') + '</div>';
  };
  /* in a game the store is the Ledger Pro app on the phone (a page, room for everything); before a game, a sheet */
  PRO.store = () => {
    again = null;
    if (S && !ui.menu && V.pro59) { if (ui.sheet) closeSheet(); if (ui.tab === 'phone' && ui.ph && ui.ph.n === 'pro59') return render(); return ACT.phapp({ n: 'pro59' }); }
    openSheet('<h2>Ledger Pro</h2>' + storeBody() + '<div class="btnrow col">' + btn('Close', 'sheetclose', undefined, 'wide') + '</div>', 'plan'); };
  V.titles.pro59 = 'Ledger Pro';
  V.pro59 = () => storeBody();
  if (window.PHAPPS) window.PHAPPS.push(['pro59', 'star', 'Ledger Pro', 'a']);
  const done = o => {
    setOwn(o);
    const a = again; again = null;
    closeSheet(); render();
    if (a && PRO.has(a.k)) setTimeout(a.f, 50); /* carry on with what the lock stopped */
  };
  ACT.prostore = () => PRO.store();
  ACT.proplan = p => { ui.proPlan = p.v; if (ui.sheet && !S) PRO.store(); else render(); };
  ACT.probuy = p => {
    const skin = !!SKINS[p.id];
    const what = PACKS[p.id] ? 'The ' + PACKS[p.id][0] + ' pack is yours.' : skin ? SKINS[p.id][0] + ' is yours and in use.' : 'Ledger Pro is on. Thank you!';
    if (skin) put(KS, p.id); /* a bought look is put on at once */
    if (!APP) { /* the browser: a test purchase, kept in this browser */
      const o = Object.assign({}, own, { packs: Object.assign({}, own.packs) });
      if (PACKS[p.id] || skin) o.packs[p.id] = 1; else { o.pro = p.id; PRO.on = true; put(K, '1'); }
      done(o); toast(what); return;
    }
    APP.store.buy(p.id).then(o => { done(o); toast(what); }, e => { if (!(e && e.cancelled)) toast((e && e.message) || 'The purchase did not go through.', true); });
  };
  ACT.prorestore = () => {
    if (!APP) { toast('Purchases are restored in the app.'); return; }
    APP.store.restore().then(o => { done(o); toast(o.pro || Object.keys(o.packs || {}).length ? 'Your purchases are back.' : 'No purchases found for this Apple ID.'); }, () => toast('Could not reach the App Store. Try again later.', true));
  };
  ACT.promanage = () => APP.store.manage();
  useSkin();
  ACT.prolink = p => APP ? APP.open(p.u) : window.open(p.u, '_blank');
  if (APP) {
    APP.store.onChange(o => { setOwn(o); try { render(); } catch (e) { } });
    APP.store.load().then(r => { price = r.items || {}; setOwn(r.own); }, () => { });
  }

  /* ---------- the locks ---------- */
  /* a catch-up of up to three days after a long absence is free (goals_and_awards.js) */
  addStep('ACT.untilneeded.around', 96, 'Pro: Until needed', (next) => { const free = ui.catch56 && (ui.untlMax || 0) <= 3; ui.catch56 = 0; if (ui.untl || free || PRO.ask('untl', () => ACT.untilneeded())) return next(); });
  ACT.ncgo = pipeView('ACT.ncgo', ACT.ncgo, 1);
  addStep('ACT.ncgo.around', 10, 'Pro: tycoon trades and countries', (p, next) => {
    const st = ui.nc || {};
    if (p && p.bd && !PRO.typeOk(p.bd)) return PRO.sheet('tycoon', () => ACT.ncgo(p));
    if (st.country && st.country !== S.country && !PRO.ccOk(st.country)) return PRO.sheet('world', () => ACT.ncgo(p));
    return next();
  });
  ['clubbuy', 'clubfound'].forEach(k => { ACT[k] = pipeView('ACT.' + k, ACT[k], 1); addStep('ACT.' + k + '.around', 10, 'Pro: football clubs', (p, next) => { if (PRO.ask('clubs', () => ACT[k](p))) return next(p); }); });
  addStep('ACT.slotkeep.around', 10, 'Pro: slots 2 and 3', (p, next) => { if (p && p.s !== 'slot:1' && !PRO.ask('slots', () => ACT.slotkeep(p))) return; return next(); });
  ACT.slotkeep = pipeView('ACT.slotkeep', ACT.slotkeep, 1);

  /* ---------- Settings: what the player has, the store, and (browser only) the test switches ---------- */
  PRO.card = () => {
    return '<div class="card"><div class="bhead"><b>Ledger Pro</b>' + (PRO.on ? '<span class="pill green">' + (APP ? 'On' : 'All open') + '</span>' : '<span class="pill">Free version</span>') + '</div>' +
      '<span class="tipt">' + esc(status()) + '</span><div class="two">' + btn('Store', 'prostore') + btn('Restore purchases', 'prorestore') + '</div>' +
      '<span class="lab">Look</span>' + chips(Object.keys(SKINS).filter(hasSkin).map(id => [id, SKINS[id][0]]), PRO.skin, 'proskinc') +
      (APP ? '' : '<span class="lab">Test</span>' + chips([[1, 'Everything open'], [0, 'Play as a free player']], PRO.on ? 1 : 0, 'pro56') +
        '<span class="lab">Screens</span>' + chips([[1, 'Show everything'], [0, 'Appear as you play']], PRO.showAll ? 1 : 0, 'pro57')) + '</div>';
  };
  ACT.proskinc = p => ACT.proskin({ id: p.v });
  ACT.pro57 = p => { PRO.showAll = !!+p.v; put(K2, PRO.showAll ? '1' : '0'); render(); toast(PRO.showAll ? 'Every screen shows.' : 'Screens appear as you play, like for a new player.'); };
  ACT.pro56 = p => { PRO.on = !!+p.v; put(K, PRO.on ? '1' : '0'); if (!PRO.on) setOwn({}); render(); toast(PRO.on ? 'Everything is open.' : 'You now play as a free player.'); };
})();

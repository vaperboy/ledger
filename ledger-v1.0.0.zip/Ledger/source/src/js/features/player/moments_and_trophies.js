/* ===== Round 28a: moments that feel good.
   Firsts are celebrated with a short full-screen moment and kept on a trophy wall in the office.
   Every company gets a storefront picture that grows with it: an empty unit, a small shop, a busy one with a queue,
   a flagship. And "Next day" now tells you how the day went, with the takings counting up. ===== */
window.R28 = window.R28 || {};
(function () {
  const R28 = window.R28;
  const U = window.UI, { toast, save, render, svg, row } = U;
  const P = o => esc(JSON.stringify(o));
  const pillp = (t, c) => '<span class="pill ' + (c || '') + '">' + t + '</span>';
  const sumF = (a, f) => a.reduce((t, x) => t + (f(x) || 0), 0);
  const live = () => S.cos.filter(c => c.st === 'open' || c.st === 'closed');
  const K = v => KC(v, S.country); /* a round local amount */
  /* during a trophy check each costly number is worked out once (M), not once per trophy */
  let M = null;
  const memo = (k, f) => () => { if (!M) return f(); if (!(k in M)) M[k] = f(); return M[k]; };
  const jobs = memo('jobs', () => sumF(live(), c => (c.staff || []).length + (c.mgr ? 1 : 0)));
  const nwAll = memo('nw', () => { try { return netWorth(); } catch (e) { return { total: 0 }; } });
  const nw = () => nwAll().total;

  /* ---------- the firsts ---------- */
  const ACH = [
    ['cust', 'First customer', 'bag', () => { const c = live().find(x => (x.dl && x.dl.u > 0) || (x.lastW && x.lastW.units > 0)); return c && c.name + ' served its first customer.'; }],
    ['emp', 'First employee', 'people', () => { const c = live().find(x => (x.staff || []).length); return c && S.npcs[c.staff[0].id] && S.npcs[c.staff[0].id].name + ' joined ' + c.name + '.'; }],
    ['profit', 'First profitable month', 'chart', () => { const c = live().find(x => (x.hist || []).some(h => h.profit > 0)); return c && c.name + ' made money for a whole month.'; }],
    ['year', 'One year in business', 'star', () => { const w0 = Math.min.apply(null, S.cos.map(c => c.w0 == null ? 1e9 : c.w0)); return S.week - w0 >= 52 && 'A year since you started your first company.'; }],
    ['mgr', 'First manager', 'tie', () => { const c = live().find(x => x.mgr && S.npcs[x.mgr]); return c && S.npcs[c.mgr].name + ' now runs ' + c.name + '.'; }],
    ['ten', 'Ten people on the payroll', 'people', () => jobs() >= 10 && 'Ten people now earn their living with you.'],
    ['branch', 'First branch', 'biz', () => { const t = {}; let hit = null; live().forEach(c => { if (c.st === 'open') { if (t[c.type]) hit = c; t[c.type] = 1; } }); const b = live().find(c => c.branch || c.chain); return (hit || b) && 'Your second ' + BD[(hit || b).type].n.toLowerCase() + ' is open.'; }],
    ['million', 'First million', 'coin', () => nw() >= K(1e6) && 'Your net worth passed ' + money(K(1e6)) + '.'],
    ['div', 'First dividend', 'coin', () => (S.stats.dividends || 0) > 0 && 'Your company paid you a share of its profit.'],
    ['stars', 'A 4.5-star business', 'star', () => { const c = live().find(x => (x.rvN || 0) >= 50 && ratingOf(x) >= 4.5); return c && 'Customers rate ' + c.name + ' ' + ratingOf(c).toFixed(1) + ' stars.'; }],
    ['acq', 'First acquisition', 'deal', () => window.R27 && R27.amb && R27.amb().cnt.buy > 0 && 'You bought a competitor.'],
    ['no1', 'No. 1 in a market', 'fire', () => { if (!window.R26) return false; const m = R26.markets().find(x => { const t = R26.truthOf(x); return t.riv.length && t.riv.every(r => r.share < t.share); }); return m && 'Nobody sells more ' + (m.kind === 'fin' ? 'here' : BD[m.type].n.toLowerCase() + ' in ' + cityOf(m.city).name) + ' than you.'; }],
    ['abroad', 'First company abroad', 'globe', () => { const c = live().find(x => x.country !== S.country); return c && c.name + ' opened in ' + CO[c.country].name + '.'; }],
    ['tenm', 'Net worth of 10 million', 'coin', () => nw() >= K(10e6) && 'Your net worth passed ' + money(K(10e6)) + '.'],
    ['hundred', '100 people work for you', 'people', () => jobs() >= 100 && 'A hundred jobs. Families depend on you now.'],
    ['bank', 'Your own bank', 'bank', () => live().some(c => c.type === 'bank' && c.st === 'open') && 'You run a bank.'],
    ['listed', 'Listed on the stock exchange', 'invest', () => live().some(c => c.type === 'hold' && c.listed) && 'Anyone can now buy shares in your group.'],
    ['top10', 'Top 10 in your country', 'fire', () => window.R27 && R27.myRank && (() => { const r = R27.myRank('cc', 'rev'); return r && r.rank <= 10 && 'Only nine companies in ' + (CO[S.country] || CC()).name + ' sell more than you.'; })()],
    ['give', 'First gift to the city', 'house', () => window.R28 && R28.giveCount && R28.giveCount() > 0 && 'Your name is on something that is not a business.'],
    ['mgr10', 'A manager for ten years', 'tie', () => { const c = live().find(x => x.mgr && x.mgrW0 != null && S.week - x.mgrW0 >= 520); return c && S.npcs[c.mgr].name + ' has run ' + c.name + ' for ten years.'; }],
    ['hm', 'Net worth of 100 million', 'coin', () => nw() >= K(100e6) && 'Your net worth passed ' + money(K(100e6)) + '.'],
    ['bn', 'A billionaire', 'coin', () => nw() >= K(1e9) && 'Your net worth passed ' + money(K(1e9)) + '.']
  ];
  /* round 56: the wall in groups, and many more to collect. [id, name, icon, test, group] */
  const GRP = { cust: 'first', emp: 'first', profit: 'first', year: 'first', mgr: 'first', branch: 'first', div: 'first', acq: 'first', abroad: 'first', give: 'first', million: 'money', tenm: 'money', hm: 'money', bn: 'money', ten: 'people', hundred: 'people', mgr10: 'people', stars: 'market', no1: 'market', top10: 'market', bank: 'trades', listed: 'trades' };
  ACH.forEach(a => { a[4] = GRP[a[0]] || 'first'; });
  const ever = () => S.cos.filter(c => c.type !== 'hold');
  const types = () => new Set(ever().map(c => c.type)).size;
  const fams = () => new Set(ever().map(c => (BD[c.type] || {}).fam)).size;
  const ccs = () => new Set(live().map(c => c.country)).size;
  const openN = () => live().filter(c => c.type !== 'hold').length;
  const luxN = f => ((S.lux || []).filter(x => { const i = window.LUX47 && LUX47.LUXI[x.k]; return i && f(i, x); })).length;
  const no1N = memo('no1', () => { if (!window.R26) return 0; try { return R26.markets().filter(m => { const t = R26.truthOf(m); return t.riv.length && t.riv.every(r => r.share < t.share); }).length; } catch (e) { return 0; } });
  const rankCC = memo('rank', () => { try { const r = window.R27 && R27.myRank ? R27.myRank('cc', 'rev') : null; return r ? r.rank : 1e9; } catch (e) { return 1e9; } });
  const port = () => { const n = nwAll(); return (n.inv || 0) + (n.funds || 0) + (n.crypto || 0); };
  const yrs = () => { const w0 = Math.min.apply(null, S.cos.map(c => c.w0 == null ? 1e9 : c.w0)); return w0 < 1e9 ? (S.week - w0) / 52 : 0; };
  const awN = k => ((S.aw56 && S.aw56.won) || []).filter(w => !k || w.k === k).length;
  const frUnits = () => sumF(live(), c => c.fr && c.fr.units ? c.fr.units.length : 0);
  const chainMax = () => Math.max(0, ...(S.chains || []).map(ch => live().filter(c => c.chain === ch.id).length));
  const tenure = () => Math.max(0, ...live().map(c => Math.max(0, ...(c.staff || []).map(x => S.week - (x.w0 || S.week)))));
  const mgrs = () => live().filter(c => c.mgr && S.npcs[c.mgr]).length;
  const ladder = (pre, g, ic, list, test, txt) => list.forEach(x => {
    const a = [pre + x[0], x[1], ic, () => test(x[2]) && txt(x[2]), g];
    if (typeof x[1] === 'function') Object.defineProperty(a, 1, { get: x[1], configurable: true }); /* a title in your own currency */
    ACH.push(a);
  });
  /* money trophies count in your own currency, like the first-million ones (features/people/part_time_and_milestones.js):
     "5 million" is five million dollars in the US; yen count in hundreds of millions and won in billions */
  const unitL = () => ({ JPY: 100, KRW: 1000 }[(CO[S.country] || CC()).cur] || 1);
  const L = v => v * unitL() * fxr(CO[S.country] || CC());
  const words = v => { v *= unitL(); return v >= 1e9 ? (v / 1e9) + ' billion' : (v / 1e6) + ' million'; };
  const mlist = (L0, f) => L0.map(x => [x[0], () => f(words(x[1])), x[1]]);
  ladder('nw', 'money', 'coin', mlist([['5m', 5e6], ['50m', 50e6], ['500m', 500e6], ['5b', 5e9], ['10b', 1e10], ['50b', 5e10]], w => 'Net worth of ' + w), v => nw() >= L(v), v => 'Your net worth passed ' + money(L(v)) + '.');
  ladder('dv', 'money', 'coin', mlist([['1m', 1e6], ['10m', 1e7], ['100m', 1e8], ['1b', 1e9]], w => 'Dividends of ' + w), v => (S.stats.dividends || 0) >= L(v), v => 'Your companies have paid you ' + money(L(v)) + ' in dividends.');
  ladder('tx', 'money', 'tax', mlist([['1m', 1e6], ['10m', 1e7], ['100m', 1e8]], w => w.replace(/^1 /, 'A ') + ' in tax'), v => (S.stats.taxPaid || 0) >= L(v), v => 'You have paid ' + money(L(v)) + ' in tax. Schools and roads, partly yours.');
  ladder('pf', 'money', 'invest', mlist([['1m', 1e6], ['10m', 1e7], ['100m', 1e8]], w => 'A portfolio of ' + w), v => port() >= L(v), v => 'Your shares, funds and coins are worth ' + money(L(v)) + '.');
  ladder('jb', 'people', 'people', [['25', '25 people work for you', 25], ['50', '50 people work for you', 50], ['250', '250 people work for you', 250], ['500', '500 people work for you', 500], ['1k', 'A thousand jobs', 1000], ['5k', 'Five thousand jobs', 5000], ['10k', 'Ten thousand jobs', 10000]], v => jobs() >= v, v => v.toLocaleString('en-US').replace(/,/g, ' ') + ' people earn their living with you.');
  ladder('mg', 'people', 'tie', [['3', 'Three managers', 3], ['10', 'Ten managers', 10], ['25', 'Twenty-five managers', 25]], v => mgrs() >= v, v => v + ' companies are run by managers you hired.');
  ACH.push(['ten10', 'Ten years with you', 'people', () => tenure() >= 520 && 'Someone on your staff has worked with you for ten years.', 'people']);
  ACH.push(['hq5', 'A real main office', 'office', () => S.office && (S.office.staff || []).length >= 5 && 'Five people work at your main office.', 'people']);
  ACH.push(['team56', 'A management team', 'tie', () => live().some(c => c.team && c.team.ceo && Object.keys(c.team.heads || {}).length >= 2) && 'A company with a managing director and its own department heads.', 'people']);
  ladder('co', 'trades', 'biz', [['3', 'Three companies', 3], ['5', 'Five companies', 5], ['10', 'Ten companies', 10], ['25', 'Twenty-five companies', 25], ['50', 'Fifty companies', 50], ['100', 'A hundred companies', 100]], v => openN() >= v, v => v + ' companies open at the same time.');
  ladder('ty', 'trades', 'tool', [['5', 'Five trades', 5], ['10', 'Ten trades', 10], ['20', 'Twenty trades', 20], ['35', 'Thirty-five trades', 35], ['all', 'Every trade', 0]], v => types() >= (v || BD_ORDER.length), v => 'You have run ' + (v || BD_ORDER.length) + ' different kinds of business.');
  ACH.push(['fam', 'A bit of everything', 'globe', () => fams() >= 9 && 'You have owned a business in nine different kinds of trade.', 'trades']);
  ACH.push(['hold', 'A holding company', 'biz', () => live().some(c => c.type === 'hold') && 'Your companies now sit under a holding.', 'trades']);
  ladder('ch', 'trades', 'biz', [['3', 'A chain of three', 3], ['10', 'A chain of ten', 10], ['25', 'A chain of twenty-five', 25]], v => chainMax() >= v, v => 'One of your chains has ' + v + ' stores.');
  ladder('fr', 'trades', 'deal', [['1', 'First franchisee', 1], ['5', 'Five franchise units', 5], ['25', 'Twenty-five franchise units', 25], ['100', 'A hundred franchise units', 100]], v => frUnits() >= v, v => v + (v === 1 ? ' franchisee runs' : ' franchise units run') + ' under your name.');
  ACH.push(['rd', 'Something new', 'rocket', () => live().some(c => c.rd56 && c.rd56.done.length) && 'A company of yours developed something new that customers wanted.', 'trades']);
  ACH.push(['oil', 'Black gold', 'fire', () => live().some(c => c.type === 'oilgas' && c.st === 'open') && 'You produce oil and gas.', 'trades']);
  ACH.push(['club', 'A football club', 'fire', () => live().some(c => BD[c.type] && BD[c.type].fam === 'club') && 'You own a football club.', 'trades']);
  ladder('n1', 'market', 'fire', [['3', 'No. 1 in three markets', 3], ['10', 'No. 1 in ten markets', 10]], v => no1N() >= v, v => 'Nobody sells more than you in ' + v + ' markets.');
  ladder('rk', 'market', 'fire', [['50', 'Top 50 in the country', 50], ['3', 'Top 3 in the country', 3], ['1', 'The biggest in the country', 1]], v => rankCC() <= v, v => v === 1 ? 'No company in ' + (CO[S.country] || CC()).name + ' sells more than you.' : 'Your group is among the ' + v + ' biggest in ' + (CO[S.country] || CC()).name + '.');
  ACH.push(['st48', 'Loved by customers', 'star', () => live().some(c => (c.rvN || 0) >= 500 && ratingOf(c) >= 4.8) && 'A company with 4.8 stars from more than 500 reviews.', 'market']);
  ladder('cc', 'world', 'globe', [['3', 'Three countries', 3], ['5', 'Five countries', 5], ['10', 'Ten countries', 10], ['15', 'Every country', 15]], v => ccs() >= v, v => 'You do business in ' + v + ' countries.');
  ACH.push(['abr50', 'More abroad than at home', 'globe', () => { try { return R27.F.abroadShare() >= 0.5 && 'Half your sales now come from abroad.'; } catch (e) { return false; } }, 'world']);
  ACH.push(['lx1', 'Something beautiful', 'star', () => luxN(() => 1) >= 1 && 'Your first piece from Aurum.', 'life']);
  ACH.push(['lxc5', 'A car collection', 'truck', () => luxN(i => i.cat === 'cars') >= 5 && 'Five cars in the garage.', 'life']);
  ACH.push(['lxj', 'Wheels up', 'rocket', () => luxN(i => i.cat === 'jets') >= 1 && 'You have your own jet.', 'life']);
  ACH.push(['lxy', 'On the water', 'globe', () => luxN(i => i.cat === 'yachts') >= 1 && 'You have a yacht.', 'life']);
  ACH.push(['lxe', 'Land of your own', 'house', () => luxN(i => i.cat === 'estates') >= 1 && 'You own an estate.', 'life']);
  ACH.push(['lxi', 'An island', 'globe', () => luxN((i, x) => x.k === 'e2') >= 1 && 'A whole island is yours.', 'life']);
  ACH.push(['lxm', 'On the museum wall', 'grad', () => luxN((i, x) => x.use === 'museum') >= 1 && 'A work from your collection hangs in a museum.', 'life']);
  ACH.push(['lxw', 'Paid for itself', 'coin', () => luxN((i, x) => x.use === 'charter' || x.use === 'rent') >= 1 && 'Something you own earns its keep.', 'life']);
  ACH.push(['su1', 'Founder', 'rocket', () => (S.founded || []).length >= 1 && 'You founded a startup.', 'life']);
  ACH.push(['sux', 'An exit', 'rocket', () => ((S.founder && S.founder.exits) || 0) >= 1 && 'You sold a startup you founded.', 'life']);
  ACH.push(['pe1', 'Private equity', 'invest', () => S.pe56 && S.pe56.mine.length >= 1 && 'You committed money to a private equity fund.', 'life']);
  ACH.push(['pe2', 'Twice your money', 'invest', () => S.pe56 && S.pe56.mine.some(f => f.paid && f.dist >= f.paid * 2) && 'A fund paid you back twice what you put in.', 'life']);
  ladder('yr', 'legacy', 'star', [['5', 'Five years in business', 5], ['10', 'Ten years in business', 10], ['25', 'Twenty-five years', 25], ['50', 'Half a century', 50]], v => yrs() >= v, v => v + ' years since you started your first company.');
  ladder('aw', 'legacy', 'star', [['1', 'An award', 1], ['5', 'Five awards', 5], ['20', 'Twenty awards', 20]], v => awN() >= v, v => 'You have won ' + v + (v === 1 ? ' business award.' : ' business awards.'));
  ACH.push(['boty', 'Business of the year', 'star', () => awN('boty') >= 1 && 'One of your companies was named business of the year.', 'legacy']);
  ACH.push(['g10', 'A city remembers', 'house', () => window.R28 && R28.giveCount && R28.giveCount() >= 10 && 'Ten gifts to the places you work in.', 'legacy']);
  R28.ACH = ACH;
  R28.GRPN = { first: 'Firsts', money: 'Money', people: 'People', trades: 'Companies and trades', market: 'Markets', world: 'The world', life: 'Life and investments', legacy: 'Legacy' };
  const A = () => S.ach28 = S.ach28 || {};
  function checkAch(silent) {
    const a = A();
    /* an older save: what you already reached goes on the wall without a party */
    let first = !S.ach28i && S.week > 8;
    S.ach28i = 1;
    /* round 56 added many more: what an older game already reached goes up quietly too */
    if (!S.ach56i) { if (S.week > 8) first = true; S.ach56i = 1; }
    M = {};
    try { ACH.forEach(x => {
      if (a[x[0]]) return;
      let r = false;
      try { r = x[3](); } catch (e) { }
      if (!r) return;
      a[x[0]] = { w: S.week, t: r, old: first || silent ? 1 : 0 };
      if (!first && !silent) { S.cel28q = S.cel28q || []; S.cel28q.push(x[0]); }
    }); } finally { M = null; }
  }
  R28.checkAch = checkAch;
  /* the full-screen moment */
  function confetti() {
    const C = ['#e7b65b', '#c4a47c', '#93b8a0', '#7aa5d6', '#e5534b', '#f2e3c6'];
    let h = '';
    for (let i = 0; i < 46; i++) h += '<i style="left:' + Math.round(Math.random() * 100) + '%;background:' + C[i % C.length] + ';animation-delay:' + (Math.random() * 0.9).toFixed(2) + 's;animation-duration:' + (1.8 + Math.random() * 1.6).toFixed(2) + 's;transform:rotate(' + Math.round(Math.random() * 360) + 'deg)"></i>';
    return '<div class="conf28">' + h + '</div>';
  }
  R28.confetti = confetti;
  function celHtml(id) {
    const x = ACH.find(a => a[0] === id), r = A()[id];
    if (!x || !r) return '';
    return confetti() + '<div class="cel28b"><div class="cel28i">' + svg(x[2], 40) + '</div><small>' + esc(dateStr(r.w)) + '</small><h2>' + esc(x[1]) + '</h2><p class="lead">' + esc(r.t) + '</p>' + (window.R31 && R31.celExtra ? R31.celExtra(id, r) : '') + '<div class="btnrow col">' + btn('Nice!', 'cel28ok', undefined, 'primary wide') + btn('See the trophy wall', 'cel28wall', undefined, 'ghost wide') + '</div></div>';
  }
  R28.celHtml = celHtml;
  /* V.1.0.0: after a good moment, the app may ask for a rating (Apple's own small prompt, which Apple shows at most
     three times a year). Only after two months of play and a few trophies, and at most every four months. */
  const RK = U.KEY + ':rate';
  function askRate() {
    if (!window.LedgerApp || !LedgerApp.review || !S || S.week < 8 || Object.keys(A()).length < 4) return;
    let t = 0; try { t = +localStorage.getItem(RK) || 0; } catch (e) { }
    if (Date.now() - t < 120 * 864e5) return;
    try { localStorage.setItem(RK, String(Date.now())); } catch (e) { }
    setTimeout(() => LedgerApp.review(), 600);
  }
  ACT.cel28ok = () => { ui.sheet = null; render(); askRate(); };
  ACT.cel28wall = () => { ui.sheet = null; ACT.go({ n: 'trophies28', p: {} }); };
  /* show queued moments when nothing else is on screen */
  setInterval(() => {
    try {
      if (!S || S.over || !S.cel28q || !S.cel28q.length || ui.sheet || ui.dayBusy || ui.untl || ui.repLock || (ui.view && ui.view.n === 'weekreport')) return;
      const id = S.cel28q.shift();
      const h = celHtml(id);
      if (h) { ui.sheet = { html: h, cls: 'cel28' }; render(); }
    } catch (e) { }
  }, 600);

  /* ---------- the trophy wall ---------- */
  V.titles.trophies28 = 'Trophy wall';
  V.heads = V.heads || {};
  V.heads.trophies28 = () => { const n = Object.keys(A()).length; return { t: 'Trophy wall', sub: n + ' of ' + ACH.length + ' firsts', right: pillp(n + ' / ' + ACH.length, 'amb') }; };
  V.trophies28 = function () {
    const a = A();
    const tile = x => { const r = a[x[0]]; return '<button class="tile28' + (r ? ' on' : '') + '" data-a="' + (r ? 'tw28' : 'none') + '" data-p="' + P({ id: x[0] }) + '"><span class="ti">' + svg(x[2], 26) + '</span><b>' + esc(x[1]) + '</b><small>' + (r ? (r.old ? 'Before the wall' : dateStr(r.w)) : 'Not yet') + '</small></button>'; };
    /* round 56: in groups, each with how many you have */
    let h = Object.keys(R28.GRPN).map(g => { const L = ACH.filter(x => x[4] === g); if (!L.length) return ''; const n = L.filter(x => a[x[0]]).length; return '<div class="tw56h"><h2 class="sec">' + esc(R28.GRPN[g]) + '</h2><small>' + n + ' of ' + L.length + '</small></div><div class="tw28">' + L.map(tile).join('') + '</div>'; }).join('');
    const hof = S.hof28 || [];
    if (hof.length) h += '<h2 class="sec">Hall of fame</h2><div class="lrows">' + hof.slice(0, 12).map(x => '<div class="lrow"><span class="av">' + esc(String(x.n).split(' ').map(w => w[0]).join('').slice(0, 2)) + '</span><span class="ctext"><b>' + esc(x.n) + '</b><small>' + esc(x.t) + '</small></span></div>').join('') + '</div>';
    return h;
  };
  ACT.tw28 = p => { const h = celHtml(p.id); if (h) { ui.sheet = { html: h.replace(confetti(), ''), cls: 'cel28 calm28' }; render(); } };
  ACT.none = () => { };

  /* ---------- storefront pictures ---------- */
  const PAL = { venue: ['#7a4b2a', '#e7b65b'], retail: ['#2f4b6e', '#7aa5d6'], svc: ['#2f5a48', '#93b8a0'], prod: ['#6b3a2e', '#d08a6a'], logi: ['#4a4f57', '#c4a47c'], project: ['#5c5240', '#e7b65b'], fin: ['#3b3f47', '#d9d4c7'], energy: ['#2c4a3e', '#93b8a0'], rent: ['#4b4458', '#c9b8e0'], club: ['#2d4a2a', '#e5e5e5'], hold: ['#3b3f47', '#c4a47c'] };
  function stageOf(co) {
    const bd = BD[co.type];
    if (co.st === 'setup' || co.st === 'closed') return 0;
    const sold = (co.uh || []).slice(-4).reduce((t, x) => t + x, 0) + (co.lastW ? co.lastW.units || 0 : 0);
    if (sold <= 0) return 0;
    const ref = (bd.Dc || 1) * bd.ticket * 52 * cityOf(co.city).dem;
    const rev = window.R26 && R26.annRev ? R26.annRev(co) : (co.lastW ? co.lastW.rev * 52 : 0);
    const sites = live().filter(c => c.type === co.type && c.st === 'open').length;
    if ((co.size || 1) >= 1.4 || rev >= ref * 1.1 || sites >= 3 || (co.chain)) return 3;
    const u = co.lastW ? co.lastW.util || 0 : 0;
    return u >= 0.82 ? 2 : 1;
  }
  R28.stageOf = stageOf;
  const STN = ['An empty unit', 'A small business', 'Busy, with a queue', 'A flagship'];
  function person(x, y, c, s) { s = s || 1; return '<g transform="translate(' + x + ' ' + y + ') scale(' + s + ')"><circle cx="0" cy="-17" r="4" fill="' + c + '"/><rect x="-4.5" y="-12" width="9" height="13" rx="4" fill="' + c + '"/></g>'; }
  function famIcon(f, x, y, c) {
    if (f === 'venue') return '<g fill="none" stroke="' + c + '" stroke-width="2"><path d="M' + (x - 7) + ' ' + (y - 4) + 'h12v6a6 6 0 0 1-12 0z"/><path d="M' + (x + 5) + ' ' + (y - 2) + 'h3a2 2 0 0 1 0 5h-3"/></g>';
    if (f === 'retail') return '<g fill="none" stroke="' + c + '" stroke-width="2"><rect x="' + (x - 7) + '" y="' + (y - 5) + '" width="14" height="12" rx="2"/><path d="M' + (x - 3) + ' ' + (y - 5) + 'v-2a3 3 0 0 1 6 0v2"/></g>';
    if (f === 'svc') return '<g fill="none" stroke="' + c + '" stroke-width="2"><rect x="' + (x - 8) + '" y="' + (y - 3) + '" width="16" height="10" rx="2"/><path d="M' + (x - 3) + ' ' + (y - 3) + 'v-3h6v3"/></g>';
    if (f === 'fin') return '<g fill="' + c + '"><path d="M' + (x - 9) + ' ' + (y - 3) + 'l9-6 9 6z"/><rect x="' + (x - 7) + '" y="' + (y - 2) + '" width="2.5" height="9"/><rect x="' + (x - 1.2) + '" y="' + (y - 2) + '" width="2.5" height="9"/><rect x="' + (x + 4.5) + '" y="' + (y - 2) + '" width="2.5" height="9"/></g>';
    return '<circle cx="' + x + '" cy="' + y + '" r="5" fill="' + c + '"/>';
  }
  function storeSvg(co) {
    const bd = BD[co.type], f = bd.fam, pal = PAL[f] || PAL.svc, st = stageOf(co) || (co.st === 'open' ? 1 : 0);
    const u = co.lastW ? co.lastW.util || 0 : 0;
    const W = 340, H = 150, gy = 128;
    let s = '<svg class="shop28" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="' + esc(STN[st]) + '"><defs><linearGradient id="sky' + co.id + '" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1d2026"/><stop offset="1" stop-color="#15171b"/></linearGradient></defs><rect width="' + W + '" height="' + H + '" fill="url(#sky' + co.id + ')"/>';
    /* neighbours */
    s += '<rect x="0" y="' + (gy - 70) + '" width="60" height="70" fill="#22252b"/><rect x="280" y="' + (gy - 84) + '" width="60" height="84" fill="#22252b"/>';
    for (let i = 0; i < 3; i++) s += '<rect x="' + (10 + i * 16) + '" y="' + (gy - 58) + '" width="8" height="10" fill="#2c3037"/><rect x="' + (290 + i * 16) + '" y="' + (gy - 70) + '" width="8" height="10" fill="#2c3037"/>';
    const big = st === 3, bx = big ? 66 : 92, bw = big ? 208 : 156, bh = big ? 104 : 74, by = gy - bh;
    /* the building */
    s += '<rect x="' + bx + '" y="' + by + '" width="' + bw + '" height="' + bh + '" rx="3" fill="' + (st === 0 ? '#2a2d33' : pal[0]) + '"/>';
    if (big) { for (let i = 0; i < 5; i++) s += '<rect x="' + (bx + 14 + i * 38) + '" y="' + (by + 8) + '" width="24" height="16" rx="2" fill="#f2d79a" opacity=".85"/>'; }
    if (f === 'prod' && st > 0) s += '<rect x="' + (bx + bw - 34) + '" y="' + (by - 22) + '" width="12" height="22" fill="' + pal[0] + '"/><circle cx="' + (bx + bw - 28) + '" cy="' + (by - 30) + '" r="6" fill="#3a3d44" opacity=".8"/><circle cx="' + (bx + bw - 20) + '" cy="' + (by - 40) + '" r="8" fill="#3a3d44" opacity=".6"/>';
    if (f === 'project' && st > 0) s += '<path d="M' + (bx + bw + 6) + ' ' + gy + 'V' + (by - 26) + 'h-60" stroke="' + pal[1] + '" stroke-width="3" fill="none"/><path d="M' + (bx + bw - 44) + ' ' + (by - 26) + 'v16" stroke="' + pal[1] + '" stroke-width="1.5"/>';
    if (f === 'energy' && st > 0) s += '<path d="M' + (bx + bw + 14) + ' ' + gy + 'V' + (by - 20) + '" stroke="#cfd3d8" stroke-width="2.5"/><path d="M' + (bx + bw + 14) + ' ' + (by - 20) + 'l-16 -10M' + (bx + bw + 14) + ' ' + (by - 20) + 'l16 -10M' + (bx + bw + 14) + ' ' + (by - 20) + 'v18" stroke="#cfd3d8" stroke-width="2"/>';
    /* the sign */
    const sy = big ? by + 30 : by + 6, sw = bw - 24;
    s += '<rect x="' + (bx + 12) + '" y="' + sy + '" width="' + sw + '" height="20" rx="3" fill="' + (st === 0 ? '#34373e' : '#141518') + '"/>';
    const nm = st === 0 ? (co.st === 'setup' ? 'Opening soon' : 'Closed') : co.name;
    s += '<text x="' + (bx + bw / 2) + '" y="' + (sy + 14) + '" text-anchor="middle" font-size="11.5" font-weight="700" fill="' + (st === 0 ? '#8b8f97' : pal[1]) + '" font-family="system-ui, sans-serif">' + esc(nm.length > 26 ? nm.slice(0, 25) + '…' : nm) + '</text>';
    /* awning */
    if (st >= 2) { const ay = sy + 22, n = Math.floor((bw - 8) / 14); for (let i = 0; i < n; i++) s += '<path d="M' + (bx + 4 + i * 14) + ' ' + ay + 'h14l-2 10h-10z" fill="' + (i % 2 ? pal[1] : '#f2e3c6') + '" opacity=".9"/>'; }
    /* windows and door */
    const wy = big ? by + 62 : by + 34, wh = big ? 34 : 30;
    if (st === 0) {
      s += '<rect x="' + (bx + 12) + '" y="' + wy + '" width="' + (bw - 24) + '" height="' + wh + '" fill="#3a3d44"/>';
      for (let i = 0; i < 6; i++) s += '<line x1="' + (bx + 12) + '" x2="' + (bx + bw - 12) + '" y1="' + (wy + 4 + i * 5) + '" y2="' + (wy + 4 + i * 5) + '" stroke="#2a2d33" stroke-width="1.5"/>';
      s += '<rect x="' + (bx + bw / 2 - 16) + '" y="' + (wy + 6) + '" width="32" height="14" fill="#e6e1d6"/><text x="' + (bx + bw / 2) + '" y="' + (wy + 16) + '" text-anchor="middle" font-size="6.5" fill="#333" font-family="system-ui">' + (co.st === 'setup' ? 'SOON' : 'TO LET') + '</text>';
    } else {
      const dw = 22, dx = bx + bw / 2 - dw / 2;
      s += '<rect x="' + (bx + 12) + '" y="' + wy + '" width="' + (dx - bx - 18) + '" height="' + wh + '" rx="2" fill="#f2d79a" opacity="' + (0.55 + 0.4 * Math.min(1, u)) + '"/>';
      s += '<rect x="' + (dx + dw + 6) + '" y="' + wy + '" width="' + (bx + bw - 12 - dx - dw - 6) + '" height="' + wh + '" rx="2" fill="#f2d79a" opacity="' + (0.55 + 0.4 * Math.min(1, u)) + '"/>';
      s += '<rect x="' + dx + '" y="' + (gy - 36) + '" width="' + dw + '" height="36" fill="#141518"/><rect x="' + (dx + 2) + '" y="' + (gy - 34) + '" width="' + (dw - 4) + '" height="32" fill="' + pal[1] + '" opacity=".35"/>';
      s += famIcon(f, bx + 30, wy + wh / 2, '#141518');
    }
    /* street */
    s += '<rect x="0" y="' + gy + '" width="' + W + '" height="' + (H - gy) + '" fill="#191b1f"/><rect x="0" y="' + gy + '" width="' + W + '" height="2" fill="#2a2d33"/>';
    if (f === 'logi' && st > 0) s += '<g transform="translate(' + (bx + bw + 4) + ' ' + (gy - 20) + ')"><rect width="34" height="16" rx="2" fill="' + pal[1] + '"/><rect x="34" y="5" width="12" height="11" rx="2" fill="' + pal[1] + '"/><circle cx="8" cy="18" r="3.5" fill="#111"/><circle cx="38" cy="18" r="3.5" fill="#111"/></g>';
    /* people: more when busy, a queue when full */
    const C = ['#c4a47c', '#93b8a0', '#7aa5d6', '#d08a6a', '#e6e1d6', '#a99bd0'];
    const n = st === 0 ? 0 : Math.min(9, Math.round(Math.min(1.4, u) * (st >= 2 ? 7 : 4)));
    for (let i = 0; i < n; i++) { const qx = bx + bw / 2 - 30 - i * 13; s += person(qx < 6 ? bx + bw / 2 + 30 + (i - 4) * 13 : qx, gy + 14, C[i % C.length], 0.95); }
    if (big) s += '<rect x="' + (bx - 8) + '" y="' + (gy - 14) + '" width="8" height="14" rx="3" fill="#2f5a48"/><rect x="' + (bx + bw) + '" y="' + (gy - 14) + '" width="8" height="14" rx="3" fill="#2f5a48"/>';
    return s + '</svg>';
  }
  /* round 37: the picture follows the premises the company really has */
  function premOf(co) {
    const bd = BD[co.type], k0 = (bd.prem || ['none'])[0];
    const P = co.prem;
    const kind = P && P.m2 ? P.kind : P && P.kind === 'home' ? 'home' : k0;
    return { kind, m2: P && P.m2 ? P.m2 : 0, typ: (bd.prem || [0, 0])[1] || 0 };
  }
  R28.premOf = premOf;
  const SCENE = { home: 'home', none: 'mobile', office: 'office', warehouse: 'hall', industrial: 'hall', yard: 'yard', hotel: 'tower' };
  const sceneOf = co => SCENE[premOf(co).kind] || 'store';
  function frame(co, inner) {
    return '<svg class="shop28" viewBox="0 0 340 150" role="img" aria-label="' + esc(co.name) + '"><defs><linearGradient id="sky' + co.id + '" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1d2026"/><stop offset="1" stop-color="#15171b"/></linearGradient></defs><rect width="340" height="150" fill="url(#sky' + co.id + ')"/>' + inner + '</svg>';
  }
  const street = (W, H, gy) => '<rect x="0" y="' + gy + '" width="' + W + '" height="' + (H - gy) + '" fill="#191b1f"/><rect x="0" y="' + gy + '" width="' + W + '" height="2" fill="#2a2d33"/>';
  const label = (x, y, w, txt, col, bg) => '<rect x="' + (x - w / 2) + '" y="' + y + '" width="' + w + '" height="16" rx="3" fill="' + (bg || '#141518') + '"/><text x="' + x + '" y="' + (y + 11.5) + '" text-anchor="middle" font-size="9.5" font-weight="700" fill="' + col + '" font-family="system-ui, sans-serif">' + esc(txt.length > 30 ? txt.slice(0, 29) + '…' : txt) + '</text>';
  function van(x, y, col, nm, kind) {
    if (kind === 'car') return '<g transform="translate(' + x + ' ' + y + ')"><path d="M0 14v-6l8-7h22l8 7v6z" fill="' + col + '"/><rect x="10" y="3" width="18" height="6" rx="1" fill="#2a2d33"/><rect x="15" y="-3" width="9" height="4" rx="1" fill="#f2d79a"/><circle cx="9" cy="15" r="3.5" fill="#111"/><circle cx="30" cy="15" r="3.5" fill="#111"/></g>';
    return '<g transform="translate(' + x + ' ' + y + ')"><rect x="0" y="0" width="40" height="18" rx="3" fill="' + col + '"/><path d="M40 4h7l5 6v8h-12z" fill="' + col + '"/><rect x="42" y="6" width="5" height="5" fill="#2a2d33"/><circle cx="10" cy="19" r="3.8" fill="#111"/><circle cx="43" cy="19" r="3.8" fill="#111"/>' + (nm ? '<text x="20" y="12" text-anchor="middle" font-size="5.6" font-weight="700" fill="#141518" font-family="system-ui">' + esc(nm.split(' ')[0].slice(0, 12)) + '</text>' : '') + '</g>';
  }
  const lit = (u, i, n) => i < Math.max(1, Math.round(n * Math.min(1, 0.25 + u))) ? '#f2d79a' : '#3a3d44';
  function shopSvg(co) {
    const sc = sceneOf(co);
    if (sc === 'store') return storeSvg(co);
    const bd = BD[co.type], pal = PAL[bd.fam] || PAL.svc, st = stageOf(co), on = co.st === 'open';
    const u = co.lastW ? co.lastW.util || 0 : 0, gy = 128, nm = on ? co.name : co.st === 'setup' ? 'Opening soon' : 'Closed';
    const nv = Math.min(3, (co.veh || []).length), heads = (co.staff || []).length + (co.mgr ? 1 : 0) + (co.ohrs > 0 && !co.mgr ? 1 : 0);
    const pm = premOf(co);
    let s = '<rect x="0" y="' + (gy - 62) + '" width="48" height="62" fill="#22252b"/><rect x="292" y="' + (gy - 78) + '" width="48" height="78" fill="#22252b"/>';
    if (sc === 'home') {
      /* a house: the company is run from the kitchen table */
      s += '<rect x="96" y="' + (gy - 58) + '" width="112" height="58" fill="#3b3530"/><path d="M88 ' + (gy - 56) + 'L152 ' + (gy - 96) + 'L216 ' + (gy - 56) + 'z" fill="#4a3f38"/><rect x="186" y="' + (gy - 92) + '" width="10" height="20" fill="#4a3f38"/>';
      s += '<rect x="108" y="' + (gy - 46) + '" width="26" height="20" rx="2" fill="' + (on ? '#f2d79a' : '#3a3d44') + '" opacity="' + (on ? 0.6 + 0.35 * Math.min(1, u) : 1) + '"/><rect x="170" y="' + (gy - 46) + '" width="26" height="20" rx="2" fill="#3a3d44"/><rect x="142" y="' + (gy - 34) + '" width="20" height="34" fill="#141518"/>';
      if (on) s += '<rect x="113" y="' + (gy - 33) + '" width="14" height="7" rx="1" fill="#141518"/><rect x="114" y="' + (gy - 32) + '" width="12" height="5" fill="' + pal[1] + '" opacity=".8"/>';
      s += '<rect x="60" y="' + (gy - 22) + '" width="3" height="22" fill="#555"/>' + label(62, gy - 38, 74, nm, on ? pal[1] : '#8b8f97');
      s += street(340, 150, gy);
      for (let i = 0; i < nv; i++) s += van(214 + i * 4, gy - 20 - i * 0, pal[1], i === 0 ? co.name : '', bd.fam === 'svc' && /taxi/.test(co.type) ? 'car' : 'van');
    } else if (sc === 'mobile') {
      /* no premises: the vehicle is the business */
      s += '<rect x="60" y="' + (gy - 50) + '" width="220" height="50" fill="#20232a"/>' + street(340, 150, gy);
      const n = Math.max(1, nv);
      for (let i = 0; i < n; i++) s += '<g transform="translate(' + (70 + i * 70) + ' ' + (gy - 40) + ') scale(1.5)">' + van(0, 0, on ? pal[1] : '#555', i === 0 ? co.name : '', /taxi/.test(co.type) ? 'car' : 'van').replace(/^<g transform="translate\(0 0\)">/, '<g>') + '</g>';
      s += label(170, gy - 72, 160, nm, on ? pal[1] : '#8b8f97');
    } else if (sc === 'office') {
      /* an office block: floors grow with the team, lit windows show how busy it is */
      const floors = Math.max(2, Math.min(6, Math.ceil(Math.max(heads, pm.m2 / 25) / 4)));
      const fh = 14, bh = floors * fh + 18, bw = pm.m2 >= 300 ? 170 : 140, bx = 170 - bw / 2, by = gy - bh;
      s += '<rect x="' + bx + '" y="' + by + '" width="' + bw + '" height="' + bh + '" rx="2" fill="#2f3a48"/>';
      const cols = Math.floor((bw - 16) / 18);
      for (let f = 0; f < floors; f++) for (let c = 0; c < cols; c++) s += '<rect x="' + (bx + 10 + c * 18) + '" y="' + (by + 18 + f * fh) + '" width="12" height="8" fill="' + (on ? lit(u, (f * cols + c) % (cols * floors), cols * floors) : '#3a3d44') + '" opacity=".85"/>';
      s += label(170, by - 2, Math.min(bw, 150), nm, on ? pal[1] : '#8b8f97', '#141518');
      s += '<rect x="160" y="' + (gy - 16) + '" width="20" height="16" fill="#141518"/>' + street(340, 150, gy);
      for (let i = 0; i < Math.min(3, heads > 2 ? 2 : 1) && on; i++) s += person(140 - i * 14, gy + 14, ['#c4a47c', '#93b8a0', '#7aa5d6'][i], 0.95);
      for (let i = 0; i < nv; i++) s += van(232 + i * 8, gy - 20, pal[1], i === 0 ? co.name : '');
    } else if (sc === 'hall') {
      /* a workshop or warehouse: roller doors, trucks at the ramp */
      const bw = pm.m2 >= 800 ? 240 : 200, bx = 170 - bw / 2, bh = 64, by = gy - bh;
      s += '<rect x="' + bx + '" y="' + by + '" width="' + bw + '" height="' + bh + '" fill="#3c4048"/><path d="M' + bx + ' ' + by + 'l' + bw / 2 + ' -14l' + bw / 2 + ' 14z" fill="#454a53"/>';
      const doors = bw >= 240 ? 3 : 2;
      for (let i = 0; i < doors; i++) { const dx = bx + 16 + i * ((bw - 32) / doors); s += '<rect x="' + dx + '" y="' + (gy - 36) + '" width="' + ((bw - 32) / doors - 12) + '" height="36" fill="' + (on && i < Math.max(1, Math.round(doors * Math.min(1, u + 0.2))) ? '#5b5f68' : '#2a2d33') + '"/>'; for (let k = 0; k < 6; k++) s += '<line x1="' + dx + '" x2="' + (dx + (bw - 32) / doors - 12) + '" y1="' + (gy - 32 + k * 6) + '" y2="' + (gy - 32 + k * 6) + '" stroke="#2a2d33" stroke-width="1"/>'; }
      if (bd.fam === 'prod' && on) s += '<rect x="' + (bx + bw - 30) + '" y="' + (by - 34) + '" width="10" height="24" fill="#3c4048"/><circle cx="' + (bx + bw - 25) + '" cy="' + (by - 40) + '" r="6" fill="#3a3d44" opacity=".8"/>';
      s += label(170, by + 6, Math.min(bw - 20, 170), nm, on ? pal[1] : '#8b8f97');
      s += street(340, 150, gy);
      for (let i = 0; i < nv; i++) s += van(bx + bw - 60 - i * 58, gy - 8, pal[1], i === 0 ? co.name : '');
    } else if (sc === 'yard') {
      /* a sales yard or lot: a cabin, a fence, what is for sale */
      s += street(340, 150, gy) + '<rect x="40" y="' + (gy - 40) + '" width="70" height="40" fill="#3b3f47"/><rect x="50" y="' + (gy - 30) + '" width="22" height="14" fill="' + (on ? '#f2d79a' : '#3a3d44') + '" opacity=".8"/>' + label(75, gy - 58, 96, nm, on ? pal[1] : '#8b8f97');
      for (let x = 120; x < 330; x += 10) s += '<rect x="' + x + '" y="' + (gy - 14) + '" width="2" height="14" fill="#555a63"/>';
      s += '<rect x="120" y="' + (gy - 12) + '" width="210" height="1.5" fill="#555a63"/>';
      const n = on ? Math.max(1, Math.min(5, Math.round(2 + u * 3))) : 0;
      for (let i = 0; i < n; i++) s += van(130 + i * 40, gy - 30, ['#7aa5d6', '#d08a6a', '#93b8a0', '#e6e1d6', '#c4a47c'][i], '', 'car');
    } else {
      /* a tall building: hotel, casino, head office */
      const bw = 110, bh = 112, bx = 115, by = gy - bh;
      s += '<rect x="' + bx + '" y="' + by + '" width="' + bw + '" height="' + bh + '" fill="#3a3448"/>';
      for (let f = 0; f < 7; f++) for (let c = 0; c < 5; c++) s += '<rect x="' + (bx + 10 + c * 19) + '" y="' + (by + 22 + f * 12) + '" width="10" height="7" fill="' + (on ? lit(u, f * 5 + c, 35) : '#3a3d44') + '" opacity=".85"/>';
      s += label(170, by + 3, 104, nm, on ? pal[1] : '#8b8f97') + street(340, 150, gy) + '<rect x="160" y="' + (gy - 14) + '" width="20" height="14" fill="#141518"/>';
      for (let i = 0; i < Math.min(5, Math.round(u * 6)) && on; i++) s += person(132 - i * 13, gy + 14, ['#c4a47c', '#93b8a0', '#7aa5d6', '#d08a6a', '#e6e1d6'][i], 0.95);
    }
    return frame(co, s);
  }
  R28.shopSvg = shopSvg;
  R28.sceneOf = sceneOf;
  /* the storefront at the top of a company's overview (ui/company/view.js CT.ov) */
  R28.shopCard = co => {
    try {
      if (!co || co.type === 'hold') return '';
      const st = stageOf(co), u = co.lastW ? co.lastW.util || 0 : 0;
      const sc = sceneOf(co), pm = premOf(co), P0 = (typeof PREM !== 'undefined' && PREM[pm.kind]) || ['Premises'];
      const where = sc === 'home' ? 'Run from home' : sc === 'mobile' ? 'On the road' : P0[0].replace(/ \/.*$/, '') + (pm.m2 ? ' · ' + pm.m2 + ' m²' : '');
      const busy = st === 0 ? (co.st === 'setup' ? 'Getting ready to open' : 'Quiet for now') : u >= 0.82 ? (sc === 'store' ? 'Busy: customers queue at the door' : 'Busy: fully booked most days') : u >= 0.4 ? 'Steady work' : 'Finding its customers';
      const ph = (sc === 'office' || sc === 'hall') && window.photoFor ? photoFor(pm.kind, pm.m2) : '';
      return '<div class="card shopc28">' + (ph ? '<div class="ph28">' + shopSvg(co) + photoTag(ph) + '</div>' : shopSvg(co)) + '<div class="bhead"><small>' + esc(busy) + '</small>' + pillp(esc(where), st === 3 ? 'amb' : st === 2 ? 'grn' : '') + '</div></div>';
    } catch (e) { console.error(e); return ''; }
  };

  /* ---------- a livelier day ---------- */
  addStep('day.after', 20, 'the day card notes', (d) => { dayNotes(d); });
  function dayNotes(d) {
    if (ui.untl) return;
    const L = [];
    let tot = 0;
    S.cos.forEach(co => {
      if (co.st !== 'open' || !co.dl || co.dl.w !== S.week) return;
      const x = co.dl.days[d];
      if (!x) return;
      tot += x.r || 0;
      if (x.u > 0) {
        const bd = BD[co.type], unit = String(bd.unit || 'customers').replace(/ sold$/, '');
        L.push({ co, u: x.u, r: x.r, t: '+' + (x.u >= 10 ? Math.round(x.u) : Math.round(x.u * 10) / 10) + ' ' + unitPl(unit, x.u) });
        co.best28 = co.best28 || 0;
        /* a best day ever is a real jump: 10% above the record (records still count every day) */
        if (x.r > co.best28 * 1.1 && co.best28 > 0 && S.week - (co.wOpen || co.w0 || 0) > 8) { L[L.length - 1].best = 1; }
        if (x.r > co.best28) co.best28 = x.r;
        const cap = co.dl.cap || 0;
        if (cap > 0 && x.u >= cap / (co.dl.wd || 7) * 0.98) L[L.length - 1].full = 1;
      }
    });
    /* only the special ones: a best day ever or fully booked, each company at most once a fortnight. An ordinary
       good day is not news, however big the company, so the card does not show every day */
    const now = S.week * 7 + d;
    S.fb34 = S.fb34 || {};
    const notes = L.filter(x => (x.best || x.full) && !(S.fb34[x.co.id] != null && now - S.fb34[x.co.id] < 14)).sort((a, b) => (b.best || 0) - (a.best || 0) || b.r - a.r).slice(0, 3).map(x => {
      S.fb34[x.co.id] = now;
      return [x.t, x.co.name + (x.best ? ' · best day ever!' : ' · fully booked'), x.r];
    });
    /* round 41: review notes come from the real reviews written today */
    ui.day28 = { k: S.week * 7 + d, tot: Math.round(tot), notes, at: Date.now() };
  }
  addStep('V.home:2', 30, 'moments_and_trophies V.home', (h) => {
    try {
      const D = ui.day28;
      if (!D || ui.untl || Date.now() - D.at > 60000 || !D.notes.length) return h;
      const card = '<div class="day28"><div class="bhead"><span>Today</span><b class="cnt28" data-to="' + D.tot + '">' + mshort(D.tot) + '</b></div>' + D.notes.map((x, i) => '<div class="dl28" style="animation-delay:' + (0.15 + i * 0.12).toFixed(2) + 's"><b>' + esc(x[0]) + '</b><span>' + esc(x[1]) + '</span>' + (x[2] ? '<small>' + mshort(x[2]) + '</small>' : '') + '</div>').join('') + '</div>';
      const i = h.indexOf('<div class="advbar">');
      return i > 0 ? h.slice(0, i) + card + h.slice(i) : h;
    } catch (e) { return h; }
  });
  /* numbers count up when they appear */
  new MutationObserver(() => {
    document.querySelectorAll('.cnt28:not([data-done])').forEach(el => {
      el.setAttribute('data-done', '1');
      const to = +el.getAttribute('data-to') || 0, t0 = performance.now(), dur = 700;
      const step = t => { const k = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - k, 3); el.textContent = mshort(Math.round(to * e)); if (k < 1) requestAnimationFrame(step); };
      requestAnimationFrame(step);
    });
  }).observe(document.body, { childList: true, subtree: true });
  addStep('week.after', 55, 'moments_and_trophies weekly', () => { try { checkAch(); } catch (e) { console.error(e); } });
  addStep('day.after', 30, 'firsts and milestones', (d) => { if (!ui.untl) checkAch(); }, true);
})();


/* ---- features/player/first_steps.js ---- */
/* ===== Round 58: first steps. A new game gets a short checklist on Home that teaches by doing: each step says what to
   do and has a Show me that opens the right screen; once it is done, you claim a small reward that fits it (a town's
   start-up grant, the local paper writing about you, a better credit score, a refunded ad week, the agency waiving its
   fee). The checks look at the game itself, so a step done another way counts too (an inherited café is already open).
   The card shows the next step only, with the count; the whole list is one tap away (V.fs58), and the card can be
   put away. Older saves (no S.fs58) do not get it. Started from ui/screens/start.js with the new game. ===== */
window.FS58 = window.FS58 || {};
(function () {
  const F = window.FS58;
  const live = () => S.cos.filter(c => c.st !== 'sold' && c.st !== 'bust' && c.type !== 'hold');
  const first = () => live()[0] || null;
  const cash = (v, why) => { moveCash(ME, KC(v), why); return mshort(KC(v)); };
  const knobbed = c => { const bd = BD[c.type]; return (c.price || 0) !== 0 || (bd.knobs || []).some(k => c.knob && c.knob[k.id] != null && c.knob[k.id] !== (k.def || 0)); };
  /* [id, title, how, done?, show me (action, params), the reward line, give it] */
  const L = [
    ['co', 'Start a business', 'New company: pick a trade. The small ones are cheap to start.', () => live().length > 0, () => ['go', { n: 'newbiz' }],
      'A start-up grant from the town', () => 'The town gives new businesses a small grant: ' + cash(25000, 'Start-up grant from the town') + '.'],
    ['staff', 'Hire your first worker', 'In the company: Manage › Find workers. Check what they claim before you hire.', () => live().some(c => (c.staff || []).length > 0), () => first() ? ['go', { n: 'co', p: { id: first().id, t: 'st' } }] : ['go', { n: 'newbiz' }],
      'The job centre pays a month of payroll tax', () => 'The job centre pays a month of payroll tax for your first hire: ' + cash(6000, 'Job centre: first hire') + '.'],
    ['open', 'Open the doors', 'Papers, premises, equipment and people in place: it opens by itself. Press Next day while papers are processed.', () => live().some(c => c.st === 'open'), () => first() ? ['go', { n: 'co', p: { id: first().id } }] : ['go', { n: 'newbiz' }],
      'The local paper writes about you', () => { const c = live().find(x => x.st === 'open'); if (c) c.aware = Math.min(100, (c.aware || 0) + 8); return 'The local paper writes about ' + (c ? c.name : 'you') + ': more people know the name.'; }],
    ['week', 'Read your week report', 'Press Next day until the week ends; the report shows what happened and where the money went.', () => !!S.lastRep, () => ['weekrep', {}],
      'The bank likes what it sees', () => { S.credit = Math.min(100, (S.credit || 50) + 3); return 'The bank likes a good start: your credit score is a little better.'; }],
    ['sell', 'Choose how you sell', 'Sales › How you sell: who you are for, and what else you offer. Or set your prices.', () => live().some(knobbed), () => first() ? ['go', { n: 'co', p: { id: first().id, t: 'cli', s: 'hys' } }] : ['go', { n: 'newbiz' }],
      'Word gets around', () => { const c = live().find(knobbed); if (c) c.aware = Math.min(100, (c.aware || 0) + 5); return 'People talk about what you offer: more of them know the name.'; }],
    ['ad', 'Run an ad', 'Sales › Marketing: even a small campaign brings people in.', () => live().some(c => mktCost(c) > 0), () => first() ? ['go', { n: 'co', p: { id: first().id, t: 'cli', s: 'mk' } }] : ['go', { n: 'newbiz' }],
      'The ad agency refunds your first week', () => 'The ad agency refunds your first week: ' + cash(3000, 'Ad agency: first week refunded') + '.'],
    ['inbox', 'Answer a decision', 'Inbox › To do: problems and offers wait there for your answer.', () => S.inbox.some(m => m.opts && m.pick != null), () => ['tab', 'meet'],
      'People learn they can count on you', () => { live().forEach(c => { c.rep = Math.min(100, (c.rep || 50) + 1); }); return 'People learn they can count on you: a little better reputation.'; }],
    ['pay', 'Pay yourself', 'Money › Pay yourself: a salary, a dividend, or take money out. Leave enough for the bills.', () => live().some(c => (c.ownerSalary || 0) > 0 || (c.dist || 0) > 0), () => first() ? ['go', { n: 'payself', p: { id: first().id } }] : ['go', { n: 'newbiz' }],
      'Your accountant’s first month is free', () => 'Your accountant waives the first month: ' + cash(2500, 'Accountant: first month free') + '.'],
    ['profit', 'Make a profit in a month', 'Keep the costs in check and the customers coming. The month’s result is on the company’s overview.', () => live().some(c => (c.hist || []).some(x => x.profit > 0)), () => first() ? ['go', { n: 'co', p: { id: first().id, t: 'money' } }] : ['go', { n: 'newbiz' }],
      'Better terms from the bank', () => { S.credit = Math.min(100, (S.credit || 50) + 5); return 'A profitable month: the bank offers you better terms.'; }],
    ['mgr', 'Hire a manager or an assistant', 'Manage › Management: they run it day to day while you grow.', () => live().some(c => c.mgr || c.asst), () => first() ? ['go', { n: 'mgmt56', p: { id: first().id } }] : ['go', { n: 'newbiz' }],
      'The agency waives its fee', () => 'The recruitment agency waives its fee for your first hire: ' + cash(15000, 'Recruitment agency: fee waived') + '.']
  ];
  F.L = L;
  /* V.1.0.0: the first game on this device opens with a three-card welcome (also Settings › How to play) */
  const W = window.UI, GK = W.KEY + ':guide';
  F.start = () => {
    S.fs58 = { got: {}, off: 0, w0: S.week };
    let seen = null; try { seen = localStorage.getItem(GK); } catch (e) { }
    if (!seen) setTimeout(() => F.welcome(0), 300);
  };
  const WEL = [
    ['Welcome to Ledger', 'Start with one small business and grow it into a group. Your net worth is your score. Nothing is scripted: good choices and a little luck decide how it goes.'],
    ['Day by day', 'Tap Next day to play. Decisions pop up when they need you, and the Next line on Home always says what to do, with a button that does it.'],
    ['Grow', 'Hire people, then a manager who runs it for you. Open more companies, invest, expand abroad. First steps on Home show the way and pay a small reward for each.']
  ];
  F.welcome = i => {
    i = Math.max(0, Math.min(WEL.length - 1, i || 0));
    const last = i === WEL.length - 1;
    W.openSheet('<span class="lab">' + (i + 1) + ' of ' + WEL.length + '<span class="pdots">' + WEL.map((x, j) => '<i class="' + (j === i ? 'on' : '') + '"></i>').join('') + '</span></span><h2>' + W.esc(WEL[i][0]) + '</h2><p class="lead">' + W.esc(WEL[i][1]) + '</p>' +
      '<div class="btnrow col">' + W.btn(last ? 'Let’s play' : 'Next', last ? 'wel59end' : 'wel59', { i: i + 1 }, 'primary wide') + (last ? '' : W.btn('Skip', 'wel59end', undefined, 'ghost wide')) + '</div>');
  };
  W.ACT.wel59 = p => F.welcome(p.i);
  W.ACT.wel59end = () => { try { localStorage.setItem(GK, '1'); } catch (e) { } W.closeSheet(); };
  const st = () => S && S.fs58;
  const done = x => { try { return !!x[3](); } catch (e) { return false; } };
  /* the next step: the first not yet claimed */
  F.next = () => { const s = st(); return s ? L.find(x => !s.got[x[0]]) || null : null; };
  F.count = () => { const s = st(); return s ? L.filter(x => s.got[x[0]]).length : 0; };
  F.claim = id => {
    const s = st(), x = L.find(y => y[0] === id);
    if (!s || !x || s.got[id] || !done(x)) return null;
    s.got[id] = { w: S.week };
    return x[6]();
  };

  /* ---------- the screens ---------- */
  const U = window.UI;
  if (!U) return;
  const { ui, V, ACT, esc, btn, svg, render, save, toast } = U;
  const P = o => esc(JSON.stringify(o));
  const show = x => { const g = x[4](); return btn('Show me', g[0], g[1], 'chip'); };
  /* the card on Home (ui/screens/mockup.js V.home) */
  F.card = function () {
    const s = st(), x = F.next();
    if (!s || s.off || !x) return '';
    const ok = done(x), n = F.count();
    return '<div class="card fs58"><button class="fs58h" data-a="go" data-p="' + P({ n: 'fs58' }) + '"><span class="lab">First steps · ' + n + ' of ' + L.length + '</span><span class="fs58bar"><i style="width:' + Math.round(n / L.length * 100) + '%"></i></span></button>' +
      '<div class="fs58n"><span class="ctext"><b>' + (ok ? '✓ ' : '') + esc(x[1]) + '</b><small>' + esc(ok ? 'Done. Reward: ' + x[5].toLowerCase() : x[2]) + '</small></span>' + (ok ? btn('Claim', 'fs58claim', { id: x[0] }, 'chip primary') : show(x)) + '</div></div>';
  };
  V.titles.fs58 = 'First steps';
  V.heads = V.heads || {};
  V.heads.fs58 = () => ({ t: 'First steps', sub: F.count() + ' of ' + L.length + ' done' });
  V.fs58 = function () {
    const s = st();
    if (!s) return '<div class="calm">You know your way around.</div>';
    let h = '<div class="lrows">' + L.map(x => {
      const got = s.got[x[0]], ok = done(x);
      return '<div class="lrow fs58r' + (got ? ' got' : '') + '"><span class="lic">' + (got ? svg('check', 20) : '<i class="fs58o"></i>') + '</span><span class="ctext"><b>' + esc(x[1]) + '</b><small>' + esc(got ? x[5] : x[2]) + '</small></span>' + (got ? '' : ok ? btn('Claim', 'fs58claim', { id: x[0] }, 'chip primary') : show(x)) + '</div>';
    }).join('') + '</div>';
    h += s.off ? btn('Show on Home again', 'fs58off', { v: 0 }, 'ghost wide') : btn('Put the guide away', 'fs58off', { v: 1 }, 'ghost wide');
    return h;
  };
  ACT.fs58claim = p => {
    const r = F.claim(p.id);
    if (!r) return;
    addMsg({ kind: 'info', from: 'First steps', title: (L.find(y => y[0] === p.id) || [])[5] || 'A reward', body: r, tone: 'good', status: 'done' });
    save(); render(); toast(r);
  };
  ACT.fs58off = p => { const s = st(); if (!s) return; s.off = p.v ? 1 : 0; save(); render(); };
})();

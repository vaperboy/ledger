/* ===== saves: no error on an empty paste, save to / load from a file, three save slots and a monthly backup =====
   Slots and the backup are kept packed (engine/core/state.js packText) next to the running game in this browser:
   KEY:slot:1 .. KEY:slot:3, KEY:auto (written at every month end), KEY:prev (the game you left from the main menu)
   and KEY:meta with a line about each. In the iPhone app every key is also kept in a file and the game, the slots and
   KEY:meta in iCloud (ui/core/base.js disk); a newer game from another phone waits here as KEY:cloud. */
{
  ACT.loadpaste = pipeView('ACT.loadpaste', ACT.loadpaste, 0);
  addStep('ACT.loadpaste.around', 10, 'no error on an empty paste', (next) => {
    if (!(ui.inp.imp2 || '').trim()) { toast('Paste a save text first.', true); return; } next();
  });
  ACT.savefile = () => {
    try {
      const name = 'ledger-' + (S.player && S.player.name ? S.player.name.replace(/\W+/g, '-') : 'save') + '-week' + S.week + '.txt';
      if (window.LedgerApp) { LedgerApp.disk.share({ name, text: serialize() }).catch(() => toast('Could not make the file here.', true)); return; } /* the app: the share sheet (Save to Files, AirDrop, Mail) */
      const b = new Blob([serialize()], { type: 'text/plain' }), a = document.createElement('a');
      a.href = URL.createObjectURL(b);
      a.download = name;
      document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
      toast('Save file downloaded.');
    } catch (e) { toast('Could not make the file here.', true); }
  };
  ACT.loadfile = () => {
    const i = document.createElement('input');
    i.type = 'file'; i.accept = '.txt,.json,text/plain';
    i.onchange = () => { const f = i.files && i.files[0]; if (!f) return; const r = new FileReader(); r.onload = () => { ui.inp.imp2 = String(r.result || ''); ACT.loadpaste(); }; r.readAsText(f); };
    i.click();
  };

  /* ---------- slots and the monthly backup ---------- */
  const SLOTS = 3, K = U.KEY;
  const ls = {
    get: k => { try { return localStorage.getItem(k); } catch (e) { return null; } },
    set: k => v => { try { localStorage.setItem(k, v); U.disk(k, v); return true; } catch (e) { return false; } },
    del: k => { try { localStorage.removeItem(k); } catch (e) { } U.disk(k, null); }
  };
  const meta = () => { try { return JSON.parse(ls.get(K + ':meta') || '{}') || {}; } catch (e) { return {}; } };
  const setMeta = m => ls.set(K + ':meta')(JSON.stringify(m));
  const about = () => ({ name: S.player.name, cc: S.country, week: S.week, nw: Math.round(netWorth().total), cos: liveCos().filter(c => c.type !== 'hold').length, t: Date.now() });
  function keep(slot) {
    const t = serialize();
    const ok = ls.set(K + ':' + slot)('LZ1:' + packText(t));
    if (ok) { const m = meta(); m[slot] = about(); setMeta(m); }
    return ok;
  }
  function restore(slot) {
    const t = ls.get(K + ':' + slot);
    if (!t || !deserialize(t)) return false;
    save();
    ui.stack = [];
    ui.tab = 'home';
    ui.view = { n: 'home', p: {} };
    return true;
  }
  /* every month end the game keeps a backup of itself (quietly skipped when the browser is short of room).
     Packing takes a moment in a big game, so it is done once the week has finished, not inside it. */
  let backupDue = 0;
  addStep('week.after', 90, 'a monthly backup of the game', () => {
    if (!S || S.over || !isMonthEnd(S.week) || backupDue) return;
    backupDue = 1;
    setTimeout(() => { backupDue = 0; if (S && !S.over) keep('auto'); }, 0);
  });
  /* how much of the browser's storage the game uses, in characters (most browsers allow about five million) */
  function used() {
    let n = 0;
    try { for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (k && k.indexOf(K) === 0) n += (localStorage.getItem(k) || '').length; } } catch (e) { }
    return n;
  }
  const line = (slot, label) => {
    const m = meta()[slot];
    const info = m ? esc(m.name) + ' · ' + esc((CO[m.cc] || {}).name || '') + ' · ' + dateStr(m.week) + ' · ' + m.cos + (m.cos === 1 ? ' company' : ' companies') : 'Empty';
    const b = slot === 'auto' ? '' : btn('Save here' + (slot !== 'slot:1' && window.PRO ? PRO.tag('slots') : ''), 'slotkeep', { s: slot }, 'chip');
    return '<div class="opt"><div class="bhead"><div><b>' + label + '</b><small>' + info + '</small></div></div><div class="chips">' + b + (m ? btn('Load', 'slotload', { s: slot }, 'chip') : '') + (m && slot !== 'auto' ? btn('Clear', 'slotdel', { s: slot }, 'chip ghost') : '') + '</div></div>';
  };
  function slotsCard() {
    const n = used();
    let h = '<div class="card"><h3>Save slots<small>' + (U.inCloud() ? 'Kept on this phone and in iCloud' : window.LedgerApp ? 'Kept on this phone' : 'Kept in this browser') + ', next to the game you are playing.</small></h3>';
    for (let i = 1; i <= SLOTS; i++) h += line('slot:' + i, 'Slot ' + i);
    h += line('auto', 'Monthly backup');
    h += '<p class="muted small">This game uses about ' + (n >= 1e6 ? (n / 1e6).toFixed(1) + ' million' : Math.max(1, Math.round(n / 1000)) + ' thousand') + ' characters of the browser\'s storage' + (ui.saveErr ? '. <b class="neg">The last save did not fit: save to a file.</b>' : '.') + '</p></div>';
    return h;
  }
  ACT.slotkeep = p => {
    const go = () => { if (keep(p.s)) { toast('Saved in ' + p.s.replace('slot:', 'slot ') + '.'); render(); } else toast('No room left in the browser. Save to a file instead.', true); };
    if (meta()[p.s]) confirmThen('Replace this slot?', 'The game saved in it now is replaced by the one you are playing.', 'Replace', go); else go();
  };
  ACT.slotload = p => confirmThen('Load this game?', 'The game you are playing now is replaced. Put it in a slot first if you want to keep it.', 'Load', () => {
    if (restore(p.s)) { render(true); toast('Loaded.'); } else toast('That save could not be read.', true);
  }, true);
  ACT.slotdel = p => confirmThen('Clear this slot?', 'The game saved in it is deleted.', 'Clear', () => {
    ls.del(K + ':' + p.s); const m = meta(); delete m[p.s]; setMeta(m); render();
  }, true);
  /* in Settings (ui/phone/phone.js V.settings): files under the save text, the slots before Start over */
  window.SAVES = window.SAVES || {};
  SAVES.fileBtns = () => '<div class="two">' + btn('Save to a file', 'savefile') + btn('Load from a file', 'loadfile') + '</div>';
  SAVES.slotsCard = slotsCard;
  /* ---------- the main menu when the game opens (ui/core/boot.js sets ui.menu; ui/core/base.js render shows it) ----------
     Continue the game you were playing, load one of the saved ones, or start a new one. The game you leave for a
     new or loaded one is kept as "Your previous game" (KEY:prev), so nothing is lost by accident. */
  const hasMain = () => !!ls.get(K);
  const any = () => hasMain() || Object.keys(meta()).some(k => ls.get(K + ':' + k));
  const NAMES = { cloud: 'From iCloud, another device', 'slot:1': 'Slot 1', 'slot:2': 'Slot 2', 'slot:3': 'Slot 3', auto: 'Monthly backup', prev: 'Your previous game' };
  V.menu = function () {
    const m = meta();
    let h = '<div class="splash st2 menu56"><div><div class="eyebrow">Ledger · Business Tycoon Simulator</div><h1 class="hero">' + (S ? 'Welcome back, ' + esc(String(S.player.name || 'you').split(' ')[0]) + '.' : 'Build companies, hire people, invest.') + '</h1>';
    if (S && !S.over) {
      const a = about(), c = CO[a.cc] || CC();
      h += '<button class="card cont56" data-a="menucont"><span class="lab">Continue</span><b>' + esc(a.name) + '</b><small>' + c.flag + ' ' + esc(c.name) + ' · ' + dateStr(a.week) + ' · ' + a.cos + (a.cos === 1 ? ' company' : ' companies') + ' · net worth ' + mshort(a.nw) + '</small><span class="go56">Continue ›</span></button>';
      h += '<p class="muted small">The game saves itself all the time, and keeps a backup at every month end.</p>';
    }
    const L = Object.keys(NAMES).filter(k => m[k] && ls.get(K + ':' + k));
    if (L.length) h += '<span class="lab">Saved games</span><div class="lrows">' + L.map(k => { const x = m[k], c = CO[x.cc] || {}; return '<button class="lrow" data-a="menuload" data-p="' + esc(JSON.stringify({ s: k })) + '"><span class="ctext"><b>' + esc(x.name) + ' <small>· ' + NAMES[k] + '</small></b><small>' + (c.flag || '') + ' ' + esc(c.name || '') + ' · ' + dateStr(x.week) + ' · ' + x.cos + (x.cos === 1 ? ' company' : ' companies') + ' · ' + mshort(x.nw) + '</small></span><i>›</i></button>'; }).join('') + '</div>';
    h += '<div class="stbtns">' + btn('New game', 'menunew', undefined, (S && !S.over) || L.length ? 'ghost wide' : 'primary wide go') + btn('Load from a file', 'loadfile', undefined, 'ghost wide') + (window.PRO && !PRO.on ? btn('Ledger Pro', 'prostore', undefined, 'ghost wide') : '') + '</div><p class="muted small center">' + U.PATCH + '</p></div></div>';
    return h;
  };
  ACT.menucont = () => { ui.menu = 0; ui.tab = 'home'; ui.stack = []; ui.view = { n: 'home', p: {} }; render(true); };
  ACT.menuload = p => {
    const t = ls.get(K + ':' + p.s);
    if (!t) { toast('That save is gone.', true); return; }
    if (S && !S.over) keep('prev'); /* the game you leave stays as your previous game */
    if (!deserialize(t)) { toast('That save could not be read.', true); return; }
    if (p.s === 'cloud') { ls.del(K + ':cloud'); const m = meta(); delete m.cloud; setMeta(m); }
    save();
    if (p.s === 'cloud') U.flushSave(); /* it is this phone's game now: iCloud hears so at once */
    ACT.menucont();
    toast('Loaded.');
  };
  ACT.menunew = () => {
    if (S && !S.over) keep('prev');
    S = null; ui.menu = 0; ui.inp = {}; render(true);
  };
  ACT.menuback = () => { if (!S) U.loadSaved(); ui.menu = 1; render(true); };
  /* a game loaded from a file or a pasted text leaves the menu */
  addStep('ACT.loadpaste.around', 20, 'loading from a file leaves the main menu', (next) => { next(); if (S) ui.menu = 0; render(true); });
  /* iCloud (ui/core/boot.js, at the start and when iCloud brings something new): slots this phone lacks are filled
     in; on a new phone the game simply carries on; a game another phone sent is offered in the menu, never put over
     the one here */
  function cloudIn(r) {
    const C = r && r.cloud, m = meta();
    if (!C) return;
    let cm = {}; try { cm = JSON.parse((C[K + ':meta'] || {}).v || '{}') || {}; } catch (e) { }
    let ch = 0;
    Object.keys(C).forEach(k => { const s = k.slice(K.length + 1); if (/^slot:\d$/.test(s) && !ls.get(k) && cm[s]) { ls.set(k)(C[k].v); m[s] = cm[s]; ch = 1; } });
    const g = C[K], mine = ls.get(K);
    if (g && g.v && !mine) ls.set(K)(g.v);
    else if (g && g.v && g.a && g.a.dev !== U.dev() && g.v !== mine && g.v !== ls.get(K + ':cloud')) { ls.set(K + ':cloud')(g.v); m.cloud = g.a; ch = 1; }
    if (ch) setMeta(m);
  }
  window.R56saves = { keep, restore, meta, used, any, about, cloudIn };
}

/* ===== Round 5b: selling and raising money, own startups, the big meeting, worker discipline,
   price moves, crisis centre, marketing client stats ===== */
  const SALES = () => (S.sales = S.sales || []);
  const FOUNDER = () => (S.founder = S.founder || { exits: 0, fails: 0, raised: 0 });
  const FD = () => (S.founded = S.founded || []);
  const STK = () => (S.stakes = S.stakes || []);
  window.founderRec = FOUNDER;
  function capK(co) {
    return { energy: 5, fin: 4, club: 4, rent: 3, prod: 3, logi: 3, project: 2, venue: 2, retail: 2, svc: 1 }[BD[co.type].fam] || 2;
  }
  function traction(co) {
    const e = coEbit12(co);
    const rev = (co.bk.y && co.bk.y.rev) || (co.lastW ? co.lastW.rev * 52 : 0);
    const mg = rev > 0 ? e / rev : -0.2;
    const h = co.hist.slice(-6).map(x => x.rev || 0);
    const g = h.length >= 2 && h[0] > 0 ? h[h.length - 1] / h[0] - 1 : 0;
    return clamp(0.25 + mg * 1.5 + clamp(g, -0.5, 1) * 0.6 + ((co.rep || 50) - 50) / 150 + Math.min(0.2, (S.week - co.w0) / 260), 0, 1);
  }
  /* investors look at your record as a founder, how much capital the business eats, and how it is doing */
  function interest(ck, tr) {
    const f = FOUNDER();
    const track = Math.min(0.36, f.exits * 0.12) - Math.min(0.3, f.fails * 0.06);
    const pen = (ck - 1) * 0.13 * (f.exits ? 0.4 : 1);
    return clamp(0.3 + track + tr * 0.45 - pen + (((S.econ && S.econ.dem) || 1) - 1), 0.02, 0.97);
  }
  const intWord = x => x >= 0.7 ? ['Strong', 'pos'] : x >= 0.45 ? ['Some interest', 'amb'] : x >= 0.25 ? ['Weak', 'amb'] : ['Almost none', 'neg'];
  function consequences(co, pct, kind) {
    const after = kind === 'fund' ? co.own * (1 - pct / 100) : co.own - pct * co.own / 100;
    return '<h2 class="sec">What happens</h2><div class="card">' + row('You get cash', kind === 'fund' ? '<span class="pos">Into the company</span>' : '<span class="pos">Into your pocket</span>') + row('Your ownership', '<span class="amb">' + fmtPct(Math.round(co.own * 10) / 10) + '% → ' + fmtPct(Math.round(Math.max(0, after) * 10) / 10) + '%</span>') + (after > 0 ? row('Future dividends', 'Shared ' + fmtPct(Math.round((co.own - after) * 10) / 10) + '%') + row('Big decisions', after < 50 ? '<span class="neg">You lose control</span>' : after < 67 ? '<span class="amb">May need their vote</span>' : 'Still yours') : row('The company', 'No longer yours')) + '</div>';
  }

  /* ---------- sell a company or part of it ---------- */
  V.titles.sale = 'Sell or raise money';
  V.heads.sale = p => {
    const co = getCo(p.id);
    return { t: 'Sell or raise money', sub: co ? esc(co.name) : '' };
  };
  V.sale = function (p) {
    const co = getCo(p.id);
    if (!co || co.st === 'sold' || co.st === 'bust') return '<div class="calm">This company is no longer yours.</div>';
    const t = ui.salet || 'whole';
    const V0 = Math.max(0, companyValue(co));
    const net = companyAssets(co) - companyDebts(co);
    let h = '<div class="ptabs">' + [['whole', 'Whole company'], ['part', 'Part of it'], ['fund', 'Raise funding']].map(x => '<button class="' + (t === x[0] ? 'on' : '') + '" data-a="saletab" data-p="' + P(x[0]) + '">' + x[1] + '</button>').join('') + '</div>';
    h += '<div class="card"><span class="lab">Estimated value</span><b class="huge">' + nok(V0) + '</b>' + row('Profit last 12 months', nok(Math.max(0, coEbit12(co)))) + row('Assets minus debts', nok(net)) + row('Brand, clients, contracts', nok(Math.max(0, V0 - net))) + '</div>';
    if (t === 'fund') return h + fundPart(co, V0);
    const Lst = SALES().find(x => x.co === co.id);
    if (Lst) return h + listingPart(co, Lst);
    if (t === 'part' && co.form !== 'AS') return h + '<div class="card sense"><b>Only a limited company can sell shares</b><span class="tipt">Convert to ' + esc(CC().forms.AS) + ' first, then sell part of it.</span>' + btn('Convert to ' + esc(CC().forms.AS), 'tcAS', { id: co.id }, 'wide') + '</div>';
    const pct = t === 'whole' ? 100 : (ui.salep || 25);
    if (t === 'part') h += '<div class="card"><div class="kv"><span>Share of your stake to sell</span><b>' + pct + '%</b></div>' + chips([[10, '10%'], [25, '25%'], [34, '34%'], [49, '49%']], pct, 'salepct') + '</div>';
    const m = ui.salem || 'private';
    h += '<h2 class="sec">How to sell</h2><div class="lrows">' + [['private', 'Quiet private sale', 'Fewer buyers and slower. Staff and rivals do not hear.'], ['broker', 'Use a broker', 'More buyers, fee 4%. Rivals and staff hear about it.']].map(x => '<button class="lrow" data-a="salemode" data-p="' + P(x[0]) + '"><span class="ctext"><b>' + x[1] + '</b><small>' + x[2] + '</small></span><span class="radio' + (m === x[0] ? ' on' : '') + '"></span></button>').join('') + '</div>';
    h += consequences(co, pct, 'sell');
    h += btn('Put ' + (pct === 100 ? 'the company' : pct + '% of your shares') + ' up for sale', 'salego', { id: co.id, pct, m }, 'primary wide go');
    return h;
  };
  ACT.saletab = p => {
    ui.salet = p;
    render(true);
  };
  ACT.salepct = p => {
    ui.salep = p.v;
    render();
  };
  ACT.salemode = p => {
    ui.salem = p;
    render();
  };
  ACT.salego = p => {
    const co = getCo(p.id);
    if (!co || SALES().some(x => x.co === co.id)) return;
    SALES().push({ id: uid(), co: co.id, pct: p.pct, m: p.m, w0: S.week, offers: [] });
    save();
    toast(p.m === 'broker' ? 'The broker starts calling buyers.' : 'You quietly let it be known you would sell.');
    render(true);
  };
  const KIND_N = { rival: 'Rival · wants the clients', fund: 'Investment fund', mbo: 'Management buyout', private: 'Private buyer', angel: 'Private investor' };
  function listingPart(co, Lst) {
    const best = Lst.offers.reduce((a, o) => (o.price > (a ? a.price : 0) ? o : a), null);
    let h = '<div class="card sense"><b>On the market since ' + dateStr(Lst.w0) + '</b><span class="tipt">' + (Lst.pct === 100 ? 'The whole company' : Lst.pct + '% of your shares') + ' · ' + (Lst.m === 'broker' ? 'through a broker' : 'quiet private sale') + ' · ' + Lst.offers.length + ' offer' + (Lst.offers.length === 1 ? '' : 's') + ' so far.</span>' + btn('Take it off the market', 'salewd', { id: co.id }, 'wide') + '</div>';
    if (!Lst.offers.length) return h + '<div class="calm">No offers yet. Buyers show up over the coming weeks.</div>';
    return h + '<h2 class="sec">Buyers</h2>' + Lst.offers.map(o => '<div class="card' + (o === best ? ' offer on' : ' offer') + '"><div class="cchd">' + av(ini(o.name)) + '<span class="ctext"><b>' + esc(o.name) + '</b><small>' + esc(KIND_N[o.k] || '') + ' · until ' + dateStr(o.exp) + '</small></span><span class="badge ' + (o === best ? 'amber' : '') + '">' + mshort(o.price) + '</span></div><span class="tipt">' + esc(o.note) + '</span><div class="dbtns">' + btn('Accept', 'saleacc', { id: co.id, o: o.id }, 'primary') + (o.ctr ? btn('Decline', 'saledec', { id: co.id, o: o.id }) : btn('Counter +8%', 'salectr', { id: co.id, o: o.id })) + '</div></div>').join('');
  }
  function sellPart(co, pct, amt, buyer) {
    const pts = Math.min(pct * co.own / 100, co.own - 1);
    moveCash(ME, amt, 'Sold ' + pct + '% of ' + co.name);
    S.tax.gain = (S.tax.gain || 0) + Math.max(0, amt - (co.inj || 0) * pts / 100);
    co.holders.push({ name: buyer, pct: pts, in: amt });
    co.own = Math.round((co.own - pts) * 100) / 100;
    if (pts >= 20) co.flags.boardSeat = (co.flags.boardSeat || 0) + 1;
    note('Sold ' + pct + '% of your shares in ' + co.name + ' to ' + buyer + ' for ' + money(amt) + '.', 'good', co.id);
  }
  ACT.saleacc = p => {
    const co = getCo(p.id), Lst = SALES().find(x => x.co === p.id), o = Lst && Lst.offers.find(x => x.id === p.o);
    if (!co || !o) return;
    const fee = Lst.m === 'broker' ? Math.round(o.price * 0.04) : 0;
    const get = Lst.pct === 100 ? o.price * co.own / 100 - fee : o.price - fee;
    confirmThen('Sell ' + (Lst.pct === 100 ? esc(co.name) : Lst.pct + '% of your shares') + '?', 'You receive ' + money(get) + (fee ? ' after the broker fee' : '') + (o.k === 'mbo' ? '. A third is a seller loan paid back over two years.' : '.') + ' This cannot be undone.', 'Sell', () => {
      if (Lst.pct === 100) {
        const r = acceptSale(co, { buyer: o.name, price: o.price, V: o.price });
        if (r !== 'ok') return U.res(r);
        if (fee) {
          moveCash(ME, -fee, 'Broker fee');
        }
        if (o.k === 'mbo') {
          const later = Math.round(o.price * co.own / 100 / 3);
          moveCash(ME, -later, 'Part of the price lent to the buyers (paid back later)', co.id);
          S.deferred = (S.deferred || []).concat([{ w: S.week + 104, amt: later, co: co.id, name: co.name, hurdle: 0 }]);
        }
        if (o.price > (co.inj || 0) * 1.3) FOUNDER().exits++;
      } else sellPart(co, Lst.pct, o.price - fee, o.name);
      S.sales = SALES().filter(x => x !== Lst);
      save();
      if (co.st === 'sold') {
        ui.stack = [];
        tabTo('cos');
      } else render(true);
      toast('Deal done.');
    }, true);
  };
  ACT.salectr = p => {
    const Lst = SALES().find(x => x.co === p.id), o = Lst && Lst.offers.find(x => x.id === p.o);
    if (!o || o.ctr) return;
    o.ctr = 1;
    if (chance(o.k === 'rival' || o.k === 'fund' ? 0.55 : 0.4)) {
      o.price = rnl(o.price * 1.08, 1000);
      o.note = 'Accepted your counter-offer.';
      toast(o.name + ' accepts +8%.');
    } else {
      Lst.offers = Lst.offers.filter(x => x !== o);
      toast(o.name + ' walked away.', true);
    }
    save();
    render();
  };
  ACT.saledec = p => {
    const Lst = SALES().find(x => x.co === p.id);
    if (Lst) Lst.offers = Lst.offers.filter(x => x.id !== p.o);
    save();
    render();
  };
  ACT.salewd = p => {
    S.sales = SALES().filter(x => x.co !== p.id);
    save();
    render();
    toast('Taken off the market.');
  };
  function salesWeek() {
    SALES().slice().forEach(Lst => {
      const co = getCo(Lst.co);
      if (!co || co.st === 'sold' || co.st === 'bust') {
        S.sales = SALES().filter(x => x !== Lst);
        return;
      }
      Lst.offers = (Lst.offers || []).filter(o => S.week < o.exp);
      if (Lst.offers.length >= 4) return;
      const V0 = Math.max(KC(20000), companyValue(co));
      const tr = traction(co);
      const hi = window.PK58 ? PK58.hosted('inv') : 0; /* investors you hosted come sooner and pay a little more (features/people/perks_and_hosting.js) */
      if (!chance((Lst.m === 'broker' ? 0.42 : 0.16) * (0.35 + tr) * (coEbit12(co) > 0 ? 1 : 0.45) * (1 + 0.6 * hi))) return;
      const kinds = Lst.pct === 100 ? ['private', 'fund', 'rival'] : ['private', 'fund', 'angel'];
      if (co.mgr && S.npcs[co.mgr] && Lst.pct === 100) kinds.push('mbo');
      const k = pick(kinds);
      const f = { rival: rng(0.95, 1.18), fund: rng(0.82, 1.02), mbo: rng(0.62, 0.8), private: rng(0.8, 1), angel: rng(0.78, 0.98) }[k] * (Lst.m === 'broker' ? 1.05 : 1) * (0.85 + tr * 0.3) * (1 + 0.05 * hi);
      const riv = rivalsOf(co)[0];
      const name = k === 'rival' && riv ? riv.name : k === 'mbo' ? S.npcs[co.mgr].name + ', your manager' : k === 'fund' ? brandCoName(CC(), 'fin') : personName();
      const nt = { rival: 'Strategic buyer. Pays well but may close it and keep only the customers.', fund: 'Wants to grow it and sell again. Keeps staff and the brand.', mbo: 'Management buyout. A third is paid as a seller loan over two years. Safe, loyal, slower to pay.', private: 'A private buyer who wants to run it themselves.', angel: 'A private investor who wants a say in big decisions.' }[k];
      const base = Lst.pct === 100 ? V0 : V0 * Lst.pct / 100 * co.own / 100;
      const o = { id: uid(), k, name, price: rnl(base * f, 1000), note: nt, w: S.week, exp: S.week + 6 };
      Lst.offers.push(o);
      addMsg({ kind: 'info', from: name, title: 'Offer for ' + (Lst.pct === 100 ? co.name : Lst.pct + '% of ' + co.name), body: name + ' offers ' + money(o.price) + '.', co: co.id, tone: 'good', status: 'done', go: { l: 'See offer', a: 'go', p: { n: 'sale', p: { id: co.id } } } });
      if (Lst.m === 'broker' && !Lst.heard) {
        Lst.heard = 1;
        co.mood = Math.max(0, (co.mood != null ? co.mood : 60) - 8);
        rivalsOf(co).forEach(r => {
          r.rel = Math.max(0, r.rel - 5);
        });
        note('Word is out that ' + co.name + ' is for sale. Staff are uneasy and rivals are watching.', 'n', co.id);
      }
    });
  }

  /* ---------- raise funding: new shares, the money goes into the company ---------- */
  function fundPart(co, V0) {
    if (co.form !== 'AS') return '<div class="card sense"><b>Investors buy shares</b><span class="tipt">Only a limited company can issue new shares. Convert first.</span>' + btn('Convert to ' + esc(CC().forms.AS), 'tcAS', { id: co.id }, 'wide') + '</div>';
    const it = interest(capK(co), traction(co)), iw = intWord(it), f = FOUNDER();
    const k = 'fneed' + co.id;
    let h = '<div class="card">' + row('You own', fmtPct(Math.round(co.own * 10) / 10) + '%') + row('Investor interest', '<span class="' + iw[1] + '">' + iw[0] + '</span>') + row('Your record as founder', f.exits + ' exit' + (f.exits === 1 ? '' : 's') + ' · ' + f.fails + ' failure' + (f.fails === 1 ? '' : 's')) + '<div class="kv"><span>You need</span>' + inp(k, '', rnl(Math.max(KC(100000), V0 * 0.2), 10000)) + '</div>' + btn('Pitch to investors', 'pitch', { id: co.id }, 'primary wide') + '</div>';
    const offs = (S.fundOffers || {})[co.id] || [];
    if (offs.length) h += '<h2 class="sec">Offers</h2>' + offs.map((o, i) => '<div class="card offer' + (i === 0 ? ' on' : '') + '"><div class="cchd">' + av(ini(o.name)) + '<span class="ctext"><b>' + esc(o.name) + '</b><small>Wants ' + o.pct.toFixed(0) + '% for ' + mshort(o.amt) + ' · values you at ' + mshort(o.pre + o.amt) + '</small></span>' + (i === 0 ? '<span class="badge amber">Best</span>' : '') + '</div>' + row(o.k === 'fund' ? 'Brings' : 'Says', esc(o.says)) + '<div class="dbtns">' + btn('Accept', 'fundacc', { id: co.id, i }, 'primary') + (o.ctr ? btn('Decline', 'funddec', { id: co.id, i }) : btn('Counter', 'fundctr', { id: co.id, i })) + '</div></div>').join('');
    else if (S.fundTried && S.fundTried[co.id] != null && S.week - S.fundTried[co.id] < 4) h += '<div class="calm">No investor bit this time. More profit, growth or a founder record makes them keener.</div>';
    h += consequences(co, offs[0] ? offs[0].pct : 20, 'fund');
    return h;
  }
  function makeOffers(ck, tr, amt, pre0) {
    const it = interest(ck, tr);
    const k = it > 0.72 ? 3 : it > 0.48 ? 2 : it > 0.26 ? 1 : (chance(it * 2) ? 1 : 0);
    const kinds = ['angel', 'fund', 'ff'];
    return Array.from({ length: k }, (x, i) => {
      const kd = kinds[i];
      const a = rnl((kd === 'ff' ? amt * 0.5 : amt * rng(0.8, 1.15)), 1000);
      const pre = pre0 * rng(0.7, 1.25) * (0.7 + it * 0.6) * (kd === 'ff' ? 1.1 : 1);
      return { k: kd, name: kd === 'fund' ? brandCoName(CC(), 'fin') : kd === 'ff' ? 'Friends and family' : personName() + ', angel investor', amt: a, pre, pct: a / (pre + a) * 100, says: kd === 'fund' ? 'Contacts, advice, strict targets and a board seat' : kd === 'ff' ? 'Friendly, but it can get awkward if things go badly' : pick(['Will stay quiet', 'Interferes with managers', 'Wants monthly numbers']) };
    }).sort((a, b) => a.pct - b.pct);
  }
  ACT.pitch = p => {
    const co = getCo(p.id);
    S.fundTried = S.fundTried || {};
    if (S.fundTried[co.id] != null && S.week - S.fundTried[co.id] < 4) {
      toast('Investors need time. Try again in ' + (4 - (S.week - S.fundTried[co.id])) + ' week(s).', true);
      return;
    }
    S.fundTried[co.id] = S.week;
    const amt = Math.max(KC(50000), Math.round(U.inum('fneed' + co.id, KC(100000))));
    S.fundOffers = S.fundOffers || {};
    S.fundOffers[co.id] = makeOffers(capK(co), traction(co), amt, Math.max(amt, companyValue(co)));
    save();
    render();
    if (!S.fundOffers[co.id].length) toast('No investor bit.', true);
  };
  ACT.fundacc = p => {
    const co = getCo(p.id), o = ((S.fundOffers || {})[co.id] || [])[p.i];
    if (!o) return;
    moveCash(co, o.amt);
    co.tx.unshift({ w: S.week, a: o.amt, l: 'New shares sold to ' + o.name });
    co.holders.push({ name: o.name, pct: o.pct * co.own / 100, in: o.amt });
    co.own = Math.round(co.own * (1 - o.pct / 100) * 100) / 100;
    if (o.k === 'fund') co.flags.boardSeat = (co.flags.boardSeat || 0) + 1;
    FOUNDER().raised += o.amt;
    S.fundOffers[co.id] = [];
    note(co.name + ' raised ' + money(o.amt) + ' from ' + o.name + ' for ' + o.pct.toFixed(0) + '% in new shares.', 'good', co.id);
    save();
    render();
  };
  ACT.fundctr = p => {
    const co = getCo(p.id), L = (S.fundOffers || {})[co.id] || [], o = L[p.i];
    if (!o || o.ctr) return;
    o.ctr = 1;
    if (chance(0.25 + interest(capK(co), traction(co)) * 0.5)) {
      o.pre *= 1.2;
      o.pct = o.amt / (o.pre + o.amt) * 100;
      toast(o.name + ' accepts a higher valuation.');
    } else {
      S.fundOffers[co.id] = L.filter(x => x !== o);
      toast(o.name + ' walked away.', true);
    }
    save();
    render();
  };
  ACT.funddec = p => {
    const co = getCo(p.id), L = (S.fundOffers || {})[co.id] || [];
    S.fundOffers[co.id] = L.filter((x, i) => i !== p.i);
    save();
    render();
  };

  /* ---------- your own startups ---------- */
  const ROUNDS = ['Pre-seed', 'Seed', 'Series A', 'Series B', 'Growth'];
  const CAPN = ['', 'Low', 'Medium', 'High', 'Very high', 'Huge'];
  function foundCard(f) {
    const run = f.burn > 0 ? Math.max(0, Math.floor(f.cash / f.burn)) : 0;
    let h = '<div class="card"><div class="cchd">' + av(ini(f.name)) + '<span class="ctext"><b>' + esc(f.name) + '</b><small>' + esc(f.secn) + ' · ' + (f.st === 'live' ? ROUNDS[f.stage] : f.st === 'exit' ? 'Acquired' : 'Shut down') + '</small></span><span class="badge ' + (f.st === 'live' ? (run < 8 ? 'red' : 'amber') : f.st === 'exit' ? 'green' : 'red') + '">' + (f.st === 'live' ? run + ' wk runway' : f.st === 'exit' ? 'Exit' : 'Closed') + '</span></div>';
    if (f.st !== 'live') return h + row('You put in', nok(f.in)) + (f.exitV ? row('Sold for', nok(f.exitV)) : '') + '</div>';
    h += row('You own', f.pct.toFixed(0) + '%') + row('Valuation', nok(f.val)) + row('Cash in the company', nok(f.cash)) + row('Investor interest', intWord(interest(f.ck, clamp(f.tr + f.stage * 0.15, 0, 1)))[0]);
    (f.offers || []).forEach((o, i) => {
      h += '<div class="card offer on"><div class="cchd">' + av(ini(o.name)) + '<span class="ctext"><b>' + esc(o.name) + '</b><small>' + mshort(o.amt) + ' for ' + o.pct.toFixed(0) + '%</small></span></div><div class="dbtns">' + btn('Accept', 'facc', { id: f.id, i }, 'primary') + btn('Decline', 'fdec', { id: f.id, i }) + '</div></div>';
    });
    return h + '<div class="three">' + btn('Raise a round', 'fpitch', { id: f.id }, 'primary') + btn('Put in money', 'ftop', { id: f.id }) + btn('Shut down', 'fshut', { id: f.id }) + '</div></div>';
  }
  ACT.fpitch = p => {
    const f = FD().find(x => x.id === p.id);
    if (!f) return;
    if (f.pitchW != null && S.week - f.pitchW < 4) {
      toast('Investors need time. Try again in ' + (4 - (S.week - f.pitchW)) + ' week(s).', true);
      return;
    }
    f.pitchW = S.week;
    f.offers = makeOffers(f.ck, clamp(f.tr + f.stage * 0.15, 0, 1), Math.max(f.burn * 26, f.val * 0.3), Math.max(f.val, f.in * 1.5));
    save();
    render();
    if (!f.offers.length) toast('No investor bit. Show more traction first.', true);
  };
  ACT.facc = p => {
    const f = FD().find(x => x.id === p.id), o = f && f.offers[p.i];
    if (!o) return;
    f.cash += o.amt;
    f.val = o.pre + o.amt;
    f.pct = f.pct * (1 - o.pct / 100);
    f.burn *= 1.35;
    f.warn = 0;
    FOUNDER().raised += o.amt;
    f.offers = [];
    note(f.name + ' raised ' + money(o.amt) + ' from ' + o.name + '.', 'good');
    save();
    render();
  };
  ACT.fdec = p => {
    const f = FD().find(x => x.id === p.id);
    if (f) f.offers.splice(p.i, 1);
    save();
    render();
  };
  ACT.ftop = p => openSheet('<h2>Put in money</h2>' + inp('ftopa', 'Amount') + U.quick('ftopa', [100000, 500000, 1000000, 5000000]) + '<div class="btnrow">' + btn('Cancel', 'sheetclose', undefined, 'ghost') + btn('Put in', 'ftopgo', { id: p.id }, 'primary') + '</div>');
  ACT.ftopgo = p => {
    const f = FD().find(x => x.id === p.id), a = Math.round(U.inum('ftopa', 0));
    if (!f || !(a > 0) || liquid() < a) {
      toast('Not enough money.', true);
      return;
    }
    fromSavings(a);
    moveCash(ME, -a, 'Put money into ' + f.name);
    f.cash += a;
    f.in += a;
    f.warn = 0;
    ui.sheet = null;
    ui.inp.ftopa = '';
    save();
    render();
  };
  ACT.fshut = p => {
    const f = FD().find(x => x.id === p.id);
    if (!f) return;
    confirmThen('Shut down ' + esc(f.name) + '?', 'Your share of the cash that is left comes back to you. It counts as a failed startup.', 'Shut down', () => {
      const back = Math.max(0, f.cash) * f.pct / 100;
      if (back) {
        moveCash(ME, back, 'Closed ' + f.name);
      }
      f.st = 'failed';
      f.val = 0;
      FOUNDER().fails++;
      save();
      render();
    }, true);
  };
  function foundedWeek() {
    FD().forEach(f => {
      if (f.st !== 'live') return;
      f.cash -= f.burn;
      f.tr = clamp(f.tr + (f.q - 0.3) * 0.012 + gauss() * 0.004, 0, 1);
      if (f.cash < 0) {
        f.st = 'failed';
        f.val = 0;
        FOUNDER().fails++;
        note(f.name + ' ran out of money and shut down.', 'bad');
        news('Startup ' + f.name + ' shuts down.', 'n');
        return;
      }
      if (f.cash < f.burn * 6 && !f.warn) {
        f.warn = 1;
        addMsg({ kind: 'info', from: f.name, title: f.name + ' has about ' + Math.floor(f.cash / f.burn) + ' weeks of money left', body: 'Raise a round or put in more money, or it shuts down.', tone: 'bad', status: 'done', go: { l: 'Open', a: 'phapp', p: { n: 'startups' } } });
      }
      if (S.week < f.wNext) return;
      f.wNext = S.week + rint(20, 34);
      if (chance(clamp(f.q * 0.9 + f.tr * 0.3 - f.stage * 0.05, 0.1, 0.9))) {
        f.stage = Math.min(4, f.stage + 1);
        f.val *= rng(1.8, 3.2);
        note(f.name + ' hit its milestone and is now at ' + ROUNDS[f.stage] + ' stage.', 'good');
        if (f.stage >= 4 && chance(0.5 + f.q * 0.3)) {
          const ex = f.val * rng(1.2, 2.8), pr = ex * f.pct / 100;
          moveCash(ME, pr, 'Exit: ' + f.name);
          S.tax.gain = (S.tax.gain || 0) + Math.max(0, pr - f.in);
          f.st = 'exit';
          f.exitV = ex;
          f.val = 0;
          FOUNDER().exits++;
          note('EXIT! ' + f.name + ' was acquired. Your ' + f.pct.toFixed(0) + '% pays ' + money(pr) + '.', 'good');
          news(f.name + ' is acquired for ' + mshort(ex) + '.', 'good');
        }
      } else {
        f.val *= rng(0.6, 0.95);
        note(f.name + ' missed its milestone. The valuation fell.', 'bad');
      }
    });
  }
  /* your own startups: Investing › Startups › My startups (ui/phone/invest.js) and New company › Start a startup */
  window.foundedPage = function () {
    const f = FOUNDER(), L = FD();
    return '<div class="card">' + row('Your record as founder', f.exits + ' exit' + (f.exits === 1 ? '' : 's') + ' · ' + f.fails + ' failure' + (f.fails === 1 ? '' : 's')) + row('Raised from investors', nok(f.raised || 0)) + '<span class="tipt">Investors back founders with a record. A first-timer asking for a capital-heavy venture finds few takers.</span>' + btn('＋ Found a startup', 'found', undefined, 'primary wide') + '</div>' + L.slice().reverse().map(foundCard).join('');
  };

  /* ---------- the big meeting (late game) ---------- */
  function bigWeek() {
    if (S.bigOff && S.week >= S.bigOff.exp) S.bigOff = null;
    if (S.bigOff || S.week % 13 !== 7 || netWorth().total < KC(40e6) || !chance(0.35)) return;
    const nw = netWorth().total;
    const o = { id: uid(), tgt: brandCoName(CC(), pick(['venue', 'prod', 'logi', 'rent'])).split(' ')[0] + ' Group', seller: personName(), sellerCo: brandCoName(CC(), 'fin'), pct: pick([25, 30, 40, 49]), price: Math.round(nw * rng(0.5, 1.1) / 1e5) * 1e5, yld: rng(0.06, 0.1), w: S.week, exp: S.week + 3, ctr: 0 };
    S.bigOff = o;
    addMsg({ kind: 'info', from: o.seller, title: 'Big meeting: ' + o.pct + '% of ' + o.tgt, body: 'An offer is on the table for 3 weeks.', tone: 'good', status: 'done', go: { l: 'Go to the meeting', a: 'go', p: { n: 'bigmeet' } } });
  }
  V.titles.bigmeet = 'Big meeting';
  V.heads.bigmeet = () => ({ t: 'Big meeting', sub: 'Year ' + (Math.floor(S.week / 52) + 1), right: '<span class="badge blue">Only you attend</span>' });
  const prow = (nm, sub, right) => '<div class="lrow">' + av(ini(nm)) + '<span class="ctext"><b>' + esc(nm) + '</b><small>' + sub + '</small></span>' + (right ? '<span class="badge">' + right + '</span>' : '') + '</div>';
  V.bigmeet = function () {
    const o = S.bigOff;
    const stakes = STK();
    if (!o) return '<div class="calm">No big offer on the table right now. They come when your net worth is large enough.</div>' + (stakes.length ? '<h2 class="sec">Your stakes</h2><div class="lrows">' + stakes.map(x => prow(x.name, x.pct + '% · profit share ' + mshort(x.val * x.yld) + ' a year', mshort(x.val))).join('') + '</div>' : '');
    const nw = netWorth();
    const bankMax = Math.round(o.price * 0.6);
    const bank = (S.cos.find(c => c.type === 'bank' && c.st === 'open') || {}).name || brandCoName(CC(), 'fin').split(' ')[0] + ' Bank';
    const g = S.group || {};
    const lead = g.ceo && S.npcs[g.ceo.npc] ? [S.npcs[g.ceo.npc].name, 'Group CEO · reports on your behalf'] : g.regional && g.regional[0] && S.npcs[g.regional[0].npc] ? [S.npcs[g.regional[0].npc].name, 'Regional manager · reports on your behalf'] : null;
    let h = '<div class="card sense"><b>Offer to buy ' + o.pct + '% of ' + esc(o.tgt) + '</b><span class="tipt">Seller: ' + esc(o.sellerCo) + '. Offer is open for ' + Math.max(0, o.exp - S.week) + ' more week(s).</span><div class="duo"><div><span>Price</span><b>' + mshort(o.price) + '</b></div><div><span>Yearly profit share</span><b class="pos">' + mshort(o.price * o.yld) + '</b></div></div></div>';
    h += '<h2 class="sec">At the table</h2><div class="lrows">' + prow(o.seller, esc(o.sellerCo) + ' · seller') + prow(bank, 'Would finance up to 60%', mshort(bankMax)) + (lead ? prow(lead[0], lead[1]) : '') + '</div>';
    h += '<h2 class="sec">Your numbers</h2><div class="tri"><div><span>Net worth</span><b>' + mshort(nw.total) + '</b></div><div><span>Cash</span><b>' + mshort(S.cash) + '</b></div><div><span>Debt</span><b class="neg">' + mshort(nw.debt) + '</b></div></div>';
    h += '<h2 class="sec">Decide</h2><div class="dbtns three3">' + btn('Accept and borrow', 'bigacc', undefined, 'primary') + (o.ctr ? '' : btn('Counter ' + mshort(o.price * 0.9), 'bigctr')) + btn('Walk away', 'bigwalk') + '</div>';
    if ((policy() + 0.045) * bankMax > o.price * o.yld) h += '<div class="card probcard"><p>If rates rise 2 points, your interest cost would be higher than the profit share.</p></div>';
    return h;
  };
  ACT.bigacc = () => {
    const o = S.bigOff;
    if (!o) return;
    const borrow = Math.min(Math.round(o.price * 0.6), Math.max(0, Math.round(o.price - Math.max(0, liquid() - KC(100000)))));
    const own = o.price - borrow;
    if (liquid() < own) {
      toast('You need ' + money(own) + ' of your own money.', true);
      return;
    }
    confirmThen('Buy ' + o.pct + '% of ' + esc(o.tgt) + '?', 'You pay ' + money(own) + ' yourself and borrow ' + money(borrow) + ' over 10 years.', 'Buy', () => {
      if (borrow > 0) {
        const r = policy() + 0.02;
        S.loans.push({ id: uid(), kind: 'mort', name: 'Acquisition loan: ' + o.tgt, bal: borrow, amt0: borrow, margin: 0.02, pay: annuity(borrow, r, 120), termM: 120, co: 0, w0: S.week, guar: 0, bank: 0 });
        gainMe(borrow, 'Acquisition loan');
      }
      payMe(o.price, 'Bought ' + o.pct + '% of ' + o.tgt);
      STK().push({ id: uid(), name: o.tgt, pct: o.pct, val: o.price, yld: o.yld, w0: S.week });
      S.bigOff = null;
      note('You bought ' + o.pct + '% of ' + o.tgt + '.', 'good');
      save();
      render();
    }, true);
  };
  ACT.bigctr = () => {
    const o = S.bigOff;
    if (!o || o.ctr) return;
    o.ctr = 1;
    if (chance(0.45)) {
      o.price = Math.round(o.price * 0.9 / 1e5) * 1e5;
      toast(o.seller + ' accepts your counter.');
    } else {
      S.bigOff = null;
      toast(o.seller + ' walked away from the deal.', true);
    }
    save();
    render();
  };
  ACT.bigwalk = () => {
    S.bigOff = null;
    save();
    U.back();
  };
  function stakesWeek() {
    STK().forEach(x => {
      x.val = Math.max(0, x.val * (1 + 0.003 + gauss() * 0.015));
      if (isMonthEnd(S.week)) {
        const a = Math.round(x.val * x.yld / 12);
        moveCash(ME, a, 'Profit share: ' + x.name);
      }
    });
  }

  /* ---------- worker discipline: raise, warn, lay off ---------- */
  const justified = s => (s.warn || 0) >= 2 || s.flag === 'theft';
  const compRange = s => [s.wage * 2, s.wage * 4];
  function tenure2(s) {
    const wk = Math.max(0, S.week - (s.w0 || S.week));
    return wk >= 52 ? Math.floor(wk / 52) + ' yr' : wk >= 9 ? Math.round(wk / 4.35) + ' months' : wk + ' weeks';
  }
  V.titles.staffman = 'Profile';
  V.heads.staffman = p => {
    const co = getCo(p.id), s = co && co.staff.find(x => x.id === p.s), n = s && S.npcs[s.id];
    return n ? { t: n.name, sub: esc(ROLES[s.role][0]) + ' · ' + tenure2(s) + ' · ' + money(s.wage), right: s.flag ? '<span class="badge red">PROBLEM</span>' : '' } : {};
  };
  V.staffman = function (p) {
    const co = getCo(p.id), s = co && co.staff.find(x => x.id === p.s);
    if (!s) return '<div class="calm">This person no longer works here.</div>';
    const bd = BD[co.type];
    const team = co.staff.filter(x => x.role === s.role);
    const avg = sum(team, x => staffSkill(x)) / Math.max(1, team.length);
    const per = co.lastW && co.lastW.units ? co.lastW.units / Math.max(1, co.staff.length) : 0;
    const mine = per * staffSkill(s) / Math.max(1, avg);
    let h = (CT.staffProfile ? CT.staffProfile(co, s) : '') + '<h2 class="sec">Record</h2><div class="card">' + row('Late this quarter', '<span class="' + (s.late ? 'neg' : '') + '">' + (s.late || 0) + (s.late === 1 ? ' time' : ' times') + '</span>') + row('Client complaints', '<span class="' + (s.cmp ? 'neg' : '') + '">' + (s.cmp || 0) + '</span>') + (window.staffSalesRow ? window.staffSalesRow(co, s, bd, per, mine) : row(esc(capF(unitPl(bd.unit, 2))) + ' per week', (Math.round(mine * 10) / 10) + ' · average here ' + (Math.round(per * 10) / 10))) + row('Warnings on file', s.warn || 0) + row('Notice period', s.w0 < S.week - 52 ? '2 months' : '1 month') + '</div>';
    h += '<h2 class="sec">What you can do</h2>';
    const f = ui.rf || 0.06;
    h += '<div class="card"><div class="bhead"><b>Give a raise</b><span class="badge blue">Keeps good workers</span></div>' + chips([[0.03, '+3%'], [0.06, '+6%'], [0.1, '+10%']], f, 'rfset') + '<span class="tipt">Cost +' + money(s.wage * f) + ' a month plus charges.' + (s.flag === 'late' ? ' Does not fix lateness.' : '') + '</span>' + btn('Give +' + Math.round(f * 100) + '%', 'doraise', { id: co.id, s: s.id, f }, 'wide') + '</div>';
    h += '<div class="card"><div class="bhead"><b>Written warning</b><span class="badge amber">' + (s.warn ? s.warn + ' on file' : 'First step') + '</span></div><span class="tipt">Creates a record. A second warning later makes a firing easier to defend.</span>' + btn('Issue warning', 'warnstaff', { id: co.id, s: s.id }, 'wide') + '</div>';
    if (bd.crs && bd.crs.length) h += '<div class="card"><div class="bhead"><b>Send on a course</b><span class="badge">from ' + mshort(Math.min.apply(null, bd.crs.map(c => c[2]))) + '</span></div><span class="tipt">Might help, might do nothing.</span>' + btn('Choose a course', 'coursesheet', { id: co.id, s: s.id }, 'wide') + '</div>';
    const just = justified(s), cr = compRange(s);
    h += '<div class="card' + (just ? '' : ' probcard') + '"><div class="bhead"><b>Let them go</b><span class="badge ' + (just ? 'green' : 'red') + '">' + (just ? 'Documented' : 'Legal rules') + '</span></div><span class="tipt">' + (just ? 'Two warnings are on file, so dismissal for cause is easy to defend. No severance.' : 'Without documented warnings they can claim unfair dismissal. Cost: notice pay plus possible compensation of ' + mshort(cr[0]) + ' to ' + mshort(cr[1]) + '.') + '</span>' + btn('Start process', 'firestaff', { id: co.id, s: s.id }, 'wide') + '</div>';
    h += '<h2 class="sec">Layoffs for the whole company</h2>' + layoffCard(co);
    return h;
  };
  ACT.rfset = p => {
    ui.rf = p.v;
    render();
  };
  ACT.warnstaff = p => {
    const co = getCo(p.id), s = co && co.staff.find(x => x.id === p.s);
    if (!s) return;
    s.warn = (s.warn || 0) + 1;
    s.warnW = S.week;
    if (s.flag && chance(0.35)) {
      s.flag = null;
      toast('The warning worked. ' + S.npcs[s.id].name.split(' ')[0] + ' has improved.');
    } else toast('Warning on file (' + s.warn + ').');
    save();
    render();
  };
  ACT.firestaff = p => {
    const co = getCo(p.id), s = co && co.staff.find(x => x.id === p.s);
    if (!s) return;
    const n = S.npcs[s.id], just = justified(s), mo = s.w0 < S.week - 52 ? 2 : s.w0 < S.week - 13 ? 1 : 0.5, sev = s.wage * mo * (1 + CC().empNI), cr = compRange(s);
    confirmThen('Let ' + esc(n.name) + ' go?', just ? 'Dismissal for cause with warnings on file. No severance.' : 'Notice pay is about ' + money(sev) + '. Without documented warnings ' + esc(n.name.split(' ')[0]) + ' may claim unfair dismissal (' + mshort(cr[0]) + '–' + mshort(cr[1]) + ').', 'Let go', () => {
      const unfair = !just && chance(s.flag ? 0.35 : 0.55);
      fireStaff(co, s.id, just ? 1 : 0);
      if (unfair) {
        const c = rnl(rng(cr[0], cr[1]), 100);
        payCo(co, c, 'fine', 'Unfair dismissal settlement');
        note(n.name + ' claimed unfair dismissal. ' + co.name + ' paid ' + money(c) + ' in compensation.', 'bad', co.id);
      }
      save();
      if (ui.view.n === 'staffman') U.back(); else render();
    }, true);
  };
  function layoffCard(co) {
    const v = ui.lo || '1';
    const n = v === '10' ? Math.max(1, Math.round(co.staff.length * 0.1)) : Math.min(co.staff.length, +v);
    const pickL = co.staff.slice().sort((a, b) => staffSkill(a) - staffSkill(b)).slice(0, n);
    const saves = sum(pickL, s => s.wage * (1 + CC().empNI));
    const sev = sum(pickL, s => s.wage * (s.w0 < S.week - 52 ? 2 : s.w0 < S.week - 13 ? 1 : 0.5) * (1 + CC().empNI));
    return '<div class="card"><div class="kv"><span>Cut staff to save costs</span><b>Choose how many</b></div>' + chips([['1', '1 person'], ['3', '3 people'], ['10', '10%']], v, 'loset') + row('Saves per month', '<span class="pos">' + nok(saves) + '</span>') + row('Severance now', '<span class="neg">' + nok(sev) + '</span>') + row('Who goes', esc(pickL.map(s => S.npcs[s.id] ? S.npcs[s.id].name.split(' ')[0] : '').join(', ') || 'Nobody')) + btn('Lay off ' + n, 'logo', { id: co.id, n }, 'wide') + '</div>';
  }
  ACT.loset = p => {
    ui.lo = p.v;
    render();
  };
  ACT.logo = p => {
    const co = getCo(p.id);
    if (!co || !co.staff.length) return;
    confirmThen('Lay off ' + p.n + '?', 'The weakest performers go and get severance. Morale drops for the rest.', 'Lay off', () => {
      co.staff.slice().sort((a, b) => staffSkill(a) - staffSkill(b)).slice(0, p.n).forEach(s => fireStaff(co, s.id, 0));
      co.mood = Math.max(0, (co.mood != null ? co.mood : 60) - 6);
      note(co.name + ' laid off ' + p.n + ' (' + (p.n === 1 ? 'person' : 'people') + ').', 'n', co.id);
      save();
      if (ui.view.n === 'staffman') U.back(); else render();
    }, true);
  };
  function staffTrack() {
    S.cos.forEach(co => {
      if (co.st !== 'open') return;
      const q4 = Math.floor(S.week / 13);
      co.staff.forEach(s => {
        if (s.qtr !== q4) {
          s.qtr = q4;
          s.late = 0;
          s.cmp = 0;
        }
        if (s.flag === 'late' ? chance(0.45) : chance(0.01)) s.late = (s.late || 0) + 1;
        if ((s.flag === 'conflict' || s.flag === 'lazy' || s.flag === 'theft') && chance(0.18)) s.cmp = (s.cmp || 0) + 1;
        if (s.flag && s.warnW && S.week - s.warnW <= 8 && chance(0.05)) {
          s.flag = null;
          if (S.npcs[s.id]) note(S.npcs[s.id].name + ' has improved after the warning.', 'good', co.id);
        }
      });
    });
  }

  /* ---------- price moves ---------- */
  const rivRun = r => Math.round(6 + r.size * 8 + hrng(String(r.id))() * 4);
  const rivPrice = (co, r) => ticketEff(co, BD[co.type]) / priceMult(co) * (window.R18 && r.pm16 ? R18.effP(r) : (0.82 + hrng(S.seed + ':rp:' + r.id)() * 0.4));
  V.titles.pricemoves = 'Price moves';
  V.heads.pricemoves = p => {
    const co = getCo(p.id);
    return { t: 'Price moves', sub: co ? esc(co.name) + ' · ' + esc(cityOf(co.city).name) : '' };
  };
  ACT.pwgo = p => {
    const co = getCo(p.id);
    confirmThen('Start a price war?', 'Your prices go to the bottom for ' + p.w + ' weeks. It costs you revenue, and it may draw the competition authority.', 'Start', () => {
      co.flags.pw = { rid: p.r, end: S.week + p.w, prev: co.price, odds: p.odds, share: p.share, loss: 0 };
      co.price = -3;
      save();
      render();
    }, true);
  };
  ACT.pwend = p => {
    const co = getCo(p.id), pw = co.flags.pw;
    if (!pw) return;
    co.price = pw.prev;
    delete co.flags.pw;
    save();
    render();
  };
  function pwWeek() {
    S.cos.forEach(co => {
      const pw = co.flags && co.flags.pw;
      if (!pw) return;
      if (co.st !== 'open') {
        delete co.flags.pw;
        return;
      }
      co.price = -3;
      pw.loss = (pw.loss || 0) + Math.round(((co.lastW && co.lastW.rev) || 0) * 0.3);
      if (S.week < pw.end) return;
      const rs = rivalsOf(co), r = rs.find(x => x.id === pw.rid);
      co.price = pw.prev;
      delete co.flags.pw;
      if (r && chance(pw.odds)) {
        const m = ensureMk(co);
        m.riv = (m.riv || []).filter(x => x !== r);
        m.n = Math.max(1, m.n - 1);
        co.aware = Math.min(100, co.aware + 6);
        note(r.name + ' could not survive the price war and closed. Its customers are up for grabs.', 'good', co.id);
        news(r.name + ' closes after a price war.', 'n');
      } else note((r ? r.name : 'The rival') + ' survived the price war.', 'bad', co.id);
      if (pw.share >= 0.35 && chance(0.3)) {
        const f = Math.round(Math.max(KC(50000), (co.bk.y.rev || 0) * 0.05));
        payCo(co, f, 'fine', 'Competition fine');
        co.rep = clamp(co.rep - 5, 0, 100);
        addMsg({ kind: 'info', from: '{auth:comp}', title: 'Abuse of a dominant position at ' + co.name, body: 'The competition authority fined ' + co.name + ' ' + money(f) + ' for pricing to push out a rival.', co: co.id, tone: 'bad', status: 'done' });
      }
    });
  }

  /* ---------- crisis centre ---------- */
  function crisisList() {
    return S.inbox.filter(m => m.status === 'open' && m.opts && m.opts.length && (m.tone === 'bad' || m.kind === 'decision') && m.act !== 'mprop').sort((a, b) => (a.exp || 999) - (b.exp || 999));
  }
  window.crisisCount = () => (S ? crisisList().length : 0);
  V.titles.crisis = 'Crisis centre';
  V.heads.crisis = () => {
    const n = crisisList().length;
    return { t: 'Crisis centre', right: n ? '<span class="badge red">' + n + ' open</span>' : '' };
  };
  V.crisis = function () {
    const Lc = crisisList();
    if (!Lc.length) return '<div class="calm">No crises right now.</div>';
    return Lc.map(m => {
      const co = getCo(m.co), left = m.exp ? m.exp - S.week : null;
      return '<div class="card' + (left != null && left <= 1 ? ' hot' : '') + '"><div class="bhead"><b>' + esc(m.title) + '</b>' + (left != null ? '<span class="badge ' + (left <= 1 ? 'red' : 'amber') + '">' + (left <= 0 ? 'Now' : 'In ' + left + ' wk') + '</span>' : '') + '</div>' + (m.body ? '<span class="tipt">' + esc(m.body) + '</span>' : '') + (co ? '<small>' + esc(co.name) + '</small>' : '') + '<div class="chips">' + m.opts.map((o, i) => '<button class="btn chip' + (m.rec === i ? ' primary' : '') + '" data-a="msgpick" data-p="' + P({ id: m.id, i }) + '">' + esc(o.l) + '</button>').join('') + '</div>' + (m.opts.some(o => o.fx && fxText(o.fx)) ? '<small>' + esc(m.opts.map(o => o.l + ': ' + (fxText(o.fx || {}) || 'no direct cost')).join(' · ')) + '</small>' : '') + '</div>';
    }).join('');
  };

  /* ---------- marketing: new clients and cost per client ---------- */
  addStep('mktWeek.after', 20, 'new clients and cost per client', (co, bd) => {
    {
      const mi = monthIdx(S.week);
      if (!co.mks || co.mks.m !== mi) co.mks = { m: mi, n: 0, c: 0, ch: {}, prev: co.mks ? { n: co.mks.n, c: co.mks.c } : null };
      const sp = mktCost(co);
      const dpm = co.dbg && co.dbg.dp && co.dbg.dp.marketing ? co.dbg.dp.marketing : 1 + co.aware / 200;
      const att = sp > 0 ? clamp(1 - 1 / Math.max(1, dpm), 0, 0.6) : 0;
      const nw = ((co.lastW && co.lastW.units) || 0) * att * 0.5;
      co.mks.n += nw;
      co.mks.c += sp;
      const tot = sum(Object.keys(co.mkt), k => co.mkt[k].b * (CH[k] ? CH[k].eff : 1)) || 1;
      Object.keys(co.mkt).forEach(k => {
        co.mks.ch[k] = (co.mks.ch[k] || 0) + nw * co.mkt[k].b * (CH[k] ? CH[k].eff : 1) / tot;
      });
    }
  });
  CT.marketing = pipeView('CT.marketing', CT.marketing, 2); /* CT.marketing: the screen above, then the steps below and in later files */
  addStep('CT.marketing', 10, 'selling_startups_and_crisis CT.marketing', (co, bd, h) => {
    const st = co.mks && co.mks.m === monthIdx(S.week) ? co.mks : null;
    const n = st ? Math.round(st.n) : 0;
    const chs = st ? Object.keys(st.ch).filter(k => co.mkt[k] && co.mkt[k].b) : [];
    const top = '<div class="card"><div class="kv bigkv"><span>Monthly budget</span><b>' + money(mktCost(co) * 4.33) + '</b></div>' + row('New clients this month', (n ? '~' : '') + n) + row('Cost per client', n ? npadL(st.c / n) : '—') + (co.mks && co.mks.prev ? row('Last month', '~' + Math.round(co.mks.prev.n) + ' new clients') : '') + chs.map(k => row(esc(CH[k].n) + ' · clients won', '~' + Math.round(st.ch[k]))).join('') + (mktCost(co) > 0 ? '<div class="kv"><span>Charged to the company account</span><b><span class="badge green">Auto-renew on</span></b></div>' : '') + '</div>';
    return top + h.replace(/<div class="card"><div class="kv bigkv"><span>Weekly budget<\/span><b>[\s\S]*?<\/b><\/div>/, '<div class="card">');
  });

  /* ---------- weekly hooks and net worth ---------- */
  addStep('week.after', 30, 'sales of companies, your startups, big meetings, stakes, staff, price wars', () => {
    if (S && !S.over) {
      salesWeek();
      foundedWeek();
      bigWeek();
      stakesWeek();
      staffTrack();
      pwWeek();
    }
  });
  addStep('netWorth', 20, 'startups you founded and shares you hold', r => {
    if (!S) return;
    const f = sum(FD().filter(x => x.st === 'live'), x => x.val * x.pct / 100) + sum(STK(), x => x.val);
    if (f) {
      r.cos += f;
      r.total += f;
    }
  });
  ACT.cofin = pipeView('ACT.cofin', ACT.cofin, 1);
  addStep('ACT.cofin.around', 10, 'selling the company opens the sale screen', (p, next) => (p && p.s === 'sell' ? go('sale', { id: p.id }) : next()));
  ACT.codeal = pipeView('ACT.codeal', ACT.codeal, 1);
  addStep('ACT.codeal.around', 10, 'selling the company opens the sale screen', (p, next) => (p && p.s === 'sell' ? go('sale', { id: p.id }) : next()));
  window.__r5 = { salesWeek, bigWeek, foundedWeek, pwWeek, mprops };


/* ===== Lifestyle (round 54, round 56): what you own matters, and can earn.
   Round 54: a home people write about, a private jet, a yacht, a serious car or watch each add a little to how well
   known you are (fame decides who applies to you and what they ask for). A jet means you fly in to meetings abroad
   yourself, so starting abroad costs less; a serious car or watch makes owners take your offers more seriously.
   Round 56: things you own can work for you, and carry real risks and taxes.
   - Uses: charter out a jet or yacht (a charter firm runs it; income after their fee, more wear), rent out a home
     (you no longer rest there), lend art to a museum (better known, the work gains provenance; it stays there half a
     year). Income is capital income in your yearly tax.
   - Risks: damage and theft happen; upkeep includes insurance, so you pay the excess and the insurer the rest.
   - Through a company: a car or jet bought by one of your limited companies. The company pays it, writes it down and
     pays its upkeep (all costs before company tax); you pay benefit-in-kind tax on its private use each year, by
     the country's rule of thumb (BIK). A car far too big for the company draws the tax office.
   - Lending: the bank lends against art, watches, homes, boats and jets (loan kind 'lomb', engine/money/money.js).
     Sell what the loan stands on and the bank wants its share back.
   - Perks with effects: a home you live in lets you recover from long weeks; dinners on your yacht warm the people
     you know and sometimes bring a lead.
   Upkeep is charged by the luxury collection itself (ui/screens/mockup.js); it is a company cost for company items. ===== */
window.LIFE = window.LIFE || {};
(function () {
  'use strict';
  const LIFE = window.LIFE;
  const LX = () => (window.LUX47 || {}).LUXI || {};
  const own = () => (S && S.lux) || [];
  const it = x => LX()[x.k] || null;
  const has = f => own().some(x => { const i = it(x); return i && f(i, x); });
  const livesIn = () => has((i, x) => i.cat === 'homes' && !x.co && x.use !== 'rent');
  function perks() {
    const home = livesIn(), jet = has(i => i.cat === 'jets'), yacht = has(i => i.cat === 'yachts');
    const serious = has(i => (i.cat === 'cars' && i.price >= 2500000) || (i.cat === 'watches' && i.price >= 1000000));
    const museum = has((i, x) => i.cat === 'art' && x.use === 'museum');
    return { home, jet, yacht, serious, museum, fame: (home ? 3 : 0) + (jet ? 2 : 0) + (yacht ? 2 : 0) + (serious ? 1 : 0) + (museum ? 1 : 0) };
  }
  LIFE.perks = perks;
  addStep('fame', 10, 'what you own adds a little to how known you are', f => f + perks().fame);
  addStep('window.abroadFee', 20, 'a private jet: you fly in to the meetings yourself', v => perks().jet && v > 0 ? rnl(v * 0.85, 1000) : v);
  /* owners take a serious buyer more seriously: the offer is judged a little better, the price stays the same */
  addStep('proposeBuy.terms', 30, 'a serious car or watch: owners take your offer seriously', (co, r, t) => { if (perks().serious) { t.mult *= 1.02; t.scale *= 1.02; } });

  /* ---------- uses ---------- */
  /* yearly income as a share of the price, before tax; wear: extra loss of value a year */
  const USE = {
    charter: { cats: { jets: 1, yachts: 1 }, n: 'Charter it out', y: { jets: 0.075, yachts: 0.11 }, fee: 0.3, wear: 0.02, d: 'A charter firm flies or sails it for paying guests and keeps 30%. More wear, and it is not always free when you want it.' },
    rent: { cats: { homes: 1 }, n: 'Rent it out', y: { homes: 0.032 }, fee: 0.12, wear: 0.004, d: 'Let it to tenants through an agent who keeps 12%. You no longer stay there yourself.' },
    museum: { cats: { art: 1 }, n: 'Lend it to a museum', y: {}, fee: 0, wear: -0.02, d: 'On show for half a year: your name on the label, and the work gains provenance. It cannot be sold until it comes back.' }
  };
  const usesFor = i => Object.keys(USE).filter(k => USE[k].cats[i.cat]);
  /* the charter season: the warm months (the southern half of the world has them round the new year) */
  const SOUTH = { AU: 1, BR: 1 };
  const inSeason = () => { const m = monthIdx(S.week) % 12; return SOUTH[S.country] ? (m >= 10 || m <= 2) : (m >= 4 && m <= 8); };
  function weekIncome(x, i) {
    const u = USE[x.use];
    if (!u || !u.y[i.cat]) return 0;
    const seas = i.cat === 'yachts' ? (inSeason() ? 2.4 : 0) : 1; /* yachts earn their year in the warm months */
    return Math.round(x.val * u.y[i.cat] * (1 - u.fee) * seas / 52);
  }
  LIFE.weekIncome = (x) => { const i = it(x); return i ? weekIncome(x, i) : 0; };
  /* risks a year, insured: damage costs the excess; theft of art or watches is paid out at the value */
  const RISK = { cars: [0.03, 'damage'], art: [0.004, 'theft'], watches: [0.006, 'theft'], yachts: [0.02, 'damage'], jets: [0.01, 'damage'], homes: [0.012, 'damage'] };
  const excess = v => Math.max(KC(10000), Math.round(v * 0.02));
  /* benefit-in-kind on a company car (share of the price a year, electric cars about 60% of it) and on a company jet */
  const BIK = { NO: 0.3, SE: 0.3, UK: 0.37, DE: 0.12, NL: 0.22, FR: 0.3, ES: 0.2, PL: 0.1, LT: 0.15, US: 0.25, CA: 0.24, AU: 0.2, JP: 0.2, KR: 0.2, BR: 0.2, CH: 0.11, MX: 0.2, AE: 0, IT: 0.25, DK: 0.25, FI: 0.2, IE: 0.3, SG: 0.15 };
  const EV = { c1: 1, c15: 1 };
  const bikOf = (x, i) => i.cat === 'jets' ? 0.08 : (BIK[S.country] || 0.25) * (EV[x.k] ? 0.6 : 1);
  const DEP = { cars: 0.2, jets: 0.1 }; /* written down each year in the company's books, on the book value */
  LIFE.bikYear = x => { const i = it(x); return i && x.co ? Math.round(x.price * bikOf(x, i)) : 0; };

  addStep('week.after', 12, 'what you own: uses, wear, risks, company items and benefit tax', () => {
    if (!S || S.over || !own().length) return;
    const gone = [];
    let inc = 0;
    own().forEach(x => {
      const i = it(x);
      if (!i) return;
      const co = x.co && getCo(x.co);
      if (x.co && (!co || co.st === 'sold' || co.st === 'bust')) { x.co = 0; x.bv = 0; } /* the company is gone: the item is yours */
      /* use */
      const u = USE[x.use];
      if (u) {
        if (u.wear) x.val = Math.max(i.price * 0.05, Math.round(x.val * (1 - u.wear / 52)));
        const w = weekIncome(x, i);
        if (w > 0) { if (co) coIn(co, w, 'rev', (x.use === 'rent' ? 'Rent: ' : 'Charter: ') + i.n); else inc += w; }
        if (x.use === 'museum' && x.until && S.week >= x.until) { x.use = null; x.until = 0; info('The museum', i.n + ' is back', 'The exhibition has closed and the work is back with you. It is better known now.', 0, 'good'); }
      }
      /* company items: written down, and the benefit is taxed as your salary */
      if (co) {
        const d = Math.round((x.bv || 0) * (DEP[i.cat] || 0.1) / 52);
        if (d > 0) { bk(co, 'dep', d); x.bv -= d; }
        S.tax.wage = (S.tax.wage || 0) + Math.round(x.price * bikOf(x, i) / 52);
      }
      /* risks */
      const rk = RISK[i.cat];
      if (rk && chance(rk[0] * (x.use === 'charter' ? 1.8 : x.use === 'rent' ? 1.5 : 1) / 52)) {
        if (rk[1] === 'theft') {
          const pay = Math.round(x.val - excess(x.val));
          gone.push(x.id);
          if (co) coIn(co, pay, null, 'Insurance: ' + i.n); else gainMe(pay, 'Insurance: ' + i.n + ' stolen');
          info('Your insurer', i.n + ' was stolen', 'The police have not found it. The insurer pays ' + money(pay) + ', the value less the excess.', 0, 'bad');
        } else {
          const ex = excess(x.val);
          if (co) payCo(co, ex, 'oth', 'Insurance excess: ' + i.n); else payMe(ex, 'Insurance excess: ' + i.n);
          info('Your insurer', 'Damage to ' + i.n, (i.cat === 'homes' ? 'A water leak' : i.cat === 'cars' ? 'A scrape in a car park' : 'Damage at the marina') + '. Repaired; you paid the excess of ' + money(ex) + '.', 0, 'bad');
        }
      }
    });
    if (gone.length) S.lux = own().filter(x => gone.indexOf(x.id) < 0);
    if (gone.length || own().some(x => x.co)) syncBV();
    if (inc > 0) { gainMe(inc, 'Charter and rent'); S.tax.int = (S.tax.int || 0) + inc; }
    /* the tax office looks at a company car far too big for the company */
    if (isYearEnd(S.week)) own().filter(x => x.co).forEach(x => {
      const co = getCo(x.co), i = it(x);
      const rev = co && co.bk && co.bk.y ? co.bk.y.rev || 0 : 0;
      if (co && rev < x.price * 1.5 && chance(0.35)) {
        const fine = rnl(x.price * (DEP[i.cat] || 0.1) * 0.5, 1000);
        payCo(co, fine, 'fine', 'Tax office: ' + i.n);
        info('The tax office', 'A company ' + (i.cat === 'jets' ? 'jet' : 'car') + ' too big for ' + co.name, 'Sales of ' + money(rev) + ' a year do not need a ' + money(x.price) + ' ' + (i.cat === 'jets' ? 'jet' : 'car') + '. Part of the write-down is refused: ' + money(fine) + ' in back tax and a surcharge.', co.id, 'bad');
      }
    });
    /* a loan against the collection: if what it stands on is worth less, the bank wants the difference back */
    const L = S.loans.filter(l => !l.co && l.kind === 'lomb');
    if (L.length) {
      const owed = sum(L, l => l.bal), cap = collateral() * 1.1;
      if (owed > cap + KC(1000)) {
        const due = Math.round(Math.min(owed - cap * 0.95, Math.max(0, S.cash)));
        if (due > 0) {
          let left = due;
          L.forEach(l => { const a = Math.min(l.bal, left); l.bal -= a; left -= a; });
          payMe(due, 'Margin call: loan against your collection');
          S.loans = S.loans.filter(l => l.bal > 1);
          info('Your bank', 'The bank wants its share back', 'What your loan stands on is now worth less than the loan allows. ' + money(due) + ' was taken from your account to bring it back in line.', 0, 'bad');
        }
      }
    }
  });
  /* a home you live in: you recover from long weeks faster (after the weekly tiredness, owner_hours_clients_assistants.js) */
  addStep('week.after', 41, 'a home of your own: rest', () => { if (S && S.fat > 0 && livesIn()) S.fat = Math.max(0, S.fat - 4); });

  /* ---------- lending against what you own ---------- */
  const LTV = { art: 0.4, watches: 0.5, homes: 0.6, yachts: 0.3, jets: 0.3 };
  function collateral() { return own().filter(x => !x.co).reduce((t, x) => { const i = it(x); return t + (i && LTV[i.cat] ? x.val * LTV[i.cat] : 0); }, 0); }
  addStep('collateral', 10, 'art, watches, homes, boats and jets', v => v + collateral());

  /* ---------- through a company ---------- */
  function syncBV() { S.cos.forEach(c => { c.luxBV = Math.round(sum(own().filter(x => x.co === c.id), x => x.bv || 0)); }); }
  const coFor = i => liveCos().filter(c => c.st === 'open' && c.form === 'AS' && c.type !== 'hold' && c.country === S.country);
  function buyVia(co, i) {
    if (co.cash < i.price) return 'cash';
    moveCash(co, -i.price);
    co.tx.unshift({ w: S.week, a: -i.price, l: 'Bought: ' + i.n });
    own().push({ id: uid(), k: i.id, price: i.price, val: i.price, w: S.week, co: co.id, bv: i.price });
    syncBV();
    return 'ok';
  }
  LIFE.buyVia = buyVia;

  /* ---------- a dinner on your yacht ---------- */
  function dinner() {
    const y = own().filter(x => { const i = it(x); return i && i.cat === 'yachts'; }).sort((a, b) => b.val - a.val)[0];
    if (!y) return 'none';
    if (S.din56 && S.week - S.din56 < 4) return 'wait';
    const cost = Math.max(KC(15000), Math.round(y.val * 0.002));
    if (S.cash < cost) return 'cash';
    payMe(cost, 'Dinner on the yacht');
    S.din56 = S.week;
    const R = window.R31 && R31.roster ? R31.roster().filter(c => c.role !== 'Executives') : [];
    const guests = R.sort((a, b) => (a.rel || 0) - (b.rel || 0)).slice(0, 3);
    guests.forEach(c => { try { R31.bumpRel(c, 6); } catch (e) { } });
    let lead = '';
    const riv = guests.find(c => c.r && !c.r.listed);
    if (riv && chance(0.25)) { riv.r.listed = true; lead = ' Over dessert, ' + riv.name + ' let slip that ' + riv.org.replace('Owner of ', '') + ' could be for sale.'; }
    info('Dinner on the yacht', guests.length ? guests.map(c => c.name.split(' ')[0]).join(', ') + ' came aboard' : 'A quiet evening on board', (guests.length ? 'They will remember the evening.' : 'You need people you know to invite.') + lead, 0, 'good');
    return 'ok';
  }
  LIFE.dinner = dinner;

  /* ---------- Aurum: manage what you own; buy through a company ---------- */
  const useLine = x => {
    const i = it(x); if (!i) return '';
    const w = weekIncome(x, i);
    const t = x.use === 'charter' ? 'Chartered out' : x.use === 'rent' ? 'Rented out' : x.use === 'museum' ? 'At the museum until ' + dateStr(x.until || S.week) : window.PK58 ? PK58.lentLine(x) : '';
    return (x.co ? 'Owned by ' + esc((getCo(x.co) || {}).name || '') + (t ? ' · ' : '') : '') + esc(t) + (w > 0 ? ' · ' + mshort(w * 52 / 12) + ' a month' : '');
  };
  V.lux = pipeView('V.lux', V.lux, 1); /* V.lux: the Aurum shop (features/screens/hiring_place_swipe_luxury.js), then the steps below */
  addStep('V.lux', 10, 'manage what you own; buy a car or jet through a company', (p, h) => {
    own().forEach(x => {
      const btn0 = '<button class="lxsell" data-a="luxsell" data-p="' + P({ id: x.id }) + '">Sell</button>';
      const l = useLine(x);
      h = h.replace(btn0, (l ? '<small class="lx56u">' + l + '</small>' : '') + '<button class="lxsell" data-a="lx56" data-p="' + P({ id: x.id }) + '">Manage</button>');
    });
    const i = p && p.k && LX()[p.k];
    if (i && (i.cat === 'cars' || i.cat === 'jets') && coFor(i).length) {
      const at = h.indexOf('<p class="lxfine">');
      if (at > 0) h = h.slice(0, at) + '<button class="lxbuy ghost" data-a="lx56co" data-p="' + P({ k: i.id }) + '">Buy through a company</button>' + h.slice(at);
    }
    return h;
  });
  ACT.lx56 = p => {
    const x = own().find(y => y.id === p.id), i = x && it(x);
    if (!i) return;
    const co = x.co && getCo(x.co);
    const opts = usesFor(i);
    let h = '<h2>' + esc(i.n) + '</h2>' + row('Worth today', money(x.val)) + row('Bought', dateStr(x.w) + ' for ' + mshort(x.price)) + row('Upkeep and insurance', money(i.up * x.price / 12) + ' a month' + (co ? ', paid by ' + esc(co.name) : ''));
    if (co) h += row('In the books of ' + esc(co.name), money(x.bv || 0)) + row('Benefit tax on your salary', money(LIFE.bikYear(x)) + ' a year');
    if (!co && LTV[i.cat]) h += row('The bank lends on it', money(x.val * LTV[i.cat]));
    if (opts.length) {
      h += '<h3 class="gap">Use</h3>' + chips([['', 'Keep it for yourself']].concat(opts.map(k => [k, USE[k].n])), x.use || '', 'lx56use', { id: x.id });
      const u = USE[x.use];
      h += '<p class="muted small">' + (u ? esc(u.d) + (weekIncome(x, i) > 0 || x.use === 'charter' ? ' About ' + money(Math.round(x.val * (u.y[i.cat] || 0) * (1 - u.fee) / 12)) + ' a month on average' + (i.cat === 'yachts' ? ', earned in the warm months' : '') + '.' : '') : 'You keep it for yourself.' + (i.cat === 'homes' ? ' Living here helps you recover from long weeks.' : '')) + '</p>';
    }
    h += '<div class="btnrow col">' + (i.cat === 'yachts' ? btn('Host a dinner on board', 'lx56din', {}, 'wide') : '') + (window.PK58 ? PK58.manageBtns(x) : '') + (x.use === 'museum' ? '<button class="btn wide" disabled>At the museum until ' + dateStr(x.until) + '</button>' : btn('Sell', 'luxsell', { id: x.id }, 'wide ghost danger')) + btn('Close', 'sheetclose', undefined, 'wide ghost') + '</div>';
    openSheet(h);
  };
  ACT.lx56use = p => {
    const x = own().find(y => y.id === p.id); if (!x) return;
    if (x.use === 'museum') { toast('It is at the museum until ' + dateStr(x.until) + '.', true); return; }
    x.use = p.v || null;
    if (x.use === 'museum') x.until = S.week + 26;
    save();
    ACT.lx56({ id: x.id });
  };
  ACT.lx56din = () => {
    const r = dinner();
    closeSheet();
    if (r === 'ok') { save(); render(); } else toast(r === 'wait' ? 'You hosted a dinner less than a month ago.' : r === 'cash' ? 'Not enough cash for the evening.' : 'You need a yacht.', true);
  };
  ACT.lx56co = p => {
    const i = LX()[p.k]; if (!i) return;
    const L = coFor(i);
    openSheet('<h2>Buy through a company</h2><p class="lead">' + esc(i.n) + ' · ' + money(i.price) + '</p><p class="muted small">The company pays, writes it down in its books and pays the upkeep, all before company tax. You pay tax on the private use as salary: about ' + money(Math.round(i.price * bikOf({ k: i.id }, i))) + ' a year counts as your income. A company too small for it draws the tax office.</p>' +
      '<div class="lrows">' + L.map(c => '<button class="lrow" data-a="lx56cogo" data-p="' + P({ k: i.id, c: c.id }) + '"' + (c.cash < i.price ? ' disabled' : '') + '><span class="ctext"><b>' + esc(c.name) + '</b><small>Cash ' + mshort(c.cash) + (c.cash < i.price ? ' · not enough' : '') + '</small></span><i>›</i></button>').join('') + '</div>' + btn('Cancel', 'sheetclose', undefined, 'ghost wide'));
  };
  ACT.lx56cogo = p => {
    const i = LX()[p.k], co = getCo(p.c); if (!i || !co) return;
    const r = buyVia(co, i);
    if (r !== 'ok') { toast(co.name + ' does not have the cash.', true); return; }
    ui.sheet = null; ui.ph = { n: 'lux', p: { pg: 'mine' } };
    save(); render(true); toast(co.name + ' bought ' + i.n + '.');
  };

  LIFE.html = function () {
    const p = perks(), L = [];
    if (p.home) L.push(['A home of your own', 'More people know your name, and you recover from long weeks']);
    if (p.jet) L.push(['Your own jet', 'You fly in to meetings abroad: starting abroad costs less']);
    if (p.yacht) L.push(['A yacht', 'Dinners on board warm the people you know']);
    if (p.serious) L.push(['A serious car or watch', 'Owners take your offers more seriously']);
    if (p.museum) L.push(['A work at the museum', 'Your name on the label']);
    const inc = own().reduce((t, x) => t + LIFE.weekIncome(x), 0);
    if (inc > 0) L.push(['What it earns', mshort(inc * 52 / 12) + ' a month, before tax']);
    if (!L.length) return '';
    return '<div class="lxspec">' + L.map(r => '<div><span>' + esc(r[0]) + '</span><b>' + esc(r[1]) + '</b></div>').join('') + '</div>';
  };
})();

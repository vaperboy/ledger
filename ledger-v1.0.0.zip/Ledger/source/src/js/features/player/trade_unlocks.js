/* ---- features/player/trade_unlocks.js ---- */
/* ===== Round 57: trades open up as you grow.
   A new game starts with the 8 cheapest trades of your country. Every other trade opens when the net worth you have
   EARNED since the start (the highest it has been; money you started with does not count) reaches about a third of
   what the trade costs to start: about what a bank wants to see as your own stake before it lends the rest. The
   values are rounded up to 1, 1.5, 2, 3, 5 or 7.5 of a power of ten in your currency, so trades of a similar size open together.
   Trades you own are always open (an inherited café, a store of your chain, a company you bought).
   Older saves (no S.unl57) have everything open, and so does Ledger Pro (features/player/pro.js PRO.on). In New company, a group of trades shows once one trade in it is
   open (ui/screens/companies_list.js V.newbiz); the next ones to open are shown with their value. ===== */
window.UNL57 = window.UNL57 || {};
(function () {
  const U57 = window.UNL57;
  const SKIP = { hold: 1, club: 1 };
  const st = () => S && S.unl57;
  /* rounded up to 1, 1.5, 2, 3, 5 or 7.5 × 10^n of the local currency, back in base units */
  function tier(base, cc) {
    const fx = fxr(CO[cc] || CC()), v = Math.max(1, base / fx);
    const p = Math.pow(10, Math.floor(Math.log10(v)));
    const t = [1, 1.5, 2, 3, 5, 7.5, 10].map(x => x * p).find(x => x >= v - 1e-6);
    return Math.round(t * fx);
  }
  U57.tier = tier;
  const est = (t, cc) => { try { setCtx({ country: cc }); return setupEstimate(t, { country: cc }).total; } catch (e) { return 0; } finally { setCtx(null); } };
  const nw = () => { try { return netWorth().total; } catch (e) { return 0; } };
  /* a new game: the values in the home country, the 8 cheapest open, the net worth to count from */
  U57.init = function () {
    const cc = S.country, L = BD_ORDER.filter(t => !SKIP[BD[t].fam] && legalStatus(t, cc).ok).map(t => [t, est(t, cc)]).filter(x => x[1] > 0).sort((a, b) => a[1] - b[1]);
    const s = S.unl57 = { nw0: nw(), best: 0, open: {}, need: {}, at: {}, w0: S.week };
    L.forEach((x, i) => { s.need[x[0]] = i < 8 ? 0 : tier(x[1] / 3, cc); if (i < 8) { s.open[x[0]] = 1; s.at[x[0]] = -1; } });
    S.cos.forEach(c => { s.open[c.type] = 1; });
    return s;
  };
  U57.all = () => { if (S) S.unl57 = null; };
  const pro = () => !!(window.PRO && PRO.has('trades')); /* Ledger Pro or the Time savers pack: every trade from the start */
  U57.ok = t => { const s = st(); return !s || pro() || !!s.open[t] || (BD[t] && BD[t].fam === 'hold') || S.cos.some(c => c.type === t && c.st !== 'sold' && c.st !== 'bust'); };
  U57.need = t => { const s = st(); return s ? (s.need[t] != null ? s.need[t] : tier(est(t, S.country) / 3, S.country)) : 0; };
  U57.earned = () => { const s = st(); return s ? Math.max(s.best || 0, nw() - s.nw0) : 0; };
  U57.isNew = t => { const s = st(); return !!(s && s.at[t] != null && s.at[t] >= 0 && S.week - s.at[t] <= 4); };
  /* the next value to reach, and the trades that open with it */
  U57.next = function () {
    const s = st();
    if (!s || pro()) return null;
    const L = Object.keys(s.need).filter(t => !s.open[t] && BD[t]).sort((a, b) => s.need[a] - s.need[b]);
    if (!L.length) return null;
    const v = s.need[L[0]];
    return { v, L: L.filter(t => s.need[t] === v) };
  };
  /* football: a club costs millions; the Sport group opens with the trades of that size */
  U57.sportOk = () => { const s = st(); return !s || pro() || U57.earned() >= tier(KC(15e6) / 3, S.country) || S.cos.some(c => c.type === 'club'); };
  /* weekly: what you have earned opens trades */
  function check() {
    const s = st();
    if (!s || S.over) return;
    s.best = Math.max(s.best || 0, nw() - s.nw0);
    const L = Object.keys(s.need).filter(t => !s.open[t] && BD[t] && s.need[t] <= s.best);
    if (!L.length) return;
    L.forEach(t => { s.open[t] = 1; s.at[t] = S.week; });
    if (pro()) return; /* with Pro they were open already: no message */
    const nm = L.map(t => BD[t].n);
    const nx = U57.next();
    addMsg({ kind: 'info', from: 'Your bank', title: (L.length > 1 ? L.length + ' new trades' : 'A new trade') + ' you can start', body: 'You have built up ' + money(s.best) + ' since you started. That is enough of your own money for the bank to lend you the rest of a ' + nm.join(', ').replace(/, ([^,]*)$/, ' or $1') + '.' + (nx ? ' Next: ' + nx.L.map(t => BD[t].n).slice(0, 3).join(', ') + ' at ' + mshort(nx.v) + ' earned.' : ''), tone: 'good', status: 'done', go: { l: 'See them', a: 'go', p: { n: 'newbiz' } } });
  }
  addStep('week.after', 92, 'trades open as the net worth you earned grows', check);
  /* a trade you own is open: an inherited company, a new store of your chain, a company you bought */
  addStep('startCompany', 12, 'a trade you own is open', (type, o, co) => { const s = st(); if (s && co && typeof co === 'object') s.open[type] = 1; });
})();

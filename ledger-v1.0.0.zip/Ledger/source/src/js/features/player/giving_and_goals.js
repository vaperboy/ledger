/* ===== Round 28c: giving back.
   Sponsor the local club, fund a scholarship, build a park or a hospital wing, or start a foundation.
   Each leaves a named mark, raises your standing in that city (people there choose your businesses a little more often)
   and adds to your legacy. (The monthly targets that used to live here are features/people/targets_and_budgets.js.) ===== */
(function () {
  const R28 = window.R28 = window.R28 || {};
  const U = window.UI, { toast, save, render, svg, row } = U;
  const P = o => esc(JSON.stringify(o));
  const pillp = (t, c) => '<span class="pill ' + (c || '') + '">' + t + '</span>';
  const sumF = (a, f) => a.reduce((t, x) => t + (f(x) || 0), 0);
  const MI = () => monthIdx(S.week);
  const sur = () => String(S.player.name || 'You').split(' ').slice(-1)[0];
  const live = () => S.cos.filter(c => c.st === 'open');
  const K = v => KC(v, S.country); /* a round local amount */
  const legacy = (pts, t) => { if (!window.R27 || !R27.amb) return; const a = R27.amb(); a.score += pts; a.hist.unshift({ w: S.week, t, path: 'give', pts }); if (a.hist.length > 40) a.hist.length = 40; };
  const img = (k, d) => { if (S.pr28) S.pr28.img[k] = Math.max(0, Math.min(100, S.pr28.img[k] + d)); };

  /* ================= giving back ================= */
  const G = () => { S.give28 = S.give28 || { marks: [], rep: {}, yearly: [], found: null }; return S.give28; };
  const ck = (cc, city) => cc + '|' + city;
  const GIVE = {
    club: { n: 'Sponsor the local football club', y: 1, c: 250000, rep: 8, leg: 15, img: ['care', 2], mark: (c) => c + ' FC, sponsored by ' + sur(), d: 'Your name on the shirts and around the pitch. Everyone in town sees it every weekend.' },
    fest: { n: 'Sponsor the summer festival', y: 1, c: 400000, rep: 6, leg: 12, img: ['bold', 2], mark: (c) => 'The ' + c + ' summer festival, presented by ' + sur(), d: 'Bars, restaurants and shops in town feel it too.' },
    food: { n: 'Support the food bank', y: 1, c: 120000, rep: 3, leg: 8, img: ['care', 4], mark: (c) => 'Main supporter of the ' + c + ' food bank', d: 'Quiet, steady help. People notice who shows up every year.' },
    schol: { n: 'Found a scholarship', y: 0, c: 2e6, rep: 4, leg: 60, img: ['care', 6], mark: () => 'The ' + sur() + ' Scholarship', d: 'Pays for young people to study. Your staff are proud of it.' },
    park: { n: 'Build a park and playground', y: 0, c: 6e6, rep: 12, leg: 90, img: ['care', 4], mark: (c) => sur() + ' Park, ' + c, d: 'A place families use every day.' },
    gallery: { n: 'Fund a museum gallery', y: 0, c: 15e6, rep: 10, leg: 180, img: ['trust', 3], mark: (c) => 'The ' + sur() + ' Gallery at the ' + c + ' museum', d: 'Art, history, and your name above the door.' },
    wing: { n: 'Build a hospital wing', y: 0, c: 40e6, rep: 25, leg: 400, img: ['trust', 8], mark: (c) => 'The ' + sur() + ' Wing, ' + c + ' Hospital', d: 'The biggest thing most people ever give. It will outlast every company you own.' }
  };
  R28.giveCount = () => G().marks.length + (G().found ? 1 : 0);
  function cities() {
    const s = {};
    live().forEach(c => { s[ck(c.country, c.city)] = { cc: c.country, city: c.city }; });
    if (S.player && S.player.city) s[ck(S.country, S.player.city)] = s[ck(S.country, S.player.city)] || { cc: S.country, city: S.player.city };
    return Object.values(s);
  }
  const cname = (cc, city) => { try { return (CO[cc].cities.find(x => x.id === city) || {}).name || city; } catch (e) { return city; } };
  function giveTo(k, cc, city, fromFound) {
    const g = GIVE[k], cost = rnl(K(g.c), 1000), nm = cname(cc, city);
    if (!fromFound) { if (S.cash < cost) return 'cash'; payMe(cost, g.n + ' (' + nm + ')'); }
    const R = G().rep, key = ck(cc, city);
    R[key] = Math.min(100, (R[key] || 0) + g.rep);
    if (g.img) img(g.img[0], g.img[1]);
    legacy(g.leg, g.mark(nm));
    if (k === 'schol') live().forEach(c => { c.mood = Math.min(100, (c.mood || 60) + 3); });
    if (k === 'fest') live().filter(c => c.city === city && (BD[c.type].fam === 'venue' || BD[c.type].fam === 'retail')).forEach(c => { c.aware = Math.min(100, (c.aware || 0) + 4); });
    if (k === 'club') live().filter(c => c.city === city).forEach(c => { c.aware = Math.min(100, (c.aware || 0) + 3); });
    const ex = G().marks.find(m => m.k === k && m.key === key);
    if (!ex) G().marks.unshift({ k, key, cc, city, w: S.week, name: g.mark(nm), y: g.y });
    if (g.y && !fromFound && !G().yearly.some(y => y.k === k && y.key === key)) G().yearly.push({ k, key, cc, city, next: S.week + 52 });
    if (window.R28 && R28.press) R28.press(g.y ? 3 : 4.5, g.y ? S.player.name + ' backs ' + g.mark(nm).toLowerCase().replace(/^the /, 'the ') : g.mark(nm) + ' opens', g.y ? '' : 'A gift from ' + S.player.name + ' to ' + nm + '.');
    return 'ok';
  }
  R28.giveTo = giveTo;
  /* standing in a city: a little more demand there */
  addStep('demand', 70, 'gifts to the city', (co, bd, r) => {
    const v = S.give28 && S.give28.rep[ck(co.country, co.city)]; if (v > 0 && r && r.D > 0) { const f = 1 + Math.min(0.06, v * 0.0008); r.D *= f; if (r.parts) r.parts.city27 = f; }
  }, true);
  function giveWeek() {
    const g = G();
    /* yearly sponsorships renew, if you can pay */
    g.yearly = g.yearly.filter(y => {
      if (S.week < y.next) return true;
      const cost = rnl(K(GIVE[y.k].c), 1000);
      if (S.cash < cost) { note('You could not renew ' + GIVE[y.k].n.toLowerCase() + ' in ' + cname(y.cc, y.city) + '. The sponsorship has ended.', 'bad'); g.marks = g.marks.filter(m => !(m.k === y.k && m.key === y.key)); return false; }
      payMe(cost, GIVE[y.k].n + ' (' + cname(y.cc, y.city) + ')');
      g.rep[y.key] = Math.min(100, (g.rep[y.key] || 0) + GIVE[y.k].rep * 0.6);
      legacy(Math.round(GIVE[y.k].leg * 0.6), GIVE[y.k].mark(cname(y.cc, y.city)) + ', another year');
      y.next = S.week + 52;
      return true;
    });
    /* standing fades slowly unless you keep giving */
    if (S.week % 13 === 0) Object.keys(g.rep).forEach(k => { g.rep[k] = Math.max(0, g.rep[k] * 0.975); });
    /* the foundation gives every year */
    if (g.found && S.week >= g.found.next) {
      const grant = g.found.cap * 0.04;
      const cs = cities();
      cs.forEach(c => { g.rep[ck(c.cc, c.city)] = Math.min(100, (g.rep[ck(c.cc, c.city)] || 0) + Math.min(10, grant / K(1e6) * 1.5 / cs.length)); });
      legacy(Math.round(Math.min(200, grant / K(1e6) * 4)), 'The ' + sur() + ' Foundation gave ' + mshort(grant));
      img('care', 2);
      g.found.given = (g.found.given || 0) + grant;
      g.found.next = S.week + 52;
      info('The ' + sur() + ' Foundation', 'The foundation gave ' + money(grant) + ' this year', 'Grants to schools, clubs and people in need in ' + cs.map(c => cname(c.cc, c.city)).join(', ') + '.', 0, 'good');
    }
  }
  V.titles.give28 = 'Giving back';
  V.heads = V.heads || {};
  V.heads.give28 = () => ({ t: 'Giving back', sub: R28.giveCount() ? R28.giveCount() + ' marks you have left' : 'What your money can do for others' });
  V.give28 = function () {
    const g = G(), cs = cities();
    const cur = ui.gc28 && cs.find(c => ck(c.cc, c.city) === ui.gc28) || cs[0];
    if (!cur) return '<div class="calm">Start a business first.</div>';
    const key = ck(cur.cc, cur.city), rp = g.rep[key] || 0;
    let h = '<div class="card sense"><span class="tipt">Money you give does not come back. It buys standing in a city (people there choose your businesses a little more often), a better name, and a legacy that outlives your companies.</span></div>';
    if (cs.length > 1) h += '<div class="chips">' + cs.map(c => '<button class="btn chip' + (ck(c.cc, c.city) === key ? ' primary' : '') + '" data-a="gc28" data-p="' + P({ v: ck(c.cc, c.city) }) + '">' + esc(cname(c.cc, c.city)) + '</button>').join('') + '</div>';
    h += '<div class="card"><div class="bhead"><b>Your standing in ' + esc(cname(cur.cc, cur.city)) + '</b>' + pillp(rp >= 40 ? 'Loved' : rp >= 20 ? 'Respected' : rp >= 5 ? 'Known' : 'Unknown', rp >= 20 ? 'grn' : '') + '</div><div class="bar"><i style="width:' + Math.max(2, rp) + '%;background:var(--amber)"></i></div><span class="tipt">' + (rp > 0 ? 'Your businesses there get about ' + (Math.min(6, rp * 0.08)).toFixed(1) + '% more customers.' : 'Nobody there knows you outside your shops yet.') + '</span></div>';
    h += '<h2 class="sec">Every year</h2><div class="lrows">' + Object.keys(GIVE).filter(k => GIVE[k].y).map(k => opt(k, cur)).join('') + '</div>';
    h += '<h2 class="sec">Once, for good</h2><div class="lrows">' + Object.keys(GIVE).filter(k => !GIVE[k].y).map(k => opt(k, cur)).join('') + '</div>';
    h += '<h2 class="sec">A foundation</h2><div class="card">' + (g.found ? row('The ' + esc(sur()) + ' Foundation', mshort(g.found.cap)) + row('Given so far', mshort(g.found.given || 0)) + '<span class="tipt">Gives about 4% a year to your cities, for as long as it exists.</span>' : '<span class="tipt">Put money into a foundation once, and it gives about 4% of it away every year, in every city you work in. The money is no longer yours.</span><div class="chips">' + [10e6, 50e6, 200e6].map(v => btn(mshort(K(v)), 'found28', { v: Math.round(K(v)) }, 'chip')).join('') + '</div>') + '</div>';
    if (g.marks.length) h += '<h2 class="sec">Your marks</h2><div class="lrows">' + g.marks.map(m => '<div class="lrow"><span class="lic">' + svg(m.y ? 'star' : 'house', 20) + '</span><span class="ctext"><b class="wrap">' + esc(m.name) + '</b><small>' + (m.y ? 'Every year since ' : 'Since ') + wYear(m.w) + '</small></span></div>').join('') + '</div>';
    return h;
  };
  function opt(k, cur) {
    const g = GIVE[k], cost = rnl(K(g.c), 1000), key = ck(cur.cc, cur.city);
    const done = G().marks.some(m => m.k === k && m.key === key);
    return '<button class="lrow" data-a="' + (done ? 'none' : 'give28') + '" data-p="' + P({ k, key }) + '"><span class="ctext"><b>' + esc(g.n) + '</b><small>' + esc(g.d) + '</small></span>' + (done ? pillp(g.y ? 'Yours' : 'Done', 'grn') : '<b>' + mshort(cost) + (g.y ? '<small>/yr</small>' : '') + '</b>') + '</button>';
  }
  ACT.gc28 = p => { ui.gc28 = p.v; render(); };
  ACT.give28 = p => {
    const g = GIVE[p.k], [cc, city] = p.key.split('|'), cost = rnl(K(g.c), 1000);
    confirmThen(g.n + '?', money(cost) + (g.y ? ' a year, from your own money.' : ' from your own money, once.') + ' Your name: "' + g.mark(cname(cc, city)) + '".', 'Give', () => {
      const r = giveTo(p.k, cc, city);
      if (r !== 'ok') { toast('Not enough cash in your own account.', true); return; }
      save(); render(true); toast('Thank you, from ' + cname(cc, city) + '.');
    });
  };
  ACT.found28 = p => {
    confirmThen('Start the ' + sur() + ' Foundation?', 'You put ' + money(p.v) + ' in. It is no longer yours; the foundation gives about ' + money(p.v * 0.04) + ' a year to your cities.', 'Start it', () => {
      if (S.cash < p.v) { toast('Not enough cash.', true); return; }
      payMe(p.v, 'Endowment: the ' + sur() + ' Foundation');
      G().found = { cap: p.v, w: S.week, next: S.week + 4, given: 0 };
      legacy(Math.round(Math.min(500, p.v / K(1e6) * 3)), 'Started the ' + sur() + ' Foundation');
      img('care', 6); img('trust', 4);
      if (R28.press) R28.press(5, 'The ' + sur() + ' Foundation is born', S.player.name + ' gives ' + mshort(p.v) + ' to a new foundation.');
      save(); render(true); toast('The ' + sur() + ' Foundation is started.');
    });
  };

  addStep('week.after', 55, 'giving back: yearly sponsorships', () => { try { giveWeek(); } catch (e) { console.error(e); } });
})();


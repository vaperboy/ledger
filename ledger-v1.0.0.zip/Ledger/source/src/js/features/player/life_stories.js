/* ---- features/player/life_stories.js ---- */
/* ===== Round 57: who you are when the game starts (the start screen's Your story, ui/screens/start.js).
   - Heir: the family café is yours, open with a small team and money in its account; a little savings, no loan.
   - Laid off: twelve months of pay as severance (after tax), no business yet, no loan.
   - Student: a little saved, a thin credit history (higher interest), and young.
   - Investor's kid: 2 M from your parents (in your currency's terms), but nobody takes you seriously for two years:
     a weak credit score, banks charge more, and managers ask for more to work for you.
   - Start-up loan: the bank's start-up loan, the classic start (and what a game without a story gets).
   Applied right after the new game is made; the trades you can start count from the net worth you have then
   (features/player/trade_unlocks.js). ===== */
window.STORY57 = window.STORY57 || {};
(function () {
  const Y = window.STORY57;
  /* [id, name, one line, the age it suggests or 0] */
  Y.L = [
    ['heir', 'Heir', 'The family café is yours: open, a small team, money in its account. A little savings, no loan.', 0],
    ['laid', 'Laid off', 'Twelve months of pay as severance. No business yet, no loan.', 38],
    ['student', 'Student', 'A little saved, a thin credit history, and time on your side.', 21],
    ['kid', 'Investor’s kid', '2 M from your parents. Banks, managers and suppliers do not take you seriously yet.', 24],
    ['loan', 'Start-up loan', 'The bank lends you a start-up loan. The classic start.', 0]
  ];
  Y.get = k => Y.L.find(x => x[0] === k) || Y.L[4];
  const noLoan = () => { const l = S.loans.find(x => x.kind === 'start'); if (!l) return; S.loans = S.loans.filter(x => x !== l); moveCash(ME, -l.bal, 'No start-up loan'); };
  const give = (amt, why) => { if (amt > 0) moveCash(ME, amt, why); };
  function heir() {
    noLoan();
    const sav = KC(50000), est = setupEstimate('cafe', {}).total, put = rnl(est * 1.3, 1000);
    give(put + sav + CC().asCapital + CC().asFee, 'Inheritance: the family café and savings');
    const cc = CC().code, w = { NO: 'Kafé', DK: 'Kafé', SE: 'Kafé', FI: 'Kahvila', IT: 'Caffè', ES: 'Café', MX: 'Café', BR: 'Café', PL: 'Kawiarnia', LT: 'Kavinė', NL: 'Koffiehuis' }[cc] || 'Café';
    const co = startCompany('cafe', { form: 'AS', name: pick(CC().last) + ' ' + w });
    if (!co || typeof co === 'string') return;
    injectCash(co, put);
    autoSetup(co, { force: 1 });
    /* the family has run it for years: the papers are in order and the town knows it */
    docNeeds(co).forEach(d => { if (d !== 'mva_na') co.docs[d] = { st: 'ok', done: S.week, ok: S.week, w0: S.week }; });
    co.staff.forEach(s => onbItems(s.role).forEach(it => { s.onb = s.onb || {}; s.onb[it[0]] = 1; }));
    openCompany(co);
    co.aware = Math.max(co.aware, 45);
    co.rep = Math.max(co.rep || 0, 60);
    co.ohrs = 25;
    co.inherited57 = 1;
    const left = S.cash - sav;
    if (left > 0) moveCash(ME, -left, 'Inheritance tax and lawyer');
  }
  Y.apply = function (k) {
    S.story57 = k;
    if (k === 'heir') heir();
    else if (k === 'laid') { noLoan(); const c = CC(); give(rnl(c.pack.economy.medianWage * fxr(c) * 12 * 0.72, 1000), 'Severance: twelve months of pay'); }
    else if (k === 'student') { noLoan(); give(KC(30000), 'Your savings'); S.credit = 40; }
    else if (k === 'kid') { noLoan(); give(KC(2000000), 'A gift from your parents'); S.credit = 45; S.flags.kid57 = S.week + 104; }
  };
  /* nobody trusts an investor's kid for two years; a student has no credit history yet */
  const doubt = () => S && S.flags && S.flags.kid57 && S.week < S.flags.kid57;
  addStep('loanOffer', 40, 'a young borrower pays more', (kind, amt, co, o) => { if (o && S && (doubt() || (S.story57 === 'student' && S.week < 156))) o.margin += doubt() ? 0.015 : 0.01; return o; });
  addStep('genManager', 40, 'managers ask an investor’s kid for more', (co, mtype, n) => { if (n && doubt()) n.ask = rnl(n.ask * 1.1, 500); return n; });
})();

/* ===== Round 56: reasons to come back.
   - The next goal on Home: the closest milestone of your ambition (features/player/ambitions.js), otherwise the next
     round net worth (1, 10, 100 million ... in your currency), with how far you are. Tap: the Ambition screen.
   - A deal of the week every few weeks, open for seven days: a rival owner ready to sell below value, a private sale
     in the Aurum shop at 15% off, or a listed share that has fallen too far. A row at the top of your companies on Home, only while you can pay for it.
   - The business awards, every year end: Business of the year, Employer of the year, Best rated, Newcomer, Fastest
     growing and Entrepreneur of the year, decided by where you rank, your staff's mood, your reviews and your growth.
     Wins are kept (S.aw56) and count for trophies; the evening shows how far you climbed in the rankings.
   - Welcome back: after six hours away, managers can run your companies for some days (three for free, two weeks
     with Ledger Pro); decisions still wait for you. ===== */
window.GA56 = window.GA56 || {};
(function () {
  const GA = window.GA56;
  const K = v => KC(v, S.country);
  const nw = () => { try { return netWorth().total; } catch (e) { return 0; } };
  const live = () => S.cos.filter(c => c.st === 'open' || c.st === 'closed');
  /* ---------- the next goal ---------- */
  function nextGoal() {
    try {
      const a = window.R27 && R27.amb ? R27.amb() : null;
      if (a && a.path && R27.tierList) {
        const t = a.tier[a.path] || 0, L = R27.tierList(a.path, t).filter(m => !a.done[m[0]]);
        let best = null;
        L.forEach(m => { let r = [0, 1]; try { r = m[2](); } catch (e) { } const f = r[1] > 0 ? clamp(r[0] / r[1], 0, 0.999) : 0; if (!best || f > best.f) best = { t: m[1], f, sub: 'Ambition milestone' }; });
        if (best) return best;
      }
      if (a && !a.path && live().length) return { t: 'Choose your ambition', f: 0, sub: 'Six ways to build an empire, each with a perk' };
    } catch (e) { }
    const v = nw();
    let g = K(1e6);
    while (g <= v) g *= 10;
    return { t: 'Net worth of ' + mshort(g), f: clamp(v / g, 0, 0.999), sub: mshort(Math.max(0, g - v)) + ' to go' };
  }
  GA.nextGoal = nextGoal;
  /* the next goal: a row on Group › You (round 56: no longer on Home) */
  GA.goalRow = () => {
    if (!S || !S.cos.length) return '';
    const g = nextGoal();
    return '<button class="goal56" data-a="go" data-p="' + P({ n: window.V && V.amb27 ? 'amb27' : 'trophies28' }) + '"><span class="ctext"><b>' + esc(g.t) + '</b><span class="gbar"><i style="width:' + Math.max(2, Math.round(g.f * 100)) + '%"></i></span><small>' + esc(g.sub) + '</small></span><span class="gpc">' + Math.round(g.f * 100) + '%</span></button>';
  };

  /* ---------- the deal of the week ----------
     Not every week: one comes every few weeks (two to five weeks after the last one ended) and is open for seven days.
     One of three kinds, equally likely: a rival owner who wants out and sells about 20% below value, a private sale at
     Aurum at 15% off, or a listed share that fell 12% and tends to drift back. The row says what you save. */
  const D = () => S.dow56;
  function newDeal() {
    const kinds = [];
    const riv = [];
    live().filter(c => c.st === 'open' && !['fin', 'energy', 'club', 'hold', 'rent'].includes((BD[c.type] || {}).fam)).forEach(co => {
      try { (rivalsOf(co) || []).slice(0, 3).forEach(r => { if (S.week >= (r.lock || 0) && rivalValue(co, r) * 0.8 + KC(200000, co.country) <= S.cash) riv.push([co, r]); }); } catch (e) { }
    });
    if (riv.length) kinds.push('riv');
    const LX = (window.LUX47 || {}).LUXI || {};
    const lux = Object.keys(LX).filter(k => LX[k].price <= Math.max(0, S.cash) * 0.4 && LX[k].cat !== 'estates');
    if (lux.length) kinds.push('lux');
    const st = Object.keys(S.stocks || {});
    if (st.length && S.cash > K(100000)) kinds.push('stock');
    if (!kinds.length) return null;
    const k = kinds[Math.floor(Z() * kinds.length)], o = { k, w0: S.week, exp: S.week + 1 };
    if (k === 'riv') {
      const [co, r] = riv[Math.floor(Z() * riv.length)];
      Object.assign(o, { co: co.id, r: r.id, n: r.name, v: rivalValue(co, r) });
      o.ask = rnl(o.v * 0.8, 1000);
      r.listed = true; r.dow56 = o.exp;
    } else if (k === 'lux') o.id = lux[Math.floor(Z() * lux.length)];
    else { o.s = st[Math.floor(Z() * st.length)]; const x = S.stocks[o.s]; o.p0 = x.p; x.p = Math.round(x.p * 0.88 * 100) / 100; (S.reb56 = S.reb56 || []).push({ s: o.s, p0: o.p0, until: S.week + 10 }); }
    return o;
  }
  addStep('week.after', 92, 'the deal of the week', () => {
    if (!S || S.over) return;
    const d = D();
    if (d && S.week >= d.exp) { S.dow56 = null; S.dow56n = S.week + 2 + Math.floor(Z() * 4); }
    /* a share that fell too far drifts back over the next weeks, as overreactions do */
    if (S.reb56) S.reb56 = S.reb56.filter(x => { const s = S.stocks[x.s]; if (!s || S.week > x.until) return false; if (s.p < x.p0 * 0.97) s.p = Math.round(s.p * 1.02 * 100) / 100; return true; });
    if (!S.dow56 && live().length && S.week >= (S.dow56n || 0)) S.dow56 = newDeal();
  });
  /* the owner on the deal takes about 20% less; the private sale is 15% off */
  addStep('proposeBuy.terms', 40, 'deal of the week: a keen seller', (co, r, t) => { if (r && r.dow56 && S.week < r.dow56) { t.mult *= 1.25; } });
  GA.luxOff = k => { const d = D(); return d && d.k === 'lux' && d.id === k && S.week < d.exp ? 0.85 : 1; };
  /* what the deal costs you, to hide it while you cannot pay */
  const dealCost = d => d.k === 'riv' ? (d.ask || 0) + KC(200000) : d.k === 'lux' ? (((window.LUX47 || {}).LUXI || {})[d.id] || { price: 0 }).price * 0.85 : K(100000);
  function dealRow() {
    const d = D();
    if (!d || S.week >= d.exp || S.cash < dealCost(d)) return '';
    const days = Math.max(1, 7 - (S.day || 0));
    let t = '', s = '', save = '', a = null;
    if (d.k === 'riv') { if (!getCo(d.co)) return ''; const v = d.v || 0, ask = d.ask || v * 0.8; t = d.n + ' for sale'; s = 'Takes about ' + mshort(ask) + ', worth ' + mshort(v); save = 'Save ' + mshort(v - ask); a = { n: 'rival', p: { id: d.co, r: d.r } }; }
    else if (d.k === 'lux') { const i = ((window.LUX47 || {}).LUXI || {})[d.id]; if (!i) return ''; t = i.n; s = 'Private sale · ' + mshort(i.price * 0.85); save = '−15%'; a = { n: 'lux', p: { k: d.id } }; }
    else if (d.k === 'stock') { const x = S.stocks[d.s]; if (!x) return ''; t = x.n + ' fell 12%'; s = x.sym + ' ' + x.p.toFixed(2) + ' · often drifts back'; save = '−12%'; a = { n: 'invest', p: { tab: 'stocks' } }; }
    return '<button class="lrow dow56" data-a="dow56go" data-p="' + P(a) + '"><span class="lic">' + svg('deal', 20) + '</span><span class="ctext"><b>' + esc(t) + '</b><small>Deal of the week · ' + days + (days === 1 ? ' day' : ' days') + ' · ' + esc(s) + '</small></span><b class="pos">' + esc(save) + '</b></button>';
  }
  ACT.dow56go = p => { if (p.n === 'lux' || p.n === 'invest') { if (p.n === 'invest') ui.itab = 'stocks'; U.phoneGo(p.n, p.p); } else go(p.n, p.p); };
  GA.dealRow = dealRow;

  /* ---------- the business awards ---------- */
  const AW = () => (S.aw56 = S.aw56 || { won: [], years: [] });
  const CATS = [
    ['boty', 'Business of the year'], ['emp', 'Employer of the year'], ['rated', 'Best rated business'],
    ['new', 'Newcomer of the year'], ['grow', 'Fastest growing'], ['ent', 'Entrepreneur of the year']
  ];
  function rivalName() { try { const L = live(); const r = L.length ? (rivalsOf(L[Math.floor(Z() * L.length)]) || [])[0] : null; return r ? r.name : brandCoName(CC(), 'venue'); } catch (e) { return brandCoName(CC(), 'venue'); } }
  function judge(y) {
    const L = live().filter(c => c.type !== 'hold' && c.st === 'open');
    const rk = window.R27 && R27.myRank ? R27.myRank('cc', 'rev') : null, gr = window.R27 && R27.myRank ? R27.myRank('cc', 'gr') : null;
    const res = [];
    const win = (k, co, why, p) => res.push({ k, me: chance(p), co: co ? co.name : S.player.name, why, other: rivalName() });
    if (L.length) {
      const best = L.slice().sort((a, b) => (b.lastW ? b.lastW.rev : 0) - (a.lastW ? a.lastW.rev : 0))[0];
      win('boty', best, 'one of the biggest in the country', rk ? (rk.rank <= 10 ? 0.6 : rk.rank <= 50 ? 0.25 : rk.rank <= 300 ? 0.05 : 0) : 0);
      const big = L.filter(c => c.staff.length >= 15).sort((a, b) => (b.mood || 60) - (a.mood || 60))[0];
      if (big) win('emp', big, 'staff who stay and like their work', clamp(((big.mood || 60) - 62) / 40, 0, 0.6));
      const top = L.filter(c => (c.rvN || 0) >= 80).sort((a, b) => ratingOf(b) - ratingOf(a))[0];
      if (top) win('rated', top, ratingOf(top).toFixed(1) + ' stars from ' + top.rvN + ' reviews', clamp((ratingOf(top) - 4.3) * 1.2, 0, 0.7));
      const nw0 = L.filter(c => S.week - (c.w0 || 0) < 60).sort((a, b) => (b.lastW ? b.lastW.rev : 0) - (a.lastW ? a.lastW.rev : 0))[0];
      if (nw0 && nw0.lastW) win('new', nw0, mshort(nw0.lastW.rev * 52) + ' a year in its first year', clamp(nw0.lastW.rev * 52 / K(20e6), 0, 0.5));
      if (gr) win('grow', best, 'grew faster than almost anyone', gr.rank <= 20 ? 0.45 : gr.rank <= 100 ? 0.12 : 0);
    }
    const a = AW(), prev = a.years.length ? a.years[a.years.length - 1].nw : (S.cash0 || 0);
    const g = prev > 0 ? nw() / prev - 1 : 0;
    if (nw() >= K(50e6)) win('ent', null, 'net worth up ' + Math.round(g * 100) + '% this year', clamp((g - 0.3) * 0.8, 0, 0.6));
    return res;
  }
  addStep('week.after', 93, 'the business awards at year end', () => {
    /* the first awards come once you have been in business for half a year */
    if (!S || S.over || !isYearEnd(S.week) || !live().some(c => S.week - (c.w0 || 0) >= 26)) return;
    const y = wYear(S.week), a = AW();
    if (a.years.some(x => x.y === y)) return;
    const res = judge(y), rk = window.R27 && R27.myRank ? R27.myRank('cc', 'rev') : null;
    const last = a.years.length ? a.years[a.years.length - 1] : null;
    a.years.push({ y, res, rank: rk ? rk.rank : null, of: rk ? rk.of : null, was: last ? last.rank : null, nw: nw() });
    if (a.years.length > 30) a.years.shift();
    res.filter(r => r.me).forEach(r => { a.won.push({ y, k: r.k, co: r.co }); news(r.co + ' wins ' + CATS.find(c => c[0] === r.k)[1].toLowerCase() + ' at the ' + y + ' business awards.', 'good'); });
    S.aw56q = y;
  });
  function awardsHtml(yr) {
    const a = AW(), Y = a.years.find(x => x.y === yr) || a.years[a.years.length - 1];
    if (!Y) return '<div class="calm">The first business awards are held at the end of the year.</div>';
    const won = Y.res.filter(r => r.me).length;
    let h = '<div class="aw56"><div class="awimg">' + photoTag('pictures/events/aw1-awards-gala.webp') + '</div><h2>Business awards ' + Y.y + '</h2><p class="lead">' + (won ? 'You took home ' + won + (won === 1 ? ' award' : ' awards') + '.' : 'No award this year. The room still knows your name.') + '</p>';
    h += '<div class="lrows awlist">' + Y.res.map(r => { const c = CATS.find(x => x[0] === r.k); return '<div class="lrow"><span class="av' + (r.me ? ' me27' : '') + '">' + (r.me ? '★' : '·') + '</span><span class="ctext"><b>' + esc(c[1]) + '</b><small>' + (r.me ? esc(r.co) + ': ' + esc(r.why) : 'Won by ' + esc(r.other) + '. You were in the running.') + '</small></span></div>'; }).join('') + '</div>';
    if (Y.rank) h += '<p class="muted small">In the country’s rankings you are No. ' + Y.rank.toLocaleString('en-US').replace(/,/g, ' ') + ' of ' + (Y.of || 0).toLocaleString('en-US').replace(/,/g, ' ') + (Y.was ? (Y.was > Y.rank ? ', up ' + (Y.was - Y.rank).toLocaleString('en-US').replace(/,/g, ' ') + ' places from last year' : Y.was < Y.rank ? ', down ' + (Y.rank - Y.was) + ' places' : ', the same as last year') : '') + '.</p>';
    return h + '</div>';
  }
  /* the evening opens when nothing else is on screen */
  setInterval(() => {
    try {
      if (!S || S.over || !S.aw56q || ui.sheet || ui.dayBusy || ui.untl || ui.repLock || (ui.view && ui.view.n === 'weekreport')) return;
      const y = S.aw56q; S.aw56q = null;
      ui.sheet = { html: awardsHtml(y) + btn('Close', 'sheetclose', undefined, 'primary wide') + btn('All awards', 'go', { n: 'awards56' }, 'ghost wide'), cls: 'cel28' };
      render();
    } catch (e) { }
  }, 700);
  V.titles.awards56 = 'Business awards';
  V.awards56 = function () {
    const a = AW();
    let h = '<div class="card">' + row('Awards won', a.won.length) + (a.won.length ? '<span class="tipt">' + a.won.slice(-8).reverse().map(w => w.y + ': ' + CATS.find(c => c[0] === w.k)[1] + ' (' + esc(w.co) + ')').join(' · ') + '</span>' : '') + '</div>';
    a.years.slice().reverse().forEach(Y => { h += awardsHtml(Y.y); });
    return h || '<div class="calm">The first business awards are held at the end of the year.</div>';
  };
  GA.awards = AW;

  /* ---------- welcome back: managers run things while you were away ---------- */
  const SEEN = U.KEY + ':seen';
  const stamp = () => { try { localStorage.setItem(SEEN, String(Date.now())); } catch (e) { } };
  document.addEventListener('visibilitychange', () => { if (document.hidden) stamp(); });
  window.addEventListener('pagehide', stamp);
  setInterval(stamp, 60000);
  function welcome() {
    let t0 = 0;
    try { t0 = +localStorage.getItem(SEEN) || 0; } catch (e) { }
    stamp();
    if (!S || S.over || !t0) return;
    const hrs = (Date.now() - t0) / 3600000;
    if (hrs < 6 || !live().some(c => c.mgr && S.npcs[c.mgr])) return;
    const cap = PRO.has('untl') ? 14 : 3, n = Math.max(1, Math.min(cap, Math.floor(hrs / 4)));
    /* waits for anything already on screen (the awards evening, a week report) to be closed */
    const show = k => {
      if (!S || S.over) return;
      if (ui.sheet || ui.dayBusy || ui.untl) { if (k < 60) setTimeout(() => show(k + 1), 1000); return; }
      openSheet('<h2>Welcome back</h2><p class="lead">You were away for ' + (hrs >= 48 ? Math.floor(hrs / 24) + ' days' : Math.floor(hrs) + ' hours') + '. Your managers can run things for ' + n + (n === 1 ? ' day' : ' days') + ' while you catch up. Decisions still wait for you.</p>' + (cap < 14 ? '<p class="muted small">Up to two weeks with Ledger Pro.</p>' : '') + '<div class="btnrow col">' + btn('Let them run ' + n + (n === 1 ? ' day' : ' days'), 'away56', { n }, 'primary wide') + btn('Not now', 'sheetclose', undefined, 'ghost wide') + '</div>');
    };
    setTimeout(() => show(0), 900);
  }
  ACT.away56 = p => { ui.sheet = null; ui.untlMax = p.n; ui.catch56 = 1; ACT.untilneeded(); };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => setTimeout(welcome, 300)); else setTimeout(welcome, 300);
  GA.welcome = welcome;

})();

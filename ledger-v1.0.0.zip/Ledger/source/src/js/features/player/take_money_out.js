/* ===== Round 56: rich on paper, broke in your pocket. When your own account is overdrawn, Home offers to take money
   out of your companies: every holding company and company that can pay you is listed with how much it can pay now
   (a dividend for a limited company, a withdrawal for a sole proprietorship), best first, and opens its Pay
   yourself page (features/sales/realistic_odds.js V.payself). Holding companies have their own Pay yourself row
   (features/world/rivals_holdings_software.js holdingView). ===== */
(function () {
  const U = window.UI;
  if (!U) return;
  const { ACT, esc, btn, openSheet } = U;
  const P = o => esc(JSON.stringify(o));
  const can = co => co.form === 'AS' ? Math.max(0, divMax(co)) : Math.max(0, Math.floor(co.cash - coWeekCost(co) * 2));
  ACT.paysrcgo = p => { U.ui.sheet = null; U.go('payself', { id: p.id }); };
  ACT.paysrc56 = () => {
    const L = S.cos.filter(c => c.st === 'open' && !(c.hold && getCo(c.hold))).map(c => [c, can(c)]).filter(x => x[1] > 0).sort((a, b) => b[1] - a[1]);
    let h = '<h2>Take money out</h2><p class="muted small">Your own account is ' + (S.cash < 0 ? 'overdrawn by ' + money(-S.cash) : 'at ' + money(S.cash)) + '. These can pay you now. Money in a company is the company’s: it reaches you as a dividend, a salary or a withdrawal, and is taxed as yours.</p>';
    h += L.length ? '<div class="lrows">' + L.slice(0, 8).map(([c, a]) => '<button class="lrow" data-a="paysrcgo" data-p="' + P({ id: c.id }) + '"><span class="ctext"><b>' + esc(c.name) + '</b><small>' + (c.type === 'hold' ? 'Holding company · dividend' : c.form === 'AS' ? 'Dividend' : 'Withdrawal') + '</small></span><b class="num pos">up to ' + mshort(a) + '</b></button>').join('') + '</div>' : '<div class="calm">None of your companies has profit or spare cash to pay out right now. A loan against your shares or selling something would.</div>';
    openSheet(h + btn('Close', 'sheetclose', undefined, 'ghost wide'));
  };
})();

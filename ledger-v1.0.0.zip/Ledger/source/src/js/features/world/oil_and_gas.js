/* ===== Oil and gas (round 24) =====
   - a discovery is a decision: develop it alone, bring in a partner who pays half, or sell it as it is
   - a developed field holds a plateau for about two years before it declines
   - lifting costs follow real offshore costs (about 200 NOK a barrel, rising with inflation and material prices)
   - in Norway the state refunds 78% of exploration costs to companies with no taxable income, once a year */
(function () {
  const r0 = Math.round;
  addStep('oilExplore.before', 10, 'cash before drilling', (co, ph) => { ph.c0 = co.cash; });
  addStep('oilExplore.after', 10, 'exploration cost, plateau and development cost', (co, ph) => {
    const r = ph.r, c0 = ph.c0;
    if (r === 'hit' || r === 'dry') {
      const cost = c0 - co.cash;
      co.fm.expl = (co.fm.expl || 0) + cost; /* this year's exploration spend, for the refund */
    }
    if (r === 'hit') {
      const f = co.fm.fields[co.fm.fields.length - 1];
      f.plat = 104;
      /* a plateau of about 14% of the reserves a year, and full-cycle development costs nearer real offshore projects */
      f.q0 = f.res * 0.0028;
      f.capex = r0(f.res * 1000 * 130 * Math.pow(1 + S.econ.infl, S.week / 52) ** 0.5);
      const sell = r0(f.res * 1000 * 25 * Math.sqrt(S.econ.oil) / 1e5) * 1e5;
      const capex = f.capex;
      addMsg({ kind: 'ask', from: co.name, title: 'Discovery: ' + f.name, body: 'About ' + r0(f.res / 1000) + ' million barrels. Developing it costs about ' + money(capex) + ' over three years before any oil flows. You have ' + money(co.cash) + ' in the company.', co: co.id, act: 'oil24', exp: S.week + 4, tone: 'good', data: { f: f.id, sell },
        opts: [{ l: 'Develop it ourselves', d: 'You pay all of the development and keep all of the oil.', fx: {} }, { l: 'Bring in a partner for half', d: 'A partner pays half the development and takes half the field.', fx: {} }, { l: 'Sell the discovery · ' + money(sell), d: 'Cash now; no development risk.', fx: {} }] });
    }
  });
  function oilChoice(co, f, idx, sell) {
    if (idx === 1) { f.res = r0(f.res / 2); f.q0 = f.q0 / 2; f.capex = f.capex / 2; f.name += ' (50%)'; note('A partner takes half of ' + f.name + ' and pays half the development.', 'good', co.id); }
    else if (idx === 2) { co.fm.fields = co.fm.fields.filter(x => x !== f); coIn(co, sell, 'rev', 'Discovery sold: ' + f.name); }
  }
  ACTS.oil24 = (m, idx) => {
    const co = getCo(m.co), f = co && co.fm && (co.fm.fields || []).find(x => x.id === m.data.f);
    if (!f || m.data.done) return true;
    m.data.done = 1;
    oilChoice(co, f, idx, m.data.sell);
    return true;
  };
  /* no answer: the company cannot afford it alone → bring in a partner; otherwise develop */
  addStep('week.after', 55, 'oil_and_gas weekly', () => {
    try {
      S.inbox.forEach(m => {
        if (m.act !== 'oil24' || !m.auto || m.data.done) return;
        const co = getCo(m.co), f = co && co.fm && (co.fm.fields || []).find(x => x.id === m.data.f);
        m.data.done = 1;
        if (f) { const i = co.cash < f.capex * 1.1 ? 1 : 0; oilChoice(co, f, i, m.data.sell); note('No answer on the discovery, so ' + (i ? 'a partner was brought in for half.' : 'development goes ahead.'), 'n', co.id); }
      });
      /* exploration refund (Norway): paid at the start of the next year for companies without taxable income */
      if (S.week % 52 === 0) S.cos.forEach(co => {
        if (co.type !== 'oilgas' || co.country !== 'NO' || !co.fm || !(co.fm.expl > 0) || co.st === 'bust') return;
        const taxed = (co.pay && co.pay.tax) || 0;
        const ref = r0(co.fm.expl * 0.78);
        if (taxed < 1) { coIn(co, ref, null, 'Exploration cost refund (78%)'); note(co.name + ' gets ' + money(ref) + ' back from the state for last year\'s exploration.', 'good', co.id); }
        co.fm.expl = 0;
      });
    } catch (e) { console.error(e); }
  });
  /* development: when the company cannot pay this week's share, the bank lends against the field (reserve-based lending) */
  R24.oilDevCash = function (co, f, c) {
    if (co.cash >= c) return;
    const need = Math.max(c - co.cash, c * 26);
    const lim = f.res * 1000 * 100 - (f.rbl || 0);
    const amt = r0(Math.min(need, lim) / 1e5) * 1e5;
    if (amt <= 0) return;
    /* interest only until the field produces, then repaid over seven years */
    const l = { id: uid(), kind: 'biz', name: 'Reserve-based loan: ' + f.name, bal: amt, amt0: amt, margin: creditMargin() + 0.025, pay: 0, termM: 84, co: co.id, w0: S.week + f.wl, graceW: S.week + f.wl + 13, guar: 0, bank: 0 };
    l.pay = annuity(amt, policy() + l.margin, 84);
    S.loans.push(l);
    coIn(co, amt, null, 'Loan drawn');
    f.rbl = (f.rbl || 0) + amt;
    note('The bank lends ' + money(amt) + ' against ' + f.name + ' to finish development.', 'n', co.id);
  };
  R24.oilLift = () => 200 * (0.7 + 0.3 * (S.econ.mat || 1)) * Math.pow(1 + S.econ.infl, S.week / 52) ** 0.5;
})();

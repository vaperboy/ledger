/* ===== Bank liquidity (round 24): a solvent bank hit by a run borrows from the central bank against its loans
   instead of going bankrupt; it repays as deposits come back. ===== */
(function () {
  const r0 = Math.round;
  function cbLoans(co) { return S.loans.filter(l => l.co === co.id && l.cb); }
  R24.bankLiquidity = function (co) {
    const fm = co.fm;
    if (!fm || co.type !== 'bank' || (co.st !== 'open' && co.st !== 'closed')) return;
    const dep = fm.dep || 0, book = fm.book || 0, eq = fm.equity != null ? fm.equity : co.cash + book - dep;
    const have = cbLoans(co).reduce((a, l) => a + l.bal, 0);
    if (co.cash < dep * 0.03 && eq > 0) {
      const want = dep * 0.08 - co.cash, room = book * 0.5 - have, amt = r0(Math.min(want, room) / 1e5) * 1e5;
      if (amt > 0) {
        const l = { id: uid(), kind: 'biz', name: 'Central bank liquidity facility', bal: amt, amt0: amt, margin: 0.01, pay: 0, termM: 12, co: co.id, w0: S.week + 26, graceW: S.week + 26, guar: 0, bank: 0, cb: 1 };
        l.pay = annuity(amt, policy() + 0.01, 12);
        S.loans.push(l);
        coIn(co, amt, null, 'Loan drawn');
        if (!co.flags.cb24 || S.week - co.flags.cb24 > 26) { co.flags.cb24 = S.week; note(co.name + ' borrows ' + money(amt) + ' from the central bank to meet withdrawals. It is repaid as deposits return.', 'bad', co.id); }
      }
    } else if (have > 0 && co.cash > dep * 0.15) {
      let x = Math.min(have, co.cash - dep * 0.12);
      cbLoans(co).forEach(l => { const p = Math.min(l.bal, x); if (p > 0) { payCo(co, p, null, 'Central bank facility repaid'); l.bal -= p; x -= p; } });
      S.loans = S.loans.filter(l => !(l.cb && l.bal < 1));
    }
  };
  addStep('week.before', 10, 'banks borrow from the central bank in a run', () => { S.cos.forEach(co => R24.bankLiquidity(co)); });
})();

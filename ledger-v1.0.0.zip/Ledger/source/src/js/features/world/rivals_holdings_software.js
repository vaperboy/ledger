/* ===== Round 7b: rivals you can read, a guided price war, opening next to a rival, talking buyers up,
   holding companies with share management, and software from your own startup. ===== */
{
  const P = o => esc(JSON.stringify(o));
  const pillp = (t, c) => '<span class="pill ' + (c || '') + '">' + t + '</span>';
  const R7 = window.R7 = window.R7 || {};
  const hv = (a, b) => hrng(S.seed + ':' + a + ':' + b)();
  const pct = x => Math.round(x * 100) + '%';

  /* ---------- the analyst: how sharp the estimates are ---------- */
  function anaInfo() {
    const st = S.office && S.office.staff && S.office.staff.find(x => x.role === 'ana');
    if (!st) return null;
    const n = S.npcs[st.id];
    return { id: st.id, name: n ? n.name : st.name, s: clamp(((n && n.skill) || 55) / 100 + ((n && n.exp) || 0) * 0.01, 0.2, 0.98) };
  }
  R7.anaInfo = anaInfo;
  /* a range around the true value: experienced analysts are tight, juniors are either lucky-close or wide */
  function est(trueV, key, an, unit) {
    const a = hv(key, an.id), b = hv(key + 'b', an.id);
    let w, c;
    if (an.s >= 0.65) { w = Math.abs(trueV) * (0.06 + (1 - an.s) * 0.12) + unit; c = trueV * (1 + (a - 0.5) * 0.05); }
    else if (b < 0.5) { w = Math.abs(trueV) * 0.08 + unit; c = trueV * (1 + (a - 0.5) * 0.28); }
    else { w = Math.abs(trueV) * 0.55 + unit * 4; c = trueV; }
    return [c - w / 2, c + w / 2];
  }
  const rngTxt = (r, f) => f(r[0]) + '–' + f(r[1]);
  function truth(co, r) {
    const bd = BD[co.type], rs = rivalsOf(co);
    const rev = (bd.Dc || 1) * bd.ticket * cityOf(co.city).dem * r.size * 0.9 * 52;
    const margin = clamp((bd.m || 0.1) + (hv('m', r.id) - 0.5) * 0.14 - (r.pw || 0) * 0.04, -0.12, 0.45);
    const staff = Math.max(1, Math.round(bd.std.reduce((t, s) => t + s[1], 0) * r.size));
    const run = rivRun(r);
    const tot = (co.size || 1) + rs.reduce((t, x) => t + x.size, 0);
    return { rev, margin, profit: rev * margin, staff, run, share: (window.R26 && R26.rivShare ? R26.rivShare(co, r) : null) ?? r.size / tot, price: rivPrice(co, r) };
  }
  R7.truth = truth;
  const sizeW = r => r.size >= 1.15 ? 'Large' : r.size >= 0.7 ? 'Medium' : 'Small';
  const feel = (co, r, t) => t.margin > 0.14 ? 'Seems to be doing well' : t.margin > 0.05 ? 'Getting by' : t.margin > 0 ? 'Looks like thin margins' : 'Looks like they are losing money';

  /* ---------- Rivals app ---------- */
  /* every rival, company by company; p.inMarket: inside Group › Market (features/world/market_map_and_reviews.js),
     which already says what your analyst knows */
  V.rivals = function (p) {
    const cos = S.cos.filter(c => c.st === 'open' && c.type !== 'hold' && ['fin', 'energy', 'club'].indexOf(BD[c.type].fam) < 0);
    if (!cos.length) return '<div class="calm">Rivals appear once you open a business.</div>';
    const an = anaInfo();
    let h = p && p.inMarket ? '' : ('<div class="card sense"><span class="tipt">' + (an ? esc(an.name) + ', your analyst, puts numbers on each rival. ' + (an.s >= 0.65 ? 'Experienced: the ranges are tight.' : 'Still learning: some guesses are close, some are very wide.') : 'Without an analyst you only have a feeling about your rivals. Hire a data analyst in your office to get numbers.') + '</span></div>');
    cos.forEach(co => {
      const rs = rivalsOf(co);
      h += '<h2 class="sec">' + esc(co.name) + ' · ' + esc(cityOf(co.city).name) + '</h2><div class="lrows">' + rs.map(r => {
        const t = truth(co, r), my = ticketEff(co, BD[co.type]), d = t.price / my - 1;
        return '<button class="lrow" data-a="go" data-p="' + P({ n: 'rival', p: { id: co.id, r: r.id } }) + '"><span class="av">' + esc(r.name.replace(/[^A-Za-zÀ-ÿ ]/g, '').split(/\s+/).filter(Boolean).slice(0, 2).map(w => w[0]).join('')) + '</span><span class="ctext"><b>' + esc(r.name) + (r.listed ? ' · for sale' : '') + '</b><small>' + sizeW(r) + ' · ' + (an ? 'margin ' + rngTxt(est(t.margin * 100, 'mg' + r.id, an, 1), x => Math.round(x)) + '%' : feel(co, r, t)) + '</small></span>' + pillp(Math.abs(d) < 0.03 ? 'Same price' : (d > 0 ? 'Dearer ' : 'Cheaper ') + Math.abs(Math.round(d * 100)) + '%', d < -0.03 ? 'amb' : '') + '<i>›</i></button>';
      }).join('') + '</div>';
    });
    return h;
  };
  V.titles.rival = 'Rival';
  V.heads = V.heads || {};
  V.heads.rival = p => { const co = getCo(p.id), r = co && rivalsOf(co).find(x => x.id === p.r); return { t: r ? r.name : 'Rival', sub: co ? esc(BD[co.type].n) + ' · ' + esc(cityOf(co.city).name) : '' }; };
  V.rival = function (p) {
    const co = getCo(p.id), r = co && rivalsOf(co).find(x => x.id === p.r);
    if (!r) return '<div class="calm">This rival is gone.</div>';
    const t = truth(co, r), an = anaInfo(), my = ticketEff(co, BD[co.type]);
    const myRev = (co.bk.y && co.bk.y.rev) ? co.bk.y.rev / Math.max(1, (S.week % 52) || 1) * 52 : (co.lastW ? co.lastW.rev * 52 : 0);
    let h = '<div class="card"><div class="cchd"><span class="av">' + esc(r.name.replace(/[^A-Za-zÀ-ÿ ]/g, '').split(/\s+/).filter(Boolean).slice(0, 2).map(w => w[0]).join('')) + '</span><span class="ctext"><b>' + esc(r.name) + '</b><small>Owner ' + esc(r.owner) + ' · ' + sizeW(r) + ' · relationship ' + relLabel(r) + '</small></span>' + (r.listed ? pillp('For sale', 'grn') : '') + '</div></div>';
    h += '<h2 class="sec">' + (an ? 'Your analyst\'s estimate' : 'Your feeling') + '</h2><div class="card">';
    if (an) {
      h += row('Revenue a year', rngTxt(est(t.rev, 'rv' + r.id, an, 0), mshort)) + row('Margin', rngTxt(est(t.margin * 100, 'mg' + r.id, an, 1), x => Math.round(x)) + '%') + row('Profit a year', rngTxt(est(t.profit, 'pf' + r.id, an, 0), mshort)) + row('Costs a year', rngTxt(est(t.rev - t.profit, 'cs' + r.id, an, 0), mshort)) + row('Staff', rngTxt(est(t.staff, 'st' + r.id, an, 1), x => Math.max(1, Math.round(x)))) + row('Cash lasts if they lose money', rngTxt(est(t.run, 'rn' + r.id, an, 2), x => Math.max(1, Math.round(x))) + ' weeks') + row('Market share', rngTxt(est(t.share * 100, 'sh' + r.id, an, 2), x => Math.max(0, Math.round(x))) + '%');
      h += '<span class="tipt">' + esc(an.name) + (an.s >= 0.65 ? ' is experienced, so these ranges are close to the truth.' : ' is fairly new. A narrow range may still be off; a wide one is an honest "not sure".') + '</span>';
    } else {
      h += row('Size', t.rev > myRev * 1.3 ? 'Bigger than you' : t.rev < myRev * 0.75 ? 'Smaller than you' : 'About your size') + row('Money', feel(co, r, t)) + row('If it got tough', t.run >= 14 ? 'Could hold out a long time' : t.run >= 9 ? 'Could last a while' : 'Money looks tight') + row('Staff', t.staff >= 10 ? 'A big team' : t.staff >= 4 ? 'A handful of people' : 'Just a few');
      h += '<span class="tipt">Only gut feeling. A data analyst in your office can estimate their revenue, margin and cash.</span>';
    }
    const d = t.price / my - 1;
    h += row('Their price vs yours', Math.abs(d) < 0.03 ? 'About the same' : (d > 0 ? 'Higher by about ' : 'Lower by about ') + Math.abs(Math.round(d * 100)) + '%') + '</div>';
    h += '<h2 class="sec">What you can do</h2><div class="lrows"><button class="lrow" data-a="rivmeet" data-p="' + P({ id: co.id, r: r.id }) + '"><span class="ctext"><b>Meet the owner</b><small>Better relations, and maybe a deal later</small></span><i>›</i></button><button class="lrow" data-a="rivbuy" data-p="' + P({ id: co.id, r: r.id }) + '"><span class="ctext"><b>Offer to buy them</b><small>' + (r.listed ? 'They are open to offers' : 'Not for sale, so it takes a good price') + '</small></span><i>›</i></button><button class="lrow" data-a="go" data-p="' + P({ n: 'pricewar', p: { id: co.id, r: r.id } }) + '"><span class="ctext"><b>Price war against them</b><small>Undercut until one of you runs out of cash</small></span><i>›</i></button><button class="lrow" data-a="go" data-p="' + P({ n: 'branch', p: { id: co.id, r: r.id } }) + '"><span class="ctext"><b>Open next to their best site</b><small>A new site of your own on their doorstep</small></span><i>›</i></button>' +
      /* invite the owner to your yacht, jet, castle or island (features/people/perks_and_hosting.js) */
      (window.PK58 && PK58.venues().length ? '<button class="lrow" data-a="pk58hgo" data-p="' + P({ x: PK58.venues()[0].id, k: 'riv', co: co.id, r: r.id }) + '"><span class="ctext"><b>Invite ' + esc(r.owner.split(' ')[0]) + ' to ' + esc((LUX47.LUXI[PK58.venues()[0].k] || {}).n || 'your place') + '</b><small>' + (PK58.hosted('r:' + r.id) ? 'Hosted lately: your offers count for more' : 'An evening there: for three months your offers count for more') + '</small></span><i>›</i></button>' : '') + '</div>';
    return h;
  };

  /* ---------- the price war, explained ---------- */
  V.titles.pricewar = 'Price war';
  V.heads.pricewar = p => { const co = getCo(p.id); return { t: 'Price war', sub: co ? esc(co.name) + ' · ' + esc(cityOf(co.city).name) : '' }; };
  function warCalc(co, r, wk) {
    const bd = BD[co.type], rs = rivalsOf(co), t = truth(co, r), w = co.lastW || {};
    const lossW = Math.round((w.rev || ticketEff(co, bd) * 10) * 0.3);
    const myRun = lossW > 0 ? Math.floor(Math.max(0, co.cash) / lossW) : 99;
    const others = rs.filter(x => x !== r);
    const mine = co.size || 1, oth = others.reduce((s, x) => s + x.size, 0);
    const toYou = clamp(mine * 1.6 / (mine * 1.6 + oth), 0.15, 0.95);
    const big = others.slice().sort((a, b) => b.size - a.size)[0];
    let odds = clamp(0.25 + (co.cash > lossW * t.run * 1.3 ? 0.35 : co.cash > lossW * t.run * 0.7 ? 0.15 : 0) + (1.2 - r.size) * 0.2, 0.05, 0.9);
    if (wk < t.run) odds *= clamp(wk / t.run, 0.2, 1) * 0.7;
    return { t, lossW, myRun, toYou, big, odds, cost: lossW * wk, share: mine / (mine + oth + r.size), others };
  }
  const oddsWord = o => o >= 0.65 ? 'I think they would fold' : o >= 0.45 ? 'Could go either way' : o >= 0.25 ? 'They would probably survive' : 'Very unlikely to work';
  V.pricewar = function (p) {
    const co = getCo(p.id);
    if (!co || co.st !== 'open') return '<div class="calm">Only an open company can start a price war.</div>';
    const rs = rivalsOf(co), an = anaInfo();
    if (!rs.length) return '<div class="calm">No rivals in this market.</div>';
    const pw = co.flags.pw;
    let h = '';
    if (pw) {
      const r0 = rs.find(x => x.id === pw.rid);
      return '<div class="card probcard"><b>Price war with ' + esc(r0 ? r0.name : 'a rival') + '</b>' + row('Weeks left', Math.max(0, pw.end - S.week)) + row('Revenue given up so far', nok(pw.loss || 0)) + '<span class="tipt">Your prices stay at rock bottom until it ends. Ending early saves money, but they recover.</span>' + btn('End the price war now', 'pwend', { id: co.id }, 'wide') + '</div>';
    }
    const W = ui.pwx = ui.pwx && ui.pwx.id === co.id ? ui.pwx : { id: co.id, r: p.r || rs.slice().sort((a, b) => a.size - b.size)[0].id, wk: 10 };
    const r = rs.find(x => x.id === W.r) || rs[0];
    W.r = r.id;
    const c = warCalc(co, r, W.wk);
    h += '<div class="card sense"><b>What is a price war?</b><span class="tipt">You drop your prices to rock bottom so customers leave a rival. They lose money every week, and so do you. Whoever runs out of cash first loses. If they close, their customers look for somewhere new: some come to you, some go to other rivals.</span></div>';
    h += '<div class="card"><div class="bhead"><b>How it works</b></div>' + ['Pick the rival you want to push out.', 'Your prices go to the lowest level for the weeks you choose.', 'You earn about a third less every week while it runs.', 'If they run out of money first, they close.', 'Afterwards your prices go back to normal.'].map((x, i) => '<div class="step"><i>' + (i + 1) + '</i><div>' + x + '</div></div>').join('') + '</div>';
    h += '<h2 class="sec">Who</h2><div class="lrows">' + rs.map(x => { const tx = truth(co, x); return '<button class="lrow" data-a="pwpick" data-p="' + P({ r: x.id }) + '"><span class="ctext"><b>' + esc(x.name) + '</b><small>' + sizeW(x) + ' · ' + (an ? 'cash lasts ' + rngTxt(est(tx.run, 'rn' + x.id, an, 2), v => Math.max(1, Math.round(v))) + ' wk' : feel(co, x, tx)) + '</small></span><span class="radio' + (x.id === r.id ? ' on' : '') + '"></span></button>'; }).join('') + '</div>';
    h += '<h2 class="sec">How long</h2>' + chips([[6, '6 weeks'], [10, '10 weeks'], [14, '14 weeks'], [20, '20 weeks']], W.wk, 'pwlen');
    h += '<h2 class="sec">Your chances</h2><div class="card">';
    h += row('They can hold out', an ? rngTxt(est(c.t.run, 'rn' + r.id, an, 2), v => Math.max(1, Math.round(v))) + ' weeks' : (c.t.run >= 14 ? 'A long time, I think' : c.t.run >= 9 ? 'A couple of months, maybe' : 'Not long, it seems'));
    h += row('You can hold out', c.myRun >= 99 ? 'As long as you like' : '<span class="' + (c.myRun < W.wk ? 'neg' : 'pos') + '">About ' + c.myRun + ' weeks</span>');
    h += row('Chance they close', an ? (() => { const e = (1 - an.s) * 0.18 + 0.03, m = c.odds + (hv('od' + r.id, an.id) - 0.5) * (1 - an.s) * 0.2; return 'About ' + Math.max(0, Math.round((m - e) * 100)) + '–' + Math.min(100, Math.round((m + e) * 100)) + '%'; })() : oddsWord(c.odds));
    h += row('Where their customers go', an ? 'About ' + pct(c.toYou) + ' to you' + (c.big ? ', ' + pct(1 - c.toYou) + ' to others' : '') : (c.toYou >= 0.6 ? 'Most should come to you' : c.big ? 'Many may go to ' + esc(c.big.name) : 'Hard to say'));
    h += row('It costs you about', '<span class="neg">' + mshort(c.cost) + '</span>') + row('Competition authority', c.share >= 0.35 ? '<span class="neg">Can fine you: you are big here</span>' : 'Low risk at your size') + '</div>';
    if (c.big && c.toYou < 0.5) h += '<div class="card sense"><b>You may mostly help ' + esc(c.big.name) + '</b><span class="tipt">They are bigger than you, so more of the customers end up with them. You pay for the war, they get the reward.</span></div>';
    if (c.myRun < W.wk) h += '<div class="card sense"><b>You may run out first</b><span class="tipt">At this pace your cash lasts about ' + c.myRun + ' weeks. Put money in first, or choose a shorter war.</span></div>';
    if (!an) h += '<p class="muted small">A data analyst gives you ranges and real odds.</p>';
    h += btn('Start a price war against ' + esc(r.name), 'pwgo7', { id: co.id }, 'primary wide go');
    return h;
  };
  ACT.pwpick = p => { ui.pwx.r = p.r; render(); };
  ACT.pwlen = p => { ui.pwx.wk = p.v; render(); };
  ACT.pwgo7 = p => {
    const co = getCo(p.id), W = ui.pwx, r = rivalsOf(co).find(x => x.id === W.r);
    if (!r) return;
    const c = warCalc(co, r, W.wk);
    ACT.pwgo({ id: co.id, r: r.id, w: W.wk, odds: c.odds, share: c.share });
    co.flags.pwTo = c.toYou;
  };
  /* after a rival closes, its customers spread out: some to you, some to the others */
  addStep('week.before', 30, 'price wars: who is still standing', (ctx) => {
    ctx.pw = S.cos.filter(c => c.flags && c.flags.pw).map(c => ({ c, pw: c.flags.pw, rs: rivalsOf(c).slice() }));
  });
  addStep('week.after', 50, 'price wars: a rival that gave up leaves you its customers', (ctx) => {
    {
      (ctx.pw || []).forEach(b => {
        if (b.c.flags.pw) return;
        const now = rivalsOf(b.c), gone = b.rs.find(x => x.id === b.pw.rid && now.indexOf(x) < 0);
        if (!gone) return;
        const to = b.c.flags.pwTo != null ? b.c.flags.pwTo : 0.6;
        b.c.aware = Math.min(100, b.c.aware + 10 * to);
        b.c.size = Math.min(BD[b.c.type].maxSize || 3, (b.c.size || 1) + gone.size * to * 0.25);
        const oth = now.reduce((t, x) => t + x.size, 0) || 1;
        now.forEach(x => { x.size = Math.round((x.size + gone.size * (1 - to) * x.size / oth) * 100) / 100; });
        if (to < 0.5 && now.length) note('Most of ' + gone.name + '\'s customers went to ' + now.slice().sort((a, b2) => b2.size - a.size)[0].name + ', not to you.', 'bad', b.c.id);
        delete b.c.flags.pwTo;
      });
    }
  });

  /* ---------- open next to a rival: a new site of your own, after the franchise papers ---------- */
  V.titles.branch = 'New site';
  V.heads.branch = p => { const co = getCo(p.id), r = co && rivalsOf(co).find(x => x.id === p.r); return { t: 'Open next to ' + (r ? r.name : 'a rival'), sub: co ? esc(co.name) + ' · ' + esc(cityOf(co.city).name) : '' }; };
  V.branch = function (p) {
    const co = getCo(p.id), r = co && rivalsOf(co).find(x => x.id === p.r);
    if (!r) return '<div class="calm">That rival is gone.</div>';
    const bd = BD[co.type], d = co.docs.fran, dd = DOCS.fran;
    const ok = docOk(co, 'fran');
    let h = '<div class="card sense"><b>A new ' + esc(bd.n.toLowerCase()) + ' under your name</b><span class="tipt">Open a site of ' + esc(co.name) + ' right next to ' + esc(r.name) + '\'s busiest place. It carries your brand, so people know you from day one, and it pulls customers straight from them.</span></div>';
    h += '<h2 class="sec">Step 1 · Franchise papers</h2><div class="card"><div class="bhead"><b>' + esc(dd[0]) + '</b>' + pillp(ok ? 'Approved' : d && d.st === 'applied' ? 'Ready in ' + Math.max(0, d.done - S.week) + ' wk' : 'Needed', ok ? 'grn' : d && d.st === 'applied' ? 'amb' : 'red') + '</div><span class="tipt">Your concept, brand rules and operations manual written down, so every site runs the same way. Needed before you open a second site under the same name.</span>' + (ok || (d && d.st === 'applied') ? '' : row('Cost', money(docCost(co, 'fran'))) + row('Takes', 'about ' + Math.max(1, docWeeks(co, 'fran')) + ' weeks') + btn('Apply for franchise papers', 'applydoc', { id: co.id, d: 'fran' }, 'primary wide')) + '</div>';
    h += '<h2 class="sec">Step 2 · The new site</h2><div class="card">' + row('Where', 'Next to ' + esc(r.name) + ', ' + esc(cityOf(co.city).name)) + row('Your name', 'Known from day one') + row('Effect on ' + esc(r.name), 'Loses customers every week you are open') + row('Start-up cost, about', mshort(setupEstimate(co.type, { city: co.city, country: co.country, size: co.size || 1, form: co.form }).total)) + '<span class="tipt">It is its own company with its own books. You set up premises, staff and equipment like any new company.</span></div>';
    h += ok ? btn('Open the new site', 'branchgo', { id: co.id, r: r.id }, 'primary wide go') : '<div class="calm">You can open the site once the franchise papers are approved.</div>';
    return h;
  };
  ACT.branchgo = p => {
    const co = getCo(p.id), r = rivalsOf(co).find(x => x.id === p.r);
    if (!r || !docOk(co, 'fran')) return;
    const n0 = S.cos.filter(c => c.type === co.type && c.name.indexOf(co.name) === 0).length;
    const n = startCompany(co.type, { city: co.city, country: co.country, name: co.name + ' ' + (n0 + 1), form: co.form });
    if (!n || typeof n === 'string') { toast(n === 'cash' ? 'Not enough money to start it.' : 'Could not start the site.', true); return; }
    n.branch = { of: co.id, r: r.id };
    n.aware = Math.max(n.aware, co.aware * 0.6);
    n.rep = Math.max(n.rep, co.rep * 0.9);
    n.docs.fran = Object.assign({}, co.docs.fran);
    save();
    ui.stack = [];
    ui.tab = 'cos';
    ui.view = { n: 'co', p: { id: n.id, t: 'ov' } };
    render(true);
    toast(n.name + ' is registered. Set it up to open.');
  };
  R7.afterCoWeek = function (co) {
    if (co.branch && co.st === 'open') {
      const r = rivalsOf(co).find(x => x.id === co.branch.r);
      if (r) { r.size = Math.max(0.3, Math.round((r.size - 0.006) * 1000) / 1000); co.aware = Math.min(100, co.aware + 0.2); }
    }
    ownSwWeek(co);
  };

  /* ---------- selling: offers come from the market, and you can talk them up ---------- */
  V.sale = pipeView('V.sale', V.sale, 1); /* V.sale: the screen above, then the steps below and in later files */
  addStep('V.sale', 10, '---------- selling: offers come from the market, and you can talk them up ----------', (p, h) => {
    h = h.replace(/<button class="btn ([^"]*)" data-a="salectr" data-p="([^"]+)">[^<]*<\/button>/g, (m, cls, pp) => '<button class="btn ' + cls + '" data-a="saletalk" data-p="' + pp + '">Discuss</button>');
    h = h.replace('Quiet private sale', 'Private sale').replace('Use a broker', 'Open market through a broker');
    return h;
  });
  const SALES7 = () => (S.sales = S.sales || []);
  const findO = p => { const L = SALES7().find(x => x.co === p.id); return [L, L && L.offers.find(o => o.id === p.o)]; };
  ACT.saletalk = p => go('saletalk', { id: p.id, o: p.o });
  V.titles.saletalk = 'Offer';
  V.saletalk = function (p) {
    const co = getCo(p.id), [L, o] = findO(p);
    if (!co || !o) return '<div class="calm">This offer is no longer on the table.</div>';
    o.max = o.max || rnl(o.price * (1 + rng(o.k === 'rival' || o.k === 'fund' ? 0.06 : 0.02, o.k === 'rival' ? 0.22 : 0.14)), 1000);
    o.pat = o.pat == null ? 3 : o.pat;
    o.talk = o.talk || [];
    const who = { id: o.id, name: o.name, age: 50 };
    const msgs = [{ me: 0, t: 'We would like to buy ' + (L.pct === 100 ? co.name : L.pct + '% of your shares') + ' for ' + money(o.price) + '. ' + o.note }].concat(o.talk);
    const k = 'sp' + o.id;
    let h = '<div class="ichat"><div class="vh"><button class="bk" data-a="back" aria-label="Back">‹</button>' + faceAv(who) + '<div class="vht"><h1>' + esc(o.name) + '</h1><p>Offer ' + mshort(o.price) + ' · open until ' + dateStr(o.exp) + '</p></div><span class="pdots">' + [0, 1, 2].map(i => '<i class="' + (i < o.pat ? 'on' : '') + '"></i>').join('') + '</span></div>';
    h += '<div class="clog">' + msgs.map(x => '<div class="bub ' + (x.sys ? 'sys' : x.me ? 'me' : 'them') + '">' + esc(x.t) + '</div>').join('') + '</div><div class="composer">';
    h += '<div class="chips qk">' + btn('Ask about staff', 'saleq', { id: co.id, o: o.id, q: 'staff' }, 'chip') + btn('Ask about payment', 'saleq', { id: co.id, o: o.id, q: 'pay' }, 'chip') + btn('Walk away', 'saledec7', { id: co.id, o: o.id }, 'chip ghost') + '</div>';
    h += '<div class="chips qk">' + [1.05, 1.1, 1.2].map(f => '<button class="btn chip" data-a="setinp" data-p="' + P({ k, v: rnl(o.price * f, 1000) }) + '">+' + Math.round((f - 1) * 100) + '% · ' + mshort(o.price * f) + '</button>').join('') + '</div>';
    h += '<div class="crow">' + U.inp(k, 'Your price', o.price) + btn('Counter', 'salecounter', { id: co.id, o: o.id }, '') + btn('Accept', 'saleacc', { id: co.id, o: o.id }, 'primary') + '</div></div></div>';
    return h;
  };
  ACT.saleq = p => {
    const [, o] = findO(p);
    if (!o) return;
    o.talk = o.talk || [];
    if (p.q === 'staff') { o.talk.push({ me: 1, t: 'What happens to my staff?' }); o.talk.push({ me: 0, t: { rival: 'We would merge it with ours. Some jobs will go.', fund: 'We keep the team and the name. We want it to grow.', mbo: 'I know everyone here. Nobody goes.', private: 'I want to run it as it is.', angel: 'The team stays, but I want a say.' }[o.k] || 'They stay for now.' }); }
    else { o.talk.push({ me: 1, t: 'How would you pay?' }); o.talk.push({ me: 0, t: o.k === 'mbo' ? 'Two thirds now, the rest as a seller loan over two years.' : o.later ? 'Part now, part later if profits hold.' : 'Cash on closing.' }); }
    save();
    render();
  };
  ACT.salecounter = p => {
    const co = getCo(p.id), [L, o] = findO(p);
    if (!o) return;
    const ask = rnl(U.inum('sp' + o.id, o.price), 1000);
    o.talk.push({ me: 1, t: 'I want ' + money(ask) + '.' });
    if (ask <= o.price) o.talk.push({ me: 0, t: 'That is what we offered. Shall we sign?' });
    else if (ask <= o.max) { o.price = ask; o.talk.push({ me: 0, t: 'Fine. ' + money(ask) + ' it is.' }); }
    else if (ask <= o.max * 1.1) { o.price = Math.min(o.max, rnl((o.price + o.max) / 2, 1000)); o.pat--; o.talk.push({ me: 0, t: 'We can stretch to ' + money(o.price) + '. That is about as far as we go.' }); }
    else { o.pat -= 2; o.talk.push({ me: 0, t: 'That is far above what it is worth to us.' }); }
    if (o.pat <= 0) {
      o.talk.push({ sys: 1, t: o.name + ' walked away.' });
      L.offers = L.offers.filter(x => x !== o);
      toast(o.name + ' walked away.', true);
      save();
      U.back();
      return;
    }
    save();
    render();
  };
  ACT.saledec7 = p => { ACT.saledec(p); U.back(); };
  /* the money page no longer has instant offers: selling goes through the market */
  window.R7DEAL = {
    sell: co => {
      const L = SALES7().find(x => x.co === co.id);
      return '<div class="lrows">' + (L ? '<button class="lrow" data-a="go" data-p="' + P({ n: 'sale', p: { id: co.id } }) + '"><span class="lic">' + svg('deal', 20) + '</span><span class="ctext"><b>On the market</b><small>' + (L.pct === 100 ? 'Whole company' : L.pct + '% of your shares') + ' · ' + L.offers.length + ' offer' + (L.offers.length === 1 ? '' : 's') + '</small></span><i>›</i></button>' :
        '<button class="lrow" data-a="go" data-p="' + P({ n: 'sale', p: { id: co.id } }) + '"><span class="lic">' + svg('deal', 20) + '</span><span class="ctext"><b>Sell the company</b><small>Put it on the market, privately or openly, and discuss offers</small></span><i>›</i></button>') + '</div>';
    }
  };

  /* ---------- holding companies: share management, not business management ---------- */
  HQ_ROLES.fin = ['Finance manager', 82000, 'Runs your holding companies: invests spare cash, raises money when you ask, and negotiates share sales.'];
  window.hqUnlocked = pipeView('window.hqUnlocked', window.hqUnlocked, 1);
  addStep('window.hqUnlocked.around', 10, 'rivals_holdings_software window.hqUnlocked', (k, next) => {
    return k === 'fin' ? S.cos.some(c => c.type === 'hold' && c.st === 'open') : next();
  });
  if (window.hqUnlockText) {
    window.hqUnlockText = pipeView('window.hqUnlockText', window.hqUnlockText, 1);
    addStep('window.hqUnlockText.around', 10, 'rivals_holdings_software window.hqUnlockText', (k, next) => { return k === 'fin' ? 'a holding company' : next(); });
  }
  window.hqResult = pipeView('window.hqResult', window.hqResult, 1);
  addStep('window.hqResult.around', 10, 'rivals_holdings_software window.hqResult', (k, next) => {
    return k === 'fin' ? (() => { const st = S.office.staff.find(x => x.role === 'fin'); const n = (st && st.holds || []).length; return n ? 'Manages ' + n + (n > 1 ? ' holding companies' : ' holding company') : 'Not assigned to a holding yet'; })() : next();
  });
  const holds = () => S.cos.filter(c => c.type === 'hold' && c.st === 'open');
  const finSt = () => S.office && S.office.staff.find(x => x.role === 'fin');
  function holdValue(h) {
    const kids = S.cos.filter(c => c.hold === h.id && c.st !== 'sold' && c.st !== 'bust');
    return kids.reduce((t, c) => t + Math.max(0, companyValue(c)) * c.own / 100, 0) + h.cash + (h.fm && h.fm.idxU ? h.fm.idxU * fundPx('idx') : 0);
  }
  R7.holdValue = holdValue;
  /* the holding's tax group (taxGroup, groupContrib in engine/money/money.js): what group contribution saves this year */
  function groupTaxLine(x) {
    const L = typeof taxGroup === 'function' ? taxGroup(x) : null;
    if (!L) return '';
    let cov = 0, saved = 0;
    L.forEach(c => { const g = c.gc || {}; if (g.out > 0) { cov += g.out; saved += g.out * coTaxRate(c); } });
    return '<span class="tipt">Tax group of ' + L.length + ' companies' + (cov > 0 ? ': profits cover ' + mshort(cov) + ' of sister companies\' losses this year, saving about ' + mshort(saved) + ' in tax.' : '. Profits in one can cover losses in another in the same year.') + '</span>';
  }
  V.titles.holdings = 'Holding companies';
  V.holdings = function () {
    let h = '<div class="card sense"><span class="tipt">A holding company owns shares in your companies. Dividends into it are taxed far lower, it can invest, and it can raise money by selling its own shares, privately or on the stock exchange.</span></div>';
    h += holds().map(x => '<button class="card opt2" data-a="go" data-p="' + P({ n: 'co', p: { id: x.id } }) + '"><div class="cchd">' + pic('building', x.id) + '<span class="ctext"><b>' + esc(x.name) + '</b><small>' + S.cos.filter(c => c.hold === x.id && c.st !== 'sold' && c.st !== 'bust').length + ' companies · you own ' + Math.round(x.own) + '%</small></span>' + pillp(x.listed ? 'Listed' : 'Private', x.listed ? 'blue' : '') + '</div><div class="tri"><div><span>Value</span><b>' + mshort(holdValue(x)) + '</b></div><div><span>Cash</span><b>' + mshort(x.cash) + '</b></div><div><span>Managed by</span><b>' + (finSt() && (finSt().holds || []).indexOf(x.id) >= 0 ? esc(finSt().name.split(' ')[0]) : 'You') + '</b></div></div>' + groupTaxLine(x) + '</button>').join('');
    return h + btn('＋ Create a holding company', 'go', { n: 'newhold' }, 'primary wide');
  };
  ACT.newhold = () => go('newhold');
  V.titles.newhold = 'New holding company';
  V.newhold = function () {
    const c = CC(), s = ui.nh = ui.nh || { cos: [], pub: 'private', acc: (S.pool.acc[1] || S.pool.acc[0]).id };
    const el = S.cos.filter(x => x.st !== 'sold' && x.st !== 'bust' && x.type !== 'hold' && !x.hold);
    const fee = KC(1500000);
    let h = '<h2 class="sec">Name</h2>' + U.inp('nhname', 'Holding company name', (S.player.name || 'My').split(' ').pop() + ' Holding ' + c.forms.ASs, 'text');
    h += '<h2 class="sec">Which companies it holds</h2><div class="lrows">' + (el.length ? el.map(x => x.form === 'AS' ? '<button class="lrow" data-a="nhco" data-p="' + P({ id: x.id }) + '"><span class="ctext"><b>' + esc(x.name) + '</b><small>Value ' + mshort(Math.max(0, companyValue(x))) + ' · you own ' + Math.round(x.own) + '%</small></span><span class="radio' + (s.cos.indexOf(x.id) >= 0 ? ' on' : '') + '"></span></button>' : '<div class="lrow"><span class="ctext"><b>' + esc(x.name) + '</b><small>Sole proprietorship: convert to ' + esc(c.forms.AS) + ' first</small></span></div>').join('') : '<div class="lrow"><small>No companies yet. You can add them later.</small></div>') + '</div>';
    h += '<h2 class="sec">Who can own shares</h2><div class="lrows"><button class="lrow" data-a="nhpub" data-p="' + P({ v: 'private' }) + '"><span class="ctext"><b>Private</b><small>Only you, and investors you pick yourself</small></span><span class="radio' + (s.pub === 'private' ? ' on' : '') + '"></span></button><button class="lrow" data-a="nhpub" data-p="' + P({ v: 'public' }) + '"><span class="ctext"><b>Public, listed on the exchange</b><small>Listed through a bank for ' + mshort(fee) + '. Anyone can buy shares; you report every quarter.</small></span><span class="radio' + (s.pub === 'public' ? ' on' : '') + '"></span></button></div>';
    h += '<h2 class="sec">Accountant</h2>' + U.ddown(S.pool.acc.map(a => [a.id, esc((a.tier ? a.tier + ' · ' : '') + a.name + ' · ' + mshort(a.fee) + '/mo')]), s.acc, 'nhacc');
    const tot = c.asCapital + c.asFee + (s.pub === 'public' ? fee : 0);
    h += '<div class="card sense"><b>What it costs</b>' + row('Share capital (stays in the holding)', mshort(c.asCapital)) + row('Registration', mshort(c.asFee)) + (s.pub === 'public' ? row('Bank listing fee', mshort(fee)) : '') + row('Total now', '<b>' + mshort(tot) + '</b>') + '<span class="tipt">Companies you add keep their own managers. The holding only owns the shares: you manage shares and money here, not the businesses.</span></div>';
    return h + btn('Create the holding company', 'nhgo', undefined, 'primary wide go');
  };
  ACT.nhco = p => { const L = ui.nh.cos, i = L.indexOf(p.id); if (i >= 0) L.splice(i, 1); else L.push(p.id); render(); };
  ACT.nhpub = p => { ui.nh.pub = p.v; render(); };
  ACT.nhacc = p => { ui.nh.acc = p.v; render(); };
  ACT.nhgo = () => {
    const s = ui.nh, c = CC(), fee = KC(1500000);
    const tot = c.asCapital + c.asFee + (s.pub === 'public' ? fee : 0);
    if (S.cash < tot) { toast('You need ' + money(tot) + ' in your account.', true); return; }
    const nm = String(ui.inp.nhname || '').trim() || (S.player.name || 'My').split(' ').pop() + ' Holding ' + c.forms.ASs;
    const h = createHolding(nm, s.acc);
    if (!h) { toast('Not enough money.', true); return; }
    s.cos.forEach(id => { const x = getCo(id); if (x) moveToHolding(x, h.id); });
    if (s.pub === 'public') { payMe(fee, 'Stock exchange listing'); h.listed = 1; }
    ui.nh = null;
    ui.inp.nhname = '';
    save();
    ui.stack = [];
    ui.tab = 'hq';
    ui.view = { n: 'co', p: { id: h.id } };
    render(true);
    toast(h.name + ' is registered.');
  };
  V.co = pipeView('V.co', V.co, 1); /* V.co: the screen above, then the steps below and in later files */
  addStep('V.co.route', 10, 'a holding company opens its own screen', (p) => {
    const co = getCo(p.id);
    if (co && co.type === 'hold' && co.st !== 'sold') return holdingView(co, p);
  });
  addStep('V.heads.co.around', 20, 'rivals_holdings_software V.heads.co', (p, next) => {
    const co = getCo(p.id);
    if (co && co.type === 'hold') return { t: co.name, sub: 'Holding company · ' + (co.listed ? 'listed on the exchange' : 'private') + ' · you own ' + Math.round(co.own) + '%', right: pillp(co.listed ? 'Listed' : 'Private', co.listed ? 'blue' : '') };
    return next();
  });
  function raisePlan(h, goal, mode) {
    const V0 = Math.max(KC(100000), holdValue(h));
    const st = finSt(), mg = st && (st.holds || []).indexOf(h.id) >= 0 ? S.npcs[st.id] : null;
    const s = mg ? clamp(((mg.skill || 55) / 100) + (mg.exp || 0) * 0.01, 0.2, 0.98) : null;
    const f = mode === 'public' ? 0.97 : s != null ? 0.78 + 0.3 * s : 0.9;
    const over = mode === 'public' ? 0 : s != null ? (1 - s) * 0.7 : 0.1;
    const q = 100 * goal / (V0 * f + goal);
    const qa = Math.min(49, q * (1 + over));
    const amt = Math.round(qa * V0 * f / (100 - qa));
    return { V0, f, q, qa, amt, mg, s, fee: mode === 'public' ? Math.round(amt * 0.03) : 0 };
  }
  function holdingView(h, p) {
    const t = ui.hdt || 'ov';
    const kids = S.cos.filter(c => c.hold === h.id && c.st !== 'sold' && c.st !== 'bust');
    const st = finSt(), mine = st && (st.holds || []).indexOf(h.id) >= 0;
    let o = '<div class="ptabs">' + [['ov', 'Overview'], ['cos', 'Companies'], ['sh', 'Shares'], ['acc', 'Accounts']].map(x => '<button class="' + (t === x[0] ? 'on' : '') + '" data-a="hdt" data-p="' + P(x[0]) + '">' + x[1] + '</button>').join('') + '</div>';
    const k = 'hamt' + h.id;
    if (t === 'ov') {
      o += '<div class="tri"><div><span>Value</span><b>' + mshort(holdValue(h)) + '</b></div><div><span>Cash</span><b class="' + sgn(h.cash) + '">' + mshort(h.cash) + '</b></div><div><span>You own</span><b>' + Math.round(h.own) + '%</b></div></div>';
      o += '<div class="card">' + row('Companies held', kids.length) + row('Index fund', nok((h.fm && h.fm.idxU || 0) * fundPx('idx'))) + row('Income this year', nok((h.bk.y && h.bk.y.rev) || 0)) + (h.listed ? row('Share price', mshort(holdValue(h) / 1e6) + ' per share') : '') + '</div>';
      o += '<h2 class="sec">Finance manager</h2><div class="card">' + (st ? (mine ? row('Managed by', esc(st.name)) + '<span class="tipt">' + esc(st.name.split(' ')[0]) + ' invests spare cash and keeps a buffer. Shares are only sold when you ask.</span>' + btn('Manage it myself', 'hfin', { id: h.id }, 'chip') : '<span class="tipt">' + esc(st.name) + ' can run this holding: investing spare cash and negotiating share sales when you ask.</span>' + btn('Let ' + esc(st.name.split(' ')[0]) + ' manage it', 'hfin', { id: h.id }, 'chip primary')) : '<span class="tipt">Hire a finance manager in your office to run holdings for you. An experienced one gets good prices; a new one may sell more shares than needed.</span>' + btn('Open the office', 'go', { n: 'hq', p: { t: 'office' } }, 'chip')) + '</div>';
      /* round 56: take money out of the holding for yourself, as a dividend (taxed as yours) or a salary */
      { const av = Math.max(0, divMax(h)); o += '<div class="lrows"><button class="lrow" data-a="go" data-p="' + P({ n: 'payself', p: { id: h.id } }) + '"><span class="lic">' + svg('coin', 20) + '</span><span class="ctext"><b>Pay yourself</b><small>' + (av > 0 ? 'Up to ' + mshort(av) + ' as a dividend now' : 'No profit to pay out yet: dividends from your companies come in first') + '</small></span><i>›</i></button></div>'; }
      o += '<h2 class="sec">Move money</h2><div class="card">' + U.inp(k, 'Amount', null) + '<div class="chips">' + btn('Put money in', 'injhold', { id: h.id }, 'chip') + btn('Invest in index', 'holdin', { id: h.id }, 'chip') + btn('Sell index', 'holdout', { id: h.id }, 'chip') + '</div></div>';
    } else if (t === 'cos') {
      o += '<div class="lrows">' + (kids.length ? kids.map(c => '<div class="lrow"><span class="ctext"><b>' + esc(c.name) + '</b><small>' + esc(BD[c.type].n) + ' · ' + Math.round(c.own) + '% · value ' + mshort(Math.max(0, companyValue(c)) * c.own / 100) + '</small></span>' + btn('Open', 'go', { n: 'co', p: { id: c.id } }, 'chip') + btn('Release', 'hrel', { id: c.id }, 'chip ghost') + '</div>').join('') : '<div class="lrow"><small>No companies yet.</small></div>') + '</div>';
      const el = S.cos.filter(x => x.st !== 'sold' && x.st !== 'bust' && x.type !== 'hold' && !x.hold && x.form === 'AS');
      if (el.length) o += '<h2 class="sec">Add a company</h2><div class="lrows">' + el.map(x => '<div class="lrow"><span class="ctext"><b>' + esc(x.name) + '</b><small>Value ' + mshort(Math.max(0, companyValue(x))) + '</small></span>' + btn('Add', 'tohold', { id: x.id, h: h.id }, 'chip primary') + '</div>').join('') + '</div>';
    } else if (t === 'sh') {
      o += '<h2 class="sec">Shareholders</h2><div class="lrows"><div class="lrow"><span class="ctext"><b>You</b></span><b>' + (Math.round(h.own * 10) / 10) + '%</b></div>' + (h.holders || []).map(x => '<div class="lrow"><span class="ctext"><b>' + esc(x.name) + '</b></span><b>' + (Math.round(x.pct * 10) / 10) + '%</b></div>').join('') + '</div>';
      const g = Math.max(0, U.inum('hgoal' + h.id, 0)), mode = ui.hmode7 || (h.listed ? 'public' : 'private');
      o += '<h2 class="sec">Raise money</h2><div class="card">' + (h.listed ? chips([['private', 'Private investors'], ['public', 'On the exchange']], mode, 'hmode7') : '') + U.inp('hgoal' + h.id, 'How much the holding needs', null) + U.quick('hgoal' + h.id, [KC(1000000), KC(5000000), KC(20000000)].map(niceAmt));
      if (g > 0) {
        const r = raisePlan(h, g, mode);
        o += row('Who negotiates', mode === 'public' ? 'The bank, on the exchange' : r.mg ? esc(r.mg.name) + (r.s >= 0.7 ? ' · experienced' : ' · still learning') : 'You') + row('Expected', 'About ' + (Math.round(r.qa * 10) / 10) + '% for ' + mshort(r.amt)) + (r.qa > r.q * 1.15 ? '<div class="note bad">Likely to sell more shares than needed (' + (Math.round(r.q * 10) / 10) + '% would do).</div>' : '') + '<span class="tipt">New shares are issued, so the money goes into the holding and your share shrinks.</span>' + btn('Raise ' + mshort(g), 'hraise', { id: h.id }, 'chip primary');
      }
      o += '</div>';
      if (!h.listed) o += '<div class="card"><div class="bhead"><b>List it on the exchange</b>' + pillp(mshort(KC(1500000))) + '</div><span class="tipt">A bank takes it to the stock exchange. Anyone can then buy shares, so raising money is quicker and the price is fair, but you report every quarter. Needs a value of at least ' + mshort(niceAmt(30000000)) + '.</span>' + btn('Go public', 'hlist', { id: h.id }, 'chip') + '</div>';
    } else o += window.R6FIN.books(h, BD.hold);
    return o;
  }
  ACT.hdt = p => { ui.hdt = p; render(); };
  ACT.hmode7 = p => { ui.hmode7 = p.v; render(); };
  ACT.hfin = p => {
    const st = finSt();
    if (!st) return;
    st.holds = st.holds || [];
    const i = st.holds.indexOf(p.id);
    if (i >= 0) st.holds.splice(i, 1); else st.holds.push(p.id);
    save();
    render();
  };
  ACT.hrel = p => { const c = getCo(p.id); if (c) c.hold = null; save(); render(); };
  ACT.hlist = p => {
    const h = getCo(p.id), fee = KC(1500000);
    if (holdValue(h) < niceAmt(30000000)) { toast('Too small to list. It needs a value of at least ' + money(niceAmt(30000000)) + '.', true); return; }
    if (liquid() < fee) { toast('You need ' + money(fee) + '.', true); return; }
    confirmThen('List ' + esc(h.name) + ' on the exchange?', 'The bank fee is ' + money(fee) + '. You then report every quarter.', 'Go public', () => {
      payMe(fee, 'Stock exchange listing');
      h.listed = 1;
      save();
      render();
    });
  };
  ACT.hraise = p => {
    const h = getCo(p.id), g = U.inum('hgoal' + h.id, 0), mode = ui.hmode7 || (h.listed ? 'public' : 'private');
    if (!(g > 0)) return;
    const r = raisePlan(h, g, mode);
    confirmThen('Raise money for ' + esc(h.name) + '?', 'About ' + (Math.round(r.qa * 10) / 10) + '% in new shares for ' + money(r.amt) + (r.fee ? ', less a 3% bank fee' : '') + '.', 'Raise', () => {
      const buyer = mode === 'public' ? 'Shareholders on the exchange' : brandCoName(CC(), 'fin');
      moveCash(h, r.amt - r.fee);
      h.holders = h.holders || [];
      h.holders.forEach(x => { x.pct *= (1 - r.qa / 100); });
      h.holders.push({ name: buyer, pct: r.qa, in: r.amt });
      h.own = Math.round(h.own * (1 - r.qa / 100) * 100) / 100;
      ui.inp['hgoal' + h.id] = '';
      if (r.mg) info(r.mg.name, 'Money raised for ' + h.name, 'I raised ' + money(r.amt) + ' from ' + buyer + ' for ' + (Math.round(r.qa * 10) / 10) + '% of the holding.' + (r.qa > r.q * 1.15 ? ' I had to give a bit more than I hoped.' : ''), h.id, 'good');
      save();
      render();
      toast('Raised ' + money(r.amt) + '.');
    });
  };
  addStep('week.after', 55, 'rivals_holdings_software weekly', () => {
    const st = finSt();
    if (!st || !(st.holds || []).length) return;
    st.holds.forEach(id => {
      const h = getCo(id);
      if (!h || h.st !== 'open') return;
      const buf = KC(200000);
      if (h.cash > buf * 3) holdInvest(h, Math.round(h.cash - buf * 2));
      else if (h.cash < 0) holdDivest(h, -h.cash + buf);
    });
  });

  /* ---------- your own software: build it, test it in your companies, sell it ---------- */
  const SWT = [['crm', 'CRM and sales', /crm|listing|applicant|case-management/], ['book', 'Booking and scheduling', /booking|dispatch app|hotel management|reception/], ['acct', 'Accounting and payroll', /accounting|payroll/], ['shop', 'Shop and payments', /shop platform|pos and|webshop/], ['job', 'Job and quoting', /job|quoting|estimating/], ['fleet', 'Fleet and routing', /routing|tracking|fleet|tachograph/], ['cad', 'Design and CAD', /cad|bim|design and cost/], ['health', 'Patient journals', /journal|patient/], ['ticket', 'Ticketing and events', /ticketing/], ['erp', 'ERP and planning', /erp|planning|dealer management/]];
  const SWM = [['once', 'One-time purchase'], ['sub', 'Subscription'], ['both', 'Setup fee + subscription']];
  const swPrice = (m) => m === 'once' ? KC(15000) : m === 'sub' ? KC(1200) : KC(800);
  const FDs = () => (S.founded = S.founded || []);
  const swReady = f => f && f.st === 'live' && f.sw && (f.sw.phase === 'beta' || f.sw.phase === 'live');
  addStep('week.after', 55, 'rivals_holdings_software weekly', () => {
    FDs().forEach(f => {
      if (f.st !== 'live' || !f.sw) return;
      const w = f.sw;
      const speed = w.devs + w.selfH / 40 * 0.7 * ownerFactor();
      if (w.phase !== 'live') {
        w.prog = Math.min(1, w.prog + speed / 30 * (0.7 + f.q * 0.6));
        if (w.phase === 'build' && w.prog >= 0.5) { w.phase = 'beta'; note(f.name + ' is ready to test. Your companies can try it from the equipment shop.', 'good'); }
        if (w.prog >= 1) { w.phase = 'live'; note(f.name + ' is published and on sale.', 'good'); news(f.name + ' launches its new software.', 'good'); }
      }
      let rev = 0;
      if (w.phase === 'live') {
        const nc = Math.max(0, Math.round((f.q * 2.2 + f.tr * 3 + w.devs * 0.3) * (1 + w.cust / 250) * rng(0.2, 1.3)));
        w.cust = Math.round(w.cust * 0.99) + nc;
        rev = w.model === 'once' ? nc * w.price : w.model === 'sub' ? w.cust * w.price * 12 / 52 : nc * KC(5000) + w.cust * w.price * 12 / 52;
        f.tr = clamp(f.tr + Math.min(0.01, rev / Math.max(1, f.burn) * 0.004), 0, 1);
      } else if (w.phase === 'beta') w.cust = Math.max(w.cust, 3 + Math.floor(w.prog * 10));
      w.revW = Math.round(rev);
      f.cash += rev;
      if (rev > 0) f.val = Math.max(f.val, rev * 52 * 3);
    });
  });
  function ownSwWeek(co) {
    for (const id in co.eq) {
      const r = co.eq[id];
      if (!r.ownF) continue;
      const f = FDs().find(x => x.id === r.ownF);
      if (!f || f.st !== 'live') { r.perf = 0.8; continue; }
      if (r.sub) f.cash += r.sub.fee * 12 / 52;
      if (f.sw.phase === 'beta') {
        r.perf = 0.85;
        if (chance(0.1)) { r.perf = 0.6; note(f.name + ' (test version) crashed at ' + co.name + ' this week.', 'bad', co.id); }
      } else r.perf = 1.03;
    }
  }
  /* startups tab: build progress, team, pricing, internal price */
  addStep('V.startups', 10, 'startups tab: build progress, team, pricing, internal price', (h) => {
    if ((ui.stab || 'deals') !== 'found') return h;
    const L = FDs().filter(f => f.st === 'live' && f.sw);
    if (!L.length) return h;
    return h + '<h2 class="sec">Software you are building</h2>' + L.map(f => {
      const w = f.sw, inUse = S.cos.filter(c => Object.keys(c.eq).some(k => c.eq[k].ownF === f.id)).length;
      return '<div class="card"><div class="cchd">' + pic('soft', f.id) + '<span class="ctext"><b>' + esc(f.name) + '</b><small>' + esc(SWT.find(x => x[0] === w.type)[1]) + ' · ' + esc(SWM.find(x => x[0] === w.model)[1]) + '</small></span>' + pillp(w.phase === 'build' ? 'Building' : w.phase === 'beta' ? 'Testing' : 'On sale', w.phase === 'live' ? 'grn' : 'amb') + '</div>' + (w.phase !== 'live' ? '<div class="kv"><span>Progress</span><b>' + Math.round(w.prog * 100) + '%</b></div>' + bar(w.prog * 100, 'var(--blue)') : '') +
        '<div class="tri"><div><span>Customers</span><b>' + w.cust + '</b></div><div><span>Revenue / wk</span><b>' + mshort(w.revW || 0) + '</b></div><div><span>Your companies</span><b>' + inUse + '</b></div></div>' +
        '<div class="kv"><span>Team</span><b>' + w.devs + ' coders' + (w.selfH ? ' + you ' + w.selfH + ' h' : '') + '</b></div><div class="chips">' + btn('＋ Coder', 'swdev', { id: f.id, d: 1 }, 'chip') + (w.devs ? btn('− Coder', 'swdev', { id: f.id, d: -1 }, 'chip') : '') + btn(w.selfH ? 'Stop coding myself' : 'Code myself 20 h', 'swself', { id: f.id }, 'chip') + '</div>' +
        '<div class="kv"><span>How customers pay</span><b></b></div>' + chips(SWM, w.model, 'swmodel', { id: f.id }) +
        '<div class="kv"><span>Price for your own companies</span><b>' + w.int + '% of list</b></div>' + chips([[0, 'Free'], [25, '25%'], [50, '50%'], [75, '75%'], [100, 'Full']], w.int, 'swint', { id: f.id }) +
        '<span class="tipt">' + (w.phase === 'build' ? 'Not usable yet.' : w.phase === 'beta' ? 'Your companies can use the test version from the equipment shop. It is less reliable than the finished one.' : 'Your companies can buy it in the equipment shop.') + ' What they pay counts as revenue here.</span></div>';
    }).join('');
  });
  ACT.swdev = p => { const f = FDs().find(x => x.id === p.id); const n = Math.max(0, Math.min(10, f.sw.devs + p.d)); f.burn += (n - f.sw.devs) * KC(65000) * 12 / 52; f.sw.devs = n; save(); render(); };
  ACT.swself = p => {
    const f = FDs().find(x => x.id === p.id);
    if (f.sw.selfH) f.sw.selfH = 0;
    else { const left = HCAP - hoursUsed(); if (left < 5) { toast('You have no hours left this week.', true); return; } f.sw.selfH = Math.min(20, left); }
    save();
    render();
  };
  ACT.swmodel = p => { const f = FDs().find(x => x.id === p.id); f.sw.model = p.v; f.sw.price = swPrice(p.v); save(); render(); };
  ACT.swint = p => { const f = FDs().find(x => x.id === p.id); f.sw.int = p.v; save(); render(); };
  /* in the equipment shop: your own software as a provider */
  V.shop = pipeView('V.shop', V.shop, 1); /* V.shop: the screen above, then the steps below and in later files */
  addStep('V.shop', 10, 'in the equipment shop: your own software as a provider', (p, h) => {
    const co = getCo(p.id), bd = co && BD[co.type], e = bd && bd.eq.find(x => x.id === p.e);
    if (!e || !window.R6 || R6.kindOf(bd, e) !== 'soft') return h;
    const fs = FDs().filter(f => swReady(f) && SWT.find(x => x[0] === f.sw.type)[2].test(e.n.toLowerCase()));
    if (!fs.length) return h;
    const cur = co.eq[e.id];
    return fs.map(f => {
      const list = f.sw.model === 'once' ? f.sw.price * 4 : f.sw.price * 4, cost = Math.round(list * f.sw.int / 100);
      return '<div class="card"><div class="cchd">' + pic('soft', f.id) + '<span class="ctext"><b>Your own: ' + esc(f.name) + '</b><small>' + (f.sw.phase === 'beta' ? 'Test version · less reliable' : 'Published') + ' · ' + esc(SWM.find(x => x[0] === f.sw.model)[1]) + '</small></span>' + pillp(f.sw.int ? mshort(cost) + (f.sw.model === 'once' ? '' : '/mo') : 'Free', 'grn') + '</div><span class="tipt">Your internal price is ' + f.sw.int + '% of list. The money goes to ' + esc(f.name) + '.</span>' + (cur && cur.ownF === f.id ? pillp('In use', 'grn') : btn('Use ' + esc(f.name), 'ownsw', { id: co.id, e: e.id, f: f.id }, 'chip primary')) + '</div>';
    }).join('') + h;
  });
  ACT.ownsw = p => {
    const co = getCo(p.id), bd = BD[co.type], e = bd.eq.find(x => x.id === p.e), f = FDs().find(x => x.id === p.f);
    if (!f) return;
    const cost = Math.round(f.sw.price * 4 * f.sw.int / 100);
    const had = !!co.eq[e.id];
    if (f.sw.model === 'once') {
      if (cost && co.cash < cost) { toast('Not enough cash.', true); return; }
      if (cost) { payCo(co, cost, null, 'Licence: ' + f.name); f.cash += cost; }
      co.eq[e.id] = { n: 1, cond: 1, bv: cost, cost, used: 0, age: 0, life: e.life, soft: 'once', ver: S.week, perf: 1, rel: 1, ownF: f.id, mods: [{ nm: f.name, n: 1, rt: 4 }] };
    } else co.eq[e.id] = { n: 1, cond: 1, bv: 0, cost: 0, used: 0, age: 0, life: e.life, sub: { tier: 1, fee: cost, nm: f.name, w0: S.week, c: -1 }, perf: 1, rel: 1, ownF: f.id, mods: [{ nm: f.name, n: 1, rt: 4 }] };
    if (!had && FAM[bd.fam] && FAM[bd.fam].afterBuy) FAM[bd.fam].afterBuy(co, bd, e.id, 1);
    ui.shop = null;
    save();
    U.back();
    toast(co.name + ' now uses ' + f.name + '.');
  };
}


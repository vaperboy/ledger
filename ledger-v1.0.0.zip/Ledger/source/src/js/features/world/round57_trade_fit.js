/* ---- features/world/round57_trade_fit.js ---- */
/* ===== Round 57: some new trades fit some countries far better than others.
   - PC gaming café: Korea's PC bangs are part of everyday life (thousands of them, open all night), Japan has net and
     manga cafés; in most other countries it is a niche for gamers.
   - Vineyard: the famous wine countries (France, Italy, Spain) sell at higher prices; cool-climate wine (the UK,
     Germany, Switzerland, Canada) sells for less volume; elsewhere it is ordinary.
   - Dental clinic: where most adults pay for dental care themselves (Norway, Switzerland, the US...) people come a
     little less often than where public insurance pays for most of it (Germany, Japan, Korea).
   Applied on the demand step of each company (engine/company/model.js demand). ===== */
window.FIT57 = window.FIT57 || {};
(function () {
  const F = window.FIT57;
  const D = {
    pcbang: { KR: 1.6, JP: 1.15, SG: 1.05, BR: 1, MX: 0.95, US: 0.9, _: 0.9 },
    vineyard: { FR: 1.1, IT: 1.1, ES: 1.05, UK: 0.85, DE: 0.95, CH: 0.95, CA: 0.9, _: 1 },
    dental: { DE: 1.1, JP: 1.1, KR: 1.05, FR: 1.05, _: 1 }
  };
  const T = { vineyard: { FR: 1.15, IT: 1.15, ES: 1.05, UK: 1.05, _: 1 } };
  F.D = D;
  F.dem = co => { const t = D[co.type]; if (!t) return 1; const c = co.country || S.country; return t[c] != null ? t[c] : t._; };
  F.price = co => { const t = T[co.type]; if (!t) return 1; const c = co.country || S.country; return t[c] != null ? t[c] : t._; };
  addStep('ticketMult', 45, 'famous wine countries sell dearer', (co, bd, r) => co ? r * F.price(co) : r);
  addStep('demand', 86, 'how well a new trade fits its country', (co, bd, r) => { const f = F.dem(co); if (f !== 1 && r && r.D > 0) r.D *= f; }, true);
})();

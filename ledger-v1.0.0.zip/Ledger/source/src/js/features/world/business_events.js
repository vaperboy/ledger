/* ===== Round 27e: events that feel like real business life.
   Six classes with their own rhythm:
     small operational   frequent, low impact      (the existing event engine, with some now simply happening)
     strategic choices   about once a quarter       (by stage: startup, growth, established)
     major opportunities rare, big upside and risk
     crises              uncommon, weighted by exposure (debt, size, market share)
     market changes      every month in the background (rival groups, economy)
     corporate events    rare, only for big groups (listing, takeovers, private equity, succession)
   plus events that belong to one country, and general ones (inflation, technology). Many need no answer:
   things happen and you adapt. ===== */
(function () {
  const R27 = window.R27 = window.R27 || {};
  const U = window.UI, { toast, save, render, svg, row } = U;
  const P = o => esc(JSON.stringify(o));
  const sumF = (a, f) => a.reduce((t, x) => t + (f(x) || 0), 0);
  const MI = () => monthIdx(S.week);
  const E = {};
  R27.E = E;
  const st = () => { S.e27 = S.e27 || { last: {}, q: [], n: {}, lastS: -99, lastO: -99, lastC: -99, lastT: -99, rate: [] }; return S.e27; };

  /* ---------- helpers ---------- */
  const wk = co => { try { return avgWk(co); } catch (e) { return 3000; } };
  const yr = co => wk(co) * 52;
  const payroll = co => sumF(co.staff || [], s => s.wage);
  const dem = (co, m, w) => co.mods.push({ k: 'dem', m, w: Math.round(w) });
  const cap = (co, m, w) => co.mods.push({ k: 'cap', m, w: Math.round(w) });
  const cost = (co, m, w) => co.mods.push({ k: 'cogsup', m, w: Math.round(w) });
  const rep = (co, d) => { co.rep = clamp((co.rep || 50) + d, 0, 100); };
  const pay = (co, a, cat, l) => payCo(co, Math.max(0, Math.round(a)), cat || 'oth', l);
  const wc = (co, a, w) => { a = Math.round(a); if (a <= 0) return; moveCash(co, -a); co.recv.push({ a, due: S.week + w, bad: false }); };
  const later = (w, id, co, d) => st().q.push({ w: S.week + w, id, co: co ? co.id : 0, d: d || {} });
  const fmt = money;
  const stage = co => {
    const n = (co.staff || []).length, age = S.week - (co.wOpen != null ? co.wOpen : co.w0 || 0);
    if (age < 52 || (n <= 3 && !co.mgr)) return 'start';
    if (n > 15 || (co.mgr && yr(co) > KC(20e6))) return 'est';
    return 'grow';
  };
  R27.stage = stage;
  const liveCos = () => S.cos.filter(c => c.st === 'open' && c.type !== 'hold' && BD[c.type]);
  const groupRev = () => sumF(liveCos(), c => yr(c) * (c.own || 100) / 100);
  const tycoon = () => S.cos.some(c => c.type === 'hold' && c.st !== 'sold' && c.st !== 'bust') || liveCos().length >= 5 || groupRev() > KC(150e6);
  R27.tycoon = tycoon;
  const b2b = co => (BD[co.type].b2b || 0);
  const fam = co => BD[co.type].fam;

  /* ---------- defining and firing ---------- */
  /* d: { cls, st (stages), w, cond(co), data(co), t(co,d), b(co,d), o: [{l, d, run(co,d)}], def, auto(co,d), tone, cc } */
  function ev27(id, d) { d.id = id; E[id] = d; }
  const str = (v, co, d) => typeof v === 'function' ? v(co, d) : v || '';
  function fire(def, co, extra) {
    const d = extra || (def.data ? def.data(co) : {});
    if (!d || d.skip) return false;
    st().last[def.id] = S.week;
    st().n[def.cls] = (st().n[def.cls] || 0) + 1;
    const title = str(def.t, co, d), body = str(def.b, co, d);
    if (!def.o || !def.o.length) {
      try { if (def.auto) def.auto(co, d); } catch (e) { console.error(e); }
      addMsg({ kind: 'info', from: str(def.from, co, d) || (co ? co.name : 'News'), title, body, co: co ? co.id : 0, tone: def.tone || 'n', status: 'done', go: def.go ? def.go(co, d) : undefined });
      return true;
    }
    /* round 56: a store that runs inside a chain with a boss above its manager answers for itself: the manager takes
       the sensible choice and you see it in the notes, not as a question */
    if (co && co.mgr && S.npcs[co.mgr] && typeof chainOf === 'function' && chainOf(co).length > 1) {
      const i = def.def != null ? def.def : 0, o = def.o[i] || def.o[0];
      try { if (o && o.run) o.run(co, d, null); } catch (e) { console.error(e); }
      note(S.npcs[co.mgr].name + ' at ' + co.name + ': ' + title.replace(/\.$/, '') + ' · ' + str(o.l, co, d).toLowerCase() + '.', 'n', co.id);
      return true;
    }
    addMsg({ kind: 'ask', from: str(def.from, co, d) || (co ? co.name : 'News'), title, body, co: co ? co.id : 0, opts: def.o.map(o => ({ l: str(o.l, co, d), d: str(o.d, co, d), fx: {} })), act: 'e27', data: { id: def.id, co: co ? co.id : 0, d }, exp: S.week + (def.exp || 3), tone: def.tone || 'n' });
    return true;
  }
  R27.fire = (id, co, extra) => E[id] ? fire(E[id], co, extra) : false;
  ACTS.e27 = (m, idx) => {
    const def = E[m.data.id], co = m.data.co ? getCo(m.data.co) : null;
    if (!def || (m.data.co && (!co || co.st === 'sold' || co.st === 'bust'))) return true;
    const o = def.o[idx];
    try { if (o && o.run) o.run(co, m.data.d, m); } catch (e) { console.error(e); }
    return true;
  };

  /* ================= startup stage ================= */
  ev27('s_bigcust', {
    cls: 'strat', st: ['start', 'grow'], w: 3, cond: co => b2b(co) > 0.15 && co.lastW && co.lastW.util < 0.85,
    data: co => ({ v: rnl(yr(co) * 0.3, 1000) }),
    t: co => 'A big customer wants a contract with ' + co.name,
    b: (co, d) => 'A large customer offers work worth about ' + fmt(d.v) + ' a year, about 30% of what you sell today. They want 10% off and 60 days to pay.',
    o: [
      { l: 'Accept their terms', d: 'More volume, thinner margin, and cash tied up waiting for them to pay.', run: (co, d) => { dem(co, 1.3, 52); cost(co, 1.035, 52); wc(co, d.v / 6, 9); note(co.name + ' signed the contract. The first invoices are paid in two months.', 'good', co.id); } },
      { l: 'Negotiate: 5% off and 30 days', d: 'They might accept, or go elsewhere.', run: (co, d) => { if (chance(0.55)) { dem(co, 1.3, 52); cost(co, 1.017, 52); wc(co, d.v / 12, 5); note('They agreed: 5% off, 30 days.', 'good', co.id); } else note('They signed with someone else.', 'bad', co.id); } },
      { l: 'Decline, stay with smaller customers', d: 'No risk of depending on one buyer.', run: () => { } }
    ], def: 2
  });
  ev27('s_breakdown', {
    cls: 'strat', st: ['start', 'grow', 'est'], w: 3, cond: co => Object.keys(co.eq || {}).length > 0,
    data: co => ({ c: Math.round(Math.max(KC(8000), wk(co) * 0.15)) }),
    t: co => 'Essential equipment breaks down at ' + co.name,
    b: (co, d) => 'The ' + (typeof pickEqName === 'function' ? pickEqName(co, BD[co.type]) : 'main machine') + ' is out. A fast repair costs about ' + fmt(d.c * 1.6) + '; the normal one about ' + fmt(d.c) + ' but takes two weeks.',
    o: [
      { l: 'Repair now, at a premium', d: 'Back in a day or two.', run: (co, d) => { pay(co, d.c * 1.6, 'oth', 'Emergency repair'); cap(co, 0.9, 1); } },
      { l: 'Rent a replacement', d: 'Keeps you going while the normal repair is done.', run: (co, d) => { pay(co, d.c * 0.5 + wk(co) * 0.04, 'oth', 'Rented equipment'); pay(co, d.c, 'oth', 'Repair'); cap(co, 0.95, 2); } },
      { l: 'Wait for the cheaper repair', d: 'Lost sales for two weeks, and some customers may not come back.', run: (co, d) => { pay(co, d.c, 'oth', 'Repair'); cap(co, 0.55, 2); rep(co, -1); } }
    ], def: 2
  });
  ev27('s_burnout', {
    cls: 'strat', st: ['start', 'grow'], w: 3, cond: co => !co.mgr && (co.ohrs || 40) >= 50,
    t: co => 'You are running on empty at ' + co.name,
    b: co => (co.ohrs || 50) + '-hour weeks are catching up with you. Mistakes are creeping in and customers wait longer.',
    o: [
      { l: 'Hire part-time help', d: 'Half a worker\'s pay for 20 hours a week. Opens Find workers.', run: co => { co.ohrs = Math.min(co.ohrs, 45); rep(co, 1); } },
      { l: 'Cut opening hours', d: 'Fewer hours, less money, but you get your life back.', run: co => { co.ohrs = 40; dem(co, 0.93, 26); } },
      { l: 'Keep going', d: 'No cost now. Slower service, more mistakes.', run: co => { cap(co, 0.9, 8); rep(co, -2); co.oskill = Math.max(0, (co.oskill || 50) - 1); } }
    ], def: 2
  });
  ev27('s_quit', {
    cls: 'strat', st: ['start', 'grow'], w: 2, cond: co => (co.staff || []).length >= 2,
    data: co => { const s = co.staff.slice().sort((a, b) => staffSkill(b) - staffSkill(a))[0]; const n = s && S.npcs[s.id]; return n ? { s: s.id, n: n.name, r: s.role } : { skip: 1 }; },
    t: (co, d) => d.n + ' is leaving ' + co.name + ' for a competitor',
    b: (co, d) => d.n + ', your best ' + (ROLES[d.r] ? ROLES[d.r][0].toLowerCase() : 'worker') + ', has an offer elsewhere and leaves in two weeks.',
    o: [
      { l: 'Recruit a replacement', d: 'An agency finds someone in a few weeks.', run: (co, d) => { pay(co, KC(12000), 'oth', 'Recruiting'); fireStaff(co, d.s, 1); cap(co, 0.92, 3); } },
      { l: 'Promote someone from the team', d: 'A raise for them, and one person short.', run: (co, d) => { fireStaff(co, d.s, 1); const o = co.staff[0]; if (o) o.wage = Math.round(o.wage * 1.1); cap(co, 0.9, 6); } },
      { l: 'Run short-handed', d: 'Saves the wage. Slower and more tired staff.', run: (co, d) => { fireStaff(co, d.s, 1); co.mood = Math.max(0, (co.mood || 60) - 5); } }
    ], def: 2
  });
  ev27('s_supprice', {
    cls: 'strat', st: ['start', 'grow', 'est'], w: 3, cond: co => typeof hasGoods === 'function' && hasGoods(co) && !(R27.links && R27.links().some(l => l.b === co.id)),
    t: co => 'The main supplier of ' + co.name + ' raises prices 12%',
    b: () => 'Goods cost 12% more from next month. How much your customers will put up with depends on your prices and theirs.',
    o: [
      { l: 'Negotiate', d: 'You might get it down to 4%. Or not.', run: co => { cost(co, chance(0.5) ? 1.04 : 1.12, 26); } },
      { l: 'Find another supplier', d: 'A week of disruption while you switch.', run: co => { cap(co, 0.9, 1); cost(co, 1.02, 26); } },
      { l: 'Raise your prices', d: 'Keep the margin, lose some price-sensitive customers.', run: co => { cost(co, 1.12, 26); co.mods.push({ k: 'dem', m: 0.95, w: 26 }); co.price = clamp((co.price || 0) + 0.5, -3, 3); } },
      { l: 'Accept the lower margin', d: '', run: co => cost(co, 1.12, 26) }
    ], def: 3
  });
  ev27('s_campaign', {
    cls: 'strat', st: ['start', 'grow'], w: 2, cond: co => Object.keys(co.mkt || {}).some(k => co.mkt[k] && co.mkt[k].b > 0),
    t: co => 'A campaign is working for ' + co.name,
    b: () => 'Early numbers look good: new customers are coming in at a reasonable cost. Whether it pays depends on how long they stay.',
    o: [
      { l: 'Double the budget', d: 'More customers now, but returns usually fall as you spend more.', run: co => { Object.keys(co.mkt || {}).forEach(k => { if (co.mkt[k] && co.mkt[k].b > 0) co.mkt[k].b = Math.round(co.mkt[k].b * 2); }); } },
      { l: 'Keep it as it is', d: '', run: () => { } },
      { l: 'Stop while it is ahead', d: 'Saves the money. The effect fades over a few months.', run: co => { Object.keys(co.mkt || {}).forEach(k => { delete co.mkt[k]; }); } }
    ], def: 1
  });
  ev27('s_acqoffer', {
    cls: 'opp', st: ['start', 'grow', 'est'], w: 2, cond: co => coEbit12(co) > 0 && companyValue(co) > KC(500000) && S.week - (co.w0 || 0) > 40 && !(co.bid27 > S.week),
    data: co => { const g = window.R27 && R27.groupsIn ? R27.groupsIn(co.country).filter(x => !x.dist && x.types.indexOf(co.type) >= 0)[0] : null; return { g: g ? g.id : 0 }; },
    t: co => 'Someone wants to buy ' + co.name, b: () => '',
    handle: (co, d) => { co.bid27 = S.week + 40; const g = d.g && R27.G(d.g); const V0 = companyValue(co); if (g && R27.bidFor) { R27.bidFor(co, g, rnl(V0 * rng(1.05, 1.3), 1000), V0); return true; } return false; }
  });
  ev27('s_latepay', {
    cls: 'strat', st: ['start', 'grow'], w: 2, cond: co => b2b(co) > 0.25 && (co.recv || []).length > 0,
    data: co => { const r = co.recv.slice().sort((a, b) => b.a - a.a)[0]; return r ? { a: r.a } : { skip: 1 }; },
    t: co => 'A customer of ' + co.name + ' has not paid',
    b: (co, d) => 'An invoice of ' + fmt(d.a) + ' is past due. The customer says it is coming.',
    o: [
      { l: 'Send a reminder and a fee', d: 'Most pay within weeks.', run: (co, d) => { pay(co, KC(800), 'oth', 'Collection'); const r = co.recv.find(x => x.a === d.a); if (r) { r.due = S.week + 3; r.bad = chance(0.08); } } },
      { l: 'Agree a payment plan', d: 'You get it, slowly.', run: (co, d) => { const r = co.recv.find(x => x.a === d.a); if (r) { r.due = S.week + 10; r.bad = chance(0.04); } } },
      { l: 'Wait', d: 'Free, but they may never pay.', run: (co, d) => { const r = co.recv.find(x => x.a === d.a); if (r) { r.due = S.week + 6; r.bad = r.bad || chance(0.25); } } }
    ], def: 2
  });

  /* ================= growth stage ================= */
  ev27('g_overcap', {
    cls: 'strat', st: ['grow', 'est'], w: 3, cond: co => co.lastW && co.lastW.D > (co.lastW.cap || 0) * 1.12 && co.lastW.cap > 0,
    t: co => 'More orders than ' + co.name + ' can handle',
    b: co => 'Demand runs about ' + Math.round((co.lastW.D / co.lastW.cap - 1) * 100) + '% above what you can deliver. Growing costs money before the extra sales are certain.',
    o: [
      { l: 'Add an evening shift', d: 'Overtime pay for two months, more output now.', run: co => { cap(co, 1.15, 8); pay(co, payroll(co) * 0.25 * 2, 'wages', 'Overtime'); } },
      { l: 'Hire more people', d: 'Go to Find workers. Permanent cost, permanent capacity.', run: () => { } },
      { l: 'Outsource part of the work', d: 'More output at a higher cost per unit.', run: co => { cap(co, 1.2, 12); cost(co, 1.08, 12); } },
      { l: 'Turn customers away', d: 'No cost. Some will not come back, and reviews suffer a little.', run: co => { rep(co, -1); } }
    ], def: 3
  });
  ev27('g_mgrraise', {
    cls: 'strat', st: ['grow', 'est'], w: 3, cond: co => co.mgr && S.npcs[co.mgr] && S.week - (co.mgrW0 || 0) > 40,
    data: co => ({ n: S.npcs[co.mgr].name, w: co.mgrWage || 0 }),
    t: (co, d) => d.n + ' asks for a raise',
    b: (co, d) => d.n + ', who runs ' + co.name + ', wants 12% more: ' + fmt(d.w * 1.12) + ' a month. Good managers are hard to find.',
    o: [
      { l: 'Approve it', d: '', run: co => { co.mgrWage = Math.round((co.mgrWage || 0) * 1.12); co.mood = Math.min(100, (co.mood || 60) + 6); } },
      { l: 'Offer pay for results', d: '5% more, plus a bonus if profit grows.', run: co => { co.mgrWage = Math.round((co.mgrWage || 0) * 1.05); co.mgrBonus = Math.max(co.mgrBonus || 0, 0.05); co.mood = Math.min(100, (co.mood || 60) + 2); } },
      { l: 'Refuse', d: 'They may look elsewhere.', run: (co, d) => { co.mood = Math.max(0, (co.mood || 60) - 10); if (chance(0.3) && co.mgr) mgrResign(co, 'I was refused the raise, so I am taking another job'); } }
    ], def: 2
  });
  ev27('g_location', {
    cls: 'opp', st: ['grow', 'est'], w: 3, cond: co => coEbit12(co) > 0 && LOCALT(co) && CO[co.country].cities.length > 1,
    data: co => { const C = CO[co.country]; const cs = C.cities.filter(c => c.id !== co.city && c.id !== 'small'); const c = cs[rint(0, cs.length - 1)]; return c ? { city: c.id, cn: c.name, disc: rint(10, 25) } : { skip: 1 }; },
    t: (co, d) => 'A good site for ' + BD[co.type].n.toLowerCase() + ' in ' + d.cn,
    b: (co, d) => 'A landlord in ' + d.cn + ' offers a site ' + d.disc + '% below normal rent for the first two years if you sign soon. A second ' + co.name + ' would share your brand, but it ties up money and management time.',
    o: [
      { l: 'Sign now', d: 'A new company is registered there; you set it up like any new business.', run: (co, d) => { const n = startCompany(co.type, { city: d.city, country: co.country, form: 'AS', name: co.name + ' ' + d.cn }); if (typeof n === 'object') { n.flags.rent27 = { m: 1 - d.disc / 100, until: S.week + 104 }; n.branch = n.branch || { of: co.id }; note(n.name + ' is registered. Set it up in Companies.', 'good', n.id); } else note('Could not start: ' + n, 'bad', co.id); } },
      { l: 'Negotiate an even better rent', d: 'They may give more, or rent it to someone else.', run: (co, d) => { later(3, 'g_location_neg', co, d); } },
      { l: 'Wait until you have more cash', d: 'The site goes to someone else, maybe a rival.', run: () => { } }
    ], def: 2
  });
  const LOCALT = co => ['svc', 'venue', 'retail', 'prod', 'logi', 'project'].indexOf(fam(co)) >= 0;
  ev27('g_volume', {
    cls: 'strat', st: ['grow', 'est'], w: 2, cond: co => typeof hasGoods === 'function' && hasGoods(co) && (co.bk.m.cogs || 0) > 0,
    data: co => ({ c: rnl(Math.max(KC(20000), (co.bk.y.cogs || co.bk.m.cogs * 4) / Math.max(1, (S.week % 52) || 1) * 8), 1000) }),
    t: co => 'A volume discount for ' + co.name,
    b: (co, d) => 'Your supplier offers 6% off if you order about ' + fmt(d.c) + ' up front (two months\' worth). The stock has to sit somewhere, and the cash is gone until it sells.',
    o: [
      { l: 'Commit to the volume', d: '6% cheaper goods for half a year.', run: (co, d) => { wc(co, d.c * 0.5, 9); cost(co, 0.94, 26); } },
      { l: 'Ask for flexible deliveries', d: '3% off, no big order.', run: co => cost(co, 0.97, 26) },
      { l: 'Decline', d: '', run: () => { } }
    ], def: 2
  });
  ev27('g_quality', {
    cls: 'strat', st: ['grow', 'est'], w: 3, cond: co => co.q < 62 || ratingOf(co) < 3.6,
    t: co => 'Complaints are rising at ' + co.name,
    b: () => 'More customers complain about quality. Left alone, reviews will follow.',
    o: [
      { l: 'Fix the work and refund', d: 'Costs now, protects reviews.', run: co => { pay(co, wk(co) * 0.4, 'oth', 'Corrective work and refunds'); rep(co, 1); } },
      { l: 'Retrain the team', d: 'A week of lower output, better quality afterwards.', run: co => { cap(co, 0.85, 1); pay(co, (co.staff || []).length * KC(3000), 'oth', 'Training'); co.q = Math.min(100, co.q + 5); } },
      { l: 'Ignore it', d: 'No cost. Reviews will get worse.', run: co => { later(4, 'g_quality_bad', co, {}); } }
    ], def: 2
  });
  ev27('g_loan', {
    cls: 'strat', st: ['grow', 'est'], w: 2, cond: co => coEbit12(co) > 0 && co.form === 'AS',
    data: co => { let o = { max: 0 }; try { o = loanOffer('biz', 1, co); } catch (e) { } return { a: rnl(Math.min(o.max, yr(co) * 0.4), 1000), r: (policy() + (o.margin || 0.03)) }; },
    t: co => 'Your bank offers ' + co.name + ' an expansion loan',
    b: (co, d) => d.a > 0 ? 'Up to ' + fmt(d.a) + ' over five years at about ' + pc(d.r, 1) + '. Debt lets you grow without giving away shares, but the payments come every month, good or bad.' : '',
    o: [
      { l: 'Take it all', d: '', run: (co, d) => { const r = takeLoan('biz', d.a, 60, co); if (r !== 'ok') note('The loan fell through: ' + r + '.', 'bad', co.id); } },
      { l: 'Take half', d: '', run: (co, d) => { takeLoan('biz', Math.round(d.a / 2000) * 1000, 60, co); } },
      { l: 'No thanks', d: 'Grow from your own profits, or sell shares instead.', run: () => { } }
    ], def: 2, skipIf: (co, d) => d.a < KC(100000)
  });
  ev27('g_teampoach', {
    cls: 'strat', st: ['grow', 'est'], w: 2, cond: co => (co.staff || []).length >= 5,
    data: co => { const g = window.R27 && R27.groupsIn ? R27.groupsIn(co.country).find(x => x.types.indexOf(co.type) >= 0) : null; return { gn: g ? g.name : 'A competitor', n: Math.min(3, Math.floor(co.staff.length / 4) + 1) }; },
    t: (co, d) => d.gn + ' is hiring away your people',
    b: (co, d) => d.n + ' experienced people at ' + co.name + ' have offers from ' + d.gn + '.',
    o: [
      { l: 'Retention bonuses', d: 'A month\'s pay each. Most stay.', run: (co, d) => { const L = co.staff.slice().sort((a, b) => staffSkill(b) - staffSkill(a)).slice(0, d.n); pay(co, sumF(L, s => s.wage), 'wages', 'Retention bonuses'); if (chance(0.25) && L[0]) fireStaff(co, L[0].id, 1); } },
      { l: 'Reorganise around it', d: 'Let them go and spread the work.', run: (co, d) => { co.staff.slice().sort((a, b) => staffSkill(b) - staffSkill(a)).slice(0, d.n).forEach(s => fireStaff(co, s.id, 1)); cap(co, 0.9, 6); co.mood = Math.max(0, (co.mood || 60) - 6); } },
      { l: 'Let them go and recruit', d: 'Recruiting costs, and new people need time.', run: (co, d) => { co.staff.slice().sort((a, b) => staffSkill(b) - staffSkill(a)).slice(0, d.n).forEach(s => fireStaff(co, s.id, 1)); pay(co, KC(10000) * d.n, 'oth', 'Recruiting'); } }
    ], def: 2
  });
  ev27('g_franinq', {
    cls: 'opp', st: ['grow', 'est'], w: 1, cond: co => !(co.fr && co.fr.on) && co.rep > 60 && LOCALT(co) && coEbit12(co) > 0,
    t: co => 'An investor wants to run a ' + co.name + ' of their own',
    b: () => 'They would pay a fee and royalties to use your name and recipe in another city. Faster growth with their money, but less control over quality.',
    o: [
      { l: 'Look at franchising', d: 'Set up a franchise system in the company\'s Grow tab.', run: () => { } },
      { l: 'Open your own branches instead', d: 'More control, your money.', run: () => { } },
      { l: 'Not yet', d: 'Standardise first.', run: () => { } }
    ], def: 2
  });
  ev27('g_bigcustgo', {
    cls: 'strat', st: ['grow', 'est'], w: 2, cond: co => b2b(co) > 0.35,
    t: co => 'A big customer of ' + co.name + ' changes its buying rules',
    b: () => 'A customer worth about a quarter of your sales moves to a new procurement process. You have to bid again, against everyone.',
    o: [
      { l: 'Bid hard to keep it', d: 'Keep the work at a lower price.', run: co => { cost(co, 1.05, 52); } },
      { l: 'Win new customers instead', d: 'Marketing and sales effort, and the old customer goes.', run: co => { dem(co, 0.85, 20); pay(co, wk(co) * 0.6, 'mkt', 'Sales push'); co.aware = Math.min(100, co.aware + 6); } },
      { l: 'Cut costs and accept the loss', d: '', run: co => { dem(co, 0.78, 40); } }
    ], def: 2
  });

  /* ================= established ================= */
  ev27('e_execleave', {
    cls: 'strat', st: ['est'], w: 2, cond: co => co.mgr && S.npcs[co.mgr],
    data: co => ({ n: S.npcs[co.mgr].name }),
    t: (co, d) => d.n + ' resigns from ' + co.name,
    b: (co, d) => d.n + ' has accepted a job elsewhere and leaves at the end of the month.',
    o: [
      { l: 'Promote from inside', d: 'Cheaper and knows the place, but untested.', run: co => R27.replaceMgr && R27.replaceMgr(co, 'promote') },
      { l: 'Hire an outside executive', d: 'Expensive, experienced, needs time to settle.', run: co => R27.replaceMgr && R27.replaceMgr(co, 'external') },
      { l: 'Run it yourself for now', d: 'Your hours, your time.', run: co => { const n = S.npcs[co.mgr]; if (n) n.hired = 0; co.mgr = null; co.mgrWage = 0; co.ohrs = 45; } }
    ], def: 0
  });
  ev27('e_automation', {
    cls: 'strat', st: ['est', 'grow'], w: 2, cond: co => ['prod', 'retail', 'logi'].indexOf(fam(co)) >= 0 && (co.staff || []).length >= 6,
    data: co => ({ c: rnl(payroll(co) * 10, 1000) }),
    t: co => 'Automation could cut costs at ' + co.name,
    b: (co, d) => 'New equipment for about ' + fmt(d.c) + ' would do the work of two people and speed things up. Training takes a month.',
    o: [
      { l: 'Invest now', d: 'Pay up front, lower costs for years.', run: (co, d) => { if (co.cash < d.c) { note('Not enough cash in ' + co.name + '.', 'bad', co.id); return; } pay(co, d.c, null, 'Automation equipment'); co.flags.capex27 = (co.flags.capex27 || 0) + d.c; cap(co, 0.85, 4); later(5, 'e_auto_done', co, { n: 2 }); } },
      { l: 'Phase it in', d: 'Half now, half next year. Half the gain.', run: (co, d) => { if (co.cash < d.c / 2) return; pay(co, d.c / 2, null, 'Automation, phase one'); later(5, 'e_auto_done', co, { n: 1 }); } },
      { l: 'Keep the team as it is', d: '', run: () => { } }
    ], def: 2
  });
  ev27('e_audit', {
    cls: 'crisis', st: ['grow', 'est'], w: 2,
    data: co => ({ c: Math.round(Math.max(KC(15000), wk(co) * 0.3)) }),
    t: co => 'Inspectors find problems at ' + co.name,
    b: (co, d) => 'A compliance audit lists several deficiencies. Fixing them costs about ' + fmt(d.c) + '. Serious ones can mean fines or closure.',
    o: [
      { l: 'Fix everything', d: '', run: (co, d) => pay(co, d.c, 'oth', 'Compliance work') },
      { l: 'Pause the affected work', d: 'Fix it while part of the business stands still.', run: (co, d) => { pay(co, d.c * 0.6, 'oth', 'Compliance work'); cap(co, 0.7, 2); } },
      { l: 'Contest the findings', d: 'Legal costs; you may be right, or fined.', run: (co, d) => { pay(co, d.c * 0.3, 'oth', 'Legal costs'); if (chance(0.45)) pay(co, d.c * 2, 'fine', 'Compliance fine'); } }
    ], def: 0
  });
  ev27('e_refi', {
    cls: 'strat', st: ['grow', 'est'], w: 2, cond: co => S.loans.some(l => l.co === co.id && l.bal > KC(200000) && l.kind !== 'start'),
    data: co => { const L = S.loans.filter(l => l.co === co.id && l.kind !== 'start'); return { b: Math.round(sumF(L, l => l.bal)) }; },
    t: co => 'A lender offers to refinance ' + co.name + '\'s debt',
    b: (co, d) => 'Your ' + fmt(d.b) + ' of loans could move to a new lender at about 0.6 points lower interest, for a 1% fee. A shorter term saves more interest but raises the monthly payment.',
    o: [
      { l: 'Refinance at the lower rate', d: '1% fee now.', run: (co, d) => { pay(co, d.b * 0.01, 'int', 'Refinancing fee'); S.loans.filter(l => l.co === co.id && l.kind !== 'start').forEach(l => { l.margin = Math.max(0.005, l.margin - 0.006); }); } },
      { l: 'Refinance and pay off faster', d: 'Lower rate, higher payments.', run: (co, d) => { pay(co, d.b * 0.01, 'int', 'Refinancing fee'); S.loans.filter(l => l.co === co.id && l.kind !== 'start').forEach(l => { l.margin = Math.max(0.005, l.margin - 0.008); l.termM = Math.max(24, Math.round((l.termM || 120) * 0.6)); }); } },
      { l: 'Keep things as they are', d: '', run: () => { } }
    ], def: 2
  });
  ev27('e_merger', {
    cls: 'opp', st: ['est', 'grow'], w: 1, cond: co => LOCALT(co) && (rivalsOf(co) || []).some(r => !r.g27 && r.size < (co.size || 1) * 1.4),
    data: co => { const r = (rivalsOf(co) || []).filter(x => !x.g27).sort((a, b) => b.size - a.size)[0]; return r ? { r: r.id, n: r.name, o: r.owner } : { skip: 1 }; },
    t: (co, d) => d.n + ' proposes a merger',
    b: (co, d) => d.o + ', who owns ' + d.n + ', suggests putting the two businesses together: no cash changes hands, ' + d.o.split(' ')[0] + ' gets a share of ' + co.name + '. Bigger and stronger together, but you share ownership, and the competition authority may look at it.',
    o: [
      { l: 'Merge: they get 30% of the company', d: 'You take over their customers and sites.', run: (co, d) => mergeIn(co, d, 30) },
      { l: 'Negotiate: offer 20%', d: 'They may accept, or walk.', run: (co, d) => { if (chance(0.5)) mergeIn(co, d, 20); else note(d.o + ' turned down 20%.', 'n', co.id); } },
      { l: 'Decline', d: '', run: () => { } }
    ], def: 2
  });
  function mergeIn(co, d, pct) {
    const r = (rivalsOf(co) || []).find(x => x.id === d.r);
    if (!r) return;
    const m = S.mk[mkKey(co)];
    m.riv = m.riv.filter(x => x !== r);
    m.n = Math.max(1, m.n - 1);
    co.size = Math.min((BD[co.type].maxSize || 3), (co.size || 1) + r.size * 0.6);
    co.aware = Math.min(100, co.aware + 10);
    addMod(co, 'dem', 1.15, 52);
    co.holders = co.holders || [];
    co.holders.push({ name: d.o, pct: pct * co.own / 100, in: 0, sat: 65 });
    co.own = co.own * (1 - pct / 100);
    if (R27.amb) R27.amb().cnt.buy++;
    note(co.name + ' merged with ' + d.n + '. ' + d.o + ' now owns ' + pct + '%.', 'good', co.id);
    try { const t = window.R26 && R26.truthOf(R26.mkOfCo(co)); if (t && t.share > 0.3) later(8, 'e_merger_review', co, { s: t.share }); } catch (e) { }
  }
  ev27('e_reputation', {
    cls: 'crisis', st: ['grow', 'est'], w: 2,
    t: co => 'A complaint about ' + co.name + ' goes viral',
    b: () => 'A customer\'s angry post is everywhere. People want to know what you will do.',
    o: [
      { l: 'Respond openly and make it right', d: 'Costs a little, contains it.', run: co => { pay(co, wk(co) * 0.2, 'oth', 'Making it right'); rep(co, -2); } },
      { l: 'Order an independent review', d: 'Takes weeks; credible if it clears you.', run: co => { pay(co, KC(40000), 'oth', 'Independent review'); rep(co, -3); later(6, 'e_rep_review', co, {}); } },
      { l: 'Say nothing', d: 'It may blow over. Or not.', run: co => { if (chance(0.5)) rep(co, -1); else { rep(co, -8); dem(co, 0.9, 12); } } }
    ], def: 2
  });
  ev27('e_wages', {
    cls: 'strat', st: ['est', 'grow'], w: 2, cond: co => (co.staff || []).length >= 8,
    t: co => 'Wage talks at ' + co.name,
    b: () => 'The staff want 6% more and a better pension.',
    o: [
      { l: 'Agree', d: 'Higher payroll, good morale.', run: co => { co.staff.forEach(s => { s.wage = Math.round(s.wage * 1.06); }); co.mood = Math.min(100, (co.mood || 60) + 8); } },
      { l: '3% now, 3% next year', d: 'Spreads the cost.', run: co => { co.staff.forEach(s => { s.wage = Math.round(s.wage * 1.03); }); later(52, 'e_wages_2', co, {}); } },
      { l: 'Refuse', d: 'Risk a strike and people leaving.', run: co => { co.mood = Math.max(0, (co.mood || 60) - 12); if (chance(0.4)) { cap(co, 0.4, 2); rep(co, -2); note('Staff at ' + co.name + ' went on strike for two weeks.', 'bad', co.id); } } }
    ], def: 1
  });
  ev27('e_distress', {
    cls: 'opp', st: ['grow', 'est'], w: 2, cond: co => LOCALT(co) && (rivalsOf(co) || []).some(r => !r.g27 && !r.listed),
    data: co => { const r = (rivalsOf(co) || []).filter(x => !x.g27 && !x.listed)[0]; return r ? { r: r.id, n: r.name } : { skip: 1 }; },
    auto: (co, d) => { const r = (rivalsOf(co) || []).find(x => x.id === d.r); if (r) { r.listed = true; r.dist27 = S.week; } },
    t: (co, d) => d.n + ' is in trouble and for sale', tone: 'good',
    b: (co, d) => d.n + ' is behind on its bills and the owner wants out. It could be bought well below its normal price, or you could wait for it to close. A buyer may find surprises in the books.',
    go: (co, d) => ({ l: 'See ' + d.n, a: 'go', p: { n: 'rival', p: { id: co.id, r: d.r } } })
  });

  /* ================= big groups ================= */
  ev27('t_restructure', {
    cls: 'corp', w: 2, cond: () => liveCos().filter(c => (c.hist || []).slice(-6).reduce((t, x) => t + x.profit, 0) < 0).length >= 2,
    data: () => ({ L: liveCos().filter(c => (c.hist || []).slice(-6).reduce((t, x) => t + x.profit, 0) < 0).map(c => c.id) }),
    t: () => 'Several of your companies keep losing money',
    b: (co, d) => d.L.map(id => getCo(id).name).join(', ') + ' have lost money for six months. Your advisors want a decision.',
    o: [
      { l: 'Sell the weakest', d: 'It goes at a low price, but stops the bleeding.', run: (co, d) => { const w = d.L.map(getCo).filter(c => c && c.st === 'open').sort((a, b) => coEbit12(a) - coEbit12(b))[0]; if (w) { const o = saleOffers(w).find(x => x.id === 4) || saleOffers(w)[0]; acceptSale(w, o); } } },
      { l: 'New management where there is a manager', d: '', run: (co, d) => { d.L.map(getCo).filter(c => c && c.mgr).forEach(c => R27.replaceMgr && R27.replaceMgr(c, 'external')); } },
      { l: 'Keep funding them', d: 'They may support the rest of the group.', run: () => { } }
    ], def: 2
  });
  ev27('t_ipo', {
    cls: 'corp', w: 2, cond: () => S.cos.some(c => c.type === 'hold' && c.st === 'open' && !c.listed && companyValue(c) > KC(30e6)),
    data: () => { const h = S.cos.find(c => c.type === 'hold' && c.st === 'open' && !c.listed && companyValue(c) > KC(30e6)); return h ? { h: h.id, n: h.name } : { skip: 1 }; },
    t: (co, d) => 'A bank proposes listing ' + d.n,
    b: () => 'An investment bank thinks the market would value your group well. A listing raises money and makes shares easy to sell, but you report every quarter and outsiders get a say. Private equity would invest without a listing, for a big stake and a seat at the table.',
    o: [
      { l: 'Go public', d: () => 'Listing fee about ' + fmt(KC(1500000)) + '.', run: (co, d) => { const h = getCo(d.h); if (!h) return; const fee = KC(1500000); payMe(fee, 'Stock exchange listing'); h.listed = 1; if (R27.amb) R27.amb().cnt.ipo++; note(h.name + ' is listed on the stock exchange.', 'good', h.id); } },
      { l: 'Wait for better numbers', d: '', run: () => { } },
      { l: 'Take private equity instead', d: 'They buy 25% in new shares.', run: (co, d) => { const h = getCo(d.h); if (!h) return; const r = sellShares(h, 25, 'primary'); if (typeof r === 'number') { const x = h.holders[h.holders.length - 1]; if (x) { x.name = brandCoName(CC(), 'fin') + ' Partners'; x.k27 = 'exit'; x.sat = 60; } } } }
    ], def: 1
  });
  ev27('t_pe', {
    cls: 'corp', w: 2, cond: () => liveCos().some(c => c.form === 'AS' && coEbit12(c) > KC(1e6) && c.own >= 90),
    data: () => { const c = liveCos().filter(x => x.form === 'AS' && coEbit12(x) > KC(1e6) && x.own >= 90).sort((a, b) => companyValue(b) - companyValue(a))[0]; return c ? { c: c.id, n: c.name, v: rnl(companyValue(c) * 1.2, 1000) } : { skip: 1 }; },
    t: (co, d) => 'Private equity wants control of ' + d.n,
    b: (co, d) => 'A private equity firm values ' + d.n + ' at ' + fmt(d.v) + ' and wants 60%. You would cash in now and keep 40%, but they would run it their way and sell within five years.',
    o: [
      { l: 'Sell them 60%', d: '', run: (co, d) => { const c = getCo(d.c); if (!c) return; const amt = Math.round(d.v * 0.6 * c.own / 100); gainMe(amt, 'Sold 60% of ' + c.name + ' to private equity'); S.tax.gain = (S.tax.gain || 0) + amt * 0.7; c.holders = c.holders || []; c.holders.push({ name: brandCoName(CC(), 'fin') + ' Equity', pct: 60, in: amt, k27: 'exit', sat: 65, w0: S.week }); c.own = c.own * 0.4; c.flags.boardSeat = (c.flags.boardSeat || 0) + 2; } },
      { l: 'Offer them 25% instead', d: 'They may accept a minority stake.', run: (co, d) => { const c = getCo(d.c); if (!c || !chance(0.5)) { note('They only wanted control.', 'n'); return; } const amt = Math.round(d.v * 0.25 * c.own / 100); gainMe(amt, 'Sold 25% of ' + c.name); S.tax.gain = (S.tax.gain || 0) + amt * 0.7; c.holders = c.holders || []; c.holders.push({ name: brandCoName(CC(), 'fin') + ' Equity', pct: 25, in: amt, k27: 'growth', sat: 60, w0: S.week }); c.own = c.own * 0.75; c.flags.boardSeat = (c.flags.boardSeat || 0) + 1; } },
      { l: 'Say no', d: '', run: () => { } }
    ], def: 2
  });
  ev27('t_hostile', {
    cls: 'corp', w: 3, cond: () => S.cos.some(c => c.type === 'hold' && c.st === 'open' && c.listed && c.own < 60),
    data: () => { const h = S.cos.find(c => c.type === 'hold' && c.st === 'open' && c.listed && c.own < 60); const g = R27.groupsIn ? R27.groupsIn(S.country).filter(x => !x.dist).sort((a, b) => b.cash - a.cash)[0] : null; return h && g ? { h: h.id, n: h.name, g: g.id, gn: g.name } : { skip: 1 }; },
    t: (co, d) => d.gn + ' is buying up shares in ' + d.n, tone: 'bad',
    b: (co, d) => d.gn + ' has quietly built up a stake in ' + d.n + ' and wants seats on the board. If it gets more than half, it can replace the board, and you.',
    o: [
      { l: 'Buy shares back', d: 'Costs you cash; lifts your stake.', run: (co, d) => { const h = getCo(d.h); if (!h) return; const V0 = companyValue(h), add = Math.min(100 - h.own, 10), c = Math.round(V0 * add / 100 * 1.15); if (S.cash < c) { note('Not enough cash to buy back shares.', 'bad'); hostile(h, d, 0.6); return; } payMe(c, 'Share buyback in ' + h.name); h.own += add; hostile(h, d, 0.25); } },
      { l: 'Find a friendly investor', d: 'A "white knight" takes a stake and votes with you.', run: (co, d) => { const h = getCo(d.h); if (h) hostile(h, d, 0.3); } },
      { l: 'Negotiate a sale', d: 'Sell to them at a good price.', run: (co, d) => { const h = getCo(d.h), g = R27.G(d.g); if (h && g && R27.sellToGroup) R27.sellToGroup(h, g, Math.round(companyValue(h) * 1.3)); } },
      { l: 'Defend your strategy in public', d: 'Convince the other shareholders.', run: (co, d) => { const h = getCo(d.h); if (h) hostile(h, d, 0.5); } }
    ], def: 3
  });
  function hostile(h, d, p) {
    if (chance(p)) { const g = R27.G(d.g); if (g && R27.sellToGroup) { R27.sellToGroup(h, g, Math.round(companyValue(h) * 1.2)); info('Shareholders of ' + h.name, d.gn + ' took control of ' + h.name, 'Enough shareholders sold to ' + d.gn + '. Your stake was bought at the offer price.', 0, 'bad'); } }
    else note('The takeover attempt on ' + h.name + ' failed.', 'good');
  }
  ev27('t_downgrade', {
    cls: 'crisis', w: 2, cond: () => { const nw = Math.max(1, (() => { try { return netWorth().total; } catch (e) { return 1; } })()); return totalDebt() > nw * 0.8 && totalDebt() > KC(5e6); },
    auto: () => { S.credit = clamp((S.credit || 60) - 10, 0, 100); }, tone: 'bad',
    t: () => 'Your credit rating has been cut',
    b: () => 'With this much debt against what you own, lenders see more risk. New loans will cost more until the debt comes down or profits go up. Selling assets or paying down debt helps.'
  });
  ev27('t_antitrust', {
    cls: 'crisis', w: 2, cond: () => window.R26 && R26.markets().some(m => R26.truthOf(m).share > 0.35),
    data: () => { const m = R26.markets().filter(x => R26.truthOf(x).share > 0.35)[0]; return m ? { k: m.k, c: m.cos[0].id, n: m.cos[0].name, s: R26.truthOf(m).share } : { skip: 1 }; },
    t: (co, d) => 'The competition authority investigates ' + d.n, from: '{auth:comp}', tone: 'bad',
    b: (co, d) => 'You hold about ' + Math.round(d.s * 100) + '% of the market. The authority wants to know whether you use that position against customers and rivals. Legal costs have started.',
    pre: (co, d) => { const c = getCo(d.c); if (c) pay(c, KC(60000), 'oth', 'Lawyers: competition case'); },
    o: [
      { l: 'Offer to sell part of the business', d: 'Sell this company to end the case.', run: (co, d) => { const c = getCo(d.c); if (c) { const o = saleOffers(c).find(x => x.id === 3) || saleOffers(c)[0]; acceptSale(c, o); } } },
      { l: 'Accept conditions', d: 'No price cuts or acquisitions in this market for a year.', run: (co, d) => { const c = getCo(d.c); if (c) { c.flags.ac27 = S.week + 52; if (c.price < 0) c.price = 0; } } },
      { l: 'Fight it', d: 'More legal costs; a fine of several percent of sales if you lose.', run: (co, d) => { const c = getCo(d.c); if (!c) return; pay(c, KC(150000), 'oth', 'Lawyers: competition case'); if (chance(0.45)) pay(c, yr(c) * 0.04, 'fine', 'Competition fine'); else note('The authority closed the case against ' + c.name + '.', 'good', c.id); } }
    ], def: 1
  });
  ev27('t_activist', {
    cls: 'corp', w: 2, cond: () => liveCos().some(c => (c.holders || []).some(h => h.pct >= 10)),
    data: () => { const c = liveCos().filter(x => (x.holders || []).some(h => h.pct >= 10))[0]; const h = c.holders.filter(x => x.pct >= 10).sort((a, b) => b.pct - a.pct)[0]; return { c: c.id, n: c.name, h: h.name, p: h.pct }; },
    t: (co, d) => d.h + ' pushes for changes at ' + d.n,
    b: (co, d) => d.h + ' (' + d.p.toFixed(1) + '%) wants higher dividends and lower costs, and says so to the other owners.',
    o: [
      { l: 'Adopt their plan', d: '50% of profit as dividends, and a cost review.', run: (co, d) => { const c = getCo(d.c); if (!c) return; c.dp27 = 'mid'; cost(c, 0.98, 26); c.mood = Math.max(0, (c.mood || 60) - 5); (c.holders || []).forEach(h => { h.sat = Math.min(100, (h.sat || 60) + 12); }); } },
      { l: 'Meet them halfway', d: '25% as dividends.', run: (co, d) => { const c = getCo(d.c); if (!c) return; c.dp27 = 'low'; (c.holders || []).forEach(h => { h.sat = Math.min(100, (h.sat || 60) + 5); }); } },
      { l: 'Oppose them', d: 'What happens depends on how many shares they can rally.', run: (co, d) => { const c = getCo(d.c); if (!c) return; (c.holders || []).forEach(h => { h.sat = Math.max(0, (h.sat || 60) - 10); }); if (R27.outside(c) > 50) { c.dp27 = 'mid'; note('The other owners outvoted you: ' + c.name + ' now pays out half its profit.', 'bad', c.id); } } }
    ], def: 1
  });
  ev27('t_auction', {
    cls: 'opp', w: 1, cond: () => tycoon() && S.cash > KC(20e6),
    data: () => { const cs = Object.keys(CO).filter(c => c !== S.country); const cc = cs[rint(0, cs.length - 1)]; R27.ensureCC(cc); const gs = R27.groupsIn(cc).filter(g => g.cc === cc && !g.dist); const g = gs.sort((a, b) => b.rev - a.rev)[0]; return g ? { g: g.id, n: g.name, cc, v: rnl(R27.valueOf(g) * 0.3, 1000) } : { skip: 1 }; },
    t: (co, d) => 'A 30% stake in ' + d.n + ' is up for auction',
    b: (co, d) => 'The founding family of ' + d.n + ' (' + (CO[d.cc] || {}).name + ') is selling 30%. Fair value is about ' + fmt(d.v) + '. Others are bidding: to win you probably have to pay more, and overpaying destroys value even if your group gets bigger.',
    o: [
      { l: 'Bid aggressively', d: 'About 30% above fair value. You probably win.', run: (co, d) => buyStake(d, 0.3, 1.3, 0.8) },
      { l: 'Partner with another investor', d: '15% each, at a fair price. You may lose out.', run: (co, d) => buyStake(d, 0.15, 1.1, 0.55) },
      { l: 'Walk away', d: '', run: () => { } }
    ], def: 2
  });
  function buyStake(d, pct, mult, p) {
    const g = R27.G(d.g);
    if (!g) return;
    const price = rnl(R27.valueOf(g) * pct * mult, 1000);
    if (!chance(p)) { note('Another bidder won the stake in ' + g.name + '.', 'n'); return; }
    if (S.cash < price) { note('You could not raise ' + fmt(price) + ' in time.', 'bad'); return; }
    payMe(price, 'Stake in ' + g.name);
    S.st27 = S.st27 || [];
    S.st27.push({ g: g.id, pct, cost: price, w: S.week });
    note('You now own ' + Math.round(pct * 100) + '% of ' + g.name + '.', 'good');
  }
  /* stakes in other groups: dividends each quarter and a value in your net worth */
  addStep('netWorth', 30, 'stakes in other groups', r => { const v = sumF(S.st27 || [], s => { const g = R27.G(s.g); return g && !g.gone ? R27.valueOf(g) * s.pct : 0; }); if (v) { r.inv = (r.inv || 0) + v; r.total += v; } }, true);

  /* ================= any company ================= */
  ev27('x_infl', {
    cls: 'gen', w: 2, cond: () => (S.econ.infl || 0) > 0.03, tone: 'bad', from: 'Economy',
    auto: () => liveCos().filter(c => c.country === S.country).forEach(c => cost(c, 1.025, 13)),
    t: () => 'Prices are rising faster than expected',
    b: () => 'Inflation is running at ' + pc(S.econ.infl, 1) + '. Costs and wage demands creep up over the coming months. Businesses that can raise prices protect their margins; fixed-price contracts suffer.'
  });
  ev27('x_tech', {
    cls: 'gen', w: 2, cond: co => co && ['svc', 'retail', 'logi', 'prod'].indexOf(fam(co)) >= 0,
    data: co => ({ c: rnl(Math.max(KC(50000), yr(co) * 0.03), 1000) }),
    t: co => 'New technology changes ' + BD[co.type].n.toLowerCase(),
    b: (co, d) => 'A new kind of software and equipment is spreading through the trade. Early users cut costs and win customers who expect it. Getting it costs about ' + fmt(d.c) + '.',
    o: [
      { l: 'Invest now', d: 'Lower costs and a small edge for two years.', run: (co, d) => { pay(co, d.c, null, 'New technology'); co.flags.capex27 = (co.flags.capex27 || 0) + d.c; cost(co, 0.95, 104); dem(co, 1.03, 52); } },
      { l: 'Partner with a provider', d: 'A monthly fee instead of a big bill.', run: (co, d) => { pay(co, d.c * 0.15, 'oth', 'Technology partner'); cost(co, 0.98, 104); } },
      { l: 'Wait and see', d: 'No cost now. Customers may drift to those who have it.', run: co => dem(co, 0.96, 52) }
    ], def: 2
  });
  ev27('x_claim', {
    cls: 'crisis', w: 2,
    data: co => ({ c: rnl(Math.max(KC(30000), yr(co) * 0.01), 1000), who: ['a former employee', 'a supplier', 'a customer', 'a competitor'][rint(0, 3)] }),
    t: (co, d) => co.name + ' is sued by ' + d.who,
    b: (co, d) => 'They claim about ' + fmt(d.c * 3) + '. Legal costs have started. Settling is cheaper and certain; defending may clear you, or cost more.',
    pre: (co, d) => { pay(co, d.c * 0.2, 'oth', 'Lawyers'); },
    o: [
      { l: 'Settle', d: (co, d) => 'Pay ' + fmt(d.c) + ', a third of the claim.', run: (co, d) => pay(co, d.c, 'oth', 'Settlement') },
      { l: 'Defend it', d: '', run: (co, d) => { pay(co, d.c * 0.5, 'oth', 'Lawyers'); if (chance(0.45)) pay(co, d.c * 3, 'oth', 'Damages awarded'); else note(co.name + ' won the case.', 'good', co.id); } }
    ], def: 0
  });

  /* ================= country events ================= */
  const CEV = [
    ['NO', 'Offshore investment slows', 'Oil companies cut back. Offshore suppliers lose contracts; the rest of the economy barely notices.', { energy: 0.85, logi: 0.95, project: 0.95 }],
    ['NO', 'Fish-farming rules tighten', 'New environmental and licence rules raise costs for fish farms.', { salmon: ['cost', 1.08, 52] }],
    ['SE', 'Housing and building slow down', 'Fewer new homes are started. Builders and building suppliers must plan for less work.', { project: 0.85, hardware: 0.9, furniture: 0.93 }],
    ['SE', 'A weak krona helps exporters', 'Swedish goods are cheaper abroad; imported equipment and parts cost more.', { prod: 1.06, retail: ['cost', 1.04, 26] }],
    ['LT', 'Baltic freight booms', 'Cross-border freight is in demand. Transport firms can fill more trucks if they have drivers.', { trucking: 1.15, courier: 1.06 }],
    ['LT', 'Young workers leave for the West', 'Some trades struggle to fill jobs. Expect higher wage demands.', { wage: 1.03 }],
    ['BR', 'The real falls sharply', 'Imported machinery and foreign debt get more expensive; exporters may gain.', { all: ['cost', 1.05, 26], prod: 1.03 }],
    ['BR', 'Credit gets tighter', 'Banks charge more and lend less. Heavily indebted firms feel it; cash-rich buyers find bargains.', { rate: 0.015 }],
    ['BR', 'A crop shock', 'A poor harvest raises food prices. Farms gain; restaurants and grocers pay more.', { farm: 1.1, restaurant: ['cost', 1.05, 26], grocery: ['cost', 1.04, 26], bakery: ['cost', 1.05, 26] }],
    ['DE', 'Industrial exports weaken', 'Foreign customers order less from German factories and their suppliers.', { factory: 0.88, trucking: 0.94, engcons: 0.94 }],
    ['DE', 'Energy prices squeeze factories', 'Electricity and gas cost more. Energy-heavy production is hit hardest.', { prod: ['cost', 1.06, 26] }],
    ['FR', 'Strikes disrupt transport', 'A transport strike delays deliveries and keeps customers at home in some cities.', { logi: ['cap', 0.8, 2], venue: 0.92, retail: 0.95 }],
    ['FR', 'Tourists shift destinations', 'Visitor numbers swing between regions. Hotels and restaurants adjust staff and prices.', { hotel: 0.92, restaurant: 0.96, fun: 0.94 }],
    ['PL', 'Wages catch up', 'Employers compete for skilled workers. Labour costs rise.', { wage: 1.04 }],
    ['PL', 'A currency move raises import costs', 'Imported equipment costs more; local suppliers gain an edge.', { all: ['cost', 1.03, 26] }],
    ['KR', 'Electronics parts run short', 'A component shortage delays production and deliveries.', { prod: ['cap', 0.85, 6], retail: ['cost', 1.04, 13] }],
    ['KR', 'Export demand swings', 'Global orders for Korean goods change. Exporters adjust capacity.', { prod: 0.92 }],
    ['JP', 'An older customer base', 'Demand shifts towards services for older people; youth-oriented businesses lose ground.', { physio: 1.08, nightclub: 0.92, gym: 0.97 }],
    ['JP', 'The yen moves', 'Imports, foreign debt, tourism and exports all feel the exchange rate.', { hotel: 1.06, retail: ['cost', 1.04, 26] }],
    ['AU', 'Mining slows', 'Commodity prices fall. Mining services, transport and regional hotels lose work.', { energy: 0.9, trucking: 0.92, hotel: 0.96 }],
    ['AU', 'Bushfire season', 'Heat and fires disrupt operations and raise insurance and safety costs.', { all: ['cost', 1.02, 13], project: ['cap', 0.85, 3], farm: ['cap', 0.8, 3] }],
    ['CA', 'The housing market corrects', 'Less building and fewer home sales: developers, builders and furniture shops feel it.', { project: 0.85, furniture: 0.9, estate: 0.85 }],
    ['CA', 'Border delays with the US', 'Trade with the US slows at the border. Exporters and their transport partners are hit.', { prod: 0.94, trucking: 0.92 }],
    ['NL', 'Port congestion', 'Delays at the big ports mean longer deliveries and more stock to hold.', { retail: ['cost', 1.03, 13], logi: ['cap', 0.9, 4] }],
    ['NL', 'Warehouse space runs short', 'Warehouse rents rise as everyone wants space near the ports.', { logi: ['cost', 1.04, 52], webshop: ['cost', 1.03, 52] }],
    ['ES', 'A strong tourist season', 'Visitors flood in. Hotels, restaurants and leisure fill up; prices can rise.', { hotel: 1.15, restaurant: 1.08, fun: 1.1, cafe: 1.05 }],
    ['ES', 'Property markets split', 'Rents and prices rise in some cities and fall in others.', { estate: 0.95, realdev: 0.95 }],
    ['UK', 'The pound swings', 'Importers, exporters and anyone with foreign debt feel the move.', { retail: ['cost', 1.03, 26], prod: 1.03 }],
    ['US', 'Insurance costs spike in exposed regions', 'Premiums jump after a run of disasters.', { all: ['cost', 1.015, 52] }]
  ];
  CEV.forEach((x, i) => ev27('c_' + x[0] + i, {
    cls: 'cty', cc: x[0], w: 2, tone: 'n', from: 'Economy',
    t: () => (CO[x[0]] || {}).name + ': ' + x[1].charAt(0).toLowerCase() + x[1].slice(1), b: () => x[2],
    auto: () => {
      const fx = x[3];
      liveCos().filter(c => c.country === x[0]).forEach(c => {
        const f = fx[c.type] != null ? fx[c.type] : fx[fam(c)] != null ? fx[fam(c)] : fx.all;
        if (f == null) return;
        if (typeof f === 'number') dem(c, f, 26);
        else if (f[0] === 'cost') cost(c, f[1], f[2]);
        else if (f[0] === 'cap') cap(c, f[1], f[2]);
      });
      if (fx.wage) liveCos().filter(c => c.country === x[0]).forEach(c => (c.staff || []).forEach(s => { s.wage = Math.round(s.wage * fx.wage); }));
      if (fx.rate) st().rate.push({ cc: x[0], add: fx.rate, until: S.week + 39 });
    }
  }));
  /* country events with a real choice */
  ev27('c_NO_wage', {
    cls: 'cty', cc: 'NO', w: 2, cond: co => (co.staff || []).length >= 4,
    t: co => 'A tight labour market squeezes ' + co.name, b: () => 'Norwegian employers compete hard for people. Your staff hear about better offers every week.',
    o: [
      { l: 'Raise pay 4%', d: '', run: co => { co.staff.forEach(s => { s.wage = Math.round(s.wage * 1.04); }); co.mood = Math.min(100, (co.mood || 60) + 5); } },
      { l: 'Invest in productivity', d: 'Better tools so fewer people do more.', run: co => { pay(co, payroll(co) * 1.5, null, 'Productivity tools'); cap(co, 1.06, 52); } },
      { l: 'Hire less and accept vacancies', d: 'Slower growth.', run: co => { co.mood = Math.max(0, (co.mood || 60) - 6); if (chance(0.3) && co.staff.length > 1) fireStaff(co, co.staff[co.staff.length - 1].id, 1); } }
    ], def: 2
  });
  ev27('c_LT_eu', {
    cls: 'cty', cc: 'LT', w: 2, cond: co => co.form === 'AS',
    t: co => 'EU money for modernising ' + co.name, b: () => 'An EU programme co-finances new equipment and technology. Applying takes work and there is no guarantee.',
    o: [
      { l: 'Apply', d: 'Paperwork costs now; about half of applicants get support.', run: co => { pay(co, KC(8000), 'oth', 'EU application'); later(10, 'c_LT_eu_res', co, {}); } },
      { l: 'Invest without support', d: 'Faster, full price.', run: co => { pay(co, yr(co) * 0.03, null, 'Modernisation'); cost(co, 0.96, 104); } },
      { l: 'Skip it', d: '', run: () => { } }
    ], def: 2
  });
  ev27('c_PL_contract', {
    cls: 'cty', cc: 'PL', w: 2, cond: co => fam(co) === 'prod' || fam(co) === 'logi',
    t: co => 'A foreign manufacturer wants ' + co.name + ' as a supplier', b: () => 'A big contract, but one customer would be a large part of your business.',
    o: [
      { l: 'Take it all', d: '', run: co => { dem(co, 1.35, 104); later(60, 'c_dep_risk', co, {}); } },
      { l: 'Take part, subcontract the rest', d: 'Less risk, less margin.', run: co => { dem(co, 1.15, 104); cost(co, 1.02, 104); } },
      { l: 'Decline', d: 'Too much eggs in one basket.', run: () => { } }
    ], def: 2
  });
  ev27('c_KR_cust', {
    cls: 'cty', cc: 'KR', w: 2, cond: co => b2b(co) > 0.2,
    t: co => 'A large corporate customer squeezes ' + co.name, b: () => 'They want 8% lower prices and stricter delivery terms, or they will take their business elsewhere.',
    o: [
      { l: 'Accept for the volume', d: '', run: co => cost(co, 1.05, 52) },
      { l: 'Negotiate service levels', d: '', run: co => { if (chance(0.5)) cost(co, 1.02, 52); else dem(co, 0.9, 26); } },
      { l: 'Diversify to smaller customers', d: '', run: co => { dem(co, 0.88, 26); pay(co, wk(co) * 0.4, 'mkt', 'Finding new customers'); } }
    ], def: 0
  });
  ev27('c_JP_succ', {
    cls: 'cty', cc: 'JP', w: 2, cond: co => LOCALT(co) && (rivalsOf(co) || []).some(r => !r.g27 && !r.listed),
    data: co => { const r = (rivalsOf(co) || []).filter(x => !x.g27 && !x.listed)[0]; return r ? { r: r.id, n: r.name } : { skip: 1 }; },
    auto: (co, d) => { const r = (rivalsOf(co) || []).find(x => x.id === d.r); if (r) { r.listed = true; r.dist27 = S.week; r.succ27 = 1; } },
    t: (co, d) => d.n + ' has no successor', tone: 'good',
    b: (co, d) => 'The owner of ' + d.n + ' is retiring and has no one to take over. It is profitable and for sale at a fair price.',
    go: (co, d) => ({ l: 'See ' + d.n, a: 'go', p: { n: 'rival', p: { id: co.id, r: d.r } } })
  });
  ev27('c_UK_rent', {
    cls: 'cty', cc: 'UK', w: 2, cond: co => co.prem && !co.prem.owned,
    t: co => 'The landlord of ' + co.name + ' wants 20% more rent', b: () => 'The lease is up for renewal.',
    o: [
      { l: 'Negotiate', d: 'You may get 8%.', run: co => { co.flags.rent27 = { m: chance(0.6) ? 1.08 : 1.2, until: S.week + 260 }; } },
      { l: 'Move somewhere cheaper', d: 'A month of disruption, and some regulars lose track of you.', run: co => { cap(co, 0.75, 3); dem(co, 0.95, 26); co.flags.rent27 = { m: 0.92, until: S.week + 260 }; } },
      { l: 'Accept', d: 'The location is worth it.', run: co => { co.flags.rent27 = { m: 1.2, until: S.week + 260 }; } }
    ], def: 2
  });
  ev27('c_US_fed', {
    cls: 'cty', cc: 'US', w: 2, cond: co => b2b(co) > 0.2 && (co.staff || []).length >= 5,
    t: co => 'A federal contract that fits ' + co.name, b: () => 'Steady work for years, with heavy compliance requirements.',
    o: [
      { l: 'Bid', d: '', run: co => { pay(co, KC(20000), 'oth', 'Federal bid'); if (chance(0.3)) { dem(co, 1.25, 156); cost(co, 1.03, 156); note(co.name + ' won the federal contract.', 'good', co.id); } } },
      { l: 'Partner with an established contractor', d: '', run: co => { if (chance(0.5)) dem(co, 1.1, 156); } },
      { l: 'Pass', d: '', run: () => { } }
    ], def: 2
  });
  ev27('c_US_vc', {
    cls: 'cty', cc: 'US', w: 2, cond: co => co.form === 'AS' && co.own > 80 && S.week - (co.w0 || 0) < 156 && yr(co) > KC(2e6),
    data: co => ({ v: rnl(companyValue(co) * 1.6, 1000) }),
    t: co => 'Venture capital wants to invest in ' + co.name,
    b: (co, d) => 'A fund values ' + co.name + ' at ' + fmt(d.v) + ' and wants 20% in new shares. Money to grow fast, a board seat for them, and less of the company for you.',
    o: [
      { l: 'Take the money', d: '', run: (co, d) => { const amt = Math.round(d.v * 0.2 / 0.8); coIn(co, amt, null, 'Venture capital'); co.holders = co.holders || []; co.holders.push({ name: brandCoName(CC(), 'fin') + ' Ventures', pct: 20 * co.own / 100, in: amt, k27: 'growth', sat: 65, w0: S.week }); co.own = co.own * 0.8; co.flags.boardSeat = (co.flags.boardSeat || 0) + 1; } },
      { l: 'Borrow instead', d: 'Keep the shares, take on debt.', run: co => { takeLoan('biz', rnl(yr(co) * 0.2, 1000), 60, co); } },
      { l: 'Grow on your own profits', d: '', run: () => { } }
    ], def: 2
  });
  ev27('c_ES_tax', {
    cls: 'cty', cc: 'ES', w: 1, cond: () => { try { return netWorth().total > KC(10e6); } catch (e) { return false; } }, from: '{auth:tax}',
    t: () => 'The tax office asks you to review your tax position', b: () => 'A notice asks you to review your personal and company tax affairs.',
    o: [
      { l: 'Pay for proper advice', d: '', run: () => payMe(KC(25000), 'Tax advisor') },
      { l: 'Reorganise where it is legal', d: 'Advice now, and a structure that may save tax later.', run: () => payMe(KC(60000), 'Tax restructuring') },
      { l: 'Carry on as you are', d: '', run: () => { if (chance(0.2)) payMe(KC(40000), 'Back taxes and interest'); } }
    ], def: 2
  });
  ev27('c_NL_wh', {
    cls: 'cty', cc: 'NL', w: 2, cond: co => co.type === 'webshop' || fam(co) === 'logi' || co.type === 'grocery',
    t: co => 'Warehouse space for ' + co.name + ' is getting scarce', b: () => 'Rents for storage near the ports are rising fast.',
    o: [
      { l: 'Sign a long lease now', d: 'Lock in today\'s price for five years.', run: co => { pay(co, wk(co) * 0.3, 'rent', 'Lease deposit'); cost(co, 0.99, 260); } },
      { l: 'Use a logistics provider', d: 'Flexible, a bit dearer.', run: co => cost(co, 1.02, 104) },
      { l: 'Hold less stock', d: 'Cheaper, but more stock-outs.', run: co => cap(co, 0.95, 52) }
    ], def: 1
  });
  ev27('c_AU_freight', {
    cls: 'cty', cc: 'AU', w: 2, cond: co => typeof hasGoods === 'function' && hasGoods(co),
    t: co => 'Long-distance freight costs hit ' + co.name, b: () => 'Moving goods across the country costs more this year.',
    o: [
      { l: 'Consolidate deliveries', d: 'Fewer, bigger loads; sometimes slower.', run: co => { cost(co, 1.01, 26); dem(co, 0.98, 13); } },
      { l: 'Buy more locally', d: '', run: co => cost(co, 1.015, 26) },
      { l: 'Raise prices', d: '', run: co => { cost(co, 1.03, 26); dem(co, 0.97, 26); } }
    ], def: 2
  });
  ev27('c_SE_wage', {
    cls: 'cty', cc: 'SE', w: 2, cond: co => (co.staff || []).length >= 5,
    t: () => 'Industry-wide wage talks in Sweden', b: () => 'The unions and employers negotiate a new collective agreement. Labour costs will rise; how much is uncertain.',
    o: [
      { l: 'Plan for a 4% rise', d: '', run: co => co.staff.forEach(s => { s.wage = Math.round(s.wage * 1.04); }) },
      { l: 'Plan productivity gains', d: 'Training and tools, then a smaller rise.', run: co => { pay(co, payroll(co) * 0.8, 'oth', 'Training'); co.staff.forEach(s => { s.wage = Math.round(s.wage * 1.025); }); } },
      { l: 'Hire less this year', d: '', run: co => { co.staff.forEach(s => { s.wage = Math.round(s.wage * 1.03); }); } }
    ], def: 0
  });
  ev27('c_CA_proj', {
    cls: 'cty', cc: 'CA', w: 2, cond: co => ['project', 'logi', 'venue'].indexOf(fam(co)) >= 0,
    t: () => 'A big resource project nearby', b: () => 'A mine and pipeline project needs builders, trucks, rooms and meals for two years. It will end, though.',
    o: [
      { l: 'Go after the work', d: 'More business, travel costs, and it ends.', run: co => { dem(co, 1.25, 104); cost(co, 1.03, 104); } },
      { l: 'Take some, keep your regulars first', d: '', run: co => dem(co, 1.1, 104) },
      { l: 'Stay out', d: '', run: () => { } }
    ], def: 1
  });
  ev27('c_DE_quality', {
    cls: 'cty', cc: 'DE', w: 2, cond: co => fam(co) === 'prod',
    t: co => 'A key part for ' + co.name + ' fails quality checks', b: () => 'A batch from your main parts supplier does not meet spec.',
    o: [
      { l: 'Stop production to inspect', d: 'A week lost; no faulty goods ship.', run: co => cap(co, 0.3, 1) },
      { l: 'Switch supplier', d: 'Dearer, but safe.', run: co => cost(co, 1.04, 26) },
      { l: 'Controlled delay and claim compensation', d: '', run: co => { cap(co, 0.8, 2); if (chance(0.6)) coIn(co, wk(co) * 0.2, 'rev', 'Compensation from supplier'); } }
    ], def: 2
  });

  /* ---------- follow-ups ---------- */
  const FOLLOW = {
    g_location_neg: (co, d) => { if (chance(0.5)) { R27.fire('g_location', co, Object.assign({}, d, { disc: d.disc + 10 })); } else note('The site in ' + d.cn + ' went to someone else.', 'n', co.id); },
    g_quality_bad: co => { rep(co, -4); dem(co, 0.93, 12); note('The complaints at ' + co.name + ' have reached the review sites.', 'bad', co.id); },
    e_auto_done: (co, d) => { const n = d.n || 1; for (let i = 0; i < n; i++) { const s = co.staff.filter(x => ['fworker', 'helper', 'cashier', 'operator', 'labour'].indexOf(x.role) >= 0).sort((a, b) => staffSkill(a) - staffSkill(b))[0]; if (s && co.staff.length > 2) fireStaff(co, s.id, 0); } cap(co, 1 + 0.06 * n, 260); note('The new equipment at ' + co.name + ' is running.', 'good', co.id); },
    e_rep_review: co => { if (chance(0.65)) { rep(co, 6); note('The independent review cleared ' + co.name + '.', 'good', co.id); } else { rep(co, -3); note('The review found real problems at ' + co.name + '.', 'bad', co.id); } },
    e_wages_2: co => { co.staff.forEach(s => { s.wage = Math.round(s.wage * 1.03); }); },
    e_merger_review: (co, d) => { if (chance(0.4)) R27.fire('t_antitrust', co); },
    c_LT_eu_res: co => { if (chance(0.5)) { cost(co, 0.95, 156); note('The EU programme will co-finance new equipment at ' + co.name + '.', 'good', co.id); } else note('The EU application for ' + co.name + ' was turned down.', 'n', co.id); },
    c_dep_risk: co => { if (chance(0.3)) { dem(co, 0.7, 26); note('The big foreign customer of ' + co.name + ' moved production elsewhere.', 'bad', co.id); } }
  };
  /* rent changes from events (a cheaper first lease, a renewal) */
  addStep('rentWeek.before', 10, 'rent changes from events: cash before', (co, ph) => {
    const r = co && co.flags && co.flags.rent27;
    if (r && S.week < r.until) { ph.r27 = r; ph.c0 = co.cash; }
  });
  addStep('rentWeek.after', 10, 'rent changes from events', (co, ph) => {
    const r = ph.r27;
    if (!r) return;
    const paid = ph.c0 - co.cash;
    if (paid > 0 && r.m !== 1) { const d = Math.round(paid * (1 - r.m)); if (d > 0) { coIn(co, d, null, null); bk(co, 'rent', -d); } else payCo(co, -d, 'rent', null); }
  });
  /* tighter credit in a country */
  addStep('loanRate', 10, 'rate rises after country events', (l, r) => {
    const co = l.co ? getCo(l.co) : null, cc = co ? co.country : S.country; const add = sumF((st().rate || []).filter(x => x.cc === cc && S.week < x.until), x => x.add); return r + add;
  }, true);

  /* ---------- making some existing events simply happen ---------- */
  const AUTO = { g_theft: 1, g_power: 1, g_roadwork: 1, g_heat: 1, l_fuel: 1, p_matprice: 1, pr_flour: 1, pr_wood: 0, l_toll: 0, r_carrier: 1, l_app: 0, g_it: 1, r_adCost: 1, r_stockout: 1 };
  Object.keys(AUTO).forEach(k => { const e = EV[k]; if (!e || !e.opts || !e.opts.length) return; e.fx = e.opts[AUTO[k]].fx; e.auto = true; e.opts = []; });
  if (EV.g_power) { EV.g_power.fx = { cap: [0.85, 1] }; EV.g_power.t = 'A power cut hits the street around {n}. Part of a day is lost.'; }
  if (EV.g_roadwork) EV.g_roadwork.t = 'Roadworks outside {n} block the street for weeks. Fewer people walk past.';
  if (EV.l_fuel) EV.l_fuel.t = 'Fuel prices jump. Transport costs rise for a couple of months.';
  if (EV.p_matprice) EV.p_matprice.t = 'Material prices spike on building sites. Jobs cost more for a while.';
  if (EV.g_theft) EV.g_theft.t = 'Thieves broke into {n} during the night. Insurance covers part of it if you have it.';
  if (EV.g_it) EV.g_it.t = 'An IT outage hits {n}. Support fixes it in a day, at a cost.';
  /* rivals now come from real competitors (rival groups); the old random versions are rarer */
  ['g_rival', 'r_priceWar', 'r_chain'].forEach(k => { if (EV[k]) EV[k].w = EV[k].w * 0.3; });
  if (EV.g_poach) EV.g_poach.w = EV.g_poach.w * 0.6;

  /* ================= the scheduler ================= */
  const pickDef = (list, co) => {
    const ok = list.filter(d => (!d.st || (co && d.st.indexOf(stage(co)) >= 0)) && (!d.cc || (co ? co.country === d.cc : myCC().indexOf(d.cc) >= 0)) && (S.week - (st().last[d.id] || -999) > 52) && (() => { try { return !d.cond || d.cond(co); } catch (e) { return false; } })());
    if (!ok.length) return null;
    const tot = sumF(ok, d => d.w || 1);
    let x = rng(0, tot);
    for (const d of ok) { if (x < (d.w || 1)) return d; x -= d.w || 1; }
    return ok[0];
  };
  const myCC = () => { const s = {}; liveCos().forEach(c => { s[c.country] = 1; }); return Object.keys(s); };
  function tryFire(d, co) {
    if (!d) return false;
    let ctx;
    try { ctx = d.data ? d.data(co) : {}; } catch (e) { console.error(e); return false; }
    if (!ctx || ctx.skip) return false;
    if (d.skipIf && d.skipIf(co, ctx)) return false;
    if (d.handle) { const r = d.handle(co, ctx); if (r) st().last[d.id] = S.week; return !!r; }
    if (d.pre) d.pre(co, ctx);
    return fire(d, co, ctx);
  }
  R27.tryFire = tryFire;
  function monthly() {
    const s = st(), all = Object.values(E), cos = liveCos();
    if (!cos.length) return;
    const lev = (() => { try { const nw = Math.max(1, netWorth().total); return totalDebt() / nw; } catch (e) { return 0; } })();
    /* strategic choices: roughly one a quarter for a small business, a little more for a bigger group */
    if (S.week - s.lastS >= 5 && chance(Math.min(0.55, 0.3 + 0.05 * cos.length))) {
      const co = cos[rint(0, cos.length - 1)];
      if (tryFire(pickDef(all.filter(d => d.cls === 'strat'), co), co)) s.lastS = S.week;
    }
    /* major opportunities: rare */
    if (S.week - s.lastO >= 20 && chance(0.12)) {
      const co = cos[rint(0, cos.length - 1)];
      if (tryFire(pickDef(all.filter(d => d.cls === 'opp'), co), co)) s.lastO = S.week;
    }
    /* crises: uncommon, more likely with debt and size */
    if (S.week - s.lastC >= 26 && chance(0.05 + Math.min(0.12, lev * 0.08) + (tycoon() ? 0.03 : 0))) {
      const co = cos[rint(0, cos.length - 1)];
      if (tryFire(pickDef(all.filter(d => d.cls === 'crisis'), co), co)) s.lastC = S.week;
    }
    /* corporate events: big groups only */
    if (tycoon() && S.week - s.lastT >= 26 && chance(0.12)) {
      if (tryFire(pickDef(all.filter(d => d.cls === 'corp'), null), null)) s.lastT = S.week;
    }
    /* general and country events */
    if (chance(0.12)) { const co = cos[rint(0, cos.length - 1)]; tryFire(pickDef(all.filter(d => d.cls === 'gen'), co), co); }
    myCC().forEach(cc => {
      if (!chance(0.08)) return;
      const here = cos.filter(c => c.country === cc), co = here[rint(0, here.length - 1)];
      tryFire(pickDef(all.filter(d => d.cls === 'cty' && d.cc === cc), co), co);
    });
  }
  R27.evMonthly = monthly;
  addStep('week.after', 55, 'business_events weekly', () => {
    try {
      const s = st();
      if (s.m !== MI()) { s.m = MI(); monthly(); }
      /* follow-ups that are due */
      const due = s.q.filter(x => S.week >= x.w);
      s.q = s.q.filter(x => S.week < x.w);
      due.forEach(x => { const co = x.co ? getCo(x.co) : null; if (x.co && (!co || co.st !== 'open')) return; try { FOLLOW[x.id] && FOLLOW[x.id](co, x.d); } catch (e) { console.error(e); } });
      /* nobody answered: the default happens */
      S.inbox.forEach(m => {
        if (!m.auto || m.done27 || m.act !== 'e27') return;
        m.done27 = 1;
        const def = E[m.data.id], co = m.data.co ? getCo(m.data.co) : null;
        if (!def || (m.data.co && (!co || co.st !== 'open'))) return;
        const o = def.o && def.o[def.def != null ? def.def : def.o.length - 1];
        try { if (o && o.run) o.run(co, m.data.d, m); } catch (e) { console.error(e); }
      });
      /* group stakes pay dividends each quarter */
      if (S.week % 13 === 0 && S.st27) S.st27 = S.st27.filter(x => { const g = R27.G(x.g); if (!g || g.gone) { note('Your stake in ' + (g ? g.name : 'a group') + ' is worthless: the group went bankrupt.', 'bad'); return false; } const d = Math.max(0, R27.profitOf(g)) * 0.4 / 4 * x.pct; if (d > 0) { gainMe(d, 'Dividend from ' + g.name); S.tax.ytdDiv = (S.tax.ytdDiv || 0) + d; } return true; });
    } catch (e) { console.error(e); }
  });
})();


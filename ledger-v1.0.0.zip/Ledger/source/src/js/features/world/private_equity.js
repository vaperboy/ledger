/* ===== Round 56: private equity. Each year a handful of funds raise money in your country: buyout, growth,
   infrastructure and venture. You commit an amount; the fund calls it in over its first four years, invests it,
   charges 2% a year on what you committed while it invests (1% after) and 20% of the profit above an 8% a year
   hurdle, pays back from year four and winds up after ten years. The value moves with the fund's own deals and with
   the market; venture funds swing the most. Miss a capital call and you lose half your stake. You can sell a stake
   early on the secondary market, at a discount. Gains are taxed when money comes back above what you paid in.
   Shown in its own phone app (Private equity); counted in net worth as investments. Part of Ledger Pro ('pe'). ===== */
window.PE56 = window.PE56 || {};
(function () {
  const PE = window.PE56;
  const STY = {
    buyout: { n: 'Buyout', r: 0.14, v: 0.16, beta: 0.8, d: 'Buys mature companies with borrowed money, makes them better and sells them.' },
    growth: { n: 'Growth', r: 0.16, v: 0.24, beta: 1, d: 'Minority stakes in fast-growing companies.' },
    infra: { n: 'Infrastructure', r: 0.09, v: 0.07, beta: 0.3, d: 'Ports, power lines, fibre and toll roads. Steady and slow.' },
    venture: { n: 'Venture', r: 0.18, v: 0.42, beta: 1.2, d: 'Many young companies. Most fail, a few return the fund.' }
  };
  const ROMAN = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII'];
  const st = () => (S.pe56 = S.pe56 || { offers: [], y: null, mine: [] });
  const yearsIn = f => (S.week - f.w0) / 52;
  const track = q => q >= 0.75 ? 'Top quartile' : q >= 0.55 ? 'Above median' : q >= 0.4 ? 'Median' : 'Below median';
  function offersFor(y) {
    const C = CC(), out = [];
    ['buyout', 'growth', 'infra', 'venture'].forEach((k, i) => {
      const R = hrng(S.seed + ':pe:' + y + ':' + k);
      const q = Math.round((0.25 + R() * 0.7) * 100) / 100;
      const nm = brandCoName(C, 'fin').split(' ')[0] + ' ' + (k === 'infra' ? 'Infrastructure' : k === 'venture' ? 'Ventures' : 'Capital') + ' ' + ROMAN[Math.floor(R() * 6) + 1];
      /* what you see of the manager's past is a noisy read of how good they are */
      const seen = clamp(q + (R() - 0.5) * 0.3, 0.05, 0.98);
      out.push({ id: 'pe' + y + i, k, n: nm, q, seen, min: KC(k === 'venture' ? 500000 : k === 'infra' ? 2500000 : 1000000), y });
    });
    return out;
  }
  function refresh() {
    const s = st(), y = wYear(S.week);
    if (s.y !== y) { s.y = y; s.offers = offersFor(y); }
  }
  PE.offers = () => { refresh(); return st().offers; };
  function commit(o, amt) {
    if (!PRO.ask('pe')) return 'pro';
    amt = Math.round(amt);
    if (amt < o.min) return 'small';
    if (netWorth().total < amt * 1.5) return 'rich'; /* funds take money only from investors who can carry it */
    const s = st();
    s.mine.push({ id: uid(), o: o.id, n: o.n, k: o.k, q: o.q, w0: S.week, com: amt, called: 0, nav: 0, dist: 0, paid: 0, fee: 0, st: 'live' });
    s.offers = s.offers.filter(x => x !== o);
    return 'ok';
  }
  PE.commit = commit;
  /* quarterly: calls, fees, value and money back */
  addStep('week.after', 16, 'private equity funds', () => {
    if (!S || S.over) return;
    const s = st();
    s.mine.forEach(f => {
      if (f.st !== 'live') return;
      const S1 = STY[f.k], yr = yearsIn(f);
      /* value moves every week: the fund's deals and the market */
      if (f.nav > 0) {
        const mu = (S1.r + (f.q - 0.5) * 0.12) / 52, sd = S1.v / Math.sqrt(52);
        f.nav = Math.max(0, f.nav * (1 + mu + S1.beta * ((S.idxRet || 0) - 0.0012) + gauss() * sd));
      }
      if ((S.week - f.w0) % 13 !== 12) return;
      /* management fee */
      const fee = Math.round(f.com * (yr < 5 ? 0.02 : 0.01) / 4);
      f.fee += fee;
      f.nav = Math.max(0, f.nav - fee);
      /* capital calls in the first four years */
      if (yr < 4 && f.called < f.com) {
        const want = Math.min(f.com - f.called, Math.round(f.com * clamp(0.2 + gauss() * 0.08, 0.05, 0.4) / (yr < 1 ? 1 : 1.2)));
        if (S.cash >= want) {
          payMe(want, 'Capital call: ' + f.n);
          f.called += want; f.paid += want; f.nav += want;
        } else {
          f.nav = Math.round(f.nav * 0.5); f.com = f.called; f.miss = S.week;
          info(f.n, 'You missed a capital call', 'The fund asked for ' + money(want) + ' and your account could not pay it. Under the fund rules you lose half your stake and will not be asked again.', 0, 'bad');
        }
      }
      /* money back from year four; the fund winds up after ten years */
      if (yr >= 4 && f.nav > 0) {
        const share = yr >= 10 ? 1 : clamp(0.05 + (yr - 4) * 0.035, 0.05, 0.3);
        let out = Math.round(f.nav * share);
        /* the manager's carried interest: 20% of what comes back above the paid-in money grown by 8% a year */
        const gross = (f.gd || 0) + out;
        const due = Math.max(0, gross - f.paid * Math.pow(1.08, yr)) * 0.2;
        const carry = Math.max(0, Math.min(out, Math.round(due - (f.carry || 0))));
        f.carry = (f.carry || 0) + carry;
        f.gd = gross;
        f.nav -= out;
        out -= carry;
        f.dist += out;
        gainMe(out, 'Distribution: ' + f.n);
        const gain = Math.max(0, f.dist - f.paid) - (f.taxed || 0);
        if (gain > 0) { S.tax.gain = (S.tax.gain || 0) + gain; f.taxed = (f.taxed || 0) + gain; }
      }
      /* the fund winds up after ten years, also when nothing is left */
      if (yr >= 10) { f.st = 'done'; f.nav = 0; info(f.n, 'The fund has closed', 'You paid in ' + money(f.paid) + ' and got back ' + money(f.dist) + ' (' + (f.paid ? (f.dist / f.paid).toFixed(2) : '0') + '×).', 0, f.dist >= f.paid ? 'good' : 'bad'); }
    });
  });
  addStep('netWorth', 40, 'private equity', r => {
    const v = (S.pe56 ? S.pe56.mine : []).filter(f => f.st === 'live').reduce((t, f) => t + f.nav, 0);
    if (v) { r.inv = (r.inv || 0) + v; r.total += v; }
  });
  /* the secondary market: older and better stakes sell closer to their value */
  const disc = f => clamp(0.35 - yearsIn(f) * 0.025 - (f.q - 0.5) * 0.1 + (S.econ && S.econ.dem < 0.97 ? 0.08 : 0), 0.08, 0.45);
  function sell(f) {
    const get = Math.round(f.nav * (1 - disc(f)));
    gainMe(get, 'Sold on the secondary market: ' + f.n);
    const gain = Math.max(0, f.dist + get - f.paid) - (f.taxed || 0);
    if (gain > 0) S.tax.gain = (S.tax.gain || 0) + gain;
    f.dist += get; f.nav = 0; f.st = 'sold';
    return get;
  }
  PE.sell = sell;

  /* ---------- the app ---------- */
  V.titles.pe56 = 'Private equity';
  V.pe56 = function () {
    refresh();
    const s = st(), L = s.mine.filter(f => f.st === 'live'), past = s.mine.filter(f => f.st !== 'live');
    let h = '<div class="card"><h3>Private equity<small>Ten-year funds. Your money is tied up; the best managers beat the stock market.</small></h3>' + row('In funds now', money(L.reduce((t, f) => t + f.nav, 0))) + row('Still to be called', money(L.reduce((t, f) => t + f.com - f.called, 0))) + '</div>';
    if (L.length) h += '<h2 class="sec">Your funds</h2>' + L.map(f => '<div class="card"><div class="bhead"><div><b>' + esc(f.n) + '</b><small>' + STY[f.k].n + ' · year ' + (Math.floor(yearsIn(f)) + 1) + ' of 10</small></div><b>' + mshort(f.nav) + '</b></div>' +
      row('Committed · called', mshort(f.com) + ' · ' + mshort(f.called)) + row('Paid back so far', mshort(f.dist)) + row('Value and money back on paid in', f.paid ? ((f.nav + f.dist) / f.paid).toFixed(2) + '×' : '–') + row('Fees so far', mshort(f.fee)) +
      btn('Sell on the secondary market · about ' + mshort(f.nav * (1 - disc(f))), 'pe56sell', { id: f.id }, 'ghost wide') + '</div>').join('');
    h += '<h2 class="sec">Raising money in ' + wYear(S.week) + '</h2>';
    h += s.offers.length ? s.offers.map(o => '<div class="card"><div class="bhead"><div><b>' + esc(o.n) + '</b><small>' + STY[o.k].n + ' · track record: ' + track(o.seen) + '</small></div>' + (PRO.has('pe') ? '' : PRO.pill) + '</div><span class="tipt">' + esc(STY[o.k].d) + ' From ' + mshort(o.min) + '. 2% a year and 20% above an 8% hurdle.</span>' +
      '<div class="chips">' + [1, 2, 5, 10].map(x => btn(mshort(o.min * x), 'pe56go', { id: o.id, a: o.min * x }, 'chip' + (netWorth().total < o.min * x * 1.5 ? ' cant' : ''))).join('') + '</div></div>').join('') : '<div class="calm">All of this year’s funds are full. New ones raise money next year.</div>';
    if (past.length) h += '<h2 class="sec">Earlier</h2><div class="card">' + past.map(f => row(esc(f.n), (f.paid ? (f.dist / f.paid).toFixed(2) : '0') + '× · ' + (f.st === 'sold' ? 'sold' : 'closed'))).join('') + '</div>';
    return h;
  };
  ACT.pe56go = p => {
    const o = st().offers.find(x => x.id === p.id); if (!o) return;
    confirmThen('Commit ' + money(p.a) + ' to ' + esc(o.n) + '?', 'The fund calls the money over about four years. Missing a call costs half your stake.', 'Commit', () => {
      const r = commit(o, p.a);
      if (r === 'ok') { save(); render(); toast('Committed to ' + o.n + '.'); } else if (r === 'rich') toast('The fund only takes investors whose net worth is well above the commitment.', true); else if (r === 'small') toast('Below the minimum.', true);
    });
  };
  ACT.pe56sell = p => {
    const f = st().mine.find(x => x.id === p.id); if (!f) return;
    confirmThen('Sell your stake in ' + esc(f.n) + '?', 'A buyer pays about ' + money(f.nav * (1 - disc(f))) + ', ' + Math.round(disc(f) * 100) + '% below its value.', 'Sell', () => { const g = sell(f); save(); render(); toast('Sold for ' + mshort(g) + '.'); }, true);
  };
  if (window.PHAPPS) window.PHAPPS.splice(2, 0, ['pe56', 'invest', 'Private equity', 'g']);
})();

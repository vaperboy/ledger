/* ===== Franchise lifecycle (round 24) =====
   You as franchisor: units earn what your own concept earns, pay royalties (or fall behind when they lose money),
   can be terminated by you, renew or leave when their contract ends, and close when they go broke.
   You as franchisee: royalties you cannot pay become arrears, the brand enforces its quality standard,
   the contract ends after its term (renew or go independent), and you can buy yourself out early. */
(function () {
  const r0 = Math.round;
  const termOf = f => f.term || 10;
  /* what the concept earns: the franchisor's own operating margin over recent months, kept within reason for the trade */
  /* the store's own margin is tracked week by week without the franchise money (fees, royalties, support), so
     paying for your franchisees' setup does not make your concept look worse */
  function conceptMargin(co, bd) {
    const f = co.fr || {};
    let own = f.cmE;
    if (own == null) { const H = (co.hist || []).slice(-6), rev = H.reduce((a, x) => a + (x.rev || 0), 0), pr = H.reduce((a, x) => a + (x.profit || 0), 0); own = rev > 0 ? pr / rev : bd.m; }
    return clamp(own, bd.m - 0.04, bd.m + 0.12);
  }
  const frIn = (co, a) => { if (co && co.fr) co.fr.wIn = (co.fr.wIn || 0) + a; };
  const frOut = (co, a) => { if (co && co.fr) co.fr.wOut = (co.fr.wOut || 0) + a; };
  addStep('week.after', 55, 'franchise_lifecycle weekly', () => {
    try {
      S.cos.forEach(co => {
        const f = co.fr;
        if (!f || !f.on) return;
        /* the store's own trading: its sales, its cost of goods and its running costs; franchise money never enters */
        const w = co.lastW || {}, r = w.rev || 0;
        if (r > 0 && co.st === 'open') { const e = (w.cogs || 0) + coWeekCost(co) - (w.cogs || 0) * 0.5; const m = clamp((r - e) / r, -1, 1); f.cmE = f.cmE == null ? m : f.cmE + (m - f.cmE) * 0.06; }
        f.wIn = 0; f.wOut = 0;
      });
    } catch (e) { console.error(e); }
  });
  R24.conceptMargin = conceptMargin;
  addStep('frAccept.before', 10, 'cash before', (co, aid, ph) => { ph.c0 = co.cash; });
  addStep('frAccept.after', 10, 'fee, term and site of a new franchisee', (co, aid, ph) => {
    const r = ph.r, c0 = ph.c0;
    if (r === 'ok') {
      const fee = co.fr.fee || 0; frIn(co, fee); frOut(co, Math.max(0, c0 + fee - co.cash));
      const u = co.fr.units[co.fr.units.length - 1];
      u.end = S.week + (u.term || termOf(co.fr)) * 52;
      u.q = clamp(u.skill + rint(-10, 10), 20, 95);
      u.loc = gauss() * 0.045; /* some sites are simply better than others */
      u.owed = 0; u.late = 0;
    }
  });
  function unitAsk(co, u, kind) {
    const f = co.fr, act = 'fr24';
    const due = u.rev * f.roy;
    const body = kind === 'owed'
      ? u.name + ' (' + cityOf(u.city).name + ') is ' + Math.round(u.late) + ' weeks behind and owes ' + money(u.owed) + ' in royalties. The unit is losing money.'
      : u.name + ' (' + cityOf(u.city).name + ') failed a brand inspection. Poor units drag down the whole brand.';
    addMsg({ kind: 'ask', from: co.name + ' franchise', title: kind === 'owed' ? 'Franchisee behind on royalties' : 'Franchisee below standard', body, co: co.id, act, exp: S.week + 3, tone: 'bad', data: { u: u.id, kind },
      opts: [{ l: kind === 'owed' ? 'Give them time' : 'Warn them', d: kind === 'owed' ? 'Arrears stay on the books; they repay when they can.' : 'They get three months to fix it.', fx: {} },
        { l: 'Terminate the contract', d: 'The unit loses your brand. You chase ' + (kind === 'owed' ? 'the arrears through a lawyer.' : 'nothing, but the brand is protected.'), fx: {} }] });
  }
  /* ending a unit: by you (terminate), by the franchisee (leave at contract end) or by bankruptcy */
  function endUnit(co, u, how) {
    const f = co.fr;
    f.units = f.units.filter(x => x !== u);
    /* a loan still open: a franchisee who leaves pays it back, a bankrupt one cannot */
    if (u.loan && u.loan.bal > 0) {
      const b = Math.round(u.loan.bal);
      if (how === 'bust') { bk(co, 'loss', b); note(u.name + ' went bankrupt owing ' + money(b) + ' on your loan. It is written off.', 'bad', co.id); }
      else { coIn(co, b, null, 'Franchise loan repaid: ' + u.name); frIn(co, b); }
      u.loan = null;
    }
    if (how === 'term') {
      const legal = KC(15000);
      payCo(co, legal, 'oth', 'Franchise termination: lawyer'); frOut(co, legal);
      const rec = u.owed > 0 ? r0(u.owed * rng(0.25, 0.55)) : 0;
      if (rec) { coIn(co, rec, 'rev', 'Arrears recovered from ' + u.name); frIn(co, rec); }
      f.brand = clamp(f.brand + (u.q < 45 ? 0.5 : -1), 0, 100);
      note('Franchise contract with ' + u.name + ' terminated. ' + (u.owed > 0 ? 'Recovered ' + money(rec) + ' of ' + money(u.owed) + ' owed.' : ''), 'n', co.id);
    } else if (how === 'left') {
      f.brand = Math.max(0, f.brand - 1);
      note(u.name + ' did not renew and left the ' + co.name + ' brand.', 'n', co.id);
    } else {
      f.brand = Math.max(0, f.brand - 2);
      note('The franchise unit run by ' + u.name + ' in ' + cityOf(u.city).name + ' went bankrupt. ' + (u.owed > 0 ? money(u.owed) + ' in royalties is lost.' : ''), 'bad', co.id);
    }
    f.ended = (f.ended || 0) + 1;
    if (u.owed > 0) f.lostOwed = (f.lostOwed || 0) + u.owed * (how === 'term' ? 0.6 : 1);
  }
  ACTS.fr24 = (m, idx) => {
    const co = getCo(m.co), f = co && co.fr;
    const u = f && f.units.find(x => x.id === m.data.u);
    if (!u) return true;
    if (idx === 1) endUnit(co, u, 'term');
    else if (m.data.kind === 'qual') u.qwarn = S.week;
    else u.grace = S.week + 12;
    return true;
  };
  window.frWeek = function (co) {
    const f = co.fr;
    if (!f || !f.on) return;
    const bd = BD[co.type];
    frApplicants(co);
    const cm = conceptMargin(co, bd);
    let roy = 0, sup = 0, renew = 0, back = 0, intr = 0;
    f.units.slice().forEach(u => {
      if (u.end == null) { u.end = (u.w0 || S.week) + termOf(f) * 52; u.q = u.q != null ? u.q : clamp(u.skill, 20, 95); u.owed = u.owed || 0; u.late = u.late || 0; }
      if (u.loc == null) u.loc = gauss() * 0.045;
      const city = cityOf(u.city);
      const age = S.week - u.w0;
      const ramp = Math.min(1, 0.35 + age / 40);
      const rev = bd.Dc * bd.ticket * city.dem * (0.35 + f.brand / 100 * 0.6) * (0.6 + u.skill / 160) * seasOf(bd) * ramp * (1 + (S.econ.dem - 1) * 0.8) * (0.9 + 0.2 * Z()) * 0.85;
      /* the unit's own margin before fees: your concept, the brand's pull, how good the operator is; a new unit runs below par */
      /* each unit's own terms where they were agreed one by one (franchise_talks.js), otherwise the franchise's */
      const uRoy = u.roy != null ? u.roy : f.roy, uSupp = u.supp != null ? u.supp : f.supp, uShare = u.share != null ? u.share : f.share;
      const m0 = cm + (f.brand / 100 - 0.35) * 0.06 + (u.skill - 55) * 0.0012 + (uSupp > 0 ? 0.01 : 0) - 0.01 - (1 - ramp) * 0.06 + u.loc + gauss() * 0.01;
      const due = rev * uRoy, fund = rev * f.mkt;
      const prof = rev * m0 - due - fund;
      u.rev = rev; u.prof = prof;
      f.fund = (f.fund || 0) + fund;
      /* royalties: paid in full while the unit makes money; a losing unit pays less and less and the rest becomes arrears */
      let paid = due;
      if (prof < 0) { u.late++; if (u.late > 3) paid = due * clamp(0.95 - u.late * 0.05, 0.15, 0.9); }
      else { u.late = Math.max(0, u.late - 1); if (u.owed > 0) { const x = Math.min(u.owed, prof * 0.5); paid += x; u.owed -= x; } }
      u.owed += Math.max(0, due - Math.min(paid, due));
      roy += paid;
      if (uSupp === 2 || (u.share && uSupp > 0)) { if (prof > 0) roy += prof * uShare; else sup += -prof * uShare; }
      /* a loan from you: interest runs and the instalment is paid every week, like the royalty: a unit stops paying only
         once it has lost money for more than three weeks (u.late), and starts again when it makes money */
      if (u.loan && u.loan.bal > 0) {
        const i = u.loan.bal * u.loan.rate / 52;
        u.loan.bal += i;
        const pay = prof > 0 || u.late <= 3 ? Math.min(u.loan.bal, u.loan.pay) : 0;
        u.loan.bal -= pay;
        back += pay; intr += Math.min(pay, i);
        if (u.loan.bal < 1) u.loan = null;
      }
      u.neg = prof < 0 ? (u.neg || 0) + 1 : Math.max(0, (u.neg || 0) - 1);
      /* the operator's quality drifts with their skill and with whether they can afford to run the place properly */
      u.q = clamp(u.q + (u.skill - u.q) * 0.02 + (prof < 0 ? -0.15 : 0.05), 10, 98);
      if (u.owed > due * 8 && u.late >= 8 && !(u.grace > S.week) && !u.asked) { u.asked = S.week; unitAsk(co, u, 'owed'); }
      if (u.q < 40 && !(u.qwarn > S.week - 13) && !u.qasked) { u.qasked = S.week; unitAsk(co, u, 'qual'); }
      if (u.asked && S.week - u.asked > 13) u.asked = 0;
      if (u.qasked && S.week - u.qasked > 13) u.qasked = 0;
      /* long losses break the operator (with full support you carry them, up to a point) */
      if ((u.neg > 30 && uSupp < 2) || u.neg > 52) { endUnit(co, u, 'bust'); return; }
      /* end of the contract: profitable units mostly renew and pay a renewal fee; struggling ones leave */
      if (S.week >= u.end) {
        if (prof > 0 && u.q >= 45 && chance(0.85)) { u.end = S.week + termOf(f) * 52; renew += r0(f.fee * 0.3); note(u.name + ' renewed the ' + co.name + ' franchise for another ' + termOf(f) + ' years.', 'good', co.id); }
        else endUnit(co, u, 'left');
      }
    });
    if (roy) coIn(co, roy, 'rev', null);
    if (back) { coIn(co, back - intr, null, 'Franchise loans repaid'); coIn(co, intr, 'rev', 'Interest on franchise loans'); }
    if (renew) coIn(co, renew, 'rev', 'Franchise renewal fees');
    if (sup) payCo(co, sup, 'oth', 'Covering franchise-unit losses');
    frIn(co, roy + renew + back); frOut(co, sup);
    const used = (f.fund || 0) * 0.9;
    if (used > 0) { co.aware = Math.min(100, co.aware + Math.sqrt(used) * 0.002); f.fund = 0; }
    const qAvg = f.units.length ? f.units.reduce((a, u) => a + u.q, 0) / f.units.length : 60;
    f.brand = clamp(f.brand + f.units.length * 0.05 + (co.q - 60) * 0.0015 + (qAvg - 55) * 0.002 * Math.min(1, f.units.length / 3) - f.brand * 0.003, 0, 100);
    const mw = masterWeek(co); frIn(co, mw);
    f.income = roy + renew + mw;
  };
  /* unanswered royalty or quality questions: the default is to give time / warn */
  addStep('week.after', 55, 'franchise_lifecycle weekly', () => {
    try { S.inbox.forEach(m => { if (m.act === 'fr24' && m.auto && !m.done24) { m.done24 = 1; ACTS.fr24(m, 0); } }); } catch (e) { console.error(e); }
  });
  /* a franchisor that goes bankrupt takes the brand down with it: the units rebrand and leave */
  addStep('bankrupt.before', 10, 'is this a franchisor', (co, why, ph) => { ph.frHad = co && co.fr && co.fr.on && co.st !== 'bust' && co.st !== 'sold'; });
  addStep('bankrupt.after', 20, 'its franchise units rebrand and leave', (co, why, ph) => {
    { if (ph.frHad && co.st === 'bust') { const n = co.fr.units.length; co.fr.units = []; co.fr.on = 0; co.fr.masters = []; if (n) note(n + ' franchise units of ' + co.name + ' rebrand and go their own way.', 'n'); } }
  });

  /* ---------- you as franchisee ---------- */
  R24.fbMinQ = f => Math.round(Math.min(f.std || 60, 72) - 27);
  const brandOf = co => co.franchise && co.franchise.brandId ? fbBrand(co.franchise.brandId) : null;
  window.franchiseeWeek = function (co, rev) {
    const f = co.franchise;
    if (!f || !f.fran) return;
    if (f.term && f.w0 != null && f.end == null) f.end = f.w0 + f.term * 52;
    const due = rev * (f.roy + f.mkt);
    /* royalties come out of the company account; when there is not enough, the unpaid part is owed to the franchisor */
    const can = Math.max(0, Math.min(due + (f.owed || 0), co.cash));
    if (can > 0) payCo(co, can, 'oth', null);
    f.owed = Math.max(0, (f.owed || 0) + due - can);
    if (f.owed > 0.5) { f.lateW = (f.lateW || 0) + 1; } else f.lateW = 0;
    f.brand = clamp(f.brand + (co.q - 55) * 0.004, 10, 90);
    if (f.brandId) co.aware = Math.max(co.aware, 15 + f.brand * 0.45);
    /* the brand's quality standard */
    /* the brand's minimum: stricter brands demand more, but a new unit gets half a year to get up to speed */
    const minQ = R24.fbMinQ(f);
    if (co.st === 'open' && co.lastW && co.lastW.units > 0 && S.week - (f.w0 || 0) >= 26) f.lowQ = co.q < minQ ? (f.lowQ || 0) + 1 : Math.max(0, (f.lowQ || 0) - 1);
    if (f.lowQ === 8) { note('The franchisor warns ' + co.name + ': quality is well below the brand standard. Fix it within two months or the contract can be terminated.', 'bad', co.id); co.rep -= 2; }
    if (f.lowQ >= 17 && !f.asked) fbAsk(co, 'qual');
    if (f.lateW >= 8 && f.owed > due * 6 && !f.asked) fbAsk(co, 'owed');
    if (f.end != null && S.week >= f.end && !f.asked) fbAsk(co, 'end');
  };
  function fbAsk(co, kind) {
    const f = co.franchise, b = brandOf(co), bn = f.brandName || (b && b.name) || 'The franchisor';
    f.asked = S.week;
    const renewFee = r0((f.fee || 0) * 0.3);
    let title, body, opts;
    if (kind === 'owed') { title = bn + ' demands unpaid royalties'; body = co.name + ' owes ' + money(f.owed) + ' in royalties and marketing fees. Pay now or the franchise contract ends.'; opts = [{ l: 'Pay ' + money(f.owed), d: 'From company cash.', fx: {} }, { l: 'Let the contract end', d: 'You lose the brand. The debt stays as a bill to pay.', fx: {} }]; }
    else if (kind === 'qual') { title = bn + ' terminates for poor quality'; body = 'Quality at ' + co.name + ' has been far below the brand standard for months. Invest in a refit and training, or the contract ends.'; opts = [{ l: 'Refit and retrain · ' + money(KC(30000) * (co.size || 1)), d: 'Quality improves; the warning is withdrawn.', fx: {} }, { l: 'Let the contract end', d: 'You run on as an independent.', fx: {} }]; }
    else { title = 'Your ' + bn + ' contract has ended'; body = 'The ' + (f.term || 10) + '-year franchise agreement for ' + co.name + ' is up. Renew on the same terms, or go independent (new signs, fewer people know the name).'; opts = [{ l: 'Renew · ' + money(renewFee), d: 'Another ' + (f.term || 10) + ' years on the same royalty.', fx: {} }, { l: 'Go independent', d: 'No more royalties. Awareness drops.', fx: {} }]; }
    addMsg({ kind: 'ask', from: bn, title, body, co: co.id, act: 'fb24', data: { kind }, exp: S.week + 3, tone: kind === 'end' ? 'n' : 'bad', opts });
  }
  /* leaving the brand: by choice, at contract end, or terminated by the franchisor */
  function leaveBrand(co, why) {
    const f = co.franchise;
    if (!f) return;
    if (f.owed > 0.5) { co.pay.other = (co.pay.other || 0) + f.owed; }
    const sign = KC(8000) * (co.size || 1);
    payCo(co, sign, 'oth', 'New signs and rebranding');
    co.aware = Math.max(5, co.aware * 0.55);
    co.franchise = null;
    if (co.docs) delete co.docs.fran_op;
    note(co.name + (why === 'term' ? ' lost its franchise contract.' : ' is now independent.') + (f.owed > 0.5 ? ' ' + money(f.owed) + ' in unpaid royalties is still owed.' : ''), why === 'term' ? 'bad' : 'n', co.id);
  }
  R24.leaveBrand = leaveBrand;
  ACTS.fb24 = (m, idx) => {
    const co = getCo(m.co), f = co && co.franchise;
    if (!f) return true;
    f.asked = 0;
    const k = m.data.kind;
    if (k === 'owed') { if (idx === 0) { const x = Math.min(f.owed, Math.max(0, co.cash)); payCo(co, x, 'oth', 'Royalty arrears'); f.owed -= x; f.lateW = 0; if (f.owed > 0.5) leaveBrand(co, 'term'); } else leaveBrand(co, 'term'); }
    else if (k === 'qual') { if (idx === 0) { payCo(co, KC(30000) * (co.size || 1), 'oth', 'Refit and training (franchise standard)'); co.q = Math.min(100, (co.q || 50) + 15); f.lowQ = 0; } else leaveBrand(co, 'term'); }
    else { if (idx === 0) { payCo(co, r0((f.fee || 0) * 0.3), 'oth', 'Franchise renewal fee'); f.end = S.week + (f.term || 10) * 52; } else leaveBrand(co, 'end'); }
    return true;
  };
  /* no answer: arrears and quality end the contract; an expired contract is renewed only if you said so, otherwise you go independent */
  addStep('week.after', 55, 'franchise_lifecycle weekly', () => {
    try { S.inbox.forEach(m => { if (m.act === 'fb24' && m.auto && !m.done24) { m.done24 = 1; const co = getCo(m.co); if (co && co.franchise) ACTS.fb24(m, 1); } }); } catch (e) { console.error(e); }
  });
  /* leave early: you buy out the rest of the contract */
  R24.buyout = function (co) {
    const f = co.franchise;
    if (!f || f.end == null) return 0;
    const yrs = Math.max(0, (f.end - S.week) / 52);
    const yRoy = ((co.bk.y.rev || 0) / Math.max(1, (S.week % 52) || 52) * 52) * (f.roy + f.mkt);
    return r0(Math.max((f.fee || 0) * 0.25 * Math.min(1, yrs / 3), Math.min((f.fee || 0) * 1.5, yRoy * yrs * 0.5)) / 1000) * 1000 + r0(f.owed || 0);
  };
  ACT.fb24leave = p => {
    const co = getCo(p.id);
    if (!co || !co.franchise) return;
    const fee = R24.buyout(co);
    confirmThen('Leave the franchise?', 'You pay ' + money(fee) + ' to buy out the contract (including any royalties you owe), put up new signs, and lose much of the brand awareness. No more royalties after that.', 'Leave', () => {
      if (fee) payCo(co, fee, 'oth', 'Franchise contract buyout');
      co.franchise.owed = 0;
      leaveBrand(co, 'exit');
      save(); render();
    }, true);
  };
  R24.fbCard = function (co) {
    const f = co.franchise;
    if (!f || !f.fran) return '';
    return row('Quality', Math.round(co.q || 0) + ' (brand minimum ' + R24.fbMinQ(f) + ')') + (f.end != null ? row('Contract ends', dateStr(f.end)) : '') + (f.owed > 0.5 ? row('Royalties owed', '<span class="neg">' + money(f.owed) + '</span>') : '') + (f.brandId ? btn('Leave the franchise · buyout ' + money(R24.buyout(co)), 'fb24leave', { id: co.id }, 'chip ghost danger') : '');
  };
  R24.frUnitRow = function (u) {
    return (u.owed > 0.5 ? ' · owes ' + mshort(u.owed) : '') + (u.end ? ' · until ' + (wYear ? wYear(u.end) : '') : '');
  };
  ACT.fr24term = p => {
    const co = getCo(p.id), u = co && co.fr && co.fr.units.find(x => x.id === p.u);
    if (!u) return;
    confirmThen('Terminate ' + esc(u.name) + '?', 'The unit loses your brand and stops paying royalties. A lawyer costs ' + money(KC(15000)) + (u.owed > 0.5 ? ' and may recover part of the ' + money(u.owed) + ' owed.' : '.'), 'Terminate', () => { endUnit(co, u, 'term'); save(); render(); }, true);
  };
})();

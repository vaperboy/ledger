/* ===== Football clubs (round 24): debt you take over, realistic running costs, transfer windows ===== */
(function () {
  const r0 = Math.round, rk = x => Math.round(x / 100000) * 100000;
  /* an existing club carries debt: anywhere from a little to about half its value. You take it over when you buy. */
  R24.clubDebt = function (club) {
    if (club.debt == null) { const h = (fbHash(club.id + ':' + (S.seed || 1)) % 1000) / 1000; club.debt = club.founded ? 0 : rk(club.val * (0.05 + 0.45 * h)); }
    return club.debt;
  };
  addStep('proposeClub', 10, 'football_clubs proposeClub', (club, mult, r) => {
    if (r && r.price) {
      const d = R24.clubDebt(club), eq = Math.max(rk(r.price - d), rk(club.val * 0.1));
      r.msg = r.msg.replace(money(r.price), money(eq)) + (d ? ' On top, you take over ' + money(d) + ' of club debt.' : '');
      r.price = eq; r.debt = d;
    }
  });
  addStep('buyClub.before', 10, 'the club debt you take over', (club, price, ph) => { ph.d = R24.clubDebt(club); });
  addStep('buyClub.after', 10, 'the debt becomes a loan of the club', (club, price, ph) => {
    const co = ph.r, d = ph.d;
    if (co && typeof co === 'object' && d > 0) {
      const l = { id: uid(), kind: 'biz', name: 'Club debt taken over', bal: d, amt0: d, margin: creditMargin() + 0.015, pay: 0, termM: 240, co: co.id, w0: S.week, guar: 0, bank: 0 };
      l.pay = annuity(d, policy() + l.margin, 240);
      S.loans.push(l);
      club.debt = 0;
      note(co.name + ' comes with ' + money(d) + ' of debt, repaid by the club over twenty years. Clubs rarely make money on football alone: plan to put in cash, or sell players.', 'n', co.id);
    }
  });
  /* a club is worth its football value plus cash, minus what it owes */
  addStep('companyValue', 10, 'a club is worth its football value plus cash, minus what it owes', (co, v) => {
    if (co && co.type === 'club' && co.fm && co.st !== 'sold' && co.st !== 'bust') return r0(v - S.loans.filter(l => l.co === co.id).reduce((a, l) => a + l.bal, 0) + (co.fm.book || 0) * 0.8);
  }, true);
  /* ---------- transfer windows ---------- */
  const TIERS = [['Squad player', 0.04, 1.2, 0.006], ['First-team starter', 0.1, 3, 0.015], ['Star signing', 0.25, 7, 0.035]];
  R24.TIERS = TIERS;
  R24.window = function (co) {
    const lg = leagueOf(co.country), sw = S.week - lg.w0;
    return sw >= 0 && sw < 6 ? 'summer' : sw >= 26 && sw < 30 ? 'winter' : null;
  };
  R24.signFee = (co, i) => rk(clubRev(clubOf(co), co.fm) * TIERS[i][1]);
  R24.sign = function (co, i) {
    const fm = co.fm, T = TIERS[i], fee = R24.signFee(co, i);
    if (!R24.window(co)) return 'closed';
    if (co.cash < fee) return 'cash';
    payCo(co, fee, null, 'Transfer fee: ' + T[0].toLowerCase());
    fm.sq = (fm.sq || 0) + T[2];
    fm.xw = (fm.xw || 0) + T[3];
    fm.book = (fm.book || 0) + fee;
    (fm.amort = fm.amort || []).push({ a: fee / 156, left: 156 });
    fm.tin = (fm.tin || 0) + fee;
    return 'ok';
  };
  R24.sell = function (co, bid) {
    const fm = co.fm;
    coIn(co, bid.fee, 'rev', 'Transfer fee received');
    fm.sq = (fm.sq || 0) - bid.pts;
    fm.xw = Math.max(-0.05, (fm.xw || 0) - bid.xw);
    fm.tout = (fm.tout || 0) + bid.fee;
    co.rep = clamp(co.rep - bid.pts * 0.3, 0, 100);
  };
  ACTS.club24 = (m, idx) => {
    const co = getCo(m.co);
    if (!co || !co.fm || m.data.done) return true;
    m.data.done = 1;
    if (idx === 0) { R24.sell(co, m.data); note(co.name + ' sold ' + m.data.who + ' to ' + m.data.to + ' for ' + money(m.data.fee) + '.', 'good', co.id); }
    return true;
  };
  addStep('clubWeek', 10, 'football_clubs clubWeek', (co, bd, ctx, r) => {
    const fm = co.fm, R = clubRev(clubOf(co), fm);
    /* extra wages for players signed (or saved by selling) on top of the wage budget */
    const xw = (fm.xw || 0) * R / 52;
    ctx.cogs += xw;
    /* signings are paid up front and written off over a three-year contract */
    let dep = 0;
    (fm.amort || []).forEach(a => { if (a.left > 0) { dep += a.a; a.left--; } });
    fm.amort = (fm.amort || []).filter(a => a.left > 0);
    if (dep > 0) { bk(co, 'dep', dep); fm.book = Math.max(0, (fm.book || 0) - dep); }
    /* bids for your players arrive while a window is open */
    const win = R24.window(co);
    if (win && chance(win === 'summer' ? 0.15 : 0.08) && !S.inbox.some(m => m.act === 'club24' && m.co === co.id && m.status === 'open')) {
      const f = rng(0.04, 0.15) * (0.6 + (fm.s || 50) / 100), fee = rk(R * f), pts = f * 22, xw2 = f * 0.12;
      const who = personName(), to = pick(FB_A) + ' ' + pick(['FC', 'United', 'City', 'Athletic', 'SK']);
      addMsg({ kind: 'ask', from: co.name, title: to + ' bid ' + money(fee) + ' for ' + who, body: who + ' is one of your ' + (pts > 4 ? 'best players' : 'regular starters') + '. Selling brings cash now but weakens the team (about ' + pts.toFixed(1) + ' strength points) until you replace him.', co: co.id, act: 'club24', exp: S.week + 2, tone: 'n', data: { who, to, fee, pts, xw: xw2 }, opts: [{ l: 'Sell for ' + money(fee), d: 'Cash now, weaker squad.', fx: {} }, { l: 'Keep him', d: 'No change.', fx: {} }] });
    }
  });
  /* contracts run out and players age: what you bought (or lost) fades over a season or two */
  addStep('seasonEnd', 10, 'contracts run out and players age: what you bought (or lost) fades over a season or two', (lg, country, own, r) => {
    (own || []).forEach(co => { if (!co.fm) return; co.fm.sq = (co.fm.sq || 0) * 0.65; co.fm.xw = (co.fm.xw || 0) * 0.65; });
  });
  ACT.club24buy = p => {
    const co = getCo(p.id);
    const fee = R24.signFee(co, p.i);
    confirmThen('Sign a ' + TIERS[p.i][0].toLowerCase() + '?', 'Transfer fee ' + money(fee) + ' now (written off over three years), plus about ' + money(TIERS[p.i][3] * clubRev(clubOf(co), co.fm) / 12) + ' a month in extra wages. The squad gets about ' + TIERS[p.i][2] + ' strength points stronger.', 'Sign', () => { const r = R24.sign(co, p.i); if (r === 'ok') { toast('Signed.'); save(); render(); } else res(r === 'closed' ? 'The transfer window is closed.' : r); }, false);
  };
  R24.clubCard = function (co) {
    const fm = co.fm, win = R24.window(co), lg = leagueOf(co.country), sw = S.week - lg.w0;
    const debt = S.loans.filter(l => l.co === co.id).reduce((a, l) => a + l.bal, 0);
    let h = '<div class="card"><h3>Transfers</h3>' + row('Window', win ? (win === 'summer' ? 'Summer window open' : 'Winter window open') : 'Closed · opens in ' + (sw < 26 ? 26 - sw : 52 - sw) + ' wk') + row('Bought this year / sold', money(fm.tin || 0) + ' / ' + money(fm.tout || 0)) + (debt > 0 ? row('Club debt', money(debt)) : '');
    if (win) h += '<div class="dbtns three3">' + TIERS.map((t, i) => btn(t[0] + ' · ' + mshort(R24.signFee(co, i)), 'club24buy', { id: co.id, i }, i === 1 ? 'primary' : '')).join('') + '</div>';
    h += '<span class="tipt">Clubs bid for your players while a window is open. Selling brings cash and weakens the team; signings cost a fee up front and more wages.</span></div>';
    return h;
  };
  CT.ov = pipeView('CT.ov:2', CT.ov, 2); /* CT.ov: the screen above, then the steps below and in later files */
  addStep('CT.ov:2', 10, 'football_clubs CT.ov', (co, bd, h) => { return bd && bd.fam === 'club' && co.fm ? h + R24.clubCard(co) : h; });
  /* the offer sheet shows the debt that comes with the club */
  ACT.clubbuy = pipeView('ACT.clubbuy', ACT.clubbuy, 1);
  addStep('ACT.clubbuy.around', 10, 'the offer sheet shows the debt that comes with the club', (p, next) => {
    next();
    try { const c = clubsOf(p.k).find(x => x.id === p.c), d = R24.clubDebt(c); if (d && ui.sheet && ui.sheet.html) { ui.sheet.html = ui.sheet.html.replace('A bad offer can end the talks for a year.', 'It owes ' + money(d) + ' that you take over; the amounts below are for the club including its debt, so you pay that much less in cash. A bad offer can end the talks for a year.'); render(); } } catch (e) { console.error(e); }
  });
})();

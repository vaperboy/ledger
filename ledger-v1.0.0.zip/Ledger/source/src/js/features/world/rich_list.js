/* ---- features/world/rich_list.js ---- */
/* ===== Round 57: the rich list (Phone › Stats › Rich list).
   The richest people of your country, and you among them. Wealth by rank falls off roughly as a power law
   (rank^-0.75, as in the Forbes and Kapital lists); the top fortune grows with the size of the economy. The owners of
   the rival groups (features/world/rival_groups.js) are on it at what their group is worth. Your place counts your
   net worth; below the top 100 it is estimated from the same curve. The list remembers where you were last month,
   and tells you when you enter the top 100 and the top 10. ===== */
window.RICH57 = window.RICH57 || {};
(function () {
  const RL = window.RICH57;
  const A = 0.75;
  const top1 = cc => { const c = CO[cc] || CC(); return KC(120e9, cc) * Math.pow(Math.max(0.5, (c.pop || 5) / 5.5), 0.8) * Math.max(0.4, c.wage || 1); };
  const SRC = ['shipping', 'property', 'retail', 'oil and gas', 'software', 'banking', 'fish farming', 'hotels', 'food', 'media', 'industry', 'inheritance', 'investments', 'telecoms', 'construction'];
  const nw = () => { try { return netWorth().total; } catch (e) { return 0; } };
  /* the top 100 of a country, the same people every time for this game */
  function people(cc) {
    const C = CO[cc] || CC(), W1 = top1(cc), L = [];
    for (let i = 1; i <= 100; i++) {
      const R = hrng(S.seed + ':rich57:' + cc + ':' + i);
      L.push({ name: C.first[Math.floor(R() * C.first.length)] + ' ' + C.last[Math.floor(R() * C.last.length)], w: W1 * Math.pow(i, -A) * (0.9 + R() * 0.2), src: SRC[Math.floor(R() * SRC.length)] });
    }
    /* the rival groups' owners, at what their group is worth */
    if (window.R27 && R27.groupsIn) R27.groupsIn(cc).filter(g => g.cc === cc).forEach(g => {
      const v = Math.max(0, g.rev * (g.m || 0.08) * 8 + (g.cash || 0) - (g.debt || 0));
      if (v > 0) L.push({ name: g.owner, w: v, src: g.name, g: g.id });
    });
    return L.sort((a, b) => b.w - a.w).slice(0, 100);
  }
  RL.people = people;
  /* your place: in the top 100, or estimated from the curve below it */
  function rankOf(cc, v) {
    const L = people(cc), i = L.findIndex(p => v >= p.w);
    if (i >= 0) return i + 1;
    if (v <= 0) return null;
    return Math.max(101, Math.round(Math.pow(top1(cc) / v, 1 / A)));
  }
  RL.rankOf = rankOf;
  const fmtRank = r => r == null ? '–' : '#' + String(r).replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
  /* monthly: remember the place, and tell the big moments */
  addStep('week.after', 93, 'the rich list', () => {
    if (!isMonthEnd(S.week) || S.over) return;
    const s = S.rich57 = S.rich57 || { r: null, best: null, top100: 0, top10: 0 };
    const r = rankOf(S.country, nw());
    s.prev = s.r; s.r = r;
    if (r != null) s.best = s.best == null ? r : Math.min(s.best, r);
    if (r != null && r <= 100 && !s.top100) { s.top100 = S.week; addMsg({ kind: 'info', from: 'News', title: 'You are on the rich list', body: 'You are number ' + r + ' among the richest people in ' + CC().name + ', with ' + money(nw()) + '.', tone: 'good', status: 'done', go: { l: 'See the list', a: 'phapp', p: { n: 'stats' } } }); }
    if (r != null && r <= 10 && !s.top10) { s.top10 = S.week; addMsg({ kind: 'info', from: 'News', title: 'Top ten in ' + CC().name, body: 'You are now number ' + r + ' on the rich list.', tone: 'good', status: 'done' }); }
  });

  /* ---------- the page ---------- */
  const U = window.UI;
  if (!U) return;
  const { esc } = U;
  RL.page = function () {
    const cc = S.country, L = people(cc), me = nw(), r = rankOf(cc, me), s = S.rich57 || {};
    const mv = s.prev != null && r != null ? s.prev - r : 0;
    const row = (i, p, mine) => '<div class="lrow' + (mine ? ' hl' : '') + '"><span class="av' + (mine ? ' me27' : '') + '">' + (i <= 999 ? i : '·') + '</span><span class="ctext"><b>' + esc(p.name) + '</b><small>' + esc(mine ? 'You' : p.src) + '</small></span><b class="num">' + mshort(p.w) + '</b></div>';
    let h = '<div class="card dash56"><div class="dh56"><div><span class="lab">You on the rich list of ' + esc(CC().name) + '</span><b class="huge">' + fmtRank(r) + '</b><small class="mo56">' + mshort(Math.max(0, me)) + ' net worth' + (mv ? ' · ' + (mv > 0 ? '▲ ' + mv : '▼ ' + (-mv)) + ' since last month' : '') + (s.best ? ' · best ' + fmtRank(s.best) : '') + '</small></div></div>' +
      (r && r > 100 ? '<span class="tipt">Number 100 has ' + mshort(L[99].w) + '. ' + mshort(Math.max(0, L[99].w - me)) + ' to go.</span>' : '') + '</div>';
    const mine = { name: S.player.name || 'You', w: me, me: 1 }, all = L.slice();
    if (r && r <= 100) all.splice(r - 1, 0, mine);
    const rowI = (p, i) => row(i + 1, p, p.me);
    h += '<h2 class="sec">The top ten</h2><div class="lrows">' + all.slice(0, 10).map(rowI).join('') + '</div>';
    if (r && r > 10 && r <= 100) { const a = Math.max(10, r - 4); h += '<h2 class="sec">Around you</h2><div class="lrows">' + all.slice(a, Math.min(all.length, r + 3)).map((p, j) => rowI(p, a + j)).join('') + '</div>'; }
    else if (!r || r > 100) h += '<h2 class="sec">The way in</h2><div class="lrows">' + all.slice(97, 100).map((p, j) => rowI(p, 97 + j)).join('') + '<div class="lrow hl"><span class="av me27">·</span><span class="ctext"><b>' + esc(mine.name) + '</b><small>You · ' + fmtRank(r) + '</small></span><b class="num">' + mshort(Math.max(0, me)) + '</b></div></div>';
    return h;
  };
})();

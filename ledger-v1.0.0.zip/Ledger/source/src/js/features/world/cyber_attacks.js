/* ===== Round 56: cyber attacks. Every company chooses its IT security (Company › IT security):
   none, basic (updates, antivirus, strong passwords, two-step login), managed (an IT firm watches and patches) or a
   security team (round-the-clock monitoring, tests, an incident plan), plus offline backups and staff training
   (lasts a year). They cost a monthly fee that grows with the company.
   Odds follow the UK Cyber Security Breaches Survey 2025: about 43% of businesses notice an attack in a year, mostly
   phishing; about one in ten of them loses money or data (an outcome), so roughly 8% of small firms a year without
   protection; ransomware hits just over 1% of businesses a year. Larger and more online companies are hit more
   (webshops, finance, agencies, hotels and logistics), small offline trades less. Security cuts the odds:
   basic halves them, managed to a quarter, a team to a tenth; trained staff catch most fake invoices.
   What can happen:
   - a fake invoice or a "CEO" asking for a payment: staff catch it, or the money is gone (cyber insurance covers it)
   - ransomware: the systems are locked and you choose: pay, restore from backups (slow without them), or bring in
     an incident team. The company works at a fraction of its capacity until it is fixed
   - a data leak: tell the customers and the data protection authority now (a fine, some lost trust), or keep quiet
     and hope (if it comes out, the fine and the damage are far larger)
   - a site knocked offline: online sales stop for some days unless the security is managed
   Losses go through the event engine (applyFx, category 'cyber'), so cyber insurance pays them. Replaces the old
   ransomware event (g_cyber). ===== */
window.CY56 = window.CY56 || {};
(function () {
  const Y = window.CY56;
  const LV = [
    ['None', 0, 'Only what came with the computers.'],
    ['Basic', 600, 'Updates, antivirus, strong passwords and two-step login.'],
    ['Managed', 3500, 'An IT firm watches the systems, patches them and helps when something happens.'],
    ['Security team', 18000, 'Monitoring day and night, regular tests and an incident plan.']
  ];
  Y.LV = LV;
  const ODDS = [1, 0.5, 0.25, 0.1];
  Y.ODDS = ODDS;
  const EXPO_T = { webshop: 1.6, webdev: 1.4, mktg: 1.3, law: 1.4, acctfirm: 1.5, staffing: 1.2, estate: 1.2, hotel: 1.3, airline: 1.5, wh3pl: 1.3, courier: 1.1, cardealer: 1.1, foodtruck: 0.4, carclean: 0.5, handy: 0.5, barber: 0.6, farm: 0.5, salmon: 0.7, kiosk: 0.6 };
  const EXPO_F = { fin: 1.6, energy: 1.3, svc: 1, retail: 1, venue: 0.8, project: 0.8, prod: 0.9, logi: 1.1, rent: 0.6 };
  const ONLINE = { webshop: 1, hotel: 1, airline: 1, wh3pl: 1, webdev: 1, mktg: 1, courier: 1, fun: 1, indoorski: 1, skires: 1 };
  const GDPR = { NO: 1, SE: 1, DE: 1, UK: 1, FR: 1, ES: 1, NL: 1, PL: 1, LT: 1, CH: 1, IT: 1, DK: 1, FI: 1, IE: 1 };
  const st = co => (co.cy56 = co.cy56 || { lvl: 0, bk: 0, tr: null, log: [], blocked: 0, by: S.week });
  Y.st = st;
  const heads = co => (co.staff ? co.staff.filter(s => !s.off).length : 0) + (co.mgr ? 1 : 0);
  Y.heads = heads;
  const sizeF = co => Math.pow(Math.max(1, heads(co) / 6), 0.6);
  const expo = co => EXPO_T[co.type] || EXPO_F[(BD[co.type] || {}).fam] || 1;
  const trained = co => { const s = st(co); return s.tr != null && S.week - s.tr < 52; };
  Y.trained = trained;
  const monthly = (co, lvl, bk) => KC(LV[lvl][1], co.country) * sizeF(co) + (bk ? KC(400, co.country) * sizeF(co) : 0);
  Y.monthly = monthly;
  /* the chance of a serious incident in a year */
  function yearOdds(co) {
    const s = st(co);
    const size = Math.sqrt(clamp((heads(co) + 1) / 5, 0.6, 4));
    let p = 0.08 * expo(co) * size * ODDS[s.lvl || 0];
    if (trained(co)) p *= 0.75;
    if (s.target && s.target > S.week) p *= 1.8; /* paid a ransom: on the list of those who pay */
    return clamp(p, 0.002, 0.6);
  }
  Y.yearOdds = yearOdds;
  const log = (co, k, t) => { const s = st(co); s.log.unshift({ w: S.week, k, t }); if (s.log.length > 10) s.log.length = 10; };
  const wkRev = co => Math.max(KC(10000, co.country), (co.lastW && co.lastW.rev) || 0);
  const covered = co => !!(co.ins && co.ins.cyber);

  /* ---------- what happens ---------- */
  function fraud(co) {
    const s = st(co);
    const amt = rnl(clamp(wkRev(co) * rng(0.4, 1.8), KC(15000, co.country), KC(600000, co.country)), 1000);
    const catchP = clamp(0.25 + (trained(co) ? 0.5 : 0) + 0.1 * (s.lvl || 0), 0, 0.95);
    if (chance(catchP)) {
      s.blocked++;
      log(co, 'fraud', 'Fake invoice for ' + money(amt) + ' spotted');
      note('Someone at ' + co.name + ' spotted a fake invoice for ' + money(amt) + ' that looked like it came from a supplier. Nothing was paid.', 'good', co.id);
      return;
    }
    applyFx(co, { loss: amt }, null, { cat: 'cyber', id: 'cy56' });
    log(co, 'fraud', 'Paid a fake invoice: ' + money(amt));
    addMsg({ kind: 'info', from: co.name, title: co.name + ' paid a fake invoice', body: 'An email that looked like it came from a supplier asked us to pay ' + money(amt) + ' to a new bank account. It was a fraud and the money is gone.' + (covered(co) ? ' The cyber insurance covers most of it.' : ' There is no cyber insurance to cover it.') + (trained(co) ? '' : ' Staff training teaches people to check a new bank account by phone.'), co: co.id, tone: 'bad', status: 'done' });
  }
  function ransom(co) {
    const s = st(co), sz = sizeF(co);
    const demand = rnl(clamp(wkRev(co) * rng(1, 3), KC(40000, co.country), KC(5e6, co.country)), 1000);
    const team = rnl(KC(60000, co.country) * sz, 1000);
    addMod(co, 'cap', 0.3, 1);
    log(co, 'ransom', 'Ransomware: systems locked');
    addMsg({
      kind: 'ask', from: co.mgr && S.npcs[co.mgr] ? S.npcs[co.mgr].name : co.name, title: 'Ransomware has locked the systems at ' + co.name,
      body: 'Nothing works: bookings, tills, files and email are encrypted. The attackers want ' + money(demand) + ' to unlock them. ' + (s.bk ? 'We have offline backups, so we can rebuild without them.' : 'We have no offline backups.') + (covered(co) ? ' The cyber insurance covers most of the costs.' : ''),
      co: co.id, act: 'cy56r', data: { co: co.id, demand, team }, exp: S.week + 1, tone: 'bad',
      opts: [
        { l: 'Pay the ransom · ' + money(demand), d: 'Usually works, not always. Those who pay get attacked again more often.', fx: {} },
        { l: s.bk ? 'Restore from the backups' : 'Rebuild without backups', d: s.bk ? 'About a week at reduced capacity.' : 'Weeks of trouble, and some data is lost for good.', fx: {} },
        { l: 'Bring in an incident team · ' + money(team), d: 'Experts clean the systems and get you running fast.', fx: {} }
      ]
    });
  }
  function leak(co) {
    const sz = sizeF(co), f = GDPR[co.country] ? 1 : 0.5;
    const fine = rnl(KC(25000, co.country) * sz * rng(0.6, 1.6) * f * expo(co), 1000);
    const auth = (typeof LOCN !== 'undefined' && LOCN[co.country] && LOCN[co.country].data) || 'the data protection authority';
    log(co, 'leak', 'Customer data leaked');
    addMsg({
      kind: 'ask', from: co.mgr && S.npcs[co.mgr] ? S.npcs[co.mgr].name : co.name, title: 'Customer data has leaked from ' + co.name,
      body: 'Someone got into our systems and copied names, emails and some payment details of our customers. The law says we must tell ' + auth + ' within 72 hours and warn the customers.',
      co: co.id, act: 'cy56l', data: { co: co.id, fine }, exp: S.week + 1, tone: 'bad',
      opts: [
        { l: 'Tell them now', d: 'A fine of about ' + money(fine) + ' and some lost trust.', fx: {} },
        { l: 'Keep it quiet', d: 'Nothing now. If it comes out, the fine is far larger and customers leave.', fx: {} }
      ]
    });
  }
  function down(co) {
    const s = st(co);
    if ((s.lvl || 0) >= 2) { s.blocked++; log(co, 'ddos', 'Attack on the website stopped'); return; }
    addMod(co, 'dem', 0.6, 1);
    log(co, 'ddos', 'Website knocked offline');
    note(co.name + '’s website and online sales were knocked offline by an attack for several days. Managed IT security would have stopped it.', 'bad', co.id);
  }
  Y.hit = (co, k) => ({ fraud, ransom, leak, down })[k](co); /* for tests */
  ACTS.cy56r = (m, idx) => {
    const d = m.data || {}, co = getCo(d.co);
    if (!co) return true;
    const s = st(co);
    if (idx === 0) {
      applyFx(co, { loss: d.demand }, null, { cat: 'cyber', id: 'cy56' });
      s.target = S.week + 52;
      if (chance(0.2)) { addMod(co, 'cap', 0.45, 2); note('The key the attackers sent only unlocked part of the systems at ' + co.name + '. It takes weeks to rebuild the rest.', 'bad', co.id); }
      else note('The ransom was paid and the systems at ' + co.name + ' are unlocked.', 'n', co.id);
    } else if (idx === 1) {
      if (s.bk) { addMod(co, 'cap', 0.65, 1); applyFx(co, { loss: rnl(KC(10000, co.country) * sizeF(co), 1000) }, null, { cat: 'cyber', id: 'cy56' }); note(co.name + ' is rebuilt from the backups. A slow week, nothing lost.', 'n', co.id); }
      else { addMod(co, 'cap', 0.3, 3); co.rep = clamp(co.rep - 3, 0, 100); applyFx(co, { loss: rnl(KC(35000, co.country) * sizeF(co), 1000) }, null, { cat: 'cyber', id: 'cy56' }); note(co.name + ' rebuilds without backups: weeks of trouble, and some customer records are gone for good.', 'bad', co.id); }
    } else {
      applyFx(co, { loss: d.team }, null, { cat: 'cyber', id: 'cy56' });
      addMod(co, 'cap', s.bk ? 0.85 : 0.6, 1);
      note('An incident team cleaned the systems at ' + co.name + '. It is running again.', 'n', co.id);
    }
    return true;
  };
  ACTS.cy56l = (m, idx) => {
    const d = m.data || {}, co = getCo(d.co);
    if (!co) return true;
    if (idx === 0) {
      applyFx(co, { fine: d.fine, rep: -1 }, null, { cat: 'none' });
      addMod(co, 'dem', 0.95, 6);
      note(co.name + ' told its customers and the authority about the leak. A fine of ' + money(d.fine) + '; most customers stay.', 'n', co.id);
    } else st(co).hide = { w: S.week, fine: d.fine };
    return true;
  };

  /* ---------- weekly: costs, attacks, what comes out ---------- */
  addStep('week.after', 66, 'IT security and cyber attacks', () => {
    S.cos.forEach(co => {
      if (co.st !== 'open' || co.type === 'hold' || !BD[co.type]) return;
      const s = st(co);
      const mo = monthly(co, s.lvl || 0, s.bk);
      if (mo > 0) payCo(co, mo * 12 / 52, 'oth', null);
      /* an unanswered attack: the manager, or the safe choice */
      S.inbox.forEach(m => { if ((m.act === 'cy56r' || m.act === 'cy56l') && m.co === co.id && m.status === 'done' && m.pick === -1 && !m.cy56d) { m.cy56d = 1; ACTS[m.act](m, m.act === 'cy56r' ? (s.bk ? 1 : 2) : 0); } });
      /* a leak kept quiet: it may still come out */
      if (s.hide && S.week - s.hide.w < 26 && chance(0.45 / 26)) {
        const fine = s.hide.fine * 4;
        s.hide = null;
        applyFx(co, { fine, rep: -6 }, null, { cat: 'none' });
        addMod(co, 'dem', 0.85, 12);
        addMsg({ kind: 'info', from: 'News', title: co.name + ' hid a data leak', body: 'Journalists found out that ' + co.name + ' kept a leak of customer data quiet. The authority fines it ' + money(fine) + ', and many customers go elsewhere.', co: co.id, tone: 'bad', status: 'done' });
      } else if (s.hide && S.week - s.hide.w >= 26) s.hide = null;
      if (S.week - (co.wOpen != null ? co.wOpen : co.w0 || 0) < 8) return; /* a brand new company is not on anyone's list yet */
      if (!chance(yearOdds(co) / 52)) return;
      const w = [['fraud', 0.5 * (trained(co) ? 0.5 : 1)], ['ransom', 0.15], ['leak', 0.2], ['down', ONLINE[co.type] ? 0.25 : 0.03]];
      const tot = w.reduce((a, x) => a + x[1], 0);
      let r = rng(0, tot), k = 'fraud';
      for (const x of w) { if ((r -= x[1]) <= 0) { k = x[0]; break; } }
      ({ fraud, ransom, leak, down })[k](co);
    });
  });

  /* ---------- the screen: Company › IT security ---------- */
  const U = window.UI;
  if (!U) return;
  const { V, ACT, esc, btn, render, save, toast } = U;
  const P = o => esc(JSON.stringify(o));
  const oneIn = p => p >= 0.5 ? 'about 1 in 2' : 'about 1 in ' + Math.round(1 / p);
  Y.row = function (co) {
    const s = st(co);
    const sub = LV[s.lvl || 0][0] + (s.bk ? ' · backups' : '') + (trained(co) ? ' · trained' : '') + ' · ' + oneIn(yearOdds(co)) + ' a year';
    return '<button class="lrow" data-a="go" data-p="' + P({ n: 'cy56', p: { id: co.id } }) + '"><span class="lic">' + U.svg('shield', 20) + '</span><span class="ctext"><b>IT security</b><small>' + esc(sub) + '</small></span>' + ((s.lvl || 0) === 0 && yearOdds(co) > 0.08 ? '<span class="pill amb">At risk</span>' : '<i>›</i>') + '</button>';
  };
  V.titles.cy56 = 'IT security';
  V.heads = V.heads || {};
  V.heads.cy56 = p => { const co = getCo(p.id); return { t: 'IT security', sub: co ? esc(co.name) : '' }; };
  V.cy56 = function (p) {
    const co = getCo(p.id);
    if (!co) return '<div class="calm">Gone.</div>';
    const s = st(co), yo = yearOdds(co), D = window.DASH56;
    const last = s.log[0];
    const T = D ? [
      D.tile('Serious attack', oneIn(yo), 'a year at this level', null, yo > 0.1 ? 'bad' : yo > 0.04 ? 'warn' : 'good'),
      D.tile('Stopped', s.blocked || 0, 'attacks caught since you started'),
      D.tile('Last incident', last ? dateStr(last.w) : 'None', last ? esc(last.t) : 'so far'),
      D.tile('Backups', s.bk ? 'Offline' : 'None', s.bk ? 'ransomware can be undone' : 'ransomware hurts', null, s.bk ? 'good' : 'warn'),
      D.tile('Training', trained(co) ? 'Done' : 'Not done', trained(co) ? 'until ' + dateStr(s.tr + 52) : 'fake invoices get through', null, trained(co) ? 'good' : 'warn'),
      D.tile('Cyber insurance', covered(co) ? 'Yes' : 'No', covered(co) ? 'pays the losses' : 'every loss is yours', ['cosub', { id: co.id, s: 'ins' }], covered(co) ? '' : 'warn')
    ] : [];
    /* who decides: the chain for all its stores, the manager (features/people/manager_duties.js), or you */
    const MD = window.MD56, ch = MD ? MD.chainRule(co) : null, m = co.mgr && S.npcs[co.mgr], byM = m && MD && mgrDuty(co, 'sec');
    let h = ch ? '<div class="mgrbar"><span>' + esc(ch.name) + ' sets IT security for every store</span>' + btn('Chain rules', 'go', { n: 'chain12', p: { id: ch.id, t: 'rules' } }, 'chip') + '</div>'
      : byM ? '<div class="mgrbar">' + (window.faceAv ? faceAv(m) : '') + '<span><b>' + esc(m.name.split(' ')[0]) + '</b> ' + (s.own ? 'follows your choice' : 'looks after it · picks ' + LV[MD.secNeed(co)][0].toLowerCase()) + '</span>' + (s.own ? btn('Leave it to ' + esc(m.name.split(' ')[0]), 'md56give', { id: co.id, k: 'sec' }, 'chip') : '') + '</div>' : '';
    h += '<div class="card dash56"><div class="dh56"><div><span class="lab">Protection</span><b class="huge">' + LV[s.lvl || 0][0] + '</b><small class="mo56">' + mshort(monthly(co, s.lvl || 0, s.bk)) + ' a month · ' + heads(co) + (heads(co) === 1 ? ' person' : ' people') + ' with a computer or a phone</small></div></div><div class="t56grid">' + T.join('') + '</div></div>';
    h += '<h2 class="sec">Level</h2><div class="optlist56">' + LV.map((l, i) => '<button class="opt' + ((s.lvl || 0) === i ? ' on' : '') + (ch ? ' cant' : '') + '" data-a="cy56set" data-p="' + P({ id: co.id, lvl: i }) + '"><div class="bhead"><b>' + l[0] + '</b><span class="pill">' + (i ? mshort(monthly(co, i, 0)) + '/mo' : 'Free') + '</span></div><small>' + l[2] + ' Serious attacks: ' + oneIn(clamp(yo / ODDS[s.lvl || 0] * ODDS[i], 0.002, 0.6)) + ' a year.</small></button>').join('') + '</div>';
    const tc = rnl(KC(450, co.country) * Math.max(1, heads(co)), 100);
    h += '<h2 class="sec">Backups and training</h2><div class="lrows"><button class="lrow" data-a="cy56bk" data-p="' + P({ id: co.id }) + '"><span class="ctext"><b>Offline backups</b><small>' + mshort(KC(400, co.country) * sizeF(co)) + ' a month · after ransomware you rebuild in days, not weeks</small></span><span class="pill ' + (s.bk ? 'green' : '') + '">' + (s.bk ? 'On' : 'Off') + '</span></button>' +
      '<button class="lrow' + (co.cash < tc && !trained(co) ? ' cant' : '') + '" data-a="cy56tr" data-p="' + P({ id: co.id }) + '"><span class="ctext"><b>Train the staff</b><small>' + (trained(co) ? 'Done ' + dateStr(s.tr) + ', good for a year' : money(tc) + ' once · people learn to spot fake invoices and links') + '</small></span><span class="pill ' + (trained(co) ? 'green' : '') + '">' + (trained(co) ? 'Done' : 'Book') + '</span></button></div>';
    if (s.log.length) h += '<h2 class="sec">What happened</h2><div class="lrows">' + s.log.slice(0, 6).map(x => '<div class="lrow"><span class="ctext"><b>' + esc(x.t) + '</b><small>' + dateStr(x.w) + '</small></span></div>').join('') + '</div>';
    return h;
  };
  /* a level you pick yourself stands: the manager keeps it until you leave it to them again */
  ACT.cy56set = p => {
    const co = getCo(p.id); if (!co) return;
    const ch = window.MD56 ? MD56.chainRule(co) : null;
    if (ch) { toast(ch.name + ' sets IT security for every store. Change it in the chain’s rules.', true); return; }
    const s = st(co); s.lvl = +p.lvl; if (co.mgr) s.own = 1;
    save(); render(); toast('IT security: ' + LV[+p.lvl][0].toLowerCase() + '.');
  };
  ACT.cy56bk = p => { const co = getCo(p.id); if (!co) return; if (window.MD56 && MD56.chainRule(co)) { toast('The chain decides on backups for every store.', true); return; } const s = st(co); s.bk = s.bk ? 0 : 1; if (co.mgr) s.own = 1; save(); render(); };
  ACT.cy56tr = p => {
    const co = getCo(p.id);
    if (!co || trained(co)) return;
    const tc = rnl(KC(450, co.country) * Math.max(1, heads(co)), 100);
    if (co.cash < tc) { toast('Not enough cash in ' + co.name + '.', true); return; }
    payCo(co, tc, 'oth', 'Security training');
    st(co).tr = S.week;
    save(); render(); toast('The team is trained for a year.');
  };
})();

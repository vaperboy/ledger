/* ===== Round 56: snow. A ski resort (engine/businesses/venues_retail.js skires) lives on its season and its snow:
   - only where there are mountains with snow; an indoor ski hall (indoorski) works anywhere
   - the season follows the hemisphere (December to April in the north, June to September in Australia)
   - every season draws its own snow around the country's reliability (the Alps and Scandinavia are dependable,
     Scotland and Australia are not); a snowmaking system keeps a poor season from being a lost one
   - lift operators, instructors and kitchen staff are hired for the season and come back each winter; the snow
     crew stays all year
   - with summer lifts (downhill biking and hiking) a little of the summer pays too
   An indoor hall pays a lot of power to stay cold; its bill moves with the power price (S.econ.power). ===== */
window.SKI56 = window.SKI56 || {};
(function () {
  const SK = window.SKI56;
  /* how reliable the natural snow is, by country (0 to 1); no entry: no ski resorts */
  const REL = { NO: 0.95, SE: 0.93, CH: 0.9, FR: 0.85, JP: 0.92, CA: 0.93, US: 0.85, KR: 0.78, DE: 0.72, PL: 0.7, ES: 0.62, AU: 0.55, UK: 0.35, IT: 0.85, FI: 0.92 };
  const SOUTH = { AU: 1 };
  SK.REL = REL;
  /* the countries without ski mountains say so when you try to start one */
  BANNED.skires = BANNED.skires || {};
  ['NL', 'LT', 'BR', 'MX', 'AE', 'DK', 'IE', 'SG'].forEach(cc => { BANNED.skires[cc] = 'There are no ski mountains with snow here. An indoor ski hall works anywhere.'; });
  const seasonMonths = cc => (SOUTH[cc] ? [6, 7, 8, 9] : [12, 1, 2, 3, 4]);
  SK.seasonMonths = seasonMonths;
  const mon = () => wMonth(S.week) + 1;
  const inSeason = co => seasonMonths(co.country).indexOf(mon()) >= 0 || (SOUTH[co.country] ? mon() === 5 || mon() === 10 : mon() === 11);
  /* this season's snow: drawn when the season begins */
  function snowOf(co) {
    const y = wYear(S.week) - (SOUTH[co.country] ? 0 : (mon() <= 6 ? 1 : 0));
    const s = co.snow56;
    if (s && s.y === y) return s.f;
    const R = hrng(S.seed + ':snow:' + co.country + ':' + co.city + ':' + y);
    const rel = REL[co.country] || 0.5;
    let f = clamp(rel + (R() + R() + R() - 1.5) * 0.25, 0.08, 1.15);
    const made = co.eq && typeof eqN === 'function' ? eqN(co, (BD.skires.eq.find(e => e.id === 'snowm'))) >= 1 : false;
    if (made) f = Math.max(f, 0.78);
    co.snow56 = { y, f, made: made ? 1 : 0 };
    if (co.st === 'open') addMsg({ kind: 'info', from: co.name, title: f >= 0.9 ? 'A great snow year at ' + co.name : f >= 0.65 ? 'A normal snow year at ' + co.name : 'Poor snow at ' + co.name, body: f >= 0.9 ? 'Plenty of natural snow: the slopes open early and the season looks long.' : f >= 0.65 ? 'Enough snow for most of the season.' + (made ? ' The snow guns fill the gaps.' : '') : 'Little natural snow this winter. ' + (made ? 'The snowmaking keeps the main slopes open, at a cost in power.' : 'Without snowmaking, some slopes stay closed and the season is short.'), co: co.id, tone: f >= 0.65 ? 'good' : 'bad', status: 'done' });
    return f;
  }
  SK.snowOf = snowOf;
  addStep('demand', 92, 'snow and the hemisphere for ski resorts', (co, bd, r) => {
    if (!co || !r || !(r.D >= 0)) return;
    if (co.type === 'skires') {
      const m = wMonth(S.week);
      if (SOUTH[co.country]) r.D *= SEAS.skiS[m] / Math.max(0.001, SEAS.ski[m]);
      if (inSeason(co)) r.D *= snowOf(co);
      else if ((co.knob.summer || 0) === 1) r.D += (bd.Dc || 0) * 0.12;
      if (r.parts) r.parts.snow56 = co.snow56 ? co.snow56.f : 1;
    } else if (co.type === 'indoorski') {
      /* busier where and when there is no snow outside */
      const out = REL[co.country] != null && seasonMonths(co.country).indexOf(wMonth(S.week) + 1) >= 0 ? 0.85 : 1.1;
      r.D *= out * (co.country === 'AE' ? 1.25 : 1);
    }
  }, true);
  /* the lifts and the seasonal crew are sized for the season: full capacity in winter, a little in summer */
  addStep('capacity', 75, 'ski resorts run at full lift capacity in the season', (co, bd, r) => {
    if (!co || co.type !== 'skires' || !r || !r.cap) return;
    r.cap *= inSeason(co) ? 2.1 : (co.knob.summer || 0) === 1 ? 0.35 : 0.05;
  }, true);
  /* seasonal staff: a ski resort hires lift operators, instructors, cashiers and cooks for the season */
  addStep('week.after', 44, 'ski resort staff work the season', () => {
    S.cos.forEach(co => {
      if (co.type !== 'skires' || co.st === 'sold' || co.st === 'bust') return;
      const ms = seasonMonths(co.country).concat(SOUTH[co.country] ? [5, 10] : [11]);
      let n = 0;
      co.staff.forEach(s => { if (!s.seas && s.role !== 'snowtech') { s.seas = ms.slice(); n++; } });
      if (n && !co.ski56n) { co.ski56n = 1; note(co.name + ': lift operators, instructors and kitchen staff are hired for the season and come back each winter. The snow crew works all year.', 'n', co.id); }
    });
  });
  /* snowmaking and an indoor hall use a lot of power; the bill follows the power price */
  addStep('week.after', 45, 'power for snow', () => {
    S.cos.forEach(co => {
      if (co.st !== 'open') return;
      const pw = (S.econ && S.econ.power) || 1;
      /* the hall's normal power bill is in its running costs; dearer power costs more, cheaper power saves */
      if (co.type === 'indoorski') { const x = Math.round(KC(95000, co.country) * (pw - 1)); if (x > 0) payCo(co, x, 'rent', 'Power for the cooling plant'); else if (x < 0) coIn(co, -x, null, 'Cheaper power for the cooling plant'); }
      else if (co.type === 'skires' && inSeason(co) && co.snow56 && co.snow56.made && co.snow56.f < 0.95) payCo(co, Math.round(KC(30000, co.country) * pw * (1.2 - co.snow56.f)), 'rent', 'Power for snowmaking');
    });
  });
})();

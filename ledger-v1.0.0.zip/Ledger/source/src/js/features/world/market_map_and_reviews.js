/* ===== Round 26: the Market map, market analysts you hire per company, and reviews of you and your rivals.
   Shares are worked out from sales: your own weekly sales against what each rival sells in the same market
   (banks, insurers and funds against the whole country). What you SEE depends on who looks for you:
     no analyst          -> only your own guess, in words
     HQ data analyst     -> ranges, sharper with experience
     market analyst      -> close numbers for that company's market, history, and a report every month ===== */
window.R26 = window.R26 || {};
(function () {
  const R26 = window.R26;
  const U = window.UI, { spark, toast, save, render, svg, row } = U;
  const P = o => esc(JSON.stringify(o));
  const pillp = (t, c) => '<span class="pill ' + (c || '') + '">' + t + '</span>';
  const LOCAL = { svc: 1, venue: 1, retail: 1, project: 1, prod: 1, logi: 1 };
  const FIN = { bank: ['Bank deposits', 'deposits', 450000], insco: ['Insurance', 'premiums', 14000], fund: ['Fund assets', 'fund assets', 300000] };
  const COLS = ['var(--amber, #f2a93b)', 'var(--blue, #4c8dff)', 'var(--green, #39c07a)', 'var(--red, #e5534b)', '#a77bf3', '#3cc4c9'];
  const hv = (a, b) => hrng(S.seed + ':26:' + a + ':' + b)();
  const MI = () => monthIdx(S.week);
  const ini = n => String(n || '?').replace(/[^\p{L}0-9 ]/gu, ' ').trim().split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase() || '?';
  const barH = (p, c, fuzzy) => '<div class="bar"' + (fuzzy ? ' style="opacity:.55"' : '') + '><i style="width:' + Math.max(fuzzy ? 8 : 2, Math.min(100, p)) + '%;background:' + (fuzzy ? 'repeating-linear-gradient(90deg,' + c + ' 0 6px,transparent 6px 10px)' : c) + '"></i></div>';
  const sumF = (a, f) => a.reduce((t, x) => t + (f(x) || 0), 0);

  /* ---------- the new role ---------- */
  ROLES.mktan = ['Market analyst', 62000];
  R26.ROLE = 'mktan';

  /* ---------- sales, kept week by week ---------- */
  function annRev(co) {
    const L = co.rv26 || [];
    if (L.length >= 2) return sumF(L, x => x) / L.length * 52;
    const h = (co.hist || []).slice(-3);
    if (h.length) return sumF(h, x => x.rev) / h.length * 12;
    return (co.lastW ? co.lastW.rev || 0 : 0) * 52;
  }
  R26.annRev = annRev;
  /* what a rival sells in a year: the same formula the rival screen has always used, so the numbers agree */
  function rivRev(co, r) {
    const bd = BD[co.type];
    return (bd.Dc || 1) * bd.ticket * cityOf(co.city).dem * r.size * 0.9 * 52;
  }
  R26.rivRev = rivRev;
  function finSize(co) {
    const fm = co.fm || {};
    if (co.type === 'bank') return fm.dep || 0;
    if (co.type === 'fund') return fm.aum || 0;
    return annRev(co);
  }
  function natTotal(type, cc) {
    const C = CO[cc] || CC();
    return Math.max(1, (C.pop || 5) * 1e6 * FIN[type][2] * Math.pow(C.mkt || 1, 2) * (C.pl || 1));
  }

  /* ---------- markets you are in ---------- */
  function markets() {
    const by = {}, list = [];
    S.cos.forEach(co => {
      if (co.st !== 'open') return;
      const bd = BD[co.type];
      if (!bd) return;
      let k, kind;
      if (LOCAL[bd.fam] && bd.Dc) { k = mkKey(co); kind = 'local'; }
      else if (FIN[co.type]) { k = 'fin|' + co.type + '|' + co.country; kind = 'fin'; }
      else return;
      let m = by[k];
      if (!m) { m = by[k] = { k, kind, type: co.type, city: co.city, country: co.country, cos: [] }; list.push(m); }
      m.cos.push(co);
    });
    return list;
  }
  R26.markets = markets;
  const findMk = k => markets().find(m => m.k === k);
  const mkOfCo = co => markets().find(m => m.cos.indexOf(co) >= 0);
  R26.mkOfCo = mkOfCo;
  function label(m, many) {
    if (m.kind === 'fin') return FIN[m.type][0];
    const cities = many == null ? markets().filter(x => x.type === m.type).length > 1 : many;
    return BD[m.type].n + (cities ? ' · ' + cityOf(m.city).name : '');
  }
  /* national players for banks, insurers and funds: a few big names, the same every time */
  function finRivals(m, my, tot) {
    const C = CO[m.country] || CC();
    const out = [], rest = Math.max(0, 1 - my / tot);
    const base = [0.31, 0.21, 0.14, 0.09];
    for (let i = 0; i < 4; i++) {
      const R = hrng(S.seed + ':26f:' + m.type + ':' + m.country + ':' + i);
      /* a clean root: no trade words, no names of real banks or insurers, a different one for each player */
      const cities = C.cities.filter(c => c.id !== 'small');
      let root = '';
      for (let g = 0; g < 10 && !root; g++) {
        const nR = hrng(S.seed + ':26n:' + m.type + ':' + m.country + ':' + i + ':' + g);
        const save = S.rs; S.rs = Math.floor(nR() * 1e9) | 0;
        let nm = '';
        try { nm = rivalName(BD[m.type], cities[Math.floor(nR() * cities.length)].id, m.country); } catch (e) { }
        S.rs = save;
        const w = nm.split(/\s+/).filter(x => x.indexOf('-') < 0 && x.indexOf('.') < 0 && /^\p{Lu}/u.test(x) && x.length >= 3 && !FINSTOP.test(x))[0];
        if (w && !FINREAL.test(w) && !cities.some(c => c.name === w) && !out.some(o => o.root === w)) root = w;
      }
      const wd = (FINW[m.country] || FINW.US)[m.type === 'bank' ? 0 : m.type === 'insco' ? 1 : 2];
      if (!root) root = (C.name.split(/\s+/).pop()) + ' ' + ['Union', 'Mutual', 'Central', 'United'][i];
      const sh = base[i] * (0.8 + R() * 0.4) * rest;
      out.push({ fin: 1, id: 'f' + m.type + m.country + i, root, name: root + ' ' + wd, share: sh, rev: sh * tot });
    }
    return out;
  }
  const FINSTOP = /^(kapit|capit|financ|finanz|finans|finanse|invest|inwest|inver|patrim|gesti|gestor|cr[eé]dit|asset|wealth|advis|fiduc|secur|insur|assur|verzek|versich|beheer|verm[oö]g|forvalt|förvalt|valdym|powiern|fundus|fond|bank|banc|banq|trust|partner|holding|group|eiendom|fastig|immob|verwalt|draud|seguro|ubezp|forsikr|försäk|llp$|pty$|ltd$|plc$|inc|llc$|as$|asa$|ab$|uab$|gmbh$|ag$|sa$|bv$|nv$|kk$|co\.?$|corp)/i;
  /* names too close to real banks and insurers are never used as a root */
  const FINREAL = /^(royal|national|first|citizens|commonwealth|vanguard|shinsei|mirae|fuji|sumitomo|mitsui|mizuho|asahi|nippon|hana|shinhan|woori|kookmin|itau|ita[uú]|bradesco|santander|caixa|nordea|danske|handels|swed|seb|dnb|storebrand|gjensidige|allianz|axa|generali|aviva|prudential|chase|wells|citi|barclays|lloyds|natwest|hsbc|ing|rabo|abn|commerz|deutsche|sparkasse|volks|bnp|soci[eé]t[eé]|cr[eé]dit|desjardins|scotia|westpac|anz|macquarie|meridian|jeil|sakura|dongyang|daehan|kb|nh|ibk|resona|shizuoka|chiba|busan|daegu|kyobo|samsung|hanwha|meritz|tokio|sompo|aflac|metlife|nationwide|progressive|allstate|geico|travelers|sun|manulife|great|zurich|ergo|ageas|achmea|nn|aegon|pzu|warta|mapfre|bbva|caixabank|sabadell|bankinter|sparbanken|lansforsakringar|folksam|if|tryg|fremtind|eika|sparebank|luminor|citadele|siauliu|swedbank)$/i;
  const FINW = {
    NO: ['Bank', 'Forsikring', 'Forvaltning'], SE: ['Bank', 'Försäkring', 'Fonder'], PL: ['Bank', 'Ubezpieczenia', 'Fundusze'], LT: ['Bankas', 'Draudimas', 'Fondai'],
    DE: ['Bank', 'Versicherung', 'Invest'], UK: ['Bank', 'Insurance', 'Asset Management'], FR: ['Banque', 'Assurances', 'Gestion'], ES: ['Banco', 'Seguros', 'Gestión'],
    NL: ['Bank', 'Verzekeringen', 'Beleggingen'], US: ['Bank', 'Insurance', 'Asset Management'], CA: ['Bank', 'Insurance', 'Asset Management'], AU: ['Bank', 'Insurance', 'Asset Management'],
    JP: ['Bank', 'Insurance', 'Asset Management'], KR: ['Bank', 'Insurance', 'Asset Management'], BR: ['Banco', 'Seguros', 'Gestora'],
    CH: ['Bank', 'Versicherungen', 'Vermögensverwaltung'], MX: ['Banco', 'Seguros', 'Inversiones'], AE: ['Bank', 'Insurance', 'Capital'],
    IT: ['Banca', 'Assicurazioni', 'Gestioni'], DK: ['Bank', 'Forsikring', 'Kapitalforvaltning'], FI: ['Pankki', 'Vakuutus', 'Varainhoito'], IE: ['Bank', 'Insurance', 'Asset Management'], SG: ['Bank', 'Insurance', 'Capital']
  };
  const finCache = {};
  /* the true picture of one market */
  function truthOf(m) {
    if (m.kind === 'local') {
      const co = m.cos[0];
      let rs = [];
      try { rs = rivalsOf(co) || []; } catch (e) { }
      const my = sumF(m.cos, annRev);
      const rv = rs.map(r => ({ r, id: r.id, name: r.name, rev: rivRev(co, r) }));
      const tot = my + sumF(rv, x => x.rev);
      rv.forEach(x => { x.share = tot > 0 ? x.rev / tot : 0; });
      return { my, tot, share: tot > 0 ? my / tot : 0, riv: rv.sort((a, b) => b.rev - a.rev), co };
    }
    const tot = natTotal(m.type, m.country), my = Math.min(tot * 0.95, sumF(m.cos, finSize));
    const ck = m.k + ':' + S.week;
    const riv = finCache[ck] || (finCache[ck] = finRivals(m, my, tot));
    return { my, tot, share: my / tot, riv, co: m.cos[0] };
  }
  R26.truthOf = truthOf;
  /* a rival's share of its market, by sales (used by the rival screen too) */
  R26.rivShare = function (co, r) {
    const m = mkOfCo(co);
    if (!m) return null;
    const t = truthOf(m), x = t.riv.find(y => y.id === r.id);
    return x ? x.share : null;
  };

  /* ---------- who is looking for you ---------- */
  function mktanOf(co) {
    const s = co && co.staff && co.staff.find(x => x.role === 'mktan');
    if (!s) return null;
    const n = S.npcs[s.id];
    return { t: 2, id: s.id, name: n ? n.name : 'Your market analyst', s: clamp(staffSkill(s) / 100, 0.2, 0.98), co };
  }
  R26.mktanOf = mktanOf;
  function know(m) {
    for (const co of m.cos) { const a = mktanOf(co); if (a) return a; }
    const an = R7.anaInfo && R7.anaInfo();
    if (an) return { t: 1, id: an.id, name: an.name, s: an.s };
    return { t: 0, id: 'me' };
  }
  R26.know = know;
  /* an estimate of a share (0..1) as the person looking at it sees it this month */
  function est(v, key, K) {
    const a = hv(key + ':' + MI(), K.id), b = hv(key + 'b:' + MI(), K.id);
    if (K.t === 2) {
      const c = v * (1 + (a - 0.5) * 0.06 * (1 - K.s));
      const w = Math.max(0.002, v * (0.015 + (1 - K.s) * 0.05));
      return { t: 2, c, lo: Math.max(0, c - w), hi: Math.min(1, c + w) };
    }
    if (K.t === 1) {
      let w, c;
      const u = Math.min(0.01, v * 0.3 + 0.0004); /* a point of slack, less for very small shares */
      if (K.s >= 0.65) { w = v * (0.06 + (1 - K.s) * 0.12) + u; c = v * (1 + (a - 0.5) * 0.05); }
      else if (b < 0.5) { w = v * 0.08 + u; c = v * (1 + (a - 0.5) * 0.28); }
      else { w = v * 0.55 + u * 4; c = v; }
      return { t: 1, c, lo: Math.max(0, c - w / 2), hi: Math.min(1, c + w / 2) };
    }
    return { t: 0, c: clamp(v * (0.6 + a * 0.8), 0, 1) };
  }
  R26.est = est;
  const pcS = x => x < 0.001 ? 'under 0.1%' : x < 0.1 ? (Math.round(x * 1000) / 10).toFixed(1).replace(/\.0$/, '') + '%' : Math.round(x * 100) + '%';
  const pcR = (lo, hi) => { const f = x => x < 0.1 ? (Math.round(x * 1000) / 10).toFixed(1).replace(/\.0$/, '') : String(Math.round(x * 100)); return f(lo) === f(hi) ? f(lo) + '%' : f(lo) + '–' + f(hi) + '%'; };
  const guessW = g => g < 0.04 ? 'A tiny slice' : g < 0.1 ? 'A small slice' : g < 0.2 ? 'A fair slice' : g < 0.35 ? 'One of the big ones' : 'The biggest, I think';
  function shTxt(e) { return e.t === 2 ? pcS(e.c) : e.t === 1 ? pcR(e.lo, e.hi) : guessW(e.c); }
  R26.shTxt = shTxt;
  const sizeVs = (rev, my) => my <= 0 ? 'Bigger than you' : rev > my * 1.3 ? 'Bigger than you' : rev < my * 0.75 ? 'Smaller than you' : 'About your size';
  /* a money amount as seen: exact-ish, a range, or nothing */
  function amtTxt(v, key, K) {
    if (K.t === 0) return null;
    const a = hv(key + ':' + MI(), K.id), b = hv(key + 'b:' + MI(), K.id);
    if (K.t === 2) return 'about ' + mshort(v * (1 + (a - 0.5) * 0.06 * (1 - K.s)));
    let w, c;
    if (K.s >= 0.65) { w = 0.08 + (1 - K.s) * 0.15; c = v * (1 + (a - 0.5) * 0.05); }
    else if (b < 0.5) { w = 0.1; c = v * (1 + (a - 0.5) * 0.28); }
    else { w = 0.6; c = v; }
    return mshort(c * (1 - w / 2)) + '–' + mshort(c * (1 + w / 2));
  }

  /* ---------- a rival's mood, for the pills ---------- */
  function rivMood(co, r) {
    if (co && co.flags && co.flags.pw && co.flags.pw.rid === r.id) return ['Price war', 'red', 'in a price war with you'];
    if (r.camp16 && S.week < r.camp16.end) return [r.camp16.pct + '% off', 'amb', 'running ' + r.camp16.pct + '% off'];
    if (r.listed) return ['For sale', 'grn', 'open to offers'];
    if (r.mkt16) return ['Campaign', 'blue', 'pushing marketing'];
    const m = S.mk[mkKey(co)];
    if (window.R18 && r.pm16 != null && m && m.pi) {
      const p = R18.effP(r);
      if (p < m.pi - 0.06) return ['Cheap', 'amb', 'cutting prices'];
      if (p > m.pi + 0.08) return ['Premium', '', 'charging more'];
    }
    if (r.hold16) return ['Holding prices', '', 'holding last year\'s prices'];
    return ['Stable', '', ''];
  }
  R26.rivMood = rivMood;

  /* ---------- history: one point a month per market, and weekly sales per company ---------- */
  function snap() {
    S.ms26 = S.ms26 || {};
    markets().forEach(m => {
      const t = truthOf(m);
      const L = S.ms26[m.k] = S.ms26[m.k] || [];
      if (L.length && L[L.length - 1].m === MI()) L.pop();
      L.push({ m: MI(), s: Math.round(t.share * 10000) / 10000, tot: Math.round(t.tot) });
      if (L.length > 24) L.splice(0, L.length - 24);
    });
  }
  R26.snap = snap;
  const histOf = k => (S.ms26 && S.ms26[k]) || [];

  /* ---------- the monthly market report ---------- */
  function reportLines(m, K, short) {
    const t = truthOf(m), co = m.cos[0], L = histOf(m.k);
    const prev = L.length >= 2 ? L[L.length - 2] : null, q = L.length >= 4 ? L[L.length - 4] : null;
    const e = est(t.share, 'my' + m.k, K), out = [];
    const what = m.kind === 'fin' ? FIN[m.type][1] + ' in ' + (CO[m.country] || CC()).name : BD[m.type].n.toLowerCase() + ' sales in ' + cityOf(m.city).name;
    let s1 = (m.cos.length > 1 ? 'Our share of ' : 'Our share of ') + what + ' is ' + (K.t === 2 ? 'about ' : '') + shTxt(e);
    if (prev && K.t === 2) {
      const d = (t.share - prev.s) * 100;
      s1 += Math.abs(d) < 0.15 ? ', about the same as last month' : ', ' + (d > 0 ? 'up ' : 'down ') + (Math.abs(d) < 1 ? Math.abs(d).toFixed(1) : Math.round(Math.abs(d))) + (Math.abs(d) >= 0.95 && Math.abs(d) < 1.5 ? ' point' : ' points') + ' on last month';
    }
    out.push(s1 + '.');
    if (short) return out;
    const tt = amtTxt(t.tot, 'tot' + m.k, K);
    if (tt) out.push('The whole market ' + (m.kind === 'fin' ? 'holds ' : 'sells ') + tt + (m.kind === 'fin' ? '' : ' a year') + (q && q.tot > 0 && K.t === 2 ? (Math.abs(t.tot / q.tot - 1) < 0.005 ? ', flat over three months' : ', ' + (t.tot >= q.tot ? 'up ' : 'down ') + Math.max(1, Math.round(Math.abs(t.tot / q.tot - 1) * 100)) + '% in three months') : '') + '.');
    const big = t.riv[0];
    if (big) {
      const be = est(big.share, 'rv' + big.id, K);
      const md = big.r ? rivMood(co, big.r) : null;
      out.push('Biggest rival: ' + big.name + ' with ' + shTxt(be) + (md && md[2] ? ', ' + md[2] : '') + '.');
    }
    t.riv.slice(1).forEach(x => { if (!x.r) return; const md = rivMood(co, x.r); if (md[0] !== 'Stable' && md[2]) out.push(x.name + ' is ' + md[2] + '.'); });
    if (m.kind === 'local') {
      const mk = S.mk[mkKey(co)];
      if (mk && mk.pi) {
        const my = priceMult(co) / (co.ig || 1), d = mk.pi / my - 1;
        out.push(Math.abs(d) < 0.03 ? 'Rivals charge about what we do.' : 'Rivals charge about ' + Math.round(Math.abs(d) * 100) + '% ' + (d < 0 ? 'less' : 'more') + ' than we do.');
      }
    }
    if (L.length >= 3 && K.t === 2) {
      const a = L[L.length - 3].s, b = L[L.length - 2].s, c = t.share;
      if (c < b - 0.003 && b < a - 0.003) out.push('Two months of lost ground in a row. Worth a look at prices, marketing and reviews.');
      else if (c > b + 0.003 && b > a + 0.003) out.push('Two months of growth in a row.');
    }
    return out;
  }
  R26.reportLines = reportLines;
  function sendReport(m, K) {
    const co = K.co || m.cos[0];
    const lines = reportLines(m, K);
    const title = 'Market report: ' + label(m, true) + ' (' + monthStr(S.week - 1) + ')';
    co.mr26 = co.mr26 || [];
    co.mr26.unshift({ w: S.week, k: m.k, title, lines, by: K.name });
    if (co.mr26.length > 12) co.mr26.length = 12;
    addMsg({ kind: 'info', from: K.name, role: 'Market analyst', title, body: lines.join(' '), co: co.id, tone: 'n', status: 'done', go: { l: 'Market map', a: 'go', p: { n: 'mktdetail', p: { k: m.k } } } });
  }
  R26.sendReport = sendReport;
  /* the HQ analyst sends a short overview each quarter for the markets no market analyst covers */
  function hqOverview() {
    const an = R7.anaInfo && R7.anaInfo();
    if (!an) return;
    const L = markets().filter(m => know(m).t === 1);
    if (!L.length) return;
    const K = { t: 1, id: an.id, name: an.name, s: an.s };
    const many = L.length > 1;
    const body = L.map(m => label(m) + ': ' + shTxt(est(truthOf(m).share, 'my' + m.k, K))).join('. ') + '. ' + (an.s >= 0.65 ? 'These ranges should be close.' : 'Some of these are rough; a market analyst in a company gives exact numbers for its market.');
    addMsg({ kind: 'info', from: an.name, role: 'Data analyst', title: 'Market overview (' + monthStr(S.week - 1) + ')', body: (many ? 'Our market shares: ' : 'Our market share, ') + body, tone: 'n', status: 'done', go: { l: 'Market map', a: 'go', p: { n: 'market' } } });
  }
  addStep('week.after', 55, 'market_map_and_reviews weekly', () => {
    try {
      S.cos.forEach(co => {
        if (co.st !== 'open') return;
        const L = co.rv26 = co.rv26 || [];
        L.push(Math.round(co.lastW ? co.lastW.rev || 0 : 0));
        if (L.length > 13) L.splice(0, L.length - 13);
      });
      S.mm26 = S.mm26 || { idx: [], m: MI() };
      S.mm26.idx.push(Math.round((S.idx || 100) * 100) / 100);
      if (S.mm26.idx.length > 5) S.mm26.idx.splice(0, S.mm26.idx.length - 5);
      if (S.mm26.m !== MI()) {
        S.mm26.m = MI();
        snap();
        const done = {};
        markets().forEach(m => {
          const K = know(m);
          if (K.t === 2 && !done[m.k]) { done[m.k] = 1; sendReport(m, K); }
        });
        if (MI() % 3 === 0) hqOverview();
      }
    } catch (e) { console.error(e); }
  });

  /* ---------- board packs and meetings carry the market share ---------- */
  function packLine(co) {
    const m = mkOfCo(co);
    if (!m) return '';
    const K = know(m), t = truthOf(m);
    if (K.t === 0) return 'Market share: no analyst, so only a feeling (' + guessW(est(t.share, 'my' + m.k, K).c).toLowerCase() + ').';
    return reportLines(m, K, true)[0].replace(/^Our share of /, 'Market share of ');
  }
  R26.packLine = packLine;
  window.boardPack = pipeView('window.boardPack', window.boardPack, 1); /* window.boardPack: the screen above, then the steps below and in later files */
  addStep('window.boardPack', 10, 'market_map_and_reviews window.boardPack', (co, r) => {
    try { const l = packLine(co); if (l) r.body += ' ' + l; } catch (e) { console.error(e); }
    return r;
  });
  window.meetOne = pipeView('window.meetOne', window.meetOne, 3); /* window.meetOne: the screen above, then the steps below and in later files */
  addStep('window.meetOne', 10, 'market_map_and_reviews window.meetOne', (co, goal, sev, r) => {
    try {
      const K = mktanOf(co), m = K && mkOfCo(co);
      if (K && m && S.week - (co.mb26 || -99) >= 3) {
        co.mb26 = S.week;
        addMsg({ kind: 'info', from: K.name, role: 'Market analyst', title: 'In the meeting: the market for ' + co.name, body: reportLines(m, K).slice(0, 3).join(' '), co: co.id, tone: 'n', status: 'done', go: { l: 'Market map', a: 'go', p: { n: 'mktdetail', p: { k: m.k } } } });
      }
    } catch (e) { console.error(e); }
    return r;
  });

  /* ---------- Market map ---------- */
  const PH = { boom: ['Boom', 'amb'], steady: ['Steady', ''], slowdown: ['Slowdown', 'amb'], recession: ['Recession', 'red'] };
  const EXCH = { NO: 'Oslo Børs', SE: 'Stockholm', PL: 'Warsaw', LT: 'Vilnius', DE: 'Frankfurt', UK: 'London', FR: 'Paris', ES: 'Madrid', NL: 'Amsterdam', US: 'New York', CA: 'Toronto', AU: 'Sydney', JP: 'Tokyo', KR: 'Seoul', BR: 'São Paulo', CH: 'SIX Zurich', MX: 'Mexico City', AE: 'Dubai', IT: 'Milan', DK: 'Copenhagen', FI: 'Helsinki', IE: 'Dublin', SG: 'SGX' };
  V.titles.market = 'Market map';
  V.heads = V.heads || {};
  V.heads.market = () => { const ph = PH[S.econ.phase] || PH.steady; return { t: 'Market map', sub: esc((CO[S.country] || CC()).name) + ' · Year ' + (Math.floor(S.week / 52) + 1), right: pillp(ph[0], ph[1]) }; };
  function kNote(list) {
    const ks = list.map(know);
    const t2 = ks.filter(k => k.t === 2), an = R7.anaInfo && R7.anaInfo();
    if (!list.length) return '';
    if (t2.length === list.length) return 'Your market analysts measure every market you are in. Reports arrive in Meetings each month.';
    let s = t2.length ? 'Markets with a market analyst show close numbers. ' : '';
    s += an ? esc(an.name) + ', your data analyst, puts ranges on the rest' + (an.s >= 0.65 ? '.' : ' (still learning, so some are wide).') : 'Without an analyst you only have your own guess. A data analyst at your main office gives ranges; a market analyst in a company measures its market.';
    return s;
  }
  function weight() {
    const live = S.cos.filter(c => c.st === 'open' || c.st === 'closed');
    const C = CO[S.country] || CC();
    const jobs = sumF(live, c => (c.staff || []).length + (c.mgr ? 1 : 0) + (c.asst ? 1 : 0)) + ((S.office && S.office.staff) ? S.office.staff.length : 0);
    const debt = sumF(S.loans || [], l => l.bal || 0) + sumF(live, c => sumF(c.loans || [], l => l.bal || 0));
    const natLoans = (C.pop || 5) * 1e6 * 160000 * Math.pow(C.mkt || 1, 2) * (C.pl || 1);
    const ms = markets().map(m => truthOf(m).share);
    const top = ms.length ? Math.max.apply(null, ms) : 0;
    return { jobs, debt, loanSh: debt / natLoans, top };
  }
  const attention = top => top >= 0.35 ? ['High', 'neg'] : top >= 0.2 ? ['Rising', 'amb'] : top >= 0.1 ? ['Watching', ''] : ['Low', 'pos'];
  function events(list) {
    const ev = [];
    list.forEach(m => {
      if (m.kind !== 'local') return;
      const co = m.cos[0];
      (truthOf(m).riv || []).forEach(x => {
        const r = x.r;
        if (!r) return;
        if (r.listed) ev.push({ t: r.name + ' is for sale', d: 'The owner, ' + esc(r.owner) + ', is open to offers. ' + (know(m).t ? 'Your analyst puts the value at about ' + mshort(rivalValue(co, r)) + '.' : 'Without an analyst the price is a guess.') + ' You could bid, or wait for someone else to buy it.', b: ['See ' + esc(r.name), { n: 'rival', p: { id: co.id, r: r.id } }] });
        else if (r.camp16 && S.week < r.camp16.end) ev.push({ t: r.name + ' runs ' + r.camp16.pct + '% off', d: 'In ' + esc(cityOf(co.city).name) + ' until ' + dateStr(r.camp16.end) + '. Some price-hunting customers will try them.', b: ['Price moves', { n: 'pricemoves', p: { id: co.id } }] });
        else if (r.mkt16) ev.push({ t: r.name + ' is pushing marketing', d: 'A big campaign in ' + esc(cityOf(co.city).name) + '. Expect a little less walk-in trade for a few weeks.', b: ['See ' + esc(r.name), { n: 'rival', p: { id: co.id, r: r.id } }] });
      });
      if (co.flags && co.flags.pw) {
        const r = (rivalsOf(co) || []).find(x => x.id === co.flags.pw.rid);
        ev.unshift({ t: 'Price war with ' + (r ? r.name : 'a rival'), d: Math.max(0, co.flags.pw.end - S.week) + ' weeks left at rock-bottom prices.', b: ['Price war', { n: 'pricewar', p: { id: co.id } }] });
      }
    });
    return ev.slice(0, 4);
  }
  V.market = function () {
    const E = S.econ, list = markets();
    const ix = (S.mm26 && S.mm26.idx) || [];
    const ch = ix.length >= 2 ? ix[ix.length - 1] / ix[0] - 1 : 0;
    let h = '<div class="trio"><div><span>Policy rate</span><b>' + pc(E.rate, 2) + '</b></div><div><span>Inflation</span><b>' + pc(E.infl, 1) + '</b></div><div><span>' + esc(EXCH[S.country] || 'Stock index') + '</span><b class="' + (ch > 0.0005 ? 'pos' : ch < -0.0005 ? 'neg' : '') + '">' + (ix.length >= 2 ? (ch >= 0 ? '+' : '−') + (Math.abs(ch) * 100).toFixed(1) + '%' : '–') + '</b></div></div>';
    if (!list.length) return h + '<h2 class="sec">Your market share</h2><div class="card"><span class="tipt">Your share of each market shows up here once one of your businesses is open.</span></div>';
    h += '<div class="card sense"><span class="tipt">' + kNote(list) + '</span></div>';
    h += '<h2 class="sec">Your market share</h2><div class="card">' + list.map((m, i) => {
      const K = know(m), t = truthOf(m), e = est(t.share, 'my' + m.k, K);
      const v = K.t === 0 ? '<span class="muted">' + guessW(e.c) + '</span>' : shTxt(e);
      return '<button class="mrow26" data-a="go" data-p="' + P({ n: 'mktdetail', p: { k: m.k } }) + '"><span class="kv"><span>' + esc(label(m)) + (K.t === 0 ? ' <small>· your guess</small>' : '') + '</span><b>' + v + ' <i class="muted">›</i></b></span>' + barH((K.t === 2 ? e.c : K.t === 1 ? (e.lo + e.hi) / 2 : e.c) * 100, COLS[i % COLS.length], K.t === 0) + '</button>';
    }).join('') + '</div>';
    /* competitors: every rival, company by company (features/world/rivals_holdings_software.js V.rivals); without
       that page, the biggest across your markets */
    const cs = [];
    list.forEach(m => { const t = truthOf(m), K = know(m); t.riv.forEach(x => cs.push({ m, x, K, my: t.my })); });
    cs.sort((a, b) => b.x.share - a.x.share);
    if (V.rivals) { const rv = V.rivals({ inMarket: 1 }); if (rv) h += '<h2 class="sec">Your rivals</h2>' + rv; }
    else if (cs.length) h += '<h2 class="sec">Competitors</h2><div class="lrows">' + cs.slice(0, 6).map(c => {
      const md = c.x.r ? rivMood(c.m.cos[0], c.x.r) : ['Rival', 'blue', ''];
      const sh = c.K.t === 0 ? sizeVs(c.x.rev, c.my).toLowerCase() : shTxt(est(c.x.share, 'rv' + c.x.id, c.K)) + (c.m.kind === 'fin' ? ' of ' + FIN[c.m.type][1] : ' share');
      const inner = '<span class="av">' + esc(ini(c.x.name)) + '</span><span class="ctext"><b>' + esc(c.x.name) + '</b><small>' + esc(label(c.m)) + ' · ' + sh + (md[2] ? ' · ' + md[2] : '') + '</small></span>' + pillp(md[0], md[1]);
      return c.x.r ? '<button class="lrow" data-a="go" data-p="' + P({ n: 'rival', p: { id: c.m.cos[0].id, r: c.x.id } }) + '">' + inner + '<i>›</i></button>' : '<div class="lrow">' + inner + '</div>';
    }).join('') + '</div>';
    const W = weight(), at = attention(W.top);
    h += '<h2 class="sec">Your weight in the economy</h2><div class="card">' + row('Share of all business loans', W.debt > 0 ? pcS(W.loanSh) : 'None') + row('Jobs you provide', W.jobs.toLocaleString('en-US').replace(/,/g, ' ')) + row('Regulator attention', '<span class="' + at[1] + '">' + at[0] + '</span>') + '<span class="tipt">' + (W.top >= 0.35 ? 'You hold over a third of a market. A price war now can bring a fine for abusing a dominant position, and the competition authority looks closely at what you do.' : 'At about a third of a local market, the competition authority starts to watch your pricing: a price war from that size can bring a fine. ') + '</span></div>';
    const ev = events(list);
    if (ev.length) h += '<h2 class="sec">Events</h2>' + ev.map(e => '<div class="card"><b>' + esc(e.t) + '</b><span class="tipt">' + e.d + '</span>' + (e.b ? '<button class="btn chip wide" data-a="go" data-p="' + P(e.b[1]) + '">' + e.b[0] + '</button>' : '') + '</div>').join('');
    return h;
  };

  /* ---------- one market up close ---------- */
  V.titles.mktdetail = 'Market';
  V.heads.mktdetail = p => { const m = findMk(p.k); return { t: m ? label(m, false) : 'Market', sub: m ? (m.kind === 'fin' ? 'All of ' + esc((CO[m.country] || CC()).name) : esc(cityOf(m.city).name) + ' · ' + m.cos.map(c => esc(c.name)).join(', ')) : '' }; };
  V.mktdetail = function (p) {
    const m = findMk(p.k);
    if (!m) return '<div class="calm">You are no longer in this market.</div>';
    const K = know(m), t = truthOf(m), e = est(t.share, 'my' + m.k, K), L = histOf(m.k);
    let h = '<div class="card"><div class="bhead"><span>' + (K.t === 0 ? 'Your guess' : K.t === 1 ? 'Your data analyst\'s estimate' : 'Measured by ' + esc(K.name)) + '</span>' + pillp(K.t === 2 ? 'Market analyst' : K.t === 1 ? 'Data analyst' : 'No analyst', K.t === 2 ? 'grn' : K.t === 1 ? 'blue' : 'amb') + '</div><div class="big2">' + (K.t === 0 ? guessW(e.c) : shTxt(e)) + '</div>' + barH((K.t === 1 ? (e.lo + e.hi) / 2 : e.c) * 100, COLS[0], K.t === 0);
    if (K.t === 2 && L.length >= 2) {
      const d = (t.share - L[L.length - 2].s) * 100;
      h += row('Since last month', '<span class="' + (d > 0.15 ? 'pos' : d < -0.15 ? 'neg' : '') + '">' + (Math.abs(d) < 0.15 ? 'About the same' : (d > 0 ? '+' : '−') + Math.abs(d).toFixed(1) + ' points') + '</span>');
    }
    if (K.t === 2 && L.length >= 3) h += '<div style="display:flex;justify-content:center">' + spark(L.map(x => x.s * 100), 280, 52) + '</div><p class="muted small">Your share, month by month</p>';
    const tt = amtTxt(t.tot, 'tot' + m.k, K);
    h += row(m.kind === 'fin' ? 'Size of the market' : 'The market sells a year', tt ? tt.replace(/^about /, 'About ') : '<span class="muted">Not known</span>') + row(m.kind === 'fin' ? 'Yours' : 'Your sales a year', mshort(t.my));
    h += '<span class="tipt">' + (K.t === 0 ? 'Your guess from walking past their doors.' : K.t === 1 ? esc(K.name) + ' at your main office estimates this from public data' + (K.s >= 0.65 ? '. Experienced, so the range is tight.' : '. Still learning: a narrow range may be off, a wide one is an honest "not sure".') : esc(K.name) + ' tracks this market full time: prices, footfall and filings. Close to the truth.') + '</span></div>';
    /* who has the market */
    h += '<h2 class="sec">Who has the market</h2><div class="lrows"><div class="lrow"><span class="av">' + esc(ini(m.cos[0].name)) + '</span><span class="ctext"><b>' + esc(m.cos.length > 1 ? 'You (' + m.cos.length + ' sites)' : m.cos[0].name) + ' <small>(yours)</small></b><small>' + (K.t === 0 ? guessW(e.c) : shTxt(e)) + '</small></span></div>' + t.riv.map(x => {
      const re = est(x.share, 'rv' + x.id, K), md = x.r ? rivMood(m.cos[0], x.r) : ['Rival', 'blue', ''];
      const inner = '<span class="av">' + esc(ini(x.name)) + '</span><span class="ctext"><b>' + esc(x.name) + '</b><small>' + (K.t === 0 ? sizeVs(x.rev, t.my) : shTxt(re) + (K.t === 2 ? ' · sells ' + mshort(x.rev) + (m.kind === 'fin' ? '' : ' a year') : '')) + (md[2] ? ' · ' + md[2] : '') + '</small></span>' + pillp(md[0], md[1]);
      return x.r ? '<button class="lrow" data-a="go" data-p="' + P({ n: 'rival', p: { id: m.cos[0].id, r: x.id } }) + '">' + inner + '<i>›</i></button>' : '<div class="lrow">' + inner + '</div>';
    }).join('') + (m.kind === 'fin' ? '<div class="lrow"><span class="ctext"><b>Everyone else</b><small>' + (K.t === 0 ? 'Many small ones' : shTxt(est(Math.max(0, 1 - t.share - sumF(t.riv, x => x.share)), 'oth' + m.k, K))) + '</small></span></div>' : '') + '</div>';
    /* the analyst */
    const a = m.cos.map(mktanOf).find(Boolean);
    h += '<h2 class="sec">Market analyst</h2>';
    if (a) {
      h += '<div class="card"><div class="bhead"><b>' + esc(a.name) + '</b>' + pillp(a.s >= 0.7 ? 'Experienced' : a.s >= 0.5 ? 'Solid' : 'Junior', a.s >= 0.7 ? 'grn' : '') + '</div>' + row('Works at', esc(a.co.name)) + row('Reports', 'Every month, in Meetings') + row('Next report', monthStr(S.week + 4).split(' ')[0] + ', first week') + '<span class="tipt">Also briefs you in meetings with the manager, and adds the share to board packs.</span><button class="btn chip wide" data-a="mkt26rep" data-p="' + P({ k: m.k }) + '">Ask for a report now</button></div>';
      const R = (a.co.mr26 || []).filter(x => x.k === m.k).slice(0, 4);
      if (R.length) h += '<h2 class="sec">Past reports</h2>' + R.map(r => '<div class="card"><div class="bhead"><b>' + esc(r.title.replace(/^Market report: [^(]*\(/, '').replace(/\)$/, '')) + '</b><small>' + dateStr(r.w) + '</small></div>' + r.lines.map(l => '<p class="small">' + esc(l) + '</p>').join('') + '</div>').join('');
    } else {
      const co = m.cos[0];
      h += '<div class="card"><span class="tipt">A market analyst works in ' + esc(co.name) + ' and measures this market: close numbers here, a report every month in Meetings, and a briefing whenever you meet the manager. Costs about ' + money(wageFor('mktan', co) * OC()) + ' a month with employer costs.</span><button class="btn chip primary wide" data-a="mkt26hire" data-p="' + P({ id: co.id }) + '">Hire a market analyst</button></div>';
    }
    return h;
  };
  ACT.mkt26hire = p => { ui.hrole = 'mktan'; ui.cand = null; goV('hire', { id: p.id }); };
  ACT.mkt26rep = p => {
    const m = findMk(p.k), K = m && know(m);
    if (!m || K.t !== 2) return;
    const co = K.co;
    if (S.week - (co.mq26 || -99) < 2) { toast('Your analyst sent one last week. Give it a little time.', true); return; }
    co.mq26 = S.week;
    snap();
    sendReport(m, K);
    save();
    render(true);
    toast('Report sent to Meetings.');
  };
  const goV = (n, p) => ACT.go({ n, p });

  /* ---------- the rival screen: your market analyst's numbers ---------- */
  V.rival = pipeView('V.rival', V.rival, 1); /* V.rival: the screen above, then the steps below and in later files */
  addStep('V.rival', 10, '---------- the rival screen: your market analyst’s numbers ----------', (p, h) => {
    try {
      const co = getCo(p.id), r = co && rivalsOf(co).find(x => x.id === p.r), m = co && mkOfCo(co), a = m && m.cos.map(mktanOf).find(Boolean);
      if (!r || !a) return h;
      const t = truthOf(m), x = t.riv.find(y => y.id === r.id);
      if (!x) return h;
      const md = rivMood(co, r);
      const c = '<h2 class="sec">Your market analyst</h2><div class="card">' + row('Market share', shTxt(est(x.share, 'rv' + x.id, a))) + row('Sales a year', amtTxt(x.rev, 'rr' + x.id, a).replace(/^about/, 'About')) + row('Doing now', md[2] ? md[2].replace(/^./, s => s.toUpperCase()) : 'Nothing unusual') + '<span class="tipt">' + esc(a.name) + ' at ' + esc(a.co.name) + ' follows them closely.</span></div>';
      const i = h.indexOf('<h2 class="sec">What you can do</h2>');
      return i > 0 ? h.slice(0, i) + c + h.slice(i) : h + c;
    } catch (e) { console.error(e); return h; }
  });

  /* ---------- hiring a market analyst: what you get instead of a capacity forecast (ui/screens/hiring.js) ---------- */
  R26.mktanHire = co => {
    const m = mkOfCo(co), has = mktanOf(co);
    return { ok: !!(m && !has), t: has ? 'You already have a market analyst here' : !m ? 'Nothing to measure here' : 'Measures where you stand', s: has ? 'A second one adds cost, not insight.' : !m ? 'This kind of business has no market share to track.' : 'Monthly reports on your market share; close numbers on the Market map. Sales stay the same.' };
  };

  /* ---------- a company's market share row (Money › Ownership and value, ui/company/money.js) ---------- */
  window.CT.marketRow = function (co) {
    try {
      const m = co && co.st === 'open' && mkOfCo(co);
      if (!m) return '';
      const K = know(m), e = est(truthOf(m).share, 'my' + m.k, K);
      return '<button class="lrow" data-a="go" data-p="' + P({ n: 'mktdetail', p: { k: m.k } }) + '"><span class="lic">' + svg('chart', 20) + '</span><span class="ctext"><b>Market share</b><small>' + (K.t === 0 ? guessW(e.c) + ' · your guess' : shTxt(e) + ' · ' + (K.t === 2 ? 'market analyst' : 'data analyst')) + '</small></span><i>›</i></button>';
    } catch (e) { console.error(e); return ''; }
  };

  /* ---------- Reviews: you, and your rivals market by market ---------- */
  V.reviews = function () {
    const f = ui.rvf === 'riv' || ui.rvf === 'all' ? 'riv' : 'mine';
    const L = reviewList('all');
    const mine = L.filter(x => x.mine);
    let h = '<div class="ptabs">' + [['mine', 'My companies'], ['riv', 'Rivals']].map(x => '<button class="' + (f === x[0] ? 'on' : '') + '" data-a="rvf" data-p="' + P({ v: x[0] }) + '">' + x[1] + '</button>').join('') + '</div>';
    const rowR = (x, extra) => '<button class="lrow" data-a="rvopen" data-p="' + P({ k: x.key }) + '"><span class="av">' + esc(ini(x.name)) + '</span><span class="ctext"><b>' + esc(x.name) + (x.mine ? ' <small>(yours)</small>' : '') + '</b><small>' + rvStars(x.rt, x.n) + (x.n < RV_MIN ? '' : ' · ' + rvComment(x.rt)) + (extra ? ' · ' + extra : '') + '</small></span><i>›</i></button>';
    const groups = {};
    L.forEach(x => { const k = x.type + '|' + x.city; (groups[k] = groups[k] || []).push(x); });
    if (f === 'mine') {
      if (!mine.length) return h + '<div class="calm">Nothing to review yet. Reviews arrive once customers come.</div>';
      h += '<p class="muted small">What customers say about your businesses.</p><div class="lrows">' + mine.map(x => {
        const g = (groups[x.type + '|' + x.city] || []).filter(y => y.n >= RV_MIN).sort((a, b) => b.rt - a.rt);
        const rk = x.n >= RV_MIN && g.length > 1 ? 'rated ' + ordinal(g.indexOf(x) + 1) + ' of ' + g.length + ' in ' + esc(cityOf(x.city).name) : esc(BD[x.type].n) + ' · ' + esc(cityOf(x.city).name);
        return rowR(x, rk);
      }).join('') + '</div>';
      return h;
    }
    const keys = Object.keys(groups).filter(k => groups[k].some(x => !x.mine));
    if (!keys.length) return h + '<div class="calm">Rivals show up here once one of your businesses has competition.</div>';
    h += '<p class="muted small">Every business in your markets, best rated first. Tap one to read what its customers say.</p>';
    keys.forEach(k => {
      const g = groups[k].slice().sort((a, b) => (b.n >= RV_MIN) - (a.n >= RV_MIN) || b.rt - a.rt);
      const my = g.find(x => x.mine);
      h += '<h2 class="sec">' + esc(BD[g[0].type].n) + ' · ' + esc(cityOf(g[0].city).name) + '</h2><div class="lrows">' + g.map(x => {
        let ex = '';
        if (!x.mine && my && my.n >= RV_MIN && x.n >= RV_MIN) { const d = Math.round((x.rt - my.rt) * 10) / 10; ex = Math.abs(d) < 0.05 ? 'same as you' : (d > 0 ? '+' : '−') + Math.abs(d).toFixed(1) + ' vs you'; }
        return rowR(x, ex);
      }).join('') + '</div>';
    });
    return h;
  };
  const ordinal = n => n + (n % 10 === 1 && n % 100 !== 11 ? 'st' : n % 10 === 2 && n % 100 !== 12 ? 'nd' : n % 10 === 3 && n % 100 !== 13 ? 'rd' : 'th');
  ACT.rvf = p => { ui.rvf = p.v; render(true); };
  /* in the phone, a review page opens inside the phone (before, it opened behind it and nothing seemed to happen) */
  ACT.rvopen = pipeView('ACT.rvopen', ACT.rvopen, 1);
  addStep('ACT.rvopen.around', 10, 'in the phone, a review page opens inside the phone (before, it opened behind it and nothing seemed to happen)', (p, next) => {
    if (ui.tab !== 'phone') return next();
    ui.rvn = 10;
    ui.phStack = ui.phStack || [];
    if (ui.ph && ui.ph.n !== 'home') ui.phStack.push(ui.ph);
    ui.ph = { n: 'rvdetail', p: { k: p.k } };
    render(true);
  });
  addStep('V.rvdetail', 20, 'market_map_and_reviews V.rvdetail', (p, h) => {
    try {
      /* tidy the header: the number once, the bars filled */
      h = h.replace(/<div class="big2">[\d.]+ (<span class="stars")/, '<div class="big2">$1').split('var(--accent)').join('var(--amber)');
      const x = p && reviewList('all').find(y => y.key === p.k);
      if (!x) return h;
      if (!x.mine) h = h.replace('<h3>Who rates you<small>', '<h3>Who rates them<small>');
      h = h.replace(/(<b>([\d.]+)<\/b>) <small>\2 · (\d+)<\/small>/g, '$1 <small>· $3</small>');
      const g = reviewList('all').filter(y => y.type === x.type && y.city === x.city && y.n >= RV_MIN).sort((a, b) => b.rt - a.rt);
      let c = '';
      if (g.length > 1 && x.n >= RV_MIN && g.some(y => y.key === x.key)) c += row('Rank in ' + esc(cityOf(x.city).name), ordinal(g.findIndex(y => y.key === x.key) + 1) + ' of ' + g.length);
      if (!x.mine) {
        const my = g.find(y => y.mine);
        if (my) c += row('Compared with ' + esc(my.name), (x.rt >= my.rt ? '+' : '−') + Math.abs(x.rt - my.rt).toFixed(1) + ' ★');
        const co = S.cos.find(cc => cc.st === 'open' && cc.type === x.type && cc.city === x.city && (rivalsOf(cc) || []).some(r => r.id === x.rid));
        if (co) c += '<button class="btn chip wide" data-a="go" data-p="' + P({ n: 'rival', p: { id: co.id, r: x.rid } }) + '">Open ' + esc(x.name) + ' in Rivals</button>';
      } else {
        const co = x.co, m = co && mkOfCo(co);
        if (m) c += '<button class="btn chip wide" data-a="go" data-p="' + P({ n: 'mktdetail', p: { k: m.k } }) + '">Market share of ' + esc(co.name) + '</button>';
      }
      if (!c) return h;
      const card2 = '<div class="card"><h3>In this market</h3>' + c + '</div>';
      const i = h.indexOf('<h2 class="sec">');
      return i > 0 ? h.slice(0, i) + card2 + h.slice(i) : h + card2;
    } catch (e) { console.error(e); return h; }
  });
})();


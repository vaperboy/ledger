/* ===== Round 56: weather and tourists.
   Weather: every country has its own weekly weather, drawn from the climate of its main city (average temperature
   and the share of days with rain or snow for each month) and from the weeks before it, so warm or wet spells last a
   while. A week is sunny, mixed, rainy, snowy, a heatwave, a cold snap or a storm (gales in northern Europe in the
   winter, hurricanes in the US and Mexico in late summer, typhoons in Japan and Korea, sandstorms in the UAE).
   What it does is measured against a normal week of that month, so the seasons (SEAS) are not counted twice:
   - outdoor trades (food trucks, amusement parks, car washes, café terraces, kiosks) sell more in fine weather and
     less in rain; taxis, couriers and webshops gain when it is bad; car workshops get busy in a cold snap or snow
   - building sites, hauliers, couriers, fish farms, ships and planes lose working time in storms and snow
   - a storm can damage premises (an insured loss under property insurance). You get a warning the week before
     and can pay to secure your places, which keeps most of the damage away
   Tourists: each country has its own tourist season (beaches in Spain in summer, the Alps in winter and summer, the
   UAE in winter, Australia at Christmas) and now and then a big event in a city, a travel guide that features it,
   or a scare that keeps visitors away. How much it matters depends on how many of a company's customers are
   visitors (TOURISM by country, TOUR_T by trade, engine/company/reviews.js).
   Shown: a weather pill on Home (tap: the forecast and the tourist season), one line on each company's This week
   card when the weather or the tourists move its customers. Replaces the old random bad-weather events. ===== */
window.WX56 = window.WX56 || {};
(function () {
  const X = window.WX56;
  const capF = s => String(s || '').replace(/^./, x => x.toUpperCase());
  const U = window.UI;
  /* climate of the main city: [average °C by month, share of days with rain or snow by month] */
  const CL = {
    NO: [[-3, -3, 1, 5, 11, 15, 17, 16, 11, 6, 1, -2], [.4, .35, .35, .35, .35, .4, .4, .45, .45, .45, .45, .45]],
    SE: [[-2, -2, 1, 6, 11, 16, 18, 17, 12, 7, 3, 0], [.4, .35, .3, .3, .3, .35, .35, .4, .4, .45, .45, .45]],
    DE: [[1, 2, 5, 10, 14, 17, 20, 19, 15, 10, 5, 2], [.45, .4, .4, .35, .4, .4, .4, .4, .35, .4, .45, .45]],
    UK: [[5, 6, 8, 10, 13, 17, 19, 19, 16, 12, 8, 6], [.5, .45, .4, .4, .4, .35, .35, .35, .4, .45, .5, .5]],
    FR: [[5, 6, 9, 12, 15, 19, 21, 21, 17, 13, 8, 5], [.45, .4, .4, .4, .4, .35, .3, .3, .35, .4, .45, .45]],
    ES: [[6, 8, 11, 13, 17, 23, 26, 26, 21, 15, 10, 7], [.2, .2, .2, .25, .2, .1, .05, .05, .12, .2, .22, .22]],
    NL: [[4, 4, 7, 10, 13, 16, 18, 18, 15, 11, 7, 4], [.5, .45, .45, .4, .4, .4, .4, .45, .45, .5, .55, .55]],
    PL: [[-1, 0, 4, 9, 14, 17, 19, 19, 14, 9, 4, 0], [.4, .35, .35, .35, .4, .4, .4, .35, .35, .35, .4, .4]],
    LT: [[-4, -3, 1, 7, 13, 16, 18, 17, 12, 7, 1, -2], [.45, .4, .35, .35, .35, .4, .45, .4, .4, .4, .45, .45]],
    US: [[1, 2, 6, 12, 17, 22, 25, 24, 21, 14, 9, 4], [.35, .3, .35, .35, .35, .35, .35, .3, .3, .3, .3, .35]],
    CA: [[-5, -4, 0, 7, 13, 19, 22, 21, 17, 10, 4, -2], [.4, .35, .35, .35, .35, .35, .3, .3, .3, .35, .4, .4]],
    JP: [[5, 6, 9, 14, 19, 22, 26, 27, 23, 18, 13, 8], [.15, .2, .3, .3, .35, .4, .35, .3, .4, .3, .25, .15]],
    KR: [[-2, 0, 6, 13, 18, 23, 25, 26, 21, 15, 7, 0], [.15, .15, .2, .25, .25, .3, .55, .45, .3, .2, .25, .2]],
    AU: [[23, 23, 22, 19, 16, 14, 13, 14, 16, 18, 20, 22], [.4, .45, .45, .4, .4, .4, .35, .3, .3, .35, .4, .4]],
    BR: [[23, 23, 22, 21, 18, 17, 17, 18, 19, 20, 21, 22], [.6, .55, .5, .35, .3, .25, .2, .2, .3, .4, .45, .55]],
    CH: [[0, 2, 6, 10, 14, 17, 19, 19, 15, 10, 5, 1], [.4, .4, .45, .45, .5, .5, .5, .45, .4, .4, .4, .4]],
    MX: [[14, 16, 18, 19, 19, 18, 17, 17, 17, 16, 15, 14], [.1, .1, .12, .2, .35, .55, .7, .7, .6, .3, .12, .08]],
    AE: [[19, 21, 24, 28, 32, 34, 36, 36, 33, 30, 25, 21], [.05, .07, .06, .03, .01, 0, .01, .01, 0, .01, .03, .05]],
    IT: [[8, 9, 12, 15, 19, 24, 27, 27, 23, 18, 13, 9], [.3, .3, .3, .35, .3, .2, .12, .15, .25, .35, .4, .35]],
    DK: [[1, 1, 3, 7, 12, 15, 17, 17, 14, 10, 5, 2], [.5, .4, .4, .35, .35, .35, .4, .45, .45, .5, .55, .55]],
    FI: [[-5, -6, -2, 4, 10, 15, 18, 16, 11, 5, 1, -3], [.45, .4, .35, .3, .3, .35, .4, .45, .45, .5, .5, .5]],
    IE: [[6, 6, 7, 9, 12, 14, 16, 16, 14, 11, 8, 6], [.6, .55, .55, .5, .5, .45, .45, .5, .5, .55, .6, .6]],
    SG: [[27, 27, 28, 28, 28, 28, 28, 28, 28, 28, 27, 27], [.5, .35, .45, .5, .45, .45, .45, .45, .45, .5, .6, .6]]
  };
  /* how far a week can stray from normal (°C, one standard deviation) */
  const SD = { SG: 0.8, IE: 2.2, IT: 2.4, AE: 1.8, BR: 1.8, MX: 1.6, AU: 2.2, ES: 2.6, UK: 2.6, NL: 2.8, JP: 2.4, FR: 2.8 };
  /* storms: the chance a week brings one, by month (0 = January) */
  function stormP(cc, m) {
    const W = m >= 9 || m <= 1;
    if (['NO', 'UK', 'NL', 'DE', 'FR', 'SE', 'LT', 'PL', 'CA', 'DK', 'FI', 'IE'].indexOf(cc) >= 0) return W ? 0.035 : 0.006;
    if (cc === 'IT') return m >= 9 && m <= 11 ? 0.025 : 0.006;
    if (cc === 'SG') return m >= 10 || m <= 1 ? 0.03 : 0.012;
    if (cc === 'CH') return W ? 0.02 : 0.006;
    if (cc === 'US' || cc === 'MX') return m >= 7 && m <= 9 ? 0.05 : 0.008;
    if (cc === 'JP' || cc === 'KR') return m >= 6 && m <= 8 ? 0.06 : 0.006;
    if (cc === 'AU' || cc === 'BR') return m >= 11 || m <= 2 ? 0.03 : 0.006;
    if (cc === 'AE') return m >= 2 && m <= 5 ? 0.03 : 0.004;
    if (cc === 'ES') return m >= 8 && m <= 10 ? 0.02 : 0.005;
    return 0.01;
  }
  const STORMN = { SG: 'a monsoon storm', IT: 'a severe storm', US: 'a hurricane', MX: 'a hurricane', JP: 'a typhoon', KR: 'a typhoon', AE: 'a sandstorm', AU: 'a severe storm', BR: 'a severe storm', ES: 'a severe storm' };
  X.stormName = cc => STORMN[cc] || 'a storm';
  const nz = R => (R() + R() + R() - 1.5) * 2; /* about a normal draw */
  const nice = (t, r) => clamp(1 - Math.abs(t - 22) / 16, -1, 1) * 0.6 + (1 - r / 3.5) * 0.4;
  const M = {};
  let mN = 0;
  /* the weather of a country in a week: t (°C), r (days with rain or snow), k (kind), n (how pleasant), dn (against normal) */
  function draw(cc, w) {
    const key = cc + ':' + w;
    if (M[key]) return M[key];
    if (++mN > 600) { for (const k in M) delete M[k]; mN = 0; }
    const c = CL[cc] || CL.NO, m = wMonth(w);
    let a = 0;
    for (let k = 0; k < 6; k++) a += Math.pow(0.6, k) * nz(hrng(S.seed + ':wx:' + cc + ':' + (w - k)));
    a *= 0.8;
    const R = hrng(S.seed + ':wx2:' + cc + ':' + w);
    const t = Math.round(c[0][m] + a * (SD[cc] || 3.2));
    const wet = clamp(c[1][m] * (1 + 0.35 * nz(R)), 0, 0.95);
    let r = 0;
    for (let i = 0; i < 7; i++) if (R() < wet) r++;
    const storm = R() < stormP(cc, m);
    const k = storm ? 'storm' : r >= 3 && t <= 0 ? 'snow' : t >= Math.max(22, c[0][m] + 5) ? 'heat' : t <= Math.min(-5, c[0][m] - 5.5) ? 'cold' : r >= 4 ? 'rain' : r >= 2 ? 'mixed' : 'sun';
    const n = nice(t, r);
    return (M[key] = { t, r, k, n, dn: n - nice(c[0][m], c[1][m] * 7), cc, w, snowNormal: c[0][m] <= -1 });
  }
  X.draw = draw;
  X.now = cc => draw(cc || S.country, S.week);
  const KW = { sun: 'Sunny', mixed: 'Mixed', rain: 'Rainy', snow: 'Snow', heat: 'Heatwave', cold: 'Cold snap', storm: 'Storm' };
  X.word = k => KW[k] || k;
  const ICO = {
    sun: '<circle cx="12" cy="12" r="4.5"/><path d="M12 2.5v2.5M12 19v2.5M2.5 12H5M19 12h2.5M5.3 5.3l1.8 1.8M16.9 16.9l1.8 1.8M5.3 18.7l1.8-1.8M16.9 7.1l1.8-1.8"/>',
    mixed: '<circle cx="8.5" cy="9" r="3.5"/><path d="M8 19h9a3.5 3.5 0 0 0 0-7 5 5 0 0 0-9.4 1.6A2.8 2.8 0 0 0 8 19z"/>',
    rain: '<path d="M7 15h10a3.5 3.5 0 0 0 0-7 5 5 0 0 0-9.6 1.4A2.8 2.8 0 0 0 7 15z"/><path d="M9 18l-1 2.5M13 18l-1 2.5M17 18l-1 2.5"/>',
    snow: '<path d="M7 14h10a3.5 3.5 0 0 0 0-7 5 5 0 0 0-9.6 1.4A2.8 2.8 0 0 0 7 14z"/><path d="M9 18h.01M13 19.5h.01M17 18h.01M11 21h.01M15 21.5h.01"/>',
    heat: '<circle cx="12" cy="12" r="5"/><path d="M12 1.5v3M12 19.5v3M1.5 12h3M19.5 12h3M4.6 4.6l2.1 2.1M17.3 17.3l2.1 2.1M4.6 19.4l2.1-2.1M17.3 6.7l2.1-2.1"/>',
    cold: '<path d="M12 2v20M3.3 7l17.4 10M3.3 17L20.7 7M9 4l3 2 3-2M9 20l3-2 3 2"/>',
    storm: '<path d="M7 13h10a3.5 3.5 0 0 0 0-7 5 5 0 0 0-9.6 1.4A2.8 2.8 0 0 0 7 13z"/><path d="M12.5 14l-2.5 4h3l-2 4"/>'
  };
  const deg = v => (v < 0 ? '−' : '') + Math.abs(v);
  X.deg = deg;
  const ic = (k, s) => '<svg class="wx56i wx-' + k + '" width="' + (s || 18) + '" height="' + (s || 18) + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (ICO[k] || ICO.mixed) + '</svg>';
  X.icon = ic;

  /* ---------- what the weather does to a trade: [pleasant weather against normal, demand by kind, capacity by kind] ---------- */
  const SENS = {
    foodtruck: [0.45, { storm: 0.5, snow: 0.7, heat: 1.05 }], fun: [0.4, { storm: 0.5, snow: 0.8 }], carclean: [0.35, { snow: 1.15 }],
    cafe: [0.12, { heat: 1.06, storm: 0.9 }], kiosk: [0.12, { heat: 1.1, storm: 0.9 }], restaurant: [0.06, { storm: 0.85, snow: 0.9 }],
    nightclub: [0.04, { storm: 0.85 }], hotel: [0.05, { storm: 0.9 }], hardware: [0.12, { storm: 0.9 }], boutique: [0.04, { storm: 0.9, snow: 0.92 }],
    grocery: [0.02, { storm: 0.95 }], estate: [0.04, {}], skires: [0.15, {}, { storm: 0.6 }],
    taxi: [-0.18, { snow: 1.15, storm: 1.1 }], courier: [-0.05, { storm: 1.05 }, { snow: 0.85, storm: 0.8 }], webshop: [-0.06, { storm: 1.08, snow: 1.08 }],
    casino: [-0.04, {}], indoorski: [-0.1, { heat: 1.1 }], gym: [-0.06, {}], carrepair: [0, { cold: 1.25, snow: 1.15 }], handy: [0.05, { storm: 1.3 }],
    trucking: [0, {}, { snow: 0.85, storm: 0.85 }], shipping: [0, {}, { storm: 0.7 }], airline: [0, {}, { storm: 0.75, snow: 0.9 }],
    salmon: [0, {}, { storm: 0.85 }], farm: [0, {}, { storm: 0.9 }], wh3pl: [0, {}, { snow: 0.92, storm: 0.9 }]
  };
  const FAM = { project: [0, {}, { storm: 0.7, snow: 0.75, heat: 0.92 }], venue: [0.05, { storm: 0.9 }], retail: [0.03, { storm: 0.92 }] };
  const sensOf = co => SENS[co.type] || FAM[(BD[co.type] || {}).fam] || null;
  /* {d: demand factor, c: capacity factor} for a company this week */
  function fx(co, w) {
    const s = sensOf(co);
    if (!s) return { d: 1, c: 1 };
    const x = draw(co.country || S.country, w != null ? w : S.week);
    /* snow where snow is normal is no news: it is already in the season */
    const u = x.k === 'snow' && x.snowNormal ? 0.3 : 1;
    let d = clamp(1 + s[0] * x.dn, 0.6, 1.4);
    if (s[1] && s[1][x.k]) d *= 1 + (s[1][x.k] - 1) * u;
    let c = 1;
    if (s[2] && s[2][x.k]) c *= 1 + (s[2][x.k] - 1) * u;
    if ((BD[co.type] || {}).fam === 'project' && x.r > 3) c *= 1 - 0.035 * (x.r - 3);
    return { d, c, x };
  }
  X.fx = fx;

  /* ---------- tourists ---------- */
  const TS = {
    NO: [0.7, 0.75, 0.8, 0.8, 0.95, 1.35, 1.6, 1.4, 0.95, 0.75, 0.65, 0.9], SE: [0.7, 0.7, 0.75, 0.85, 1, 1.3, 1.6, 1.4, 1, 0.8, 0.7, 0.85],
    DE: [0.7, 0.7, 0.85, 1, 1.1, 1.15, 1.25, 1.25, 1.15, 1, 0.8, 1.05], UK: [0.75, 0.75, 0.85, 0.95, 1.05, 1.15, 1.3, 1.35, 1.05, 0.95, 0.8, 0.95],
    FR: [0.7, 0.75, 0.85, 1, 1.1, 1.25, 1.5, 1.55, 1.1, 0.9, 0.7, 0.85], ES: [0.6, 0.65, 0.8, 0.95, 1.05, 1.3, 1.6, 1.65, 1.25, 0.95, 0.65, 0.65],
    NL: [0.65, 0.7, 0.9, 1.35, 1.15, 1.1, 1.25, 1.25, 1, 0.9, 0.7, 0.85], PL: [0.7, 0.7, 0.8, 0.9, 1.05, 1.2, 1.4, 1.4, 1.1, 0.9, 0.75, 0.9],
    LT: [0.6, 0.6, 0.7, 0.85, 1.05, 1.3, 1.55, 1.5, 1.05, 0.8, 0.65, 0.85], US: [0.8, 0.85, 1, 1, 1.05, 1.2, 1.3, 1.25, 1, 0.95, 0.85, 1],
    CA: [0.7, 0.75, 0.85, 0.85, 0.95, 1.25, 1.5, 1.45, 1.05, 0.9, 0.7, 0.85], JP: [0.85, 0.85, 1.1, 1.35, 1.05, 0.9, 1, 1.05, 0.9, 1.05, 1.1, 0.9],
    KR: [0.85, 0.8, 0.95, 1.1, 1.1, 1, 1.1, 1.1, 1, 1.1, 1, 0.9], AU: [1.35, 1.1, 1, 1, 0.85, 0.8, 0.95, 0.85, 0.9, 0.95, 1, 1.3],
    BR: [1.4, 1.45, 1, 0.85, 0.8, 0.8, 1.05, 0.9, 0.85, 0.9, 0.9, 1.2], CH: [1.2, 1.25, 1.05, 0.8, 0.75, 0.95, 1.2, 1.2, 0.95, 0.8, 0.65, 1],
    MX: [1.2, 1.2, 1.25, 1.15, 0.85, 0.8, 0.95, 0.95, 0.7, 0.85, 1, 1.2], AE: [1.35, 1.35, 1.3, 1.05, 0.75, 0.55, 0.55, 0.6, 0.7, 1, 1.25, 1.45],
    IT: [0.6, 0.65, 0.8, 1, 1.1, 1.3, 1.5, 1.6, 1.25, 0.95, 0.65, 0.75], DK: [0.65, 0.65, 0.75, 0.9, 1, 1.3, 1.65, 1.45, 1, 0.85, 0.75, 1.05],
    FI: [0.95, 0.85, 0.8, 0.75, 0.85, 1.15, 1.45, 1.2, 0.9, 0.75, 0.85, 1.5], IE: [0.6, 0.65, 0.85, 0.95, 1.05, 1.25, 1.45, 1.45, 1.1, 0.95, 0.75, 0.9],
    SG: [1.05, 1, 0.95, 0.95, 0.95, 1, 1.1, 1.1, 0.9, 0.95, 0.95, 1.1]
  };
  Object.keys(TS).forEach(k => { const a = TS[k], m = a.reduce((x, y) => x + y, 0) / 12; TS[k] = a.map(v => Math.round(v / m * 100) / 100); });
  X.TS = TS;
  const st = () => (S.wx56 = S.wx56 || { ev: [], prep: {}, sent: {} });
  /* how many of a company's customers are visitors */
  const share = co => Math.min(0.55, (typeof TOUR_T !== 'undefined' && TOUR_T[co.type] || 0.03) * (0.2 + 0.8 * ((typeof TOURISM !== 'undefined' && TOURISM[co.country || S.country]) || 0.1)));
  X.share = share;
  function tourF(cc, city, w) {
    let f = (TS[cc] || TS.NO)[wMonth(w)];
    st().ev.forEach(e => { if (e.cc === cc && w >= e.w0 && w < e.end && (!e.city || e.city === city)) f *= e.f; });
    return f;
  }
  X.tourF = tourF;

  /* ---------- demand and capacity ---------- */
  addStep('demand', 94, 'weather and tourists', (co, bd, r) => {
    if (!co || !r || !(r.D >= 0) || co.type === 'hold') return;
    const e = fx(co);
    const ts = share(co), tf = ts > 0.01 ? 1 + ts * (tourF(co.country || S.country, co.city, S.week) - 1) : 1;
    r.D *= e.d * tf;
    if (r.parts) { if (e.d !== 1) r.parts.weather = Math.round(e.d * 100) / 100; if (tf !== 1) r.parts.tourists = Math.round(tf * 100) / 100; }
  }, true);
  addStep('capacity', 80, 'storms and snow stop outdoor work', (co, bd, r) => {
    if (!co || !r || !r.cap || co.type === 'hold') return;
    const e = fx(co);
    if (e.c !== 1) r.cap *= e.c;
  }, true);

  /* ---------- the week's line on a company's This week card ---------- */
  X.line = function (co) {
    try {
      const e = fx(co), ts = share(co), tf = ts > 0.01 ? 1 + ts * (tourF(co.country || S.country, co.city, S.week) - 1) : 1;
      const p = [];
      if (Math.abs(e.d - 1) >= 0.04 || e.c < 0.97) p.push(ic(e.x.k, 14) + ' ' + KW[e.x.k] + ' ' + deg(e.x.t) + '°' + (Math.abs(e.d - 1) >= 0.04 ? ' · ' + (e.d > 1 ? '+' : '−') + Math.round(Math.abs(e.d - 1) * 100) + '% customers' : '') + (e.c < 0.97 ? ' · ' + Math.round((1 - e.c) * 100) + '% less working time' : ''));
      if (Math.abs(tf - 1) >= 0.04) p.push((tf > 1 ? 'Tourist season' : 'Few tourists') + ' · ' + (tf > 1 ? '+' : '−') + Math.round(Math.abs(tf - 1) * 100) + '%');
      return p.length ? '<small class="jl41 wx56l">' + p.join(' · ') + '</small>' : '';
    } catch (err) { return ''; }
  };

  /* ---------- warnings, storm damage and tourist news ---------- */
  const physical = co => co.prem && co.prem.m2 > 0 && ['fin', 'hold', 'club'].indexOf((BD[co.type] || {}).fam) < 0;
  const mine = cc => liveCos().filter(c => c.st === 'open' && (c.country || S.country) === cc);
  addStep('week.after', 64, 'weather warnings, storm damage, tourist news', () => {
    const s = st();
    const ccs = Array.from(new Set(liveCos().filter(c => c.st === 'open').map(c => c.country || S.country)));
    ccs.forEach(cc => {
      const L = mine(cc);
      /* the storm that just passed */
      const now = draw(cc, S.week), key = cc + ':' + S.week;
      if (now.k === 'storm') {
        const prep = s.prep[key];
        let hit = 0, tot = 0;
        L.filter(physical).forEach(co => {
          if (!chance(prep ? 0.04 : 0.22)) return;
          const amt = rnl(KC(8000 + rng(0, 1) * 52000, cc) * Math.pow(Math.max(0.5, co.size || 1), 0.7), 500);
          try { applyFx(co, { loss: amt }, null, { cat: 'prop', id: 'wx56' }); } catch (e) { payCo(co, amt, 'loss', 'Storm damage'); }
          hit++; tot += amt;
          note(capF(X.stormName(cc)) + ' damaged ' + co.name + ': about ' + money(amt) + (co.ins && co.ins.prop ? ', mostly paid by the insurance' : ' (not insured)') + '.', 'bad', co.id);
        });
        if (!hit && prep && L.length) note('The storm passed. Your places were secured and nothing was damaged.', 'good');
        delete s.prep[key];
      }
      /* next week's weather: a warning when it matters */
      const nx = draw(cc, S.week + 1), nkey = cc + ':' + (S.week + 1);
      if (nx.k === 'storm' && !s.sent[nkey] && L.some(physical)) {
        s.sent[nkey] = 1;
        const P = L.filter(physical), cost = rnl(sum(P, co => KC(3500, cc) * Math.pow(Math.max(0.5, co.size || 1), 0.7)), 500);
        addMsg({ kind: 'ask', from: 'Weather service', title: capF(X.stormName(cc)) + ' is coming to ' + ((CO[cc] || {}).name || cc) + ' next week', body: 'Strong winds and heavy rain are forecast. Places that are not secured can be damaged: roofs, windows, signs, stock and equipment. Securing ' + P.length + (P.length > 1 ? ' places' : ' place') + ' (shutters, sandbags, moving stock and equipment) costs about ' + money(cost) + '. Outdoor work and travel will slow down either way.', co: P[0].id, act: 'wx56prep', data: { k: nkey, cost, cos: P.map(c => c.id) }, exp: S.week + 1, tone: 'bad', opts: [{ l: 'Secure everything · ' + money(cost), d: 'Damage becomes unlikely.', fx: {} }, { l: 'Take the chance', d: 'About one in five places may be damaged.', fx: {} }] });
      } else if ((nx.k === 'heat' || nx.k === 'cold' || (nx.k === 'snow' && !nx.snowNormal)) && !s.sent[nkey] && L.some(co => Math.abs(fx(co, S.week + 1).d - 1) >= 0.08 || fx(co, S.week + 1).c < 0.95)) {
        s.sent[nkey] = 1;
        const aff = L.filter(co => Math.abs(fx(co, S.week + 1).d - 1) >= 0.08 || fx(co, S.week + 1).c < 0.95).slice(0, 4);
        addMsg({ kind: 'info', from: 'Weather service', title: KW[nx.k] + ' in ' + ((CO[cc] || {}).name || cc) + ' next week (' + deg(nx.t) + '°)', body: aff.map(co => { const e = fx(co, S.week + 1); return co.name + ': ' + (Math.abs(e.d - 1) >= 0.08 ? (e.d > 1 ? 'about ' + Math.round((e.d - 1) * 100) + '% more customers' : 'about ' + Math.round((1 - e.d) * 100) + '% fewer customers') : '') + (e.c < 0.95 ? (Math.abs(e.d - 1) >= 0.08 ? ', ' : '') + 'less working time' : '') + '.'; }).join(' '), co: aff[0].id, tone: 'n', status: 'done' });
      }
      /* tourist news: about one a year per country, only where visitors matter to you */
      const T = L.filter(co => share(co) >= 0.06);
      if (T.length && !s.ev.some(e => e.cc === cc && e.end > S.week) && chance(1 / 45)) {
        const co = T[Math.floor(rng(0, 1) * T.length)], city = cityOf(co.city).name;
        const K = [
          ['fest', 1.45, 2, [city + ' hosts a big music festival', 'a major sports final comes to ' + city, city + ' hosts an international trade fair', 'a famous food festival comes to ' + city], 1],
          ['guide', 1.15, 16, [city + ' is named one of the places to visit this year in an international travel guide'], 1],
          ['scare', 0.75, 5, ['A travel warning keeps visitors away from ' + ((CO[cc] || {}).name || cc), 'An airline strike cancels flights to ' + ((CO[cc] || {}).name || cc)], 0],
          ['cheap', 1.12, 12, ['The ' + ((CO[cc] || {}).cur || 'local currency') + ' is weak, so ' + ((CO[cc] || {}).name || cc) + ' is cheap for visitors'], 0]
        ];
        const k = K[Math.floor(rng(0, 1) * K.length)], t = k[3][Math.floor(rng(0, 1) * k[3].length)];
        s.ev.push({ cc, city: k[4] ? co.city : null, f: k[1], w0: S.week + 1, end: S.week + 1 + k[2], t });
        s.ev = s.ev.filter(e => e.end > S.week - 52);
        addMsg({ kind: 'info', from: 'Tourism board', title: capF(t), body: (k[1] > 1 ? 'More visitors than usual for about ' : 'Fewer visitors than usual for about ') + k[2] + ' weeks' + (k[4] ? ' in ' + city : '') + '. ' + T.filter(c => !k[4] || c.city === co.city).slice(0, 4).map(c => c.name + ' (' + Math.round(share(c) * 100) + '% of its customers are visitors)').join(', ') + '.', co: co.id, tone: k[1] > 1 ? 'good' : 'bad', status: 'done' });
      }
    });
    Object.keys(s.sent).forEach(k => { if (+k.split(':')[1] < S.week - 2) delete s.sent[k]; });
  });
  ACTS.wx56prep = (m, idx) => {
    if (idx !== 0) return true;
    const d = m.data || {};
    const P = (d.cos || []).map(getCo).filter(c => c && c.st === 'open');
    if (!P.length) return true;
    const each = d.cost / P.length;
    P.forEach(co => payCo(co, each, 'oth', 'Securing for the storm'));
    st().prep[d.k] = 1;
    return true;
  };

  /* ---------- the weather pill on Home and the forecast screen ---------- */
  if (!U) return;
  const { V, esc } = U;
  const P = o => esc(JSON.stringify(o));
  X.pill = function (cc) {
    const c = CO[cc] || CC(), x = draw(cc, S.week);
    return '<button class="pill wx56p" data-a="go" data-p="' + P({ n: 'wx56', p: {} }) + '">' + c.flag + ' ' + ic(x.k, 15) + ' ' + deg(x.t) + '°</button>';
  };
  V.titles.wx56 = 'Weather and tourists';
  V.wx56 = function () {
    const ccs = Array.from(new Set([S.country].concat(liveCos().filter(c => c.st === 'open').map(c => c.country || S.country))));
    const cur = ccs.indexOf(U.ui.wx56c) >= 0 ? U.ui.wx56c : ccs[0];
    let h = ccs.length > 1 ? U.chips(ccs.map(cc => [cc, (CO[cc] || {}).flag + ' ' + esc((CO[cc] || {}).name || cc)]), cur, 'wx56c') : '';
    const x = draw(cur, S.week);
    const dayW = x.r === 0 ? 'Dry all week' : x.k === 'snow' ? 'Snow on ' + x.r + (x.r > 1 ? ' days' : ' day') : 'Rain on ' + x.r + (x.r > 1 ? ' days' : ' day');
    h += '<div class="card wx56c"><div class="wx56h">' + ic(x.k, 44) + '<div><span class="lab">This week in ' + esc((CO[cur] || {}).name || cur) + '</span><b class="huge">' + deg(x.t) + '°</b><small class="mo56">' + KW[x.k] + ' · ' + dayW + '</small></div></div>';
    h += '<div class="wx56f">' + [1, 2, 3].map(i => { const y = draw(cur, S.week + i), sp = i === 1 ? 1 : i === 2 ? 2 : 3, k = i === 3 && y.k !== 'storm' && hrng(S.seed + ':fc:' + cur + ':' + (S.week + i))() < 0.3 ? 'mixed' : y.k; return '<div>' + '<span>' + (i === 1 ? 'Next week' : 'In ' + i + ' weeks') + '</span>' + ic(k, 26) + '<b>' + deg(y.t - sp) + ' to ' + deg(y.t + sp) + '°</b><small>' + (i === 3 && k !== y.k ? 'Uncertain' : KW[k]) + '</small></div>'; }).join('') + '</div></div>';
    /* how your companies feel it this week */
    const L = liveCos().filter(c => c.st === 'open' && (c.country || S.country) === cur);
    const rows = L.map(co => { const e = fx(co), ts = share(co), tf = ts > 0.01 ? 1 + ts * (tourF(cur, co.city, S.week) - 1) : 1, tot = e.d * tf; return [co, e, tf, tot]; }).filter(r => Math.abs(r[3] - 1) >= 0.02 || r[1].c < 0.98);
    h += '<h2 class="sec">Your companies this week</h2>' + (rows.length ? '<div class="lrows">' + rows.map(([co, e, tf, tot]) => '<button class="lrow" data-a="go" data-p="' + P({ n: 'co', p: { id: co.id } }) + '"><span class="ctext"><b>' + esc(co.name) + '</b><small>' + [Math.abs(e.d - 1) >= 0.02 ? 'weather ' + (e.d > 1 ? '+' : '−') + Math.round(Math.abs(e.d - 1) * 100) + '%' : '', Math.abs(tf - 1) >= 0.02 ? 'tourists ' + (tf > 1 ? '+' : '−') + Math.round(Math.abs(tf - 1) * 100) + '%' : '', e.c < 0.98 ? Math.round((1 - e.c) * 100) + '% less working time' : ''].filter(Boolean).join(' · ') + '</small></span><b class="num ' + (tot > 1 ? 'pos' : tot < 1 ? 'neg' : '') + '">' + (tot >= 1 ? '+' : '−') + Math.round(Math.abs(tot - 1) * 100) + '%</b></button>').join('') + '</div>' : '<div class="calm">The weather and the tourists change little for your companies this week.</div>');
    /* the tourist season */
    const A = TS[cur] || TS.NO, mx = Math.max(...A), m0 = wMonth(S.week);
    h += '<h2 class="sec">Tourist season</h2><div class="card"><div class="ts56">' + A.map((v, i) => '<i class="' + (i === m0 ? 'cur' : '') + '"><b style="height:' + Math.round(v / mx * 100) + '%"></b><u>' + 'JFMAMJJASOND'[i] + '</u></i>').join('') + '</div><span class="tipt">About ' + Math.round(((typeof TOURISM !== 'undefined' && TOURISM[cur]) || 0.1) * 100) + '% of visitors here come from abroad. Hotels, attractions, restaurants and nightlife feel the season most.</span>';
    const E = st().ev.filter(e => e.cc === cur && e.end > S.week);
    h += E.map(e => '<div class="kv"><span>' + esc(capF(e.t)) + '</span><b class="' + (e.f > 1 ? 'pos' : 'neg') + '">' + (e.f > 1 ? '+' : '−') + Math.round(Math.abs(e.f - 1) * 100) + '% · ' + (e.w0 > S.week ? 'from next week' : 'until ' + dateStr(e.end)) + '</b></div>').join('') + '</div>';
    return h;
  };
  U.ACT.wx56c = p => { U.ui.wx56c = p.v; U.render(); };
})();

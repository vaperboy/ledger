/* ===== Round 20: country economics from one table, USD as the reference.
   The game's internal money unit stays a Norway-priced amount (1 unit = 1 NOK at 10.7 NOK per USD), so every amount
   already tuned keeps its meaning. Exchange rates (fx in the country packs, patched at build), price level, wage level
   and buying power are all derived from this USD-based table, each applied once:
   - fx: base units per local unit = 10.7 / fxLocalPerUSD (the same number for every EUR country, also when it drifts)
   - pl (consumer prices, fees scaled by KC): costIndex / Norway's costIndex
   - wage (salaries, city wages): wageIndex / Norway's wageIndex
   - buying power: no longer a flat demand multiplier; it decides how well people can afford what you sell ===== */
{
  const T = {
    US: ['USD', 1, 100, 100, 100], NO: ['NOK', 10.7, 110, 97, 90], LT: ['EUR', 0.92, 65, 53, 62], SE: ['SEK', 10.5, 95, 78, 82], BR: ['BRL', 5.8, 55, 22, 40],
    DE: ['EUR', 0.92, 95, 90, 90], FR: ['EUR', 0.92, 95, 81, 83], PL: ['PLN', 4.0, 60, 48, 57], KR: ['KRW', 1400, 85, 62, 72], JP: ['JPY', 150, 85, 66, 75],
    AU: ['AUD', 1.5, 125, 97, 95], CA: ['CAD', 1.4, 115, 99, 93], NL: ['EUR', 0.92, 105, 108, 100], ES: ['EUR', 0.92, 80, 72, 78], UK: ['GBP', 0.79, 95, 90, 90],
    /* round 56 */ CH: ['CHF', 0.8, 140, 150, 115], MX: ['MXN', 18.5, 52, 20, 40], AE: ['AED', 3.6725, 85, 50, 85],
    /* round 57 */ IT: ['EUR', 0.92, 80, 64, 76], DK: ['DKK', 6.86, 112, 102, 95], FI: ['EUR', 0.92, 100, 82, 85], IE: ['EUR', 0.92, 110, 95, 88], SG: ['SGD', 1.29, 105, 86, 95]
  };
  const NOKUSD = T.NO[1], REF = T.NO;
  const ECON = window.ECON20 = {};
  Object.keys(T).forEach(k => { const t = T[k]; ECON[k] = { currency: t[0], fxLocalPerUSD: t[1], costIndex: t[2], wageIndex: t[3], buyingPowerIndex: t[4] }; });
  const toUSD = (local, code) => local / ECON[code].fxLocalPerUSD;
  const fromUSD = (usd, code) => usd * ECON[code].fxLocalPerUSD;
  /* base units (Norway-priced) ↔ USD */
  const baseToUSD = b => b / NOKUSD, usdToBase = u => u * NOKUSD;
  window.R20 = { ECON, toUSD, fromUSD, baseToUSD, usdToBase };

  /* apply the indices once, and carry them into the cities that were built from the old numbers */
  Object.keys(CO).forEach(k => {
    const c = CO[k], e = ECON[k];
    if (!e) return;
    const pl = Math.round(e.costIndex / REF[2] * 100) / 100, wage = Math.round(e.wageIndex / REF[3] * 100) / 100;
    const opl = c.pl || 1, ow = c.wage || 1, om = c.mkt || 1;
    (c.cities || []).forEach(ct => {
      ct.wage = Math.round(ct.wage / ow * wage * 100) / 100;
      ct.price = Math.round(ct.price / opl * pl * 100) / 100;
      ct.dem = Math.round(ct.dem / om * 100) / 100;
    });
    c.pl = pl;
    c.wage = wage;
    c.mkt = 1;
    c.bp20 = e.buyingPowerIndex / REF[4];
  });

  /* affordability: low incomes cut back hard on expensive things, a little on cheap ones; dear prices and a weak name hurt more */
  function afford(co, bd) {
    const c = CO[co.country] || CC();
    const bp = c.bp20 || 1;
    if (Math.abs(bp - 1) < 0.005) return 1;
    const tk = Math.max(1, (bd.ticket || 100) * (bd.rm || 1));
    const dear = clamp(Math.log10(tk / 150) / 2.5, 0, 1);
    const b2b = bd.aud || 0;
    let ex = (0.2 + 0.9 * dear) * (1 - 0.6 * b2b) * clamp(priceMult(co), 0.7, 1.6);
    ex *= 1 - 0.15 * clamp(((co.rep || 50) - 50) / 50, 0, 1);
    return Math.pow(bp, ex);
  }
  R20.afford = afford;
  addStep('demand', 50, 'what local people can afford', (co, bd, r) => {
    if (bd && bd.Dc && ['fin', 'energy', 'hold', 'club'].indexOf(bd.fam) < 0) { const a = afford(co, bd); if (a !== 1) { r.D *= a; r.parts.affordability = a; } }
  });

  /* euro countries move together */
  addStep('fxMonth', 10, 'euro countries move together', (r) => {
    const eur = Object.keys(CO).filter(k => CO[k].cur === 'EUR');
    const home = eur.indexOf(S.country) >= 0;
    const v = home ? 1 : (S.fxd[eur.find(k => S.fxd[k]) ] || 1);
    eur.forEach(k => { S.fxd[k] = v; });
  });
  /* saves made before this round: euro drift values may differ, line them up at load */
  window.deserialize = pipeView('window.deserialize', window.deserialize, 0); /* window.deserialize: the screen above, then the steps below and in later files */
  addStep('window.deserialize', 10, 'saves made before this round: euro drift values may differ, line them up at load', (r) => {
    try { if (r && S && S.fxd) { const eur = Object.keys(CO).filter(k => CO[k].cur === 'EUR'); const v = eur.indexOf(S.country) >= 0 ? 1 : (S.fxd.DE || S.fxd[eur.find(k => S.fxd[k])] || 1); eur.forEach(k => { S.fxd[k] = v; }); } } catch (e) { console.error(e); }
    return r;
  });

  /* checks you can run from the console: R20.validate() */
  R20.validate = function () {
    const out = [];
    Object.keys(CO).forEach(k => {
      const c = CO[k], e = ECON[k];
      if (!e) { out.push(k + ': no config'); return; }
      ['fxLocalPerUSD', 'costIndex', 'wageIndex', 'buyingPowerIndex'].forEach(f => { if (!(e[f] > 0)) out.push(k + ': bad ' + f); });
      if (e.currency !== c.cur) out.push(k + ': currency ' + c.cur + ' vs ' + e.currency);
      const want = NOKUSD / e.fxLocalPerUSD;
      if (Math.abs(c.fx / want - 1) > 0.002) out.push(k + ': fx ' + c.fx + ' vs ' + want.toFixed(5));
      const back = toUSD(fromUSD(123.45, k), k);
      if (Math.abs(back - 123.45) > 1e-9) out.push(k + ': round trip ' + back);
    });
    const eur = Object.keys(CO).filter(k => CO[k].cur === 'EUR');
    if (new Set(eur.map(k => fxr(CO[k]).toFixed(6))).size > 1) out.push('EUR rates differ: ' + eur.map(k => k + ' ' + fxr(CO[k])).join(', '));
    return out.length ? out : ['ok: ' + Object.keys(CO).length + ' countries'];
  };
}


/* ===== Round 8: realistic odds. Demand follows how known you are, a hidden "fit" decides how well the
   concept lands, price and choice effects drift with seasons, prices can follow inflation or not,
   and each business type earns a realistic margin when run well. Pay yourself is compact and holds your hours. ===== */
{
  const P = o => esc(JSON.stringify(o));
  const pillp = (t, c) => '<span class="pill ' + (c || '') + '">' + t + '</span>';
  const NOWORK = { rent: 1, fin: 1, energy: 1, club: 1, hold: 1 };
  /* demand level (KT) and price level (PF) per business type, tuned by simulation so a well-run firm earns its typical margin */
  const R8 = window.R8 = window.R8 || { K: 1.3, KT: {"cons":1.89,"tutor":1.08,"carclean":3.33,"photo":2.05,"handy":1.64,"cleaning":1.83,"webdev":1.46,"mktg":1.55,"law":1.37,"acctfirm":2.41,"staffing":0.71,"barber":2.46,"drivsk":2.64,"physio":2.02,"estate":1.84,"pets":1.68,"foodtruck":1.96,"cafe":1.53,"restaurant":1.2,"nightclub":1.46,"gym":1.48,"hotel":1.1,"casino":1.24,"fun":1.16,"kiosk":1.62,"boutique":3.26,"webshop":1.86,"grocery":1.17,"hardware":0.99,"cardealer":1.38,"construction":1.33,"electrician":1.06,"plumber":1.2,"event":1.16,"engcons":1.66,"bakery":1.3,"brewery":1.99,"furniture":3.22,"factory":0.98,"farm":1.72,"courier":1.96,"trucking":1.35,"shipping":0.96,"taxi":2.7,"carrepair":1.5,"wh3pl":2.8,"indoorski":3,"dental":3,"gamestudio":2.8,"security":4.2,"vineyard":7,"pcbang":3.3,"carrental":8}, PF: {"cleaning":1.33,"webdev":0.92,"mktg":0.8,"law":1.71,"acctfirm":1.36,"staffing":1.26,"barber":1.33,"drivsk":1.07,"physio":1.05,"estate":1.4,"pets":1.61,"foodtruck":1.84,"cafe":1.22,"restaurant":1.97,"nightclub":1.54,"gym":1.45,"hotel":1.43,"casino":1.43,"fun":2.13,"kiosk":0.76,"boutique":0.97,"webshop":0.98,"grocery":1.32,"hardware":1.96,"cardealer":1.77,"construction":2.39,"electrician":1.61,"plumber":1.46,"event":1.36,"engcons":2.5,"bakery":1.98,"brewery":1.74,"furniture":1.4,"factory":1.76,"farm":2.5,"taxi":0.85,"courier":1.23,"trucking":1.63,"shipping":1.24,"airline":1.01,"cons":0.68,"tutor":1.15,"carclean":1.08,"photo":0.87,"handy":0.83}, FIT: 0.35 };

  /* typical net margin for a decent, established operator (owner-run trades earn more, because the owner is not paid as staff) */
  const MT = { cons: 0.18, tutor: 0.2, carclean: 0.12, photo: 0.15, handy: 0.12, cleaning: 0.06, webdev: 0.12, mktg: 0.1, law: 0.2, acctfirm: 0.18, staffing: 0.04, barber: 0.1, drivsk: 0.12, physio: 0.14, estate: 0.12, pets: 0.1, foodtruck: 0.07, cafe: 0.06, restaurant: 0.05, nightclub: 0.08, gym: 0.1, hotel: 0.1, casino: 0.2, fun: 0.1, kiosk: 0.04, boutique: 0.06, webshop: 0.06, grocery: 0.03, hardware: 0.04, cardealer: 0.03, construction: 0.06, electrician: 0.1, plumber: 0.1, realdev: 0.12, event: 0.08, engcons: 0.12, bakery: 0.07, brewery: 0.1, furniture: 0.07, salmon: 0.2, factory: 0.08, farm: 0.08, taxi: 0.07, courier: 0.04, trucking: 0.05, shipping: 0.08, airline: 0.04, dental: 0.15, gamestudio: 0.12, security: 0.06, vineyard: 0.14, pcbang: 0.1, carrental: 0.1 };
  R8.MT = MT;
  Object.keys(MT).forEach(t => {
    const bd = BD[t];
    if (!bd || NOWORK[bd.fam]) return;
    bd.m = MT[t];
    bd._c = 0;
    calib(bd);
    bd.capD = bd.Dc / 0.95;
  });

  /* smooth seeded noise between 0 and 1 */
  const nz = (key, wk, span) => { const b = Math.floor(wk / span), f = wk / span - b; const a = hrng(S.seed + ':' + key + ':' + b)(), c = hrng(S.seed + ':' + key + ':' + (b + 1))(); return a + (c - a) * (f * f * (3 - 2 * f)); };
  const wave = (key, wk) => Math.sin(2 * Math.PI * (wk + hrng(S.seed + ':ph:' + key)() * 52) / 52);

  /* the concept's hidden fit: location, timing, idea. Nobody sees it, results show it */
  function fitOf(co) {
    if (co.fit == null) {
      const R = hrng(S.seed + ':fit:' + co.id), u = Math.max(1e-6, R()), v = R();
      co.fit = Math.round(clamp(Math.exp(Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v) * R8.FIT), 0.5, 1.7) * 1000) / 1000;
    }
    return co.fit;
  }
  /* being known matters: an unknown new business gets few customers */
  window.mktMult = co => 0.08 + 1.5 * Math.pow(clamp(co.aware || 0, 0, 100) / 100, 0.8);

  /* price effects are not fixed: cheaper does not always bring more people, dearer does not always lose them */
  function elast(co, bd) {
    const pd = priceDem(co, bd);
    if (Math.abs(pd - 1) < 1e-6) return 1;
    let m2 = clamp(0.8 + 0.3 * wave('el' + co.id, S.week) + 0.4 * (nz('el' + co.id, S.week, 6) - 0.5), 0.2, 1.4);
    if ((co.price || 0) > 0 && (co.q || 50) > 68) m2 *= 0.6;
    return Math.pow(pd, m2 - 1);
  }
  const igOf = co => co.ig || 1;
  /* small contractors take more, smaller jobs */
  const jobScale = co => clamp(0.5 * Math.pow(clamp(co.size || 1, 0.3, 1.5), 0.9), 0.15, 0.8);
  R8.jobScale = jobScale;
  /* a bigger customer-facing team brings in more customers (salespeople, waiters, agents, professionals with their
     own clients); back-office, kitchen, cleaning and technical roles add capacity but do not bring customers */
  const FACE = { consult: 1, tutor: 1, carwash: 1, photog: 1, handy: 1, sales: 1, marketer: 1, lawyer: 1, recept: 1, acct: 1, barber: 1, instr: 1, physio: 1, estate: 1, groom: 1, barista: 1, waiter: 1, bartender: 1, dj: 1, trainer: 1, dealer: 1, cashier: 1, usher: 1, cardealer: 1, event: 1, agent: 1, banker: 1, teller: 1, driver: 1, elec: 1, plumb: 1, architect: 1, mech: 1, liftop: 1, skiinst: 1 };
  R8.FACE = FACE;
  function demRef(co, bd, plusRole) {
    const fr = bd.std.filter(x => FACE[x[0]]);
    /* no customer-facing jobs (a factory, a haulier): demand follows the planned size of the business, not its headcount */
    if (!fr.length) return 0.5 * (co.size || 1) + 0.5 * clamp(co.size || 1, 0.2, 2.5);
    const ownF = FACE[bd.std[0][0]] ? (bd.own || 0) : 0;
    const heads = fr.reduce((s, x) => s + x[1], 0) + ownF;
    const have = co.staff.filter(s2 => FACE[s2.role]).length + (plusRole && FACE[plusRole] ? 1 : 0) + (co.mgr ? 0.5 : Math.min(1, (co.ohrs || 0) / 40) * ownF);
    return 0.5 * (co.size || 1) + 0.5 * clamp(have / Math.max(1, heads), 0.2, 2.5);
  }
  R8.demRef = demRef;
  addStep('demand', 20, 'local market size, fit and price', (co, bd, r) => {
    if (!bd.Dc || NOWORK[bd.fam]) return r;
    const city = cityOf(co.city);
    const k = R8.KT[bd.id] || R8.K;
    const ref = demRef(co, bd, null);
    const scale = ref * k * Math.pow(city.dem, 0.3) / (DK * city.dem);
    const pe = elast(co, bd), inf = Math.pow(igOf(co), (bd.ela || 1) * 0.7);
    r.D *= scale * fitOf(co) * pe * inf * (bd.fam === 'project' && !bd.tw.dev ? 1 / jobScale(co) : 1);
    r.parts.price = (r.parts.price || 1) * pe * inf;
  });
  /* business choices: their pull on customers drifts with the season */
  addStep('knobFx', 10, 'business choices: their pull on customers drifts with the season', (co, key, mode, r) => {
    if (key !== 'd' || mode === 'sum' || !co || r === 1 || !S) return r;
    const m = clamp(1 + 0.4 * wave('kn' + co.id, S.week) + 0.4 * (nz('kn' + co.id, S.week, 8) - 0.5), 0.25, 1.6);
    return 1 + (r - 1) * m;
  });

  /* customers who had a good experience tell others; a shop on a busy street is seen */
  addStep('weekCo.after', 20, 'happy customers tell others; held prices fall behind inflation', (co, ph) => {
    const bd = BD[co.type];
    if (co.st === 'open' && bd && bd.Dc && !NOWORK[bd.fam]) {
      const ref = bd.capD * (co.size || 1);
      const served = co.lastW && ref > 0 ? Math.min(1, (co.lastW.units || 0) / ref) : 0;
      const qf = clamp(((co.q || 50) - 40) / 35, 0, 1.4);
      /* round 56: word of mouth on its own settles around 10-15 points of awareness (it fades about 4.5% a week);
         growing beyond that takes marketing, a busy street or a reputation that gets talked about */
      let g = 0.45 * served * qf;
      if (co.prem && co.prem.m2 && isFoot(co.prem.kind)) g += 0.35 * (co.prem.loc || 1);
      co.aware = clamp(co.aware + g, 0, 100);
    }
    if (co.inflHold) co.ig = igOf(co) * (1 + (S.econ.infl || 0.02) / 52);
  });

  /* ---------- inflation: follow it, or hold prices to win customers and squeeze rivals ---------- */
  addStep('ticketMult', 10, '---------- inflation: follow it, or hold prices to win customers and squeeze rivals ----------', (co, bd, r) => {
    return co && co.ig && co.ig !== 1 ? r / co.ig : r;
  });
  ACTS.infl = (m, idx) => {
    const co = getCo(m.co);
    if (!co) return true;
    if (idx === 1) co.inflHold = 1;
    else { co.inflHold = 0; co.ig = 1; }
    return true;
  };
  addStep('week.before', 20, 'remember the year', (ctx) => { ctx.y0 = S ? wYear(S.week) : 0; });
  addStep('week.after', 60, 'new year: follow inflation or hold prices; weak rivals squeezed', (ctx) => {
    {
      if (S && !S.over && wYear(S.week) !== ctx.y0) {
        const pr = Math.round((S.econ.infl || 0.02) * 1000) / 10;
        S.cos.filter(c => c.st === 'open' && BD[c.type] && BD[c.type].Dc && !NOWORK[BD[c.type].fam]).forEach(co => {
          if (co.mgr) { if (!co.inflHold) co.ig = 1; return; }
          addMsg({ kind: 'ask', from: 'Your accountant', title: 'New year: follow inflation at ' + co.name + '?', body: 'Prices in your market rose about ' + pr + '% last year. Raise yours to match, or hold them to win customers and squeeze weaker rivals. Your own costs rise either way.', co: co.id, opts: [{ l: 'Follow inflation', d: '', fx: {} }, { l: 'Hold my prices', d: '', fx: {} }], act: 'infl', exp: S.week + 3 });
        });
      }
      S.cos.forEach(co => {
        if (co.st !== 'open' || igOf(co) < 1.02) return;
        const rs = rivalsOf(co), weak = rs.filter(x => x.size < 0.8).sort((a, b) => a.size - b.size)[0];
        if (weak && chance(0.004 * (igOf(co) - 1) * 100)) {
          weak.size = Math.round((weak.size - 0.05) * 100) / 100;
          if (weak.size < 0.35) {
            const m = ensureMk(co);
            m.riv = (m.riv || []).filter(x => x !== weak);
            m.n = Math.max(1, m.n - 1);
            note(weak.name + ' could not keep up with your prices and closed.', 'good', co.id);
          }
        }
      });
    }
  });
  ACT.inflset = p => {
    const co = getCo(p.id);
    if (p.v) { co.inflHold = 0; co.ig = 1; } else co.inflHold = 1;
    save();
    render();
  };
  /* how far behind the market a company is that holds its prices (shown on the Sales dashboard) */
  R8.inflGap = co => igOf(co) - 1;
  R8.noPrice = bd => !!NOWORK[bd.fam];

  /* ---------- Pay yourself: compact, with your hours ---------- */
  window.ownerHoursRow = () => '';
  function hoursCard(co) {
    if (co.mgr) return '';
    const used = hoursUsed(co), left = HCAP - used, f = S.fat || 0;
    const fw = S.burnUntil && S.week < S.burnUntil ? ['Burned out', 'red'] : f >= 70 ? ['Exhausted', 'red'] : f >= 40 ? ['Tired', 'amb'] : ['Rested', 'grn'];
    return '<div class="card"><div class="bhead"><b>Your hours here</b>' + pillp(fw[0], fw[1]) + '</div><div class="chips hrs">' + [0, 10, 20, 30, 40, 50, 60].map(v => '<button class="btn chip' + (co.ohrs === v ? ' primary' : '') + (v > left ? ' dim' : '') + '" data-a="ownhrs" data-p="' + P({ id: co.id, v }) + '">' + v + '</button>').join('') + '</div><small class="muted">' + (used + (co.ohrs || 0)) + ' of ' + HCAP + ' h a week in total · above 55 h you wear out</small></div>';
  }
  const avail = co => co.form === 'AS' ? divMax(co) : Math.max(0, Math.floor(co.cash - coWeekCost(co) * 2));
  V.payself = function (p) {
    const co = getCo(p.id);
    if (!co) return '<div class="calm">Company not found.</div>';
    const c = CO[co.country] || CC(), AS = co.form === 'AS';
    const av = avail(co), sal = AS ? (co.ownerSalary || 0) * 12 : 0;
    const out = Math.max(0, Math.min(av, U.inum('amtOut', 0))), leave = Math.max(0, av - out), tot = sal + out + leave || 1;
    const tax = (sal ? personalTax(sal, 'wage') : 0) + (AS ? out * c.divTax : 0);
    const after = co.cash - out, buf = Math.round(coWeekCost(co) * 8.7);
    let h = '<div class="tri"><div><span>You take out</span><b>' + mshort(sal + out) + '</b></div><div><span>Tax</span><b class="neg">' + (AS ? '−' + mshort(tax) : 'On profit') + '</b></div><div><span>Company after</span><b class="' + (after < buf ? 'amb' : sgn(after)) + '">' + mshort(after) + '</b></div></div>';
    h += hoursCard(co);
    h += '<div class="card split3">';
    if (AS) h += '<div class="bhead"><b>Salary</b><small>' + mshort(co.ownerSalary || 0) + '/mo · ~' + Math.round((sal ? personalTax(sal, 'wage') / sal : 0) * 100) + '% tax</small></div>' + bar(sal / tot * 100, 'var(--amber)') + chips([0, 20000, 40000, 60000, 80000].map(niceAmt).map(v => [v, v ? mshort(v) : 'None']), co.ownerSalary, 'cosal', { id: co.id });
    h += '<div class="bhead"><b>' + (AS ? 'Dividend' : 'Take out') + '</b><small>up to ' + mshort(av) + (AS ? ' · ' + pc(c.divTax, 0) + ' tax' : '') + '</small></div>' + bar(out / tot * 100, 'var(--blue)') + '<div class="crow">' + U.inp('amtOut', 'Amount', null) + btn(AS ? 'Pay' : 'Take out', AS ? 'cdiv' : 'cdraw', { id: co.id }, 'primary') + '</div>' + U.pctChips('amtOut', av);
    h += '<div class="bhead"><b>Leave in the company</b><small>' + mshort(leave) + '</small></div>' + bar(leave / tot * 100, 'var(--green)') + '</div>';
    if (after < buf) h += '<div class="note bad">Leaves less than two months of costs (' + mshort(buf) + ') in the company.</div>';
    h += '<div class="card"><div class="bhead"><b>Put money in</b><small>' + mshort(Math.max(0, liquid())) + ' available</small></div><div class="crow">' + U.inp('amtIn', 'Amount', null) + btn('Put in', 'cinject', { id: co.id }, '') + '</div></div>';
    const loans = S.loans.filter(l => l.co === co.id), hold = S.cos.some(x => x.type === 'hold' && x.st === 'open');
    h += '<div class="lrows">' + (loans.length ? '<button class="lrow" data-a="cofin" data-p="' + P({ id: co.id, s: 'loans' }) + '"><span class="ctext"><b>Pay down the loan</b></span><b class="pos">Saves ' + pc(loanRate(loans[0]), 1) + '</b><i>›</i></button>' : '') + '<button class="lrow" data-a="go" data-p="' + P({ n: hold ? 'holdings' : 'newhold' }) + '"><span class="ctext"><b>Send to a holding</b></span><b class="' + (hold ? 'pos' : '') + '">' + (hold ? 'Almost tax-free' : 'Set one up') + '</b><i>›</i></button><button class="lrow" data-a="cosub" data-p="' + P({ id: co.id, s: 'assets' }) + '"><span class="ctext"><b>Buy equipment</b></span><b>Lowers tax</b><i>›</i></button></div>';
    return h;
  };
}

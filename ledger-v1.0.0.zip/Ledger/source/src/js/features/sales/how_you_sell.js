/* ===== Round 56: How you sell is your strategy (Sales › How you sell).
   Every trade has two or three choices that shape everything else (its knobs in engine/businesses/*.js):
   - a strategy choice is one of a few (who you are for, how you work, where you sell). Each option shows what it does
     to customers, the price of a sale, costs and risk, and before you switch you see this week's numbers both ways.
     Switching is a changeover: a cost and a few weeks at reduced capacity while you refit and retrain
   - a group of add-ons (KM in engine/businesses/_helpers.js, a bitmask in co.knob) can run together: a kiosk can sell
     tobacco, beer, lottery and parcels at once. Each brings more customers or a bigger basket, some cost to run, some
     need a licence (applied for on the spot)
   At the bottom, the whole strategy in one sentence. A registered chain sets these for every store in its rules. ===== */
window.HYS56 = window.HYS56 || {};
(function () {
  const H = window.HYS56;
  const U = window.UI;
  if (!U) return;
  const { ui, ACT, esc, btn, row, render, save, toast, confirmThen, res } = U;
  const P = o => esc(JSON.stringify(o));
  const isOn = (co, k, i) => k.multi ? !!((co.knob[k.id] || 0) & (1 << i)) : (co.knob[k.id] || 0) === i;
  /* this week's numbers with a different setting of one choice */
  function weekWith(co, bd, kid, val) {
    const had = Object.prototype.hasOwnProperty.call(co.knob, kid), old = co.knob[kid];
    if (val != null) co.knob[kid] = val;
    try {
      const D = demand(co, bd).D || 0, cap = (capacity(co, bd) || {}).cap || 0, u = Math.min(D, cap || D), tk = ticketEff(co, bd);
      const w = co.lastW || {}, vr = w.rev > 0 ? clamp((w.cogs || 0) / w.rev, 0, 0.95) : (bd.cogs || 0.3);
      const c = knobFx(co, 'c', 'sum'), wk = KC(knobFx(co, 'w', 'sum') || 0, co.country);
      return { D, cap, u, tk, rev: u * tk, gross: u * tk * (1 - vr - c) - wk };
    } catch (e) { return { D: 0, cap: 0, u: 0, tk: 0, rev: 0, gross: 0 }; }
    finally { if (had) co.knob[kid] = old; else delete co.knob[kid]; }
  }
  H.weekWith = weekWith;
  /* trade-offs as four little bars: customers, price of a sale, costs, risk */
  const lvl = (v, base) => { const r = v / base; return r >= 1.4 ? 4 : r >= 1.12 ? 3 : r > 0.92 ? 2 : r > 0.7 ? 1 : 0; };
  const bars = n => '<i>' + '▮'.repeat(n) + '<span>' + '▮'.repeat(4 - n) + '</span></i>';
  function trade(o) {
    const f = o.fx || {};
    const cust = (f.d || 1) * (f.k ? Math.sqrt(f.k) : 1);
    const cost = 1 + (f.c || 0) * 6 + (f.w ? Math.min(0.6, f.w / 8000) : 0);
    return '<div class="tradeoff"><span>Customers ' + bars(lvl(cust, 1)) + '</span><span>Price of a sale ' + bars(lvl(f.t || 1, 1)) + '</span><span>Costs ' + bars(lvl(cost, 1)) + '</span><span>Risk ' + bars(lvl(f.r || f.risk || 1, 1)) + '</span></div>';
  }
  /* the changeover when a strategy choice is switched */
  function changeover(co, bd, k, i) {
    const cur = k.opts[co.knob[k.id] || 0] || {}, nx = k.opts[i] || {};
    const a = cur.fx || {}, b = nx.fx || {};
    const shift = Math.abs(Math.log((b.t || 1) / (a.t || 1))) + Math.abs(Math.log((b.d || 1) / (a.d || 1))) + Math.abs((b.q || 0) - (a.q || 0)) / 10;
    const weeks = shift < 0.15 ? 1 : shift < 0.5 ? 2 : shift < 1 ? 3 : 4;
    const base = Math.max(KC(8000, co.country), ((co.lastW && co.lastW.rev) || KC(20000, co.country)) * 0.6);
    const cost = rnl(base * weeks * (b.q > (a.q || 0) ? 1.4 : 1), 1000);
    return { weeks, cost };
  }
  H.changeover = changeover;
  const reqTxt = (co, o) => { const m = (o.fx.req || []).filter(d => !docOk(co, d)); return m.length ? 'Needs ' + m.map(d => docDef(d, co.country)[0].toLowerCase()).join(' and ') : ''; };

  /* the row on the Sales tab */
  H.summary = function (co, bd) {
    const s = [];
    bd.knobs.forEach(k => { const L = knobOpts(co, k); if (k.multi) { if (L.length) s.push('+ ' + L.map(o => o.n.toLowerCase()).join(', ')); } else if (L[0]) s.push(L[0].n); });
    return s.join(' · ');
  };

  /* the page */
  H.page = function (co, bd) {
    if (!bd.knobs || !bd.knobs.length) return '<div class="calm">' + esc(bd.n) + ' has no strategy choices of its own. Prices, marketing and ways to sell are on the Sales tab.</div>';
    const ch = window.R12 && R12.chainOf ? R12.chainOf(co) : null;
    let h = '<div class="card mk"><b>Your strategy</b><span class="tipt">' + (ch ? 'Set by the chain ' + esc(ch.name) + ' for every store. Change it in the chain rules.' : 'The choices that shape everything else. Each one moves customers, price, costs and risk.') + '</span>';
    const now = weekWith(co, bd, '__', null);
    bd.knobs.forEach(k => {
      if (k.multi) {
        h += '<div class="axis"><div class="lab2"><b>' + esc(k.n) + '</b><span>several at once</span></div><div class="chipfit">' + k.opts.map((o, i) => {
          const on = isOn(co, k, i), rq = reqTxt(co, o);
          return '<button class="btn chip' + (on ? ' primary' : '') + (ch ? ' cant' : '') + '" data-a="hysTog" data-p="' + P({ id: co.id, k: k.id, i }) + '">' + (on ? '✓ ' : '+ ') + esc(o.n) + '<small>' + esc(rq || fxShort(o.fx)) + '</small></button>';
        }).join('') + '</div><small class="muted">' + esc(k.d || '') + '</small></div>';
        return;
      }
      const cur = co.knob[k.id] || 0, pend = ui.hys56 && ui.hys56.id === co.id && ui.hys56.k === k.id ? ui.hys56.i : cur;
      /* only what the country allows (a farm's crops by climate); more than four become chips */
      const ix = k.opts.map((o, i) => i).filter(i => knobOk(co, k.opts[i]) || i === cur);
      if (ix.length > 4) h += '<div class="axis"><div class="lab2"><b>' + esc(k.n) + '</b><span>' + esc((k.opts[cur] || {}).n || '') + ' now</span></div><div class="chipfit">' + ix.map(i => '<button class="btn chip' + (i === pend ? ' primary' : '') + '" data-a="hysPick" data-p="' + P({ id: co.id, k: k.id, i }) + '">' + esc(k.opts[i].n) + '</button>').join('') + '</div>';
      else h += '<div class="axis"><div class="lab2"><b>' + esc(k.n) + '</b><span>' + esc((k.opts[cur] || {}).n || '') + ' now</span></div><div class="seg3" style="grid-template-columns:repeat(' + ix.length + ',1fr)">' + ix.map(i => k.opts[i]).map((o, j) => { const i = ix[j]; return '<button class="' + (i === pend ? 'on' : '') + (i === cur ? ' cur' : '') + '" data-a="hysPick" data-p="' + P({ id: co.id, k: k.id, i }) + '">' + esc(o.n) + '</button>'; }).join('') + '</div>';
      const o = k.opts[pend];
      h += trade(o) + '<small class="muted">' + esc(o.d || '') + '</small>';
      if (pend !== cur && !ch) {
        const w = weekWith(co, bd, k.id, pend), co2 = changeover(co, bd, k, pend);
        const dg = w.gross - now.gross;
        h += '<div class="cmp56"><div><span>Customers a week</span><b>' + Math.round(now.u) + ' → ' + Math.round(w.u) + '</b></div><div><span>Average sale</span><b>' + mshort(now.tk) + ' → ' + mshort(w.tk) + '</b></div><div><span>Profit a month</span><b class="' + (dg >= 0 ? 'pos' : 'neg') + '">' + (dg >= 0 ? '+' : '−') + mshort(Math.abs(dg * 52 / 12)) + '</b></div></div>' +
          (reqTxt(co, o) ? '<small class="neg">' + esc(reqTxt(co, o)) + ' (applied for when you switch)</small>' : '') +
          btn('Switch to ' + esc(o.n) + ' · ' + mshort(co2.cost) + ', ' + co2.weeks + (co2.weeks > 1 ? ' weeks' : ' week') + ' of changeover', 'hysGo', { id: co.id, k: k.id, i: pend }, 'primary wide' + (co.cash < co2.cost ? ' cant' : ''));
      }
      h += '</div>';
    });
    h += '</div>';
    /* the whole strategy in one sentence, and how it fits the place */
    const city = cityOf(co.city), single = bd.knobs.filter(k => !k.multi).map(k => (k.opts[co.knob[k.id] || 0] || {}));
    const prem = single.some(o => (o.fx.t || 1) >= 1.3), budget = single.some(o => (o.fx.t || 1) <= 0.85);
    const fit = prem && (city.price || 1) < 0.95 ? 'A premium choice in a place where people watch their money: fewer customers than you would get in a big city.' : budget && (city.price || 1) > 1.1 ? 'A budget choice in an expensive city: plenty of customers, thin margins.' : 'A sensible fit for ' + esc(city.name) + '.';
    h += '<div class="card"><b>' + esc(H.summary(co, bd)) + '</b><span class="tipt">' + fit + ' This week: about ' + Math.round(now.u) + ' ' + esc(unitPl(bd.unit, now.u)) + ' at ' + mshort(now.tk) + ' on average.</span></div>';
    if (co.hys56c && co.hys56c.end > S.week) h += '<div class="note">Changeover to ' + esc(co.hys56c.n) + ' until ' + dateStr(co.hys56c.end) + ': the place runs at reduced capacity.</div>';
    return h;
  };
  function fxShort(f) {
    const p = [];
    if (f.d && f.d !== 1) p.push((f.d > 1 ? '+' : '−') + Math.round(Math.abs(f.d - 1) * 100) + '% customers');
    if (f.t && f.t !== 1) p.push((f.t > 1 ? '+' : '−') + Math.round(Math.abs(f.t - 1) * 100) + '% per sale');
    if (f.w) p.push('costs to run');
    return p.slice(0, 2).join(', ') || 'small effect';
  }
  ACT.hysPick = p => { const co = getCo(p.id), k = co && BD[co.type].knobs.find(x => x.id === p.k); if (k && !knobOk(co, k.opts[+p.i])) return; ui.hys56 = { id: p.id, k: p.k, i: +p.i }; render(); };
  ACT.hysGo = p => {
    const co = getCo(p.id), bd = co && BD[co.type], k = bd && bd.knobs.find(x => x.id === p.k);
    if (!k || k.multi) return;
    const c = changeover(co, bd, k, +p.i);
    if (co.cash < c.cost) { toast('Not enough cash in ' + co.name + '.', true); return; }
    const run = () => {
      payCo(co, c.cost, 'oth', 'Changeover to ' + k.opts[+p.i].n);
      co.knob[k.id] = +p.i;
      addMod(co, 'cap', 0.75, c.weeks);
      co.hys56c = { n: k.opts[+p.i].n, end: S.week + c.weeks };
      ui.hys56 = null;
      save(); render(); toast(co.name + ' switches to ' + k.opts[+p.i].n.toLowerCase() + '.');
    };
    const miss = knobReqMissing(co, k, +p.i);
    if (miss.length) confirmThen('Documents needed', 'This needs ' + miss.map(d => docDef(d, co.country)[0]).join(', ') + '. Apply now? It works once they are approved.', 'Apply and switch', () => { miss.forEach(d => { const r = applyDoc(co, d); if (r !== 'ok' && r !== 'have') res(r); }); run(); });
    else run();
  };
  ACT.hysTog = p => {
    const co = getCo(p.id), bd = co && BD[co.type], k = bd && bd.knobs.find(x => x.id === p.k);
    if (!k || !k.multi) return;
    if (window.R12 && R12.chainOf && R12.chainOf(co)) { toast('The chain sets this. Change it in the chain rules.', true); return; }
    const bit = 1 << +p.i, on = (co.knob[k.id] || 0) & bit;
    const run = () => { co.knob[k.id] = (co.knob[k.id] || 0) ^ bit; save(); render(); };
    if (on) return run();
    const miss = knobReqMissing(co, k, +p.i);
    if (miss.length) confirmThen('Documents needed', esc(k.opts[+p.i].n) + ' needs ' + miss.map(d => docDef(d, co.country)[0]).join(', ') + '. Apply now? It starts once they are approved.', 'Apply', () => { miss.forEach(d => { const r = applyDoc(co, d); if (r !== 'ok' && r !== 'have') res(r); }); run(); });
    else run();
  };
})();

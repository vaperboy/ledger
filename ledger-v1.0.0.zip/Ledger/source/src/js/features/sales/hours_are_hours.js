/* ===== Round 34: hours are hours.
   - Trades that sell time (consulting, law, accounting, tutoring, cleaning, car cleaning, hair, physio...) now get the
     output their hours allow: a full-time worker gives 37.5 h times the trade's productive share, and the owner's own
     hours count one for one (60 h of a consultant's week is about 36 billable hours, not 7).
   - Equipment and space for those trades scale the same way, so a laptop serves a person, not 7 hours.
   - Every working day has its own share of the week's capacity: a backlog can no longer use up the whole week on Monday.
   - Hired staff work at least their contract: 37.5 h over five days, more on busy days. ===== */
window.R34 = window.R34 || {};
(function () {
  const R34 = window.R34;
  /* hours per unit sold, and the share of working hours that is productive (game estimates) */
  const T = {
    cons: [1, 0.7], law: [1, 0.7], acctfirm: [1, 0.75], mktg: [1, 0.7], webdev: [1, 0.75], tutor: [1, 0.8], cleaning: [1, 0.9],
    carclean: [1.5, 0.8], carrepair: [2.5, 0.8], handy: [3, 0.75], photo: [6, 0.7], barber: [0.75, 0.8], drivsk: [1, 0.85], physio: [0.75, 0.8], pets: [0.5, 0.85], estate: [50, 0.6],
    dental: [0.75, 0.8], gamestudio: [1, 0.75], security: [1, 0.9]
  };
  R34.T = T;
  addStep('capacity', 50, 'services sell hours', (co, bd, r) => {
    {
      const t = bd && T[bd.id];
      if (!t || !r || !r.parts || !r.parts.length) return r;
      const per = 37.5 * t[1] / t[0];                                  /* units per full-time worker per week */
      const role0 = r.parts.find(p => p.kind === 'staff');
      if (!role0 || !(role0.capPer > 0)) return r;
      const R = Math.max(1, per / role0.capPer);
      const ownFTE = sum(r.parts, p => p.owner || 0);
      /* the owner's own hours, one for one; a manager's working share as before */
      const ownUnits = co.mgr ? ownFTE * role0.capPer * R : (co.ohrs || 0) * t[1] / t[0] * (0.85 + 0.3 * (co.oskill || 0) / 100);
      let cap = Infinity, bot = null;
      r.parts.forEach(p => {
        if (p.kind === 'staff') p.cap = Math.max(0, (p.have - (p.owner || 0))) * p.capPer * R + (ownFTE > 0 ? ownUnits * (p.owner || 0) / ownFTE : 0);
        else if (p.kind === 'equip') p.cap = Math.max(p.cap * R, (p.have || 0) * 60 * t[1] / t[0]); /* one set of tools serves one person, even on a 60-hour week */
        else if (p.kind === 'space') p.cap *= R;
        if (p.capPer) p.capPer *= R;
        if (p.cap < cap) { cap = p.cap; bot = p; }
      });
      if (!isFinite(cap)) return r;
      r.cap = Math.max(0, cap * knobFx(co, 'k') * modProd(co, 'cap'));
      r.bot = bot;
    }
  });
})();


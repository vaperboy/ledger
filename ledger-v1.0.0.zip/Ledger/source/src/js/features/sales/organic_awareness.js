/* ===== Organic awareness: people find a business without advertising.
   A shop on a street is seen by passers-by, a local service turns up in maps and search, a business that serves
   people well is talked about. Awareness drifts toward this organic level a little each week; advertising pushes
   above it faster. Bad reviews pull the level down. ===== */
{
  const KIND = { venue: 1, retail: 1 };
  const ONLINE = { webshop: 1, webdev: 1, mktg: 1, tutor: 1 };
  function organic(co, bd) {
    if (!bd.Dc || ['fin', 'energy', 'hold', 'club', 'rent'].indexOf(bd.fam) >= 0) return 0;
    const pk = co.prem && co.prem.kind, foot = pk && isFoot(pk);
    /* round 56: destinations are found by everyone who looks for one: a ski resort, a ski hall, an amusement park */
    const DEST = { skires: 38, indoorski: 30, fun: 24 };
    let base = DEST[bd.id] || (foot ? 20 : ONLINE[bd.id] ? 9 : bd.fam === 'project' || bd.fam === 'prod' ? 10 : bd.fam === 'logi' ? 11 : 12);
    if (foot && co.prem && co.prem.loc) base *= clamp(co.prem.loc, 0.8, 1.25);
    /* smaller towns: a bigger share of people notice you */
    const pop = (cityOf(co.city) || {}).pop || 150;
    base *= clamp(1.25 - Math.log10(Math.max(20, pop)) * 0.12, 0.85, 1.15);
    /* reviews and repeat customers: good service spreads, poor service sinks the name */
    const rt = ratingOf(co);
    base *= clamp(0.55 + (rt - 3) * 0.45, 0.35, 1.35);
    /* it takes time to become known: full level after about a year open */
    const age = S.week - (co.wOpen != null ? co.wOpen : co.w0 || S.week);
    base *= clamp(0.35 + age / 52 * 0.65, 0.35, 1);
    return base;
  }
  window.R23 = window.R23 || {};
  R23.organic = organic;
  addStep('mktWeek.after', 50, 'people find you without advertising', (co, bd) => {
    {
      if (co.st === 'open') {
        const A = organic(co, bd);
        co.aw23 = Math.round(A * 10) / 10;
        /* below the organic level, people who know you keep knowing you (no fading), and more find you each week */
        if (A > co.aware) co.aware = clamp(co.aware / Math.max(0.5, awareDecay(co)) + (A - co.aware) * 0.035, 0, A + 0.5);
      }
    }
  });
}
/* farms sell into a commodity market: what they grow is sold at the going price; awareness and advertising
   do not decide how much of the harvest finds a buyer. Production capacity sets the volume. */
{
  const COMMOD = { farm: 1 };
  addStep('demand', 60, 'commodities sell all they make', (co, bd, r) => {
    if (COMMOD[bd.id]) {
      const cap = capacity(co, bd).cap || 0;
      const f = cap > 0 ? Math.max(r.D, cap * 0.97) / Math.max(1e-9, r.D) : 1;
      r.D = Math.max(r.D, cap * 0.97);
      r.parts.commodity = Math.round(f * 100) / 100;
    }
  });
}
/* vehicles all lost 15% of their price a year, so a 180 million aircraft was written off in under 7 years
   (real: 20–25). Depreciation now follows the kind of vehicle. */
window.R23 = window.R23 || {};
R23.vehDep = m => ({ plane: 0.05, bus: 0.1, truck: 0.12, plant: 0.1, van: 0.15, car: 0.16, bike: 0.2 }[m && m[2]] || 0.15);
/* retuned price levels (R8.PF) and demand levels (R8.KT) for types that could not work under realistic running:
   see the audit report for the reasoning behind each number */
Object.assign(window.R8.PF, { farm: 1.0, airline: 1.2 });
(function () {
  const K = window.R8.KT, F = window.R8.PF;
  /* demand: trades, couriers and pet care run at 65–85% of their capacity when known in their area */
  const kt = { courier: 1.25, trucking: 1.15, electrician: 1.45, plumber: 1.2, pets: 1.3, taxi: 1.1 };
  Object.keys(kt).forEach(t => { if (K[t]) K[t] = Math.round(K[t] * kt[t] * 100) / 100; });
  /* fares: Norwegian taxi trips average about 340 NOK */
  F.taxi = 1.0;
  /* a bank with fifteen staff and a core system needs a balance sheet of a billion or more to cover its costs;
     at 16% capital that is about 180 million of equity (EU minimum licence capital is 5 million euro, but that does not pay the wages).
     The setup estimate includes it (setupEstimate, engine/core/api.js). */
})();
/* vehicles: traded across borders, so prices differ less than local prices do (Norway's taxes make them dearest).
   In low-cost countries small firms start with used vehicles, as they do in reality. */
R23.vehCtry = co => { const C = (co && CO[co.country]) || CC(); return 0.4 + 0.6 * Math.min(1.15, C.pl || 1); };
/* running overheads (phone, accounting, insurance, small services) were charged at Norwegian prices in every
   country. They are mostly local services, so they follow the country's price level. */
/* accounting, insurance, phone and small services are mostly people's time, so they follow local wages as much as local prices */
R23.fixF = co => { const C = (co && CO[co.country]) || CC(); return 0.2 + 0.8 * (0.5 * (C.pl || 1) + 0.5 * Math.min(1.3, C.wage || 1)); };

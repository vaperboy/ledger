/* ===== Round 19: marketing that brings real customers.
   Root cause of "38 weeks of flyers, zero customers": campaigns ran and money was spent, awareness rose and sales rose,
   but the "new clients" counter only counted customers when the marketing demand multiplier was above 1, which needs
   ~55% awareness. A small local business never gets there, so it always showed 0. There was also no direct-response
   model at all: every channel only nudged awareness.
   Fix: each active channel buys contacts (budget / cost per contact, by country), contacts become leads and customers
   through channel and industry rates, fractional results accumulate week to week, acquired customers are real
   (they add to demand, buy again, and slowly leave), and the books track reach, leads, customers, spend, cost per
   customer and revenue those customers actually paid. ===== */
{
  const NOWORK = { rent: 1, fin: 1, energy: 1, club: 1, hold: 1 };
  /* cost per 1 000 contacts in Norway (NOK), contact → lead rate, lead → customer rate, age skew, B2B channel */
  const CHX = {
    flyer: { cpm: 450, resp: 0.0012, conv: 0.3, age: [0.8, 1, 1.1, 1.15], what: 'households reached' },
    google: { cpm: 35000, resp: 0.06, conv: 0.3, age: [0.9, 1.1, 1.05, 0.9], what: 'clicks from people searching' },
    meta: { cpm: 70, resp: 0.0012, conv: 0.2, age: [1.15, 1.2, 1, 0.7], what: 'people who saw the ad' },
    tiktok: { cpm: 50, resp: 0.0007, conv: 0.15, age: [1.5, 1.15, 0.6, 0.3], what: 'video views', vol: 1 },
    local: { cpm: 250, resp: 0.0007, conv: 0.28, age: [0.45, 0.7, 1.05, 1.45], what: 'readers and listeners' },
    bill: { cpm: 40, resp: 0.00015, conv: 0.2, age: [1, 1.05, 1, 0.9], what: 'people passing' },
    seo: { cpm: 20000, resp: 0.04, conv: 0.3, age: [1, 1.05, 1.05, 0.9], what: 'visits from search', seo: 1 },
    mail: { cpm: 0, resp: 0.01, conv: 0.4, age: [0.9, 1, 1.05, 1.1], what: 'regulars on the list', loyal: 1 },
    b2b: { cpm: 350, resp: 0.004, conv: 0.15, b2b: 1, what: 'decision-makers reached' },
    fair: { cpm: 2500, resp: 0.03, conv: 0.2, b2b: 1, what: 'people met' }
  };
  /* how well a channel suits each kind of business (1 = normal) */
  const FIT = {
    flyer: { svc: 1, venue: 1.1, retail: 1, project: 0.7, prod: 0.3, logi: 0.4 },
    google: { svc: 1.2, venue: 0.8, retail: 0.9, project: 1.1, prod: 0.6, logi: 0.8 },
    meta: { svc: 0.9, venue: 1.2, retail: 1.1, project: 0.5, prod: 0.5, logi: 0.5 },
    tiktok: { svc: 0.6, venue: 1.2, retail: 1.1, project: 0.3, prod: 0.4, logi: 0.3 },
    local: { svc: 1, venue: 1, retail: 1, project: 0.9, prod: 0.5, logi: 0.6 },
    bill: { svc: 0.7, venue: 1, retail: 1.1, project: 0.6, prod: 0.5, logi: 0.6 },
    seo: { svc: 1.1, venue: 0.8, retail: 1.1, project: 1, prod: 0.8, logi: 0.8 },
    mail: { svc: 0.8, venue: 1.2, retail: 1.2, project: 0.4, prod: 0.6, logi: 0.5 },
    b2b: { svc: 1, venue: 0.2, retail: 0.3, project: 1.1, prod: 1.2, logi: 1.1 },
    fair: { svc: 0.6, venue: 0.3, retail: 0.4, project: 1, prod: 1.2, logi: 1 }
  };
  /* who actually buys from each kind of business, by age group 18–24, 25–34, 35–49, 50+ (parents count for children) */
  const WHO = {
    tutor: [1, 0.6, 1.4, 0.25], drivsk: [1.7, 0.7, 0.6, 0.15], nightclub: [1.6, 1.1, 0.45, 0.15], gym: [1.2, 1.2, 0.9, 0.6], physio: [0.5, 0.8, 1.1, 1.3],
    cafe: [1.2, 1.2, 0.9, 0.8], restaurant: [0.8, 1.1, 1.1, 1], hotel: [0.6, 1, 1.1, 1.1], boutique: [1.3, 1.2, 0.9, 0.6], cardealer: [0.5, 1, 1.2, 1],
    pets: [0.6, 1.1, 1.1, 1], cleaning: [0.4, 0.9, 1.2, 1.2], handy: [0.3, 0.8, 1.2, 1.4], estate: [0.4, 1.2, 1.2, 0.9], barber: [1.1, 1, 1, 0.9],
    fun: [1.2, 1.1, 1.1, 0.5], foodtruck: [1.3, 1.2, 0.9, 0.6], kiosk: [1.2, 1, 1, 0.9], webshop: [1.1, 1.2, 1, 0.7], taxi: [1.1, 1, 0.9, 1.1], casino: [0.8, 1, 1, 1]
  };
  const WHOF = { venue: [1.1, 1.1, 1, 0.8], retail: [1, 1.1, 1, 0.9], svc: [0.8, 1, 1.1, 1] };
  const LOCALSVC = { handy: 1.2, cleaning: 1.2, carclean: 1.2, pets: 1.2, barber: 1.15, tutor: 1.1, plumber: 1.15, electrician: 1.1 };
  /* ad cost and response by country (Norway = 1). Contacts are bought in local prices; budgets are stored in NOK. */
  const CTRY = { NO: [1, 1], SE: [0.8, 1], DE: [0.8, 0.95], UK: [0.9, 1], FR: [0.75, 0.95], US: [1, 1], JP: [0.7, 0.85], KR: [0.55, 1.1], BR: [0.25, 1.15] };
  const ctry = co => { const c = CO[co.country] || CC(), x = CTRY[co.country]; return x || [clamp((c.pl || 0.8) * 0.95, 0.25, 1.1), 1]; };
  /* how often a won customer buys, how many units each time, and weekly churn */
  const BUY = { svc: [0.12, 1, 0.03], venue: [0.45, 1, 0.05], retail: [0.35, 1, 0.05], project: [0.01, 1, 0.06], prod: [0.25, 1, 0.03], logi: [0.3, 1, 0.04] };
  const BUYT = { gym: [1, 1, 0.03], hotel: [0.02, 2, 0.05], tutor: [0.8, 1, 0.04], drivsk: [0.7, 1, 0.08], cleaning: [0.5, 3, 0.03], physio: [0.5, 1, 0.08], barber: [0.15, 1, 0.03], cafe: [0.6, 1, 0.05], restaurant: [0.12, 2, 0.05], kiosk: [0.8, 1, 0.05], grocery: [0.8, 1, 0.04], cons: [0.2, 8, 0.04], webdev: [0.05, 40, 0.05], mktg: [0.15, 10, 0.04], law: [0.1, 6, 0.05], acctfirm: [0.25, 4, 0.02], staffing: [0.4, 20, 0.05] };
  const buyOf = bd => BUYT[bd.id] || BUY[bd.fam] || [0.2, 1, 0.04];

  const st = co => (co.mk19 = co.mk19 || { base: 0, nw: 0, seo: 0, ch: {} });
  const lux = co => ((co.price || 0) > 0 ? 0.6 : (co.price || 0) < 0 ? 0.15 : 0.35);
  /* everything that decides how many customers a channel brings this week */
  function chanCalc(co, bd, k, b) {
    const c = CH[k], x = CHX[k];
    if (!c || !x) return null;
    const cm = ctry(co), city = cityOf(co.city) || {}, pop = city.pop ? city.pop * 1000 : 150000;
    const aud = bd.aud || 0;
    let fit = ((FIT[k] || {})[bd.fam] || 0.5) * chAff(bd, k) * (k === 'flyer' || k === 'local' ? LOCALSVC[bd.id] || 1 : 1);
    /* consumers by age; businesses through decision-makers, not age */
    let tgt = 1;
    if (x.b2b) fit *= clamp(aud * 1.4, 0.08, 1.3);
    else {
      fit *= clamp((1 - aud) + aud * (c.b2b || 0.3), 0.15, 1);
      const ag = co.mktT && co.mktT.ag != null ? co.mktT.ag : null;
      if (ag != null && aud < 0.6 && window.AGX) tgt = clamp(Math.pow(AGX.SPD[ag], 0.3 + 1.2 * lux(co)) * (x.age ? x.age[ag] : 1) * (WHO[bd.id] || WHOF[bd.fam] || [1, 1, 1, 1])[ag] / 0.85, 0.15, 1.5);
    }
    let contacts;
    if (x.loyal) contacts = Math.max(0, st(co).base + ((co.lastW && co.lastW.units) || 0) * 0.5) * (b > 0 ? clamp(b / KC(600), 0.3, 1.5) : 0);
    else if (x.seo) contacts = (st(co).seo || 0);
    else contacts = b / (x.cpm * cm[0]) * 1000;
    /* the same people see it again: unique reach saturates against the local audience */
    const pool = x.b2b ? Math.max(500, pop * 0.02) : k === 'flyer' || k === 'local' ? pop * 0.25 : pop * 0.8;
    const reach = x.seo || x.loyal ? contacts : pool * (1 - Math.exp(-contacts / pool));
    const leads0 = reach * x.resp * cm[1] * fit * tgt * (window.R19K || 1);
    const M30 = window.R30 && R30.inMarket ? R30.inMarket(co, bd) : Infinity;
    const leads = M30 === Infinity ? leads0 : leads0 * M30 / (M30 + leads0); /* only so many people shop for this each week */
    /* a full order book turns leads away; a poor rating loses some */
    const q = clamp(0.6 + (ratingOf(co) - 3.5) * 0.25, 0.35, 1.15);
    const cust = leads * x.conv * q;
    return { contacts, reach, leads, cust, fit, tgt, cm, q };
  }
  function custValue(co, bd) {
    const B = buyOf(bd), tk = ticketEff(co, bd);
    return tk * B[1] * (1 + B[0] / Math.max(0.01, B[2])) * Math.max(0.15, (bd.m || 0.1) + 0.25);
  }
  /* expected customers per week and value for a budget on one channel: used by the manager to pick */
  function expect(co, k, b) { const bd = BD[co.type], r = chanCalc(co, bd, k, b); return r ? { cust: r.cust, roi: r.cust * custValue(co, bd) / Math.max(1, b) } : null; }
  window.R19 = { chanCalc, expect, CHX };
  /* the planner's estimate line: weekly reach and expected customers from the same model the campaign runs on */
  R19.planTxt = (co, PL) => {
    try {
      const bd = BD[co.type];
      if (NOWORK[bd.fam] || !CHX[PL.ch]) return '';
      const keepT = co.mktT;
      co.mktT = { ag: PL.ag };
      const R = chanCalc(co, bd, PL.ch, PL.b);
      co.mktT = keepT;
      if (!R) return '';
      const w = PL.w || 13, cu = R.cust * w;
      return ' · reach ~' + Math.round(R.reach).toLocaleString('en-US').replace(/,/g, ' ') + '/wk · ~' + (cu >= 10 ? Math.round(cu) : cu.toFixed(1)) + ' customers' + (PL.w ? '' : ' per quarter');
    } catch (e) { return ''; }
  };

  addStep('mktWeek.before', 10, 'remember the counters (campaign customers)', (co, bd, ctx) => {
    ctx.s19 = st(co); ctx.a019 = co.aware;
    ctx.mks0 = co.mks ? { m: co.mks.m, n: co.mks.n, c: co.mks.c, ch: Object.assign({}, co.mks.ch) } : null;
  });
  addStep('mktWeek.after', 40, 'campaigns bring real customers (churn, SEO, luck)', (co, bd, ctx) => {
    const s = ctx.s19, a0 = ctx.a019, mks0 = ctx.mks0;
    {
      if (NOWORK[bd.fam] || !bd.Dc) return;
      /* keep the old counter's month bookkeeping, but replace its guess with the real numbers below */
      if (co.mks && mks0 && co.mks.m === mks0.m) { co.mks.n = mks0.n; co.mks.c = mks0.c; co.mks.ch = mks0.ch; }
      else if (co.mks) { co.mks.n = 0; co.mks.c = 0; co.mks.ch = {}; }
      const B = buyOf(bd);
      /* customers won before: some leave, the rest keep buying (loyalty mail slows churn) */
      const loyal = co.mkt.mail && co.mkt.mail.b > 0;
      s.base = Math.max(0, s.base * (1 - B[2] * (loyal ? 0.6 : 1)));
      /* SEO: organic visits build while you pay and fade slowly after */
      const seoB = co.mkt.seo ? co.mkt.seo.b : 0;
      s.seo = Math.max(0, (s.seo || 0) * (seoB ? 0.97 : 0.95) + (seoB ? seoB / (CHX.seo.cpm * ctry(co)[0]) * 1000 * 0.04 : 0));
      let nw = 0, direct = 0, tot = 0;
      const keys = Object.keys(co.mkt).filter(k => co.mkt[k] && co.mkt[k].b > 0);
      if (s.seo > 1 && keys.indexOf('seo') < 0) keys.push('seo');
      keys.forEach(k => {
        const b = co.mkt[k] ? co.mkt[k].b : 0, x = CHX[k], R = chanCalc(co, bd, k, b);
        if (!R) return;
        const c = s.ch[k] = s.ch[k] || { sp: 0, reach: 0, leads: 0, cust: 0, rev: 0, acc: 0, w: 0, base: 0 };
        c.sp += b;
        c.w++;
        c.reach += R.reach;
        c.leads += R.leads;
        /* fractional customers carry over; luck widens or narrows each week's share (video is very uneven) */
        const since30 = co.mkt[k] ? co.mkt[k].since : -1;
        if (c.luck == null || c.luckS !== since30) { c.luck = x.vol ? Math.exp(gauss() * 0.9 - 0.4) : Math.exp(gauss() * 0.45 - 0.1); c.luckS = since30; }
        const noise = c.luck * (x.vol ? (chance(0.05) ? 3 : rng(0.5, 1.2)) : rng(0.8, 1.2)) * (window.R30M ? R30M(co, bd, k) : 1);
        /* only people you can actually serve become customers: a full book turns the rest away */
        const w0 = co.lastW || {}, served = w0.D > 0 && w0.units >= 0 ? clamp(w0.units / w0.D, 0.05, 1) : 1;
        /* a small market fills up: the more campaign customers you already have, the fewer new ones are left */
        const xr = extraUnits(co, bd), d0 = Math.max(0, (w0.D || 0) - xr), head = 1 / (1 + xr / (0.6 * d0 + 1));
        c.acc += R.cust * noise * served * head;
        c.full = (c.full || 0) + R.cust * served * (1 - head);
        c.away = (c.away || 0) + R.cust * (1 - served);
        let n = pois(c.acc);
        c.acc = 0;
        c.cust += n;
        c.base = Math.max(0, (c.base || 0) * (1 - B[2]) + n);
        c.last = { reach: R.reach, leads: R.leads, exp: R.cust, fit: R.fit, tgt: R.tgt };
        nw += n;
        tot += b;
        direct += b * (['flyer', 'google', 'b2b', 'mail', 'seo'].indexOf(k) >= 0 ? 1 : 0.6);
        if (co.mks) { co.mks.ch[k] = (co.mks.ch[k] || 0) + n; }
      });
      s.nw = nw;
      s.base += nw;
      if (co.mks) { co.mks.n += nw; co.mks.c += mktCost(co); }
      /* direct-response channels now bring customers themselves, so they lift general awareness less */
      if (tot > 0 && co.aware > a0) co.aware = a0 + (co.aware - a0) * (1 - 0.65 * direct / tot);
    }
  });
  /* the customers you won are real demand: first purchase the week they come, repeat purchases after */
  function extraUnits(co, bd) {
    const s = co.mk19;
    if (!s || NOWORK[bd.fam]) return 0;
    const B = buyOf(bd), loyal = co.mkt && co.mkt.mail && co.mkt.mail.b > 0 ? 1.3 : 1;
    return (s.nw * B[1] + Math.max(0, s.base - s.nw) * B[0] * B[1] * loyal);
  }
  /* some of the people a campaign wins would have come anyway, and a market only holds so many buyers */
  const incr = (x, D0) => 0.7 * x / (1 + x / (0.6 * D0 + 1));
  addStep('demand', 40, 'marketing campaigns', (co, bd, r) => {
    const x0 = extraUnits(co, bd); if (x0 > 0) { const x = incr(x0, r.D); const d0 = r.D; r.D += x; r.parts.campaigns = d0 > 0 ? r.D / d0 : 1; }
  });
  /* revenue: credited to campaigns only for what was actually sold, in proportion to their share of demand */
  addStep('week.after', 55, 'marketing_brings_customers weekly', () => {
    S.cos.forEach(co => {
      const s = co.mk19, w = co.lastW;
      if (!s || !w || !w.rev || co.st !== 'open') return;
      const bd = BD[co.type], x = incr(extraUnits(co, bd), Math.max(0, (w.D || 0) - extraUnits(co, bd))), D = Math.max(x, w.D || w.units || 0);
      if (!(x > 0) || !(D > 0)) return;
      const rev = w.rev * Math.min(1, x / D) * Math.min(1, (w.units || 0) / Math.max(1, w.D || w.units || 1));
      const tb = sum(Object.keys(s.ch), k => s.ch[k].base || 0);
      if (!(tb > 0.01) || !(s.base > 0.01)) return;
      Object.keys(s.ch).forEach(k => { s.ch[k].rev += rev * (s.ch[k].base || 0) / tb; });
      s.turned = w.D > (w.cap || Infinity) * 1.02 && w.cap > 0;
    });
  });
  /* manager without a fixed plan: put the money where it brings the most back for this business */
  addStep('tune.before', 20, 'count running campaigns', (co, bd, ctx, q, ph) => { ph.had19 = Object.keys(co.mkt || {}).filter(k => co.mkt[k] && co.mkt[k].b).length; });
  addStep('tune.after', 20, 'a first campaign goes to the channel that pays best', (co, bd, ctx, q, ph) => {
    const had = ph.had19;
    const now = Object.keys(co.mkt).filter(k => co.mkt[k] && co.mkt[k].b);
    if (!had && now.length === 1 && !co.mktT) {
      const b = co.mkt[now[0]].b;
      const best = Object.keys(CH).filter(k => CHX[k] && chOk(co, k) && !CH[k].prem && !CH[k].nat && !CHX[k].loyal && !CHX[k].seo).map(k => [k, expect(co, k, b)]).filter(x => x[1]).sort((a, b2) => b2[1].roi - a[1].roi)[0];
      if (best && best[0] !== now[0]) { delete co.mkt[now[0]]; co.mkt[best[0]] = { b, since: S.week }; }
    }
  });

  /* ---------- show where the money went and why ---------- */
  const nf = n => Math.round(n).toLocaleString('en-US').replace(/,/g, ' ');
  function why(co, bd, k, c) {
    const L = c.last;
    if (!L) return '';
    if ((c.away || 0) > c.cust * 0.3 && c.away >= 1) return 'You are full: about ' + Math.round(c.away) + ' would-be customers were turned away. More staff or hours would let you take them.';
    if ((c.full || 0) > c.cust && c.full >= 2) return 'Small market: most people here who want a ' + bd.n.toLowerCase() + ' already know you. More spend brings few new customers.';
    if (c.cust > 0 && L.exp >= 0.3) return 'Working. Likely ' + (window.R30rng ? R30rng(L.exp, k) : Math.round(L.exp)) + ' new customers a week at this budget, and some weeks bring nobody.';
    if (L.fit < 0.4) return 'Poor fit: ' + CH[k].n.toLowerCase() + ' rarely reaches buyers of a ' + bd.n.toLowerCase() + '.';
    if (L.tgt < 0.75) return 'The age group you aim at rarely buys here or uses this channel.';
    if ((c.away || 0) > c.cust * 0.3 && c.away >= 1) return 'You are full: about ' + Math.round(c.away) + ' would-be customers were turned away. More staff or hours would let you take them.';
    if (L.exp < 0.3) return 'Small budget: about one new customer every ' + Math.max(2, Math.round(1 / Math.max(0.01, L.exp))) + ' weeks expected.';
    return 'Results come and go week to week.';
  }
  addStep('CT.marketing', 30, 'marketing_brings_customers CT.marketing', (co, bd, h) => {
    try {
      const s = co.mk19;
      if (!s || NOWORK[bd.fam]) return h;
      const ks = Object.keys(s.ch).filter(k => s.ch[k].w > 0 && (co.mkt[k] || s.ch[k].cust));
      if (!ks.length) return h;
      h += '<h2 class="sec">Campaign results</h2>' + ks.map(k => {
        const c = s.ch[k], x = CHX[k];
        return '<div class="card"><div class="bhead"><b>' + esc(CH[k].n) + '</b><span class="pill">' + c.w + ' wk</span></div><div class="tri"><div><span>Reach</span><b>' + nf(c.reach) + '</b></div><div><span>Leads</span><b>' + (c.leads < 10 ? c.leads.toFixed(1) : nf(c.leads)) + '</b></div><div><span>Customers</span><b>' + c.cust + '</b></div></div>' + row('Spent', money(c.sp)) + row('Cost per customer', c.cust ? money(c.sp / c.cust) : '—') + row('Revenue from them', money(c.rev)) + '<span class="tipt">' + esc(x.what.charAt(0).toUpperCase() + x.what.slice(1)) + ' · ' + esc(why(co, bd, k, c)) + '</span></div>';
      }).join('');
    } catch (e) { console.error(e); }
    return h;
  });
}


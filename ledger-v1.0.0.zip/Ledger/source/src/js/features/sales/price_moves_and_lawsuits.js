/* ===== Round 16: prices move in percent, customers react to changes they notice, discount campaigns,
   rivals only get angry at real price cuts, one marketing budget system, needs-attention fixes, lawsuits with a reason and a court. ===== */
{
  const PM = PRICE_PM;
  const pmOf = L => { L = clamp(+L || 0, -3, 3); const i = Math.min(5, Math.floor(L + 3)), f = L + 3 - i; return PM[i] + (PM[i + 1] - PM[i]) * f; };
  const lvlOf = pm => { pm = clamp(pm, PM[0], PM[6]); let i = 0; while (i < 5 && pm > PM[i + 1]) i++; return Math.round((i - 3 + (pm - PM[i]) / (PM[i + 1] - PM[i])) * 1000) / 1000; };
  const pc = (x, d) => (x > 0 ? '+' : x < 0 ? '−' : '') + Math.abs(Math.round(x * 100 * (d ? 10 : 1)) / (d ? 10 : 1)) + '%';
  const pcs = x => (x < 0 ? '−' : '') + Math.abs(Math.round(x * 100)) + '%';
  const RVP = (co, r) => typeof rivPrice === 'function' ? rivPrice(co, r) : ticketEff(co, BD[co.type]) / priceMult(co) * (window.R18 && r.pm16 ? R18.effP(r) : (0.82 + hrng(S.seed + ':rp:' + r.id)() * 0.4));

  /* ---------- discount campaigns: how deep each kind of business can go (0 = not done in that trade) ---------- */
  const DISC = {
    cons: 15, tutor: 30, carclean: 30, photo: 25, handy: 15, cleaning: 20, webdev: 15, mktg: 15, law: 0, acctfirm: 0, staffing: 0, barber: 25, drivsk: 15, physio: 10, estate: 0, pets: 25,
    foodtruck: 30, cafe: 30, restaurant: 25, nightclub: 20, gym: 40, hotel: 40, casino: 0, fun: 30,
    kiosk: 25, boutique: 40, webshop: 40, grocery: 25, hardware: 30, cardealer: 10,
    construction: 0, electrician: 0, plumber: 0, realdev: 0, event: 10, engcons: 0,
    bakery: 30, brewery: 20, furniture: 30, salmon: 0, factory: 10, farm: 0,
    taxi: 15, courier: 20, trucking: 0, shipping: 0, airline: 40,
    resrent: 0, comrent: 0, parking: 20, insco: 0, bank: 0, fund: 0, power: 0, oilgas: 0, hold: 0, club: 0
  };
  const discMax = co => DISC[co.type] || 0;
  const discOpts = co => [10, 15, 20, 25, 30, 40].filter(x => x <= discMax(co));
  const campPct = co => (co && co.camp16 && S.week < co.camp16.end ? co.camp16.pct / 100 : 0);
  /* customers get used to sales: the more weeks on discount lately, the less a new one pulls */
  const fat = co => { const L = (co.cw16 || []).filter(w => S.week - w < 13 && w < (co.camp16 ? co.camp16.w0 : S.week)).length; return clamp(1 - L / 13 * 1.4, 0.25, 1); };

  window.PX16 = { pm: pmOf, lvl: lvlOf, campPct };

  /* ---------- one price index everywhere: the level (continuous) times any running discount ---------- */
  window.priceMult = co => pmOf(co.price || 0) * (1 - campPct(co));
  window.priceDem = function (co, bd) {
    const base = pmOf(co.price || 0), cp = campPct(co), eff = base * (1 - cp), effL = base * (1 - cp * 0.6);
    const sat = clamp((ratingOf(co) - 3.8) / 0.9, 0, 1);
    const e0 = bd.ela || 0, ela = e0 * (1 - 0.3 * sat);
    /* a few percent off the market price hardly registers; bigger gaps count in full */
    const dev = effL - 1, pe = 1 + dev * Math.min(1, Math.abs(dev) / 0.06);
    let d = pe <= 1 ? Math.pow(pe, -ela) : Math.pow(pe, -ela * 0.7) * Math.pow(0.45 + 0.55 * brandPull(co), (L => (L <= 1 ? 0 : (L - 1) * 1.5))(lvlOf(pe)));
    /* a change people notice: compared with what they are used to paying */
    const ref = co.pref16 != null ? co.pref16 : base, x = eff / ref - 1;
    if (x > 0.03) {
      const m = S.mk[mkKey(co)], mpi = m ? m.pi : 1;
      const tol = clamp(0.2 + 0.45 * sat + (eff <= mpi ? 0.35 : 0), 0, 0.9);
      d *= Math.exp(-(x - 0.03) * e0 * 1.3 * (1 - tol));
    } else if (x < -0.03 && !cp) d *= 1 + Math.min(0.5, (-x - 0.03) * e0 * 0.9 * clamp((co.aware || 0) / 60, 0.25, 1));
    if (cp) d *= 1 + cp * 0.8 * fat(co);
    return d;
  };
  /* the gap to rivals: a couple of percent either way goes unnoticed too */
  window.rivalMult = function (co, bd) {
    const m = S.mk[mkKey(co)];
    if (!m) return 1;
    const r0 = priceMult(co) / m.pi, dv = r0 - 1, ratio = 1 + dv * Math.min(1, Math.abs(dv) / 0.06);
    let mult = 1 - Math.min(0.3, 0.035 * m.n) * (0.7 + 0.5 * m.str);
    mult *= ratio > 1 ? Math.exp(-0.9 * (ratio - 1)) : Math.exp(0.35 * (1 - ratio));
    mult *= disMult(co);
    const v = clamp(mult, 0.2, 1.25);
    /* rival marketing pushes (round 18) take a little more of the market */
    return m.str16 ? clamp(v * (1 - m.str16 * 0.3), 0.2, 1.25) : v;
  };
  /* managers move prices in small steps, not whole levels */
  const step = (co, before) => { const d = (co.price || 0) - before; if (Math.abs(d) >= 0.5) co.price = lvlOf(pmOf(before) * (1 + Math.sign(d) * 0.06)); };
  addStep('tune.before', 30, 'remember the price', (co, bd, ctx, q, ph) => { ph.p16 = co.price || 0; });
  addStep('tune.after', 10, 'prices move in small steps', (co, bd, ctx, q, ph) => { step(co, ph.p16); }, true);
  addStep('askManager.before', 10, 'remember the price', (co, k, ph) => { ph.p16 = co && co.price || 0; });
  addStep('askManager.after', 10, 'prices move in small steps', (co, k, ph) => { if (k === 'price_up' || k === 'price_down') step(co, ph.p16); }, true);

  /* ---------- weekly: what customers are used to, price history, campaigns ---------- */
  function priceWeek() {
    S.cos.forEach(co => {
      if (co.st !== 'open') return;
      const base = pmOf(co.price || 0);
      co.pref16 = co.pref16 == null ? base : Math.round((co.pref16 + (base - co.pref16) * 0.18) * 10000) / 10000;
      co.ph16 = (co.ph16 || []).concat([[S.week, Math.round(base * 1000) / 1000]]).slice(-10);
      const c = co.camp16;
      if (c) {
        if (S.week < c.end) {
          co.cw16 = (co.cw16 || []).concat([S.week]).slice(-20);
          if (c.fake && !c.caught && chance(0.2)) {
            c.caught = 1;
            const f = rnl(KC(40000) * clamp(co.size || 1, 0.5, 3), 1000);
            payCo(co, f, 'fine', 'Consumer authority: misleading discount');
            co.rep = clamp(co.rep - 3, 0, 100);
            info('Consumer authority', 'Misleading sale at ' + co.name, 'Your ' + c.pct + '% off was measured against a price you raised ' + c.fake + ' weeks before. The before-price must be the price of the last 30 days. Fine: ' + money(f) + '.', co.id, 'bad');
          }
        } else {
          const bd = BD[co.type];
          if (['retail', 'venue', 'prod'].indexOf(bd.fam) >= 0) addMod(co, 'dem', 1 - c.pct / 100 * 0.35, 1);
          note('The ' + c.pct + '% discount at ' + co.name + ' has ended.', 'n', co.id);
          delete co.camp16;
        }
      }
    });
  }
  addStep('week.after', 55, 'price_moves_and_lawsuits weekly', () => { try { priceWeek(); courtWeek(); } catch (e) { console.error(e); } });

  /* ---------- rivals: a low price is a business model; only a real cut makes them call ---------- */
  const cutOf = co => { const H = co.ph16 || [], now = pmOf(co.price || 0); let mx = 0; H.forEach(h => { if (S.week - h[0] <= 6) mx = Math.max(mx, h[1] / now - 1); }); return mx; };
  let quiet = null;
  addStep('rivalCall.before', 10, 'only a real price cut makes a rival call', (co, bd, m, kind, ph) => {
    if (kind !== 'match') return;
    ph.cut = cutOf(co);
    if (ph.cut < 0.06 && !(co.flags && co.flags.pw)) { if (quiet) quiet.push(m); ph.no = 'small cut'; return; }
    ph.n0 = S.inbox.length;
  });
  addStep('rivalCall.after', 10, 'the call says what they matched', (co, bd, m, kind, ph) => {
    if (kind !== 'match') return;
    const msg = S.inbox.length > ph.n0 ? S.inbox[0] : null;
    if (msg && /calls about your prices/.test(msg.title)) msg.body = '"You cut your prices ' + Math.round(ph.cut * 100) + '% in a few weeks and our customers noticed. We have matched you. If you keep going down, we both bleed."';
  });
  addStep('rivalsWeek.around', 10, 'small price cuts go unanswered', (co, run) => {
    const snap = new Map();
    Object.keys(S.mk || {}).forEach(k => snap.set(S.mk[k], S.mk[k].pi));
    quiet = [];
    try { return run(); }
    finally { quiet.forEach(m => { if (snap.has(m)) m.pi = Math.max(m.pi, snap.get(m)); }); quiet = null; }
  });

  /* ---------- needs attention: unanswered complaints yes, low cash no ---------- */
  window.coAlerts = pipeView('window.coAlerts', window.coAlerts, 1); /* window.coAlerts: the screen above, then the steps below and in later files */
  addStep('window.coAlerts', 10, '---------- needs attention: unanswered complaints yes, low cash no ----------', (co, out) => {
    try {
      out = out.map(a => (a[0] === 'Low cash' ? ['Low cash', 'n'] : a));
      const asst = co.asst && (co.asst.duties || []).indexOf('comp') >= 0;
      const open = co.st === 'open' && !co.mgr && !asst ? (co.compl || []).filter(c => c.st === 'open').length : 0;
      if (open) out.unshift([open + (open > 1 ? ' complaints to answer' : ' complaint to answer'), 'bad']);
    } catch (e) { console.error(e); }
    return out;
  });

  /* ---------- lawsuits: why they sue, settle or go to court (now, or on a court date for big cases) ---------- */
  const SUE = {
    svc: [['says your work damaged their property', 0.55, 1], ['claims they were billed for hours nobody worked', 0.6, 0.5], ['says your advice cost them money', 0.5, 1.6]],
    venue: [['slipped on a wet floor and broke a wrist', 0.45, 1.4], ['got food poisoning after a visit', 0.5, 1], ['says a member of staff hurt them during an argument', 0.4, 1.8]],
    retail: [['was hurt by a faulty product you sold', 0.5, 1.5], ['says you refused a legal return or warranty claim', 0.35, 0.3], ['slipped in the shop and was injured', 0.45, 1.2]],
    logi: [['says you lost or destroyed their goods', 0.45, 0.8], ['was hurt in one of your vehicles', 0.4, 2], ['says a late delivery cost them a contract', 0.6, 1.2]],
    project: [['says your work has serious defects', 0.45, 2.2], ['claims the job ran far over the agreed price', 0.55, 0.9], ['says your crew damaged the neighbouring property', 0.5, 1.3]],
    prod: [['says a faulty batch damaged their production', 0.5, 2], ['claims you broke a supply contract', 0.55, 1.4]],
    other: [['says you broke the terms of your agreement', 0.55, 1]]
  };
  const chanceW = p => (p >= 0.65 ? 'good' : p >= 0.5 ? 'fair' : p >= 0.35 ? 'weak' : 'poor');
  const lawHelp = co => !!((co.law && co.law.own) || hasHQ('law'));
  SPEC.g_lawsuit = (co, bd, e, c) => {
    const L = SUE[bd.fam] || SUE.other, s = pick(L), who = personName();
    const wk = Math.max(3000, c.wk || 0);
    const claim = rnl(Math.max(KC(25000), wk * 0.9 * s[2]), 1000);
    const big = claim >= KC(150000) || s[2] >= 1.5;
    const p = clamp(s[1] + ((co.q || 60) - 60) / 200 + (lawHelp(co) ? 0.08 : 0), 0.15, 0.85);
    const fee = rnl(Math.max(big ? KC(25000) : KC(8000), claim * (big ? 0.18 : 0.12)) * (lawHelp(co) ? 0.6 : 1), 1000);
    const settle = rnl(claim * rng(0.35, 0.55), 1000);
    const wks = big ? rint(6, 12) : 0;
    const d = { who, why: s[0], claim, big, p, fee, settle, wks };
    const opts = [{ l: 'Settle · ' + money(settle), d: 'Pay now and the case is closed.', fx: {} }, { l: 'Go to court · ' + money(fee) + ' lawyer', d: big ? 'Ruling on ' + dateStr(S.week + wks) + '.' : 'Decided at one hearing.', fx: {} }];
    const body = who + ' ' + s[0] + ' and claims ' + money(claim) + '. ' + (big ? 'A big case: it goes to the district court.' : 'A small case: settled at one hearing.') + ' Your chances in court look ' + chanceW(p) + '.';
    const mg = co.mgr && S.npcs[co.mgr];
    if (mg) {
      const i = p >= 0.5 ? 1 : 0;
      const t = sue(co, d, i);
      info(co.name, 'A customer is suing ' + co.name, body + ' ' + mg.name + ' chose: ' + opts[i].l + '. ' + t, co.id, 'bad');
      return;
    }
    addMsg({ kind: 'ask', from: co.name, title: 'A customer is suing ' + co.name, body, co: co.id, opts, act: 'sue16', data: d, exp: S.week + 3, tone: 'bad' });
    note('Decision needed: ' + who + ' is suing ' + co.name + '.', 'bad', co.id);
  };
  const lose = (co, d, extra) => { applyFx(co, { loss: d.claim + (extra || 0) }, null, { cat: 'liab', id: 'g_lawsuit' }); co.rep = clamp(co.rep - (d.big ? 4.5 : 3), 0, 100); };
  function sue(co, d, i) {
    if (d.done) return '';
    if (i === 0) { d.done = 1; applyFx(co, { loss: d.settle }, null, { cat: 'liab', id: 'g_lawsuit' }); return 'Settled for ' + money(d.settle) + '.'; }
    payCo(co, d.fee, 'oth', 'Lawyer fees');
    if (d.big) {
      S.court16 = S.court16 || [];
      S.court16.push({ id: uid(), co: co.id, w: S.week + d.wks, d });
      return 'Court date: ' + dateStr(S.week + d.wks) + '.';
    }
    d.done = 1;
    if (chance(d.p)) { const back = Math.round(d.fee * 0.5); coIn(co, back, null, 'Legal costs awarded'); return 'You won. The claim was rejected and they pay ' + money(back) + ' of your costs.'; }
    lose(co, d, Math.round(d.fee * 0.4));
    return 'You lost. You pay the ' + money(d.claim) + ' claim and part of their costs.';
  }
  ACTS.sue16 = (m, idx) => {
    const co = getCo(m.co);
    if (!co || !m.data) return true;
    const t = sue(co, m.data, idx);
    if (t) { toast(t, /lost/.test(t)); info(co.name, idx === 1 && !m.data.big ? 'Court ruling: ' + m.data.who : 'Lawsuit: ' + m.data.who, t, co.id, /won|Settled|Court date/.test(t) ? 'n' : 'bad'); }
    return true;
  };
  function courtWeek() {
    /* unanswered lawsuits are lost by default */
    S.inbox.forEach(m => {
      if (m.act !== 'sue16' || !m.auto || !m.data || m.data.done) return;
      const co = getCo(m.co);
      m.data.done = 1;
      if (!co) return;
      lose(co, m.data);
      info(co.name, 'Lost by default: ' + m.data.who, 'Nobody answered the lawsuit, so the court ruled for ' + m.data.who + '. You pay ' + money(m.data.claim) + '.', co.id, 'bad');
    });
    const L = S.court16 || [];
    S.court16 = L.filter(x => {
      if (S.week < x.w) return true;
      const co = getCo(x.co);
      if (!co || co.st === 'sold' || co.st === 'bust') return false;
      const d = x.d;
      d.done = 1;
      if (chance(d.p)) {
        const back = Math.round(d.fee * 0.6);
        coIn(co, back, null, 'Legal costs awarded');
        info('District court', 'You won against ' + d.who, 'The court rejected the claim that ' + d.who + ' ' + d.why + '. They pay ' + money(back) + ' of your legal costs.', co.id, 'good');
      } else {
        lose(co, d, Math.round(d.fee * 0.5));
        info('District court', 'You lost against ' + d.who, 'The court found for ' + d.who + ', who ' + d.why + '. You pay ' + money(d.claim) + ' plus part of their costs.', co.id, 'bad');
      }
      return false;
    });
  }

  /* ---------- price moves: compact, one screen ---------- */
  function lastMonth(co) { const H = (co.hist || []).filter(x => x.rev > 0); return H.length ? H[H.length - 1] : null; }
  function marginNow(co) { const h = lastMonth(co); return h ? h.profit / h.rev : null; }
  /* what a change does: customers at first, customers once they are used to it, margin */
  function est(co, lv, cp) {
    const bd = BD[co.type];
    if (!bd.Dc) return null;
    const keep = { price: co.price, camp: co.camp16, pref: co.pref16 };
    try {
      if (co.pref16 == null) co.pref16 = pmOf(co.price || 0);
      const kind = window.R10 && R10.kindOf ? R10.kindOf(bd) : 'service';
      const cap = kind === 'goods' ? Infinity : (capacity(co, bd).cap || Infinity) * (kind === 'service' ? 1.1 : 1);
      const e0 = priceMult(co), D0 = demand(co, bd).D;
      co.price = lv;
      co.camp16 = cp ? { pct: cp, end: S.week + 9, w0: S.week } : (keep.camp && campPct(co) ? keep.camp : null);
      const e1 = priceMult(co), D1 = demand(co, bd).D;
      if (!cp) co.pref16 = pmOf(lv);
      const D2 = demand(co, bd).D;
      const u0 = Math.min(D0, cap), u1 = Math.min(D1, cap), u2 = Math.min(D2, cap);
      const h = lastMonth(co), w = co.lastW || {};
      let m0 = null, m1 = null;
      if (h && u0 > 0) {
        const v = w.rev > 0 ? clamp((w.cogs || 0) / w.rev, 0, 0.95) : (bd.cogs || 0.3);
        const ur = (cp ? u1 : u2) / u0, pr = e1 / e0;
        const rev1 = h.rev * ur * pr, varC = h.rev * v, fix = h.rev - h.profit - varC;
        m0 = h.profit / h.rev;
        m1 = rev1 > 0 ? (rev1 - varC * ur - fix) / rev1 : null;
      }
      return { c1: u0 > 0 ? D1 / D0 - 1 : 0, c2: u0 > 0 ? D2 / D0 - 1 : 0, m0, m1, full: D0 > cap * 1.02 };
    } catch (e) { console.error(e); return null; }
    finally { co.price = keep.price; co.camp16 = keep.camp; co.pref16 = keep.pref; }
  }
  const pill = (t, c) => '<span class="pill ' + (c || '') + '">' + t + '</span>';
  /* a slider that shows its value while you drag and applies when you let go */
  const slider = (k, v, mn, mx, st, fmt) => '<div class="rg16"><input type="range" min="' + mn + '" max="' + mx + '" step="' + st + '" value="' + v + '" oninput="var o=this.parentNode.querySelector(\'output\');o.textContent=(' + (fmt === 'pct' ? '(this.value>0?\'+\':\'\')+this.value+\'%\'' : fmt === 'wk' ? 'this.value+\' wk\'' : 'this.value+\'%\'') + ')" onchange="UI.ACT.pm16set({k:\'' + k + '\',v:+this.value})"><output>' + (fmt === 'pct' ? (v > 0 ? '+' : '') + v + '%' : fmt === 'wk' ? v + ' wk' : v + '%') + '</output></div>';
  /* forecasts: the owner only has a feeling, an analyst gives a range whose accuracy follows their skill */
  const anaOf = () => (window.R7 && R7.anaInfo ? R7.anaInfo() : null);
  const gutC = c => (c < -0.25 ? 'Many fewer' : c < -0.08 ? 'Fewer' : c < -0.02 ? 'A few fewer' : c <= 0.02 ? 'Same' : c < 0.08 ? 'A few more' : c < 0.25 ? 'More' : 'Many more');
  function guess(trueV, key, an, unit, sign) {
    const R = hrng(S.seed + ':g16:' + key + ':' + an.id + ':' + Math.floor(S.week / 4)), a = R(), b = R();
    const off = (a - 0.5) * 2 * (1 - an.s) * unit * 2.2 * (b < an.s ? 0.4 : 1), w = unit * (0.35 + (1 - an.s) * 2);
    const lo = trueV + off - w / 2, hi = trueV + off + w / 2;
    const f = x => (sign && x > 0 ? '+' : x < 0 ? '−' : '') + Math.abs(Math.round(x * 100)) + '%';
    return f(lo) + ' to ' + f(hi);
  }
  function fcBoxes(co, E, key, cpMode) {
    const an = anaOf();
    let c = '–', m = '?', cc = '', mc = '';
    if (E) {
      const cv = cpMode ? E.c1 : E.c2;
      cc = cv < -0.02 ? 'neg' : cv > 0.02 ? 'pos' : '';
      if (an) {
        c = guess(cv, key + 'c', an, 0.08, 1);
        if (E.m1 != null) { m = guess(E.m1, key + 'm', an, 0.06, 0); mc = E.m1 < 0 ? 'neg' : 'pos'; }
      } else {
        c = gutC(cv);
        if (E.m1 != null && E.m0 != null) {
          const R = hrng(S.seed + ':gm16:' + key + ':' + Math.floor(S.week / 4))(), dm = E.m1 - E.m0 + (R - 0.5) * 0.12;
          m = Math.abs(dm) < 0.02 ? 'Hard to say' : dm > 0 ? 'Better?' : 'Worse?';
          mc = 'amb';
        }
      }
    }
    return '<div class="duo dsm"><div><span>Customers</span><b class="' + cc + '">' + c + '</b></div><div><span>Margin' + (an ? '' : ' · gut feeling') + '</span><b class="' + mc + '">' + m + '</b></div></div>';
  }
  V.pricemoves = function (p) {
    const co = getCo(p.id), bd = BD[co.type];
    const D = discOpts(co);
    const u = ui.pm16 && ui.pm16.id === co.id ? ui.pm16 : (ui.pm16 = { id: co.id, d: 0.05, cp: D.indexOf(15) >= 0 ? 15 : D[0] || 0, w: 2 });
    const rs = co.st === 'open' && bd.fam !== 'fin' && bd.fam !== 'energy' ? rivalsOf(co) : [];
    const tk = ticketEff(co, bd), avg = rs.length ? sum(rs, r => RVP(co, r)) / rs.length : 0;
    const mg = marginNow(co), vs = avg ? tk / avg - 1 : 0;
    const base = pmOf(co.price || 0), cp = campPct(co);
    let h = '<div class="card pm16"><div class="tri"><div><span>Your price</span><b>' + mshort(tk) + '</b></div><div><span>Rivals</span><b>' + (avg ? mshort(avg) : '–') + '</b></div><div><span>Margin</span><b class="' + (mg == null ? '' : mg < 0 ? 'neg' : 'pos') + '">' + (mg == null ? '–' : pcs(mg)) + '</b></div></div>' +
      '</div>';
    const tag = avg ? pill(Math.abs(vs) < 0.03 ? 'Level with rivals' : pc(vs) + ' vs rivals', Math.abs(vs) < 0.03 ? '' : vs > 0 ? 'amb' : 'grn') : pill(Math.abs(base - 1) < 0.005 ? 'Market price' : pc(base - 1) + ' vs market');
    /* change the price */
    const dp = Math.round(clamp(u.d, -0.2, 0.2) * 100);
    const nb = clamp(base * (1 + dp / 100), PM[0], PM[6]), lv = lvlOf(nb), real = nb / base - 1;
    const E = dp ? est(co, lv, 0) : null;
    h += '<div class="card pm16"><div class="bhead"><b>Change price</b>' + tag + '</div>' + slider('dx', dp, -20, 20, 1, 'pct') + fcBoxes(co, E, 'p' + co.id + ':' + dp, 0) +
      btn(!dp ? 'Pick a change' : Math.abs(real) < 0.001 ? 'At the limit' : 'Set ' + pc(real) + ' · ' + mshort(tk * (1 + real)), !dp || Math.abs(real) < 0.001 ? 'noop' : 'pm16go', { id: co.id, lv }, 'primary wide') + '</div>';
    /* discount campaign */
    if (!D.length) h += '<div class="card pm16"><div class="bhead"><b>Discount campaign</b>' + pill('Not done in ' + esc(bd.n.toLowerCase())) + '</div></div>';
    else if (cp) {
      const c = co.camp16;
      h += '<div class="card pm16"><div class="bhead"><b>Discount campaign</b>' + pill(c.pct + '% off · ' + (c.end - S.week) + ' wk left', 'blue') + '</div>' + btn('End the discount', 'pm16end', { id: co.id }, 'wide') + '</div>';
    } else {
      if (D.indexOf(u.cp) < 0) u.cp = D[0];
      const C = est(co, co.price || 0, u.cp);
      const rose = cutRise(co), mx = D[D.length - 1];
      h += '<div class="card pm16"><div class="bhead"><b>Discount campaign</b>' + (rose ? pill('Raised ' + rose + ' wk ago', 'amb') : '') + '</div>' +
        '<div class="rgl"><span>Discount</span>' + (mx > 10 ? slider('cp', u.cp, 10, mx, 5, 'p') : '<b>10%</b>') + '</div><div class="rgl"><span>Length</span>' + slider('w', u.w, 1, 6, 1, 'wk') + '</div>' +
        fcBoxes(co, C, 'd' + co.id + ':' + u.cp, 1) + btn('Start ' + u.cp + '% off for ' + u.w + ' wk', 'pm16camp', { id: co.id }, 'primary wide') + '</div>';
    }
    /* rivals */
    const pw = co.flags.pw;
    if (rs.length) {
      const best = rs.slice().sort((a, b) => b.size - a.size)[0];
      const lr = (t, a, pp) => '<button class="lrow" data-a="' + a + '" data-p="' + P(pp) + '"><span class="ctext"><b>' + t + '</b></span><i>›</i></button>';
      h += '<div class="lrows pm16rows">' + (pw ? lr('Price war · ' + Math.max(0, pw.end - S.week) + ' wk left · end it', 'pwend', { id: co.id }) : lr('Price war', 'go', { n: 'pricewar', p: { id: co.id } })) + lr('Open next to ' + esc(best.name), 'go', { n: 'branch', p: { id: co.id, r: best.id } }) + lr('Talk to a rival or buy one', 'codeal', { id: co.id, s: 'rivals' }) + '</div>';
    }
    return '<div class="pm16w">' + h + '</div>';
  };
  /* raised in the last four weeks? then a "discount" is measured against a price that is not 30 days old */
  function cutRise(co) { const H = co.ph16 || [], now = pmOf(co.price || 0); let w = 99; H.forEach(x => { if (S.week - x[0] <= 4 && now / x[1] - 1 > 0.03) w = Math.min(w, S.week - x[0]); }); return w === 99 ? 0 : Math.max(1, w); }
  ACT.pm16set = p => {
    const u = ui.pm16 || (ui.pm16 = { d: 0.05, cp: 10, w: 2 });
    if (p.k === 'dx') u.d = clamp((+p.v || 0) / 100, -0.2, 0.2);
    else u[p.k] = +p.v;
    render();
  };
  ACT.pm16go = p => {
    const co = getCo(p.id);
    if (!co) return;
    if (co.pref16 == null) co.pref16 = pmOf(co.price || 0);
    co.ph16 = co.ph16 || [[S.week, Math.round(pmOf(co.price || 0) * 1000) / 1000]];
    const old = pmOf(co.price || 0);
    co.price = clamp(p.lv, -3, 3);
    co.flags.priceAt = S.week;
    const ch = co.chain && (S.chains || []).find(x => String(x.id) === String(co.chain));
    if (ch) { co.off = co.off || {}; co.off.pp = Math.round((pmOf(co.price) / pmOf(ch.rules.price || 0) - 1) * 100) / 100; co.off.price = 0; }
    save();
    render();
    toast('Prices ' + pc(pmOf(co.price) / old - 1) + '.');
  };
  ACT.pm16camp = p => {
    const co = getCo(p.id), u = ui.pm16;
    if (!co || !u || !discMax(co)) return;
    const rose = cutRise(co);
    co.camp16 = { pct: u.cp, end: S.week + u.w, w0: S.week, fake: rose || 0 };
    save();
    render();
    toast(u.cp + '% off at ' + co.name + ' for ' + u.w + (u.w > 1 ? ' weeks.' : ' week.'));
  };
  ACT.pm16end = p => { const co = getCo(p.id); if (co && co.camp16) { co.camp16.end = S.week; delete co.camp16; } save(); render(); };

  /* chain price rule in percent */
  PX16.chainCard = ch => {
    const b = pmOf(ch.rules.price || 0);
    return '<div class="card"><div class="bhead"><b>Prices</b>' + pill(Math.abs(b - 1) < 0.005 ? 'Market price' : pc(b - 1) + ' vs market') + '</div><div class="seg7">' + [-0.1, -0.05, -0.02, 0.02, 0.05, 0.1].map(x => '<button data-a="ch16rp" data-p="' + P({ id: ch.id, d: x }) + '">' + pc(x) + '</button>').join('') + '</div></div>';
  };
  ACT.ch16rp = p => {
    const ch = (S.chains || []).find(x => String(x.id) === String(p.id));
    if (!ch) return;
    ch.rules.price = lvlOf(pmOf(ch.rules.price || 0) * (1 + p.d));
    window.R12 && R12.applyAll && R12.applyAll(ch);
    save();
    render();
    toast('Every store ' + pc(p.d) + '.');
  };


  /* marketing: one budget system. Active channels change through the planner, not old fixed levels */
  addStep('CT.marketing', 20, 'marketing: one budget system. Active channels change through the planner, not old fixed levels', (co, bd, h) => {
    return h.replace(/<div class="chips">((?:<button class="btn chip[^"]*" data-a="setmkt" data-p="[^"]*">[^<]*<\/button>)+)<\/div>/g, (m, inner) => {
      const mm = inner.match(/data-p="([^"]*)"/);
      let ch = null;
      try { ch = JSON.parse(mm[1].replace(/&quot;/g, '"').replace(/&amp;/g, '&')).ch; } catch (e) { }
      if (!ch || !co.mkt[ch]) return m;
      const c = co.mkt[ch], left = co.mktEnd && co.mktEnd[ch] ? Math.max(1, co.mktEnd[ch] - S.week) : 0;
      return '<div class="two">' + btn('Change budget', 'plopen', { id: co.id, ch, b: c.b, w: left, ag: co.mktT ? co.mktT.ag : undefined }) + btn('Stop', 'setmkt', { id: co.id, ch, b: 0 }, 'ghost') + '</div>';
    });
  });
}

/* ===== Round 56: tenders, a market of their own.
   Public buyers (the municipality, the county, the health trust, the road authority, a university, a state agency) and
   a few large private ones (a supermarket chain, an industrial buyer) put work out to tender. A tender has a buyer, a
   scope (a volume every week for some years, or one big job), how the bids are scored (price against quality),
   requirements (a minimum rating, a year in business), a deadline and an award date.
   You bid from the company: your price against your list price, a quality commitment, and the cost of writing the bid.
   Real-world shape (EU single market scoreboard, Norwegian procurement rules): about half of procedures are awarded on
   price alone, about one in four gets a single bid, framework agreements run two years with up to two one-year
   extensions, public buyers pay within 30 days.
   Scoring: price points = the lowest price / your price; quality points from your rating, reputation, how you delivered
   earlier public contracts and your commitment; the buyer's weights decide. The rivals' bids are drawn around the
   market price.
   A won tender becomes a contract under the company's Business customers (features/sales/trade_sales_mechanics.js
   sw33 contracts, marked pub) or, for building and design work, a job on the order book. Deliver badly and the buyer
   warns, fines and in the end cancels; deliver well and it extends, and you start the next round as the incumbent.
   Managers bid at list price when the company has room. Shown on the Sales tab (Tenders) and in Group › Group. ===== */
window.TND56 = window.TND56 || {};
(function () {
  const T = window.TND56;
  const U = window.UI, { ui, V, ACT, esc, row, btn, render, save, toast, chips, svg } = U;
  const P = o => esc(JSON.stringify(o));
  const pillp = (t, c) => '<span class="pill ' + (c || '') + '">' + t + '</span>';
  /* what each trade can win: [title, buyer kind, 'vol' (a volume every week) or 'job' (one big job), local or national] */
  const W = {
    cleaning: [['Cleaning of schools and offices', 'muni', 'vol', 1], ['Cleaning of the hospital wards', 'health', 'vol', 1]],
    construction: [['A school extension', 'muni', 'job', 1], ['A new fire station', 'muni', 'job', 1], ['Upgrading a county road', 'road', 'job', 0]],
    electrician: [['Electrical service for municipal buildings', 'muni', 'job', 1], ['Charging points for the county fleet', 'county', 'job', 0]],
    plumber: [['Plumbing service for municipal housing', 'muni', 'job', 1], ['Bathrooms in a nursing home', 'muni', 'job', 1]],
    engcons: [['Design of a sports hall', 'muni', 'job', 1], ['A bridge study', 'road', 'job', 0]],
    event: [['The county’s annual conference', 'county', 'job', 0]],
    webdev: [['A booking system for the municipality', 'muni', 'vol', 0], ['Maintenance of a state agency’s website', 'state', 'vol', 0]],
    cons: [['Advisers for a state reorganisation', 'state', 'vol', 0]],
    mktg: [['The health trust’s recruitment campaign', 'health', 'vol', 0], ['A national brand’s campaign pitch', 'priv', 'vol', 0]],
    acctfirm: [['Accounting for the municipal companies', 'muni', 'vol', 1]],
    law: [['Legal framework agreement for the county', 'county', 'vol', 0]],
    staffing: [['Temporary nurses for the health trust', 'health', 'vol', 0], ['Temporary staff for the municipality', 'muni', 'vol', 1]],
    physio: [['Physiotherapy in nursing homes', 'muni', 'vol', 1]],
    dental: [['Dental care for the county’s children', 'county', 'vol', 1]],
    security: [['Guarding of the municipal buildings', 'muni', 'vol', 1], ['Security at the state offices', 'state', 'vol', 0]],
    carrental: [['Pool cars for the municipality', 'muni', 'vol', 1]],
    restaurant: [['Meals for the nursing homes', 'muni', 'vol', 1]],
    cafe: [['Canteen for the town hall', 'muni', 'vol', 1]],
    foodtruck: [['Lunch for the university campus', 'uni', 'vol', 1]],
    hotel: [['Rooms for travelling state staff', 'state', 'vol', 1], ['Conference rooms for the county', 'county', 'vol', 1]],
    bakery: [['Bread for schools and nursing homes', 'muni', 'vol', 1], ['A supermarket chain’s own bread', 'priv', 'vol', 0]],
    farm: [['Produce for the municipal kitchens', 'muni', 'vol', 0]],
    salmon: [['A supermarket chain’s fresh salmon', 'priv', 'vol', 0]],
    factory: [['A large order for an industrial buyer', 'priv', 'job', 0]],
    furniture: [['Furniture for a new school', 'muni', 'job', 1]],
    taxi: [['Patient transport for the health trust', 'health', 'vol', 1], ['School transport', 'muni', 'vol', 1]],
    courier: [['Lab samples and internal mail', 'health', 'vol', 1]],
    trucking: [['Gravel and road salt transport', 'road', 'vol', 0], ['A manufacturer’s freight', 'priv', 'vol', 0]],
    shipping: [['An exporter’s cargo', 'priv', 'vol', 0]],
    airline: [['A subsidised regional route', 'state', 'vol', 0]],
    carrepair: [['Service of the municipal vehicles', 'muni', 'vol', 1]],
    wh3pl: [['Storage and distribution for the health trust', 'health', 'vol', 0]],
    skires: [['Ski days for the schools', 'muni', 'vol', 1]],
    indoorski: [['Training slots for the ski federation', 'state', 'vol', 1]]
  };
  T.W = W;
  const BUYER = {
    muni: c => cityOf(c).name + ' municipality', county: c => 'The county council', health: c => 'The regional health trust',
    road: c => 'The road authority', uni: c => 'The university', state: c => 'A state agency', priv: c => { try { return brandCoName(CC(), 'svc'); } catch (e) { return 'A large buyer'; } }
  };
  const isPub = k => k !== 'priv';
  const st = () => (S.tnd56 = S.tnd56 || { L: [], hist: {}, auto: {} });
  const eligible = co => co && co.st === 'open' && W[co.type] && co.type !== 'hold';
  T.eligible = eligible;
  const tk = co => { try { return ticketEff(co, BD[co.type]); } catch (e) { return BD[co.type].ticket || 1; } };
  const capU = co => Math.max(0.5, (co.lastW && co.lastW.cap) || (BD[co.type].Dc || 1));
  /* ---------- new tenders ---------- */
  function make(co) {
    const L = W[co.type], w = L[Math.floor(Z() * L.length)], bd = BD[co.type];
    const R = Z, priceOnly = R() < 0.46;
    const t = { id: uid(), cc: co.country, city: w[3] ? co.city : null, type: co.type, title: w[0], bk: w[1], buyer: BUYER[w[1]](co.city), kind: w[2],
      wP: priceOnly ? 1 : Math.round((0.4 + R() * 0.3) * 20) / 20, minR: R() < 0.4 ? 3.5 + Math.round(R() * 6) / 10 : 0, minY: R() < 0.5 ? 1 : 0,
      w0: S.week, due: S.week + 3 + Math.floor(R() * 4), rivals: R() < 0.28 ? 0 : 1 + Math.floor(R() * 5), bids: [] };
    t.award = t.due + 2 + Math.floor(R() * 3);
    if (t.kind === 'vol') { t.u = Math.max(0.5, Math.round(capU(co) * (0.1 + R() * 0.25) * 10) / 10); t.yrs = 2; t.ext = 2; t.val = Math.round(t.u * tk(co) * 52 * t.yrs); }
    else { t.val = rnl(bd.ticket * (typeof ticketMult === 'function' ? ticketMult(co, bd) : 1) * (2 + R() * 4), 1000); t.yrs = 0; t.ext = 0; }
    t.cost = rnl(Math.max(KC(4000, co.country), t.val * (t.kind === 'job' ? 0.004 : 0.0015)), 500); /* writing the bid: documents, prices, references */
    return t;
  }
  addStep('week.after', 57, 'tenders: new ones, awards, contracts', () => {
    if (!S || S.over) return;
    const s = st();
    /* each trade you run sees about one relevant tender every two months in its country */
    const seen = {};
    S.cos.filter(eligible).forEach(co => {
      const k = co.country + ':' + co.type + ':' + (W[co.type].some(w => w[3]) ? co.city : '');
      if (seen[k]) return; seen[k] = 1;
      if (Z() < 1 / 9 && s.L.filter(t => t.type === co.type && t.cc === co.country && t.st == null).length < 3) s.L.push(make(co));
    });
    /* managers bid at list price when they have room and the bid is within their limits */
    s.L.filter(t => t.st == null && S.week < t.due).forEach(t => {
      S.cos.filter(c => eligible(c) && c.type === t.type && c.country === t.cc && (!t.city || c.city === t.city) && c.mgr && S.npcs[c.mgr] && s.auto[c.id] !== 0).forEach(c => {
        if (t.bids.some(b => b.co === c.id) || !qual(t, c).ok) return;
        const room = 1 - ((c.lastW && c.lastW.util) || 0);
        if (t.kind === 'vol' && t.u > capU(c) * room) return;
        if (c.cash < t.cost * 3) return;
        bid(t, c, 1, 0);
        logT(c, S.npcs[c.mgr].name + ' bid for ' + t.title.toLowerCase() + ' at list price.');
      });
    });
    s.L.forEach(t => { if (t.st == null && S.week >= t.award) award(t); });
    s.L = s.L.filter(t => t.st == null || S.week - t.award < 26);
    contractsWeek();
  });
  const logT = (co, txt) => { const L = (co.tnd56log = co.tnd56log || []); L.unshift({ w: S.week, t: txt }); if (L.length > 8) L.length = 8; };
  /* ---------- who may bid ---------- */
  function qual(t, co) {
    const years = (S.week - (co.w0 || 0)) / 52, r = (co.rvN || 0) >= 5 ? ratingOf(co) : 0;
    if (t.minY && years < t.minY) return { ok: false, why: 'Needs a year in business' };
    if (t.minR && r < t.minR) return { ok: false, why: 'Needs ' + t.minR.toFixed(1) + ' stars' };
    return { ok: true };
  }
  /* quality points: rating, reputation, how you delivered for public buyers before, and what you promise */
  function qScore(co, q) {
    const h = st().hist[co.id] || { ok: 0, bad: 0 };
    const r = (co.rvN || 0) >= 5 ? (ratingOf(co) - 2.5) / 2.5 : 0.35;
    return clamp(0.15 + r * 0.4 + ((co.rep || 50) - 50) / 200 + Math.min(0.15, h.ok * 0.05) - h.bad * 0.12 + (q ? 0.12 : 0), 0.05, 1);
  }
  function bid(t, co, pf, q) {
    if (co.cash < t.cost) return 'cash';
    payCo(co, t.cost, 'oth', 'Tender bid: ' + t.title);
    t.bids = t.bids.filter(b => b.co !== co.id);
    t.bids.push({ co: co.id, pf, q, w: S.week });
    return 'ok';
  }
  T.bid = bid;
  /* ---------- the award ---------- */
  function award(t) {
    const R = hrng(S.seed + ':tnd:' + t.id);
    const rivals = Array.from({ length: t.rivals }, () => ({ pf: clamp(0.95 + (R() - 0.5) * 0.18, 0.78, 1.15), q: clamp(0.55 + (R() - 0.5) * 0.4, 0.15, 0.95) }));
    const mine = t.bids.map(b => { const co = getCo(b.co); return co && co.st === 'open' ? Object.assign({ me: 1, qv: qScore(co, b.q) }, b) : null; }).filter(Boolean);
    const all = rivals.map(r => ({ pf: r.pf, qv: r.q })).concat(mine);
    if (!mine.length) { t.st = 'gone'; return; }
    const low = Math.min.apply(null, all.map(b => b.pf));
    all.forEach(b => { b.sc = t.wP * (low / b.pf) + (1 - t.wP) * b.qv; });
    all.sort((a, b) => b.sc - a.sc);
    const win = all[0];
    t.st = win.me ? 'won' : 'lost';
    t.win = win.me ? win.co : null;
    mine.forEach(b => {
      const co = getCo(b.co), place = all.indexOf(b) + 1;
      if (b === win) {
        start(t, co, b);
        addMsg({ kind: 'info', from: t.buyer, title: 'Award: ' + t.title, body: co.name + ' won with ' + Math.round(b.sc * 100) + ' points out of 100 (' + all.length + (all.length === 1 ? ' bid' : ' bids') + '). ' + (t.kind === 'vol' ? 'The contract runs ' + t.yrs + ' years, with up to ' + t.ext + ' one-year extensions, from next week.' : 'Work starts now.'), co: co.id, tone: 'good', status: 'done', ch: 'mail' });
      } else addMsg({ kind: 'info', from: t.buyer, title: 'Not awarded: ' + t.title, body: co.name + ' came ' + ordinal(place) + ' of ' + all.length + ' with ' + Math.round(b.sc * 100) + ' points. The winner had ' + Math.round(win.sc * 100) + (t.wP >= 1 ? ', on price alone.' : '. Price counted ' + Math.round(t.wP * 100) + '%, quality ' + Math.round((1 - t.wP) * 100) + '%.'), co: co.id, tone: 'bad', status: 'done', ch: 'mail' });
    });
  }
  const ordinal = n => n + (n === 1 ? 'st' : n === 2 ? 'nd' : n === 3 ? 'rd' : 'th');
  function start(t, co, b) {
    if (t.kind === 'job' && co.fm) {
      const bd = BD[co.type], tw = bd.tw || {};
      co.fm.jobs = co.fm.jobs || [];
      co.fm.jobs.push({ id: uid(), v: Math.round(t.val * b.pf), wks: Math.max(2, Math.round((tw.wks || 6) * (1.2 + Z() * 0.6))), p: 0, cf: Math.max(0.05, ((tw.mat || 0.5) + (tw.sub || 0)) * (1 + gauss() * (tw.over || 0.1)) / b.pf), delay: 0, w0: S.week, client: t.buyer, pub: isPub(t.bk) ? 1 : 0 });
      logT(co, 'Won ' + t.title.toLowerCase() + ', worth ' + mshort(t.val * b.pf) + '.');
      return;
    }
    const s = (co.sw33 = co.sw33 || { on: {}, ct: [], one: [], ref: 0, mem: 0, peak: {}, last: -99, log: [] });
    s.ct.push({ n: t.title, who: t.buyer, u: t.u, d: 1 - b.pf, end: S.week + 1 + t.yrs * 52, pub: isPub(t.bk) ? 1 : 0, tnd: t.id, ext: t.ext, warn: 0, q: b.q });
    logT(co, 'Won ' + t.title.toLowerCase() + ': ' + (window.rateW ? rateW(t.u, BD[co.type].unit) : t.u + ' a week') + ' for ' + t.yrs + ' years.');
  }
  /* ---------- running contracts: delivery, warnings, fines, extensions, the next round ---------- */
  function contractsWeek() {
    const s = st();
    S.cos.forEach(co => {
      const ct = co.sw33 && co.sw33.ct;
      if (!ct || !ct.some(c => c.tnd)) return;
      const w = co.lastW || {}, served = w.D > 0 ? Math.min(1, (w.units || 0) / w.D) : 1;
      ct.filter(c => c.tnd).forEach(c => {
        /* the buyer gets its volume first; when the company cannot keep up, it notices */
        if (co.st !== 'open' || served < 0.85) {
          c.warn = (c.warn || 0) + 1;
          if (c.warn === 2) addMsg({ kind: 'info', from: c.who, title: 'Warning: ' + c.n, body: co.name + ' is not delivering what the contract says. Another month like this brings a fine.', co: co.id, tone: 'bad', status: 'done', ch: 'mail' });
          if (c.warn === 6) { const f = Math.round(c.u * tk(co) * 4 * 0.1); payCo(co, f, 'fine', 'Contract penalty: ' + c.n); addMsg({ kind: 'info', from: c.who, title: 'Penalty: ' + c.n, body: 'A penalty of ' + money(f) + ' for missed deliveries. If it goes on, the contract is cancelled.', co: co.id, tone: 'bad', status: 'done', ch: 'mail' }); }
          if (c.warn >= 12) { c.end = S.week; c.cut = 1; const h = (s.hist[co.id] = s.hist[co.id] || { ok: 0, bad: 0 }); h.bad++; co.rep = Math.max(0, (co.rep || 50) - 4); addMsg({ kind: 'info', from: c.who, title: 'Contract cancelled: ' + c.n, body: 'The buyer has cancelled the contract with ' + co.name + ' for poor delivery. It will count against you in the next tenders.', co: co.id, tone: 'bad', status: 'done', ch: 'mail' }); }
        } else c.warn = Math.max(0, (c.warn || 0) - 0.25);
        /* at the end of the period: an extension for good delivery, otherwise the work goes out to tender again */
        if (!c.cut && S.week === c.end - 1) {
          const good = (c.warn || 0) < 2;
          if (good && c.ext > 0) { c.ext--; c.end += 52; addMsg({ kind: 'info', from: c.who, title: 'Extended: ' + c.n, body: 'The buyer extends the contract with ' + co.name + ' by a year.' + (c.ext ? ' One more extension is possible.' : ' This is the last extension; the work goes out to tender again after it.'), co: co.id, tone: 'good', status: 'done', ch: 'mail' }); }
          else {
            const h = (s.hist[co.id] = s.hist[co.id] || { ok: 0, bad: 0 }); if (good) h.ok++;
            const t = make(co); t.title = c.n; t.buyer = c.who; t.inc = co.id; t.u = c.u; t.val = Math.round(t.u * tk(co) * 52 * t.yrs); s.L.push(t);
            addMsg({ kind: 'info', from: c.who, title: 'New round: ' + c.n, body: 'The contract ends and the work goes out to tender again. ' + co.name + ' can bid as the company that does it today.', co: co.id, tone: 'n', status: 'done', ch: 'mail' });
          }
        }
      });
    });
  }
  /* ---------- screens ---------- */
  const open = co => st().L.filter(t => t.st == null && S.week < t.due && t.type === co.type && t.cc === co.country && (!t.city || t.city === co.city));
  const mineL = co => st().L.filter(t => t.bids.some(b => b.co === co.id));
  T.summary = co => {
    if (!eligible(co)) return '';
    const o = open(co), w = mineL(co).filter(t => t.st == null), ct = ((co.sw33 && co.sw33.ct) || []).filter(c => c.tnd);
    return [o.filter(t => !t.bids.some(b => b.co === co.id)).length ? o.filter(t => !t.bids.some(b => b.co === co.id)).length + ' open to bid' : '', w.length ? w.length + ' waiting' : '', ct.length ? ct.length + (ct.length > 1 ? ' contracts' : ' contract') : ''].filter(Boolean).join(' · ') || 'None open right now';
  };
  function card(co, t) {
    const b = t.bids.find(x => x.co === co.id), q = qual(t, co);
    const what = t.kind === 'vol' ? (window.rateW ? rateW(t.u, BD[co.type].unit) : t.u + ' a week') + ' · ' + t.yrs + '+' + t.ext + ' years' : 'One job';
    const state = t.st === 'won' ? (t.win === co.id ? pillp('Won', 'grn') : pillp('Lost', 'red')) : t.st === 'lost' ? pillp('Lost', 'red') : t.st === 'gone' ? pillp('Closed') : b ? pillp('Bid sent', 'amb') : pillp(Math.max(0, t.due - S.week) + ' wk to bid', 'blue');
    return '<button class="lrow' + (!b && t.st == null && !q.ok ? ' cant' : '') + '" data-a="go" data-p="' + P({ n: 'tnd56', p: { id: co.id, t: t.id } }) + '"><span class="lic">' + svg(isPub(t.bk) ? 'house' : 'biz', 20) + '</span><span class="ctext"><b>' + esc(t.title) + '</b><small>' + esc(t.buyer) + ' · ' + what + ' · about ' + mshort(t.val) + (t.inc === co.id ? ' · you deliver it today' : '') + (!q.ok && !b && t.st == null ? ' · <span class="need">' + q.why + '</span>' : '') + '</small></span>' + state + '</button>';
  }
  V.titles.tnd56 = 'Tenders';
  V.heads.tnd56 = p => { const co = getCo(p.id); return { t: p.t ? 'Tender' : 'Tenders', sub: co ? esc(co.name) : '' }; };
  V.tnd56 = function (p) {
    const co = getCo(p.id);
    if (!co) return '<div class="calm">Gone.</div>';
    if (p.t) return bidView(co, st().L.find(t => t.id === p.t));
    const o = open(co), done = mineL(co).filter(t => t.st != null).slice(-6).reverse();
    const ct = ((co.sw33 && co.sw33.ct) || []).filter(c => c.tnd);
    let h = '<div class="card"><span class="tipt">Buyers publish work, firms bid, and the best score wins: price against quality, in the buyer’s own weights. Writing a bid costs money even when you lose.</span>' + (co.mgr && S.npcs[co.mgr] ? '<span class="lab">' + esc(S.npcs[co.mgr].name.split(' ')[0]) + ' bids at list price when there is room</span>' + chips([[1, 'Yes'], [0, 'Ask me']], st().auto[co.id] === 0 ? 0 : 1, 'tnd56auto', { id: co.id }) : '') + '</div>';
    h += '<h2 class="sec">Open now</h2>' + (o.length ? '<div class="lrows">' + o.map(t => card(co, t)).join('') + '</div>' : '<div class="calm">Nothing open for ' + esc(BD[co.type].n.toLowerCase()) + ' right now. New tenders come every few weeks.</div>');
    if (ct.length) h += '<h2 class="sec">Contracts won</h2><div class="lrows">' + ct.map(c => '<div class="lrow"><span class="lic">' + svg('house', 20) + '</span><span class="ctext"><b>' + esc(c.n) + '</b><small>' + esc(c.who) + ' · until ' + dateStr(c.end) + (c.ext ? ' · ' + c.ext + ' extension' + (c.ext > 1 ? 's' : '') + ' possible' : '') + '</small></span>' + (c.warn >= 2 ? pillp('Warned', 'red') : pillp('On track', 'grn')) + '</div>').join('') + '</div>';
    if (done.length) h += '<h2 class="sec">Results</h2><div class="lrows">' + done.map(t => card(co, t)).join('') + '</div>';
    return h;
  };
  function bidView(co, t) {
    if (!t) return '<div class="calm">This tender has closed.</div>';
    const b = t.bids.find(x => x.co === co.id), q = qual(t, co);
    const F = ui.tnd56 = ui.tnd56 && ui.tnd56.t === t.id ? ui.tnd56 : { t: t.id, pf: 1, q: 0 };
    let h = '<div class="card"><b>' + esc(t.title) + '</b><span class="tipt">' + esc(t.buyer) + (isPub(t.bk) ? ' · public buyer' : ' · private buyer') + '</span>' +
      row('Scope', t.kind === 'vol' ? (window.rateW ? rateW(t.u, BD[co.type].unit) : t.u + ' a week') + ' for ' + t.yrs + ' years, up to ' + t.ext + ' more' : 'One job') +
      row('Worth about', money(t.val)) + row('Scored on', t.wP >= 1 ? 'Price only' : 'Price ' + Math.round(t.wP * 100) + '% · quality ' + Math.round((1 - t.wP) * 100) + '%') +
      (t.minR || t.minY ? row('Requires', [t.minY ? 'a year in business' : '', t.minR ? t.minR.toFixed(1) + ' stars' : ''].filter(Boolean).join(' and ')) : '') +
      row('Bids close', dateStr(t.due) + ' · award ' + dateStr(t.award)) + '</div>';
    if (t.st != null) return h + '<div class="calm">' + (t.st === 'won' && t.win === co.id ? 'You won this one.' : t.st === 'gone' ? 'Closed.' : 'Another firm won.') + '</div>';
    if (b) return h + '<div class="card">' + row('Your bid', Math.round(b.pf * 100) + '% of list price' + (b.q ? ' · higher quality' : '')) + '<span class="tipt">The buyer announces the winner on ' + dateStr(t.award) + '. You can change the bid until ' + dateStr(t.due) + ' (writing it again costs ' + mshort(t.cost) + ').</span></div>' + btn('Change the bid', 'tnd56re', { id: co.id, t: t.id }, 'ghost wide');
    if (!q.ok) return h + '<div class="note bad">' + q.why + ' to bid.</div>';
    const cap = t.kind === 'vol' ? t.u / capU(co) : 0, qv = qScore(co, F.q);
    h += '<div class="card"><span class="lab">Your price against your list price</span>' + chips([0.85, 0.9, 0.95, 1, 1.05, 1.1].map(v => [v, Math.round(v * 100) + '%']), F.pf, 'tnd56set', { k: 'pf' }) +
      '<span class="lab">Quality you commit to</span>' + chips([[0, 'Standard'], [1, 'Higher (costs about 3% more to deliver)']], F.q, 'tnd56set', { k: 'q' }) +
      row('Your quality points', Math.round(qv * 100) + ' of 100') + (cap ? row('Takes of your capacity', '<span class="' + (cap > 0.5 ? 'neg' : cap > 0.3 ? 'amb' : '') + '">about ' + Math.round(cap * 100) + '%</span>') : '') +
      row('Writing the bid costs', money(t.cost)) + '<span class="tipt">' + (t.rivals === 0 ? 'Few firms seem interested.' : 'Several firms are expected to bid.') + ' Lower prices win more often on price-heavy tenders, but you deliver at that price for years.</span></div>' +
      btn('Send the bid', 'tnd56go', { id: co.id, t: t.id }, 'primary wide' + (co.cash < t.cost ? ' cant' : ''));
    return h;
  }
  ACT.tnd56set = p => { ui.tnd56 = ui.tnd56 || {}; ui.tnd56[p.k] = +p.v; render(); };
  ACT.tnd56go = p => {
    const co = getCo(p.id), t = st().L.find(x => x.id === p.t), F = ui.tnd56 || { pf: 1, q: 0 };
    if (!co || !t || t.st != null || S.week >= t.due) return;
    const r = bid(t, co, F.pf, F.q);
    if (r !== 'ok') { toast('Not enough cash in the company to write the bid.', true); return; }
    logT(co, 'Bid for ' + t.title.toLowerCase() + ' at ' + Math.round(F.pf * 100) + '% of list price.');
    save(); render(); toast('Bid sent. The result comes on ' + dateStr(t.award) + '.');
  };
  ACT.tnd56re = p => { const t = st().L.find(x => x.id === p.t); if (!t) return; t.bids = t.bids.filter(b => b.co !== p.id); render(); };
  ACT.tnd56auto = p => { st().auto[p.id] = +p.v; save(); render(); };
  /* higher quality costs a little more to deliver on the contract */
  addStep('modProd', 25, 'tender contracts with a quality promise', (co, k, v) => {
    if (k !== 'cogsup' || !co.sw33 || !co.sw33.ct) return v;
    const u = co.sw33.ct.filter(c => c.tnd && c.q).reduce((a, c) => a + c.u, 0), all = Math.max(u, (co.lastW && co.lastW.units) || 0);
    return u > 0 && all > 0 ? v * (1 + 0.03 * u / all) : v;
  });
  T.open = open;
})();

/* ===== Round 56: every trade counts what matters in it. The This week card on a company's overview
   (features/sales/trades_in_hours.js weekCardAll) shows these rows under what was sold, and names the capacity bar and
   the demand line in the trade's own words: a hotel shows occupancy, room rate and revenue per room; a law firm the
   hours billed, the rate and how much of its billable time is used; an estate agent its commission per sale and the
   homes it has for sale (sales a week times the usual time on the market, about seven weeks).
   [cap: the capacity bar, of: after the percentage, ask: the demand line, rows: [label, value from last week]] ===== */
window.TSTAT = window.TSTAT || {};
(function () {
  const T = window.TSTAT;
  const per = w => (w.units > 0 ? w.rev / w.units : 0);
  const m = v => (v > 0 ? mshort(v) : '–');
  const n = (v, d) => (v > 0 ? (v >= 10 || !d ? Math.round(v).toLocaleString('en-US').replace(/,/g, ' ') : v.toFixed(d)) : '0');
  const day = w => (w.units || 0) / 7;
  const util = w => Math.min(1, w.util || 0);
  const R = (cap, of, ask, rows) => ({ cap, of, ask, rows });
  /* the same rows for a few related trades */
  const hours = (rate) => R('Billable hours used', 'of the team’s hours', 'Clients asking', [['Billing rate', w => m(per(w)) + (rate ? '/h' : '')], ['Billed last week', w => m(w.rev)]]);
  const chairs = (what) => R(what + ' booked', 'of the time', 'Clients wanting a time', [['Average price', w => m(per(w))], ['Treatments a day', w => n(day(w), 1)]]);
  const basket = R('Tills busy', 'of your till time', 'Shoppers coming in', [['Baskets a day', w => n(day(w))], ['Average basket', w => m(per(w))]]);
  Object.assign(T, {
    cons: hours(1), mktg: hours(1), law: hours(1), acctfirm: hours(1), webdev: hours(1), gamestudio: hours(1),
    dental: chairs('Treatment chairs'),
    security: R('Guard hours sold', 'of the guards’ hours', 'Clients asking', [['Rate per hour', w => m(per(w))], ['Hours a day', w => n(day(w), 1)]]),
    pcbang: R('PCs in use', 'of the seat hours', 'Gamers waiting for a seat', [['Spent per hour', w => m(per(w))], ['Hours played a day', w => n(day(w))]]),
    carrental: R('Cars out on hire', 'of the fleet’s days', 'Customers turned away', [['Price per day', w => m(per(w))], ['Rentals a day', w => n(day(w), 1)]]),
    vineyard: R('Bottles sold', 'of what the cellar can ship', 'Orders waiting', [['Price per bottle', w => m(per(w))], ['Bottles a day', w => n(day(w))]]),
    staffing: R('Hours placed', 'of what your people could work', 'Clients needing people', [['Charged per hour', w => m(per(w))], ['Billed last week', w => m(w.rev)]]),
    cleaning: R('Cleaning hours used', 'of the team’s hours', 'Clients asking', [['Rate per hour', w => m(per(w))], ['Hours a day', w => n(day(w), 1)]]),
    tutor: R('Lesson hours booked', 'of your teaching time', 'Students asking', [['Price per hour', w => m(per(w))], ['Lessons a day', w => n(day(w), 1)]]),
    drivsk: R('Lessons booked', 'of the instructors’ time', 'Learners asking', [['Price per lesson', w => m(per(w))], ['Lessons a day', w => n(day(w), 1)]]),
    barber: chairs('Chairs'), physio: chairs('Treatment rooms'), pets: R('Visits booked', 'of your time', 'Owners asking', [['Price per visit', w => m(per(w))], ['Visits a day', w => n(day(w), 1)]]),
    carclean: R('Wash bays busy', 'of the time', 'Cars queuing', [['Average wash', w => m(per(w))], ['Cars a day', w => n(day(w))]]),
    photo: R('Shoot days booked', 'of your days', 'Clients asking', [['Average shoot', w => m(per(w))]]),
    handy: R('Hours booked', 'of your hours', 'Jobs asked for', [['Average job', w => m(per(w))]]),
    estate: R('Agents’ time used', 'of their time', 'Sellers asking for a valuation', [['Commission per sale', w => m(per(w))], ['Homes for sale with you', w => 'about ' + n((w.units || 0) * 7)], ['Viewings a week', w => 'about ' + n((w.units || 0) * 7 * 2)]]),
    foodtruck: R('Serving hatch busy', 'of the time', 'People queuing', [['Meals a day', w => n(day(w))], ['Average meal', w => m(per(w))]]),
    cafe: R('Seats and counter busy', 'of what you can serve', 'Guests coming in', [['Orders a day', w => n(day(w))], ['Average order', w => m(per(w))]]),
    restaurant: R('Tables filled', 'of your covers', 'Guests wanting a table', [['Covers a day', w => n(day(w))], ['Average bill per guest', w => m(per(w))]]),
    nightclub: R('Room filled', 'of your capacity', 'People at the door', [['Guests a week', w => n(w.units)], ['Spend per guest', w => m(per(w))]]),
    gym: R('Floor busy', 'of what it can hold', 'People wanting to join', [['Fee per member a month', w => m(per(w) * 52 / 12)]]),
    hotel: R('Occupancy', 'of your room-nights', 'Guests wanting a room', [['Average room rate', w => m(per(w))], ['Revenue per available room', w => m(per(w) * util(w))]]),
    casino: R('Floor busy', 'of the tables and machines', 'Guests coming in', [['Visits a day', w => n(day(w))], ['Spend per visit', w => m(per(w))]]),
    fun: R('Tickets sold', 'of what you can take', 'People wanting tickets', [['Tickets a day', w => n(day(w))], ['Average ticket', w => m(per(w))]]),
    kiosk: basket, grocery: basket, hardware: basket, boutique: basket,
    webshop: R('Packing capacity used', 'of what you can ship', 'Orders coming in', [['Orders a day', w => n(day(w))], ['Average order', w => m(per(w))]]),
    cardealer: R('Sales staff busy', 'of their time', 'Buyers looking', [['Average price', w => m(per(w))], ['Cars sold a month', w => n((w.units || 0) * 52 / 12, 1)]]),
    bakery: R('Ovens running', 'of the bake capacity', 'Orders and shoppers', [['Items a day', w => n(day(w))], ['Price per item', w => m(per(w))]]),
    brewery: R('Brewhouse running', 'of its capacity', 'Buyers asking', [['Litres a week', w => n(w.units)], ['Price per litre', w => m(per(w))]]),
    furniture: R('Workshop running', 'of its capacity', 'Orders asked for', [['Pieces a week', w => n(w.units, 1)], ['Price per piece', w => m(per(w))]]),
    salmon: R('Harvest capacity used', 'of the farm', 'Buyers asking', [['Tonnes a week', w => n(w.units, 1)], ['Price per kilo', w => m(per(w) / 1000)]]),
    factory: R('Line running', 'of its capacity', 'Orders asked for', [['Lots a week', w => n(w.units, 1)], ['Price per lot', w => m(per(w))]]),
    farm: R('Land and barns used', 'of what they can give', 'Buyers asking', [['Tonnes a week', w => n(w.units, 1)], ['Price per tonne', w => m(per(w))]]),
    taxi: R('Cars busy', 'of the driving hours', 'People wanting a ride', [['Rides a day', w => n(day(w))], ['Average fare', w => m(per(w))]]),
    courier: R('Vans busy', 'of the delivery capacity', 'Parcels to collect', [['Parcels a day', w => n(day(w))], ['Paid per parcel', w => m(per(w))]]),
    trucking: R('Trucks busy', 'of the fleet', 'Loads offered', [['Trips a week', w => n(w.units, 1)], ['Paid per trip', w => m(per(w))]]),
    shipping: R('Ships sailing full', 'of the fleet', 'Cargo offered', [['Voyages a week', w => n(w.units, 1)], ['Paid per voyage', w => m(per(w))]]),
    airline: R('Seats filled', 'of the seats flown', 'Passengers booking', [['Flights a week', w => n(w.units)], ['Revenue per flight', w => m(per(w))]]),
    resrent: R('Occupancy', 'of your flats', 'People looking for a flat', [['Rent per flat a month', w => m(per(w) * 52 / 12)]]),
    comrent: R('Occupancy', 'of your square metres', 'Businesses looking', [['Rent per m² a year', w => m(per(w) * 52)]]),
    carrepair: R('Lifts in use', 'of the workshop hours', 'Cars waiting for a slot', [['Average job', w => m(per(w))], ['Jobs a day', w => n(day(w), 1)]]),
    wh3pl: R('Warehouse capacity used', 'of what you can handle', 'Orders coming in', [['Orders a day', w => n(day(w))], ['Paid per order', w => m(per(w))]]),
    skires: R('Lifts busy', 'of the lift capacity', 'Skiers coming', [['Skier days a week', w => n(w.units)], ['Spend per skier day', w => m(per(w))], ['Snow this season', (w, co) => co.snow56 ? (co.snow56.f >= 0.9 ? 'Great' : co.snow56.f >= 0.65 ? 'Normal' : 'Poor') + (co.snow56.made ? ' · snowmaking' : '') : '–']]),
    indoorski: R('Slope busy', 'of the hall capacity', 'People wanting to ski', [['Visits a day', w => n(day(w))], ['Spend per visit', w => m(per(w))]]),
    parking: R('Occupancy', 'of your spaces', 'Drivers looking', [['Paid per space a month', w => m(per(w) * 52 / 12)]])
  });
})();

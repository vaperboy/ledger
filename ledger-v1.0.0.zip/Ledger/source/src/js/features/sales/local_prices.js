/* ===== Round 8b: local prices track local costs, small firms can start lean, equipment setup counts people ===== */
{
  const NOWORK = { rent: 1, fin: 1, energy: 1, club: 1, hold: 1 };
  /* a haircut in a high-wage city costs more: prices follow the local mix of wages, rent and goods */
  function shares(bd) {
    if (bd._ls) return bd._ls;
    const R0 = Math.max(1, bd.Dc * bd.ticket);
    let W = 0;
    bd.std.forEach(s => { W += s[1] * ROLES[s[0]][1] * 12 / 52 * 1.166 * 1.2; });
    const Rn = bd.prem && PREM[bd.prem[0]] ? bd.prem[1] * PREM[bd.prem[0]][1] / 52 : 0;
    let ws = W / R0, rs = Rn / R0;
    const t = ws + rs;
    if (t > 0.85) { ws *= 0.85 / t; rs *= 0.85 / t; }
    return (bd._ls = [ws, rs]);
  }
  function locF(co, bd) {
    const c = cityOf(co.city);
    if (!c || !c.price || !bd.Dc || NOWORK[bd.fam]) return 1;
    const [ws, rs] = shares(bd);
    const f = (ws * (c.wage || 1) + rs * (c.rent || 1) + (1 - ws - rs) * c.price) / c.price;
    return 1 + (f - 1) * 0.85;
  }
  window.locF = locF;
  /* contractors: their margin depends on what the job costs, not on the price tag */
  addStep('modProd', 10, 'contractors: their margin depends on what the job costs, not on the price tag', (co, k, r) => {
    if (k !== 'price' || !co || !co.type || !BD[co.type] || BD[co.type].fam !== 'project') return r;
    return r / Math.sqrt((window.R8.PF && window.R8.PF[co.type]) || 1);
  });
  addStep('ticketMult', 20, 'local prices and job sizes', (co, bd, r) => co && bd ? r * locF(co, bd) * (bd.fam === 'project' ? (bd.tw.dev ? 1 : window.R8.jobScale(co)) : ((window.R8.PF && window.R8.PF[bd.id]) || 1)) : r, true);
  /* small firms: one person can cover the side jobs (the cook, the receptionist) until the place grows */
  addStep('stdStaff', 10, 'small firms: one person can cover the side jobs (the cook, the receptionist) until the place grows', (bd, size, r) => {
    if ((size || 1) > 0.6) return r;
    return r.map((s, i) => [s[0], i === 0 ? s[1] : Math.max(0, Math.round(bd.std[i][1] * size))]);
  });
  addStep('capacity', 10, 'small firms: the owner covers support jobs', (co, bd, res) => {
    {
      if (bd.fam === 'project' && !bd.tw.dev) res.cap *= Math.sqrt((window.R8.PF && window.R8.PF[bd.id]) || 1);
      if (!bd.std || bd.std.length < 2 || NOWORK[bd.fam]) return res;
      const parts = res.parts;
      const min0 = Math.min.apply(null, parts.map(p => p.cap));
      const mult = min0 > 0 ? res.cap / min0 : null;
      let ch = false;
      bd.std.forEach((s, i) => {
        if (i === 0) return;
        const p = parts.find(x => x.k === 'role:' + s[0]);
        if (!p || co.staff.some(x => x.role === s[0])) return;
        const cover = p.capPer * 0.45 * ((co.size || 1) <= 0.6 ? 1 : 0.4);
        if (cover > p.cap) { p.cap = cover; p.cover = 1; ch = true; }
      });
      if (!ch || mult == null) return res;
      let cap = Infinity, bot = null;
      parts.forEach(p => { if (p.cap < cap) { cap = p.cap; bot = p; } });
      res.cap = Math.max(0, cap * mult);
      res.bot = bot;
    }
  });
  /* automatic setup buys one of each personal item per person, like the Needed list */
  function topUpEq(co) {
    const bd = BD[co.type];
    if (!window.R6) return;
    bd.eq.forEach(e => {
      if (!R6.ruleOf(bd, e)) return;
      let short = R6.needOf(co, bd, e) - eqCount(co, e.id);
      let guard = 0;
      while (short > 0 && guard++ < 12) {
        let r;
        if (e.vo) { r = buyVeh(co, e.id, e.vo[0], 'new'); if (r === 'cash') r = buyVeh(co, e.id, e.vo[0], 'finance'); if (r === 'cash') r = buyVeh(co, e.id, e.vo[0], 'lease'); }
        else { r = buyEq(co, e.id, short, 'new'); if (r === 'cash') r = buyEq(co, e.id, short, 'finance'); }
        if (r !== 'ok') break;
        short = R6.needOf(co, bd, e) - eqCount(co, e.id);
      }
    });
  }
  window.topUpEq = topUpEq;
}
/* when the overdraft is used up and bills go unpaid for weeks, the company goes under */
{
  addStep('week.after', 70, 'bankrupt after seven weeks past the overdraft', () => {
    S.cos.slice().forEach(co => {
      if ((co.st === 'open' || co.st === 'closed') && co.type !== 'hold' && (co.negW || 0) > 6 && co.cash < -coOverdraft(co)) bankrupt(co, 'cash');
    });
  });
}
/* people forget a name they barely heard: low awareness fades faster without marketing */
{
  addStep('awareDecay', 10, 'local_prices awareDecay', (co, d) => {
    const spend = co && co.mkt ? Object.keys(co.mkt).reduce((t, k) => t + (co.mkt[k].b || 0), 0) : 0;
    return spend > 0 ? d : d * 0.96;
  });
}


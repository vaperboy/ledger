/* ===== Round 56: the organisation of a chain, top to bottom, each with a duty, a growth job and who approves them:
   Owner (you) · Board · Managing director (the group) · CEO (one per chain) · Chain manager · Regional managers (one per
   city) · Store managers · Assistant store managers. Requests climb this ladder (engine/management/managers.js chainOf)
   until someone with the authority and the budget decides (features/company/chain_hierarchy.js); only what nobody below
   can approve reaches the board, that is you.
   Each level grows the business in its own way, about once a month:
   - assistant store managers book training when service slips (approved by the store manager)
   - store managers market locally (managers_keep_it_working.js), regional managers expand stores that are too small
     (space requests), both through the requests above
   - the chain manager opens a new store where the chain's stores are fullest, paid from the stores' spare cash
     (approved by the CEO, the managing director or you)
   - the CEO takes the chain into a new city (approved by the managing director or the board, that is you)
   Every level is hired on the step screen through the agency (ui/screens/hiring.js, the roles in MR56 below); their pay, and the chain and regional managers' pay, is shared by the
   chain's stores by revenue, not paid from your own pocket. ===== */
window.ORG56 = window.ORG56 || {};
(function () {
  const O = window.ORG56;
  const LV = [
    ['owner', 'Owner', 'Ownership oversight', 'Major investments', 'Shareholders and the board'],
    ['board', 'Board of directors', 'Corporate governance', 'Long-term strategy', 'Major decisions'],
    ['md', 'Managing director', 'Company management', 'Business expansion', 'The board'],
    ['ceo56', 'CEO', 'Company strategy', 'New markets', 'The board'],
    ['chainmgr', 'Chain manager', 'Chain performance', 'New stores', 'The CEO'],
    ['region', 'Regional manager', 'Regional performance', 'Local expansion', 'The chain manager'],
    ['mgr', 'Store manager', 'Daily operations', 'Local marketing', 'The regional manager'],
    ['asst', 'Assistant store manager', 'Staff support', 'Service improvements', 'The store manager']
  ];
  O.LV = LV;
  const PAY = { md: 130000, ceo56: 95000, chainmgr: 70000, region: 58000 };
  const BUY = { md: 2000000, ceo56: 600000, chainmgr: 250000, region: 80000 };
  const org = () => (S.org56 = S.org56 || {});
  const chs = () => (S.chains || []).filter(ch => R12.storesOf(ch).length);
  const regs = () => S.group.regional || [];
  const cityOfCh = ch => Array.from(new Set(R12.storesOf(ch).map(c => c.city)));
  const spare = c => Math.max(0, c.cash - coWeekCost(c) * 8 - KC(20000, c.country));
  const nm = x => x && S.npcs[x.npc] ? S.npcs[x.npc] : null;

  /* ---------- approval up the ladder: from a level, the first one above with the authority decides; else you ---------- */
  function approve(co, from, cost, title, why, act, data) {
    const L = chainOf(co), i = L.findIndex(x => x.kind === from), up = L.slice(i + 1);
    const b = up.find(x => x.lvl >= 2 || (x.lvl >= 1 && cost <= (x.buy || 0)));
    if (b) { O.run(act, data); note(b.npc.name + ' (' + titleFor(co, b.kind) + ') approved: ' + title + '. ' + why, 'n', co.id); return true; }
    const top = up[up.length - 1] || L[i];
    if (S.inbox.some(m => m.act === 'org56' && m.status === 'open' && m.data && m.data.key === act + ':' + (data.ch || data.co))) return false;
    addMsg({ kind: 'ask', from: top ? top.npc.name : co.name, role: top ? titleFor(co, top.kind) : '', title, body: why + ' It is above what anyone below the board can approve, so it is yours to decide.', co: co.id, act: 'org56', data: Object.assign({ key: act + ':' + (data.ch || data.co), a: act }, data), exp: S.week + 3, tone: 'n', opts: [{ l: 'Approve', d: cost ? money(cost) : '', fx: {} }, { l: 'Not now', d: '', fx: {} }] });
    return false;
  }
  ACTS.org56 = (m, idx) => { if (idx === 0 && m.data) O.run(m.data.a, m.data); return true; };

  /* ---------- what the levels do ---------- */
  function openStore(ch, city, why) {
    const L = R12.storesOf(ch), f = L[0];
    if (!f) return null;
    const est = setupEstimate(ch.type, { city, size: 1, form: f.form, country: f.country || S.country });
    let need = rnl(est.total * 1.15, 1000);
    const parts = [];
    L.slice().sort((a, b) => spare(b) - spare(a)).forEach(s => { if (need <= 0) return; const x = Math.min(spare(s), need); if (x > 1000) { parts.push([s, x]); need -= x; } });
    if (need > 1000) return null;
    const n = startCompany(ch.type, { name: 'New store ' + uid(), city, size: 1, form: f.form, country: f.country || S.country });
    if (!n || typeof n === 'string') return null;
    parts.forEach(([s, x]) => { moveCash(s, -x); s.tx.unshift({ w: S.week, a: -x, l: 'Funding a new store' }); moveCash(n, x); });
    for (const k in f.docs) if (f.docs[k] && f.docs[k].st === 'ok' && k !== 'chain') n.docs[k] = Object.assign({}, f.docs[k]);
    n.ohrs = 0; n.open13 = S.week + 3;
    R12.joinChain(ch, n, true);
    note(n.name + ' opens in about three weeks: ' + why, 'good', n.id);
    return n;
  }
  O.run = function (act, d) {
    if (act === 'store') { const ch = R12.chainById(d.ch); if (ch) openStore(ch, d.city, d.why || ''); }
    else if (act === 'course') { const co = getCo(d.co); if (co && co.cash > d.cost) { payCo(co, d.cost, 'oth', 'Staff training'); co.q = Math.min(100, (co.q || 50) + 4); co.org56c = S.week; } }
  };
  function storeCost(ch, city) { const f = R12.storesOf(ch)[0]; return f ? rnl(setupEstimate(ch.type, { city, size: 1, form: f.form, country: f.country || S.country }).total * 1.15, 1000) : 0; }
  addStep('week.after', 67, 'every level of the organisation grows the business in its own way', () => {
    if (S.week % 4 !== 1 || !window.R12) return;
    /* assistant store managers: service improvements */
    S.cos.forEach(co => {
      if (co.st !== 'open' || !co.asst || !S.npcs[co.asst.npc] || (co.q || 60) >= 60 || S.week - (co.org56c || -99) < 26) return;
      const cost = rnl(KC(450, co.country) * Math.max(1, co.staff.length), 100);
      if (co.cash < cost * 3) return;
      co.org56c = S.week;
      if (co.mgr && (co.auth.lvl || 0) >= 1 && cost <= (co.auth.buy || 0)) { O.run('course', { co: co.id, cost }); note(S.npcs[co.asst.npc].name + ' (assistant) booked a course for the team at ' + co.name + ', approved by ' + S.npcs[co.mgr].name + ': service had slipped.', 'n', co.id); }
    });
    chs().forEach(ch => {
      const L = R12.storesOf(ch).filter(c => c.st === 'open'), cm = regs().find(r => r.scope === 'chain:' + ch.id), anyCo = L[0];
      if (!L.length) return;
      const prof = L.every(c => (c.hist || []).slice(-3).length === 3 && c.hist.slice(-3).reduce((a, x) => a + x.profit, 0) > 0);
      const full = L.map(c => [c, c.lastW && c.lastW.cap ? (c.lastW.D || 0) / c.lastW.cap : 0]).sort((a, b) => b[1] - a[1]);
      ch.org56 = ch.org56 || {};
      /* chain manager: a new store where the stores are fullest */
      if (nm(cm) && prof && full[0][1] >= 1.15 && S.week - (ch.org56.st || -99) >= 26) {
        const city = full[0][0].city, cost = storeCost(ch, city);
        if (sum(L, spare) >= cost) { ch.org56.st = S.week; approve(anyCo, 'chainmgr', cost, 'Open another ' + (window.siteW ? siteW(ch.type, 1) : 'store') + ' in ' + cityOf(city).name, nm(cm).name + ' (chain manager): ' + full[0][0].name + ' turns customers away, and the chain can pay ' + money(cost) + ' from its own cash.', 'store', { ch: ch.id, city, why: 'the stores there were full.' }); }
      }
      /* CEO: a new market, a city the chain is not in */
      if (nm(ch.ceo56) && prof && L.length >= 3 && S.week - (ch.org56.mk || -99) >= 52) {
        const have = cityOfCh(ch), C = (CO[anyCo.country || S.country] || CC()).cities.filter(c => have.indexOf(c.id) < 0).sort((a, b) => (b.pop || 0) - (a.pop || 0))[0];
        if (C) { const cost = storeCost(ch, C.id); if (sum(L, spare) >= cost) { ch.org56.mk = S.week; approve(anyCo, 'ceo56', cost, 'Take ' + ch.name + ' to ' + C.name, nm(ch.ceo56).name + ' (CEO): every store makes money, and ' + C.name + ' has no ' + BD[ch.type].n.toLowerCase() + ' of ours yet.', 'store', { ch: ch.id, city: C.id, why: 'a new market for the chain.' }); } }
      }
      /* stores without a manager get one from the chain manager */
      if (nm(cm) && window.CHN56) L.concat(R12.storesOf(ch).filter(c => c.st === 'setup')).forEach(c => { if (!c.mgr) CHN56.fillManager(c, nm(cm).name + ' (chain manager)', 'the store had no manager'); });
    });
  });
  /* ---------- pay: the chain's stores share the chain's management by revenue; the managing director by everyone ---------- */
  function share(L, amt, label) {
    const tot = sum(L, c => Math.max(1, (c.lastW && c.lastW.rev) || 1));
    L.forEach(c => payCo(c, amt * Math.max(1, (c.lastW && c.lastW.rev) || 1) / tot, 'wages', label));
  }
  addStep('week.after', 68, 'the organisation is paid by the companies it runs', () => {
    if (!window.R12) return;
    chs().forEach(ch => {
      const L = R12.storesOf(ch).filter(c => c.st === 'open');
      if (!L.length) return;
      let w = 0;
      regs().forEach(r => { if (String(r.scope).indexOf('chain:' + ch.id) === 0) { r.payCo = 'chain'; w += r.wage || 0; } });
      if (nm(ch.ceo56)) w += ch.ceo56.wage || 0;
      if (w > 0) share(L, w * 12 / 52 * OC(), 'Chain management');
    });
    const md = org().md;
    if (nm(md)) { const L = S.cos.filter(c => c.st === 'open' && c.type !== 'hold'); if (L.length) share(L, md.wage * 12 / 52 * OC(), 'Managing director'); }
  });

  /* ---------- the chart ---------- */
  const U = window.UI;
  if (!U) return;
  const { V, ACT, esc, btn, render, save, toast, openSheet } = U;
  const P = o => esc(JSON.stringify(o));
  V.titles.org56 = 'Organisation';
  V.heads = V.heads || {};
  V.heads.org56 = p => { const ch = R12.chainById(p.id); return { t: 'Organisation', sub: ch ? esc(ch.name) : '' }; };
  const person = (n, sub) => '<span class="ctext"><b>' + esc(n.name) + '</b><small>' + sub + '</small></span>';
  V.org56 = function (p) {
    const ch = R12.chainById(p.id);
    if (!ch) return '<div class="calm">This chain no longer exists.</div>';
    const L = R12.storesOf(ch), co = L[0], cm = regs().find(r => r.scope === 'chain:' + ch.id), md = org().md || S.group.ceo;
    const seats = (R12.seatsOf ? R12.seatsOf('ch:' + ch.id) : []).length;
    const lvl = (k, who, extra) => { const l = LV.find(x => x[0] === k); return '<div class="org56"><div class="orgh"><span class="orgn">' + (LV.indexOf(l) + 1) + '</span><b>' + l[1] + '</b></div>' + (who || '') + '<small class="orgd">Duties: ' + l[2] + ' · Growth: ' + l[3] + ' · Approved by: ' + l[4] + '</small>' + (extra || '') + '</div>'; };
    const vac = (role, city) => '<button class="lrow vac56" data-a="go" data-p="' + P(O.hireP(role, ch, city)) + '"><span class="ctext"><b>Vacant</b><small>' + (role === 'region' ? esc(cityOf(city).name) + ' · ' : '') + 'Their decisions go to the level above · ~' + mshort(KC(PAY[role])) + '/mo</small></span><span class="pill">Hire ›</span></button>';
    const filled = (n, sub) => '<div class="lrow">' + (window.faceAv ? faceAv(n) : '') + person(n, sub) + '</div>';
    let h = '<div class="card sense"><span class="tipt">Each level decides within its budget and passes the rest up. Vacant levels are skipped. You see what they decided in your notes.</span></div>';
    h += lvl('owner', filled({ name: S.player.name || 'You' }, 'You own ' + Math.round(co ? co.own : 100) + '%'));
    h += lvl('board', '<div class="lrows"><button class="lrow" data-a="go" data-p="' + P({ n: 'chain12', p: { id: ch.id, t: 'board' } }) + '"><span class="ctext"><b>' + (seats ? seats + (seats > 1 ? ' members' : ' member') : 'You alone') + '</b><small>Meetings and votes</small></span><i>›</i></button></div>');
    h += lvl('md', nm(md) ? filled(nm(md), 'For the whole group · ' + mshort(md.wage || 0) + '/mo') : vac('md'));
    h += lvl('ceo56', nm(ch.ceo56) ? filled(nm(ch.ceo56), mshort(ch.ceo56.wage) + '/mo · approves up to ' + mshort(ch.ceo56.buy)) : vac('ceo56'));
    h += lvl('chainmgr', nm(cm) ? filled(nm(cm), mshort(cm.wage || 0) + '/mo · approves up to ' + mshort(cm.buy || 0)) : vac('chainmgr'));
    h += lvl('region', cityOfCh(ch).map(city => { const r = regs().find(x => x.scope === 'chain:' + ch.id + ':' + city); return nm(r) ? filled(nm(r), esc(cityOf(city).name) + ' · ' + mshort(r.wage || 0) + '/mo') : vac('region', city); }).join(''));
    const sm = L.filter(c => c.mgr && S.npcs[c.mgr]).length, as = L.filter(c => c.asst && S.npcs[c.asst.npc]).length;
    h += lvl('mgr', '<div class="lrows"><button class="lrow" data-a="go" data-p="' + P({ n: 'chain12', p: { id: ch.id, t: 'team' } }) + '"><span class="ctext"><b>' + sm + ' of ' + L.length + '</b><small>' + (sm < L.length ? (L.length - sm) + ' without a manager' : 'every store has one') + '</small></span><i>›</i></button></div>');
    h += lvl('asst', '<div class="lrows"><div class="lrow"><span class="ctext"><b>' + as + ' of ' + L.length + '</b><small>Hired from each store’s Manage tab</small></span></div></div>');
    return h;
  };
  /* ---------- hiring: each level on the step screen, through the agency (ui/screens/hiring.js MR56) ---------- */
  O.hireP = (r, ch, city) => ({ n: 'mgrhire', p: { r, id: ch && R12.storesOf(ch)[0] ? R12.storesOf(ch)[0].id : 0, ch: ch ? ch.id : '', city: city || '' } });
  const MR = window.MR56 = window.MR56 || {};
  const WHAT = { md: 'Runs the whole group under you and approves what the chains cannot. Paid by all your companies.', ceo56: 'Sets the chain’s strategy and takes it into new cities. Paid by the chain’s stores.', chainmgr: 'Keeps every store on the chain’s rules, coaches the store managers, opens new stores where they are full. Paid by the chain’s stores.', region: 'Runs the chain’s stores in one city and expands the ones that are too small. Paid by the chain’s stores.' };
  ['md', 'ceo56', 'chainmgr', 'region'].forEach(r => {
    MR[r] = {
      me: 1, t: () => LV.find(x => x[0] === r)[1], d: (co, p) => WHAT[r] + (p.city ? ' ' + cityOf(p.city).name + '.' : ''), st: ['ops', 'Running things'],
      fee: () => KC(15000),
      gen: () => { const n = genExec(r === 'md' || r === 'ceo56' ? 'ceo' : 'region'); n.ask = rnl(KC(PAY[r]) * rng(0.85, 1.15), 1000); return n; },
      hire: (co, n, w, p) => {
        const ch = R12.chainById(p.ch);
        if (!ch && r !== 'md') return 'bad';
        const rec = { npc: n.id, wage: w, lvl: 1, buy: KC(BUY[r]), w0: S.week };
        if (r === 'md') { org().md = rec; n.hired = -2; }
        else if (r === 'ceo56') { ch.ceo56 = rec; n.hired = -2; if (R12.addSeat) try { R12.addSeat('ch:' + ch.id, { id: n.id, kind: 'exec', t: 'CEO' }); } catch (e) { } }
        else {
          const g = window.R12hireChief && R12hireChief(String(ch.id) + (r === 'region' ? ':' + p.city : ''), n, w, 1);
          if (!g) return 'bad';
          g.buy = rec.buy; g.payCo = 'chain';
          const t = r === 'region' ? 'Regional manager' : 'Chain manager';
          if (R12.addSeat) try { R12.addSeat('ch:' + ch.id, { id: n.id, kind: 'exec', t }); } catch (e) { }
          n.k11 = { post: 'chain:' + ch.id + (r === 'region' ? ':' + p.city : ''), t, wage: w, bonus: 0, duties: ['quality', 'coach'], auth: 1, rep: 'month', w0: S.week };
        }
        return 'ok';
      }
    };
  });
  /* Group › Group: the top of the organisation for the whole group, and each chain's own chart */
  O.groupCard = function () {
    const md = nm(org().md) ? org().md : null, n = md && nm(md), CH = (S.chains || []).filter(ch => R12.storesOf(ch).length);
    const seats = CH.reduce((t, ch) => t + (R12.seatsOf ? R12.seatsOf('ch:' + ch.id).length : 0), 0);
    let h = '<div class="card org56g"><div class="bhead"><b>Organisation</b><small>Owner · board · managing director · CEOs</small></div><div class="lrows">';
    h += '<div class="lrow"><span class="ctext"><b>' + esc(S.player.name || 'You') + '</b><small>Owner · the final say on what nobody below can approve</small></span></div>';
    h += '<button class="lrow" data-a="go" data-p="' + P({ n: 'boards12', p: {} }) + '"><span class="ctext"><b>Board of directors</b><small>' + (seats ? seats + (seats > 1 ? ' members' : ' member') + ' on your chains’ boards' : 'You alone so far') + '</small></span><i>›</i></button>';
    h += n ? '<div class="lrow">' + (window.faceAv ? faceAv(n) : '') + '<span class="ctext"><b>' + esc(n.name) + '</b><small>Managing director · ' + mshort(md.wage || 0) + '/mo · approves up to ' + mshort(md.buy || 0) + '</small></span></div>'
      : '<button class="lrow vac56" data-a="go" data-p="' + P(O.hireP('md')) + '"><span class="ctext"><b>Managing director: vacant</b><small>Runs the whole group under you; paid by the companies · ~' + mshort(KC(PAY.md)) + '/mo</small></span><span class="pill">Hire ›</span></button>';
    h += CH.map(ch => { const c = nm(ch.ceo56); return '<button class="lrow" data-a="go" data-p="' + P({ n: 'org56', p: { id: ch.id } }) + '"><span class="ctext"><b>' + esc(ch.name) + '</b><small>' + (c ? 'CEO ' + esc(c.name) : 'No CEO yet') + ' · ' + R12.storesOf(ch).length + ' stores · the whole chart</small></span><i>›</i></button>'; }).join('');
    return h + '</div></div>';
  };
  O.row = ch => '<button class="lrow" data-a="go" data-p="' + P({ n: 'org56', p: { id: ch.id } }) + '"><span class="ctext"><b>Organisation</b><small>Who runs what, from the board to the stores</small></span><i>›</i></button>';
})();

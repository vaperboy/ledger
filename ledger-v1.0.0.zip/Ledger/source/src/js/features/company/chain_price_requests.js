/* ===== Round 56: chain stores follow the chain's price, and a store manager asks before leaving it.
   A registered chain sets one price for every store (features/company/shelf_stock_chains_boards.js applyRules: the
   chain price plus the store's own offset, co.off.price). A store manager may only ask to leave it, and only for a
   reason the numbers show over the last four weeks:
   - far more customers than the store can serve, and it is full: one step higher, to slow them down
   - the store is half empty: one step lower, to win customers
   - things are back to normal: back to the chain price
   The request goes to the role above the manager: the managing director, the chain chief or regional manager, the
   group CEO (engine/management/managers.js chainOf). Someone with authority decides it there and then (a better boss
   decides better); otherwise you get the question. Unanswered, the store keeps the chain price. A store asks at most
   every eight weeks, and never more than two steps away from the chain. ===== */
window.CPX56 = window.CPX56 || {};
(function () {
  const X = window.CPX56;
  const MAXOFF = 2, GAP = 8;
  const chainOfStore = co => (window.R12 && R12.chainOf ? R12.chainOf(co) : null);
  /* what the last four weeks say: +1 too busy, -1 too quiet, 0 back to normal, null: nothing to ask */
  function want(co) {
    const H = (co.wh22 || []).slice(-4);
    if (H.length < 4 || H.some(x => x.d == null)) return null;
    const d = H.reduce((a, x) => a + x.d, 0) / H.length, u = H.reduce((a, x) => a + x.u, 0) / H.length;
    const off = (co.off && co.off.price) || 0;
    if (d > 1.25 && u >= 0.95 && off < MAXOFF) return { v: off + 1, why: 'far more customers than we can serve (about ' + Math.round(d * 100) + '% of what we can do), and the store is full', dir: 'up' };
    if (d < 0.6 && u < 0.55 && off > -MAXOFF) return { v: off - 1, why: 'the store is only about ' + Math.round(u * 100) + '% busy', dir: 'down' };
    if (off !== 0 && d >= 0.8 && d <= 1.1) return { v: 0, why: 'customers and capacity are back in balance', dir: 'back' };
    return null;
  }
  X.want = want;
  const stepWord = v => v === 0 ? 'the chain price' : Math.abs(v) + (Math.abs(v) > 1 ? ' steps ' : ' step ') + (v > 0 ? 'above' : 'below') + ' the chain price';
  function setOff(co, v) {
    co.off = co.off || { price: 0, mkt: 0, pay: 0, stock: null };
    co.off.price = v;
    const ch = chainOfStore(co);
    if (ch && window.R12 && R12.applyAll) R12.applyAll(ch);
  }
  addStep('week.after', 62, 'chain store managers ask to leave the chain price', () => {
    S.cos.forEach(co => {
      if (co.st !== 'open' || !co.mgr || !S.npcs[co.mgr]) return;
      const ch = chainOfStore(co);
      if (!ch) return;
      co.cpx56 = co.cpx56 || { w: -99 };
      if (S.week - co.cpx56.w < GAP) return;
      if (S.inbox.some(m => m.act === 'cpx56' && m.co === co.id && m.status === 'open')) return;
      const r = want(co);
      if (!r) return;
      co.cpx56.w = S.week;
      const m = S.npcs[co.mgr], L = typeof chainOf === 'function' ? chainOf(co) : [];
      const boss = L.slice(1).find(c => c.lvl >= 1);
      const ask = 'Price at ' + co.name + ': ' + stepWord(r.v) + '?';
      if (boss) {
        /* the boss decides: a good one says yes when the numbers are clear, and to going back to the chain price always */
        const q = boss.npc.stats ? ((boss.npc.stats.ops || 60) + (boss.npc.stats.fin || 60)) / 200 : 0.6;
        const yes = r.dir === 'back' || chance(0.55 + 0.4 * q);
        if (yes) setOff(co, r.v);
        note(boss.npc.name + ' (' + titleFor(co, boss.kind) + ') ' + (yes ? 'agreed' : 'said no') + ': ' + m.name + ' asked to move ' + co.name + ' to ' + stepWord(r.v) + ', because ' + r.why + '.', yes ? 'n' : 'bad', co.id);
        return;
      }
      if (r.dir === 'back') { setOff(co, 0); note(m.name + ' moved ' + co.name + ' back to the chain price: ' + r.why + '.', 'n', co.id); return; }
      addMsg({
        kind: 'ask', from: m.name, role: titleFor(co, 'mgr'), title: ask,
        body: 'We follow ' + ch.name + '’s price. Over the last four weeks ' + r.why + '. I would like to go ' + (r.dir === 'up' ? 'one step higher, so fewer people queue and each sale earns more' : 'one step lower, to win back customers') + '. Every store in the chain keeps its own price only with your permission.',
        co: co.id, act: 'cpx56', data: { co: co.id, v: r.v }, exp: S.week + 3, tone: 'n',
        opts: [{ l: 'Allow it', d: stepWord(r.v), fx: {} }, { l: 'Keep the chain price', d: 'The store stays with the others.', fx: {} }]
      });
    });
  });
  ACTS.cpx56 = (m, idx) => {
    const co = getCo(m.data && m.data.co);
    if (co && idx === 0) setOff(co, m.data.v);
    return true;
  };
})();

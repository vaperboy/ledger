/* ===== Round 56: renaming a company and rebranding a chain.
   - Rename (Company › Name and brand): a new name on the register, the signs and the website. A small fee to the
     register and new signs; part of the people who knew the old name do not find the new one (awareness falls).
   - Rebrand a chain (the chain's page): a new name, logo and look for every store. Stores are renamed after the chain
     and their city. It costs signs, packaging and uniforms in every store; awareness falls at first, a launch gives a
     short buzz, and a reputation is partly reset toward neutral, which is why a chain with a bad name rebrands.
   Costs scale with the store's size and the country's price level. ===== */
window.RN56 = window.RN56 || {};
(function () {
  const RN = window.RN56;
  const U = window.UI;
  if (!U) return;
  const { ui, ACT, esc, btn, row, render, save, toast, openSheet, closeSheet } = U;
  const P = o => esc(JSON.stringify(o));
  const sz = co => Math.pow(Math.max(0.5, co.size || 1), 0.7);
  const renameCost = co => rnl(KC(2500, co.country) + KC(15000, co.country) * sz(co), 500);
  const rebrandCost = co => rnl(KC(40000, co.country) * sz(co), 1000);
  const chainOf = co => (window.R12 && R12.chainOf ? R12.chainOf(co) : null);
  const storesOf = ch => (window.R12 && R12.storesOf ? R12.storesOf(ch) : []);
  const taken = (n, self) => S.cos.some(c => c !== self && c.st !== 'sold' && c.st !== 'bust' && c.name.toLowerCase() === n.toLowerCase());
  RN.row = function (co) {
    const ch = chainOf(co);
    return '<button class="lrow" data-a="rn56" data-p="' + P({ id: co.id }) + '"><span class="lic">' + U.svg('star', 20) + '</span><span class="ctext"><b>Name and brand</b><small>' + esc(co.name) + (ch ? ' · part of ' + esc(ch.name) : ' · rename it') + '</small></span><i>›</i></button>';
  };
  /* rename one company */
  ACT.rn56 = p => {
    const co = getCo(p.id);
    if (!co) return;
    const ch = chainOf(co), cost = renameCost(co);
    ui.inp.rn56 = ui.inp.rn56 != null && ui.rn56id === co.id ? ui.inp.rn56 : co.name;
    ui.rn56id = co.id;
    let h = '<h2>Name and brand</h2><p class="muted small">' + esc(co.name) + ' · ' + esc(BD[co.type].n) + '</p>';
    if (ch) h += '<div class="note">' + esc(co.name) + ' carries the name of the chain ' + esc(ch.name) + '. To change the name of every store, rebrand the chain from its page.</div>' + btn('Open ' + esc(ch.name), 'go', { n: 'chain12', p: { id: ch.id } }, 'wide');
    else {
      h += '<span class="lab">New name</span>' + U.inp('rn56', 'New name', co.name, 'text');
      h += row('Register and new signs', money(cost)) + row('Awareness', 'About a third of those who knew the old name lose track of you');
      h += btn('Rename it', 'rn56go', { id: co.id }, 'primary wide' + (co.cash < cost ? ' cant' : ''));
    }
    openSheet(h + btn('Close', 'sheetclose', undefined, 'ghost wide'));
  };
  ACT.rn56go = p => {
    const co = getCo(p.id);
    if (!co) return;
    const n = String(ui.inp.rn56 || '').trim(), cost = renameCost(co);
    if (n.length < 2 || n === co.name) { toast('Type a new name.', true); return; }
    if (taken(n, co)) { toast('You already have a company with that name.', true); return; }
    if (co.cash < cost) { toast('Not enough cash in ' + co.name + '.', true); return; }
    payCo(co, cost, 'oth', 'New name and signs');
    const old = co.name;
    co.name = n;
    co.aware = Math.round(co.aware * 0.68 * 10) / 10;
    co.nameLog = (co.nameLog || []).concat([{ w: S.week, from: old }]);
    note(old + ' is now called ' + n + '.', 'n', co.id);
    save(); closeSheet(); render(); toast('Renamed to ' + n + '.');
  };
  /* rebrand a chain: a row on the chain's page */
  RN.chainRow = ch => '<button class="lrow" data-a="rb56" data-p="' + P({ id: ch.id }) + '"><span class="ctext"><b>Rename or rebrand</b><small>A new name and look for every store</small></span><i>›</i></button>';
  ACT.rb56 = p => {
    const ch = window.R12 && R12.chainById ? R12.chainById(p.id) : null;
    if (!ch) return;
    const L = storesOf(ch), cost = sum(L, rebrandCost), rep = L.length ? sum(L, c => c.rep) / L.length : 50;
    ui.inp.rb56 = ui.inp.rb56 != null && ui.rb56id === ch.id ? ui.inp.rb56 : ch.name;
    ui.rb56id = ch.id;
    let h = '<h2>Rebrand ' + esc(ch.name) + '</h2><p class="muted small">' + L.length + ' ' + (window.siteW ? siteW(ch.type, L.length) : (L.length === 1 ? 'store' : 'stores')) + ' · ' + esc(BD[ch.type].n) + '</p>';
    h += '<span class="lab">New chain name</span>' + U.inp('rb56', 'Chain name', ch.name, 'text');
    h += row('Signs, packaging and uniforms', money(cost)) + row('Stores take the name', esc((ui.inp.rb56 || ch.name) + ' ' + cityOf(L[0] ? L[0].city : CC().cities[0].id).name) + (L.length > 1 ? ' and so on' : ''));
    h += row('Awareness', 'Falls by about a quarter at first; the launch gives a few weeks of buzz');
    h += row('Reputation', rep < 45 ? '<span class="pos">A fresh start: a poor name is partly forgotten</span>' : rep > 65 ? '<span class="neg">Part of a good name is lost</span>' : 'Little change');
    h += btn('Rebrand every store · ' + mshort(cost), 'rb56go', { id: ch.id }, 'primary wide' + (S.cash + sum(L, c => Math.max(0, c.cash)) < cost ? ' cant' : ''));
    h += '<span class="tipt">Each store pays its own part. Renaming only the chain without new signs is not possible: customers would not find you.</span>';
    openSheet(h + btn('Close', 'sheetclose', undefined, 'ghost wide'));
  };
  ACT.rb56go = p => {
    const ch = window.R12 && R12.chainById ? R12.chainById(p.id) : null;
    if (!ch) return;
    const n = String(ui.inp.rb56 || '').trim();
    if (n.length < 2 || n === ch.name) { toast('Type a new name.', true); return; }
    if ((S.chains || []).some(x => x !== ch && x.name.toLowerCase() === n.toLowerCase())) { toast('You already have a chain with that name.', true); return; }
    const L = storesOf(ch);
    if (L.some(c => c.cash < rebrandCost(c))) { toast('Every store needs the cash for its own signs. Put money into the ones short of it first.', true); return; }
    const old = ch.name;
    ch.name = n;
    ch.nameLog = (ch.nameLog || []).concat([{ w: S.week, from: old }]);
    L.forEach(c => {
      payCo(c, rebrandCost(c), 'oth', 'Rebranding to ' + n);
      const cn = cityOf(c.city).name;
      let nm = n + ' ' + cn, i = 2;
      while (taken(nm, c)) nm = n + ' ' + cn + ' ' + (i++);
      c.name = L.length === 1 ? n : nm;
      c.aware = Math.round(c.aware * 0.75 * 10) / 10;
      c.hype = Math.min(100, (c.hype || 0) + 12);
      c.rep = Math.round((c.rep + (55 - c.rep) * 0.35) * 10) / 10;
    });
    note(old + ' is now ' + n + '. All ' + L.length + ' stores carry the new name.', 'good');
    save(); closeSheet(); render(); toast(old + ' is now ' + n + '.');
  };
})();

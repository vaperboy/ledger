/* ===== Round 56: talking to franchise applicants. Each applicant is a person with experience, money of their own and a
   way of bargaining (eager, careful, tough). You open a conversation like the salary talks and agree terms one by one:
   the entry fee (full, half, waived), the royalty, your help with the setup (none, a loan of a quarter or half of it,
   or covering half or all of it for a share of the profit) and the length of the contract.
   They say yes when they can pay their part (with a little to spare) and the unit pays them back in reasonable time;
   otherwise they say what would work for them. Patience runs out after a few offers.
   The agreed terms go on the unit (engine/world/deals.js frAcceptCore, features/world/franchise_lifecycle.js frWeek):
   its own royalty, profit share, loan (paid back from its profit, with interest; written off if it fails) and term. ===== */
(function () {
  const bub = x => '<div class="bub ' + (x.sys ? 'sys' : x.me ? 'me' : 'them') + '">' + esc(x.t) + '</div>';
  const seg = (items, cur, act, p0) => '<div class="seg7">' + items.map(x => '<button class="' + (x[0] === cur ? 'on' : '') + '" data-a="' + act + '" data-p="' + P(Object.assign({}, p0, { v: x[0] })) + '">' + x[1] + '</button>').join('') + '</div>';
  const HELP = [['none', 'None', 0, 0], ['l25', 'Lend 25%', 0, 0.25], ['l50', 'Lend 50%', 0, 0.5], ['c50', 'Cover half', 0.5, 0]]; /* covering all of it would make the unit yours: that is a chain store, not a franchise */
  const PAT = { eager: 4, careful: 3, tough: 2 };
  /* how many years a franchisee accepts to earn back what they put in. Buyers aim for 3-5 years; 5-7 is accepted for
     fast food and other costly setups, 5-10 for full-service restaurants and hotels, 1-3 for home services
     (sharpsheets.io franchise payback benchmarks). The trade sets the base, the person moves it. */
  const PB_FAM = { svc: 3, retail: 4.5, venue: 5, prod: 6, logi: 4.5, project: 4 };
  const PB_PERS = { eager: 1.35, careful: 1, tough: 0.85 };
  function payback(co, a, setup) {
    const bd = BD[co.type];
    let base = PB_FAM[bd.fam] || 4.5;
    if (bd.fam === 'venue' && setup > KC(6e6, co.country)) base = 7; /* a full-service restaurant or a hotel */
    return Math.round(base * (PB_PERS[a.pers] || 1) * 10) / 10;
  }
  const PERS = { eager: 'Keen to get going', careful: 'Careful with money', tough: 'A hard bargainer' };
  const appOf = (co, id) => co && co.fr && co.fr.app.find(x => x.id === id);
  function fill(a) { /* applicants from older saves */
    if (a.exp == null) a.exp = Math.max(0, Math.round((a.skill - 30) / 3.5));
    if (!a.pers) a.pers = ['eager', 'careful', 'tough'][a.id % 3];
    if (!a.age) a.age = 30 + (a.id % 25);
  }
  function std(co) {
    const f = co.fr;
    return { feeF: 1, roy: f.roy, help: ['none', 'c50', 'c50'][f.supp || 0], share: f.share || 0.45, term: f.term || 10 };
  }
  const T = (co, a) => { ui.frt = ui.frt || {}; const k = co.id + ':' + a.id; return (ui.frt[k] = ui.frt[k] || { t: std(co), log: [], pat: PAT[a.pers] || 3, a }); };
  function termsOf(co, t) {
    const h = HELP.find(x => x[0] === t.help) || HELP[0];
    return { feeF: t.feeF, roy: t.roy, grant: h[2], loan: h[3], share: h[2] > 0 ? t.share : 0, term: t.term, rate: Math.round((policy() + 0.03) * 1000) / 1000 };
  }
  /* what the unit would earn in a normal year, and who gets what */
  function sums(co, a, t) {
    const f = co.fr, bd = BD[co.type], city = cityOf(a.city), x = termsOf(co, t);
    const setup = unitSetupCost(co);
    const rev = bd.Dc * bd.ticket * city.dem * (0.35 + f.brand / 100 * 0.6) * (0.6 + a.skill / 160) * seasOf(bd) * 0.85 * 52;
    const m = (window.R24 && R24.conceptMargin ? R24.conceptMargin(co, bd) : bd.m) + (f.brand / 100 - 0.35) * 0.06 + (a.skill - 55) * 0.0012 + (x.grant > 0 ? 0.01 : 0) - 0.01;
    const prof = rev * (m - x.roy - f.mkt);
    const loan = setup * x.loan, loanY = loan ? annuity(loan, x.rate, 60) * 12 : 0;
    const theirs = prof * (1 - x.share) - loanY;
    const own = setup * (1 - x.grant - x.loan) + f.fee * x.feeF;
    const need = own + setup * 0.1;
    const yours = rev * x.roy + prof * x.share + loanY;
    return { setup, rev, prof, theirs, own, need, youIn: setup * (x.grant + x.loan), yours, x };
  }
  /* their answer to an offer */
  function answer(co, a, t) {
    const s = sums(co, a, t), f = co.fr;
    if (a.capital < s.need) {
      /* what more help would close the gap: a loan of a quarter or half, or covering half or all of it */
      const more = (s.need - a.capital) / s.setup + s.x.loan + s.x.grant;
      const hint = more <= 0.25 ? 'l25' : more <= 0.5 ? 'l50' : 'none';
      const say = { l25: 'If you lent me a quarter of the setup, I could do it.', l50: 'If you lent me half of the setup, or covered half of it, I could do it.', none: 'Even with help I do not have enough of my own to open a unit. Perhaps when I have saved more.' }[hint];
      return { ok: false, t: 'I have ' + mshort(a.capital) + ' of my own. On these terms I would need about ' + mshort(s.need) + ', with something left for the first months. ' + (hint === 'none' ? say : t.help === hint ? 'Could you waive the fee as well?' : say), hint: t.help === hint || hint === 'none' ? null : hint };
    }
    if (s.theirs <= 0) return { ok: false, t: 'I ran the numbers. With these costs I would lose money every year. The royalty and the share would have to come down.' };
    const years = s.own / s.theirs, lim = payback(co, a, s.setup);
    if (a.pers === 'tough' && t.roy > f.roy && t.feeF > 0) return { ok: false, t: 'A higher royalty than your other franchisees pay? Not with me. Standard terms, or less.' };
    if (years > lim) {
      const ask = t.roy > 0.04 ? 'a royalty one point lower' : t.feeF > 0 ? 'half the entry fee' : 'more help with the setup';
      return { ok: false, t: 'It would take me ' + years.toFixed(1) + ' years to earn back what I put in. I need it closer to ' + lim + '. With ' + ask + ' I am in.' };
    }
    return { ok: true, t: a.pers === 'eager' ? 'Yes! When can we start?' : a.pers === 'careful' ? 'That works for me. I would like it in writing, and then we can begin.' : 'Fine. That is a deal.' };
  }

  V.titles.frtalk56 = 'Franchise applicant';
  V.frtalk56 = function (p) {
    const co = getCo(p.id), st0 = ui.frt && co && ui.frt[co.id + ':' + p.a], a = appOf(co, p.a) || (st0 && st0.a);
    if (!co || !a) return '<div class="calm">This applicant has moved on.</div>';
    fill(a);
    const bd = BD[co.type], st = T(co, a), t = st.t, s = sums(co, a, t);
    const n = { id: 'fa' + a.id, name: a.name, age: a.age };
    const tr = bd.n.toLowerCase().replace(/ \(.*\)$/, ''); const open = { t: 'Hello. ' + (a.exp > 0 ? 'I have ' + a.exp + (a.exp === 1 ? ' year' : ' years') + ' in ' + tr : 'I am new to ' + tr + ', but I learn fast') + ' and would like to open a ' + co.name + ' in ' + cityOf(a.city).name + '. I have ' + mshort(a.capital) + ' of my own; the setup is about ' + mshort(s.setup) + '.' };
    let h = '<div class="ichat phone7"><div class="ph7top"><button class="bk" data-a="back" aria-label="Back">‹</button>' + faceAv(n) + '<div class="vht"><h1>' + esc(a.name) + '</h1><p>' + esc(cityOf(a.city).name) + ' · ' + a.exp + ' yr experience · ' + esc(skillBand(a.skill)) + ' · ' + esc(PERS[a.pers]) + '</p></div></div>';
    h += '<div class="clog"><div class="cfill"></div>' + [open].concat(st.log).map(bub).join('') + '</div><div class="composer">';
    if (st.done) return h + btn('Back to the franchise', 'back', undefined, 'primary wide') + '</div></div>';
    /* round 56: the conversation keeps the screen. The offer is one line with its numbers; the controls open only
       while you change the terms, so a long talk stays readable */
    const help = HELP.find(x => x[0] === t.help) || HELP[0];
    const sumT = 'Fee ' + (t.feeF === 1 ? 'in full' : t.feeF ? 'half' : 'waived') + ' · ' + Math.round(t.roy * 100) + '% royalty · ' + (help[0] === 'none' ? 'no help' : help[1].toLowerCase()) + (s.x.grant > 0 ? ' for ' + Math.round(t.share * 100) + '% of profit' : '') + ' · ' + t.term + ' years';
    const ed = ui.frtEd === co.id + ':' + a.id;
    if (ed) {
      h += '<span class="lab">Entry fee · ' + mshort(co.fr.fee * t.feeF) + '</span>' + seg([[1, 'Full'], [0.5, 'Half'], [0, 'Waived']], t.feeF, 'frt56', { id: co.id, a: a.id, k: 'feeF' });
      h += '<span class="lab">Royalty of sales</span>' + seg([0.04, 0.05, 0.06, 0.07, 0.08, 0.1].map(v => [v, Math.round(v * 100) + '%']), t.roy, 'frt56', { id: co.id, a: a.id, k: 'roy' });
      h += '<span class="lab">Your help with the setup</span>' + seg(HELP.map(x => [x[0], x[1]]), t.help, 'frt56', { id: co.id, a: a.id, k: 'help' });
      if (s.x.grant > 0) h += '<span class="lab">Your share of their profit</span>' + seg([[0.25, '25%'], [0.45, '45%'], [0.6, '60%']], t.share, 'frt56', { id: co.id, a: a.id, k: 'share' });
      h += '<span class="lab">Contract</span>' + seg([[5, '5 years'], [10, '10 years']], t.term, 'frt56', { id: co.id, a: a.id, k: 'term' });
    } else h += '<button class="frsum56" data-a="frt56ed" data-p="' + P({ id: co.id, a: a.id }) + '"><span>Your offer</span><b>' + esc(sumT) + '</b><i>Change ›</i></button>';
    h += '<div class="frnum56"><span>They need <b class="' + (a.capital < s.need ? 'neg' : '') + '">' + mshort(Math.max(0, s.need)) + '</b> · have ' + mshort(a.capital) + '</span><span>Their profit <b class="' + (s.theirs < 0 ? 'neg' : '') + '">' + mshort(s.theirs) + '</b>/yr</span><span>Yours <b>' + mshort(s.yours) + '</b>/yr' + (s.youIn ? ' · you put in ' + mshort(s.youIn) : '') + '</span></div>';
    h += '<div class="crow"><div class="crowtxt"><small>Patience ' + '●'.repeat(Math.max(0, st.pat)) + '○'.repeat(Math.max(0, (PAT[a.pers] || 3) - st.pat)) + (s.x.loan ? ' · loan at ' + pc(s.x.rate, 1) + ' over five years' : '') + '</small></div>' + (ed ? btn('Done', 'frt56ed', { id: co.id, a: a.id }, '') : '') + btn('Send offer', 'frt56go', { id: co.id, a: a.id }, 'primary') + '</div>';
    return h + '</div></div>';
  };
  ACT.frt56 = p => {
    const co = getCo(p.id), a = appOf(co, p.a); if (!a) return;
    const st = T(co, a);
    st.t[p.k] = p.k === 'help' ? p.v : +p.v;
    render();
  };
  ACT.frt56ed = p => { const k = p.id + ':' + p.a; ui.frtEd = ui.frtEd === k ? null : k; render(); };
  ACT.frt56go = p => {
    const co = getCo(p.id), a = appOf(co, p.a); if (!a) return;
    ui.frtEd = null;
    const st = T(co, a), t = st.t, x = termsOf(co, t);
    const help = HELP.find(h => h[0] === t.help) || HELP[0];
    st.log.push({ me: 1, t: 'Fee ' + (t.feeF === 1 ? 'in full' : t.feeF ? 'half' : 'waived') + ', ' + Math.round(t.roy * 100) + '% royalty, ' + (help[0] === 'none' ? 'no help with the setup' : help[1].toLowerCase() + ' of the setup' + (x.share ? ' for ' + Math.round(x.share * 100) + '% of the profit' : '')) + ', ' + t.term + ' years.' });
    const r = answer(co, a, t);
    st.log.push({ t: r.t });
    if (r.ok) {
      if (co.cash < sums(co, a, t).youIn) { st.log.push({ sys: 1, t: co.name + ' does not have the cash for its part (' + money(sums(co, a, t).youIn) + ').' }); render(); return; }
      a.terms = x;
      const res = frAccept(co, a.id);
      if (res === 'ok') { st.done = 1; st.log.push({ sys: 1, t: 'Contract signed. ' + a.name + ' opens in ' + cityOf(a.city).name + '.' }); save(); }
      else { delete a.terms; st.log.push({ sys: 1, t: res === 'cash' ? 'Not enough cash in ' + co.name + '.' : 'It could not be signed.' }); }
    } else {
      st.pat--;
      if (r.hint) st.t.help = r.hint;
      if (st.pat <= 0) { st.log.push({ sys: 1, t: a.name + ' has found another opportunity.' }); st.done = 1; co.fr.app = co.fr.app.filter(y => y !== a); save(); }
    }
    render();
  };
})();

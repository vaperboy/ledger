/* ===== Round 56: a chain runs itself. When someone sits above a store manager (the managing director, a chain
   chief or regional manager, the group CEO: engine/management/managers.js chainOf), the store manager's requests go
   to them first, not to you:
   - they judge the request on the numbers: more staff or equipment when customers are turned away and the money is
     there, a cut when the team is idle, an ad push when nobody knows the store. Clear yes: done. Clear no: refused,
     with the reason in your notes
   - money for a store that is short: moved from a sister store in the same chain that can spare it, as a group loan
     the store pays back when it can
   - only what is above their budget, or a close call, comes to you, with their recommendation
   Everyone aims at profit and growth; you hear about it in the notes. ===== */
window.CHN56 = window.CHN56 || {};
(function () {
  const C = window.CHN56;
  const sisters = co => { const ch = window.R12 && R12.chainOf ? R12.chainOf(co) : null; return ch ? R12.storesOf(ch).filter(c => c !== co && c.st === 'open') : []; };
  const spare = c => Math.max(0, c.cash - coWeekCost(c) * 8 - KC(20000, c.country));
  /* move money from the sister store that can spare it most; a group loan the store pays back later */
  C.sisterCash = function (co, need) {
    const L = sisters(co).sort((a, b) => spare(b) - spare(a)), s = L[0];
    if (!s || spare(s) < need) return false;
    const amt = rnl(need, 1000);
    moveCash(s, -amt); moveCash(co, amt);
    s.tx.unshift({ w: S.week, a: -amt, l: 'Group loan to ' + co.name });
    co.tx.unshift({ w: S.week, a: amt, l: 'Group loan from ' + s.name });
    co.gl56 = (co.gl56 || []).concat([{ from: s.id, amt, w: S.week }]);
    return s;
  };
  /* group loans are paid back once the store has a cushion of its own */
  addStep('week.after', 63, 'group loans inside a chain are paid back', () => {
    S.cos.forEach(co => {
      if (!co.gl56 || !co.gl56.length || co.st !== 'open') return;
      const l = co.gl56[0], s = getCo(l.from);
      if (!s || s.st === 'sold' || s.st === 'bust') { co.gl56.shift(); return; }
      const room = co.cash - coWeekCost(co) * 10;
      if (room <= 0) return;
      const x = Math.min(l.amt, Math.floor(room * 0.5));
      if (x < 1000) return;
      moveCash(co, -x); moveCash(s, x);
      co.tx.unshift({ w: S.week, a: -x, l: 'Group loan repaid to ' + s.name });
      s.tx.unshift({ w: S.week, a: x, l: 'Group loan repaid by ' + co.name });
      l.amt -= x;
      if (l.amt < 1000) co.gl56.shift();
    });
  });
  /* a store without a manager gets one from the boss: the best person on the team if someone is ready, otherwise
     someone from outside at the going rate. by: who appoints (a name), why: what happened */
  C.fillManager = function (co, by, why) {
    if (!co || co.mgr || co.st !== 'open') return null;
    const bd = BD[co.type];
    let n = null;
    try { n = genManager(co, bd.mgr); } catch (e) { n = null; }
    if (!n) return null;
    const r = hireManager(co, n, Math.round((n.ask || 0) * 1.05));
    if (r !== 'ok') return null;
    note((by ? by + ' appointed ' : '') + n.name + (by ? '' : ' was appointed') + ' as manager of ' + co.name + (why ? ' after ' + why : '') + '.', 'n', co.id);
    return n;
  };
  /* trouble at a store: the boss above it deals with it and tells you in the notes. code(x) runs one of the
     emergency answers (features/company/shelf_stock_chains_boards.js doEmg); pick is the sensible choice there */
  C.handle = function (co, kind, why, code, pick) {
    const L = typeof chainOf === 'function' ? chainOf(co).filter(x => x.kind !== 'mgr') : [];
    const boss = L.find(x => x.lvl >= 1) || L[0];
    if (!boss) return false;
    const who = boss.npc.name + ' (' + titleFor(co, boss.kind) + ')';
    if (kind === 'mgr') return !!C.fillManager(co, who, 'the last manager left');
    if (kind === 'cash') {
      const s = C.sisterCash(co, Math.max(KC(30000, co.country), coWeekCost(co) * 6));
      if (s) note(who + ' moved money from ' + s.name + ' to ' + co.name + ': its cash was running out.', 'n', co.id);
      else { code('mkt0'); note(who + ' stopped marketing at ' + co.name + ' to save cash.', 'n', co.id); }
      return true;
    }
    if (kind === 'loss') return false; /* selling a store is yours to decide */
    const opts = { drop: ['price-', 'mkt+'], stock: ['stock', 'asst'], rating: ['course', 'raise'] }[kind];
    if (!opts) return false;
    const c = opts[Math.min(opts.length - 1, Math.max(0, pick || 0))];
    code(c);
    const what = { 'price-': 'cut prices one step', 'mkt+': 'raised marketing by half', stock: 'ordered more stock from now on', asst: 'gave the ordering to the assistant', course: 'sent the staff on a course', raise: 'raised pay 5%' }[c] || c;
    note(who + ' ' + what + ' at ' + co.name + ': ' + String(why || '').replace(/\.$/, '').toLowerCase() + '.', 'n', co.id);
    return true;
  };
  /* what the boss thinks of a request: 1 yes, -1 no, 0 close call */
  function merit(co, dp) {
    const w = co.lastW || {}, d = co.dbg || {}, over = d.cap > 0 ? (d.D || 0) / d.cap : 0, u = w.util || 0;
    const prof = (co.hist || []).slice(-3).reduce((a, x) => a + (x.profit || 0), 0) / 3;
    if (dp.t === 'hire' || dp.t === 'eq' || dp.t === 'veh' || dp.t === 'space') {
      if (over >= 1.2 && u >= 0.9) return 1;
      if (over < 0.95 || u < 0.75) return -1;
      return 0;
    }
    if (dp.t === 'cut') return u < 0.5 && prof < 0 ? 1 : u > 0.7 ? -1 : 0;
    if (dp.t === 'ad') return co.aware < 20 && co.cash > coWeekCost(co) * 8 ? 1 : co.cash < coWeekCost(co) * 4 ? -1 : 0;
    return 0;
  }
  C.merit = merit;
  const WHY = { hire: 'customers are being turned away and people are the limit', eq: 'the equipment is full and customers wait', veh: 'every vehicle is busy', space: 'the place is too small for the customers it gets', cut: 'the team has too little to do', ad: 'too few people know the store' };
  const NO = { hire: 'there is not enough work for one more', eq: 'what we have is not full yet', veh: 'the vehicles are not all busy', space: 'there is room in the place we have', cut: 'the team is busy enough', ad: 'the money is better kept for now' };
  /* returns true when the boss dealt with it; false: it goes to you as before (with the boss's view in the message) */
  C.decide = function (co, dp, n, title, doIt, afford) {
    const L = typeof chainOf === 'function' ? chainOf(co).slice(1) : [];
    if (!L.length) return false;
    const boss = L[0], who = boss.npc.name + ' (' + titleFor(co, boss.kind) + ')';
    const cost = dp.t === 'hire' ? (dp.cost || 0) / 12 : dp.cost || 0;
    const inBudget = boss.lvl >= 2 || (boss.lvl >= 1 && cost <= (boss.buy || 0));
    /* money first: a store that is short gets it from a sister store */
    if (dp.t === 'cash' || (dp.t === 'hire' && !afford)) {
      const need = dp.t === 'cash' ? Math.max(KC(50000, co.country), coWeekCost(co) * 6 - co.cash) : Math.max(0, hireShort(co, dp.cost || 0));
      const s = need > 0 ? C.sisterCash(co, need) : null;
      if (s) {
        note(who + ' moved ' + money(need) + ' from ' + s.name + ' to ' + co.name + ' as a group loan' + (dp.t === 'hire' ? ', so the hire can go ahead.' : '.'), 'n', co.id);
        if (dp.t === 'cash') return true;
        afford = true;
      } else if (dp.t === 'cash') return false;
    }
    const m = merit(co, dp);
    if (m < 0) { note(who + ' said no to ' + n.name + ': ' + title.toLowerCase() + '. ' + capF(NO[dp.t] || 'not now') + '.', 'n', co.id); return true; }
    /* within their budget they decide close calls too, leaning to growth when the store can pay for it */
    if (inBudget && afford && m >= 0) { doIt(); note(who + ' approved: ' + title + '. ' + capF(m > 0 ? WHY[dp.t] || '' : 'a close call, but the store can afford it and it should grow') + '.', 'n', co.id); return true; }
    if (inBudget && !afford) { note(who + ' put off ' + title.toLowerCase() + ' until ' + co.name + ' has the cash.', 'n', co.id); return true; }
    if (m <= 0) { note(who + ' said no to ' + title.toLowerCase() + ': above their budget and not clearly worth it.', 'n', co.id); return true; }
    /* a close call, or above their budget: you decide, with their view */
    dp.view56 = boss.npc.name + ' ' + (m > 0 ? 'recommends it: ' + (WHY[dp.t] || '') + (inBudget ? '' : ', but it is above the budget you gave them') : 'is not sure: the numbers could go either way') + '.';
    return false;
  };
  const capF = s => String(s || '').replace(/^./, x => x.toUpperCase());
})();

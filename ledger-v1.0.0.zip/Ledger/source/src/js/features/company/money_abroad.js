/* ===== Round 21: money that adds up for small businesses abroad.
   - fit-out was charged in Norwegian prices in every country and never shown, so cheap rents still failed with "not enough cash"
   - converting to a limited company asked for a new accountant even when you had one, and only took personal cash
   - the home screen "Companies" figure is the companies' value, not their cash ===== */
{
  const fitOf = (co, kind, m2) => KC((FIT[kind] || 0) * m2, co.country) || 0;
  window.R21 = { fitOf };
  /* what renting a listing costs up front: 3 months deposit + fit-out */
  function startCost(co, l) {
    const bd = BD[co.type], kind = bd.prem[0], P = PREM[kind], city = cityOf(co.city);
    const rent = rl(P[1] * l.rentF * city.rent * Math.pow(1 + S.econ.infl, S.week / 52) * l.m2 / 12);
    const bl = co.franchise && co.franchise.bld;
    return { rent, dep: bl ? 0 : rent * 3, fit: fitOf(co, kind, l.m2) };
  }
  /* show the up-front cost on each listing */
  ACT.premsheet = pipeView('ACT.premsheet', ACT.premsheet, 1);
  addStep('ACT.premsheet.around', 10, 'show the up-front cost on each listing', (p, next) => {
    next();
    try {
      const co = getCo(p.id), L = premListings(co);
      let i = 0;
      ui.sheet.html = ui.sheet.html.replace(/(<small>Rent [^<]*? a month · buy [^<·]*)/g, m => { const l = L[i++]; if (!l) return m; const c = startCost(co, l); return m + ' · to move in ' + mshort(c.dep + c.fit); });
      ui.sheet.html = ui.sheet.html.replace('Renting needs a 3 month deposit plus fit-out.', 'Renting needs a 3 month deposit plus fit-out. Company cash: ' + money(co.cash) + '.');
      render();
    } catch (e) { console.error(e); }
  });
  /* not enough in the company: say how much is missing and offer to put in your own money */
  ACT.premset = pipeView('ACT.premset', ACT.premset, 1);
  addStep('ACT.premset.around', 10, 'not enough in the company: say how much is missing and offer to put in your own money', (p, next) => {
    const co = getCo(p.id), l = premListings(co)[p.i];
    if (!co || !l || p.buy) return next();
    const c = startCost(co, l), need = c.dep + c.fit, short = Math.ceil(need - co.cash);
    if (short <= 0) return next();
    if (liquid() >= short) {
      confirmThen('Put in ' + money(short) + '?', 'Moving in costs ' + money(need) + ' (deposit ' + money(c.dep) + ' + fit-out ' + money(c.fit) + '). The company has ' + money(co.cash) + '. The rest comes from your own money.', 'Put in and rent', () => { injectCash(co, short); next(); });
      return;
    }
    toast('Moving in costs ' + money(need) + ' (deposit ' + money(c.dep) + ' + fit-out ' + money(c.fit) + '). The company has ' + money(co.cash) + ' and you have ' + money(Math.max(0, liquid())) + '.', true);
  });
  /* keep the accountant you already have */
  /* share capital may come from the business's own cash when your personal cash is short */
  ACT.tcAS = pipeView('ACT.tcAS', ACT.tcAS, 1);
  addStep('ACT.tcAS.around', 10, 'share capital may come from the business’s own cash when your personal cash is short', (p, next) => {
    next();
    try {
      const co = getCo(p.id), c = CC(), need = c.asCapital + c.asConvFee;
      let h = ui.sheet.html;
      if (S.cash < need && S.cash + Math.max(0, co.cash) >= need) h = h.replace(/(<span[^>]*>Paid from<\/span><b>)[^<]*/, '$1Personal ' + mshort(Math.max(0, S.cash)) + ' + company ' + mshort(need - Math.max(0, S.cash)));
      else if (S.cash + Math.max(0, co.cash) < need) h = h.replace('<h3 class="gap">Step 2 of 2', '<div class="card probcard"><b>Not enough money</b><span class="tipt">It costs ' + money(need) + '. You have ' + money(Math.max(0, S.cash)) + ' and the company ' + money(Math.max(0, co.cash)) + '.</span></div><h3 class="gap">Step 2 of 2');
      if (co.acc) {
        const i = h.indexOf('<h3 class="gap">Step 2 of 2');
        const j = h.lastIndexOf('<button', h.indexOf('data-a="sheetclose"'));
        if (i >= 0 && j > i) h = h.slice(0, i) + '<h3 class="gap">Step 2 of 2 · Your accountant</h3><div class="card">' + row('Keeps the books', esc(co.acc.name)) + '</div>' + btn('Convert · pay ' + money(need), 'convgo', { id: co.id, a: co.acc.id }, 'primary wide') + h.slice(j);
      }
      ui.sheet.html = h;
      render();
    } catch (e) { console.error(e); }
  });
}



/* ===== Round 56: every store has an address, and stores under one name sit in one folder.
   - addrOf(co): a street address in the country's own style (Storgata 12 in Norway, 12 High Street in the UK,
     Calle Mayor, 12 in Spain, 1-2-3 Ginza in Japan). It is drawn from the company and its premises, so it changes
     when the company moves and stays the same otherwise.
   - On the Companies tab (ui/screens/companies_list.js V.cos) two or more companies of the same trade under the
     same name ("Kaffe Nord", "Kaffe Nord 2", "Kaffe Nord Bergen") are one folder row, like a registered chain. The folder lists every store with its address and
     city, and offers to register them as a chain so they share rules, prices and a board. ===== */
window.BR56 = window.BR56 || {};
(function () {
  const B = window.BR56;
  const U = window.UI;
  if (!U) return;
  const { ui, V, esc, btn, svg } = U;
  const P = o => esc(JSON.stringify(o));
  const liveCo = c => c && c.st !== 'sold' && c.st !== 'bust';
  /* common street names and how a number is written with them: n = number first, a = after, c = after a comma */
  const ST = {
    NO: ['a', 'Storgata', 'Kirkegata', 'Strandgata', 'Parkveien', 'Torggata', 'Bogstadveien', 'Dronningens gate', 'Kongens gate'],
    SE: ['a', 'Storgatan', 'Drottninggatan', 'Kungsgatan', 'Hamngatan', 'Sveavägen', 'Götgatan'],
    DE: ['a', 'Hauptstraße', 'Bahnhofstraße', 'Schillerstraße', 'Gartenstraße', 'Lindenstraße', 'Goethestraße'],
    UK: ['n', 'High Street', 'Station Road', 'Church Street', 'King Street', 'Victoria Road', 'Market Street'],
    FR: ['c0', 'rue de la République', 'rue Victor Hugo', 'avenue Jean Jaurès', 'rue du Marché', 'boulevard Voltaire', 'rue de la Paix'],
    ES: ['c', 'Calle Mayor', 'Gran Vía', 'Calle Real', 'Avenida de la Constitución', 'Calle del Carmen', 'Calle de Alcalá'],
    NL: ['a', 'Kerkstraat', 'Dorpsstraat', 'Stationsweg', 'Molenstraat', 'Hoogstraat', 'Nieuwstraat'],
    PL: ['a', 'ul. Długa', 'ul. Kościuszki', 'ul. Mickiewicza', 'ul. Piłsudskiego', 'ul. Słowackiego', 'ul. Marszałkowska'],
    LT: ['a', 'Gedimino pr.', 'Pilies g.', 'Vilniaus g.', 'Laisvės al.', 'Didžioji g.', 'Savanorių pr.'],
    US: ['n', 'Main Street', 'Oak Street', 'Maple Avenue', 'Broadway', 'Elm Street', 'Washington Avenue'],
    CA: ['n', 'Main Street', 'King Street', 'Queen Street', 'Yonge Street', 'Maple Avenue', 'Front Street'],
    AU: ['n', 'George Street', 'Queen Street', 'High Street', 'Chapel Street', 'King Street', 'Elizabeth Street'],
    JP: ['j', 'Ginza', 'Shinjuku', 'Umeda', 'Sakae', 'Tenjin', 'Omotesando'],
    KR: ['a', 'Teheran-ro', 'Sejong-daero', 'Gangnam-daero', 'Itaewon-ro', 'Jongno', 'Hongik-ro'],
    BR: ['c', 'Rua Augusta', 'Avenida Paulista', 'Rua das Flores', 'Rua XV de Novembro', 'Avenida Brasil', 'Rua Oscar Freire'],
    CH: ['a', 'Bahnhofstrasse', 'Marktgasse', 'Seestrasse', 'Kirchgasse', 'Rue du Rhône', 'Hauptgasse'],
    MX: ['c', 'Avenida Reforma', 'Calle Madero', 'Avenida Juárez', 'Calle Hidalgo', 'Avenida Insurgentes', 'Calle Morelos'],
    AE: ['u', 'Sheikh Zayed Road', 'Al Wasl Road', 'Jumeirah Beach Road', 'Al Maktoum Street', 'Hamdan Street', 'Corniche Road'],
    IT: ['c', 'Via Roma', 'Corso Italia', 'Via Garibaldi', 'Via Dante', 'Via Mazzini', 'Corso Vittorio Emanuele'],
    DK: ['a', 'Strøget', 'Vestergade', 'Østergade', 'Nørregade', 'Algade', 'Søndergade'],
    FI: ['a', 'Mannerheimintie', 'Aleksanterinkatu', 'Hämeenkatu', 'Kauppakatu', 'Rantakatu', 'Esplanadi'],
    IE: ['n', 'Main Street', 'O’Connell Street', 'Grafton Street', 'Patrick Street', 'Shop Street', 'Church Street'],
    SG: ['n', 'Orchard Road', 'Raffles Place', 'North Bridge Road', 'Beach Road', 'Tanjong Pagar Road', 'Bukit Timah Road']
  };
  function addrOf(co) {
    if (!co) return '';
    const cc = co.country || S.country, L = ST[cc] || ST.UK;
    const R = hrng('addr:' + co.id + ':' + ((co.prem && (co.prem.lname || co.prem.m2)) || 0) + ':' + co.city);
    const st = L[1 + Math.floor(R() * (L.length - 1))], n = 1 + Math.floor(R() * (R() < 0.7 ? 40 : 160));
    const f = L[0];
    return f === 'n' ? n + ' ' + st : f === 'c0' ? n + ' ' + st : f === 'c' ? st + ', ' + n : f === 'j' ? (1 + Math.floor(R() * 6)) + '-' + (1 + Math.floor(R() * 12)) + '-' + n + ' ' + st : f === 'u' ? 'Unit ' + n + ', ' + st : st + ' ' + n;
  }
  B.addrOf = addrOf;
  window.addrOf = addrOf;
  /* where a company is, in one line: the address and the city */
  B.where = co => addrOf(co) + ', ' + cityOf(co.city).name;

  /* what one site of a trade is called: an accounting firm has offices, a café has cafés, a shop has stores */
  const SITE = { cons: 'office', law: 'office', acctfirm: 'office', webdev: 'office', mktg: 'office', staffing: 'office', estate: 'office', tutor: 'centre', engcons: 'office', photo: 'studio', event: 'office', insco: 'office', bank: 'branch', fund: 'office',
    barber: 'salon', physio: 'clinic', drivsk: 'school', carrepair: 'workshop', handy: 'workshop', furniture: 'workshop', electrician: 'branch', plumber: 'branch', construction: 'branch', cleaning: 'branch', pets: 'centre',
    courier: 'depot', trucking: 'depot', taxi: 'depot', wh3pl: 'warehouse', farm: 'farm', salmon: 'site', hotel: 'hotel', gym: 'gym', cafe: 'café', restaurant: 'restaurant', nightclub: 'club', foodtruck: 'truck',
    skires: 'resort', indoorski: 'hall', fun: 'park', casino: 'casino', bakery: 'bakery', brewery: 'brewery', factory: 'plant', carclean: 'car wash', cardealer: 'dealership', webshop: 'shop', parking: 'site', resrent: 'building', comrent: 'building', dental: 'clinic', gamestudio: 'studio', security: 'office', vineyard: 'estate', pcbang: 'café', carrental: 'branch' };
  const PL = { branch: 'branches', 'car wash': 'car washes', café: 'cafés', bakery: 'bakeries', brewery: 'breweries', depot: 'depots', centre: 'centres' };
  function siteW(type, n) { const w = SITE[type] || 'store'; return n === 1 ? w : (PL[w] || w + 's'); }
  window.siteW = siteW;
  B.siteW = siteW;

  /* ---------- companies under one name, without a registered chain ---------- */
  const baseName = co => {
    let n = String(co.name || '').trim();
    const cn = cityOf(co.city).name;
    n = n.replace(/\s+\d+$/, '');
    if (cn && n.endsWith(' ' + cn)) n = n.slice(0, -cn.length - 1);
    return n.replace(/\s+\d+$/, '').toLowerCase();
  };
  const keyOf = co => co.type + '|' + (co.country || S.country) + '|' + baseName(co);
  function groupOf(co) {
    if (!co || co.chain || co.type === 'hold') return null;
    const k = keyOf(co);
    const L = S.cos.filter(c => liveCo(c) && !c.chain && c.type !== 'hold' && keyOf(c) === k);
    return L.length >= 2 ? { k, L } : null;
  }
  B.groupOf = groupOf;
  const nameOf = g => g.L.slice().sort((a, b) => a.name.length - b.name.length)[0].name.replace(/\s+\d+$/, '');
  B.nameOf = nameOf;
  V.titles.brand56 = 'Stores';
  V.heads = V.heads || {};
  V.heads.brand56 = p => { const L = S.cos.filter(c => liveCo(c) && !c.chain && keyOf(c) === p.k); return L.length ? { t: nameOf({ L }), sub: BD[L[0].type].n + ' · ' + L.length + ' ' + siteW(L[0].type, L.length) } : { t: 'Stores' }; };
  V.brand56 = function (p) {
    const L = S.cos.filter(c => liveCo(c) && !c.chain && c.type !== 'hold' && keyOf(c) === p.k);
    if (!L.length) return '<div class="calm">These stores are gone.</div>';
    if (L.length === 1) return '<div class="calm">Only ' + esc(L[0].name) + ' is left under this name.</div>' + btn('Open ' + esc(L[0].name), 'go', { n: 'co', p: { id: L[0].id } }, 'primary wide');
    const mo = c => (c.hist || [])[c.hist.length - 1] || {};
    const rev = sum(L, c => mo(c).rev || 0), pr = sum(L, c => mo(c).profit || 0);
    let h = '<div class="tri"><div><span>Revenue/mo</span><b>' + mshort(rev) + '</b></div><div><span>Profit/mo</span><b class="' + (pr > 0 ? 'pos' : pr < 0 ? 'neg' : '') + '">' + mshort(pr) + '</b></div><div><span>Staff</span><b>' + sum(L, c => c.staff.length + (c.mgr ? 1 : 0)) + '</b></div></div>';
    /* by city, each store with its address */
    const cities = Array.from(new Set(L.map(c => c.city)));
    cities.forEach(ci => {
      const C = L.filter(c => c.city === ci);
      h += '<h2 class="sec">' + esc(cityOf(ci).name) + ' · ' + C.length + '</h2><div class="lrows">' + C.map(c => {
        const pf = lastProfit(c), m = c.mgr && S.npcs[c.mgr], al = badAlerts(c);
        return '<button class="lrow" data-a="go" data-p="' + P({ n: 'co', p: { id: c.id } }) + '">' + av(ini(c.name)) + '<span class="ctext"><b>' + esc(c.name) + '</b><small>' + esc(addrOf(c)) + ' · ' + (al.length ? '<em class="neg">' + esc(al[0][0]) + '</em>' : esc(m ? m.name : c.st === 'setup' ? 'Setting up' : 'You run it')) + '</small></span><b class="num ' + (pf > 0 ? 'pos' : pf < 0 ? 'neg' : '') + '">' + (pf == null ? '—' : mshort(pf)) + '</b></button>';
      }).join('') + '</div>';
    });
    const first = L.slice().sort((a, b) => (a.w0 || 0) - (b.w0 || 0))[0];
    h += '<div class="card"><b>Make them a chain</b><span class="tipt">A registered chain shares one set of rules, prices and marketing, can have a chain manager, and gets a board. Register it from the first store; the others join it.</span>' + btn('Register a chain from ' + esc(first.name), 'codeal', { id: first.id, s: 'grow' }, 'wide') + '</div>';
    return h;
  };
})();

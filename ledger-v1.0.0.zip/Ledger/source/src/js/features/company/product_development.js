/* ===== Round 56: developing something new. A company can run one development project at a time: a new product
   line, a premium range or a leaner process for producers; a menu refresh, a signature offer or a loyalty programme
   for venues; an own brand, an online shop or a store refit for shops; a new service, a fixed-price package or
   automation for service firms; better processes for the rest. It costs money up front (more for a bigger company)
   and takes weeks. The team's skill and the company's quality decide whether it works fully, partly or not at all.
   What it gives fades as rivals copy it: half of it is gone after about two years, and some of it stays for good.
   Real-world anchors: about 61% of launched products succeed (PDMA 2012 study), about 80% for the best developers and
   50% for the rest, so an average team here fully succeeds about 45% of the time, partly 22% and fails a third.
   Loyalty members visit and spend 18-30% more (Paytronix), a quarter or so of customers join: about +4% in all.
   A store remodel lifts sales from existing customers 7-10% for at least a year and the store is partly closed while
   it is done (here: a sixth less capacity during the weeks). Own-brand goods earn about 9 points more margin than
   brands (35% against 26%), on the share of goods that become your own. Shown on the company's Company tab. ===== */
window.RD56 = window.RD56 || {};
(function () {
  const RD = window.RD56;
  /* [id, name, what it does, effect kind, size, weeks, cost as a share of a year's sales] */
  const P = {
    prod: [['line', 'A new product line', 'More customers: about +6% demand', 'dem', 0.06, 16, 0.06], ['prem', 'A premium range', 'People pay more: about +5% on prices', 'tick', 0.05, 20, 0.05], ['lean', 'A leaner process', 'About 5% less on materials', 'cogs', 0.05, 12, 0.04]],
    venue: [['menu', 'A new menu or concept', 'More guests: about +5% demand', 'dem', 0.05, 8, 0.03], ['sig', 'A signature offer', 'People pay more: about +4% on prices', 'tick', 0.04, 10, 0.03], ['loyal', 'A loyalty programme', 'Regulars come back: about +4% demand', 'dem', 0.04, 6, 0.02]],
    retail: [['own', 'An own brand', 'Better margins: about 4% less on goods', 'cogs', 0.04, 18, 0.04], ['web', 'An online shop', 'More customers: about +6% demand', 'dem', 0.06, 12, 0.04], ['refit', 'A store refit', 'More customers: about +7% demand; partly closed while it is done', 'dem', 0.07, 6, 0.05]],
    svc: [['svc', 'A new service', 'More clients: about +6% demand', 'dem', 0.06, 12, 0.04], ['pack', 'A fixed-price package', 'Clients pay more: about +4% on prices', 'tick', 0.04, 8, 0.03], ['auto', 'Automation and tools', 'More done with the same team: about +5% capacity', 'cap', 0.05, 14, 0.04]],
    other: [['proc', 'Better processes', 'More done with the same people: about +5% capacity', 'cap', 0.05, 14, 0.04], ['offer', 'A new offer for customers', 'More customers: about +4% demand', 'dem', 0.04, 12, 0.03]]
  };
  const famOf = co => { const f = BD[co.type].fam; return P[f] ? f : (f === 'fin' || f === 'energy' || f === 'rent' || f === 'club' || f === 'hold') ? null : 'other'; };
  const R = co => (co.rd56 = co.rd56 || { run: null, done: [] });
  const yrRev = co => Math.max(co.lastW ? co.lastW.rev * 52 : 0, sum((co.hist || []).slice(-12), h => h.rev || 0));
  const costOf = (co, p) => rnl(Math.max(KC(40000, co.country), yrRev(co) * p[6]), 1000);
  /* the share of the effect still working: half of it is copied away after about two years, 40% stays for good */
  const left = d => 0.4 + 0.6 * Math.pow(0.5, (S.week - d.w) / 104);
  const mult = (co, kind) => { const r = co.rd56; if (!r || !r.done.length) return 1; return r.done.reduce((m, d) => d.kind === kind ? m * (1 + d.mag * left(d)) : m, 1); };
  RD.mult = mult;
  addStep('demand', 95, 'what the company has developed', (co, bd, r) => { const f = mult(co, 'dem'); if (f !== 1 && r && r.D > 0) { r.D *= f; if (r.parts) r.parts.rd56 = f; } }, true);
  addStep('ticketMult', 40, 'what the company has developed', (co, bd, r) => co ? r * mult(co, 'tick') : r);
  addStep('capacity', 70, 'what the company has developed (and a refit under way)', (co, bd, r) => { if (!r || !r.cap) return; const f = mult(co, 'cap') * (co.rd56 && co.rd56.run && co.rd56.run.k === 'refit' ? 0.84 : 1); if (f !== 1) r.cap *= f; }, true);
  addStep('modProd', 20, 'what the company has developed: cheaper materials', (co, k, v) => k === 'cogsup' && co.rd56 ? v * (2 - mult(co, 'cogs')) : v);
  function start(co, id) {
    const fam = famOf(co), p = fam && P[fam].find(x => x[0] === id);
    if (!p) return 'none';
    const r = R(co);
    if (r.run) return 'busy';
    if (r.done.some(d => d.k === id && S.week - d.w < 104)) return 'recent';
    const c = costOf(co, p);
    if (co.cash < c) return 'cash';
    payCo(co, c, 'oth', 'Development: ' + p[1]);
    r.run = { k: id, w0: S.week, wEnd: S.week + p[5], cost: c };
    return 'ok';
  }
  RD.start = start;
  addStep('week.after', 47, 'development projects finish', () => {
    S.cos.forEach(co => {
      const r = co.rd56;
      if (!r || !r.run || S.week < r.run.wEnd || co.st === 'sold' || co.st === 'bust') return;
      const fam = famOf(co), p = fam && P[fam].find(x => x[0] === r.run.k);
      r.run = null;
      if (!p) return;
      const sk = co.staff.length ? sum(co.staff, s => staffSkill(s)) / co.staff.length : 50;
      const odds = clamp(0.45 + (sk - 50) / 160 + ((co.q || 50) - 50) / 200 + (co.mgr ? (mgrQual(co) - 0.5) * 0.3 : 0), 0.15, 0.9);
      const z = Z();
      const got = z < odds ? 1 : z < odds + (1 - odds) * 0.4 ? 0.5 : 0;
      if (got) r.done.push({ k: p[0], kind: p[3], mag: p[4] * got, w: S.week, n: p[1] });
      if (r.done.length > 12) r.done.shift();
      addMsg({ kind: 'info', from: co.mgr && S.npcs[co.mgr] ? S.npcs[co.mgr].name : co.name, title: got === 1 ? p[1] + ' is a success' : got ? p[1] + ': a partial success' : p[1] + ' did not work out', body: got === 1 ? p[2] + '. Rivals will copy it in time.' : got ? 'It works, but about half as well as hoped.' : 'Customers did not take to it. The money is spent.', co: co.id, tone: got ? 'good' : 'bad', status: 'done' });
    });
  });
  /* ---------- the card on the Company tab ---------- */
  function rdCard(co) {
    const fam = famOf(co);
    if (!fam || co.st !== 'open') return '';
    const r = R(co);
    let h = '<div class="card"><div class="bhead"><b>Develop something new</b>' + (r.run ? '<span class="pill amb">' + Math.max(0, r.run.wEnd - S.week) + ' weeks to go</span>' : '') + '</div>';
    if (r.run) { const p = P[fam].find(x => x[0] === r.run.k); h += '<span class="tipt">' + esc(p ? p[1] : '') + ': ' + money(r.run.cost) + ' spent. The team\'s skill and your quality decide how well it works.</span>'; }
    else h += '<div class="lrows">' + P[fam].map(p => { const rec = r.done.some(d => d.k === p[0] && S.week - d.w < 104); return '<div class="lrow"><span class="ctext"><b>' + esc(p[1]) + '</b><small>' + esc(p[2]) + ' · ' + p[5] + ' weeks · ' + mshort(costOf(co, p)) + '</small></span>' + (rec ? '<small class="muted">Done lately</small>' : btn('Start', 'rd56go', { id: co.id, k: p[0] }, 'chip' + (co.cash < costOf(co, p) ? ' cant' : ''))) + '</div>'; }).join('') + '</div>';
    const live = r.done.filter(d => left(d) > 0.41);
    if (live.length) h += '<span class="tipt">Working now: ' + live.map(d => esc(d.n) + ' (' + Math.round(d.mag * left(d) * 100) + '%)').join(', ') + '</span>';
    return h + '</div>';
  }
  RD.card = rdCard;
  ACT.rd56go = p => {
    const co = getCo(p.id); if (!co) return;
    const r = start(co, p.k);
    if (r === 'ok') { save(); render(); toast('Development started.'); } else toast(r === 'cash' ? 'Not enough cash in the company.' : r === 'busy' ? 'One project at a time.' : 'Not possible right now.', true);
  };
})();

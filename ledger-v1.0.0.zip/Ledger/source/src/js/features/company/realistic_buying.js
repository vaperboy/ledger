/* ===== Round 6b: realistic buying. New items carry this year's model and a real-world warranty, used items have
   an age, a seller and a wear description (and sometimes a hidden truth), software is licensed or subscribed,
   only vehicles and big machines can be leased, and equipment needs follow the number of people who use it. ===== */
{
  const CT = window.CT;
  const GY = () => wYear(S.week);
  const pk = (R, a) => a[Math.floor(R() * a.length) % a.length];
  const mean = (a, f) => a.length ? a.reduce((t, x) => t + f(x), 0) / a.length : 0;
  const R6 = window.R6 = {};

  /* ---------- extra vehicle models ---------- */
  Object.assign(VEH, {
    van_box: ['Box van, 20 m³ (moving van)', 640000, 'van', 300000, 1.8, 2.1],
    taxi_cmf: ['Comfort sedan (hybrid)', 640000, 'car', 380000, 0.6, 1.2],
    taxi_prm: ['Premium executive sedan', 990000, 'car', 320000, 0.9, 1.2],
    taxi_xl: ['People carrier, 7 seats', 720000, 'van', 360000, 1.0, 1.3]
  });
  const addVo = (b, id, list) => { const e = BD[b] && BD[b].eq.find(x => x.id === id); if (e && e.vo) list.forEach(m => { if (e.vo.indexOf(m) < 0) e.vo.push(m); }); };
  addVo('taxi', 'car', ['taxi_cmf', 'taxi_xl', 'taxi_prm']);
  addVo('courier', 'van', ['van_box']);
  addVo('furniture', 'van', ['van_box']);
  addVo('construction', 'vans', ['ev_van']);
  const TCLS = { car_s: 0, car_ev: 0, taxi_ev: 0, taxi_cmf: 1, taxi_xl: 1, taxi_prm: 2, car_lux: 2 };
  const TCN = ['Standard', 'Comfort', 'Premium'];

  /* ---------- what kind of thing is it ---------- */
  const SUBRX = /cloud|subscription|crm|applicant|tracking|platform|portal|research|\bdata\b|terminals and data|\bapp\b|dispatch|booking and student|ticketing|payroll|journal|listing|routing|analytics|\bcad\b|\bbim\b|seismic/;
  const OVK = { 'cleaning:chem': 'mach', 'electrician:lift': 'tool', 'salmon:boat': 'mach', 'oilgas:plat': 'svc', 'webdev:desk': 'furn', 'nightclub:cctv': 'mach', 'fun:sound': 'mach', 'event:sound': 'mach', 'staffing:ats': 'soft', 'furniture:paint': 'mach', 'furniture:saw': 'mach', 'casino:vault': 'furn', 'trucking:tms': 'soft', 'trucking:wash': 'furn', 'airline:ops': 'soft', 'shipping:dock': 'svc', 'fund:risk': 'soft', 'airline:hangar': 'furn', 'cardealer:lift': 'mach' };
  const SUBK = { 'power:scada': 0, 'trucking:tms': 1, 'staffing:ats': 1, 'airline:ops': 0, 'fund:risk': 0 };
  function kindOf(bd, e) {
    if (e.vo) return 'veh';
    if (OVK[bd.id + ':' + e.id]) return OVK[bd.id + ':' + e.id];
    const n = e.n.toLowerCase(), mc = eqMakerCat(e.n, bd.id);
    if (/website|webshop add-on|portfolio/.test(n)) return 'svc';
    if (mc === 'serv') return 'svc';
    if (/dispatch app|software|licen|subscriptions|cloud|platform|cad\/bim|system and portal|research|terminals and data/.test(n) && !/workstation|hardware/.test(n)) return 'soft';
    if (mc === 'soft') return 'soft';
    if (mc === 'it' || /laptop|workstation|phones\b/.test(n)) return 'it';
    if (mc === 'pay') return 'pos';
    if (mc === 'tools' || /tool|ladder|instrument|polisher|lens|camera body|drone|kit\b/.test(n)) return 'tool';
    if (mc === 'furn') return 'furn';
    return 'mach';
  }
  function softMode(co, e) {
    const n = e.n.toLowerCase(), sk = SUBK[co.type + ':' + e.id];
    if (sk != null) return sk ? 'sub' : 'upfront';
    if (SUBRX.test(n)) return 'sub';
    return eqPrice(co, e) < KC(20000, co.country) ? 'once' : 'upfront';
  }
  const KINDN = { veh: 'Vehicle', soft: 'Software', svc: 'Service', it: 'IT equipment', pos: 'Payment terminal', tool: 'Tools', furn: 'Furniture and fit-out', mach: 'Machine' };
  function vclass(m) {
    if (m === 'van_box' || m === 'foodtruck') return 'boxvan';
    if (m === 'excav') return 'plant';
    if (m === 'crane') return 'crane';
    const c = VEH[m] ? VEH[m][2] : 'car';
    return { car: 'car', van: 'van', truck: 'truck', bus: 'bus', bike: /scooter/.test(m) ? 'scooter' : 'bike', plant: 'plant', ship: 'ship', plane: 'plane' }[c] || 'car';
  }
  function picKind(bd, e, m) {
    if (e.vo) return vclass(m || e.vo[0]);
    const k = kindOf(bd, e), n = e.n.toLowerCase(), mc = eqMakerCat(e.n, bd.id);
    if (k === 'soft') return 'soft';
    if (k === 'svc') return /website|webshop|portfolio/.test(n) ? 'soft' : 'doc';
    if (k === 'it') return /phone/.test(n) && !/laptop/.test(n) ? 'phone' : 'laptop';
    if (k === 'pos') return 'pos';
    if (k === 'tool') return /camera|lens|drone/.test(n) ? 'camera' : 'tool';
    if (k === 'furn') return 'furn';
    if (mc === 'refrig') return 'fridge';
    if (mc === 'food') return 'kitchen';
    if (mc === 'photo' || mc === 'secur') return 'camera';
    if (mc === 'av') return 'av';
    if (mc === 'marine') return /boat/.test(n) ? 'boat' : 'ship';
    return 'machine';
  }
  const vehOpt = m => ({ ev: /ev|electric/.test(m), taxi: /^taxi/.test(m), lux: m === 'car_lux' || m === 'taxi_prm' });
  R6.picEq = (bd, e, seed, m) => pic(picKind(bd, e, m), seed || e.id, e.vo ? vehOpt(m || e.vo[0]) : {});

  /* ---------- warranties and workshop times (rough real-world terms for business buyers) ---------- */
  function warrY(k, e, cls, m, price, cc) {
    if (k === 'veh') {
      const c = vclass(m);
      if (c === 'car' || c === 'van' || c === 'boxvan') return /ev|electric/.test(m) ? 5 : (m === 'car_lux' || m === 'taxi_prm') ? 4 : 3;
      if (c === 'truck' || c === 'bus') return 2;
      if (c === 'bike' || c === 'scooter') return 2;
      if (c === 'plant' || c === 'crane') return 1;
      return 2;
    }
    if (k === 'tool') return cls >= 2 ? 3 : 2;
    if (k === 'it' || k === 'pos') return cls >= 2 ? 3 : 1;
    if (k === 'furn') return cls >= 2 ? 5 : 2;
    if (k === 'soft' || k === 'svc') return 0;
    return (price >= KC(500000, cc) ? 2 : 1) + (cls >= 2 ? 1 : 0);
  }
  const WD = { tool: [7, 14], it: [3, 10], pos: [3, 7], furn: [5, 15], mach: [3, 21], car: [2, 7], van: [2, 8], boxvan: [2, 8], truck: [3, 12], bus: [3, 12], bike: [2, 6], scooter: [2, 6], plant: [7, 25], crane: [7, 25], ship: [10, 30], plane: [7, 28] };
  const WHERE = { tool: "the maker's service centre", it: 'the repair centre', pos: 'the supplier', furn: 'the supplier', mach: 'a service technician', car: 'the dealer workshop', van: 'the dealer workshop', boxvan: 'the dealer workshop', truck: 'the truck workshop', bus: 'the workshop', bike: 'the bike shop', scooter: 'the workshop', plant: 'the dealer', crane: 'the dealer', ship: 'the yard', plane: 'the maintenance base' };
  const wdKey = (k, m) => k === 'veh' ? vclass(m) : k;

  /* ---------- wear: what the player can see ---------- */
  const WEAR = [[0.93, 'Like new'], [0.8, 'Minimal wear'], [0.65, 'Light wear'], [0.48, 'Well worn'], [0, 'Heavily worn']];
  const wearOf = c => WEAR.find(x => c >= x[0])[1];
  const wearCls = c => c >= 0.8 ? 'grn' : c >= 0.65 ? '' : c >= 0.48 ? 'amb' : 'red';
  /* the player's own impression: what it looked like when bought, minus the wear they have seen since */
  const seen = u => clamp((u.vis != null ? u.vis : u.cond != null ? u.cond : u.tc) - ((u.c0 != null ? u.c0 : (u.tc != null ? u.tc : u.cond)) - (u.tc != null ? u.tc : u.cond)), 0.05, 1);
  R6.wearOf = wearOf; R6.seen = seen;

  /* ---------- who uses it: personal items scale with the people doing the work ---------- */
  const PER = {
    'carclean:van': [['carwash'], 2, 0], 'handy:van': [['handy'], 1, 0], 'handy:tools': [['handy'], 1, 0],
    'cleaning:van': [['cleaner'], 3, 0.3], 'cleaning:vac': [['cleaner'], 1, 0],
    'drivsk:car': [['instr'], 1, 0], 'estate:car': [['estate'], 1, 0.6],
    'construction:vans': [['labour', 'carp', 'foreman'], 3, 0.3], 'construction:tools': [['labour', 'carp', 'foreman'], 3, 0],
    'electrician:vans': [['elec'], 1, 0.2], 'electrician:tools': [['elec'], 1, 0],
    'plumber:vans': [['plumb'], 1, 0.2], 'plumber:tools': [['plumb'], 1, 0],
    'event:van': [['event', 'av'], 3, 0.4], 'taxi:car': [['driver'], 1, 0], 'courier:van': [['courier'], 1, 0],
    'trucking:truck': [['truckd'], 1, 0], 'trucking:trail': [['truckd'], 1, 0],
    'barber:chair': [['barber'], 1, 0], 'physio:bench': [['physio'], 1, 0], 'pets:groom': [['groom'], 1, 0], 'photo:cam': [['photog'], 1, 0]
  };
  function ruleOf(bd, e) {
    const r = PER[bd.id + ':' + e.id];
    if (r) return r;
    if (!e.vo && kindOf(bd, e) === 'it' && /laptop|workstation/.test(e.n.toLowerCase())) return [['*'], 1, 0.25];
    return null;
  }
  const ownerWorks = co => !co.mgr && co.ohrs > 0;
  function prodN(co, bd, roles) {
    let n = co.staff.filter(s => (roles[0] === '*' || roles.indexOf(s.role) >= 0) && !(s.notice > 0)).length;
    if (ownerWorks(co) && (roles[0] === '*' || (bd.std[0] && roles.indexOf(bd.std[0][0]) >= 0))) n += 1;
    return n;
  }
  function needOf(co, bd, e) {
    const rl = ruleOf(bd, e), std = stdEq(bd, co.size)[e.id] || 0;
    if (!rl) return e.fl.indexOf('r') >= 0 ? Math.max(1, std) : std;
    let w = prodN(co, bd, rl[0]);
    if (!co.staff.length && !ownerWorks(co)) return Math.max(e.fl.indexOf('r') >= 0 ? 1 : 0, std ? Math.min(std, 1) : 0);
    if (bd.id === 'estate' && e.id === 'car') w -= co.staff.filter(s => s.ownCar && s.role === 'estate').length;
    if (bd.id === 'courier' && e.id === 'van') w -= Math.min(w, eqCount(co, 'bike'));
    return w > 0 ? Math.ceil(w / rl[1]) : 0;
  }
  R6.kindOf = kindOf; R6.needOf = needOf; R6.ruleOf = ruleOf; R6.prodN = prodN;
  const roleW = roles => roles[0] === '*' ? 'person' : ROLES[roles[0]] ? ROLES[roles[0]][0].toLowerCase() : 'worker';
  function perText(rl) {
    return rl[1] === 1 ? 'one per ' + roleW(rl[0]) : 'one per ' + rl[1] + ' ' + roleW(rl[0]) + (/s$/.test(roleW(rl[0])) ? '' : 's') + ' on a job';
  }

  /* ---------- per-unit records ---------- */
  function unitsOf(co, id) {
    co.units = co.units || {};
    const r = co.eq[id];
    if (!r || r.sub) {
      delete co.units[id];
      return [];
    }
    const U = co.units[id] || (co.units[id] = []);
    const n = Math.max(0, Math.round(r.n));
    while (U.length < n) U.push({ u: uid(), src: 'old', nm: r.mods && r.mods[0] ? r.mods[0].nm : '', yr: GY() - 1, tc: r.cond, vis: r.cond, c0: r.cond, warr: 0, price: Math.round(r.cost / Math.max(1, r.n)), down: 0, rel: r.rel || 1 });
    if (U.length > n) U.splice(n);
    return U;
  }
  R6.unitsOf = unitsOf;
  function usedTruth(R, age, life) {
    const tc = clamp(0.95 - age * 0.07 + (R() - 0.6) * 0.2, 0.18, 0.95);
    const dressed = R() < 0.25;
    const vis = dressed ? Math.min(0.95, tc + 0.15 + R() * 0.15) : clamp(tc + (R() - 0.5) * 0.08, 0.1, 0.97);
    return { tc, vis, dressed };
  }
  function newUnit(co, bd, e, cat, src, meta) {
    const k = kindOf(bd, e), price = meta && meta.price || eqPrice(co, e, null, cat);
    if (src === 'new') return { u: uid(), src, nm: cat ? cat.brand + ' ' + cat.model : e.n, yr: GY(), tc: 1, vis: 1, c0: 1, warr: S.week + warrY(k, e, cat ? cat.cls : 1, null, price, co.country) * 52, price, down: 0, rel: cat ? cat.rel : 1, cls: cat ? cat.cls : 1 };
    if (meta) return { u: uid(), src: 'used', nm: meta.nm, yr: meta.yr, tc: meta.tc, vis: meta.vis, c0: meta.tc, warr: 0, price: meta.price, down: 0, rel: meta.rel, kr: meta.kr, cls: meta.cls };
    const R = hrng(uid() + ':u'), age = rint(2, 6), t = usedTruth(R, age, e.life);
    return { u: uid(), src: 'used', nm: cat ? cat.brand + ' ' + cat.model : e.n, yr: GY() - age, tc: t.tc, vis: t.vis, c0: t.tc, warr: 0, price: Math.round(price * 0.55), down: 0, rel: (cat ? cat.rel : 1) * (1 + age * 0.04), cls: cat ? cat.cls : 1 };
  }
  function syncCond(co, id) {
    const r = co.eq[id], U = co.units && co.units[id];
    if (r && U && U.length) r.cond = mean(U, u => u.tc);
    if (r) r._c = r.cond;
  }

  /* ---------- buying: steps in the purchase pipelines (buyEq.order, buyEq.after, buyVeh) ---------- */
  /* software and services are one licence; leasing only where it is allowed; each unit is recorded */
  addStep('buyEq.order', 10, 'realistic buying: the order', (co, eqId, o) => {
    const bd = BD[co.type], e = bd && bd.eq.find(x => x.id === eqId);
    if (!e || e.vo) return;
    const k = kindOf(bd, e);
    o.cat = o.cat || mgrCat(co, eqId);
    if (k === 'soft' && softMode(co, e) === 'sub') { o.r = subscribe(co, e, recTier(co), o.cat); return; }
    if (k === 'soft' || k === 'svc') {
      o.qty = 1;
      if (o.mode === 'used' || o.mode === 'lease') o.mode = 'new';
      if (co.eq[eqId] && co.eq[eqId].n >= 1) { o.r = 'ok'; return; }
    }
    const unit = eqPrice(co, e, null, o.cat);
    if (o.mode === 'lease' && !leaseOk(co, e, unit)) o.mode = unit * (o.qty || 1) >= KC(30000, co.country) ? 'finance' : 'new';
    if (co.eq[eqId]) unitsOf(co, eqId);
    o.b6 = { bd, e, k, unit };
  });
  addStep('buyEq.after', 10, 'realistic buying: what was bought', (co, eqId, o) => {
    if (!o.b6 || o.r !== 'ok' || o.mode === 'lease') return;
    const { bd, e, k, unit } = o.b6, rec = co.eq[eqId];
    if (k === 'soft' || k === 'svc') {
      rec.soft = k === 'svc' ? 'svc' : softMode(co, e);
      rec.ver = S.week;
      rec.upd = rec.soft === 'upfront' ? Math.round(unit * 0.18) : 0;
      rec.cond = 1;
    } else {
      co.units = co.units || {};
      const U = co.units[eqId] || (co.units[eqId] = []);
      for (let i = 0; i < (o.qty || 1); i++) U.push(newUnit(co, bd, e, o.cat, o.mode === 'used' ? 'used' : 'new'));
      syncCond(co, eqId);
    }
  });
  addStep('buyVeh.before', 10, 'vehicles: count before', (co, eqId, modelId, mode, cat, ph) => { ph.n0 = co.veh.length; });
  addStep('buyVeh.after', 10, 'vehicles: model year, history and warranty', (co, eqId, modelId, mode, cat, ph) => {
    if (ph.r !== 'ok' || co.veh.length <= ph.n0) return;
    const v = co.veh[co.veh.length - 1];
    v.yr = GY();
    v.src = mode === 'used' ? 'used' : mode === 'lease' ? 'lease' : 'new';
    v.down = 0;
    if (v.src === 'used') {
      const R = hrng(v.id + ':v'), age = rint(3, 8), t = usedTruth(R, age, 10);
      v.yr -= age;
      v.cond = t.tc;
      v.vis = t.vis;
      v.c0 = t.tc;
      v.warr = 0;
      v.km = Math.max(v.km || 0, age * 15000);
    } else {
      v.vis = 1;
      v.c0 = 1;
      v.warr = S.week + (v.src === 'lease' ? 156 : warrY('veh', null, 1, modelId, v.cost, co.country) * 52);
      v.name = (cat ? cat.brand + ' ' + cat.model : v.name).replace(/ \(used\)$/, '') + ' ' + v.yr;
    }
  });
  function leaseOk(co, e, unit) {
    if (e.vo) return true;
    const bd = BD[co.type];
    return kindOf(bd, e) === 'mach' && unit >= KC(100000, co.country);
  }
  R6.leaseOk = leaseOk;
  const finOk = (co, e, unit) => !e.vo ? kindOf(BD[co.type], e) !== 'soft' && unit >= KC(30000, co.country) : true;

  /* ---------- software subscriptions: three plans by number of users ---------- */
  const TIER = [['Basic', 3, 0.55, 0.97], ['Team', 15, 1, 1], ['Business', 1e9, 1.9, 1.05]];
  const users = co => co.staff.length + 1;
  function recTier(co) {
    const u = users(co);
    return u <= 3 ? 0 : u <= 15 ? 1 : 2;
  }
  function subFee(co, e, c, t) {
    return Math.max(KC(90, co.country), Math.round(eqPrice(co, e, null, c) / Math.max(1, e.life) / 12 * TIER[t][2] / 10) * 10);
  }
  function subscribe(co, e, t, c) {
    const bd = BD[co.type];
    c = c || eqDefault(co.type, e.id);
    const fee = subFee(co, e, c, t);
    if (co.cash < fee) return 'cash';
    payCo(co, fee, 'oth', 'Subscription: ' + c.brand + ' ' + TIER[t][0]);
    const old = co.eq[e.id];
    co.eq[e.id] = { n: 1, cond: 1, bv: old && !old.sub ? old.bv : 0, cost: old && !old.sub ? old.cost : 0, used: 0, age: 0, life: e.life, sub: { tier: t, fee, nm: c.brand + ' ' + c.model, w0: S.week, c: c.i }, perf: TIER[t][3], rel: 1, mods: [{ nm: c.brand + ' ' + c.model, n: 1, rt: c.rating }] };
    if (co.units) delete co.units[e.id];
    const F = FAM[bd.fam];
    if (!old && F && F.afterBuy) F.afterBuy(co, bd, e.id, 1);
    return 'ok';
  }
  R6.subscribe = subscribe; R6.subFee = subFee; R6.TIER = TIER;

  /* ---------- used listings: refreshed monthly, each one different ---------- */
  const SELLERS = ['Private seller', 'Used-equipment dealer', 'Online marketplace', 'Closing-down sale', 'Auction house'];
  const SAYS_D = ['Freshly cleaned and serviced', 'Looks almost new', 'Hardly used, we are closing down'];
  function usedEqList(co, bd, e) {
    const key = S.seed + ':ul:' + co.id + ':' + e.id + ':' + monthIdx(S.week);
    const R = hrng(key), cat = eqCat(co.type, e.id, brandN(co), co.country);
    const taken = (co.uTaken || {})[key] || [];
    const out = [];
    const n = 3 + Math.floor(R() * 3);
    for (let i = 0; i < n; i++) {
      const c = cat[Math.floor(R() * cat.length)];
      const age = 1 + Math.floor(R() * Math.min(8, e.life + 2));
      const t = usedTruth(R, age, e.life);
      const kr = age >= 4 && R() < 0.25;
      const price = Math.max(100, rnl(eqPrice(co, e, null, c) * 0.78 * Math.pow(0.86, age) * (0.7 + 0.45 * t.vis), 100));
      const says = t.dressed ? pk(R, SAYS_D) : t.vis > 0.8 ? 'Well kept, light use' : t.vis > 0.6 ? 'Normal signs of use' : 'Used hard, but works';
      out.push({ id: key + ':' + i, key, i, c: c.i, nm: c.brand + ' ' + c.model, cls: c.cls, age, yr: GY() - age, tc: t.tc, vis: t.vis, kr, price, seller: pk(R, SELLERS), says, rel: c.rel * (kr ? 0.65 : 1 + age * 0.04), rating: c.rating, perf: c.perf });
    }
    return out.filter(x => taken.indexOf(x.i) < 0);
  }
  function usedVehList(co, bd, e) {
    const key = S.seed + ':uv:' + co.id + ':' + e.id + ':' + monthIdx(S.week);
    const R = hrng(key), infl = Math.pow(1 + S.econ.infl, S.week / 52);
    const taken = (co.uTaken || {})[key] || [];
    const out = [];
    const n = 4 + Math.floor(R() * 3);
    for (let i = 0; i < n; i++) {
      const m = e.vo[Math.floor(R() * e.vo.length)], vm = VEH[m];
      if (!vm) continue;
      const vc = vehCat(m), c = vc[Math.floor(R() * vc.length)];
      const cl = vclass(m);
      const age = 1 + Math.floor(R() * (cl === 'plant' || cl === 'ship' || cl === 'plane' ? 14 : 11));
      const kmY = bd.id === 'taxi' ? 60000 : cl === 'truck' || cl === 'bus' ? 90000 : cl === 'bike' || cl === 'scooter' ? 4000 : 18000;
      const km = Math.round(age * kmY * (0.6 + R() * 0.8) / 1000) * 1000;
      const tc = clamp(0.97 - age * 0.045 - km / 700000 + (R() - 0.6) * 0.18, 0.15, 0.96);
      const dressed = R() < 0.25;
      const vis = dressed ? Math.min(0.95, tc + 0.15 + R() * 0.15) : clamp(tc + (R() - 0.5) * 0.08, 0.1, 0.97);
      const kr = age >= 5 && R() < 0.28;
      const base = rnl(vm[1] * infl * c.f, 1000);
      const price = Math.max(1000, Math.round(base * 0.8 * Math.pow(0.87, age - 1) * clamp(1 - (km / Math.max(1, age * kmY) - 1) * 0.15, 0.8, 1.15) * (0.8 + 0.3 * vis) / 1000) * 1000);
      const risk = (1 - vis) * 1.4 + age * 0.05 + km / 500000 - (kr ? 0.3 : 0);
      out.push({ id: key + ':' + i, key, i, m, b: c.i, nm: c.brand + ' ' + c.model, yr: GY() - age, age, km, tc, vis, kr, price, seller: pk(R, SELLERS), risk: risk < 0.45 ? 'Low' : risk < 0.8 ? 'Medium' : 'High', fuel: age >= 8 ? 'Higher' : age >= 4 ? 'Normal' : 'Low', rel: c.rel * (kr ? 0.65 : 1 + age * 0.05), rating: c.rating, says: dressed ? pk(R, ['Just serviced, looks great', 'One careful owner', 'Fresh polish and new mats']) : vis > 0.8 ? 'Good condition' : vis > 0.6 ? 'Some scratches, drives well' : 'Worn, priced to sell' });
    }
    return out.filter(x => taken.indexOf(x.i) < 0);
  }
  const takeListing = (co, L) => { co.uTaken = co.uTaken || {}; for (const k in co.uTaken) if (k.split(':').pop() != String(monthIdx(S.week))) delete co.uTaken[k]; (co.uTaken[L.key] = co.uTaken[L.key] || []).push(L.i); };
  function mkLoan(co, amt, name, months, extra) {
    const l = { id: uid(), kind: 'biz', name, bal: amt, margin: creditMargin() + extra, pay: 0, termM: months, co: co.id, w0: S.week, guar: co.form === 'AS' ? 0 : 1 };
    l.pay = annuity(l.bal, policy() + l.margin, months);
    S.loans.push(l);
    return l;
  }
  function buyUsedEq(co, bd, e, L, pay) {
    const cat = eqCat(co.type, e.id, brandN(co), co.country)[L.c];
    if (pay === 'finance') {
      if (co.cash < L.price * 0.2) return 'cash';
      payCo(co, L.price * 0.2, null, 'Down payment: used ' + L.nm);
      mkLoan(co, L.price * 0.8, 'Equipment loan: ' + L.nm, 36, 0.025);
    } else {
      if (co.cash < L.price) return 'cash';
      payCo(co, L.price, null, 'Used ' + L.nm + ' (' + L.yr + ')');
    }
    if (co.eq[e.id]) unitsOf(co, e.id);
    setupEqRec(co, e.id, e, L.price, 1, true, Object.assign({}, cat, { rel: L.rel }));
    co.units = co.units || {};
    const U = co.units[e.id] || (co.units[e.id] = []);
    U.push(newUnit(co, bd, e, cat, 'used', L));
    syncCond(co, e.id);
    takeListing(co, L);
    return 'ok';
  }
  function buyUsedVeh(co, e, L, pay) {
    let loan = 0;
    if (pay === 'finance') {
      if (co.cash < L.price * 0.2) return 'cash';
      payCo(co, L.price * 0.2, null, 'Down payment: used ' + L.nm);
      loan = mkLoan(co, L.price * 0.8, 'Vehicle loan: ' + L.nm, 48, 0.02).id;
    } else {
      if (co.cash < L.price) return 'cash';
      payCo(co, L.price, null, 'Used ' + L.nm + ' (' + L.yr + ')');
    }
    co.veh.push({ id: uid(), eq: e.id, model: L.m, cost: L.price, bv: L.price, cond: L.tc, km: L.km, mode: loan ? 'fin' : 'own', loan, name: L.nm + ' ' + L.yr, rel: L.rel, rating: L.rating, yr: L.yr, src: 'used', vis: L.vis, c0: L.tc, warr: 0, down: 0, kr: L.kr });
    takeListing(co, L);
    return 'ok';
  }
  R6.usedEqList = usedEqList; R6.usedVehList = usedVehList; R6.buyUsedEq = buyUsedEq; R6.buyUsedVeh = buyUsedVeh;

  /* ---------- weekly: wear per unit, breakdowns, warranty repairs, downtime, plans and mileage ---------- */
  addStep('eqWeek.before', 10, 'units follow the condition the week left them in', (co, util) => {
    const bd = BD[co.type];
    for (const id in co.eq) {
      const e0 = bd.eq.find(x => x.id === id);
      if (e0 && !co.eq[id].sub && !co.eq[id].soft) {
        const k0 = kindOf(bd, e0);
        if (k0 === 'soft' || k0 === 'svc') { co.eq[id].soft = k0 === 'svc' ? 'svc' : 'once'; co.eq[id].ver = co.eq[id].ver || S.week; delete (co.units || {})[id]; }
      }
      if (id === 'fit' || co.eq[id].sub || co.eq[id].soft) continue;
      const r = co.eq[id], U = unitsOf(co, id);
      if (r._c != null && U.length) {
        const d = r.cond - r._c;
        if (d > 0.001) U.forEach(u => { u.tc = Math.min(1, u.tc + d); });
        else if (d < -0.001) { const u = U[Math.floor(Z() * U.length)]; u.tc = Math.max(0.05, u.tc + d * U.length); }
      }
    }
  });
  addStep('eqWeek.after', 10, 'wear per unit, breakdowns, warranty repairs, plans and mileage', (co, util) => { postWeek(co, BD[co.type], util || 0.6); });
  function breakUnit(co, bd, e, k, u, m) {
    const wk = wdKey(k, m), W = WD[wk] || [3, 10];
    const days = rint(W[0], W[1]);
    const nm = u.nm || e.n;
    if (u.warr && S.week < u.warr) {
      u.down = days;
      return nm + ' broke down. Covered by warranty: ' + WHERE[wk] + ' fixes it for free, back in about ' + days + ' days.';
    }
    const cost = Math.max(KC(400, co.country), Math.round((u.price || u.cost || e.cost) * rng(0.05, 0.2)));
    payCo(co, cost, 'oth', 'Repair: ' + nm);
    u.down = Math.max(1, Math.round(days * 0.6));
    return nm + ' broke down. No warranty, so the repair cost ' + money(cost) + '. Back in about ' + u.down + ' days.';
  }
  function postWeek(co, bd, util) {
    const mm = [1.5, 1, 0.6][co.maint] || 1, ev = [];
    const open = co.st === 'open';
    for (const id in co.eq) {
      if (id === 'fit') continue;
      const r = co.eq[id], e = bd.eq.find(x => x.id === id);
      if (!e) continue;
      if (r.sub) {
        payCo(co, r.sub.fee * 12 / 52, 'oth');
        const lim = TIER[r.sub.tier][1];
        r.perf = users(co) > lim ? 0.85 : TIER[r.sub.tier][3];
        r.cond = 1; r._c = 1;
        continue;
      }
      if (r.soft) {
        if (r.upd) payCo(co, r.upd / 52, 'oth');
        if (r.soft === 'once' && S.week - (r.ver || S.week) > e.life * 52) r.perf = Math.min(r.perf || 1, 0.92);
        r.cond = 1; r._c = 1;
        continue;
      }
      const k = kindOf(bd, e), U = unitsOf(co, id);
      U.forEach(u => {
        if (u.down > 0) { u.down = Math.max(0, u.down - 7); return; }
        u.tc = clamp(u.tc - 0.0012 * mm * (u.rel || 1) * (0.4 + util) + (co.maint === 2 ? 0.0009 : 0), 0.05, 1);
        if (!open) return;
        const age = GY() - (u.yr || GY());
        const p = 0.0035 * (1 + 6 * Math.pow(1 - u.tc, 2)) * (u.rel || 1) * (u.kr ? 0.6 : 1 + Math.max(0, age - 5) * 0.08);
        if (Z() < p) ev.push(breakUnit(co, bd, e, k, u));
      });
      syncCond(co, id);
    }
    co.veh.forEach(v => {
      if (v.down > 0) { v.down = Math.max(0, v.down - 7); return; }
      if (!open) return;
      const age = GY() - (v.yr || GY());
      const p = 0.003 * (1 + 6 * Math.pow(1 - v.cond, 2)) * (v.rel || 1) * (v.kr ? 0.6 : 1 + Math.max(0, age - 6) * 0.07) * (1 + (v.km || 0) / 600000);
      if (Z() < p) {
        const e = bd.eq.find(x => x.id === v.eq) || { n: v.name, cost: v.cost };
        if (v.mode === 'lease') v.warr = Math.max(v.warr || 0, S.week + 1);
        ev.push(breakUnit(co, bd, e, 'veh', Object.assign(v, { nm: v.name }), v.model));
      }
    });
    const own = co.staff.filter(s => s.ownCar).length;
    if (own) payCo(co, KC(4500, co.country) * 12 / 52 * own, 'oth');
    if (bd.id === 'courier' || bd.id === 'trucking') {
      co.veh.forEach(v => {
        const e = bd.eq.find(x => x.id === v.eq);
        if (!e || !e.vo || !VEH[v.model] || !VEH[e.vo[0]]) return;
        const x = VEH[v.model][4] / Math.max(0.05, VEH[e.vo[0]][4]) - 1;
        if (x > 0) payCo(co, x * KC(450, co.country), 'oth');
      });
    }
    if (ev.length && open) {
      const m = co.mgr && S.npcs[co.mgr];
      info(m ? m.name : 'Workshop', ev.length > 1 ? ev.length + ' breakdowns at ' + co.name : 'Breakdown at ' + co.name, ev.join(' '), co.id, 'bad');
    }
  }

  /* ---------- how many are actually available (some may be in for repair) ---------- */
  addStep('eqN', 10, '---------- how many are actually available (some may be in for repair) ----------', (co, e, n) => {
    if (e.vo) co.veh.forEach(v => { if (v.eq === e.id && v.down > 0) n -= Math.min(1, v.down / 7); });
    else ((co.units && co.units[e.id]) || []).forEach(u => { if (u.down > 0) n -= Math.min(1, u.down / 7); });
    return Math.max(0, n);
  });

  /* ---------- capacity: personal items limit the people who need them ---------- */
  function fleetEff(co, e) {
    const vs = co.veh.filter(v => v.eq === e.id && VEH[v.model]);
    if (!vs.length || !VEH[e.vo[0]]) return 1;
    return clamp(mean(vs, v => VEH[v.model][5]) / VEH[e.vo[0]][5], 0.75, 1.5);
  }
  addStep('capacity.core', 10, 'equipment each person needs', (co, bd, res) => { adjCap(co, bd, res); });
  function adjCap(co, bd, res) {
    const parts = res.parts;
    let changed = false;
    const roleParts = roles => parts.filter(p => p.kind === 'staff' && (roles[0] === '*' || roles.some(r => p.k === 'role:' + r)));
    bd.eq.forEach(e => {
      const rl = ruleOf(bd, e);
      if (!rl) return;
      const k = 'eq:' + e.id, i = parts.findIndex(p => p.k === k);
      const need = needOf(co, bd, e);
      if (need <= 0) {
        if (i >= 0) { parts.splice(i, 1); changed = true; }
        return;
      }
      const rp = roleParts(rl[0]);
      if (!rp.length) return;
      const base = Math.min.apply(null, rp.map(p => p.cap));
      const have = eqN(co, e), cond = eqCondOf(co, e), frac = Math.min(1, have / need);
      const gate = e.fl.indexOf('r') >= 0 && have < 0.01;
      const eff = e.vo && (bd.id === 'courier' || bd.id === 'trucking') ? fleetEff(co, e) : 1;
      const condF = cond >= 0.6 ? 1.002 : 0.7 + 0.5 * cond;
      const cap = gate ? 0 : base * (frac + (1 - frac) * rl[2]) * condF * eff;
      const part = { k, label: e.n + (gate ? ' (required)' : ''), have: Math.round(have * 10) / 10, need, cap, capPer: base / need, kind: gate ? 'gate' : 'equip' };
      if (i >= 0) parts[i] = part; else parts.push(part);
      if (eff !== 1) rp.forEach(p => { p.cap *= eff; });
      changed = true;
    });
    if (!changed) return;
    const over = Math.max(0, (co.ohrs - 40) / 40);
    const mult = knobFx(co, 'k') * modProd(co, 'cap') * (over > 0 ? 1 + over * 0.2 : 1);
    let cap = Infinity, bot = null;
    parts.forEach(p => { if (p.cap < cap) { cap = p.cap; bot = p; } });
    if (!isFinite(cap)) cap = bd.capD;
    res.cap = Math.max(0, cap * mult);
    res.bot = bot;
  }

  /* ---------- demand: taxi classes, nice cars for sales people ---------- */
  function taxiClass(co) {
    const vs = co.veh.filter(v => v.eq === 'car');
    return vs.length ? mean(vs, v => TCLS[v.model] || 0) : 0;
  }
  R6.taxiClass = taxiClass;
  addStep('demand', 10, 'taxi classes and cars for sales people', (co, bd, r) => {
    let f = 1;
    if (bd.id === 'taxi' && co.veh.length) {
      const cls = taxiClass(co), pm = priceMult(co), a = 0.12 * cls;
      f = 1 + 0.07 * cls;
      if (pm > 1) {
        f *= Math.pow(Math.min(pm, 1 + a), bd.ela * 0.8);
        if (pm > 1 + a + 0.25) f *= Math.pow((1 + a + 0.25) / pm, 2);
      }
    }
    if (bd.id === 'estate' || bd.id === 'cardealer') {
      const vs = co.veh.filter(v => v.model === 'car_lux');
      if (co.veh.length) f *= 1 + 0.05 * vs.length / co.veh.length;
    }
    if (f !== 1) {
      r.D *= f;
      r.parts.choices = (r.parts.choices || 1) * f;
    }
  });

  /* ---------- selling one unit ---------- */
  function sellUnit(co, id, uidv) {
    const r = co.eq[id], U = unitsOf(co, id), i = U.findIndex(u => u.u === uidv);
    if (!r || i < 0) return 0;
    const bvU = r.bv / Math.max(1, r.n), cU = r.cost / Math.max(1, r.n);
    const val = Math.round(bvU * 0.7 * (0.6 + 0.4 * seen(U[i])));
    U.splice(i, 1);
    r.n -= 1; r.bv -= bvU; r.cost -= cU;
    if (r.n <= 0) { delete co.eq[id]; delete co.units[id]; } else syncCond(co, id);
    if (val) coIn(co, val, null, 'Sold used ' + BD[co.type].eq.find(x => x.id === id).n);
    return val;
  }
  R6.sellUnit = sellUnit;

  /* ======================= UI ======================= */
  const P = o => esc(JSON.stringify(o));
  const ptab = (items, cur, act, extra) => '<div class="ptabs">' + items.map(x => '<button class="' + (cur === x[0] ? 'on' : '') + '" data-a="' + act + '" data-p="' + P(Object.assign({ v: x[0] }, extra || {})) + '">' + x[1] + '</button>').join('') + '</div>';
  const pillp = (t, c) => '<span class="pill ' + (c || '') + '">' + t + '</span>';
  const warrTxt = u => u.src === 'lease' || u.mode === 'lease' ? 'Service included in lease' : u.warr && S.week < u.warr ? 'Warranty to ' + monthStr(u.warr) : u.src === 'used' ? 'Sold as seen, no warranty' : 'Warranty ended';
  const downTxt = u => u.down > 0 ? '<span class="neg">In repair · ' + u.down + ' days</span>' : '';
  const shopGo = (co, e, t, extra) => P({ n: 'shop', p: Object.assign({ id: co.id, e: e.id, t }, extra || {}) });

  function eqUI(co, bd) {
    const hasV = bd.eq.some(e => e.vo), hasS = bd.eq.some(e => !e.vo && kindOf(bd, e) === 'soft');
    const tabs = [['need', 'Needed'], ['own', 'Owned']].concat(hasV ? [['veh', 'Fleet']] : []).concat(hasS ? [['soft', 'Software']] : []).concat([['place', 'Premises']]);
    let t = ui.eqt;
    if (!tabs.some(x => x[0] === t)) t = 'need';
    let h = ptab(tabs, t, 'eqtab');
    if (t === 'need') h += needTab(co, bd);
    else if (t === 'own') h += ownTab(co, bd);
    else if (t === 'veh') h += vehTab(co, bd);
    else if (t === 'soft') h += softTab(co, bd);
    else h += placeTab(co, bd) + (CT.famAssets ? CT.famAssets(co, bd) : '');
    return h;
  }
  ACT.eqtab = p => { ui.eqt = p.v; render(); };
  CT.eq = pipeView('CT.eq:2', CT.eq, 2); /* CT.eq: routes, the screen, then the steps below and in later files */
  addStep('CT.eq:2.route', 10, 'realistic buying: the equipment screen (clubs keep the old one)', (co, bd) => bd.fam === 'club' || !bd.eq.length ? undefined : eqUI(co, bd));
  function fromPrice(co, bd, e) {
    if (e.vo) return Math.min.apply(null, e.vo.filter(m => VEH[m]).map(m => rnl(VEH[m][1] * Math.pow(1 + S.econ.infl, S.week / 52) * Math.min.apply(null, vehCat(m).map(c => c.f)), 1000)));
    const cat = eqCat(co.type, e.id, brandN(co), co.country);
    return Math.min.apply(null, cat.map(c => eqPrice(co, e, null, c)));
  }
  function needCard(co, bd, e) {
    const k = kindOf(bd, e), have = eqCount(co, e.id), need = needOf(co, bd, e), rl = ruleOf(bd, e);
    const flags = [e.fl.indexOf('r') >= 0 ? 'Required' : '', e.fl.indexOf('c') >= 0 ? 'More capacity' : '', e.fl.indexOf('q') >= 0 ? 'Better quality' : ''].filter(Boolean).join(' · ');
    const sm = k === 'soft' ? softMode(co, e) : null;
    let pr;
    if (sm === 'sub') pr = 'from ' + mshort(subFee(co, e, eqDefault(co.type, e.id), 0)) + '/mo';
    else pr = 'from ' + mshort(fromPrice(co, bd, e));
    let h = '<div class="card eqc"><div class="cchd">' + R6.picEq(bd, e) + '<span class="ctext"><b class="wrap">' + esc(e.n) + '</b><small>' + (need ? have + ' of ' + need + (rl ? ' · ' + perText(rl) : ' needed') : flags || KINDN[k]) + '</small></span>' + pillp(pr) + '</div>';
    if (!e.vo && k !== 'soft' && k !== 'svc') {
      const cat = eqCat(co.type, e.id, brandN(co), co.country);
      [0, 1, 2].forEach(c => {
        const xs = cat.filter(x => x.cls === c);
        if (!xs.length) return;
        const best = xs.reduce((a, b) => eqPrice(co, e, null, a) <= eqPrice(co, e, null, b) ? a : b);
        h += row(CLASS_N[c], money(eqPrice(co, e, null, best)) + ' · output ' + (best.perf >= 1 ? '+' : '') + Math.round((best.perf - 1) * 100) + '%');
      });
      h += row('Lifetime', 'About ' + e.life + (e.life === 1 ? ' year' : ' years')) + row('Warranty, new', warrY(k, e, 1, null, fromPrice(co, bd, e), co.country) + ' yr · premium ' + warrY(k, e, 2, null, fromPrice(co, bd, e) * 1.4, co.country) + ' yr');
      h += '<div class="chips">' + [0, 1, 2].map(c => '<button class="btn chip" data-a="go" data-p="' + shopGo(co, e, 'new', { cls: c }) + '">' + CLASS_N[c] + '</button>').join('') + (usedOk(e) || k === 'tool' || k === 'it' || k === 'furn' ? '<button class="btn chip" data-a="go" data-p="' + shopGo(co, e, 'used') + '">Used</button>' : '') + (leaseOk(co, e, fromPrice(co, bd, e)) ? '<button class="btn chip" data-a="go" data-p="' + shopGo(co, e, 'lease') + '">Lease</button>' : '') + '</div>';
    } else if (e.vo) {
      h += row('Lifetime', 'About ' + e.life + ' years') + (rl ? row('Rule of thumb', capF2(perText(rl))) : '');
      h += '<div class="chips">' + btn('New', 'go', { n: 'shop', p: { id: co.id, e: e.id, t: 'new' } }, 'chip') + btn('Used', 'go', { n: 'shop', p: { id: co.id, e: e.id, t: 'used' } }, 'chip') + btn('Lease', 'go', { n: 'shop', p: { id: co.id, e: e.id, t: 'lease' } }, 'chip') + '</div>';
    } else {
      h += row('How it is sold', sm === 'sub' ? 'Subscription only, three plans' : sm === 'once' ? 'One-time licence, you own it' : k === 'svc' ? 'One-off job' : 'Licence up front, then yearly updates') + '<div class="chips">' + btn(sm === 'sub' ? 'See plans' : 'Choose a supplier', 'go', { n: 'shop', p: { id: co.id, e: e.id, t: 'new' } }, 'chip primary') + '</div>';
    }
    return h + '</div>';
  }
  const capF2 = s => String(s).replace(/^./, c => c.toUpperCase());
  function healthCard(co, bd) {
    const vals = [];
    for (const id in co.eq) (co.units && co.units[id] || []).forEach(u => vals.push(seen(u)));
    co.veh.forEach(v => vals.push(seen(v)));
    if (!vals.length) return '';
    const hp = Math.round(mean(vals, x => x) * 100);
    return '<h2 class="sec">Condition</h2><div class="card"><div class="kv"><span>Equipment health, as far as you can tell</span><b class="' + (hp >= 75 ? 'pos' : hp >= 55 ? 'amb' : 'neg') + '">' + hp + '%</b></div>' + bar(hp, hp >= 75 ? 'var(--green)' : hp >= 55 ? 'var(--amber)' : 'var(--red)') + '<span class="tipt">Old equipment breaks more often. Under warranty the maker repairs it for free, but it is away for days. Servicing costs little; replacing costs a lot.</span><div class="kv"><span>Maintenance</span><b></b></div>' + chips([[0, 'Minimal'], [1, 'Normal'], [2, 'Thorough']], co.maint, 'maint', { id: co.id }) + '</div>';
  }
  function needTab(co, bd) {
    const L = bd.eq.map(e => ({ e, have: eqCount(co, e.id), need: needOf(co, bd, e) }));
    const miss = L.filter(x => x.e.fl.indexOf('r') >= 0 && x.have < 1);
    const short = L.filter(x => x.need > 0 && x.have < x.need);
    const up = L.filter(x => x.need === 0 && x.have === 0);
    const ok = L.filter(x => x.have > 0 && x.have >= x.need);
    let h = '';
    if (miss.length) h += '<div class="card sense"><b>' + (co.st === 'setup' ? 'You cannot open without ' : 'Work stops without ') + (miss.length > 1 ? 'these ' + miss.length + ' items' : esc(miss[0].e.n.toLowerCase())) + '</b><span class="tipt">Missing items block the work. Items people use themselves are needed once per person.</span></div>';
    else if (short.length) h += '<div class="card sense"><b>' + short.length + (short.length > 1 ? ' items are' : ' item is') + ' short for your team</b><span class="tipt">Someone without the right equipment works slower or not at all.</span></div>';
    h += short.map(x => needCard(co, bd, x.e)).join('');
    if (up.length) h += '<h2 class="sec">Upgrades</h2>' + up.map(x => needCard(co, bd, x.e)).join('');
    if (ok.length) h += '<h2 class="sec">In place</h2><div class="lrows">' + ok.map(x => '<button class="lrow" data-a="go" data-p="' + shopGo(co, x.e, 'new') + '">' + R6.picEq(bd, x.e) + '<span class="ctext"><b>' + esc(x.e.n) + '</b><small>' + x.have + (x.need ? ' of ' + x.need : '') + ' · ' + esc(KINDN[kindOf(bd, x.e)]) + '</small></span>' + pillp('Owned', 'grn') + '</button>').join('') + '</div>';
    return h + healthCard(co, bd);
  }
  function unitRow(co, bd, e, u) {
    const s = seen(u);
    return '<div class="lrow">' + R6.picEq(bd, e, u.u) + '<span class="ctext"><b>' + esc((u.nm || e.n) + (u.yr ? ' · ' + u.yr : '')) + '</b><small>' + (u.src === 'used' ? 'Bought used · ' : '') + esc(warrTxt(u)) + (u.down > 0 ? ' · ' : '') + downTxt(u) + '</small></span>' + pillp(wearOf(s), wearCls(s)) + btn('Sell', 'sellunit', { id: co.id, e: e.id, u: u.u }, 'chip') + '</div>';
  }
  function ownTab(co, bd) {
    let h = '';
    bd.eq.forEach(e => {
      if (e.vo) return;
      const r = co.eq[e.id], lease = co.lease[e.id] || 0;
      if (!r && !lease) return;
      const k = kindOf(bd, e);
      if (r && (r.sub || r.soft)) {
        h += '<div class="lrows"><button class="lrow" data-a="eqtab" data-p="' + P({ v: 'soft' }) + '">' + R6.picEq(bd, e) + '<span class="ctext"><b>' + esc(e.n) + '</b><small>' + (r.sub ? esc(r.sub.nm) + ' · ' + TIER[r.sub.tier][0] + ' plan · ' + mshort(r.sub.fee) + '/mo' : r.soft === 'svc' ? 'Done' : r.soft === 'upfront' ? 'Licence + updates ' + mshort(r.upd) + '/yr' : 'Licence owned' + ((r.perf || 1) < 0.95 ? ' · outdated' : '')) + '</small></span><i>›</i></button></div>';
        return;
      }
      const U = unitsOf(co, e.id);
      h += '<div class="sh"><h2 class="sec">' + esc(e.n) + '</h2><small>' + (r ? r.n : 0) + (lease ? ' + ' + lease + ' leased' : '') + '</small></div><div class="lrows">' + U.map(u => unitRow(co, bd, e, u)).join('') + (lease ? '<div class="lrow"><span class="lic">' + svg('doc', 18) + '</span><span class="ctext"><b>' + lease + ' on lease</b><small>' + mshort((co.eqL || {})[e.id] || 0) + ' a month · service included</small></span></div>' : '') + '</div>' +
        (r ? '<div class="chips">' + btn('Service all · ' + mshort(r.cost * 0.04 * (1 - fixDisc(co))), 'repaireq', { id: co.id, e: e.id }, 'chip') + btn('Buy more', 'go', { n: 'shop', p: { id: co.id, e: e.id, t: 'new' } }, 'chip') + btn('Sell all', 'selleq', { id: co.id, e: e.id }, 'chip ghost danger') + '</div>' : '');
    });
    if (co.veh.length) h += '<div class="lrows"><button class="lrow" data-a="eqtab" data-p="' + P({ v: 'veh' }) + '"><span class="lic">' + svg('truck', 20) + '</span><span class="ctext"><b>' + co.veh.length + (co.veh.length > 1 ? ' vehicles' : ' vehicle') + '</b><small>See the fleet</small></span><i>›</i></button></div>';
    return h || '<div class="calm">Nothing bought yet. Start under Needed.</div>';
  }
  const VCN = { car: 'Cars', van: 'Vans', boxvan: 'Moving vans', truck: 'Trucks', bus: 'Buses', bike: 'Bikes', scooter: 'Scooters', plant: 'Machines', crane: 'Cranes', ship: 'Ships', plane: 'Aircraft' };
  function vehRow(co, bd, v) {
    const s = seen(v);
    return '<div class="lrow">' + pic(vclass(v.model), v.id, vehOpt(v.model)) + '<span class="ctext"><b>' + esc(v.name) + '</b><small>' + ({ own: 'Owned', fin: 'Financed', lease: 'Leased ' + mshort(v.lease || 0) + '/mo' }[v.mode] || '') + ' · ' + Math.round((v.km || 0) / 1000) + ' 000 km · ' + esc(warrTxt(v)) + (v.down > 0 ? ' · ' : '') + downTxt(v) + '</small></span>' + pillp(wearOf(s), wearCls(s)) + btn(v.mode === 'lease' ? 'Return' : 'Sell', 'sellveh', { id: co.id, v: v.id }, 'chip') + '</div>';
  }
  const WHY = {
    estate: [['Showings', 'One car per agent'], ['Own car instead', 'You pay mileage'], ['A nice car', 'Clients notice']],
    construction: [['Crews', 'One van per 3 on site'], ['Buy new', 'A breakdown stops a whole crew'], ['Branding', 'Free marketing']],
    electrician: [['Each electrician', 'Own fitted van'], ['Tools and stock', 'Travel in the van']],
    plumber: [['Each plumber', 'Own fitted van'], ['Tools and stock', 'Travel in the van']],
    carclean: [['Mobile jobs', 'One van per 2 detailers'], ['Branding', 'Free marketing']],
    cleaning: [['Teams', 'One van per 3 cleaners'], ['Equipment', 'Goes with the team']],
    taxi: [['Each driver', 'One car'], ['Nicer cars', 'More riders, higher fares'], ['Too pricey', 'Riders switch away']],
    courier: [['Each courier', 'A van or a bike'], ['Bigger vans', 'More stops per day, more fuel'], ['Moving vans', 'House moves and bulky jobs']],
    trucking: [['Each driver', 'A tractor and a trailer'], ['Bigger trucks', 'Cost more, move more']],
    drivsk: [['Each instructor', 'Own dual-control car']]
  };
  function vehTab(co, bd) {
    let h = '';
    bd.eq.filter(e => e.vo).forEach(e => {
      const mine = co.veh.filter(v => v.eq === e.id), need = needOf(co, bd, e), rl = ruleOf(bd, e);
      h += '<div class="sh"><h2 class="sec">' + esc(e.n) + '</h2><small>' + mine.length + (need ? ' of ' + need : '') + '</small></div>';
      h += mine.length ? '<div class="lrows">' + mine.map(v => vehRow(co, bd, v)).join('') + '</div>' : '<div class="calm">No vehicles yet.</div>';
      h += '<div class="chips">' + btn('Buy new', 'go', { n: 'shop', p: { id: co.id, e: e.id, t: 'new' } }, 'chip primary') + btn('Buy used', 'go', { n: 'shop', p: { id: co.id, e: e.id, t: 'used' } }, 'chip') + btn('Lease', 'go', { n: 'shop', p: { id: co.id, e: e.id, t: 'lease' } }, 'chip') + '</div>';
    });
    const why = WHY[bd.id];
    if (why) h += '<h2 class="sec">Why you need it</h2><div class="card">' + why.map(x => row(x[0], x[1])).join('') + (bd.id === 'taxi' && co.veh.length ? row('Your fleet class', TCN[Math.round(taxiClass(co))]) : '') + '</div>';
    if (bd.id === 'estate') {
      const ag = co.staff.filter(s => s.role === 'estate');
      if (ag.length) h += '<h2 class="sec">Agents and cars</h2><div class="lrows">' + ag.map(s => '<div class="lrow">' + faceAv(S.npcs[s.id]) + '<span class="ctext"><b>' + esc(S.npcs[s.id] ? S.npcs[s.id].name : 'Agent') + '</b><small>' + (s.ownCar ? 'Own car · you pay about ' + mshort(KC(4500, co.country)) + '/mo mileage' : 'Uses a company car') + '</small></span>' + btn(s.ownCar ? 'Give company car' : 'Own car + mileage', 'carallow', { id: co.id, s: s.id }, 'chip') + '</div>').join('') + '</div>';
    }
    return h + '<div class="card sense"><b>Cash, finance or lease</b><span class="tipt">Cash keeps you debt-free but drains the account. Finance builds ownership over 4–5 years. Leasing is a low monthly cost with service included, but you own nothing at the end.</span></div>';
  }
  ACT.carallow = p => {
    const co = getCo(p.id), s = co && co.staff.find(x => x.id === p.s);
    if (!s) return;
    s.ownCar = s.ownCar ? 0 : 1;
    save();
    render();
  };
  function planTiles(co, e, c, cur) {
    const rec = recTier(co);
    return '<div class="plans">' + TIER.map((t, i) => '<button class="plan' + (cur === i ? ' on' : '') + '" data-a="subpick" data-p="' + P({ id: co.id, e: e.id, t: i, c: c.i }) + '"><span>' + t[0] + (i === rec ? ' <i>fits</i>' : '') + '</span><b>' + mshort(subFee(co, e, c, i)) + '</b><small>/mo · ' + (t[1] > 1e8 ? 'any size' : 'up to ' + t[1] + ' users') + '</small></button>').join('') + '</div>';
  }
  function softTab(co, bd) {
    let h = '<p class="muted small">Small programs are bought once. Bigger systems cost more up front plus yearly updates. Some are only sold as a subscription, priced by how many people use them. You have ' + users(co) + (users(co) > 1 ? ' users.' : ' user.') + '</p>';
    bd.eq.filter(e => !e.vo && kindOf(bd, e) === 'soft').forEach(e => {
      const r = co.eq[e.id], sm = softMode(co, e);
      h += '<div class="card eqc"><div class="cchd">' + R6.picEq(bd, e) + '<span class="ctext"><b class="wrap">' + esc(e.n) + '</b><small>' + (sm === 'sub' ? 'Subscription only' : sm === 'once' ? 'One-time licence' : 'Licence up front + yearly updates') + (e.fl.indexOf('r') >= 0 ? ' · required' : '') + '</small></span>' + (r ? pillp(r.sub ? TIER[r.sub.tier][0] : 'Owned', 'grn') : '') + '</div>';
      if (sm === 'sub') {
        const c = r && r.sub ? eqCat(co.type, e.id, brandN(co), co.country)[r.sub.c] || eqDefault(co.type, e.id) : eqDefault(co.type, e.id);
        if (r && r.sub) h += row('Provider', esc(r.sub.nm)) + (users(co) > TIER[r.sub.tier][1] ? '<div class="note bad">More users than the plan allows. It runs slower until you upgrade.</div>' : '');
        h += planTiles(co, e, c, r && r.sub ? r.sub.tier : -1) + '<div class="chips">' + btn('Compare providers', 'go', { n: 'shop', p: { id: co.id, e: e.id, t: 'new' } }, 'chip') + (r && r.sub ? btn('Cancel', 'subcancel', { id: co.id, e: e.id }, 'chip ghost danger') : '') + '</div>';
      } else if (r) {
        h += row('Licence', esc(r.mods && r.mods[0] ? r.mods[0].nm : e.n)) + row('Bought', dateStr(r.ver || S.week)) + (sm === 'upfront' ? row('Updates', mshort(r.upd || 0) + ' a year') : row('Version', (r.perf || 1) < 0.95 ? '<span class="amb">Outdated, buy the new version</span>' : 'Current')) + ((r.perf || 1) < 0.95 ? btn('Buy the new version', 'go', { n: 'shop', p: { id: co.id, e: e.id, t: 'new' } }, 'chip primary') : '');
      } else {
        h += row('Price', 'from ' + money(fromPrice(co, bd, e)) + (sm === 'upfront' ? ' + 18% a year' : ' once')) + btn('Choose a licence', 'go', { n: 'shop', p: { id: co.id, e: e.id, t: 'new' } }, 'chip primary');
      }
      h += '</div>';
    });
    return h;
  }
  ACT.subpick = p => {
    const co = getCo(p.id), bd = BD[co.type], e = bd.eq.find(x => x.id === p.e), c = eqCat(co.type, e.id, brandN(co), co.country)[p.c] || eqDefault(co.type, e.id);
    const r = co.eq[e.id];
    if (r && r.sub && r.sub.tier === p.t && r.sub.c === c.i) return;
    confirmThen((r && r.sub ? 'Switch to ' : 'Subscribe to ') + TIER[p.t][0] + '?', esc(c.brand + ' ' + c.model) + ' · ' + money(subFee(co, e, c, p.t)) + ' a month, paid monthly. Cancel any time.', 'Confirm', () => {
      if (res6(subscribe(co, e, p.t, c), 'Subscribed.')) { save(); render(); }
    });
  };
  ACT.subcancel = p => {
    const co = getCo(p.id), e = BD[co.type].eq.find(x => x.id === p.e);
    confirmThen('Cancel ' + esc(e.n) + '?', 'It stops working right away.' + (e.fl.indexOf('r') >= 0 ? ' It is required, so work stops too.' : ''), 'Cancel plan', () => {
      delete co.eq[e.id];
      save();
      render();
    }, true);
  };
  const res6 = (r, ok) => r === 'ok' ? (toast(ok), true) : (toast(r === 'cash' ? 'Not enough cash.' : r === 'bad' ? 'Not possible.' : String(r), true), false);
  function placeTab(co, bd) {
    const Pm = co.prem;
    const home = bd.prem && bd.prem[0] === 'home';
    let h = '<div class="card"><div class="cchd">' + pic(home ? 'house' : 'building', co.id) + '<span class="ctext"><b>' + (Pm && Pm.m2 ? esc(PREM[Pm.kind][0]) : home ? 'Works from home' : 'No premises yet') + '</b><small>' + (Pm && Pm.m2 ? Pm.m2 + ' m² · ' + esc(cityOf(co.city).name) + (Pm.landlord ? ' · ' + esc(Pm.landlord) : '') : home ? 'No rent, no deposit' : esc(bd.prem && PREM[bd.prem[0]] ? PREM[bd.prem[0]][3] || '' : '')) + '</small></span>' + (Pm && Pm.m2 ? pillp(Pm.owned ? 'Owned' : mshort(Pm.rent * Pm.m2 / 12) + '/mo') : '') + '</div>';
    if (Pm && Pm.m2) {
      h += row(Pm.owned ? 'Value' : 'Rent per month', Pm.owned ? nok(Pm.val) : nok(Pm.rent * Pm.m2 / 12)) + (Pm.loan ? row('Mortgage', nok(Pm.loan)) : '') + (Pm.dep ? row('Deposit held', nok(Pm.dep)) : '');
      const cp = capacity(co, bd).parts.find(x => x.k === 'prem');
      if (cp) h += row('Space', cp.have + ' of ' + cp.need + ' m² needed' + (cp.have < cp.need ? ' <span class="neg">· too small</span>' : ''));
      if (Pm.loc) h += row('Location', isFoot(Pm.kind) ? (Pm.loc > 1.03 ? '<span class="pos">More passing trade</span>' : Pm.loc < 0.97 ? '<span class="amb">Less passing trade</span>' : 'Normal passing trade') : (Pm.loc < 0.97 ? '<span class="amb">Longer transport</span>' : 'Short transport'));
    }
    if (bd.prem && bd.prem[0] !== 'home' && bd.prem[0] !== 'none') h += btn(Pm && Pm.m2 ? 'Move or buy premises' : 'Find premises', 'premsheet', { id: co.id }, 'wide primary');
    h += '</div>';
    if (co.eq.fit) h += row('Fit-out (book value)', nok(co.eq.fit.bv));
    return h;
  }

  /* ---------- the shop ---------- */
  V.titles.shop = 'Shop';
  V.heads = V.heads || {};
  V.heads.shop = p => {
    const co = getCo(p.id), e = co && BD[co.type].eq.find(x => x.id === p.e);
    const k = e ? kindOf(BD[co.type], e) : '';
    return { t: k === 'veh' ? 'Vehicles' : k === 'soft' ? 'Software' : 'Equipment shop', sub: e ? esc(e.n) + ' · for ' + esc(co.name) : '' };
  };
  function shopState(co, e, p) {
    const key = co.id + ':' + e.id;
    let s = ui.shop;
    if (!s || s.key !== key || (p.t && s.t0 !== p.t) || (p.cls != null && s.cls0 !== p.cls)) s = ui.shop = { key, cid: co.id, eid: e.id, t: p.t || 'new', t0: p.t, cls: p.cls != null ? p.cls : null, cls0: p.cls, sel: null, q: null, pay: 'cash', vc: null, tier: null };
    return s;
  }
  V.shop = function (p) {
    const co = getCo(p.id);
    if (!co) return '<div class="calm">Company not found.</div>';
    const bd = BD[co.type], e = bd.eq.find(x => x.id === p.e);
    if (!e) return '<div class="calm">Not sold here.</div>';
    const k = kindOf(bd, e), st = shopState(co, e, p);
    const unit0 = fromPrice(co, bd, e);
    const modes = [['new', k === 'soft' ? (softMode(co, e) === 'sub' ? 'Plans' : 'Licences') : 'New']];
    if (e.vo || (k !== 'soft' && k !== 'svc')) modes.push(['used', 'Used']);
    if (leaseOk(co, e, unit0)) modes.push(['lease', 'Lease']);
    if (!modes.some(m => m[0] === st.t)) st.t = 'new';
    let h = modes.length > 1 ? ptab(modes, st.t, 'shopt') : '';
    const have = eqCount(co, e.id), need = needOf(co, bd, e);
    h += '<div class="tri"><div><span>You have</span><b>' + have + '</b></div><div><span>Needed</span><b>' + (need || '–') + '</b></div><div><span>Cash</span><b class="' + sgn(co.cash) + '">' + mshort(co.cash) + '</b></div></div>';
    if (e.vo) h += shopVeh(co, bd, e, st);
    else if (k === 'soft' && softMode(co, e) === 'sub') h += shopSub(co, bd, e, st);
    else h += shopEq(co, bd, e, k, st, Math.max(1, need - have));
    return h;
  };
  ACT.shopt = p => { ui.shop.t = p.v; ui.shop.sel = null; render(true); };
  ACT.shopsel = p => { ui.shop.sel = p.i; if (p.tier != null) ui.shop.tier = p.tier; render(); };
  ACT.shopcls = p => { ui.shop.cls = ui.shop.cls === p.v ? null : p.v; ui.shop.sel = null; render(); };
  ACT.shopvc = p => { ui.shop.vc = ui.shop.vc === p.v ? null : p.v; ui.shop.sel = null; render(); };
  ACT.shoppay = p => { ui.shop.pay = p.v; render(); };
  ACT.shopq = p => { ui.shop.q = Math.max(1, Math.min(50, (ui.shop.q || p.base || 1) + p.d)); render(); };
  const radio = on => '<span class="radio' + (on ? ' on' : '') + '"></span>';
  function payBox(co, opts, st, total, label, extra) {
    if (!opts.some(o => o[0] === st.pay)) st.pay = opts[0][0];
    return '<div class="card sense paybox"><b>How to pay</b>' + (opts.length > 1 ? chips(opts, st.pay, 'shoppay') : '') + (extra || '') + '<div class="kv"><span>Total</span><b>' + total + '</b></div></div>' + btn(label, 'shopbuy', undefined, 'primary wide go');
  }
  function shopEq(co, bd, e, k, st, short) {
    let h = '';
    if (st.t === 'used') {
      const L = usedEqList(co, bd, e);
      h += '<p class="muted small">Second-hand, sold as seen: no warranty and no guarantees. The seller describes the wear. It is not always the whole truth.</p>';
      if (!L.length) return h + '<div class="calm">Nothing for sale this month. New listings appear next month.</div>';
      h += L.map(x => '<button class="card opt2' + (st.sel === x.i ? ' on' : '') + '" data-a="shopsel" data-p="' + P({ i: x.i }) + '"><div class="cchd">' + R6.picEq(bd, e, x.id) + '<span class="ctext"><b>' + esc(x.nm) + ' · ' + x.yr + '</b><small>' + esc(x.seller) + ' · ' + x.age + (x.age > 1 ? ' years old' : ' year old') + '</small></span>' + pillp(mshort(x.price), 'grn') + '</div><div class="kv"><span>Wear</span><b>' + pillp(wearOf(x.vis), wearCls(x.vis)) + '</b></div><div class="kv"><span>Seller says</span><b>“' + esc(x.says) + '”</b></div>' + (x.kr ? '<div class="kv"><span>Model</span><b class="pos">Known to last</b></div>' : '') + '<div class="kv"><span>Warranty</span><b class="amb">None</b></div></button>').join('');
      const sel = L.find(x => x.i === st.sel);
      return h + (sel ? payBox(co, [['cash', 'Cash']].concat(sel.price >= KC(30000, co.country) ? [['finance', 'Finance']] : []), st, st.pay === 'finance' ? money(sel.price * 0.2) + ' down' : money(sel.price), 'Buy used · ' + mshort(sel.price)) : '');
    }
    const cat = eqCat(co.type, e.id, brandN(co), co.country);
    const lease = st.t === 'lease';
    h += '<div class="chips">' + [0, 1, 2].map(c => '<button class="btn chip' + (st.cls === c ? ' primary' : '') + '" data-a="shopcls" data-p="' + P({ v: c }) + '">' + CLASS_N[c] + '</button>').join('') + '</div>';
    const list = cat.filter(c => st.cls == null || c.cls === st.cls);
    h += list.map(c => {
      const pr = eqPrice(co, e, null, c), wy = warrY(k, e, c.cls, null, pr, co.country);
      return '<button class="card opt2' + (st.sel === c.i ? ' on' : '') + '" data-a="shopsel" data-p="' + P({ i: c.i }) + '"><div class="cchd">' + R6.picEq(bd, e, c.brand + c.model) + '<span class="ctext"><b>' + esc(c.brand + ' ' + c.model) + '</b><small>' + GY() + ' model · ' + esc(c.tier) + ' · ' + esc(c.seller || '') + '</small></span>' + pillp(lease ? mshort(pr * 0.0235) + '/mo' : mshort(pr)) + '</div><div class="kv"><span>Buyers say</span><b>' + stars(c.rating, c.reviews) + '</b></div><div class="kv"><span>Output · reliability</span><b>' + (c.perf >= 1 ? '+' : '') + Math.round((c.perf - 1) * 100) + '% · ' + (c.rel < 0.85 ? 'Excellent' : c.rel < 1.05 ? 'Good' : c.rel < 1.25 ? 'Fair' : 'Poor') + '</b></div><div class="kv"><span>' + (lease ? 'Lease' : 'Warranty') + '</span><b>' + (lease ? '3 years, service included' : k === 'soft' ? (softMode(co, e) === 'upfront' ? 'Updates 18% a year' : 'One-time, updates 1 year') : wy ? wy + (wy > 1 ? ' years' : ' year') + ' from the maker' : 'None') + '</b></div></button>';
    }).join('');
    const sel = cat.find(c => c.i === st.sel);
    if (!sel) return h;
    const one = k === 'soft' || k === 'svc';
    const q = one ? 1 : (st.q || short);
    const unit = eqPrice(co, e, null, sel);
    const qty = one ? '' : '<div class="kv"><span>Quantity</span><b class="qty">' + btn('−', 'shopq', { d: -1, base: q }, 'chip') + '<span>' + q + '</span>' + btn('+', 'shopq', { d: 1, base: q }, 'chip') + '</b></div>';
    if (lease) return h + payBox(co, [['lease', 'Lease']], st, money(unit * 0.0235 * q) + '/mo', 'Lease ' + q + ' · ' + mshort(unit * 0.0235 * q) + '/mo', qty);
    const opts = [['cash', 'Cash']].concat(finOk(co, e, unit * q) ? [['finance', 'Finance']] : []);
    return h + payBox(co, opts, st, st.pay === 'finance' ? money(unit * q * 0.2) + ' down, loan for the rest' : money(unit * q), (one ? 'Buy licence · ' : 'Buy ' + q + ' · ') + mshort(unit * q), qty);
  }
  function shopSub(co, bd, e, st) {
    const cat = eqCat(co.type, e.id, brandN(co), co.country).filter(c => c.cls === 1);
    const r = co.eq[e.id];
    let h = '<p class="muted small">Sold only as a subscription. Pick a provider and a plan. Plans are priced by users: you have ' + users(co) + '.</p>';
    h += cat.map(c => '<div class="card' + (st.sel === c.i ? ' on' : '') + '"><div class="cchd">' + R6.picEq(bd, e, c.brand) + '<span class="ctext"><b>' + esc(c.brand + ' ' + c.model) + '</b><small>' + stars(c.rating, c.reviews) + '</small></span>' + (r && r.sub && r.sub.c === c.i ? pillp('Current', 'grn') : '') + '</div>' + planTiles(co, e, c, r && r.sub && r.sub.c === c.i ? r.sub.tier : -1) + '</div>').join('');
    return h;
  }
  function vehPrices(co, m, c) {
    const base = rnl(VEH[m][1] * Math.pow(1 + S.econ.infl, S.week / 52) * c.f, 1000);
    return { base, fin: annuity(base * 0.8, policy() + creditMargin() + 0.015, 60), lease: Math.round(base * 0.0215), keep: /ev|electric/.test(m) ? 35 : m === 'car_lux' || m === 'taxi_prm' ? 38 : vclass(m) === 'truck' ? 34 : 42 };
  }
  function shopVeh(co, bd, e, st) {
    let h = '';
    const isTaxi = bd.id === 'taxi' && e.id === 'car';
    const cls = m => isTaxi ? TCN[TCLS[m] || 0] : VCN[vclass(m)];
    const groups = e.vo.filter(m => VEH[m]).map(cls).filter((x, i, a) => a.indexOf(x) === i);
    if (groups.length > 1) h += '<div class="chips">' + groups.map(g => '<button class="btn chip' + (st.vc === g ? ' primary' : '') + '" data-a="shopvc" data-p="' + P({ v: g }) + '">' + g + '</button>').join('') + '</div>';
    const models = e.vo.filter(m => VEH[m] && (!st.vc || cls(m) === st.vc));
    if (isTaxi) h += '<p class="muted small">Nicer cars bring more riders and let you charge more, up to a point. Price far above the class and riders leave anyway.</p>';
    if (st.t === 'used') {
      const L = usedVehList(co, bd, e).filter(x => models.indexOf(x.m) >= 0);
      h += '<p class="muted small">Used vehicles are sold as seen, with no warranty. Some hide faults under a fresh polish. Known-to-last models break less even when old.</p>';
      if (!L.length) return h + '<div class="calm">Nothing matching for sale this month.</div>';
      h += L.map(x => '<button class="card opt2' + (st.sel === x.i ? ' on' : '') + '" data-a="shopsel" data-p="' + P({ i: x.i }) + '"><div class="cchd">' + pic(vclass(x.m), x.id, vehOpt(x.m)) + '<span class="ctext"><b>' + esc(x.nm) + ', used</b><small>' + x.yr + ' · ' + x.age + (x.age > 1 ? ' years' : ' year') + ' · ' + npad(x.km) + ' km · ' + esc(VEH[x.m][0]) + '</small></span>' + pillp(mshort(x.price), 'grn') + '</div><div class="kv"><span>Wear</span><b>' + pillp(wearOf(x.vis), wearCls(x.vis)) + '</b></div><div class="kv"><span>Fuel and service</span><b class="' + (x.fuel === 'Higher' ? 'amb' : '') + '">' + x.fuel + '</b></div><div class="kv"><span>Breakdown risk, your guess</span><b class="' + (x.risk === 'High' ? 'neg' : x.risk === 'Medium' ? 'amb' : 'pos') + '">' + x.risk + '</b></div><div class="kv"><span>Seller says</span><b>“' + esc(x.says) + '”</b></div>' + (x.kr ? '<div class="kv"><span>Model</span><b class="pos">Known to last</b></div>' : '') + (isTaxi ? '<div class="kv"><span>Class</span><b>' + TCN[TCLS[x.m] || 0] + '</b></div>' : '') + '</button>').join('');
      const sel = L.find(x => x.i === st.sel);
      return h + (sel ? payBox(co, [['cash', 'Cash'], ['finance', 'Finance']], st, st.pay === 'finance' ? money(sel.price * 0.2) + ' down' : money(sel.price), 'Buy used · ' + mshort(sel.price)) : '');
    }
    const lease = st.t === 'lease';
    const opts = [];
    models.forEach(m => vehCat(m).forEach(c => opts.push({ m, c, id: m + ':' + c.i })));
    h += opts.map(o => {
      const pr = vehPrices(co, o.m, o.c), wy = warrY('veh', null, 1, o.m, pr.base, co.country);
      return '<button class="card opt2' + (st.sel === o.id ? ' on' : '') + '" data-a="shopsel" data-p="' + P({ i: o.id }) + '"><div class="cchd">' + pic(vclass(o.m), o.id, vehOpt(o.m)) + '<span class="ctext"><b>' + esc(o.c.brand + ' ' + o.c.model) + ', new ' + GY() + '</b><small>' + esc(VEH[o.m][0]) + ' · ' + stars(o.c.rating, o.c.reviews) + '</small></span>' + pillp(lease ? mshort(pr.lease) + '/mo' : mshort(pr.base)) + '</div>' + (lease ? row('Lease, 3 years', money(pr.lease) + '/mo') + row('Included', 'Service and repairs') : row('Pay in cash', money(pr.base)) + row('Finance, 5 years', money(pr.fin) + '/mo') + row('Lease, 3 years', money(pr.lease) + '/mo') + row('Value after 5 years', '<span class="amb">About ' + pr.keep + '%</span>') + row('Warranty', wy + ' years')) + (isTaxi ? row('Class', TCN[TCLS[o.m] || 0]) : '') + '</button>';
    }).join('');
    const sel = opts.find(o => o.id === st.sel);
    if (!sel) return h;
    const pr = vehPrices(co, sel.m, sel.c);
    if (lease) return h + payBox(co, [['lease', 'Lease']], st, money(pr.lease) + '/mo', 'Lease · ' + mshort(pr.lease) + '/mo');
    return h + payBox(co, [['cash', 'Cash'], ['finance', 'Finance']], st, st.pay === 'finance' ? money(pr.base * 0.2) + ' down, then ' + money(pr.fin) + '/mo' : money(pr.base), 'Buy new · ' + mshort(pr.base));
  }
  ACT.shopbuy = () => {
    const st = ui.shop;
    if (!st) return;
    const co = getCo(st.cid);
    if (!co) return;
    const bd = BD[co.type], e = bd.eq.find(x => x.id === st.eid), k = kindOf(bd, e);
    let r;
    if (e.vo) {
      if (st.t === 'used') {
        const L = usedVehList(co, bd, e).find(x => x.i === st.sel);
        if (!L) return;
        r = buyUsedVeh(co, e, L, st.pay);
      } else {
        const [m, ci] = String(st.sel).split(':');
        const c = vehCat(m)[+ci];
        r = buyVeh(co, e.id, m, st.t === 'lease' ? 'lease' : st.pay === 'finance' ? 'finance' : 'new', c);
      }
    } else if (st.t === 'used') {
      const L = usedEqList(co, bd, e).find(x => x.i === st.sel);
      if (!L) return;
      r = buyUsedEq(co, bd, e, L, st.pay);
    } else {
      const c = eqCat(co.type, e.id, brandN(co), co.country).find(x => x.i === st.sel);
      if (!c) return;
      const one = k === 'soft' || k === 'svc';
      if (one && co.eq[e.id] && !co.eq[e.id].sub) {
        const old = co.eq[e.id];
        const pr = eqPrice(co, e, null, c);
        if (co.cash < pr) { toast('Not enough cash.', true); return; }
        payCo(co, pr, null, 'New version: ' + c.brand + ' ' + c.model);
        old.ver = S.week; old.perf = c.perf; old.cost += pr; old.bv += pr; old.mods = [{ nm: c.brand + ' ' + c.model, n: 1, rt: c.rating }];
        r = 'ok';
      } else r = buyEq(co, e.id, one ? 1 : (st.q || Math.max(1, needOf(co, bd, e) - eqCount(co, e.id))), st.t === 'lease' ? 'lease' : st.pay === 'finance' ? 'finance' : 'new', c);
    }
    if (res6(r, st.t === 'lease' ? 'Lease signed.' : 'Bought.')) {
      ui.shop = null;
      save();
      U.back();
    }
  };
  ACT.sellunit = p => {
    const co = getCo(p.id);
    confirmThen('Sell this one?', 'Used equipment sells for well under what you paid, less if it looks worn.', 'Sell', () => {
      const v = sellUnit(co, p.e, p.u);
      save();
      render();
      if (v) toast('Sold for ' + money(v) + '.');
    });
  };

  /* ---------- hiring: work car or own car with mileage ---------- */
  window.carOffer = function (co, n) {
    const bd = BD[co.type];
    const e = bd.eq.find(x => x.vo && ruleOf(bd, x));
    if (!e || bd.id !== 'estate' || n.role !== 'estate') return '';
    ui.carc = ui.carc || {};
    const cur = ui.carc[n.id] || 'co';
    return '<div class="card"><div class="kv"><span>Work car</span><b></b></div>' + chips([['co', 'Company car'], ['own', 'Own car + mileage']], cur, 'carc', { n: n.id }) + '<span class="tipt">' + (cur === 'co' ? 'You provide a car for showings. Agents like it, and a nice one impresses clients. It needs one more car in the fleet.' : 'They use their own car. You pay mileage, about ' + money(KC(4500, co.country)) + ' a month. No car to buy.') + '</span></div>';
  };
  ACT.carc = p => {
    ui.carc = ui.carc || {};
    ui.carc[p.n] = p.v;
    render();
  };
  addStep('ACT.offer.around', 30, 'realistic_buying ACT.offer', (p, next) => {
    next();
    const n = S.npcs[p.n];
    if (n && n.hired && ui.carc && ui.carc[n.id] === 'own') {
      const co = getCo(p.id), s = co && co.staff.find(x => x.id === n.id);
      if (s) s.ownCar = 1;
    }
  });
}


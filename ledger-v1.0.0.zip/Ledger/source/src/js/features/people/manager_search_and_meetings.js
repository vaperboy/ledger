/* ===== Round 5a: manager search by type, interviews, moving managers, meetings with real proposals ===== */
  const fmtPct = x => (x % 1 ? x.toFixed(1) : String(x));
  const capF = s => String(s || '').replace(/^./, c => c.toUpperCase());
  const MT_TIER = { young: 'Early career', mid: 'Mid-career', senior: 'Senior' };
  function typeFit(co, t) {
    const bd = BD[co.type];
    return t === bd.mgr ? 1 : t === 'gen' ? 0.85 : (MGR_FIT[t] || 0.6) * 0.9;
  }
  ACT.mtypeset = p => {
    ui.mtype = ui.mtype || {};
    ui.mtype[p.id] = p.v;
    render();
  };
  ACT.mgrsearch = p => {
    const co = getCo(p.id), bd = BD[co.type];
    const t = (ui.mtype && ui.mtype[co.id]) || bd.mgr;
    if (co.cash < KC(15000) && liquid() < KC(15000)) {
      toast('Not enough cash for the search.', true);
      return;
    }
    payCo(co, KC(15000), 'oth', 'Executive search');
    ui.mgrC = ui.mgrC || {};
    ui.mgrC[co.id] = [genManager(co, t).id, genManager(co, t).id, genManager(co, t).id, genManager(co, t === bd.mgr ? 'gen' : bd.mgr).id];
    ui.mcand = null;
    save();
    render();
  };
  function mgrStyle(n) {
    const q = n.q || {};
    if (Object.keys(q).length < 2) return null;
    const v = k => (q[k] != null ? q[k] : 55);
    return [
      ['Hiring', v('people') >= 70 && v('sales') >= 60 ? 'Quick' : v('ops') >= 65 ? 'Measured' : 'Slow'],
      ['Spending', v('fin') >= 68 ? 'Careful' : v('fin') < 45 ? 'Loose' : 'Balanced'],
      ['Pricing', v('sales') >= 72 ? 'Pushes prices up' : v('fin') >= 65 ? 'Holds prices' : 'Discounts to win'],
      ['Rules', v('risk') >= 65 ? 'By the book' : v('risk') < 45 ? 'Cuts corners' : 'Pragmatic']
    ];
  }
  window.R5m = { typeFit, mgrStyle, MT_TIER }; /* the hiring screen (ui/screens/hiring.js) */
  ACT.mcandopen = p => {
    ui.mcand = p.n;
    render(true);
  };
  ACT.mcandback = () => {
    ui.mcand = null;
    render(true);
  };

  /* moving a manager: the same kind of business keeps all experience, the same field costs a little, another field more */
  function moveLoss(a, b) {
    if (a.type === b.type) return { f: 1, t: 'Keeps experience', cls: 'green' };
    if (BD[a.type].fam === BD[b.type].fam) return { f: 0.9, t: '−10% experience', cls: 'amber' };
    return { f: 0.7, t: '−30% experience', cls: 'red' };
  }
  ACT.mgrmove = p => {
    const co = getCo(p.id), n = co && S.npcs[co.mgr];
    if (!n) return;
    const tg = live().filter(c => c.id !== co.id && !c.mgr && BD[c.type].fam !== 'club');
    openSheet('<h2>Move ' + esc(n.name) + '</h2><p class="muted small">Same kind of business keeps all experience. Another business in the same field costs a little; a different field costs more.</p><div class="lrows">' + (tg.map(c => {
      const l = moveLoss(co, c);
      return '<button class="lrow" data-a="mgrmovego" data-p="' + P({ id: co.id, to: c.id }) + '"><span class="ctext"><b>' + esc(c.name) + '</b><small>' + esc(BD[c.type].n) + '</small></span><span class="badge ' + l.cls + '">' + l.t + '</span></button>';
    }).join('') || '<div class="lrow"><small>Every other company already has a manager.</small></div>') + '</div>' + btn('Cancel', 'sheetclose', undefined, 'ghost wide'));
  };
  ACT.mgrmovego = p => {
    const a = getCo(p.id), b = getCo(p.to), n = a && S.npcs[a.mgr];
    if (!a || !b || !n || b.mgr) return;
    const l = moveLoss(a, b);
    n.exp = Math.round(n.exp * l.f * 2) / 2;
    b.mgr = n.id;
    b.mgrWage = a.mgrWage;
    b.mgrBonus = a.mgrBonus || 0;
    b.mgrW0 = S.week;
    b.ohrs = 0;
    b.mood = a.mood != null ? a.mood : 60;
    b.flags.fraud = 0;
    b.lastRev = null;
    n.hired = b.id;
    a.mgr = null;
    a.mgrWage = 0;
    a.ohrs = 40;
    ui.sheet = null;
    save();
    toast(n.name + ' now manages ' + b.name + '.');
    go('co', { id: b.id, t: 'st' });
  };

  /* ---------- meetings: the manager brings 2-3 proposals with numbers ---------- */
  const fmtW = (v, once) => once ? mshort(once) + ' once' : (v < 0 ? '−' : '') + mshort(Math.abs(v)) + '/wk';
  function mprops(co) {
    const bd = BD[co.type], w = co.lastW || {}, d = co.dbg || {};
    const q = mgrQual(co);
    const units = w.units || 0, rev = w.rev || 0, tk = units > 0 ? rev / units : ticketEff(co, bd);
    const util = w.util || 0, D = d.D != null ? d.D : (w.D || 0), cap = d.cap || w.cap || 0;
    const out = [];
    const std = stdStaff(bd, co.size || 1);
    let role = null;
    std.forEach(x => {
      if (!role && co.staff.filter(s => s.role === x[0] && !s.notice).length < x[1] && ROLES[x[0]]) role = x[0];
    });
    if (!role && util > 0.85 && std[0] && ROLES[std[0][0]]) role = std[0][0];
    if (role && (util > 0.75 || D > cap)) {
      const per = cap > 0 ? cap / Math.max(1, co.staff.length || 1) : D;
      const extra = Math.min(per, Math.max(0, D - cap * 0.9)) || per * 0.3;
      if (extra * tk > 0) out.push({ t: 'hire', role, cost: wageFor(role, co) * 12 * OC(), cw: wageFor(role, co) * 12 * OC() / 52, rw: extra * tk * 0.9, title: 'Hire one more ' + ROLES[role][0].toLowerCase(), why: 'Utilisation is ' + Math.round(util * 100) + '%' + (D > cap ? ' and we turn customers away' : '') + '. I would like to hire one more. Salary around ' + money(wageFor(role, co)) + ' a month.' });
    }
    const L = pLvl(co);
    if (util > 0.85 && L < 3) out.push({ t: 'price_up', cw: 0, rw: rev * (PRICE_PM[L + 4] / PRICE_PM[L + 3] * 0.9 - 1), title: 'Raise prices one step', why: 'We are nearly fully booked, so a higher price costs us few customers.' });
    if (util < 0.6 && L > -3 && units > 0) out.push({ t: 'price_down', cw: 0, rw: rev * (PRICE_PM[L + 2] / PRICE_PM[L + 3] * 1.22 - 1), title: 'Lower prices one step', why: 'We have free capacity. A lower price fills it.' });
    if (co.aware < 70) {
      const c = bd.aud > 0.5 ? 'google' : 'meta';
      const cur = co.mkt[c] ? co.mkt[c].b : 0;
      const nx = CH[c] && CH[c].opts.find(o => o > cur);
      if (nx) out.push({ t: 'mkt_more', cw: nx - cur, rw: (nx - cur) * (1.1 + (70 - co.aware) / 60) * (util < 0.9 ? 1 : 0.4), title: 'Spend more on ' + CH[c].n, why: 'We are ' + awWord(co.aware).toLowerCase() + ' locally. More people need to hear about us.' });
    }
    if ((co.eqc != null ? co.eqc : 1) < 0.7 && co.maint < 2) out.push({ t: 'quality', cw: Math.max(KC(200), rev * 0.02), rw: rev * 0.05, title: 'Step up maintenance', why: 'Equipment is at ' + Math.round((co.eqc || 0) * 100) + '% and breakdowns cost us jobs.' });
    if (util < 0.5 && co.staff.length > 1) {
      const s = co.staff.slice().sort((a, b) => staffSkill(a) - staffSkill(b))[0];
      out.push({ t: 'cut', cost: 0, cw: -s.wage * OC() * 12 / 52, rw: -rev * 0.04, title: 'Let one person go', why: 'We have more people than work right now.' });
    }
    const bo = d.botObj;
    if (bo && bo.kind === 'equip' && util > 0.9) {
      const e = bd.eq.find(x => 'eq:' + x.id === bo.k);
      if (e && !e.vo) out.push({ t: 'eq', id: e.id, cost: eqPrice(co, e), cw: 0, once: eqPrice(co, e), rw: tk * Math.max(1, D - cap) * 0.8, title: 'Buy ' + e.n, why: 'It is our bottleneck right now.' });
    }
    if (co.maint > 0 && rev > 0 && out.length < 3) out.push({ t: 'save', cw: -Math.max(KC(100), rev * 0.015), rw: -rev * 0.01, title: 'Trim upkeep', why: 'A little less maintenance saves money with small risk.' });
    out.forEach(x => {
      x.score = x.rw - x.cw - (x.once || 0) / 26 + gauss() * Math.abs(x.rw - x.cw + 1) * 0.6 * (1 - q);
    });
    return out.sort((a, b) => b.score - a.score).slice(0, 3);
  }
  V.meet = function () {
    const cos = live().filter(c => c.mgr && S.npcs[c.mgr]);
    if (!cos.length) return '<div class="card empty"><h3>No managers yet</h3><p class="lead">Hire a manager for a company and you can call meetings here.</p></div>';
    ui.mtw = cos.some(c => c.id === ui.mtw) ? ui.mtw : cos[0].id;
    const co = getCo(ui.mtw), n = S.npcs[co.mgr];
    const wait = co.meetW != null && S.week - co.meetW < 3;
    let h = '<div class="card"><span class="lab">Meet with</span>' + U.ddown(cos.map(c => [c.id, S.npcs[c.mgr].name + ' · ' + c.name]), ui.mtw, 'mtwho') + '<small>' + esc(n.name.split(' ')[0]) + ' brings 2–3 proposals with costs and expected revenue. You decide on each.</small>' + (wait ? '<div class="note">You met recently. Next meeting possible in ' + (3 - (S.week - co.meetW)) + ' week(s).</div>' : btn('Call the meeting', 'mtgo2', undefined, 'primary wide')) + '</div>';
    h += teamCard(cos);
    const open = S.inbox.filter(m => m.status === 'open' && m.act === 'mprop');
    if (open.length) h += '<h2 class="sec">On the table</h2>' + open.map(m => '<div class="dcard">' + window.msgCard(m) + '</div>').join('');
    return h;
  };
  /* the team meeting: all your managers or one, about one thing, in the tone you choose (engine/management/meetings.js) */
  const TM_FX = {
    review: 'They go through last month and tell you how it looks.',
    growth: 'More marketing to win customers. A final warning also cuts prices a step.',
    costs: 'They look for savings. Serious: less marketing too. A final warning: staff cuts.',
    quality: 'More upkeep and higher standards. Costs up a little, fewer complaints.',
    morale: 'Lifts the mood, most of all in a casual chat.',
    pay: 'A raise (5% casual, 3% serious) or, as a final warning, a 5% pay cut.'
  };
  function teamCard(cos) {
    const T = ui.tm = ui.tm || { who: 'all', goal: 'review', sev: 'casual' };
    if (T.who !== 'all' && !cos.some(c => c.id === T.who)) T.who = 'all';
    const pick = T.who === 'all' ? cos : cos.filter(c => c.id === T.who);
    const fresh = pick.filter(c => c.meetW == null || S.week - c.meetW >= 3);
    const who = [['all', 'All managers · ' + cos.length]].concat(cos.map(c => [c.id, S.npcs[c.mgr].name + ' · ' + c.name]));
    return '<div class="card"><h3>Team meeting<small>You set the agenda and the tone.</small></h3><span class="lab">With</span>' + U.ddown(who, T.who, 'tmset', { k: 'who' }) +
      '<span class="lab">About</span>' + U.ddown(MEET_GOALS, T.goal, 'tmset', { k: 'goal' }) +
      '<span class="lab">How</span>' + chips(MEET_SEV, T.sev, 'tmset', { k: 'sev' }) +
      '<span class="tipt">' + esc(TM_FX[T.goal] || '') + (T.sev === 'serious' ? ' A serious talk costs a little goodwill.' : T.sev === 'final' ? ' A final warning costs a lot of goodwill; an unhappy manager may resign.' : '') + '</span>' +
      (fresh.length ? btn(fresh.length === pick.length ? 'Hold the meeting' : 'Meet the ' + fresh.length + ' you have not seen lately', 'tmgo', undefined, 'wide') : '<div class="note">You met ' + (pick.length > 1 ? 'all of them' : 'them') + ' less than three weeks ago.</div>') + '</div>';
  }
  ACT.tmset = p => { ui.tm = Object.assign(ui.tm || {}, { [p.k]: p.v }); render(); };
  ACT.tmgo = () => {
    const T = ui.tm || { who: 'all', goal: 'review', sev: 'casual' };
    const go = () => {
      const r = callMeeting(T.who, T.goal, T.sev);
      if (r === 'ok') { save(); toast('The meeting is done. Their replies are in Messages.'); render(); } else toast(r === 'wait' ? 'You met recently. Give it a few weeks.' : 'Nobody to meet.', true);
    };
    if (T.sev === 'final') confirmThen('Give a final warning?', 'It costs a lot of goodwill, and an unhappy manager may resign on the spot.', 'Go ahead', go, true); else go();
  };
  ACT.mtwho = p => {
    ui.mtw = p.v;
    render();
  };
  ACT.mtgo2 = () => {
    const co = getCo(ui.mtw);
    if (!co || !co.mgr || !S.npcs[co.mgr]) return;
    const n = S.npcs[co.mgr], first = n.name.split(' ')[0];
    const ps = mprops(co);
    co.meetW = S.week;
    co.mood = Math.min(100, (co.mood != null ? co.mood : 60) + 3);
    if (!ps.length) addMsg({ kind: 'info', from: n.name, role: titleFor(co, 'mgr'), title: 'Meeting: ' + co.name, body: 'Things run well. I do not see anything worth changing right now.', co: co.id, tone: 'n', status: 'done' });
    ps.forEach(x => addMsg({
      kind: 'ask',
      from: n.name,
      role: titleFor(co, 'mgr'),
      title: x.title,
      body: x.why,
      co: co.id,
      stats: [['Added cost', fmtW(x.cw, x.once)], ['Added revenue', (x.rw < 0 ? '' : '~') + fmtW(x.rw)]],
      opts: [{ l: x.t === 'hire' ? 'Approve, I pick' : 'Approve', d: '', fx: {} }, { l: 'Let ' + first + ' decide', d: '', fx: {} }, { l: 'Not now', d: '', fx: {} }],
      act: 'mprop',
      data: x,
      exp: S.week + 2
    }));
    save();
    toast(ps.length ? first + ' put ' + ps.length + ' proposal' + (ps.length === 1 ? '' : 's') + ' on the table.' : first + ' has nothing to change.');
    render(true);
  };
  function doProp(co, x, n, q, mine) {
    if (x.t === 'hire' && mine) {
      ui.hrole = x.role;
      go('hire', { id: co.id });
      return;
    }
    if (x.t === 'hire' || x.t === 'eq' || x.t === 'cut') {
      if (x.t === 'hire') {
        const need = hireShort(co, x.cost || 0);
        if (need > 0) {
          if (liquid() < need) {
            note('Not enough money to hire at ' + co.name + ': needs ' + money(need) + ' first.', 'bad', co.id);
            return;
          }
          injectCash(co, need);
        }
      }
      execProposal(co, x, n, q);
      return;
    }
    const said = runStep(co, x.t);
    if (said) note(n.name + ': ' + said, 'n', co.id);
  }
  ACTS.mprop = (m, idx) => {
    const co = getCo(m.co);
    if (!co || !co.mgr || !S.npcs[co.mgr] || idx === 2) return true;
    const x = m.data, n = S.npcs[co.mgr], q = mgrQual(co);
    if (idx === 1 && !(x.rw - x.cw > 0 && chance(0.55 + q * 0.4))) {
      note(n.name + ' decided against: ' + x.title + '.', 'n', co.id);
      return true;
    }
    doProp(co, x, n, q, idx === 0);
    return true;
  };


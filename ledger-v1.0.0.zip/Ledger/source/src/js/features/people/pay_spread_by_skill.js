/* ===== Pay spread by skill (round 24) =====
   The country table gives one wage index per country. In lower-wage countries the gap between low-paid and skilled
   jobs is wider than in Norway: a barista in Brazil earns about a tenth of a Norwegian barista, an electrician closer
   to a seventh, a pilot much closer to Norwegian pay. Low-paid jobs therefore follow the index more steeply.
   Countries at or above Norway's wage level are unchanged. */
(function () {
  R24.paySpread = function (role, cc) {
    const C = CO[cc || S.country] || CC(), w = C.wage || 1;
    if (w >= 1) return 1;
    const r = (ROLES[role] || ['', 40000])[1];
    const e = clamp(1 + (1 - r / 80000), 0.7, 1.6);
    return Math.pow(w, e) / w;
  };
  addStep('wageFor', 10, 'pay spreads with skill: specialists earn more', (role, co, v) => {
    const f = R24.paySpread(role, (co && co.country) || S.country); return f !== 1 ? rlc(rnd(v * f, 100), co && co.country) : v;
  }, true);
})();


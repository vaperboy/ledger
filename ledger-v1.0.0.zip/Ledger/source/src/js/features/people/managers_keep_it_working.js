/* ===== Round 22: managers who keep a working business working.
   Found in A/B tests (same business, same weeks, with and without a manager):
   1. Manager pay grew 6 000 a month per employee on top of 52 000: a 4-person restaurant manager asked ~136 000 a month,
      more than the restaurant earned. Now pay follows the job (≈40 000 + 2 200 per employee in Norway, by skill and city).
   2. A new manager had no authority (level 0), so every staff departure, every event and every routine choice went to
      the owner as a message and expired unanswered. Staff who left were never replaced: a builder went from 3 workers to 1
      and to zero revenue. Now a manager keeps the team it inherited (replacement hires are maintenance, not growth),
      gets routine authority on appointment, and handles events within its budget.
   3. Routine price moves were made on utilisation alone. Now a price change is kept only if the expected contribution
      (units × price − variable cost, within capacity) is at least as good as before.
   4. New marketing started by a manager needs an expected return, not just spare cash.
   5. Each manager's record is tracked against the business as it was when they started. ===== */
{
  /* ---------- 1. pay that fits the job ---------- */
  addStep('genManager', 10, '---------- 1. pay that fits the job ----------', (co, mtype, n) => {
    const st = n.stats || {};
    const skill = ((st.ops || 60) + (st.people || 60) + (st.sales || 60) + (st.fin || 60)) / 4;
    const heads = co ? co.staff.length : 3;
    const city = co ? cityOf(co.city) : cityOf(S.player.city);
    const tierF = n.tier === 'senior' ? 1.1 : n.tier === 'young' ? 0.86 : 1;
    let pay = (40000 + Math.min(60000, heads * 2200)) * (0.85 + skill / 400) * tierF * ((city && city.wage) || 1) * Math.pow(1 + ((S.econ && S.econ.infl) || 0.02), S.week / 52);
    pay *= 0.82 + 0.18 * Math.min(1, (n.exp || 0) / 9);
    n.ask = rl(rnd(pay, 500), co && co.country);
  });

  /* ---------- helpers: what a choice is worth this week ---------- */
  const bdOf = co => BD[co.type];
  function contribution(co) {
    const bd = bdOf(co);
    try {
      const D = demand(co, bd).D, cap = capacity(co, bd).cap || Infinity;
      const units = Math.min(D, cap), tk = ticketEff(co, bd);
      const w = co.lastW || {}, vr = w.rev > 0 ? clamp((w.cogs || 0) / w.rev, 0, 0.95) : (bd.cogs || 0.3);
      return units * tk * (1 - vr);
    } catch (e) { return null; }
  }
  const monthProfit = co => { const H = (co.hist || []).slice(-3); return H.length ? H.reduce((a, x) => a + (x.profit || 0), 0) / H.length : 0; };
  const monthRev = co => { const H = (co.hist || []).slice(-3); return H.length ? H.reduce((a, x) => a + (x.rev || 0), 0) / H.length : 0; };
  const roleCounts = co => { const o = {}; co.staff.forEach(s => { if (!s.notice && !s.seas) o[s.role] = (o[s.role] || 0) + 1; }); return o; }; /* seasonal help is not part of the year-round team */

  /* ---------- 5. the baseline a manager is measured against ---------- */
  addStep('hireManager.check', 20, 'note where the company stands before the manager starts', (co, n, wage, ctx) => {
    const before = ctx.before = { prof: monthProfit(co), rev: monthRev(co), roles: roleCounts(co), staff: co.staff.length, w: S.week, cash: co.cash };
    /* the owner's own hours were doing a job: when the owner steps out, that job needs a person */
    try {
      if (!co.mgr && (co.ohrs || 0) > 0) {
        /* the owner's time is spread over several jobs; replace it with as many people as it adds up to, in the jobs it mattered most */
        const P = (capacity(co, bdOf(co)).parts || []).filter(p => p.kind === 'staff' && p.owner > 0 && ROLES[p.k.split(':')[1]]).sort((a, b2) => b2.owner - a.owner);
        let n = Math.round(P.reduce((a, p) => a + p.owner, 0));
        if (!n && P.length && P[0].owner >= 0.45) n = 1;
        P.slice(0, n).forEach(p => { const role = p.k.split(':')[1]; before.roles[role] = (before.roles[role] || 0) + 1; before.owner = (before.owner || []).concat([role]); });
      }
    } catch (e) { console.error(e); }
  });
  addStep('hireManager.done', 10, 'the manager starts with routine authority and a baseline', (co, n, wage, ctx) => {
    if (ctx.r === 'ok') {
      const before = ctx.before;
      co.mgrBase = before;
      /* a manager runs the day to day: routine authority from the first day, unless the owner set something else */
      if (!co.auth.set22 && (co.auth.lvl || 0) < 1) co.auth.lvl = 1;
      co.auth.buy = Math.max(co.auth.buy || 0, rnl(Math.max(KC(10000), before.rev * 0.08), 1000));
    }
  });
  /* the owner choosing a level on purpose keeps it: ACT.authlvl and the other authority buttons set co.auth.set22 (ui/company/people.js) */


  /* ---------- 2. keep the team running: replace people who leave, cover lost capacity when it pays ---------- */
  function hireOne(co, role, why, hrs) {
    const bd = bdOf(co);
    const cs = searchWorkers(co, role, 'network').sort((a, b) => a.ask - b.ask);
    const q = mgrQual(co);
    const c = cs[Math.min(cs.length - 1, Math.floor(cs.length * (0.35 + q * 0.4)))];
    if (!c) return false;
    HIRE_HOURS = hrs || 0;
    let r;
    try { r = hireWorker(co, c, rnl(c.ask * 1.02, 100)); } finally { HIRE_HOURS = 0; }
    if (r !== 'ok') return false;
    const s = co.staff[co.staff.length - 1];
    if (s && window.managerOnboard) managerOnboard(co, s);
    const m = S.npcs[co.mgr];
    note((m ? m.name : 'Your manager') + ' hired ' + c.name + ' (' + ROLES[role][0].toLowerCase() + (hrs ? ', part time ' + hrs + ' h' : '') + ') at ' + co.name + ': ' + why + '.', 'n', co.id);
    co.mgrLog = (co.mgrLog || []).concat([{ w: S.week, t: 'hire', role }]).slice(-20);
    return true;
  }
  function keepTeam(co, bd) {
    const base = co.mgrBase;
    if (!base || !co.mgr || co.st !== 'open') return;
    if (S.week - (co.flags.rep22 || -99) < 2) return;
    const have = roleCounts(co);
    /* a job nobody does stops the whole business: fill it first, whoever used to do it */
    const bo = (co.dbg || {}).botObj, bp = bo && bo.kind === 'staff' ? ((co.dbg || {}).cp || []).find(p => p.k === bo.k) : null;
    if (bp && bp.have < 0.3 && ((co.lastW || {}).D || 0) > 0) {
      const role = bo.k.split(':')[1];
      if (ROLES[role]) {
        const cost = wageFor(role, co) * 12 * OC();
        /* in a very small business the job may not even pay for the person doing it: then the manager says so instead of hiring */
        const w0 = co.lastW || {}, vr0 = w0.rev > 0 ? clamp((w0.cogs || 0) / w0.rev, 0, 0.95) : (bd.cogs || 0.3);
        if (base.rev > 0 && base.rev * (1 - vr0) < wageFor(role, co) * OC() * 1.1) {
          if (!co.flags.rep22warn || S.week - co.flags.rep22warn > 8) { co.flags.rep22warn = S.week; note((S.npcs[co.mgr] ? S.npcs[co.mgr].name : 'Your manager') + ': nobody is working as ' + ROLES[role][0].toLowerCase() + ' at ' + co.name + ', and the business took in about ' + money(base.rev) + ' a month, less than one would cost. It cannot carry both a manager and a ' + ROLES[role][0].toLowerCase() + '. Consider running it yourself again.', 'bad', co.id); }
          return;
        }
        if (hireShort(co, cost) > 0) { if (!co.flags.rep22warn || S.week - co.flags.rep22warn > 8) { co.flags.rep22warn = S.week; note(co.name + ' has nobody working as ' + ROLES[role][0].toLowerCase() + ' and cannot afford to hire one. Nothing gets done until someone does.', 'bad', co.id); } return; }
        co.flags.rep22 = S.week;
        base.roles[role] = Math.max(base.roles[role] || 0, (have[role] || 0) + 1);
        hireOne(co, role, 'nobody was doing this job, so work had stopped');
        return;
      }
    }
    for (const role in base.roles) {
      if (!ROLES[role]) continue;
      if ((have[role] || 0) >= base.roles[role]) continue;
      /* only replace people the work needs: if this job is not what limits output, or there is not enough work, leave the post empty */
      if (!roleNeeded(co, role)) {
        base.roles[role] = have[role] || 0;
        note((S.npcs[co.mgr] ? S.npcs[co.mgr].name : 'Your manager') + ' is not filling the ' + ROLES[role][0].toLowerCase() + ' post at ' + co.name + ': the team can handle the work there is without it.', 'n', co.id);
        continue;
      }
      const cost = wageFor(role, co) * 12 * OC();
      if (hireShort(co, cost) > 0) {
        if (!co.flags.rep22warn || S.week - co.flags.rep22warn > 8) { co.flags.rep22warn = S.week; note(co.name + ' is short of a ' + ROLES[role][0].toLowerCase() + ' but cannot afford to replace them yet.', 'bad', co.id); }
        return;
      }
      const ownerRole = (base.owner || []).indexOf(role) >= 0 && !(co.mgrLog || []).some(x => x.role === role);
      /* the owner's hands-on hours only need covering when there is work for them: an idle, loss-making team does not need one more */
      if (ownerRole && idle(co)) { if (!co.flags.idle22n) { co.flags.idle22n = 1; note((S.npcs[co.mgr] ? S.npcs[co.mgr].name : 'Your manager') + ' is not replacing your hands-on hours at ' + co.name + ' yet: the team is not busy. They will hire when work picks up.', 'n', co.id); } return; }
      co.flags.rep22 = S.week;
      hireOne(co, role, ownerRole ? 'covering the work you used to do' : 'replacing someone who left');
      return;
    }
  }
  function roleNeeded(co, role) {
    /* fresh numbers: last week's figures still include the person who just left */
    let parts = [];
    try { parts = ((capacity(co, bdOf(co)) || {}).parts || []).filter(p => p && isFinite(p.cap)); } catch (e) { parts = ((co.dbg || {}).cp || []).filter(p => p && isFinite(p.cap)); }
    const rp = parts.find(p => p.k === 'role:' + role);
    if (!rp || !parts.length) return true;
    const capMin = parts.reduce((m, p) => Math.min(m, p.cap), Infinity);
    const w = co.lastW || {}, dr = w.cap > 0 ? (w.D || 0) / w.cap : 1;
    return rp.cap <= capMin * 1.15 + 1e-9 && dr > 0.8;
  }
  /* a lapsed licence stops the business: the manager re-applies as soon as the money is there */
  function renewDocs(co) {
    for (const id in co.docs || {}) {
      const d = co.docs[id];
      if (!d || d.st !== 'lapsed') continue;
      const cost = docCost(co, id);
      if (co.cash < cost * 1.5 + coWeekCost(co) * 2) continue;
      if (applyDoc(co, id) === 'ok') note((S.npcs[co.mgr] ? S.npcs[co.mgr].name : 'Your manager') + ' re-applied for ' + docDef(id, co.country)[0].toLowerCase() + ' at ' + co.name + '.', 'n', co.id);
    }
  }
  /* recent weekly results, kept by the weekly hook below */
  function hist22(co) { return co.wh22 || []; }
  function idle(co) {
    const H = hist22(co).slice(-4);
    if (H.length < 2) return false;
    /* idle = little demand for the capacity there is; a team that cannot work at all (capacity zero) is not idle, it is missing someone */
    return H.every(x => x.d != null) && H.reduce((a, x) => a + x.d, 0) / H.length < 0.6 && H.reduce((a, x) => a + x.p, 0) < 0;
  }
  /* 5. protect the cash: a manager whose business is burning money with idle people cuts back before the money runs out */
  function protectCash(co, bd) {
    if (!co.mgr || co.st !== 'open' || (co.auth.lvl || 0) < 1) return;
    const H = hist22(co).slice(-8);
    if (H.length < 6 || S.week - (co.flags.cut22 || -99) < 8) return;
    const avgP = H.reduce((a, x) => a + x.p, 0) / H.length, avgU = H.reduce((a, x) => a + x.u, 0) / H.length;
    if (avgP >= 0) return;
    const runway = Math.max(0, co.cash) / -avgP;
    if (runway > 12) return;
    const m = S.npcs[co.mgr], who = m ? m.name : 'Your manager';
    /* marketing that does not pay back goes first */
    if (window.R19) Object.keys(co.mkt || {}).forEach(k => { const c = co.mkt[k]; if (!c || !c.b) return; const e = R19.expect(co, k, c.b); if (!e || e.roi < 1) { delete co.mkt[k]; co.flags.cut22 = S.week; note(who + ' stopped ' + (CH[k] ? CH[k].n.toLowerCase() : k) + ' at ' + co.name + ': it was not paying for itself and cash is short.', 'n', co.id); } });
    /* then people who have nothing to do: one at a time, never the last person in a role */
    const avgD = H.every(x => x.d != null) ? H.reduce((a, x) => a + x.d, 0) / H.length : 1;
    if (avgU < 0.6 && avgD < 0.7 && co.staff.length > 1) {
      const rc = roleCounts(co);
      const L = co.staff.filter(x => (rc[x.role] || 0) > 1).sort((a, b) => staffSkill(a) - staffSkill(b));
      const x = L[0];
      if (x) {
        const nm = S.npcs[x.id] ? S.npcs[x.id].name : 'one person';
        fireStaff(co, x.id, 0);
        if (co.mgrBase && co.mgrBase.roles && co.mgrBase.roles[x.role] > (rc[x.role] - 1)) co.mgrBase.roles[x.role] = rc[x.role] - 1;
        co.mood = Math.max(0, (co.mood != null ? co.mood : 60) - 4);
        co.flags.cut22 = S.week;
        co.mgrLog = (co.mgrLog || []).concat([{ w: S.week, t: 'cut', role: x.role }]).slice(-20);
        note(who + ' let ' + nm + ' (' + ROLES[x.role][0].toLowerCase() + ') go at ' + co.name + ': the team is ' + Math.round(avgU * 100) + '% busy and cash lasts about ' + Math.round(runway) + ' weeks at this rate.', 'bad', co.id);
      }
    }
    if (runway < 6 && !co.flags.cash22w || (co.flags.cash22w && S.week - co.flags.cash22w > 8 && runway < 6)) { co.flags.cash22w = S.week; note(who + ' warns: ' + co.name + ' loses about ' + money(-avgP) + ' a week and has cash for about ' + Math.round(runway) + ' weeks.', 'bad', co.id); }
  }
  addStep('week.after', 55, 'managers_keep_it_working weekly', () => {
    try { S.cos.forEach(co => { if (co.st !== 'open') return; const b = co.bk && co.bk.w || {}; const w = co.lastW || {}; const L = co.wh22 = co.wh22 || []; L.push({ p: Math.round((b.rev || 0) - sumExp(b)), u: Math.round((w.util || 0) * 100) / 100, d: w.cap > 0 ? Math.round(Math.min(9, (w.D || 0) / w.cap) * 100) / 100 : 9 }); if (L.length > 12) L.splice(0, L.length - 12); }); } catch (e) { console.error(e); }
  });
  /* turning customers away for weeks: one more person, if the extra sales pay for them with room to spare */
  function coverGap(co, bd) {
    if (!co.mgr || co.st !== 'open' || (co.auth.lvl || 0) < 1) return;
    const w = co.lastW || {};
    co.flags.gap22 = w.cap > 0 && w.D > w.cap * 1.08 ? (co.flags.gap22 || 0) + 1 : 0;
    /* round 56: the busier it is, the sooner the manager acts. Far more customers than the team can serve, or a team
       working itself to exhaustion (long weeks, people off sick), is fixed within weeks, not months */
    const on = co.staff.filter(x => !x.off && !x.notice), worn = on.length ? on.filter(x => (x.tired || 0) > 55 || (typeof sickNow === 'function' && sickNow(x))).length / on.length : 0;
    const flood = w.cap > 0 && w.D > w.cap * 1.3, burn = worn >= 0.34 && (w.util || 0) >= 0.95;
    const wait = burn || flood ? 3 : 8, need = burn || flood ? 2 : 4;
    if ((co.flags.gap22 < need && !burn) || S.week - (co.flags.grow22 || -99) < wait) return;
    const dbg = co.dbg || {}, bo = dbg.botObj;
    /* only when people are the bottleneck: more staff does not help if it is space or equipment */
    let role = bo && bo.kind === 'staff' ? bo.k.split(':')[1] : null;
    if ((!role || !ROLES[role]) && burn) { const c = {}; on.filter(x => (x.tired || 0) > 55).forEach(x => { c[x.role] = (c[x.role] || 0) + 1; }); role = Object.keys(c).sort((a, b) => c[b] - c[a])[0]; }
    if (!role || !ROLES[role]) return;
    /* the last hire did not add the capacity it should have: stop hiring for a while */
    const lg = co.flags.lastGrow22;
    if (lg && S.week - lg.w >= 4 && !lg.checked) { lg.checked = 1; if ((w.cap || 0) < lg.cap + lg.exp * 0.5) { co.flags.noGrow22 = S.week + 26; } }
    if ((co.flags.noGrow22 || 0) > S.week && !burn) return;
    const cost = wageFor(role, co) * 12 * OC();
    const tk = w.units > 0.01 && w.rev > 0 ? w.rev / w.units : ticketEff(co, bd), vr = w.rev > 0 ? clamp((w.cogs || 0) / w.rev, 0, 0.95) : (bd.cogs || 0.3);
    /* what one more person in the bottleneck job adds (a share of a full week for a part-timer): their share of capacity, up to the next bottleneck */
    const parts = (dbg.cp || []).filter(p => p && isFinite(p.cap));
    const bp = parts.find(p => p.k === bo.k);
    const next = parts.filter(p => p !== bp).reduce((m, p) => Math.min(m, p.cap), Infinity);
    const adds = sh => bp && bp.capPer && bp.cap > 0 ? (w.cap || 0) * Math.max(0, Math.min(bp.cap + bp.capPer * sh, next) - bp.cap) / bp.cap : sh * (w.cap || 0) / Math.max(1, co.staff.length + (co.ohrs ? 1 : 0.5));
    const perHead = adds(1);
    /* a new person rarely runs at full speed, and only part of the people turned away come back */
    const lost = Math.max(0, (w.D || 0) - (w.units || 0));
    const gain = Math.min(perHead * 0.75, lost * 0.6) * tk * (1 - vr) * 52;
    const q = mgrQual(co), noise = 1 + gauss() * 0.25 * (1 - q), seen = gain * noise;
    /* a full-timer does not pay for the extra customers, but a part-timer working the busy hours may */
    let hrs = 0;
    /* a worn-out team costs more than one more person: sick days, mistakes, people quitting */
    if (burn && seen < cost * 1.25) { const sh = 20 / FULL_H; hrs = seen >= cost * 0.8 ? 0 : 20; if (hrs && seen < cost * sh * 0.8) hrs = 20; }
    else if (seen < cost * 1.25) {
      const sh = 20 / FULL_H, gPt = Math.min(adds(sh) * 0.9, lost * 0.6) * tk * (1 - vr) * 52 * noise;
      if (gPt < cost * sh * 1.15) return;
      hrs = 20;
    }
    const cHire = hrs ? cost * hrs / FULL_H : cost;
    const short = hireShort(co, cHire, hrs ? cHire * 1.5 : seen);
    if (short > 0) { askForHireMoney(co, role, cHire, short); return; }
    co.flags.grow22 = S.week;
    if (hireOne(co, role, burn ? 'the team was working itself to exhaustion' : 'we were turning customers away', hrs)) co.flags.lastGrow22 = { w: S.week, cap: w.cap || 0, exp: hrs ? adds(hrs / FULL_H) : perHead };
  }
  /* busy but short of cash: the manager asks you to put money in for the hire (at most every eight weeks) */
  function askForHireMoney(co, role, cost, short) {
    /* round 56: a chain moves the money from a sister store before anyone asks you */
    if (window.CHN56 && chainOf(co).length > 1) { const sis = CHN56.sisterCash(co, short * 1.2); if (sis) { note((chainOf(co)[1].npc.name) + ' moved ' + money(rnl(short * 1.2, 1000)) + ' from ' + sis.name + ' to ' + co.name + ' for a new ' + ROLES[role][0].toLowerCase() + '.', 'n', co.id); co.flags.ask22 = S.week - 8; return; } }
    if (S.week - (co.flags.ask22 || -99) < 8 || S.inbox.some(m => m.act === 'mgrcash' && m.co === co.id && m.status === 'open')) return;
    co.flags.ask22 = S.week;
    const m = S.npcs[co.mgr], amt = niceAmt(short * 1.5), job = ROLES[role][0].toLowerCase();
    addMsg({ kind: 'ask', from: m ? m.name : co.name, title: 'Money for a new ' + job + ' at ' + co.name + '?', body: 'We are turning customers away. A ' + job + ' costs about ' + money(Math.round(cost / 12)) + ' a month and should bring in clearly more than that, but the company is short of cash to hire safely. Put in ' + money(amt) + ' and I will hire next week.', co: co.id, opts: [{ l: 'Put in ' + money(amt), d: 'From your own cash.', fx: {} }, { l: 'Not now', d: 'The manager asks again in two months if it is still busy.', fx: {} }], act: 'mgrcash', data: { amt, role }, exp: S.week + 3 });
  }
  ACTS.mgrcash = (m, idx) => {
    const co = getCo(m.co);
    if (!co || idx !== 0) return true;
    if (liquid() < m.data.amt) { toast('You do not have ' + money(m.data.amt) + ' to put in.', true); return false; }
    injectCash(co, m.data.amt);
    co.flags.ask22 = S.week - 8;
    return true;
  };
  addStep('managerWeek', 10, 'managers_keep_it_working managerWeek', (co, bd, ctx, r) => {
    if (co.mgr && S.npcs[co.mgr]) { if (!co.mgrBase) co.mgrBase = { prof: monthProfit(co), rev: monthRev(co), roles: roleCounts(co), staff: co.staff.length, w: S.week, cash: co.cash }; keepTeam(co, bd); coverGap(co, bd); protectCash(co, bd); renewDocs(co); }
  });

  /* ---------- 3 + 4. routine tuning has to make sense in money ---------- */
  addStep('tune.before', 10, 'note price, campaigns and margin', (co, bd, ctx, q, ph) => {
    ph.p0 = co.price || 0; ph.mk0 = JSON.stringify(co.mkt || {}); ph.c0 = contribution(co);
  });
  addStep('tune.after', 30, 'managers back out of moves that lose money', (co, bd, ctx, q, ph) => {
    const p0 = ph.p0, mk0 = ph.mk0, c0 = ph.c0;
    if ((co.price || 0) !== p0 && c0 != null) {
      const c1 = contribution(co);
      /* a better manager reads the market better; all of them back out of a move that loses money */
      const err = 1 + gauss() * 0.04 * (1 - (q || 0.5));
      if (c1 == null || c1 * err < c0 * 0.995) { co.price = p0; co.flags.priceAt = S.week - 6; }
    }
    if (JSON.stringify(co.mkt || {}) !== mk0 && window.R19) {
      const added = Object.keys(co.mkt).filter(k => co.mkt[k] && co.mkt[k].b && !(JSON.parse(mk0)[k]));
      added.forEach(k => {
        const e = R19.expect(co, k, co.mkt[k].b);
        if (!e || e.roi < 1.2 || co.cash < coWeekCost(co) * 8) delete co.mkt[k];
        else note(S.npcs[co.mgr].name + ' started ' + CH[k].n.toLowerCase() + ' at ' + co.name + ' (' + money(co.mkt[k].b) + ' a week).', 'n', co.id);
      });
    }
  });

  /* ---------- the manager's record, against the business they took over ---------- */
  const R22 = window.R22 = { record(co) {
    const b = co.mgrBase;
    if (!b || !co.mgr) return null;
    const wk = S.week - b.w;
    const H = (co.hist || []).filter(h => h.m >= monthIdx(b.w));
    const prof = H.length ? H.reduce((a, x) => a + (x.profit || 0), 0) / H.length : null;
    return { wk, before: b.prof, now: prof, staff0: b.staff, staff: co.staff.length, hires: (co.mgrLog || []).filter(x => x.t === 'hire').length };
  },
  /* automatic setup: a vehicle that would eat a big part of the cash is financed, not paid outright */
  vehMode(co, e) { const m = VEH[e.vo[0]]; const price = m ? m[1] * Math.pow(1 + S.econ.infl, S.week / 52) * (window.R23 && R23.vehCtry ? R23.vehCtry(co) : 1) : 300000; const C = CO[co.country] || CC(); if ((C.pl || 1) < 0.7 && m && m[2] !== 'plane') return 'used'; return price > co.cash * 0.25 ? 'finance' : 'new'; } };
  window.mgrCostHint = co => genCostHint(co); /* what a manager would cost a month (ui/screens/hiring.js) */
  function genCostHint(co) {
    const city = cityOf(co.city);
    let base = (40000 + Math.min(60000, co.staff.length * 2200)) * 1.0 * ((city && city.wage) || 1);
    try { const bd = BD[co.type], tot = bd.std.reduce((m, s) => m + s[1], 0) || 1, avg = bd.std.reduce((m, s) => m + wageFor(s[0], co) * s[1], 0) / tot; base = Math.max(base, avg * 1.32); } catch (e) { }
    return rnl(base * (1 + (CC().empNI || 0.14)), 1000);
  }
  /* the board pack says how the manager is doing against where they started */
  addStep('boardPack', 10, 'the board pack says how the manager is doing against where they started', (co, r) => {
    const x = R22.record(co);
    if (x && x.wk >= 8 && x.now != null) r.body += ' Since ' + (S.npcs[co.mgr] ? S.npcs[co.mgr].name.split(' ')[0] : 'the manager') + ' took over: profit ' + money(x.now) + ' a month (before: ' + money(x.before) + '), staff ' + x.staff0 + '→' + x.staff + '.';
  });
}
/* saves from before this round: manager contracts written by the old pay formula can be several times what the job pays.
   They are brought down to a fair level once, with a note, so an old save is not ruined by the bug. */
{
  const fair = co => { const city = cityOf(co.city); return (40000 + Math.min(60000, co.staff.length * 2200)) * 1.1 * ((city && city.wage) || 1) * Math.pow(1 + ((S.econ && S.econ.infl) || 0.02), S.week / 52); };
  function fixPay() {
    if (!S || S.mgrFix22) return;
    S.mgrFix22 = 1;
    S.cos.forEach(co => {
      if (!co.mgr || !co.mgrWage) return;
      const f = rl(rnl(fair(co) * 1.15, 500), co.country);
      if (co.mgrWage > f * 1.3) {
        const old = co.mgrWage;
        co.mgrWage = f;
        if (!co.mgrBase) co.mgrBase = { prof: 0, rev: 0, roles: {}, staff: co.staff.length, w: S.week, cash: co.cash };
        info(co.name, 'Manager contract corrected', 'The manager at ' + co.name + ' was on ' + money(old) + ' a month, far above what the job pays. The contract is now ' + money(f) + ' a month.', co.id, 'n');
      }
    });
  }
  addStep('deserialize', 10, 'managers_keep_it_working deserialize', (t, r) => { if (r) fixPay(); });
  window.newGame = pipeView('window.newGame', window.newGame, 0); /* window.newGame: the screen above, then the steps below and in later files */
  addStep('window.newGame', 10, 'managers_keep_it_working window.newGame', (r) => { try { S.mgrFix22 = 1; } catch (e) { } return r; });
}

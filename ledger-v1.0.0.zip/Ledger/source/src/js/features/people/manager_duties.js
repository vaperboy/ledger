/* ===== Round 56: what a store manager looks after besides the day-to-day: IT security, insurance and the premises.
   Each is a duty you leave to the manager or keep yourself (co.duty56[k] = 0 keeps it with you); all three are the
   manager's by default, and the manager sees to them the day they start and then every month.
   - IT security (features/world/cyber_attacks.js): the level the company needs for its size and how exposed its trade
     is, as long as it costs a sensible share of sales; offline backups from Basic up; the yearly staff training once
     there are a few people and the cash. A chain can set it for every store (the chain's rules, ch.rules.cy and
     ch.rules.cybk: features/company/shelf_stock_chains_boards.js applyRules); then the chain's choice stands. A level
     you pick yourself stands as well (cy56.own) until you leave it to the manager again.
   - Insurance (ui/company/view.js CT.insurance): an insurer when there is none (your own insurance company first),
     then the policies the business needs: liability always, property with premises or equipment, professional
     indemnity where the law asks for it, cyber when attacks are likely, business interruption once a week of sales is
     worth protecting. A policy you switch yourself stays as you left it (co.insOwn).
   - Premises: when the place is too small for its customers the manager asks to expand it, and the level above
     decides (features/company/chain_hierarchy.js CHN56.decide), else you (engine/management/managers.js
     decideProposal, mgrDuty). ===== */
window.MD56 = window.MD56 || {};
(function () {
  const M = window.MD56;
  const PROF = { law: 1, acctfirm: 1, estate: 1 };
  const mgrOf = co => co.mgr && co.st !== 'sold' && co.st !== 'bust' ? S.npcs[co.mgr] : null;
  const first = n => String(n.name).split(' ')[0];
  const chainRule = co => { const ch = window.R12 && R12.chainOf ? R12.chainOf(co) : null; return ch && ch.rules && ch.rules.cy != null ? ch : null; };
  M.on = (co, k) => mgrDuty(co, k);
  M.chainRule = chainRule;
  /* who decides, in a few words, for the dashboard tiles and the screens */
  M.secBy = co => { const m = mgrOf(co), s = window.CY56 ? CY56.st(co) : {}; return chainRule(co) ? 'set by the chain' : m && mgrDuty(co, 'sec') && !s.own ? 'kept by ' + first(m) : 'your choice'; };
  M.insBy = co => { const m = mgrOf(co); return m && mgrDuty(co, 'ins') ? 'kept by ' + first(m) : 'you choose'; };

  /* ---------- IT security: the level a company like this needs ---------- */
  function secNeed(co) {
    const Y = window.CY56, s = Y.st(co), o0 = Y.yearOdds(co) / Y.ODDS[s.lvl || 0], hd = Y.heads(co);
    let lvl = hd >= 40 || o0 >= 0.3 ? 3 : hd >= 8 || o0 >= 0.12 ? 2 : 1;
    const revM = ((co.lastW && co.lastW.rev) || 0) * 4.33;
    while (lvl > 1 && Y.monthly(co, lvl, 1) > revM * 0.03) lvl--;
    return lvl;
  }
  M.secNeed = co => window.CY56 ? secNeed(co) : 0;
  function doSec(co, m) {
    const Y = window.CY56;
    if (!Y || chainRule(co)) return;
    const s = Y.st(co), L = [];
    if (!s.own) {
      const lvl = secNeed(co);
      if (lvl !== (s.lvl || 0)) { L.push((lvl > (s.lvl || 0) ? 'raised' : 'lowered') + ' IT security to ' + Y.LV[lvl][0].toLowerCase()); s.lvl = lvl; }
      if (lvl >= 1 && !s.bk) { s.bk = 1; L.push('turned on offline backups'); }
    }
    const tc = rnl(KC(450, co.country) * Math.max(1, Y.heads(co)), 100);
    if (!Y.trained(co) && Y.heads(co) >= 3 && co.cash > tc * 3 + coWeekCost(co) * 4) { payCo(co, tc, 'oth', 'Security training'); s.tr = S.week; L.push('booked security training for the team'); }
    if (L.length) note(m.name + ' ' + L.join(', ') + ' at ' + co.name + '.', 'n', co.id);
  }

  /* ---------- insurance: an insurer, then the policies the business needs ---------- */
  function insNeed(co) {
    const need = ['liab'];
    if ((co.prem && co.prem.m2 && co.prem.kind !== 'home') || (typeof eqBook === 'function' && eqBook(co) > KC(50000, co.country))) need.push('prop');
    if (PROF[co.type]) need.push('prof');
    if (window.CY56 && CY56.yearOdds(co) / CY56.ODDS[CY56.st(co).lvl || 0] >= 0.1) need.push('cyber');
    if (((co.lastW && co.lastW.rev) || 0) > KC(40000, co.country)) need.push('bi');
    return need;
  }
  M.insNeed = insNeed;
  function doIns(co, m) {
    const L = [];
    if (!co.insr) {
      const own = typeof ownFirms === 'function' ? ownFirms(co, 'ins')[0] : null;
      if (own && typeof pickOwn === 'function') pickOwn(co, 'ins', own);
      else { const best = (poolFor(co.country).ins || []).slice().sort((a, b) => b.payM / b.premM - a.payM / a.premM)[0]; if (best) pickInsurer(co, best.id); }
      if (co.insr) L.push('chose ' + co.insr.name + ' as insurer');
    }
    if (!co.insr) return;
    const own = co.insOwn || {}, add = insNeed(co).filter(k => !co.ins[k] && !own[k]);
    add.forEach(k => { co.ins[k] = 1; });
    if (add.length) L.push('took out ' + add.map(k => INSP[k][0].toLowerCase()).join(', '));
    if (L.length) note(m.name + ' ' + L.join(' and ') + ' for ' + co.name + '.', 'n', co.id);
  }

  /* ---------- the manager's month, and their first day ---------- */
  M.run = function (co) {
    const m = mgrOf(co);
    if (!m || (co.st !== 'open' && co.st !== 'setup') || co.type === 'hold' || !BD[co.type]) return;
    if (mgrDuty(co, 'sec')) doSec(co, m);
    if (mgrDuty(co, 'ins')) doIns(co, m);
  };
  addStep('week.after', 69, 'managers keep IT security and insurance up to date', () => { if (isMonthEnd(S.week)) S.cos.forEach(co => M.run(co)); });
  addStep('hireManager.done', 30, 'a new manager sees to IT security and insurance on the first day', (co, n, wage, ctx) => { if (ctx && ctx.r === 'ok') M.run(co); });

  /* ---------- the Manager page of a company's headquarters (ui/company/headquarters.js) ---------- */
  const U = window.UI;
  if (!U) return;
  const { ACT, esc, render, save } = U;
  const P = o => esc(JSON.stringify(o));
  /* one row each: what it is and who sees to it (opens its screen), and a small switch: the manager, or you */
  const seg = (co, k, m) => '<div class="seg56 mini">' + [[1, esc(first(m))], [0, 'You']].map(x => '<button class="' + ((mgrDuty(co, k) ? 1 : 0) === x[0] ? 'on' : '') + '" data-a="md56" data-p="' + P({ id: co.id, k, v: x[0] }) + '">' + x[1] + '</button>').join('') + '</div>';
  const duty = (title, val, go, line, segH) => '<div class="lrow duty56"><button class="ctext" data-a="go" data-p="' + P(go) + '"><b>' + title + ' · ' + val + ' ›</b><small>' + line + '</small></button>' + (segH || '') + '</div>';
  M.card = function (co) {
    const m = mgrOf(co);
    if (!m) return '';
    const Y = window.CY56, s = Y ? Y.st(co) : {}, ch = chainRule(co), nm = esc(first(m));
    const up = typeof chainOf === 'function' ? chainOf(co).find(x => x.kind !== 'mgr') : null, upN = up ? esc(up.npc.name) + ' (' + esc(titleLow(titleFor(co, up.kind))) + ')' : 'you';
    const ins = Object.keys(co.ins || {}).filter(k => co.ins[k]), miss = co.insr ? insNeed(co).filter(k => !co.ins[k]) : insNeed(co);
    const small = co.dbg && co.dbg.botObj && co.dbg.botObj.kind === 'space';
    let h = '<h2 class="sec">What ' + nm + ' looks after</h2><div class="lrows">';
    if (Y) h += duty('IT security', Y.LV[s.lvl || 0][0], { n: 'cy56', p: { id: co.id } },
      ch ? 'The chain sets it for every store: ' + Y.LV[ch.rules.cy][0].toLowerCase() + (ch.rules.cybk ? ', with backups' : '') + '.' : !mgrDuty(co, 'sec') ? 'You choose the level.' : s.own ? 'Your choice stands. ' + nm + ' books the training and keeps the backups.' : nm + ' picks ' + Y.LV[secNeed(co)][0].toLowerCase() + ' for a company this size' + (s.bk ? ', with backups' : '') + '.',
      ch ? '' : seg(co, 'sec', m));
    h += duty('Insurance', ins.length ? ins.length + (ins.length === 1 ? ' policy' : ' policies') : 'None', { n: 'co', p: { id: co.id, t: 'ops', s: 'ins' } },
      mgrDuty(co, 'ins') ? nm + ' keeps the insurer and the policies the business needs' + (miss.length ? ': ' + miss.length + ' missing, sorted at the month end.' : '.') : 'You choose the insurer and the policies' + (miss.length ? '. ' + miss.length + ' the business needs ' + (miss.length === 1 ? 'is' : 'are') + ' missing.' : '.'),
      seg(co, 'ins', m));
    h += duty('Premises', co.prem && co.prem.m2 ? co.prem.m2 + ' m²' : 'None', { n: 'co', p: { id: co.id, t: 'ops', s: 'assets' } },
      mgrDuty(co, 'prem') ? (small ? 'Too small for the customers. ' : 'Room enough for now. ') + nm + ' asks ' + upN + ' before expanding.' : 'You decide when to expand.' + (small ? ' It is too small for the customers.' : ''),
      seg(co, 'prem', m));
    return h + '</div>';
  };
  ACT.md56 = p => {
    const co = getCo(p.id);
    if (!co) return;
    co.duty56 = co.duty56 || {};
    co.duty56[p.k] = +p.v;
    if (+p.v) {
      if (p.k === 'sec' && window.CY56) CY56.st(co).own = 0;
      if (p.k === 'ins') co.insOwn = {};
      M.run(co);
    }
    save();
    render();
  };
  /* "leave it to the manager" from the IT security and insurance screens */
  ACT.md56give = p => ACT.md56({ id: p.id, k: p.k, v: 1 });
})();

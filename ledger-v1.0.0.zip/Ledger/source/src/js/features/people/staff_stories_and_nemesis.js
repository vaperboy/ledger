/* ===== Round 28b: people you care about.
   Staff get stories: anniversaries, promotions from the bottom up, life events, thank-you notes, retirement.
   One rival owner becomes your nemesis, with a running tally of wins and losses and the odd message.
   A business paper prints a front page every week, the Top 50 every January, and interviews you now and then;
   what you say shapes how people see you. ===== */
(function () {
  const R28 = window.R28 = window.R28 || {};
  const U = window.UI, { toast, save, render, svg, row } = U;
  const P = o => esc(JSON.stringify(o));
  const pillp = (t, c) => '<span class="pill ' + (c || '') + '">' + t + '</span>';
  const sumF = (a, f) => a.reduce((t, x) => t + (f(x) || 0), 0);
  const ini = n => String(n || '?').replace(/[^\p{L}0-9 ]/gu, ' ').trim().split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase() || '?';
  const first = n => String(n || '').split(' ')[0];
  const sur = () => String(S.player.name || 'You').split(' ').slice(-1)[0];
  const live = () => S.cos.filter(c => c.st === 'open');
  const wk = co => { try { return avgWk(co); } catch (e) { return 0; } };

  /* ================= staff stories ================= */
  const JUN = { helper: 1, cleaner: 1, cashier: 1, waiter: 1, barista: 1, housek: 1, labour: 1, fworker: 1, usher: 1, waiterB: 1, carwash: 1, courier: 1, recept: 1, groom: 1, seaman: 1, farmh: 1, teller: 1 };
  const roleN = r => ROLES[r] ? ROLES[r][0] : 'worker';
  const story = (s, t) => { s.st28 = s.st28 || []; s.st28.push({ w: S.week, t }); if (s.st28.length > 20) s.st28.splice(1, 1); };
  R28.story = story;
  const ageOf = (s, n) => (n.age || 30) + (S.week - (s.w0 || S.week)) / 52;
  function nextRole(co, s) {
    const bd = BD[co.type], w0 = ROLES[s.role] ? ROLES[s.role][1] : 40000;
    const up = (bd.std || []).map(x => x[0]).filter(r => ROLES[r] && !JUN[r] && r !== s.role && ROLES[r][1] > w0 * 1.08).sort((a, b) => ROLES[a][1] - ROLES[b][1]);
    return up[0] || null;
  }
  function staffWeek(co) {
    if (co.st !== 'open') return;
    const fresh = S.week - (co.sl28 || -99) >= 6;
    co.staff.slice().forEach(s => {
      const n = S.npcs[s.id];
      if (!n) return;
      if (!s.st28) s.st28 = [{ w: s.w0 || S.week, t: 'Joined ' + co.name + ' as ' + roleN(s.role).toLowerCase() }];
      const y = Math.floor((S.week - (s.w0 || S.week)) / 52);
      s.an28 = s.an28 || 0;
      /* anniversaries */
      if (y > s.an28 && y >= 1) {
        if (y === 1) { s.an28 = y; story(s, 'One year at ' + co.name); co.mood = Math.min(100, (co.mood || 60) + 0.5); }
        else if ([5, 10, 15, 20, 25, 30].indexOf(y) < 0) s.an28 = y;
        else if (fresh) {
          s.an28 = y;
          co.sl28 = S.week;
          addMsg({ kind: 'ask', from: co.name, title: n.name + ': ' + y + ' years at ' + co.name, body: n.name + ' started here ' + y + ' years ago as ' + (s.st28[0].t.replace(/^Joined [^ ]+.*? as /, '') || roleN(s.role).toLowerCase()) + '. The team wants to mark it.', co: co.id, opts: [{ l: 'A party for the team', d: money(KC(4000) + (co.staff.length) * KC(400)) + '. Everyone remembers it.', fx: {} }, { l: 'A bonus of a month\'s pay', d: money(s.wage) + '.', fx: {} }, { l: 'A card and a thank-you', d: 'Free.', fx: {} }], act: 'st28ann', data: { co: co.id, s: s.id, y }, exp: S.week + 2, tone: 'good' });
        }
      }
      /* from the bottom up */
      if (JUN[s.role] && y >= 1 && staffSkill(s) >= 66 && !s.pr28 && fresh && Math.random() < 0.04) {
        const to = nextRole(co, s);
        if (to) {
          co.sl28 = S.week; s.pr28 = S.week;
          const wage = rnl(Math.max(s.wage * 1.15, wageFor(to, co) * 0.95), 100);
          addMsg({ kind: 'ask', from: co.name, title: 'Promote ' + n.name + ' to ' + roleN(to).toLowerCase() + '?', body: n.name + ' started as ' + roleN(s.role).toLowerCase() + ' ' + y + ' year' + (y > 1 ? 's' : '') + ' ago and has learned the job next door. ' + first(n.name) + ' would earn ' + money(wage) + ' a month.', co: co.id, opts: [{ l: 'Promote ' + first(n.name), d: 'Loyal, motivated, and already knows the place.', fx: {} }, { l: 'Not yet', d: first(n.name) + ' may look elsewhere.', fx: {} }], act: 'st28pro', data: { co: co.id, s: s.id, to, wage }, exp: S.week + 3, tone: 'good' });
        }
      }
      /* retirement */
      if (ageOf(s, n) >= 67 && !s.ret28) {
        s.ret28 = S.week;
        addMsg({ kind: 'ask', from: n.name, title: n.name + ' is retiring', body: 'After ' + Math.max(1, y) + ' year' + (y > 1 ? 's' : '') + ' at ' + co.name + ', ' + first(n.name) + ' is retiring. ' + (s.st28.length > 2 ? 'From ' + s.st28[0].t.toLowerCase().replace(/^joined [^ ]+.*? as /, '') + ' to ' + roleN(s.role).toLowerCase() + '. ' : '') + 'How do you say goodbye?', co: co.id, opts: [{ l: 'A farewell party', d: money(KC(8000)) + '. The whole team comes.', fx: {} }, { l: 'A gift and a speech', d: money(KC(3000)) + '.', fx: {} }, { l: 'A card', d: '', fx: {} }], act: 'st28ret', data: { co: co.id, s: s.id }, exp: S.week + 2, tone: 'n' });
      }
      /* thank-you notes after a raise or a course */
      const raised = s.wl28 && s.wage >= s.wl28 * 1.04, crs = (s.crs || 0) > (s.cr28 || 0);
      if ((raised || crs) && S.week - (s.ty28 || -99) > 26 && fresh && Math.random() < 0.5) {
        s.ty28 = S.week; co.sl28 = S.week;
        const t = raised ? 'Thank you for the raise. It came at a good time for my family. I won\'t forget it.' : 'Thank you for sending me on the course. I already do the job better.';
        addMsg({ kind: 'info', from: n.name, role: roleN(s.role) + ', ' + co.name, title: 'A note from ' + n.name, body: t, co: co.id, tone: 'good', status: 'done' });
        story(s, raised ? 'Got a raise' : 'Took a course');
        co.mood = Math.min(100, (co.mood || 60) + 1);
      }
      s.wl28 = s.wage; s.cr28 = s.crs || 0;
      /* life */
      if (fresh && co.staff.length <= 40 && Math.random() < 0.0025) {
        const e = [['is getting married', 'Married'], ['has become a parent', 'Became a parent'], ['bought a first home', 'Bought a home']][Math.floor(Math.random() * 3)];
        co.sl28 = S.week;
        addMsg({ kind: 'ask', from: co.name, title: n.name + ' ' + e[0], body: 'Good news from ' + first(n.name) + ', ' + roleN(s.role).toLowerCase() + ' at ' + co.name + '.', co: co.id, opts: [{ l: 'Send a gift from the company', d: money(KC(1500)) + '.', fx: {} }, { l: 'Congratulate them', d: '', fx: {} }], act: 'st28life', data: { co: co.id, s: s.id, t: e[1] }, exp: S.week + 2, tone: 'good' });
      }
    });
    /* the manager */
    if (co.mgr && S.npcs[co.mgr] && co.mgrW0 != null) {
      const y = Math.floor((S.week - co.mgrW0) / 52);
      if ([5, 10, 15, 20].indexOf(y) >= 0 && (co.ma28 || 0) < y) { co.ma28 = y; info(co.name, S.npcs[co.mgr].name + ': ' + y + ' years running ' + co.name, (y >= 10 ? 'Few managers stay this long. ' : '') + 'Under ' + first(S.npcs[co.mgr].name) + ', ' + co.name + ' has become what it is.', co.id, 'good'); co.mood = Math.min(100, (co.mood || 60) + 4); }
    }
  }
  const getS = (m) => { const co = getCo(m.data.co); return { co, s: co && co.staff.find(x => x.id === m.data.s) }; };
  ACTS.st28ann = (m, idx) => {
    const { co, s } = getS(m);
    if (!s) return true;
    const n = S.npcs[s.id];
    if (idx === 0) { payCo(co, KC(4000) + co.staff.length * KC(400), 'oth', 'Anniversary party'); co.mood = Math.min(100, (co.mood || 60) + 6); story(s, m.data.y + ' years: a party with the whole team'); }
    else if (idx === 1) { payCo(co, s.wage, 'wages', 'Anniversary bonus'); co.mood = Math.min(100, (co.mood || 60) + 3); story(s, m.data.y + ' years: a bonus'); }
    else { co.mood = Math.min(100, (co.mood || 60) + 1); story(s, m.data.y + ' years: a card'); }
    s.loyal28 = (s.loyal28 || 0) + 1;
    return true;
  };
  ACTS.st28pro = (m, idx) => {
    const { co, s } = getS(m);
    if (!s) return true;
    if (idx === 0) {
      const from = roleN(s.role).toLowerCase();
      s.role = m.data.to; s.wage = m.data.wage; s.skillGain = (s.skillGain || 0) + 5; s.notice = 0;
      story(s, 'Promoted from ' + from + ' to ' + roleN(s.role).toLowerCase());
      co.mood = Math.min(100, (co.mood || 60) + 4);
      note(S.npcs[s.id].name + ' is now ' + roleN(s.role).toLowerCase() + ' at ' + co.name + '.', 'good', co.id);
    } else if (Math.random() < 0.25) s.notice = 1;
    return true;
  };
  ACTS.st28ret = (m, idx) => {
    const { co, s } = getS(m);
    if (!s) return true;
    const n = S.npcs[s.id], y = Math.max(1, Math.round((S.week - (s.w0 || S.week)) / 52));
    if (idx === 0) { payCo(co, KC(8000), 'oth', 'Farewell party'); co.mood = Math.min(100, (co.mood || 60) + 5); rep28(co, 1); }
    else if (idx === 1) { payCo(co, KC(3000), 'oth', 'Farewell gift'); co.mood = Math.min(100, (co.mood || 60) + 2); }
    S.hof28 = S.hof28 || [];
    S.hof28.unshift({ n: n ? n.name : 'A colleague', t: (s.st28 && s.st28.length > 2 ? s.st28[0].t.replace(/^Joined /, 'Started at ') + ', retired as ' + roleN(s.role).toLowerCase() : roleN(s.role) + ' at ' + co.name) + ' · ' + y + ' years · ' + wYear(S.week), w: S.week });
    if (S.hof28.length > 40) S.hof28.length = 40;
    fireStaff(co, s.id, 1);
    note((n ? n.name : 'A colleague') + ' has retired from ' + co.name + '. You need to hire a replacement.', 'n', co.id);
    return true;
  };
  ACTS.st28life = (m, idx) => {
    const { co, s } = getS(m);
    if (!s) return true;
    if (idx === 0) { payCo(co, KC(1500), 'oth', 'Gift to ' + S.npcs[s.id].name); co.mood = Math.min(100, (co.mood || 60) + 1.5); story(s, m.data.t + ' (the company sent a gift)'); }
    else story(s, m.data.t);
    return true;
  };
  function rep28(co, d) { co.rep = Math.max(0, Math.min(100, (co.rep || 50) + d)); }
  /* the worker's screen shows the story */
  V.staffman = pipeView('V.staffman', V.staffman, 1); /* V.staffman: the screen above, then the steps below and in later files */
  addStep('V.staffman', 10, 'the worker’s screen shows the story', (p, h) => {
    try {
      const co = getCo(p.id), s = co && co.staff.find(x => x.id === p.s);
      if (!s || !s.st28 || !s.st28.length) return h;
      return h + '<h2 class="sec">Their story</h2><div class="lrows">' + s.st28.slice().reverse().map(x => '<div class="lrow"><span class="ctext"><b class="wrap">' + esc(x.t) + '</b><small>' + dateStr(x.w) + '</small></span></div>').join('') + '</div>';
    } catch (e) { return h; }
  });

  /* ================= the nemesis ================= */
  const N = () => S.nem28;
  const NL = { loss: ['Better luck next time, {me}.', '{city} is my town. You will learn.', 'Nothing personal. Just business.', 'I have been doing this since {f0}. Keep up.', 'You make it easy for me, {me}.'], win: ['Fine. You held on this time.', 'Not bad, {me}. Not bad at all.', 'Enjoy it while it lasts.', 'I underestimated you. It will not happen twice.', 'Well played. See you next round.'] };
  function pickNem() {
    if (N() || !window.R27 || !R27.groupsIn || S.week < 10 || !live().length) return;
    /* round 37: nobody picks a fight with a newcomer; you have to matter first */
    if (!(R27.noticed && live().some(c => R27.noticed(c))) && live().filter(c => c.st === 'open').length < 3) return;
    const gs = R27.groupsIn(S.country).filter(g => !g.gone && !g.dist);
    const score = g => (R27.membersInMyMarkets(g).length * 3) + (live().some(c => g.types.indexOf(c.type) >= 0) ? 2 : 0) + (g.strat === 'acq' || g.strat === 'expand' || g.strat === 'cost' ? 1.5 : 0) + Math.log10(Math.max(1e6, g.rev)) / 4;
    const g = gs.sort((a, b) => score(b) - score(a))[0];
    if (!g || score(g) < 3) return;
    S.nem28 = { g: g.id, n: g.owner, since: S.week, w: 0, l: 0, log: [], pend: [], msg: -99, seen: 0 };
    const co = live().find(c => g.types.indexOf(c.type) >= 0) || live()[0];
    addMsg({ kind: 'info', from: g.owner + ', ' + g.name, title: 'A message from ' + g.owner, body: '"I hear you are in ' + BD[co.type].n.toLowerCase() + ' in ' + cityOf(co.city).name + ' now. Welcome to my market. Most newcomers do not last a year."', tone: 'bad', status: 'done', go: { l: 'Who is this?', a: 'go', p: { n: 'nem28' } } });
    pressAdd(5, g.owner + ' takes aim at ' + S.player.name, 'The owner of ' + g.name + ' has a new rival.');
  }
  function line(k) {
    const g = window.R27 && R27.G(N().g), co = live()[0];
    const L = NL[k];
    return L[Math.floor(Math.random() * L.length)].replace('{me}', first(S.player.name)).replace('{city}', co ? cityOf(co.city).name : 'This town').replace('{f0}', g ? g.f0 : 'forever');
  }
  function tally(k, t) {
    const nm = N();
    if (!nm) return;
    if (k === 'w') nm.w++; else if (k === 'l') nm.l++;
    nm.log.unshift({ w: S.week, k, t });
    if (nm.log.length > 30) nm.log.length = 30;
    if (k !== 'd') pressAdd(4, k === 'w' ? S.player.name + ' gets the better of ' + nm.n : nm.n + ' wins another round against ' + S.player.name, t + ' The score: ' + nm.w + '–' + nm.l + '.');
    if (k !== 'd' && S.week - nm.msg >= 6 && Math.random() < 0.7) {
      nm.msg = S.week;
      const g = R27.G(nm.g);
      addMsg({ kind: 'info', from: nm.n + (g ? ', ' + g.name : ''), title: k === 'w' ? nm.n + ' is not pleased' : nm.n + ' has something to say', body: '"' + line(k === 'w' ? 'win' : 'loss') + '"', tone: k === 'w' ? 'good' : 'bad', status: 'done', go: { l: 'The rivalry', a: 'go', p: { n: 'nem28' } } });
    }
  }
  R28.tally = tally;
  const coByName = nm => S.cos.find(c => nm.indexOf(c.name) >= 0 && (c.st === 'open' || c.st === 'sold'));
  function nemWeek() {
    pickNem();
    const nm = N();
    if (!nm || !window.R27) return;
    const g = R27.G(nm.g);
    if (!g) return;
    if (g.gone && !nm.gone) { nm.gone = S.week; tally('w', g.name + ' went bankrupt. You outlasted ' + nm.n + '.'); }
    /* their new moves */
    g.mv.filter(x => x.w === S.week && !x.n28).forEach(x => {
      x.n28 = 1;
      const t = x.t;
      if (/^Hired /.test(t)) tally('l', 'They hired your manager away.');
      else if (/^Tried to hire /.test(t)) { const co = coByName(t); if (co) nm.pend.push({ k: 'poach', co: co.id, mgr: co.mgr, w: S.week + 3 }); }
      else if (/^Cut prices/.test(t)) { const co = live().find(c => c.flags && c.flags.uc27 && c.flags.uc27.end > S.week && (rivalsOf(c) || []).some(r => r.id === c.flags.uc27.r && r.g27 === g.id)); if (co) nm.pend.push({ k: 'uc', co: co.id, r0: wk(co), w: co.flags.uc27.end + 1 }); }
      else if (/^Opened /.test(t)) { const co = coByName(t); if (co) nm.pend.push({ k: 'beside', co: co.id, r0: wk(co), w: S.week + 26 }); }
      else if (/^Bid /.test(t)) { const co = coByName(t); if (co) nm.pend.push({ k: 'bid', co: co.id, w: S.week + 4 }); }
      else if (/^Bought the supplier/.test(t)) tally('l', 'They bought one of your suppliers.');
      else if (/^Sold .* to you$/.test(t)) tally('w', 'You bought one of their sites.');
      else if (/^Bought .* from you$/.test(t)) tally('d', 'You sold them a company.');
      else if (/^Bought /.test(t)) tally('l', 'They bought a business in your market before you did.');
    });
    /* how earlier rounds ended */
    nm.pend = nm.pend.filter(p => {
      if (S.week < p.w) return true;
      const co = getCo(p.co);
      if (!co) return false;
      if (p.k === 'poach') { if (co.mgr && co.mgr === p.mgr) tally('w', 'Your manager at ' + co.name + ' turned them down.'); }
      else if (p.k === 'uc') { const r = wk(co); tally(r >= p.r0 * 0.93 ? 'w' : 'l', r >= p.r0 * 0.93 ? co.name + ' kept its customers through their price cut.' : 'Their price cut took customers from ' + co.name + '.'); }
      else if (p.k === 'beside') { const r = wk(co); tally(r >= p.r0 * 0.95 ? 'w' : 'l', r >= p.r0 * 0.95 ? co.name + ' is doing fine with them next door.' : 'Their new site next to ' + co.name + ' hurts.'); }
      else if (p.k === 'bid') { if (co.st === 'sold') tally('d', 'You sold ' + co.name + ' to them.'); else tally('w', 'You turned down their bid for ' + co.name + '.'); }
      return false;
    });
    /* each new year: who ranks higher */
    if (wYear(S.week) !== wYear(S.week - 1) && R27.ranked) {
      const L = R27.ranked('cc', 'rev'), me = L.find(e => e.me), them = L.find(e => e.id === g.id);
      if (me && them) tally(me.rk < them.rk ? 'w' : 'l', me.rk < them.rk ? 'You finished the year ahead of ' + g.name + ' (No. ' + me.rk + ' against No. ' + them.rk + ').' : g.name + ' finished the year ahead of you (No. ' + them.rk + ' against No. ' + me.rk + ').');
    }
  }
  V.titles.nem28 = 'Your rival';
  V.heads = V.heads || {};
  V.heads.nem28 = () => { const nm = N(), g = nm && R27.G(nm.g); return { t: nm ? nm.n : 'Your rival', sub: g ? esc(g.name) + ' · ' + esc(R27.STRAT[g.strat].n) : 'Nobody yet' }; };
  V.nem28 = function () {
    const nm = N();
    if (!nm) return '<div class="calm">No one has made it personal yet. Keep growing and someone will.</div>';
    const g = R27.G(nm.g);
    const lead = nm.w > nm.l ? 'You lead' : nm.w < nm.l ? 'They lead' : 'All square';
    let h = '<div class="card"><div class="cchd"><span class="av">' + esc(ini(nm.n)) + '</span><span class="ctext"><b>' + esc(nm.n) + '</b><small>Owner of ' + esc(g ? g.name : 'a group') + (g ? ' · ' + g.br + ' sites · since ' + g.f0 : '') + '</small></span>' + (g && g.gone ? pillp('Bankrupt', 'red') : pillp(lead, nm.w >= nm.l ? 'grn' : 'red')) + '</div><div class="score28"><div><b>' + nm.w + '</b><small>You</small></div><i>–</i><div><b>' + nm.l + '</b><small>' + esc(first(nm.n)) + '</small></div></div><span class="tipt">Rivals since ' + dateStr(nm.since) + '. A round is won when your business holds up against their move, or when you beat them to something.</span></div>';
    if (g) h += '<div class="lrows"><button class="lrow" data-a="go" data-p="' + P({ n: 'grp27', p: { g: g.id } }) + '"><span class="ctext"><b>' + esc(g.name) + '</b><small>See the group</small></span><i>›</i></button></div>';
    h += '<h2 class="sec">Rounds</h2><div class="lrows">' + (nm.log.length ? nm.log.map(x => '<div class="lrow"><span class="av ' + (x.k === 'w' ? 'me27' : '') + '">' + (x.k === 'w' ? 'W' : x.k === 'l' ? 'L' : '·') + '</span><span class="ctext"><b class="wrap">' + esc(x.t) + '</b><small>' + dateStr(x.w) + '</small></span></div>').join('') : '<div class="lrow"><small>No rounds yet.</small></div>') + '</div>';
    return h;
  };
  /* the rivalry sits at the top of the Rivals app */
  V.rivals = pipeView('V.rivals', V.rivals, 0); /* V.rivals: the screen above, then the steps below and in later files */
  addStep('V.rivals', 10, 'the rivalry sits at the top of the Rivals app', (h) => {
    const nm = N();
    if (!nm) return h;
    return '<button class="card opt2" data-a="go" data-p="' + P({ n: 'nem28' }) + '"><div class="bhead"><b>Your rival: ' + esc(nm.n) + '</b>' + pillp(nm.w + '–' + nm.l, nm.w >= nm.l ? 'grn' : 'red') + '</div><span class="tipt">' + esc(nm.log[0] ? nm.log[0].t : 'The rivalry has just begun.') + '</span></button>' + h;
  });

  /* ================= the business paper ================= */
  const PAPER = { NO: 'Kvartalsposten', SE: 'Kvartalet', DK: 'Kvartalet', PL: 'Bilans Tygodnia', LT: 'Savaitės Balansas', DE: 'Wirtschaftsbote', UK: 'The Counting House', FR: 'Le Bilan du Lundi', ES: 'El Balance', NL: 'De Weekbalans', US: 'The Weekly Ticker', CA: 'The Northern Ledger', AU: 'The Weekly Bottom Line', JP: 'The Tokyo Ledger', KR: 'The Seoul Ledger', BR: 'O Balanço Semanal', CH: 'Die Wochenbilanz', MX: 'El Balance Semanal', AE: 'The Gulf Ledger', IT: 'Il Bilancio', FI: 'Viikon Tase', IE: 'The Monday Ledger', SG: 'The Straits Ledger' };
  const paper = () => (window.R31 && R31.paperName ? R31.paperName() : null) || PAPER[S.country] || 'The Weekly Ledger';
  const PR = () => { S.pr28 = S.pr28 || { img: { trust: 50, bold: 50, care: 50 }, iss: [], cand: [], top: null, lastInt: -99, quote: null }; return S.pr28; };
  function pressAdd(pri, head, deck) { const p = PR(); p.cand.push({ pri, head, deck, w: S.week }); if (p.cand.length > 30) p.cand.splice(0, p.cand.length - 30); }
  R28.press = pressAdd;
  function issue() {
    const p = PR();
    const ach = S.ach28 || {};
    Object.keys(ach).forEach(k => { const a = ach[k]; if (a.w === S.week && !a.old && !a.pr) { a.pr = 1; const x = (R28.ACH || []).find(y => y[0] === k); if (x) pressAdd(k === 'cust' || k === 'emp' ? 2 : 3.5, S.player.name + ': ' + x[1].toLowerCase(), a.t); } });
    /* group moves in your country */
    if (window.R27 && S.g27) Object.values(S.g27.g).forEach(g => g.mv.filter(x => x.w === S.week && !x.p28 && (x.cc === S.country || g.cc === S.country)).forEach(x => { x.p28 = 1; pressAdd(/you|next to|for /.test(x.t) ? 3 : 1.5, g.name + ': ' + x.t.charAt(0).toLowerCase() + x.t.slice(1), 'Owner ' + g.owner + '. ' + (R27.STRAT[g.strat] ? R27.STRAT[g.strat].d : '')); }));
    (S.news || []).slice(0, 6).filter(n => n.w === S.week).forEach(n => pressAdd(1, n.t, ''));
    if (p.quote) { pressAdd(4.5, sur() + ': "' + p.quote + '"', 'An interview with ' + S.player.name + '.'); p.quote = null; }
    const C = p.cand.filter(c => S.week - c.w <= 1).sort((a, b) => b.pri - a.pri);
    p.cand = [];
    if (!C.length) return;
    p.iss.unshift({ w: S.week, head: C[0].head, deck: C[0].deck, side: C.slice(1, 5).map(c => c.head) });
    if (p.iss.length > 12) p.iss.length = 12;
  }
  function top50() {
    if (!window.R27 || !R27.ranked) return;
    const L = R27.ranked('cc', 'rev'), me = L.find(e => e.me);
    const p = PR();
    p.top = { y: wYear(S.week) - 1, list: L.slice(0, 50).map(e => ({ n: e.name, r: Math.round(e.rev), me: e.me ? 1 : 0, g: e.g ? e.g.id : 0, t: e.types ? e.types.slice(0, 2).map(t => BD[t] ? BD[t].n : t).join(', ') : '' })), rk: me ? me.rk : null, of: L.total || L.length };
    if (!me) return;
    const on = me.rk <= 50;
    addMsg({ kind: 'info', from: paper(), title: 'The Top 50 of ' + p.top.y + (on ? ': you are No. ' + me.rk : ' is out'), body: on ? 'You made the list of the 50 biggest companies in ' + (CO[S.country] || CC()).name + '.' : 'You are not on the list yet. You are No. ' + me.rk + ' by sales.', tone: on ? 'good' : 'n', status: 'done', go: { l: 'See the list', a: 'go', p: { n: 'top28' } } });
    pressAdd(on ? 5 : 2, 'The Top 50 of ' + p.top.y + ' is out', on ? S.player.name + ' at No. ' + me.rk + '.' : '');
  }
  /* interviews */
  const QS = [
    { c: () => N(), q: () => N().n + ' says you will not last. What do you say to that?', a: [['Let the results speak', 'trust', 'We keep our heads down and do good work. Results speak.'], ['We will be number one', 'bold', 'By this time next year, we will be the ones they chase.'], ['Our people are why we last', 'care', 'Our people are the reason we will be here in twenty years.']] },
    { c: () => live().some(c => (c.hist || []).slice(-3).reduce((t, x) => t + x.profit, 0) < 0), q: () => 'One of your companies is losing money. What went wrong?', a: [['Admit the mistakes', 'trust', 'We got some things wrong, and we are fixing them.'], ['It is an investment', 'bold', 'Every big business loses money on the way up.'], ['We will not cut jobs', 'care', 'We will turn it around without laying people off.']] },
    { c: () => live().length >= 2, q: () => 'You have grown fast. What is next?', a: [['Steady growth, no drama', 'trust', 'One step at a time, and we pay our bills.'], ['Bigger, faster, abroad', 'bold', 'We are just getting started. Watch this space.'], ['Better jobs in this town', 'care', 'More good jobs here, and giving something back.']] },
    { c: () => true, q: () => 'What is the secret of your business?', a: [['Honest prices', 'trust', 'Fair prices and we keep our promises.'], ['Outwork everyone', 'bold', 'We simply work harder than the competition.'], ['Happy staff, happy customers', 'care', 'Treat your people well and they treat the customers well.']] }
  ];
  function maybeInterview() {
    const p = PR();
    if (S.week - p.lastInt < 13 || !live().length || S.week < 16 || Math.random() > 0.3) return;
    p.lastInt = S.week;
    const q = QS.find(x => { try { return x.c() && Math.random() < 0.7; } catch (e) { return false; } }) || QS[QS.length - 1];
    const qi = QS.indexOf(q);
    addMsg({ kind: 'ask', from: 'A reporter at ' + paper(), title: paper() + ' wants an interview', body: '"' + q.q() + '"', opts: q.a.map(a => ({ l: a[0], d: '"' + a[2] + '"', fx: {} })).concat([{ l: 'No comment', d: 'Safer, but it looks like you are hiding something.', fx: {} }]), act: 'pr28int', data: { q: qi }, exp: S.week + 2, tone: 'n' });
  }
  ACTS.pr28int = (m, idx) => {
    const p = PR(), q = QS[m.data.q], a = q && q.a[idx];
    if (!a) { p.img.trust = Math.max(0, p.img.trust - 2); return true; }
    p.img[a[1]] = Math.min(100, p.img[a[1]] + 7);
    ['trust', 'bold', 'care'].filter(k => k !== a[1]).forEach(k => { p.img[k] = Math.max(0, p.img[k] - 1); });
    p.quote = a[2];
    if (a[1] === 'bold') live().forEach(c => { c.aware = Math.min(100, (c.aware || 0) + 2); });
    if (a[1] === 'care') live().forEach(c => { if (c.mgr || c.staff.length) c.mood = Math.min(100, (c.mood || 60) + 2); (c.holders || []).forEach(h => { h.sat = Math.max(0, (h.sat || 60) - 1); }); });
    if (a[1] === 'trust') { S.credit = Math.min(100, (S.credit || 60) + 1); live().forEach(c => (c.holders || []).forEach(h => { h.sat = Math.min(100, (h.sat || 60) + 2); })); }
    return true;
  };
  const imgWord = () => { const i = PR().img; const k = Object.keys(i).sort((a, b) => i[b] - i[a])[0]; return i[k] < 55 ? 'Not well known yet' : { trust: 'Seen as trustworthy', bold: 'Seen as bold', care: 'Seen as caring' }[k]; };
  R28.imgWord = imgWord;
  /* the local paper (Phone › News › the paper); News itself is ui/screens/mockup.js V.news */
  R28.frontPage = () => PR().iss[0] || null;
  V.titles.paper40 = 'The paper';
  V.paper40 = function () {
    const pr = PR(), I = pr.iss[0];
    let h = '<div class="card paper28"><div class="mast28"><b>' + esc(paper()) + '</b><small>' + (I ? dateStr(I.w) : dateStr(S.week)) + ' · business weekly</small></div>' + (I ? '<h2>' + esc(I.head) + '</h2>' + (I.deck ? '<p class="lead">' + esc(I.deck) + '</p>' : '') + (I.side.length ? '<div class="side28">' + I.side.map(x => '<p>' + esc(x) + '</p>').join('') + '</div>' : '') : '<p class="muted">A quiet week. Nothing made the front page.</p>') + '</div>';
    const i = pr.img;
    h += '<h2 class="sec">How people see you</h2><div class="card"><div class="bhead"><b>' + esc(imgWord()) + '</b></div>' + [['trust', 'Trust'], ['bold', 'Boldness'], ['care', 'Care']].map(x => '<div class="kv"><span>' + x[1] + '</span><span style="flex:1;margin:0 10px"><div class="bar"><i style="width:' + i[x[0]] + '%;background:var(--amber)"></i></div></span><b>' + Math.round(i[x[0]]) + '</b></div>').join('') + '<span class="tipt">Shaped by what you say in interviews and what you give back. Trust helps with lenders and co-owners, boldness gets you noticed, care keeps your people.</span></div>';
    if (pr.top) h += '<div class="lrows"><button class="lrow" data-a="go" data-p="' + P({ n: 'top28' }) + '"><span class="ctext"><b>The Top 50 of ' + pr.top.y + '</b><small>' + (pr.top.rk && pr.top.rk <= 50 ? 'You are No. ' + pr.top.rk : 'You are not on it yet') + '</small></span><i>›</i></button></div>';
    if (pr.iss.length > 1) h += '<h2 class="sec">Earlier front pages</h2><div class="lrows">' + pr.iss.slice(1, 8).map(x => '<div class="lrow"><span class="ctext"><b class="wrap">' + esc(x.head) + '</b><small>' + dateStr(x.w) + '</small></span></div>').join('') + '</div>';
    return h;
  };
  V.titles.top28 = 'Top 50';
  V.heads.top28 = () => { const t = PR().top; return { t: 'The Top 50', sub: t ? esc(paper()) + ' · ' + t.y : '' }; };
  V.top28 = function () {
    const t = PR().top;
    if (!t) return '<div class="calm">The list comes out every January.</div>';
    return '<div class="lrows">' + t.list.map((e, i) => '<' + (e.g ? 'button class="lrow' + (e.me ? ' on' : '') + '" data-a="go" data-p="' + P({ n: 'grp27', p: { g: e.g } }) + '"' : 'div class="lrow' + (e.me ? ' on' : '') + '"') + '><span class="rk27n">' + (i + 1) + '</span><span class="av' + (e.me ? ' me27' : '') + '">' + esc(ini(e.n)) + '</span><span class="ctext"><b>' + esc(e.n) + (e.me ? ' <small>(you)</small>' : '') + '</b><small>' + esc(e.t) + '</small></span><b>' + mshort(e.r) + '</b></' + (e.g ? 'button' : 'div') + '>').join('') + '</div>' + (t.rk > 50 ? '<p class="muted small">You: No. ' + t.rk + ' of ' + t.of + '.</p>' : '');
  };
  addStep('week.after', 55, 'staff_stories_and_nemesis weekly', () => {
    try {
      S.cos.forEach(staffWeek);
      /* nobody answered: the quiet default */
      S.inbox.forEach(m => { if (!m.auto || m.done28) return; const d = { st28ann: 2, st28pro: 1, st28ret: 2, st28life: 1 }[m.act]; if (d == null) return; m.done28 = 1; try { ACTS[m.act](m, d); } catch (e) { console.error(e); } });
      nemWeek();
      maybeInterview();
      if (wYear(S.week) !== wYear(S.week - 1)) top50();
      issue();
    } catch (e) { console.error(e); }
  });
})();


/* ===== Seasons and hours (round 54): plan the year, seasonal staff, and hours that follow demand.
   - Every trade has its own year (SEAS, plus a trade's own peak such as Christmas parcels): the Staff tab shows which
     seasons are busy and which are quiet, so you can plan ahead.
   - Seasonal workers are hired for the seasons you choose. In those months they work and are paid by the hour like
     part-timers (they are in the staff list and in wages); between seasons they are off and unpaid, and they come back
     the next year. A seasonal worker can be offered a part-time job all year.
   - A manager plans next week's hours for everyone paid by the hour (part-time, seasonal, full-time on an hourly wage)
     from what the last weeks sold, the season ahead and the same weeks last year; a better manager guesses closer.
     A manager also brings in seasonal help before a busy season when people are what holds the business back.
   Pay basis, hours and pay talks themselves are in engine/people/people.js. ===== */
window.R54 = window.R54 || {};
(function () {
  'use strict';
  const R54 = window.R54;
  const U = window.UI;
  if (!U) return;
  const { ui, ACT, esc, render, go, save, toast, btn } = U;
  const CT = window.CT;
  const P = o => esc(JSON.stringify(o));
  const MON = ['', 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  const SEASONS = [['winter', 'Winter', [1, 2]], ['spring', 'Spring', [3, 4, 5]], ['summer', 'Summer', [6, 7, 8]], ['autumn', 'Autumn', [9, 10]], ['xmas', 'Christmas', [11, 12]]];
  R54.SEASONS = SEASONS;
  const mon = w => wMonth(w) + 1;

  /* ---------- the year of a trade ---------- */
  /* demand in a month compared with an average month: the trade's seasons, and its own peak (Christmas parcels...) */
  function monthF(co, m) {
    const bd = BD[co.type];
    let f = SEAS[bd.seas] ? SEAS[bd.seas][m - 1] : 1;
    const pk = window.R33 && R33.ways ? R33.ways(co).find(w => w[0] === 'peak') : null;
    if (pk && pk[3] && (pk[3].m || []).indexOf(m) >= 0) f *= 1 + (pk[3].b || 0.3);
    return f;
  }
  const seasonF = (co, ms) => ms.reduce((t, m) => t + monthF(co, m), 0) / ms.length;
  const word = f => f >= 1.25 ? 'Busiest' : f >= 1.08 ? 'Busy' : f > 0.93 ? 'Normal' : f > 0.8 ? 'Quieter' : 'Quiet';
  /* the busy months of a trade: the ones a seasonal worker is for */
  const busyMonths = co => { const L = []; for (let m = 1; m <= 12; m++) if (monthF(co, m) >= 1.08) L.push(m); return L; };
  /* the seasons a set of months covers, in words */
  const seasText = ms => {
    const names = SEASONS.filter(s => s[2].every(m => ms.indexOf(m) >= 0)).map(s => s[1]);
    const rest = ms.filter(m => !SEASONS.some(s => s[2].every(x => ms.indexOf(x) >= 0) && s[2].indexOf(m) >= 0));
    return names.concat(rest.map(m => MON[m])).join(', ') || 'no months yet';
  };
  const nextMonthOf = ms => { const m0 = mon(S.week); for (let i = 1; i <= 12; i++) { const m = (m0 - 1 + i) % 12 + 1; if (ms.indexOf(m) >= 0) return m; } return 0; };
  R54.monthF = monthF; R54.busyMonths = busyMonths; R54.seasText = seasText; R54.seasonWord = (co, ms) => word(seasonF(co, ms));

  /* ---------- seasonal staff come and go ---------- */
  function seasonsTurn(co) {
    const m = mon(S.week);
    const back = [], gone = [];
    co.staff.forEach(s => {
      if (!s.seas) return;
      const on = s.seas.indexOf(m) >= 0;
      if (on && s.off) { s.off = false; back.push(s); }
      else if (!on && !s.off) { s.off = true; gone.push(s); }
    });
    const nm = s => (S.npcs[s.id] || { name: 'A seasonal worker' }).name;
    if (back.length) note((back.length === 1 ? nm(back[0]) + ' is' : back.length + ' seasonal workers are') + ' back at ' + co.name + ' for the season.', 'n', co.id);
    if (gone.length) note((gone.length === 1 ? nm(gone[0]) + ' has' : gone.length + ' seasonal workers have') + ' finished the season at ' + co.name + ' and will be back ' + (nextMonthOf(gone[0].seas) ? 'in ' + MON[nextMonthOf(gone[0].seas)] : 'next year') + '.', 'n', co.id);
  }

  /* ---------- demand history and the manager's guess for next week ---------- */
  function remember(co) {
    const w = co.lastW;
    if (!w || w.D == null || co.st !== 'open') return;
    co.dh = (co.dh || []).concat([Math.round(w.D * 10) / 10]).slice(-60);
  }
  function forecast(co) {
    const H = co.dh || [];
    if (H.length < 2) return null;
    const rec = H.slice(-4), base = rec.reduce((a, b) => a + b, 0) / rec.length;
    const now = monthF(co, mon(S.week - 2)), next = monthF(co, mon(S.week));
    let F = base * next / Math.max(0.2, now);
    /* the same weeks last year show the shape of the season, if the business was open then */
    if (H.length >= 56) {
      const ly = H[H.length - 52], lyBefore = H.slice(-56, -52).reduce((a, b) => a + b, 0) / 4;
      if (lyBefore > 0) F = 0.5 * F + 0.5 * base * ly / lyBefore;
    }
    const q = mgrQual(co);
    return Math.max(0, F * (1 + gauss() * 0.22 * (1 - q)));
  }
  R54.forecast = forecast;
  /* hours for next week: aim at about nine tenths busy. More hours only help when people are what holds the business
     back; fewer hours always save money. Part-timers and seasonal staff move between 8 h and what they can work,
     full-timers on an hourly wage between 30 and 45 h. Changes are at most a third of the hours in one week. */
  function planHours(co) {
    const w = co.lastW || {};
    if (!w.cap || co.st !== 'open') return;
    const F = forecast(co);
    if (F == null) return;
    const H = co.staff.filter(s => !s.off && !s.notice && s.basis === 'hour' && payFollowsHours(s));
    if (!H.length) return;
    const ftes = co.staff.filter(s => !s.off).reduce((t, s) => t + (s.pt || 1), 0) + (co.ohrs && !co.mgr ? co.ohrs / FULL_H : 0);
    const per = w.cap / Math.max(0.5, ftes);
    const bo = (co.dbg || {}).botObj, staffBound = bo && bo.kind === 'staff';
    const hNow = H.reduce((t, s) => t + weekHours(s), 0);
    let dH = (F / 0.9 - w.cap) / per * FULL_H;
    if (dH > 0 && !staffBound) dH = 0;
    dH = clamp(dH, -hNow / 3, hNow / 3);
    let left = dH;
    H.forEach(s => {
      const h0 = weekHours(s), top = (s.tired || 0) > 50 ? 38 : 45, lo = s.hrs ? 8 : 30, hi = s.hrs ? Math.min(s.maxH || 45, top) : top; /* a tired person gets a normal week */
      const h = clamp(Math.round(h0 + dH * h0 / hNow), lo, hi);
      if (h !== h0) { setWeekHours(co, s, h); left -= h - h0; }
    });
    co.hp54 = { w: S.week, F: Math.round(F), h: Math.round(H.reduce((t, s) => t + weekHours(s), 0)), n: H.length };
  }
  R54.planHours = planHours;

  /* ---------- seasonal help: hiring ---------- */
  function hireSeasonal(co, role, months, n, hrs) {
    let got = 0;
    for (let i = 0; i < (n || 1); i++) {
      const cs = searchWorkers(co, role, 'network').sort((a, b) => a.ask - b.ask);
      const c = cs[Math.floor(cs.length * 0.4)];
      if (!c) break;
      HIRE_SEAS = months; HIRE_HOURS = hrs || 25;
      let r;
      try { r = hireWorker(co, c, rnl(c.ask * 1.03, 100)); } finally { HIRE_SEAS = null; HIRE_HOURS = 0; }
      if (r === 'ok') { got++; const s = co.staff[co.staff.length - 1]; if (s && window.managerOnboard && co.mgr) managerOnboard(co, s); }
    }
    return got;
  }
  R54.hireSeasonal = hireSeasonal;
  /* the job seasonal help does: whatever people job holds the business back, else the first job of the trade */
  const helpRole = co => {
    const bo = (co.dbg || {}).botObj;
    if (bo && bo.kind === 'staff' && ROLES[bo.k.split(':')[1]]) return bo.k.split(':')[1];
    const std = BD[co.type].std || [];
    return std.length && ROLES[std[0][0]] ? std[0][0] : null;
  };
  R54.helpRole = helpRole;
  /* a manager brings in seasonal help a few weeks before a busy season, if people are what holds the business back */
  function mgrSeason(co) {
    if (!co.mgr || co.st !== 'open' || S.week % 2) return;
    const ms = busyMonths(co), m3 = mon(S.week + 3);
    if (ms.indexOf(m3) < 0 || ms.indexOf(mon(S.week)) >= 0) return;
    if (co.staff.some(s => s.seas && s.seas.indexOf(m3) >= 0)) return;
    const role = helpRole(co), w = co.lastW || {};
    if (!role || !w.cap) return;
    const lift = monthF(co, m3) / Math.max(0.2, monthF(co, mon(S.week))) - 1;
    const need = Math.round(co.staff.filter(s => !s.seas).length * Math.max(0, lift));
    if (need < 1) return;
    const cost = wageFor(role, co) * 0.67 * 12 * OC();
    if (typeof hireShort === 'function' && hireShort(co, cost * ms.length / 12) > 0) return;
    const got = hireSeasonal(co, role, ms, Math.min(4, need), 25);
    if (got) note((S.npcs[co.mgr] ? S.npcs[co.mgr].name : 'Your manager') + ' hired ' + got + ' seasonal ' + (got > 1 ? 'workers' : 'worker') + ' for the busy ' + seasText(ms) + ' months at ' + co.name + '.', 'n', co.id);
  }

  addStep('weekCo.before', 30, 'seasonal staff come and go; a manager plans the hours', (co) => {
    if (!co.staff || co.type === 'hold') return;
    seasonsTurn(co);
    if (co.mgr && S.npcs[co.mgr]) { mgrSeason(co); planHours(co); }
  });
  addStep('weekCo.after', 30, 'remember the demand of the week', (co) => { remember(co); }, true);

})();

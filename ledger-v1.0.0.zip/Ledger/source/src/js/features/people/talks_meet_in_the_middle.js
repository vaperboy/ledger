/* ===== Round 40: talks that meet in the middle, prompts that tell you what happened.
   - Salary talks: each candidate has a private floor; a fair offer gets a counter halfway, not a flat no. A 19-year-old
     with no rent to pay bends more than a driven senior with a family. The profile opens on top of the chat.
   - Until needed stops at every new decision, problem, unlock or celebration, and ticks slower.
   - After you answer a prompt, a short "What happened" card shows what your choice changed. Interviews raise how
     well known your companies are. No answer is highlighted as the right one. ===== */
window.R40 = window.R40 || {};
(function () {
  'use strict';
  const R40 = window.R40;
  const U = window.UI;
  if (!U) return;
  const { ui, V, ACT, esc, row, btn, card, go, render, save, svg, openSheet, closeSheet, toast } = U;
  const live = () => S.cos.filter(c => c.st !== 'sold' && c.st !== 'bust');

  /* ================= salary talks ================= */
  const hsh = s => { let h = 2166136261; s = String(s); for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return (h >>> 0) / 4294967296; };
  /* the lowest monthly pay this person would take, and how patient they are */
  function floorOf(n) {
    if (n.min40 != null) return n.min40;
    const age = n.age || 30, r = hsh(n.id + ':f');
    let f = 0.91;
    if (age <= 22) f = 0.83;
    else if (age <= 27) f = 0.87;
    else if (age >= 45) f = 0.94;
    if (n.pers === 'driven' || n.pers === 'arrogant') f += 0.04;
    if (n.pers === 'loyal' || n.pers === 'steady') f -= 0.02;
    if (n.pers === 'restless') f += 0.01;
    f += (r - 0.5) * 0.04;
    n.min40 = rnl(n.ask * Math.min(0.99, Math.max(0.78, f)), 100);
    return n.min40;
  }
  R40.floorOf = floorOf;
  const lenient = n => (n.age || 30) <= 24 || n.pers === 'loyal' || n.pers === 'steady';
  const talk = id => ((ui.talk = ui.talk || {})[id] = (ui.talk || {})[id] || []);
  addStep('ACT.offer.around', 50, 'talks_meet_in_the_middle ACT.offer', (p, next) => {
    const co = getCo(p.id), n = S.npcs[p.n];
    if (!co || !n) return next();
    const plan = SALES_ROLES[n.role] && ui.pay && ui.pay[n.id];
    if (plan && plan.m !== 'fix') return next();
    if (n.gone) { toast(n.name + ' has taken another job.', true); return; }
    if (n.hired) return;
    const w = rnl(U.inum('w' + n.id, n.ask), 100);
    const L = talk(n.id);
    L.push({ me: 1, t: 'I can offer ' + money(w) + ' a month.' });
    const max = n.pers === 'driven' ? 2 : n.pers === 'loyal' || n.pers === 'steady' ? 4 : 3;
    if (n.pat == null) n.pat = max;
    const cur = n.cur40 || n.ask, flo = floorOf(n);
    const accept = () => {
      const a0 = n.ask;
      n.ask = w;
      const r = hireWorker(co, n, w);
      n.ask = a0;
      if (r === 'ok') {
        L.push({ me: 0, t: w >= cur ? 'Deal. I can start right away.' : 'All right, we have a deal. I can start right away.' });
        toast(n.name + ' accepted. Complete the paperwork under People.');
        ui.hrole = null;
        ui.stack.length && ui.stack.pop();
        ui.view = { n: 'co', p: { id: co.id, t: 'st' } };
        save();
        render(true);
        return;
      }
      U.res(r);
    };
    if (w >= cur || (n.cnt40 && w >= n.cnt40)) return accept();
    if (w >= flo) {
      /* a fair offer: meet in the middle, and close the gap once it is small */
      const mid = rnl((w + cur) / 2, 100);
      if (cur - w <= n.ask * 0.03 || (n.cnt40 && lenient(n))) return accept();
      n.cnt40 = n.cur40 = mid;
      L.push({ me: 0, t: lenient(n) ? 'That is close. Could we meet in the middle at ' + money(mid) + '?' : 'I was hoping for more. Meet me at ' + money(mid) + ' and we have a deal.' });
    } else if (w >= flo * 0.92) {
      const ct = Math.max(flo, rnl((w + cur) / 2, 100));
      n.cnt40 = n.cur40 = ct;
      n.pat -= lenient(n) ? 0.5 : 1;
      L.push({ me: 0, t: 'That is below what I can live on. I could do ' + money(ct) + '.' });
    } else {
      n.pat -= lenient(n) ? 1 : 2;
      L.push({ me: 0, t: 'That is too far from what I need. I am asking ' + money(cur) + '.' });
    }
    if (n.pat <= 0) {
      n.gone = 1;
      L.push({ me: 0, t: 'I have accepted another offer. Good luck.' });
      ui.cand = null;
      toast(n.name + ' is no longer interested.', true);
    }
    save();
    render();
  });

  /* (Until needed's stop rules live in features/people/managers_who_manage.js window.untlStop) */

  /* ================= what your answer did ================= */
  function snap() {
    const cos = {};
    live().forEach(c => { cos[c.id] = { aware: c.aware || 0, rep: c.rep || 0, mood: c.mood != null ? c.mood : 60, cash: c.cash || 0, q: c.q || 0 }; });
    const img = S.pr28 && S.pr28.img ? Object.assign({}, S.pr28.img) : null;
    return { cash: S.cash, cos, img, credit: S.credit || 0, ev: S.rep && S.rep.ev ? S.rep.ev.length : 0, loanCut: S.net31 && S.net31.loanCut ? S.net31.loanCut.until : 0 };
  }
  function changes(a, b) {
    const out = [];
    const d = b.cash - a.cash;
    if (Math.abs(d) >= 1) out.push(['Your cash', (d > 0 ? '+' : '−') + mshort(Math.abs(d)), d > 0 ? 'pos' : 'neg']);
    Object.keys(b.cos).forEach(id => {
      const x = a.cos[id], y = b.cos[id], co = getCo(+id) || getCo(id);
      if (!x || !co) return;
      const dc = y.cash - x.cash;
      if (Math.abs(dc) >= 1) out.push([co.name + ' cash', (dc > 0 ? '+' : '−') + mshort(Math.abs(dc)), dc > 0 ? 'pos' : 'neg']);
      if (y.aware - x.aware >= 0.5) out.push([co.name, 'More people know it', 'pos']);
      if (x.aware - y.aware >= 0.5) out.push([co.name, 'Fewer people know it', 'neg']);
      if (y.rep - x.rep >= 0.5) out.push([co.name, 'Better reputation', 'pos']);
      if (x.rep - y.rep >= 0.5) out.push([co.name, 'Reputation hurt', 'neg']);
      if (y.mood - x.mood >= 1) out.push([co.name, 'Staff happier', 'pos']);
      if (x.mood - y.mood >= 1) out.push([co.name, 'Staff unhappier', 'neg']);
      if (y.q - x.q >= 0.5) out.push([co.name, 'Better quality', 'pos']);
    });
    if (a.img && b.img) {
      const W = { trust: 'trustworthy', bold: 'bold', care: 'caring' };
      Object.keys(W).forEach(k => { const dd = (b.img[k] || 0) - (a.img[k] || 0); if (dd >= 2) out.push(['People see you as', 'more ' + W[k], 'pos']); else if (dd <= -2) out.push(['People see you as', 'less ' + W[k], 'neg']); });
    }
    if (b.credit - a.credit >= 1) out.push(['Your bank', 'Trusts you a little more', 'pos']);
    if (b.loanCut > a.loanCut) out.push(['Your loans', 'Half a point cheaper until ' + dateStr(b.loanCut), 'pos']);
    return out;
  }
  ACT.msgpick = pipeView('ACT.msgpick', ACT.msgpick, 1);
  addStep('ACT.msgpick.around', 10, 'talks_meet_in_the_middle ACT.msgpick', (p, next) => {
    const m = S.inbox.find(x => x.id === p.id);
    if (!m || m.status !== 'open') return next();
    const o = m.opts && m.opts[p.i];
    const a = snap();
    const sp = window.showPop;
    let shown = false;
    /* run the original, but show the result before the next prompt */
    window.showPop = function () { };
    try { next(); } finally { window.showPop = sp; }
    if (m.status === 'open') return; /* cancelled or waiting for a confirmation */
    const b = snap();
    const ch = changes(a, b), notes = S.rep && S.rep.ev ? S.rep.ev.slice(a.ev).map(x => x.t).slice(0, 4) : [];
    if (!ch.length && !notes.length) { if (sp) sp(true); return; }
    shown = true;
    openSheet('<div class="out40"><small>You chose</small><h2>' + esc(o ? o.l : 'Done') + '</h2>' + (notes.length ? '<div class="note">' + notes.map(esc).join('<br>') + '</div>' : '') + (ch.length ? '<div class="card">' + ch.map(x => row(esc(x[0]), '<span class="' + x[2] + '">' + esc(x[1]) + '</span>')).join('') + '</div>' : '') + btn('Continue', 'out40ok', undefined, 'primary wide') + '</div>', 'out40s');
  });
  ACT.out40ok = () => { closeSheet(); if (window.showPop) window.showPop(true); };

  /* ================= interviews and press favours do something you can see ================= */
  if (ACTS.pr28int) {
    ACTS.pr28int = pipeView('ACTS.pr28int', ACTS.pr28int, 2);
    addStep('ACTS.pr28int.around', 10, '================= interviews and press favours do something you can see =================', (m, idx, next) => {
      const r = next();
      try {
        const said = m.opts && idx < m.opts.length - 1;
        if (said) live().forEach(c => { c.aware = Math.min(100, (c.aware || 0) + 3); });
        note(said ? 'Your interview runs in ' + (window.R31 && R31.paperName ? R31.paperName() : 'the paper') + ' this week. More people have heard of your companies.' : 'You said no comment. The paper ran the story without you.', said ? 'good' : 'n');
      } catch (e) { }
      return r;
    });
  }
})();


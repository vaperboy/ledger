/* ===== V.1.0.0: owner attention. A company a manager runs keeps going and earns, but it grows by your decisions,
   and a manager nobody checks on slowly lets things slide. From two months after your last meeting with them
   (co.meetW, set by every meeting in engine/management/meetings.js) the manager works a little worse and service
   slips; after about half a year without a meeting it is about a tenth worse. One meeting puts it right at once.
   Store managers with a chain or regional manager above them slip at half the pace: their boss checks on them.
   Where you see it: the manager line on the company (ui/company/view.js CT.mgrBanner), the Next line on Home
   (features/player/next_step.js), and Until needed stops once when a company starts to slip
   (features/people/managers_who_manage.js window.untlStop). Companies you run yourself never slip: you are there. ===== */
window.OA59 = window.OA59 || {};
(function () {
  const O = window.OA59, U = window.UI, { ui, ACT, toast, save, render } = U;
  const GRACE = 8, RATE = 0.005, MAX = 0.12;
  const managed = co => !!(co && co.mgr && S.npcs[co.mgr] && co.st === 'open' && co.type !== 'hold' && BD[co.type].fam !== 'club');
  /* weeks since you last met the manager (or since they started) */
  O.since = co => S.week - Math.max(co.meetW != null ? co.meetW : -1e9, co.mgrW0 != null ? co.mgrW0 : (co.wOpen || 0));
  const hasBoss = co => { try { return chainOf(co).some(x => x.kind !== 'mgr'); } catch (e) { return false; } };
  O.drift = co => {
    if (!managed(co)) return 0;
    const w = O.since(co) - GRACE;
    return w <= 0 ? 0 : Math.min(MAX, w * RATE * (hasBoss(co) ? 0.5 : 1));
  };
  O.word = co => {
    const d = O.drift(co), s = O.since(co);
    return d <= 0 ? (s <= 4 ? 'you met recently' : 'on top of things') : d < 0.04 ? 'a little slack lately' : d < 0.08 ? 'things are slipping' : 'drifting badly';
  };
  addStep('mgrQual', 50, 'owner attention: a manager left alone slips', (co, q) => { const d = O.drift(co); return d ? q * (1 - d) : q; });
  addStep('demand', 96, 'owner attention: service slips when nobody checks in', (co, bd, r) => { const d = O.drift(co); if (d && r && r.D) r.D *= 1 - d * 0.5; });
  /* companies whose manager is due a meeting */
  O.due = () => S.cos.filter(c => managed(c) && O.since(c) >= GRACE);
  /* Until needed stops once per company each time it starts to slip */
  O.untlWhy = () => {
    const c = O.due().find(x => x.oa59 !== (x.meetW != null ? x.meetW : -1));
    if (!c) return '';
    c.oa59 = c.meetW != null ? c.meetW : -1;
    return 'time to meet the manager of ' + c.name;
  };
  /* the meeting in one tap: a casual review with one manager, or with every manager you have not seen lately */
  ACT.oa59meet = p => {
    /* a chain: its store managers (features/company/chain_registration_and_boards.js) */
    if (p && p.ch) {
      const ch = R12.chainById(p.ch), L = ch ? R12.storesOf(ch).filter(c => c.mgr && S.npcs[c.mgr]) : [];
      const n = L.filter(c => callMeeting(c.id, 'review', 'casual') === 'ok').length;
      if (n) { save(); toast('Met ' + n + (n === 1 ? ' store manager' : ' store managers') + '. Their news is in Messages.'); render(); }
      else toast(L.length ? 'You met them recently. Give it a few weeks.' : 'No store managers yet.', true);
      return;
    }
    const r = callMeeting(p && p.id ? p.id : 'all', 'review', 'casual');
    if (r === 'ok') { save(); toast('Met ' + (p && p.id ? 'the manager' : 'your managers') + '. Their news is in Messages.'); render(); }
    else toast(r === 'wait' ? 'You met recently. Give it a few weeks.' : 'No manager to meet.', true);
  };
})();

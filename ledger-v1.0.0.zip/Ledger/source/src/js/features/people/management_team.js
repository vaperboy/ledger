/* ===== Round 56: a management team in each company.
   Above the manager who runs the day-to-day, a bigger company can hire, on its own payroll:
   - a managing director (CEO in some countries), from 20 people (8 in banks, insurers, funds, airlines, shipping,
     oil and gas, hotels, factories and casinos; any size for a holding, where it runs the companies under it).
     Decisions go manager -> managing director -> regional manager -> group CEO -> you (engine/management/managers.js
     chainOf), with its own authority and purchase limit; it coaches the manager (better management quality).
   - department heads as the company grows (each from its own size, half that in the big trades): sales director
     (more customers, most in business-to-business trades), operations manager (more capacity), finance manager (cheaper
     loans, books and fines), HR manager (fewer leave, better mood, less tiredness) and marketing manager (campaigns
     work better). How much they
     do depends on their real skill, which may be less than their CV says.
   - regional managers for a company with branches in several cities (and, for a chain, the chain chiefs).
   Their pay goes through the company's payroll ('extraPay', engine/company/model.js wagesWeek). ===== */
window.TEAM56 = window.TEAM56 || {};
(function () {
  const T56 = window.TEAM56;
  /* [title, the skill that counts, pay against a store manager's, what they do, from how many people]
     Pay: Norwegian medians (lonnsinnsikt.no, SSB 2024): store department manager about 48 000 a month; sales and
     marketing managers 89 000, operations managers 85 000, HR managers 97 000, finance managers 102 000.
     Effects at full skill (a typical hire has about 55%): better management practices lift productivity around 10-17%
     in field studies (Bloom et al.); good HR practice cuts staff turnover about 7% for each step up (Huselid 1995).
     Dedicated heads come with size: sales and marketing from about 10 people, operations from 15, finance from 20,
     HR from 25 (half that in the big trades). */
  const ROLES = {
    sales: ['Sales director', 'sales', 1.85, 'More customers: about 2% more demand, up to 5% in business-to-business trades.', 10],
    ops: ['Operations manager', 'ops', 1.8, 'Runs the place better: about 5% more capacity.', 15],
    fin: ['Finance manager', 'fin', 2.1, 'Cheaper money and books: a lower loan margin, lower accountant fees and fines.', 20],
    hr: ['HR manager', 'people', 2, 'People stay longer (about 7% fewer leave), better mood, long weeks wear less.', 25],
    mkt: ['Marketing manager', 'sales', 1.85, 'Campaigns reach about 8% more people.', 10]
  };
  const BIG = { bank: 1, insco: 1, fund: 1, airline: 1, shipping: 1, oilgas: 1, hotel: 1, factory: 1, casino: 1 };
  const AUTHN = [[0, 'Ask me first'], [1, 'Within limits'], [2, 'Full control']];
  const team = co => (co.team = co.team || { ceo: null, heads: {} });
  const heads = co => { const n = (co.staff || []).length + (co.mgr ? 1 : 0); return n; };
  const under = co => co.type === 'hold' ? S.cos.filter(c => c.hold === co.id && c.st !== 'sold' && c.st !== 'bust') : [];
  const roleOk = (co, k) => co.type !== 'hold' && heads(co) >= ROLES[k][4] * (BIG[co.type] ? 0.5 : 1);
  const headsOk = co => roleOk(co, 'sales') || roleOk(co, 'mkt');
  const ceoOk = co => co.type === 'hold' ? under(co).length >= 2 : heads(co) >= 20 || (BIG[co.type] && heads(co) >= 8);
  const live = x => x && S.npcs[x.npc] ? x : null;
  const head = (co, k) => live(co.team && co.team.heads && co.team.heads[k]);
  const skillOf = (x, st) => { const n = x && S.npcs[x.npc]; return n && n.stats ? clamp((n.stats[st] || 55) / 100, 0.15, 1) : 0; };
  const hq = (co, k) => { const x = head(co, k); return x ? skillOf(x, ROLES[k][1]) : 0; };
  function md(co) { const x = live(co.team && co.team.ceo); if (x) return { co, x }; const h = co.hold && getCo(co.hold); const y = h && live(h.team && h.team.ceo); return y ? { co: h, x: y } : null; }
  const regionals = co => (S.group.regional || []).filter(r => r.payCo === co.id && S.npcs[r.npc]);
  const branches = co => S.cos.filter(c => c.branch && c.branch.of === co.id && c.st !== 'sold' && c.st !== 'bust');
  Object.assign(T56, { team, head, md, ROLES, headsOk, ceoOk, roleOk });

  /* ---------- pay ---------- */
  addStep('extraPay', 10, 'the management team', (co, v) => {
    const t = co.team;
    let w = 0;
    if (t) { if (live(t.ceo)) w += t.ceo.wage; Object.keys(t.heads || {}).forEach(k => { if (live(t.heads[k])) w += t.heads[k].wage; }); }
    regionals(co).forEach(r => { w += r.wage; });
    return v + w;
  });

  /* ---------- what they do ---------- */
  addStep('demand', 85, 'sales director', (co, bd, r) => { const v = hq(co, 'sales'); if (v && r && r.D > 0) { const f = 1 + (0.035 + 0.055 * (bd.b2b || 0)) * v; r.D *= f; if (r.parts) r.parts.sales56 = f; } }, true);
  addStep('capacity', 60, 'operations manager', (co, bd, r) => { const v = hq(co, 'ops'); if (v && r && r.cap) r.cap *= 1 + 0.09 * v; }, true);
  addStep('mktMult', 20, 'marketing manager', (co, r) => { const v = co ? hq(co, 'mkt') : 0; return v ? r * (1 + 0.14 * v) : r; });
  addStep('quitF', 10, 'HR manager: people stay longer', (co, s, f) => { const v = co ? hq(co, 'hr') : 0; return v ? f * (1 - 0.13 * v) : f; });
  addStep('loanOffer', 30, 'finance manager: a lower margin', (kind, amt, co, o) => { const v = co ? hq(co, 'fin') : 0; if (v && o) o.margin -= 0.003 * v; return o; });
  addStep('payCo.amount', 30, 'finance manager: books and fines', (co, cat, label, amt) => { const v = co ? hq(co, 'fin') : 0; return v && (cat === 'acc' || cat === 'fine') ? amt * (1 - 0.15 * v) : amt; });
  addStep('mgrQual', 30, 'a managing director coaches the manager', (co, v) => { const m = md(co); return m ? Math.min(1, v + 0.06 * skillOf(m.x, 'people')) : v; });
  addStep('week.after', 46, 'the management team: mood, learning, rest', () => {
    S.cos.forEach(co => {
      if (co.st !== 'open' || !co.team) return;
      const h = hq(co, 'hr');
      if (h) {
        if (co.mgr) co.mood = clamp((co.mood != null ? co.mood : 60) + (72 - (co.mood != null ? co.mood : 60)) * 0.03 * h, 0, 100);
        (co.staff || []).forEach(s => { if (s.tired > 0) s.tired = Math.max(0, s.tired - 2 * h); });
      }
      const m = md(co);
      if (m && co.mgr) co.mood = clamp((co.mood != null ? co.mood : 60) + 0.15 * skillOf(m.x, 'people'), 0, 100);
    });
  });

  /* ---------- hiring: each role is hired on the step screen, always through the agency (ui/screens/hiring.js MR56) ---------- */
  const fee = () => KC(15000);
  const title = (co, k) => k === 'ceo' ? titleFor(co, 'mdir') : k === 'reg' ? titleFor(co, 'region') : ROLES[k][0];
  const stat = k => k === 'ceo' ? 'people' : k === 'reg' ? 'ops' : ROLES[k][1];
  const STN = { ops: 'Running things', people: 'People', sales: 'Sales', fin: 'Money', risk: 'Risk sense' };
  const what = (co, k) => k === 'ceo' ? (co.type === 'hold' ? 'Runs the ' + under(co).length + ' companies under the holding' : 'Runs the company above the manager') + ', with the authority you give, and coaches the manager.' : k === 'reg' ? 'Runs ' + co.name + ' and its ' + branches(co).length + ' branches in one city or country.' : ROLES[k][3];
  function hireTeam(co, k, n, w) {
    if (co.cash < w && liquid() < w) return 'cash';
    n.hired = -6;
    const x = { npc: n.id, wage: w, w0: S.week };
    if (k === 'ceo') team(co).ceo = Object.assign(x, { lvl: 1, buy: rnl(Math.max(KC(50000), (co.lastW ? co.lastW.rev * 4 : 0)), 1000) });
    else if (k === 'reg') { const rg = { id: uid(), npc: n.id, scope: 'co:' + co.id, wage: w, lvl: 1, buy: KC(50000), payCo: co.id, w0: S.week }; S.group.regional.push(rg); [co].concat(branches(co)).forEach(c => { c.region = rg.id; }); }
    else team(co).heads[k] = x;
    return 'ok';
  }
  const MR = window.MR56 = window.MR56 || {};
  ['ceo', 'reg'].concat(Object.keys(ROLES)).forEach(k => {
    MR[k] = {
      t: co => title(co, k), d: co => what(co, k), st: [stat(k), STN[stat(k)]], fee,
      gen: co => { const n = genManager(co, 'gen'); n.ask = rnl(n.ask * (k === 'ceo' ? 2.4 : k === 'reg' ? 1.6 : ROLES[k][2]), 500); return n; },
      hire: (co, n, w) => hireTeam(co, k, n, w)
    };
  });
  ACT.tm56fire = p => {
    const co = getCo(p.id); if (!co) return;
    const t = team(co), x = p.k === 'ceo' ? t.ceo : p.k === 'reg' ? regionals(co).find(r => r.id === p.r) : t.heads[p.k];
    if (!x) return;
    confirmThen('Let ' + esc(S.npcs[x.npc] ? S.npcs[x.npc].name : 'them') + ' go?', 'One month of pay as severance.', 'Let go', () => {
      payCo(co, Math.round(x.wage * (1 + CC().empNI)), 'wages', 'Severance: ' + title(co, p.k));
      if (S.npcs[x.npc]) S.npcs[x.npc].hired = 0;
      if (p.k === 'ceo') t.ceo = null;
      else if (p.k === 'reg') { S.group.regional = S.group.regional.filter(r => r !== x); S.cos.forEach(c => { if (c.region === x.id) c.region = null; }); }
      else delete t.heads[p.k];
      save(); render();
    }, true);
  };
  ACT.tm56auth = p => { const co = getCo(p.id), x = co && live(team(co).ceo); if (!x) return; if (p.k === 'lvl') x.lvl = +p.v; else x.buy = +p.v; save(); render(); };

  /* ---------- the Team page of a company's headquarters (ui/company/headquarters.js): who sits above the manager ---------- */
  const P = o => esc(JSON.stringify(o));
  function person(co, k, x, extra) {
    const n = S.npcs[x.npc];
    return '<div class="lrow">' + faceAv(n) + '<span class="ctext"><b>' + esc(n.name) + '</b><small>' + esc(title(co, k)) + ' · ' + mshort(x.wage) + '/mo · since ' + esc(dateStr(x.w0 != null ? x.w0 : S.week)) + '</small>' + (extra || '') + '</span>' + btn('Let go', 'tm56fire', { id: co.id, k, r: x.id }, 'chip ghost') + '</div>';
  }
  const vacant = (co, k, sub) => '<button class="lrow vac56" data-a="go" data-p="' + P({ n: 'mgrhire', p: { id: co.id, r: k } }) + '"><span class="av dim">' + esc(title(co, k).split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase()) + '</span><span class="ctext"><b>' + esc(title(co, k)) + '</b><small>' + esc(sub) + '</small></span><span class="pill">Hire ›</span></button>';
  /* the roles the company has room for: [key, the person or null, a line about them] */
  T56.slots = function (co) {
    if (co.st === 'setup' || BD[co.type].fam === 'club') return [];
    const t = team(co), L = [], m = live(t.ceo);
    if (m || ceoOk(co)) L.push(['ceo', m]);
    Object.keys(ROLES).forEach(k => { const x = head(co, k); if (x || roleOk(co, k)) L.push([k, x]); });
    regionals(co).forEach(r => L.push(['reg', r]));
    if (branches(co).length && !regionals(co).length) L.push(['reg', null]);
    return L;
  };
  T56.title = title;
  function teamCard(co) {
    if (co.st === 'setup' || BD[co.type].fam === 'club') return '';
    const t = team(co), L = T56.slots(co), m = live(t.ceo), big = BIG[co.type] ? 0.5 : 1;
    let h = '<div class="lrows">' + L.map(([k, x]) => x ? person(co, k, x, k === 'ceo' ? '<small>' + AUTHN[x.lvl || 0][1] + (x.lvl === 1 ? ' · up to ' + mshort(x.buy) : '') + '</small>' : k !== 'reg' ? '<small>' + esc(ROLES[k][3]) + '</small>' : '') : vacant(co, k, what(co, k))).join('') + '</div>';
    const md = titleFor(co, 'mdir');
    if (!L.length) h = '<div class="calm">' + (co.type === 'hold' ? esc(md) + ': once two companies sit under the holding.' : 'Department heads come with size: sales and marketing from about ' + Math.round(10 * big) + ' people, operations from ' + Math.round(15 * big) + ', finance from ' + Math.round(20 * big) + ', HR from ' + Math.round(25 * big) + '. ' + esc(md) + ': from ' + (BIG[co.type] ? 8 : 20) + ' people.') + '</div>';
    if (m) h += '<span class="lab">' + esc(titleFor(co, 'mdir')) + ' decides</span>' + chips(AUTHN, m.lvl || 0, 'tm56auth', { id: co.id, k: 'lvl' }) + (m.lvl === 1 ? chips([KC(50000), KC(200000), KC(1000000), KC(5000000)].map(v => [v, mshort(v)]), m.buy, 'tm56auth', { id: co.id, k: 'buy' }) : '');
    return h;
  }
  T56.card = teamCard;
  /* one line for the Group list: who sits above the manager */
  T56.summary = co => {
    const t = co.team || {}, n = Object.keys(t.heads || {}).filter(k => head(co, k)).length, r = regionals(co).length, L = [];
    if (live(t.ceo)) L.push(titleFor(co, 'mdir'));
    if (n) L.push(n + (n === 1 ? ' department head' : ' department heads'));
    if (r) L.push(r === 1 ? titleLow(titleFor(co, 'region')) : r + ' regional managers');
    return L.join(', ');
  };

})();

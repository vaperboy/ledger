/* ---- features/people/targets_and_budgets.js ---- */
/* ===== Round 58: targets and budgets from above.
   Every managed company gets three targets each month, set by the first level above its manager (engine/management/
   managers.js chainOf: the regional or chain manager, the managing director, the group's managing director) or by you
   when nobody sits in between: monthly sales, monthly profit, and the rating (how busy it is, for a trade without
   reviews, or how well known it is for a trade that measures neither). The targets come half from the year's budget
   (month by month in last year's pattern) and half from what the last three months point to, with a little stretch
   from whoever sets them (a skilled boss sets them closer to what is possible).
   - Hitting a target pays the manager a bonus (a share of the monthly wage per target: none, standard 8% or high 15%),
     lifts their mood and their score on the scorecard (engine/people/scorecards.js). Chasing a bonus makes them push a
     little harder (a few per cent more customers; more care when the rating is a target).
   - Missing most of them brings a talk: with you when you set them (back them, give a warning, lower the bar), or
     with their boss, who after three bad months in a row asks you whether to replace the manager.
   - The budget for the year: the manager's draft (last twelve months, growth from their skill and the economy), which
     their boss tightens or you approve, push or soften. At the year end: the year against the budget, a year-end bonus
     when both sales and profit are met.
   A company you run yourself gets a budget drafted by your accountant, and targets only if you set them yourself.
   On the company overview (one row, ui/company/view.js CT.ov), its headquarters (Manager page and dashboard,
   ui/company/headquarters.js) and its own page (V.tg58). ===== */
window.TG58 = window.TG58 || {};
(function () {
  const T = window.TG58;
  const NOFAM = { fin: 1, energy: 1, rent: 1, club: 1 };
  const BO = [[0, 'No bonus'], [0.08, 'Standard'], [0.15, 'High']];
  const MI = () => monthIdx(S.week);
  const ok = co => co && co.st === 'open' && co.type !== 'hold' && BD[co.type] && !NOFAM[BD[co.type].fam];
  const live = () => S.cos.filter(ok);
  const st = co => (co.tg58 = co.tg58 || { m: null, y: null, log: [], bo: 1, bad: 0 });
  T.st = st;
  const hasRating = co => (co.rvN || 0) >= 10;
  const utilNow = co => { const H = (co.wh22 || []).slice(-4); return H.length ? H.reduce((t, x) => t + (x.u || 0), 0) / H.length : (co.lastW ? co.lastW.util || 0 : 0); };
  /* the three measures */
  const M = {
    rev: { n: 'Sales', f: v => mshort(v) },
    profit: { n: 'Profit', f: v => (v < 0 ? '−' : '') + mshort(Math.abs(v)) },
    rating: { n: 'Rating', f: v => v.toFixed(1) + ' ★' },
    util: { n: 'How busy', f: v => Math.round(v * 100) + '%' },
    aware: { n: 'Awareness', f: v => Math.round(v) + ' / 100' }
  };
  T.M = M;
  /* the third target: the rating, or how busy it is, or for a trade that measures neither, how well known it is */
  const third = co => hasRating(co) ? 'rating' : utilNow(co) > 0.05 ? 'util' : 'aware';
  const now3Of = (co, k) => k === 'rating' ? ratingOf(co) : k === 'util' ? utilNow(co) : co.aware || 0;

  /* ---------- who sets them ---------- */
  function setter(co) {
    const up = co.mgr && typeof chainOf === 'function' ? chainOf(co).find(x => x.kind !== 'mgr') : null;
    if (up) return { k: up.kind, n: up.npc.name, npc: up.npc, t: titleFor(co, up.kind), q: clamp(((up.npc.stats && up.npc.stats.sales) || up.npc.skill || 55) / 100, 0.2, 1) };
    return { k: 'you', n: 'You', t: 'Owner', q: 1 };
  }
  T.setter = setter;

  /* ---------- the budget ---------- */
  function lastYear(co) {
    const h = (co.hist || []).slice(-12).filter(x => (x.rev || 0) > 0); /* months with sales: not the setup months */
    if (h.length < 2) return null;
    const f = 12 / h.length;
    return { rev: h.reduce((t, x) => t + (x.rev || 0), 0) * f, profit: h.reduce((t, x) => t + (x.profit || 0), 0) * f, h };
  }
  /* each calendar month's share of a year, from last year's months when there are twelve, else even */
  function shares(co) {
    const ly = lastYear(co), S12 = new Array(12).fill(1 / 12);
    if (!ly || ly.h.length < 12) return S12;
    const tot = ly.h.reduce((t, x) => t + Math.max(0, x.rev || 0), 0);
    if (tot <= 0) return S12;
    const s = new Array(12).fill(0);
    ly.h.forEach(x => { s[x.m % 12] += Math.max(0, x.rev || 0) / tot; });
    return s.map(v => v * 0.7 + 0.3 / 12); /* last year's pattern, a little evened out */
  }
  /* the manager's draft for the rest of a calendar year from month m0 (or your accountant's, without a manager) */
  function draft(co, m0) {
    const ly = lastYear(co), r3 = recent(co);
    if (!ly) return null;
    const q = co.mgr ? mgrQual(co) : 0.5, g = clamp(0.04 + (q - 0.5) * 0.08 + ((S.econ.dem || 1) - 1) * 0.5, -0.06, 0.12);
    const sh = shares(co), left = sh.slice(m0 % 12).reduce((t, v) => t + v, 0);
    /* a young company is still growing: its last three months count as much as the year */
    const base = ly.h.length >= 12 ? (ly.rev + r3.ann) / 2 : r3.ann;
    const margin = r3.rev > 0 ? (r3.profit / r3.rev + (ly.rev > 0 ? ly.profit / ly.rev : 0)) / 2 : 0, rev = base * (1 + g) * left;
    return { rev: rnl(rev, 1000), profit: rnl(rev * Math.min(0.35, margin + 0.01), 1000), g, m0, sh };
  }
  /* the last three months, and how much of a year their calendar months usually hold (sf: 3/12 when even);
     ann: the year they point to, the latest month counting most, with the trend between them */
  function recent(co) {
    const h = (co.hist || []).filter(x => (x.rev || 0) > 0).slice(-3), sh = shares(co), W = [[1], [0.4, 0.6], [0.2, 0.3, 0.5]][Math.max(0, h.length - 1)];
    const ann = h.map(x => (x.rev || 0) / Math.max(0.02, sh[x.m % 12]));
    const tr = ann.length > 1 && ann[0] > 0 ? clamp(Math.pow(ann[ann.length - 1] / ann[0], 1 / (ann.length - 1)) - 1, -0.1, 0.1) : 0;
    const a = ann.reduce((t, v, i) => t + v * W[i], 0) * (1 + tr * 0.5), rv = h.reduce((t, x) => t + (x.rev || 0), 0), pr = h.reduce((t, x) => t + (x.profit || 0), 0);
    return { rev: rv / Math.max(1, h.length) * 3, profit: pr / Math.max(1, h.length) * 3, sf: h.length ? h.reduce((t, x) => t + sh[x.m % 12], 0) / h.length * 3 : 0.25, ann: a, margin: rv > 0 ? pr / rv : 0, sh };
  }
  /* the budget a company works to this year: { yr, m0, rev, profit, by, ok (approved), sh } */
  function makeBudget(co, yr) {
    const m0 = Math.max(MI() + (isMonthEnd(S.week) ? 1 : 0), yr * 12), d = draft(co, m0);
    if (!d) return null;
    const s = setter(co), b = { yr, m0, rev: d.rev, profit: d.profit, sh: d.sh, by: co.mgr ? s.k : 'acc', ok: 1, d0: { rev: d.rev, profit: d.profit } };
    /* a boss above the manager tightens the draft; you approve it yourself */
    if (co.mgr && s.k !== 'you') { const x = 0.02 + 0.05 * s.q; b.rev = rnl(d.rev * (1 + x), 1000); b.profit = rnl(d.profit + Math.abs(d.profit) * x * 1.5, 1000); }
    /* next year's budget comes to you to approve at the year end; one made during the year is the manager's draft */
    if (co.mgr && s.k === 'you') { if (isMonthEnd(S.week) && isYearEnd(S.week)) b.ok = 0; else b.by = 'draft'; }
    st(co).y = b;
    return b;
  }
  /* what the year has brought so far */
  function ytd(co) {
    const y = st(co).y;
    if (!y) return null;
    const h = (co.hist || []).filter(x => x.m >= y.m0 && Math.floor(x.m / 12) === y.yr), bm = co.bk.m || {}, cur = MI() >= y.m0 && Math.floor(MI() / 12) === y.yr && !h.some(x => x.m === MI());
    return { rev: h.reduce((t, x) => t + (x.rev || 0), 0) + (cur ? bm.rev || 0 : 0), profit: h.reduce((t, x) => t + (x.profit || 0), 0) + (cur ? (bm.rev || 0) - sumExp(bm) : 0), months: h.length };
  }
  T.ytd = ytd;

  /* ---------- this month's targets ---------- */
  function setTargets(co, mi, mode) {
    const s = st(co), y = s.y, se = setter(co), sh = y && y.sh ? y.sh : shares(co);
    const ly = lastYear(co);
    if (!ly) return null;
    /* half the budget for the month, half what the last three months point to for this time of year */
    const r3 = recent(co), run = r3.ann * sh[mi % 12], runP = r3.rev > 0 ? run * r3.margin : r3.profit / 3;
    let bRev = run * 1.04, bProfit = runP + Math.abs(runP) * 0.05;
    if (y && Math.floor(mi / 12) === y.yr) { const left = sh.slice(y.m0 % 12).reduce((t, v) => t + v, 0) || 1, f = sh[mi % 12] / left; bRev = y.rev * f; bProfit = y.profit * f; }
    let rev = (bRev + run * 1.02) / 2, profit = (bProfit + runP + Math.abs(runP) * 0.03) / 2;
    /* the boss's own stretch: a skilled one aims close to what is possible, a weaker one guesses */
    let x = 0;
    if (se.k !== 'you') x = 0.01 + 0.03 * se.q + (hrng(S.seed + ':tg58:' + co.id + ':' + mi)() - 0.5) * 0.16 * (1 - se.q);
    if (mode != null) x = [-0.05, 0, 0.08][mode];
    const k3 = third(co), now3 = now3Of(co, k3);
    /* the rating: hold it (raise it a little when it is weak or the target is a stretch); how busy: the same */
    const up = mode === 2 ? 1 : mode === 0 ? -1 : 0;
    const t3 = k3 === 'rating' ? Math.min(4.8, Math.floor(now3 * 10 + 1e-6) / 10 + (now3 < 3.6 ? 0.1 : 0) + 0.1 * up) : k3 === 'util' ? clamp(Math.floor(now3 * 20 + 1e-6) / 20 + 0.05 * up, 0.1, 0.95) : Math.min(95, Math.floor(now3) + 1 + 2 * up);
    s.m = { mi, by: se.k, n: se.n, T: { rev: rnl(Math.max(0, rev * (1 + x)), 1000), profit: rnl(profit + Math.abs(profit) * x * 1.5, 1000), [k3]: t3 }, k3, from3: now3, mode: mode == null ? 1 : mode };
    return s.m;
  }
  T.setTargets = setTargets;
  const cur = co => { const s = co.tg58; return s && s.m && s.m.mi === MI() ? s.m : null; };
  T.cur = cur;
  /* weeks into the month, of the weeks it has */
  function monthPart() {
    let a = S.week, b = S.week;
    while (monthIdx(a - 1) === MI()) a--;
    while (monthIdx(b + 1) === MI()) b++;
    return { done: S.week - a, of: b - a + 1 };
  }
  /* where each target stands now: [key, target, now, on track] */
  function standing(co) {
    const m = cur(co);
    if (!m) return [];
    const bm = co.bk.m || {}, mp = monthPart(), part = Math.max(0.25, mp.done / mp.of);
    const L = [['rev', m.T.rev, bm.rev || 0], ['profit', m.T.profit, (bm.rev || 0) - sumExp(bm)]];
    L.push([m.k3, m.T[m.k3], now3Of(co, m.k3)]);
    return L.map(x => { const pace = x[0] === 'rating' || x[0] === 'util' || x[0] === 'aware' ? x[2] >= x[1] : x[0] === 'profit' ? x[2] >= x[1] * part - Math.abs(x[1]) * 0.05 : x[2] >= x[1] * part * 0.95; return x.concat([pace]); });
  }
  T.standing = standing;

  /* ---------- the month end: results, bonuses, talks, the next month ---------- */
  function judge(co) {
    const s = st(co), m = cur(co), h = (co.hist || [])[co.hist.length - 1];
    if (!m || !h || h.m !== m.mi) return null;
    const A = { rev: h.rev || 0, profit: h.profit || 0 };
    A[m.k3] = now3Of(co, m.k3);
    const hit = { rev: A.rev >= m.T.rev, profit: A.profit >= m.T.profit, [m.k3]: A[m.k3] >= m.T[m.k3] - 1e-9 };
    const n = Object.keys(hit).filter(k => hit[k]).length;
    const rate = co.mgr ? BO[s.bo != null ? s.bo : 1][0] : 0, bonus = Math.round(n * rate * (co.mgrWage || 0));
    if (bonus > 0) { payCo(co, bonus, 'wages', 'Bonus: monthly targets met'); co.mgrBonusLast = bonus; }
    if (co.mgr) co.mood = clamp((co.mood != null ? co.mood : 60) + [-4, -1, 2, 4][n] + (bonus > 0 ? 1 : 0), 0, 100);
    const r = { mi: m.mi, n, of: 3, hit, A, T: m.T, k3: m.k3, by: m.by, bonus };
    s.log.push(r);
    if (s.log.length > 24) s.log.shift();
    s.bad = n <= 1 ? (s.bad || 0) + 1 : 0;
    return r;
  }
  const mName = mi => MN[mi % 12];
  function talk(co, r) {
    const se = setter(co), mg = S.npcs[co.mgr];
    if (!mg) return '';
    const miss = Object.keys(r.hit).filter(k => !r.hit[k]).map(k => M[k].n.toLowerCase()).join(' and ');
    if (se.k === 'you') {
      addMsg({ kind: 'ask', from: mg.name, role: titleFor(co, 'mgr'), title: 'Targets missed at ' + co.name, body: '"We missed ' + miss + ' in ' + mName(r.mi) + '. I would like to talk about it."', co: co.id,
        opts: [{ l: 'Back them', d: 'Better mood. The targets stay.', fx: {} }, { l: 'Give a warning', d: 'They push harder this month, and take it badly if it happens again.', fx: {} }, { l: 'Lower the bar', d: 'Easier targets next month.', fx: {} }],
        act: 'tg58talk', data: { co: co.id }, exp: S.week + 3, tone: 'n' });
      return '';
    }
    if (s3(co)) {
      addMsg({ kind: 'ask', from: se.n, role: se.t, title: 'Three bad months at ' + co.name, body: '"' + mg.name + ' has missed most targets three months running. Do we keep them?"', co: co.id,
        opts: [{ l: 'One more chance', d: 'The manager knows it is serious.', fx: {} }, { l: 'Find a successor', d: 'Opens the hiring for a new manager.', fx: {} }],
        act: 'tg58bad', data: { co: co.id }, exp: S.week + 4, tone: 'bad' });
      return se.n + ' asks you about ' + mg.name;
    }
    co.mood = clamp((co.mood != null ? co.mood : 60) - 2, 0, 100);
    return se.n + ' had a talk with ' + mg.name;
  }
  const s3 = co => (st(co).bad || 0) >= 3;
  ACTS.tg58talk = (m, idx) => {
    const co = getCo(m.data.co);
    if (!co || !co.mgr) return true;
    const s = st(co);
    if (idx === 0) co.mood = clamp((co.mood || 60) + 4, 0, 100);
    else if (idx === 1) { co.mood = clamp((co.mood || 60) - (s.warn58 ? 8 : 4), 0, 100); s.warn58 = S.week; s.push = MI(); }
    else { s.easy = MI() + 1; if (s.m && s.m.mi === MI()) setTargets(co, MI(), 0); }
    return true;
  };
  ACTS.tg58bad = (m, idx) => {
    const co = getCo(m.data.co);
    if (!co) return true;
    if (idx === 0) { st(co).bad = 0; co.mood = clamp((co.mood || 60) - 3, 0, 100); }
    else setTimeout(() => { try { UI.go('mgrhire', { id: co.id }); } catch (e) { } }, 0);
    return true;
  };
  /* the year end: the year against the budget */
  function yearEnd(co) {
    const s = st(co), y = s.y;
    if (!y || y.yr !== wYear(S.week)) return null;
    const a = ytd(co), okR = a.rev >= y.rev, okP = a.profit >= y.profit;
    let bonus = 0;
    if (co.mgr && okR && okP) { bonus = Math.round((co.mgrWage || 0) * [0, 1, 1.5][s.bo != null ? s.bo : 1]); if (bonus > 0) payCo(co, bonus, 'wages', 'Bonus: the year’s budget met'); }
    if (co.mgr) co.mood = clamp((co.mood || 60) + (okR && okP ? 8 : !okR && !okP ? -4 : 1), 0, 100);
    (s.years = s.years || []).push({ yr: y.yr, rev: a.rev, profit: a.profit, B: { rev: y.rev, profit: y.profit }, okR, okP, bonus });
    if (s.years.length > 6) s.years.shift();
    return { co, a, y, okR, okP, bonus };
  }
  function monthEnd() {
    const L = live(), res = [], talks = [], years = [], asks = [];
    L.forEach(co => {
      const r = judge(co);
      if (r && co.mgr) { res.push([co, r]); if (r.n <= 1) { const t = talk(co, r); if (t) talks.push(t); } }
    });
    if (isYearEnd(S.week)) L.forEach(co => { const y = yearEnd(co); if (y) years.push(y); });
    /* next month: a budget for the coming year where there is none, then the targets */
    const nm = MI() + 1, yr = Math.floor(nm / 12);
    L.forEach(co => {
      const s = st(co);
      if (!s.y || s.y.yr !== yr || !(s.y.rev > 0)) { const b = makeBudget(co, yr); if (b && !b.ok) asks.push(co); }
      if (co.mgr || s.own) setTargets(co, nm, s.easy === nm ? 0 : s.own ? s.ownMode : s.m && s.m.by === 'you' && s.m.mode != null ? s.m.mode : null);
    });
    if (res.length) {
      const all = res.filter(x => x[1].n === 3).length, bon = res.reduce((t, x) => t + x[1].bonus, 0);
      addMsg({ kind: 'info', from: 'Your management', title: 'Targets in ' + mName(nm - 1) + ': ' + all + ' of ' + res.length + (res.length > 1 ? ' companies' : ' company') + ' hit all three', body: res.map(([co, r]) => co.name + ' ' + r.n + '/3' + (r.bonus ? ' (bonus ' + mshort(r.bonus) + ')' : '')).join(' · ') + '.' + (talks.length ? ' ' + talks.join('. ') + '.' : '') + (bon ? ' Bonuses paid: ' + mshort(bon) + '.' : ''), tone: all === res.length ? 'good' : all ? 'n' : 'bad', status: 'done', go: res.length === 1 ? { l: 'See targets', a: 'go', p: { n: 'tg58', p: { id: res[0][0].id } } } : null });
    }
    if (years.length) addMsg({ kind: 'info', from: 'Your accountant', title: 'The year ' + years[0].y.yr + ' against the budgets', body: years.map(x => x.co.name + ': sales ' + mshort(x.a.rev) + ' of ' + mshort(x.y.rev) + ', profit ' + M.profit.f(x.a.profit) + ' of ' + M.profit.f(x.y.profit) + (x.bonus ? ', year-end bonus ' + mshort(x.bonus) : '')).join(' · ') + '.', tone: years.every(x => x.okR && x.okP) ? 'good' : 'n', status: 'done' });
    if (asks.length) addMsg({ kind: 'ask', from: 'Your managers', title: 'Budgets for ' + yr + ' to approve', body: asks.map(co => co.name + ': sales ' + mshort(st(co).y.rev) + ', profit ' + M.profit.f(st(co).y.profit)).join(' · ') + '. Their drafts, from last year and what they think they can do.',
      opts: [{ l: 'Approve them', d: 'The managers like a budget they made.', fx: {} }, { l: 'Ask for 10% more', d: 'Harder targets all year. Some will grumble.', fx: {} }, { l: 'Keep them safe', d: '5% lower: easier bonuses, less ambition.', fx: {} }],
      act: 'tg58bud', data: { cos: asks.map(c => c.id), yr }, exp: S.week + 4, tone: 'n' });
  }
  ACTS.tg58bud = (m, idx) => {
    (m.data.cos || []).map(getCo).filter(Boolean).forEach(co => {
      const y = st(co).y;
      if (!y || y.yr !== m.data.yr) return;
      const f = [0, 0.1, -0.05][idx] || 0;
      y.rev = rnl(y.d0.rev * (1 + f), 1000); y.profit = rnl(y.d0.profit + Math.abs(y.d0.profit) * f * 1.5, 1000); y.ok = 1;
      if (co.mgr) co.mood = clamp((co.mood || 60) + [2, -3, 1][idx], 0, 100);
      if (st(co).m && st(co).m.mi === MI()) setTargets(co, MI(), st(co).m.mode);
    });
    return true;
  };
  T.monthEnd = monthEnd;
  addStep('week.after', 56, 'targets and budgets: the month end', () => {
    try {
      if (S.over) return;
      if (isMonthEnd(S.week)) monthEnd();
      /* a newly managed company gets its targets straight away */
      else live().forEach(co => { const s = st(co); if ((co.mgr || s.own) && !cur(co) && lastYear(co)) { if (!s.y || s.y.yr !== wYear(S.week) || !(s.y.rev > 0)) makeBudget(co, wYear(S.week)); setTargets(co, MI(), s.own ? s.ownMode : null); } });
    } catch (e) { console.error(e); }
  });
  /* chasing a bonus: a few per cent more customers; more care when the rating is a target; after a warning, harder */
  addStep('demand', 80, 'a manager chasing the month’s targets', (co, bd, r) => {
    const m = cur(co);
    if (!m || !co.mgr || !r || !(r.D > 0)) return;
    const s = co.tg58, b = BO[s.bo != null ? s.bo : 1][0];
    r.D *= 1 + (b > 0 ? 0.012 + b * 0.12 : 0.005) + (s.push === MI() ? 0.01 : 0);
  }, true);
  window.qualityTarget = pipeView('window.qualityTarget:2', window.qualityTarget, 1);
  addStep('window.qualityTarget:2', 10, 'a rating target: more care for quality', (co, v) => {
    try { const m = cur(co); if (m && co.mgr && m.k3 === 'rating' && m.T.rating > m.from3) v += BO[co.tg58.bo != null ? co.tg58.bo : 1][0] > 0 ? 3 : 2; } catch (e) { }
    return Math.max(0, Math.min(99, v));
  });

  /* ---------- the screens ---------- */
  const U = window.UI;
  if (!U) return;
  const { ui, V, ACT, esc, btn, svg, render, save, openSheet, closeSheet, toast } = U;
  const P = o => esc(JSON.stringify(o));
  const pill = (t, c) => '<span class="pill ' + (c || '') + '">' + t + '</span>';
  const shown = co => ok(co) && (co.mgr || st(co).own || st(co).y);
  /* the one row on the company overview */
  T.row = function (co) {
    if (!ok(co)) return '';
    const m = cur(co), s = st(co), se = setter(co);
    let t, sub, right;
    const last = s.log[s.log.length - 1];
    if (!m && last && last.mi === MI()) { t = 'Targets for ' + MN[last.mi % 12] + ': ' + last.n + ' of 3 met'; sub = last.bonus ? 'Bonus paid: ' + mshort(last.bonus) : co.mgr ? 'No bonus this month' : 'Your own targets'; right = pill(last.n + '/3', last.n === 3 ? 'grn' : last.n ? 'amb' : 'red'); }
    else if (!m) {
      if (co.mgr && !lastYear(co)) { t = 'Targets from next month'; sub = 'Once there are two months of numbers'; right = '<i>›</i>'; }
      else if (co.mgr) { t = 'Targets this month'; sub = 'Set at the start of next month'; right = '<i>›</i>'; }
      else { t = 'No targets'; sub = lastYear(co) ? 'You run it · set yourself monthly targets' : 'You run it · targets need two months of numbers'; right = '<i>›</i>'; }
    } else {
      const L = standing(co), n = L.filter(x => x[4]).length;
      t = 'Targets for ' + MN[m.mi % 12] + ': ' + n + ' of 3 on track';
      sub = (m.by === 'you' ? (co.mgr ? 'Set by you' : 'Your own targets') : 'Set by ' + m.n + ', ' + titleLow(titleFor(co, m.by))) + (co.mgr && BO[s.bo != null ? s.bo : 1][0] ? ' · bonus up to ' + mshort(3 * BO[s.bo != null ? s.bo : 1][0] * (co.mgrWage || 0)) : '');
      right = pill(n + '/3', n === 3 ? 'grn' : n ? 'amb' : 'red');
    }
    return '<div class="lrows"><button class="lrow tgt56" data-a="go" data-p="' + P({ n: 'tg58', p: { id: co.id } }) + '"><span class="lic">' + svg('star', 20) + '</span><span class="ctext"><b>' + t + '</b><small>' + esc(sub) + '</small></span>' + right + '</button></div>';
  };
  /* the dashboard tile's numbers (ui/company/headquarters.js) */
  T.tile = co => { const m = cur(co); if (!m) return null; const n = standing(co).filter(x => x[4]).length; return { v: n + '/3', sub: 'on track in ' + MN[m.mi % 12], tone: n === 3 ? 'good' : n ? '' : 'warn' }; };
  const bar = (f, c) => '<span class="gbar' + (c ? ' ' + c : '') + '"><i style="width:' + Math.max(3, Math.min(100, f * 100)) + '%"></i></span>';
  /* the card: this month, the year, the record */
  T.card = function (co) {
    if (!shown(co)) return '';
    const m = cur(co), s = st(co), y = s.y, se = setter(co);
    let h = '<div class="card tg58"><div class="bhead"><b>' + (m ? 'Targets for ' + MN[m.mi % 12] : 'Monthly targets') + '</b>' + (m ? pill(m.by === 'you' ? (co.mgr ? 'Set by you' : 'Your own') : esc(se.n.split(' ')[0]) + ' · ' + esc(titleLow(titleFor(co, m.by))), 'blue') : '') + '</div>';
    const last = s.log[s.log.length - 1];
    if (!m && last && last.mi === MI()) h += ['rev', 'profit', last.k3].map(k => '<div class="tg58r"><span>' + M[k].n + '</span><b>' + M[k].f(last.A[k]) + ' <small>of ' + M[k].f(last.T[k]) + '</small></b>' + pill(last.hit[k] ? 'Met' : 'Missed', last.hit[k] ? 'grn' : 'red') + '</div>').join('') + '<span class="tipt">The month is over' + (last.bonus ? ': a bonus of ' + mshort(last.bonus) + ' is paid' : '') + '. New targets come with the new month.</span>';
    else if (m) {
      const mp = monthPart();
      h += standing(co).map(([k, t, v, , on]) => { const f = k === 'rating' || k === 'util' || k === 'aware' ? (t > 0 ? v / t : 1) : t > 0 ? v / t : v >= t ? 1 : 0; return '<div class="tg58r"><span>' + M[k].n + '</span><b>' + M[k].f(v) + ' <small>of ' + M[k].f(t) + '</small></b>' + bar(f, on ? '' : 'amb') + '</div>'; }).join('');
      h += '<span class="tipt">' + (mp.done ? mp.done + ' of ' + mp.of + ' weeks gone. ' : 'The month has just begun. ') + (co.mgr ? (BO[s.bo != null ? s.bo : 1][0] ? 'Each target met pays ' + esc(S.npcs[co.mgr] ? S.npcs[co.mgr].name.split(' ')[0] : 'the manager') + ' ' + mshort(BO[s.bo != null ? s.bo : 1][0] * (co.mgrWage || 0)) + '.' : 'No bonus: the targets alone.') : 'Your own promise to yourself.') + '</span>';
    } else h += '<span class="tipt">' + (lastYear(co) ? (co.mgr ? 'The targets are set at the start of each month.' : 'You run it yourself. Set yourself targets to keep an eye on it.') : 'Targets start once the company has two months of numbers.') + '</span>';
    if (se.k === 'you' && lastYear(co)) h += btn(co.mgr ? 'Set the targets' : m ? 'Change your targets' : 'Set yourself targets', 'tg58set', { id: co.id }, 'wide');
    h += '</div>';
    if (y) {
      const a = ytd(co) || { rev: 0, profit: 0 };
      h += '<div class="card tg58"><div class="bhead"><b>Budget ' + y.yr + '</b>' + pill(!y.ok ? 'Waiting for you' : y.by === 'acc' ? 'Your accountant’s' : y.by === 'draft' ? 'The manager’s draft' : y.by === 'you' ? 'Approved by you' : 'Set by ' + esc(titleLow(titleFor(co, y.by))), y.ok ? '' : 'amb') + '</div>' +
        '<div class="tg58r"><span>Sales</span><b>' + mshort(a.rev) + ' <small>of ' + mshort(y.rev) + '</small></b>' + bar(y.rev > 0 ? a.rev / y.rev : 0) + '</div>' +
        '<div class="tg58r"><span>Profit</span><b>' + M.profit.f(a.profit) + ' <small>of ' + M.profit.f(y.profit) + '</small></b>' + bar(y.profit > 0 ? a.profit / y.profit : a.profit >= y.profit ? 1 : 0) + '</div>' +
        '<span class="tipt">' + (y.m0 % 12 ? 'From ' + MN[y.m0 % 12] + ', when the budget started. ' : '') + (co.mgr ? 'Meeting both by December pays a year-end bonus.' : 'Drafted from the last twelve months.') + '</span></div>';
    }
    const L = s.log.slice(-6);
    if (L.length) h += '<div class="card tg58"><div class="bhead"><b>The last months</b></div><div class="tg58log">' + L.map(r => '<span class="t' + r.n + '"><b>' + r.n + '/3</b><small>' + MN[r.mi % 12] + '</small></span>').join('') + '</div>' + ((s.years || []).length ? '<span class="tipt">' + s.years.slice(-2).map(x => x.yr + ': sales ' + (x.okR ? 'met' : 'missed') + ', profit ' + (x.okP ? 'met' : 'missed') + (x.bonus ? ', bonus ' + mshort(x.bonus) : '')).join(' · ') + '</span>' : '') + '</div>';
    return h;
  };
  V.titles.tg58 = 'Targets and budget';
  V.heads = V.heads || {};
  V.heads.tg58 = p => { const co = getCo(p.id); return { t: 'Targets and budget', sub: co ? esc(co.name) : '' }; };
  V.tg58 = p => { const co = getCo(p.id); return co ? (T.card(co) || '<div class="calm">No targets here.</div>') + (co.mgr ? btn('Headquarters', 'go', { n: 'mgmt56', p: { id: co.id } }, 'ghost wide') : '') : '<div class="calm">Company not found.</div>'; };
  /* you set them: how hard, and the bonus */
  ACT.tg58set = p => {
    const co = getCo(p.id);
    if (!co) return;
    const s = st(co), F = ui.tg58f = ui.tg58f && ui.tg58f.id === co.id ? ui.tg58f : { id: co.id, mode: s.m && s.m.mode != null ? s.m.mode : 1, bo: s.bo != null ? s.bo : 1 };
    const prev = JSON.stringify(s.m);
    const m = setTargets(co, MI(), F.mode);
    if (!m) { toast('Targets need two months of numbers.', true); return; }
    const k3 = m.k3;
    const L = [['rev', m.T.rev], ['profit', m.T.profit], [k3, m.T[k3]]];
    s.m = prev ? JSON.parse(prev) : null; /* only a preview until you set them */
    let h = '<h2>Targets for ' + MN[MI() % 12] + '</h2><p class="muted small">' + (co.mgr ? 'For ' + esc(S.npcs[co.mgr] ? S.npcs[co.mgr].name : 'the manager') + ', from the budget' + (s.y ? ' for ' + s.y.yr : '') + '.' : 'For yourself, from the last twelve months.') + '</p>';
    h += '<span class="lab">How hard</span>' + U.chips([[0, 'Easy'], [1, 'Realistic'], [2, 'Stretch']], F.mode, 'tg58f', { id: co.id, f: 'mode' });
    h += L.map(x => U.row(M[x[0]].n, M[x[0]].f(x[1]))).join('');
    if (co.mgr) h += '<span class="lab">Bonus per target met</span>' + U.chips(BO.map((b, i) => [i, b[0] ? b[1] + ' · ' + mshort(b[0] * (co.mgrWage || 0)) : b[1]]), F.bo, 'tg58f', { id: co.id, f: 'bo' });
    h += '<span class="tipt">' + (F.mode === 2 ? 'A stretch: more to gain, more often missed. ' : F.mode === 0 ? 'Easy targets keep morale up but ask little. ' : '') + (co.mgr ? 'A bonus makes them push a little harder.' : '') + '</span>';
    h += '<div class="btnrow col">' + btn('Set them', 'tg58go', { id: co.id }, 'primary wide') + btn('Cancel', 'sheetclose', undefined, 'ghost wide') + '</div>';
    openSheet(h);
  };
  ACT.tg58f = p => { const F = ui.tg58f; if (!F) return; F[p.f] = p.v; ACT.tg58set({ id: p.id }); };
  ACT.tg58go = p => {
    const co = getCo(p.id), F = ui.tg58f;
    if (!co || !F) return;
    const s = st(co);
    if (!s.y || s.y.yr !== wYear(S.week)) makeBudget(co, wYear(S.week));
    if (s.y && !s.y.ok) s.y.ok = 1;
    s.bo = F.bo;
    if (!co.mgr) { s.own = 1; s.ownMode = F.mode; }
    setTargets(co, MI(), F.mode);
    ui.tg58f = null;
    closeSheet(); save(); render(true); toast('Targets set for ' + MN[MI() % 12] + '.');
  };
})();

/* ---- features/people/perks_and_hosting.js ---- */
/* ===== Round 58: staff perks, deals hosted on what you own, and rewards lent from it.
   - Staff perks, company by company (Staff › Perks): a company car for the manager and team leads, gym membership,
     health insurance, a team trip each year, free lunch. Each costs a set amount a person a month (local money), paid
     through payroll ('extraPay', engine/company/model.js), and each makes people stay longer (the 'quitF' odds),
     brings better people to apply (engine/people/people.js genCand: a little more skill, fewer bad habits, a slightly
     lower ask) and, for some, eases long weeks or lifts the manager's mood. Benefits cut staff turnover by several per
     cent each in surveys; together they are worth a raise people value more than its cost.
   - Hosting: invite a rival owner, investors or franchise prospects to your yacht, jet, castle or island (Luxury ›
     your collection › Manage, or a rival's page). For 13 weeks: the owner takes your offer more seriously and answers
     sooner (engine/world/rivals.js proposeBuy), buyers for what you sell come faster and pay a little more
     (features/player/selling_startups_and_crisis.js salesWeek), franchise applicants come sooner and keener
     (engine/world/deals.js frApplicants). An island or a castle works best, then a yacht, then a jet.
   - Rewards: lend your car, villa, yacht or estate to a manager or a star worker. A manager is happier and is left
     alone by rival headhunters for half a year; a worker stays (s.happy). The piece is away while it is lent: a car
     for half a year, a villa for two weeks, a yacht or an estate for a week. ===== */
window.PK58 = window.PK58 || {};
(function () {
  const PK = window.PK58;
  /* [name, what it does, cost a person a month (base money), quit odds ×, pull on applicants, who] */
  const PERKS = {
    car: ['Company car', 'The manager and team leads drive one: they stay longer and the manager is happier.', 5500, 0.82, 0.15, 'keys'],
    gym: ['Gym membership', 'Fitter people: long weeks wear them down less.', 450, 0.95, 0.15, 'all'],
    health: ['Health insurance', 'Private care: people feel looked after and better people apply.', 650, 0.93, 0.3, 'all'],
    trips: ['A team trip each year', 'A few days away together: people stay, and the manager is happier.', 350, 0.9, 0.2, 'all'],
    lunch: ['Free lunch', 'Lunch together every day: people stay and long days are easier.', 1500, 0.94, 0.25, 'all']
  };
  PK.PERKS = PERKS;
  const on = (co, k) => !!(co && co.perks58 && co.perks58[k]);
  const keys = co => (co.mgr ? 1 : 0) + (co.staff || []).filter(s => s.role === 'lead').length;
  const heads = co => (co.staff || []).length + (co.mgr ? 1 : 0);
  const perMonth = (co, k) => KC(PERKS[k][2], co.country) * (PERKS[k][5] === 'keys' ? keys(co) : heads(co));
  PK.cost = co => Object.keys(PERKS).filter(k => on(co, k)).reduce((t, k) => t + perMonth(co, k), 0);
  /* how much the perks draw better people to apply (0 to 1) */
  PK.pull = co => Math.min(1, Object.keys(PERKS).filter(k => on(co, k)).reduce((t, k) => t + PERKS[k][4], 0));
  addStep('extraPay', 20, 'staff perks', (co, v) => v + (co && co.perks58 ? PK.cost(co) : 0));
  addStep('quitF', 20, 'staff perks: people stay longer', (co, s, f) => {
    if (!co || !co.perks58) return f;
    Object.keys(PERKS).forEach(k => { if (on(co, k) && (PERKS[k][5] !== 'keys' || (s && s.role === 'lead'))) f *= PERKS[k][3]; });
    return f;
  });
  addStep('week.after', 47, 'staff perks: long weeks and the manager', () => {
    S.cos.forEach(co => {
      if (co.st !== 'open' || !co.perks58) return;
      const ease = (on(co, 'gym') ? 1 : 0) + (on(co, 'lunch') ? 0.5 : 0);
      if (ease) (co.staff || []).forEach(s => { if (s.tired > 0) s.tired = Math.max(0, s.tired - ease); });
      if (co.mgr && (on(co, 'car') || on(co, 'trips'))) co.mood = clamp((co.mood != null ? co.mood : 60) + ((on(co, 'car') ? 0.25 : 0) + (on(co, 'trips') ? 0.2 : 0)) * Math.max(0, 1 - (co.mood || 60) / 85), 0, 100);
      /* the trip itself, once a year */
      if (on(co, 'trips') && (S.week + co.id) % 52 === 30 && heads(co) >= 2) note('The team at ' + co.name + ' is away on its yearly trip.', 'good', co.id);
    });
  });

  /* ---------- what you own: venues and lending ---------- */
  const LXI = () => (window.LUX47 || {}).LUXI || {};
  const mine = () => ((S && S.lux) || []).filter(x => LXI()[x.k]);
  const itm = x => LXI()[x.k];
  const away = x => !!(x.lent58 && x.lent58.until > S.week) || x.use === 'charter' || x.use === 'rent' || x.use === 'museum';
  /* [strength, cost, word] */
  function venue(x) {
    const i = itm(x);
    if (!i || x.co) return null;
    if (i.cat === 'estates' && (x.k === 'e2' || x.k === 'e5')) return [1, KC(x.k === 'e2' ? 45000 : 25000), x.k === 'e2' ? 'your island' : 'your castle'];
    if (i.cat === 'yachts') return [0.85, Math.max(KC(15000), Math.round(x.val * 0.002)), 'your yacht'];
    if (i.cat === 'jets') return [0.6, KC(30000), 'your jet'];
    return null;
  }
  PK.venues = () => mine().filter(x => venue(x) && !away(x));
  const H = () => (S.host58 = S.host58 || {});
  /* how much a hosted evening still counts (0 when it is over 13 weeks ago) */
  PK.hosted = k => { const h = H()[k]; return h && S.week - h.w <= 13 ? h.s : 0; };
  /* a rival owner: their offer is judged as if it were a little better, and they answer */
  addStep('proposeBuy.terms', 35, 'a rival owner you hosted', (co, r, t) => { const s = r ? PK.hosted('r:' + r.id) : 0; if (s) { t.mult *= 1 + 0.05 * s; t.scale *= 1 + 0.05 * s; } });
  function host(x, kind, d) {
    const v = venue(x);
    if (!v) return 'none';
    if (away(x)) return 'away';
    if (x.host58 && S.week - x.host58 < 4) return 'wait';
    if (S.cash < v[1]) return 'cash';
    payMe(v[1], 'Hosting on ' + v[2].replace('your ', 'the '));
    x.host58 = S.week;
    if (kind === 'riv') {
      const co = getCo(d.co), r = co && rivalsOf(co).find(y => y.id === d.r);
      if (!r) return 'none';
      H()['r:' + r.id] = { w: S.week, s: v[0] };
      r.rel = Math.min(100, (r.rel || 40) + Math.round(12 * v[0]));
      if (r.ign) r.ign = Math.max(0, r.ign - 1);
      return { t: r.owner + ' came to ' + v[2], b: 'A long evening and a good talk. For the next three months ' + r.owner.split(' ')[0] + ' takes your offers for ' + r.name + ' more seriously.' };
    }
    H()[kind] = { w: S.week, s: v[0] };
    if (kind === 'inv') return { t: 'Investors on ' + v[2], b: 'Bankers, funds and a few wealthy families. For the next three months buyers for what you sell come sooner and pay a little more.' };
    return { t: 'Franchise prospects on ' + v[2], b: 'People who want a business of their own. For the next three months applicants come sooner, and keener.' };
  }
  PK.host = host;
  /* who you can reward: managers and star workers */
  function people() {
    const L = [];
    S.cos.filter(c => c.st === 'open').forEach(co => {
      if (co.mgr && S.npcs[co.mgr]) L.push({ co, n: S.npcs[co.mgr], mgr: 1 });
      (co.staff || []).filter(s => S.npcs[s.id] && ((S.npcs[s.id].skill || 0) >= 75 || S.npcs[s.id].super)).forEach(s => L.push({ co, n: S.npcs[s.id], s }));
    });
    return L.slice(0, 14);
  }
  /* [weeks away, manager's mood, weeks they stay loyal] */
  const LEND = { cars: [26, 10, 26], homes: [2, 12, 26], yachts: [1, 15, 26], estates: [1, 15, 26] };
  PK.lendable = x => { const i = itm(x); return i && !x.co && LEND[i.cat] && !away(x) ? LEND[i.cat] : null; };
  function lend(x, coId, sid) {
    const L = PK.lendable(x), co = getCo(coId);
    if (!L || !co) return 'none';
    const n = sid ? S.npcs[sid] : S.npcs[co.mgr];
    if (!n) return 'none';
    const again = n.rw58 && S.week - n.rw58 < 26, f = again ? 0.5 : 1;
    n.rw58 = S.week;
    x.lent58 = { npc: n.id, name: n.name, until: S.week + L[0] };
    x.val = Math.round(x.val * (itm(x).cat === 'cars' ? 0.98 : 0.995)); /* a little wear */
    if (!sid) { co.mood = clamp((co.mood != null ? co.mood : 60) + L[1] * f, 0, 100); n.ret27 = Math.max(n.ret27 || 0, S.week + L[2]); }
    else { const s = co.staff.find(y => y.id === sid); if (s) { s.happy = Math.max(s.happy || 0, S.week + Math.round(L[2] * f)); s.tired = Math.max(0, (s.tired || 0) - 20 * f); } }
    return 'ok';
  }
  PK.lend = lend;
  addStep('week.after', 48, 'lent pieces come back', () => {
    mine().forEach(x => { if (x.lent58 && x.lent58.until <= S.week) { const nm = x.lent58.name; x.lent58 = null; note(nm + ' gave back the ' + itm(x).n + '. Thank you, they said.', 'good'); } });
  });

  /* ---------- the screens ---------- */
  const U = window.UI;
  if (!U) return;
  const { ui, V, ACT, esc, btn, svg, render, save, openSheet, closeSheet, toast } = U;
  const P = o => esc(JSON.stringify(o));
  const pill = (t, c) => '<span class="pill ' + (c || '') + '">' + t + '</span>';
  /* the Perks row on the Staff tab (ui/company/view.js) */
  PK.row = co => {
    if (!co || co.type === 'hold' || BD[co.type].fam === 'club') return '';
    const n = Object.keys(PERKS).filter(k => on(co, k)).length;
    return '<button class="lrow" data-a="go" data-p="' + P({ n: 'pk58', p: { id: co.id } }) + '"><span class="lic">' + svg('star', 20) + '</span><span class="ctext"><b>Perks</b><small>' + (n ? n + ' of ' + Object.keys(PERKS).length + ' · ' + mshort(PK.cost(co)) + ' a month' : 'Company car, gym, health insurance, trips, lunch') + '</small></span><i>›</i></button>';
  };
  V.titles.pk58 = 'Perks';
  V.heads = V.heads || {};
  V.heads.pk58 = p => { const co = getCo(p.id); return { t: 'Perks', sub: co ? esc(co.name) + ' · ' + heads(co) + (heads(co) === 1 ? ' person' : ' people') : '' }; };
  V.pk58 = function (p) {
    const co = getCo(p.id);
    if (!co) return '<div class="calm">Company not found.</div>';
    const tot = PK.cost(co), pay = (co.staff || []).reduce((t, s) => t + (s.wage || 0), 0) + (co.mgrWage || 0);
    let h = window.DASH56 && DASH56.card ? DASH56.card('Perks', mshort(tot) + ' a month', pay > 0 ? Math.round(tot / pay * 100) + '% on top of pay · ' + Math.round((1 - Object.keys(PERKS).filter(k => on(co, k)).reduce((f, k) => f * PERKS[k][3], 1)) * 100) + '% fewer leave' : 'nobody to give them to yet', '', []) : '';
    h += '<div class="lrows pk58">' + Object.keys(PERKS).map(k => { const x = PERKS[k], c = perMonth(co, k), o = on(co, k); return '<button class="lrow' + (o ? ' on' : '') + '" data-a="pk58t" data-p="' + P({ id: co.id, k }) + '"><span class="ctext"><b>' + esc(x[0]) + '</b><small>' + esc(x[1]) + ' ' + mshort(KC(x[2], co.country)) + (x[5] === 'keys' ? ' a car' : ' a person') + ' a month' + (c ? ' · ' + mshort(c) + ' here' : '') + '.</small></span>' + pill(o ? 'On' : 'Off', o ? 'grn' : '') + '</button>'; }).join('') + '</div>';
    const lend = mine().filter(x => PK.lendable(x));
    h += '<h2 class="sec">Rewards</h2><div class="card"><span class="tipt">Lend your car, villa, yacht or estate to a manager or a star worker. They stay, and rival headhunters leave a manager alone for half a year.</span>' + (lend.length ? lend.map(x => btn('Lend the ' + esc(itm(x).n), 'pk58lend', { x: x.id }, 'wide')).join('') : btn('Luxury', 'phapp', { n: 'lux' }, 'wide ghost')) + '</div>';
    return h;
  };
  ACT.pk58t = p => {
    const co = getCo(p.id);
    if (!co || !PERKS[p.k]) return;
    co.perks58 = co.perks58 || {};
    co.perks58[p.k] = co.perks58[p.k] ? 0 : 1;
    save(); render();
    toast(PERKS[p.k][0] + (co.perks58[p.k] ? ' from this month: ' + mshort(perMonth(co, p.k)) + ' a month.' : ' stopped.'));
  };
  /* in the Luxury collection's Manage sheet (features/player/lifestyle.js, features/player/estates.js) */
  PK.manageBtns = x => {
    let h = '';
    if (x.lent58 && x.lent58.until > S.week) return '<button class="btn wide" disabled>Lent to ' + esc(x.lent58.name) + ' until ' + dateStr(x.lent58.until) + '</button>';
    if (venue(x) && !away(x)) h += btn('Host a deal here', 'pk58host', { x: x.id }, 'wide');
    if (PK.lendable(x)) h += btn('Lend it to someone', 'pk58lend', { x: x.id }, 'wide');
    return h;
  };
  PK.lentLine = x => x.lent58 && x.lent58.until > S.week ? 'Lent to ' + x.lent58.name + ' until ' + dateStr(x.lent58.until) : '';
  ACT.pk58host = p => {
    const x = mine().find(y => y.id === p.x), v = x && venue(x);
    if (!v) return;
    const R = [];
    S.cos.filter(c => c.st === 'open' && c.type !== 'hold').forEach(co => { try { rivalsOf(co).forEach(r => { if (!R.some(z => z.r.id === r.id) && !r.bought) R.push({ co, r }); }); } catch (e) { } });
    R.sort((a, b) => (b.r.rev || 0) - (a.r.rev || 0));
    const sell = (S.sales || []).length || S.cos.some(c => c.form === 'AS' && c.st === 'open'), fr = S.cos.some(c => c.fr && c.fr.on);
    let h = '<h2>Host a deal on ' + esc(v[2]) + '</h2><p class="muted small">An evening costs about ' + mshort(v[1]) + '. It counts for three months.</p><div class="lrows">';
    if (sell) h += '<button class="lrow" data-a="pk58hgo" data-p="' + P({ x: x.id, k: 'inv' }) + '"><span class="lic">' + svg('coin', 20) + '</span><span class="ctext"><b>Investors</b><small>Buyers for what you sell come sooner and pay a little more' + (PK.hosted('inv') ? ' · hosted lately' : '') + '</small></span><i>›</i></button>';
    if (fr) h += '<button class="lrow" data-a="pk58hgo" data-p="' + P({ x: x.id, k: 'fr' }) + '"><span class="lic">' + svg('biz', 20) + '</span><span class="ctext"><b>Franchise prospects</b><small>Applicants come sooner, and keener' + (PK.hosted('fr') ? ' · hosted lately' : '') + '</small></span><i>›</i></button>';
    h += R.slice(0, 8).map(({ co, r }) => '<button class="lrow" data-a="pk58hgo" data-p="' + P({ x: x.id, k: 'riv', co: co.id, r: r.id }) + '"><span class="av">' + esc(String(r.owner || '?').split(' ').map(w => w[0]).slice(0, 2).join('')) + '</span><span class="ctext"><b>' + esc(r.owner) + '</b><small>Owns ' + esc(r.name) + (PK.hosted('r:' + r.id) ? ' · hosted lately' : '') + '</small></span><i>›</i></button>').join('');
    h += '</div>' + btn('Cancel', 'sheetclose', undefined, 'ghost wide');
    openSheet(h);
  };
  ACT.pk58hgo = p => {
    const x = mine().find(y => y.id === p.x);
    if (!x) return;
    const r = host(x, p.k, p);
    closeSheet();
    if (typeof r === 'object') { addMsg({ kind: 'info', from: 'Your evening', title: r.t, body: r.b, tone: 'good', status: 'done' }); save(); render(); toast(r.t + '.'); }
    else toast(r === 'wait' ? 'You hosted there less than a month ago.' : r === 'cash' ? 'Not enough cash for the evening.' : r === 'away' ? 'It is away just now.' : 'Nobody to host.', true);
  };
  ACT.pk58lend = p => {
    const x = mine().find(y => y.id === p.x);
    if (!x || !PK.lendable(x)) return;
    const L = people(), w = PK.lendable(x)[0];
    let h = '<h2>Lend the ' + esc(itm(x).n) + '</h2><p class="muted small">For ' + (w >= 4 ? Math.round(w / 4.33) + ' months' : w > 1 ? w + ' weeks' : 'a week') + '. A manager is happier and stays; a star worker stays.</p>';
    h += L.length ? '<div class="lrows">' + L.map(e => '<button class="lrow" data-a="pk58lgo" data-p="' + P({ x: x.id, co: e.co.id, s: e.s ? e.s.id : 0 }) + '">' + (window.faceAv ? faceAv(e.n) : '') + '<span class="ctext"><b>' + esc(e.n.name) + '</b><small>' + (e.mgr ? esc(titleFor(e.co, 'mgr')) : esc(ROLES[e.s.role] ? ROLES[e.s.role][0] : 'Worker') + ' · skill ' + Math.round(e.n.skill || 0)) + ' · ' + esc(e.co.name) + (e.n.rw58 && S.week - e.n.rw58 < 26 ? ' · rewarded lately' : '') + '</small></span><i>›</i></button>').join('') + '</div>' : '<div class="calm">No managers or star workers yet.</div>';
    openSheet(h + btn('Cancel', 'sheetclose', undefined, 'ghost wide'));
  };
  ACT.pk58lgo = p => {
    const x = mine().find(y => y.id === p.x);
    if (!x) return;
    const r = lend(x, p.co, p.s || 0);
    closeSheet();
    if (r === 'ok') { save(); render(); toast('Lent to ' + x.lent58.name + '.'); } else toast('That did not work.', true);
  };
})();

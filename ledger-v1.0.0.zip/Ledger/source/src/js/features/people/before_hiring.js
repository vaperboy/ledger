/* ===== Before hiring: what the extra person costs, what they can earn, and whether demand is there ===== */
{
  function hireImpact(co, role) {
    const bd = BD[co.type];
    if (!bd || !ROLES[role] || !bd.Dc) return null;
    const cp = capacity(co, bd), w = co.lastW || {};
    /* last week's demand and capacity are what the business actually saw; the parts tell what one more person adds */
    const capNow = w.cap > 0 ? w.cap : (cp.cap || 0), D0 = w.D != null ? w.D : demand(co, bd).D;
    /* a customer-facing hire also brings customers of their own */
    const r0d = window.R8 && R8.demRef ? R8.demRef(co, bd, null) : 1, r1d = window.R8 && R8.demRef ? R8.demRef(co, bd, role) : 1;
    const D = D0 * (r0d > 0 ? r1d / r0d : 1), dD = D - D0;
    const parts = (cp.parts || []).filter(p => p.cap != null && isFinite(p.cap));
    const mine = parts.find(p => p.k === 'role:' + role);
    const others = parts.filter(p => p !== mine).reduce((m, p) => Math.min(m, p.cap), Infinity);
    /* ask the game's own capacity model: put a typical new person in the team for a moment and see what changes
       (this also catches the owner's or manager's hours moving to the job that limits output) */
    let ratio = 1;
    try {
      const tmp = { id: '_hire24', role, skillGain: 0 };
      S.npcs._hire24 = { skill: 55 };
      co.staff.push(tmp);
      const c1 = capacity(co, bd).cap;
      co.staff.pop();
      delete S.npcs._hire24;
      ratio = cp.cap > 0 && isFinite(c1) ? c1 / cp.cap : 1;
    } catch (e) { co.staff = co.staff.filter(x => x.id !== '_hire24'); delete S.npcs._hire24; }
    const capNew = capNow * ratio, per = capNew - capNow;
    const extraUnits = Math.max(0, Math.min(D, capNew) - Math.min(D0, capNow));
    const vr = w.rev > 0 ? clamp((w.cogs || 0) / w.rev, 0, 0.95) : (bd.cogs || 0.3);
    const tk = w.units > 0.01 && w.rev > 0 ? w.rev / w.units : ticketEff(co, bd);
    const pay = wageFor(role, co) * OC();
    const contrib = extraUnits * tk * (1 - vr) * 52 / 12;
    const be = tk * (1 - vr) > 0 ? pay / (tk * (1 - vr)) * 12 / 52 : Infinity;
    return { pay, rev: extraUnits * tk * 52 / 12, contrib, be, perWk: per, extraWk: extraUnits, net: contrib - pay, bottleneck: !!(mine && mine.cap <= others + 1e-9), full: D0 > capNow * 1.02, newCust: dD };
  }
  window.R23 = window.R23 || {};
  R23.hireImpact = hireImpact; /* the hiring screen's verdict (ui/screens/hiring.js) */
}
/* bank loan-loss events: a bad quarter writes off a fraction of a percent of the loan book, not two percent at a time
   (Norwegian banks lose roughly 0.1–0.5% of their loans in a normal year, on top of the running loss rate already modelled) */
if (typeof SPEC !== 'undefined') SPEC.f_default = (co, bd, e, c) => {
  if (!co.fm || !co.fm.book) return;
  const loss = co.fm.book * rng(0.0015, 0.006) * knobFx(co, 'r') * (1 + Math.max(0, 1 - S.econ.dem) * 4);
  co.fm.book -= loss;
  bk(co, 'loss', loss);
  note('Loan losses at ' + co.name + ': ' + money(loss) + ' written off.', 'bad', co.id);
};


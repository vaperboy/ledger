/* ===== Round 9: salary talks in a phone-style message screen, pay plans and car offers that work,
   and a back button when a button sends you to another main tab. ===== */
{
  const P = o => esc(JSON.stringify(o));
  const RATES = [0.01, 0.02, 0.03, 0.05, 0.08, 0.12];
  const talkOf = id => ((ui.talk = ui.talk || {})[id] = (ui.talk || {})[id] || []);
  const bub = x => '<div class="bub ' + (x.sys ? 'sys' : x.me ? 'me' : 'them') + '">' + esc(x.t) + '</div>';
  const seg = (items, cur, act, p0) => '<div class="seg7">' + items.map(x => '<button class="' + (x[0] === cur ? 'on' : '') + '" data-a="' + act + '" data-p="' + P(Object.assign({}, p0, { v: x[0] })) + '">' + x[1] + '</button>').join('') + '</div>';
  const payOf = n => (ui.pay && ui.pay[n.id]) || { m: 'fix', rate: 0.03 };

  ACT.pay7 = p => {
    ui.pay = ui.pay || {};
    const o = ui.pay[p.n] || { m: 'fix', rate: 0.03 };
    if (p.k === 'm') { o.m = p.v; if (p.v === 'com') o.rate = Math.max(o.rate, 0.05); }
    else o.rate = p.v;
    ui.pay[p.n] = o;
    render();
  };
  ACT.car7 = p => { ui.carc = ui.carc || {}; ui.carc[p.n] = p.v; render(); };
  ACT.offer7 = p => {
    const co = getCo(p.id), n = S.npcs[p.n];
    if (!co || !n) return;
    const pm = payOf(n), sales = !!SALES_ROLES[n.role];
    const car = window.carOffer && window.carOffer(co, n) ? ((ui.carc || {})[n.id] || 'co') : null;
    const L = talkOf(n.id), before = L.length;
    if (sales && pm.m !== 'fix') ui.inp['w' + n.id] = String(Math.round(n.ask / fxr(CC())));
    const w = rnl(U.inum('w' + n.id, n.ask), 100);
    ACT.offer(p);
    let txt = !sales || pm.m === 'fix' ? 'I can offer ' + money(w) + ' a month.' : pm.m === 'mix' ? 'I can offer ' + money(rnl(n.ask * 0.6, 100)) + ' fixed plus ' + pc(pm.rate, 0) + ' of what you sell.' : 'I can offer ' + pc(pm.rate, 0) + ' commission on everything you sell, no fixed pay.';
    if (car) txt += car === 'co' ? ' You get a company car.' : ' You use your own car and I pay mileage.';
    for (let i = L.length - 1; i >= before; i--) if (L[i].me) { L[i].t = txt; break; }
    if (L.length === before) L.push({ me: 1, t: txt });
    if (!n.hired && sales && pm.m !== 'fix') {
      const last = L[L.length - 1];
      const reply = pm.m === 'com' && (n.sec || 0) > 0.65 ? 'I need a fixed income. Commission only is not for me.' : 'Your sales are still small, so at that rate I would earn too little. Can you raise it, or add a base salary?';
      if (last && !last.me && !last.sys) last.t = reply; else L.push({ me: 0, t: reply });
    }
    render();
  };
  /* buyer talks get the phone frame */
  const wrapPhone = h => h.replace('<div class="ichat">', '<div class="ichat phone7">').replace(/<div class="ichat phone7"><div class="vh">/, '<div class="ichat phone7"><div class="ph7top">').replace('<div class="clog">', '<div class="clog"><div class="cfill"></div>');
  V.saletalk = pipeView('V.saletalk', V.saletalk, 1); /* V.saletalk: the buyer talk, then the steps below */
  addStep('V.saletalk', 98, 'buyer talks get the phone frame', (p, h) => wrapPhone(h));

  /* ---------- back to the tab you came from ---------- */
  let navClick = false;
  document.addEventListener('click', e => { navClick = !!(e.target && e.target.closest && e.target.closest('.nb')); }, true);
  const snap = () => ({ tab: ui.tab, view: ui.view ? { n: ui.view.n, p: ui.view.p } : null, stack: ui.stack.slice(), ph: ui.ph, phStack: (ui.phStack || []).slice(), hqt: ui.hqt });
  const ROOTS = { home: 1, cos: 1, hq: 1, meetings: 1 };
  const TABN = { home: 'Home', cos: 'Companies', hq: 'Group', phone: 'Phone', meet: 'Inbox' };
  function remember(b) {
    if (navClick) { ui.backTo = null; return; }
    if (ui.tab !== b.tab && !ui.stack.length && ui.view && ROOTS[ui.view.n]) ui.backTo = b;
  }
  ACT.go = pipeView('ACT.go', ACT.go, 1);
  addStep('ACT.go.around', 10, 'salary_talks ACT.go', (p, next) => { const b = snap(); next(); remember(b); if (ui.backTo) render(true); });
  ACT.tab = pipeView('ACT.tab', ACT.tab, 1);
  addStep('ACT.tab.around', 10, 'salary_talks ACT.tab', (p, next) => {
    const b = snap(); next(); if (navClick) ui.backTo = null; else if (b.tab !== ui.tab) { ui.backTo = b; render(true); }
  });
  ACT.backto = () => {
    const b = ui.backTo;
    ui.backTo = null;
    if (!b) return;
    ui.tab = b.tab;
    ui.stack = b.stack;
    ui.view = b.view || { n: ROOT[b.tab] || 'home', p: {} };
    if (b.ph) { ui.ph = b.ph; ui.phStack = b.phStack; }
    if (b.hqt) ui.hqt = b.hqt;
    render(true);
  };
  /* the main screens get a way back to the tab you came from (in their header, ui/core/base.js) */
  window.backToBtn = () => {
    const b = ui.backTo;
    if (!b || b.tab === ui.tab || ui.stack.length) return '';
    return '<button class="bk backto" data-a="backto" aria-label="Back to ' + esc(TABN[b.tab] || 'where you were') + '">‹</button>';
  };
}


/* ===== Round 11: what each worker actually does, reviews that name people, bought rivals as branches or
   franchise offices, promotions with an analyst report and a contract talk. (Its group board was replaced by round 12's boards.) ===== */
{
  const P11 = o => esc(JSON.stringify(o));
  const capF = s => String(s || '').replace(/^./, x => x.toUpperCase());
  const first = nm => String(nm || '').split(' ')[0];
  const R10 = window.R10;
  const r500 = v => Math.max(500, rnl(v, 500));
  const R11 = window.R11 = {};

  /* ================= 1. work records: each worker, each day ================= */
  const DRIVE = { driver: 0.0004, truckd: 0.004, courier: 0.00005 };
  function offDays(s, sh) {
    const all = [0, 1, 2, 3, 4, 5, 6];
    const z = all.filter(i => sh[i] === 0);
    if (z.length >= 2) return z;
    const rest = all.filter(i => sh[i] > 0).sort((a, b) => sh[a] - sh[b]).slice(0, 4);
    const R = hrng('off11:' + s.id);
    const out = z.slice();
    while (out.length < 2 && rest.length) out.push(rest.splice(Math.floor(R() * rest.length), 1)[0]);
    return out;
  }
  /* round 10 asks this before it hands out today's sales: nobody sells on a day off */
  window.R11off = (co, s, wk, d) => {
    const bd = BD[co.type];
    if (!R10 || !R10.dailyOk(co, bd)) return false;
    const wd = (new Date(wDate(wk).getTime() + d * 86400000).getUTCDay() + 6) % 7;
    return offDays(s, R10.shapeOf(bd)).indexOf(wd) >= 0;
  };
  function alloc(n, ws) {
    const W = sum(ws, x => x);
    if (!W || n <= 0) return ws.map(() => 0);
    const raw = ws.map(w => n * w / W), out = raw.map(Math.floor);
    let left = n - sum(out, x => x);
    raw.map((x, i) => [x - out[i], i]).sort((a, b) => b[0] - a[0]).forEach(x => { if (left > 0) { out[x[1]]++; left--; } });
    return out;
  }
  function riskOf(s) {
    const n = S.npcs[s.id] || {};
    return (1.6 - staffSkill(s) / 100) * (n.pers === 'driven' ? 1.5 : n.pers === 'steady' ? 0.7 : 1) * (s.safe11 && S.week < s.safe11 ? 0.5 : 1) * (s.warn ? 0.85 : 1);
  }
  function workDay(co, d, pre) {
    const bd = BD[co.type];
    if (!R10.dailyOk(co, bd)) return;
    const L = co.dl;
    if (!L || L.w !== S.week || !L.days[d]) return;
    const sold = L.days[d].u, wd = L.days[d].wd, sh = R10.shapeOf(bd), sd = sh[wd] * 7;
    const key = S.week * 7 + d;
    const on = co.staff.filter(s => S.npcs[s.id] && !sickNow(s) && offDays(s, sh).indexOf(wd) < 0); /* back on the rota once well again */
    const groups = {};
    on.forEach(s => (groups[s.role] = groups[s.role] || []).push(s));
    const got = {};
    Object.keys(groups).forEach(r => {
      const g = groups[r];
      if (SALES_ROLES[r]) g.forEach(s => { got[s.id] = Math.max(0, (s.ws && s.ws.w === S.week ? s.ws.u : 0) - (pre[s.id] || 0)); });
      else alloc(sold, g.map(s => staffSkill(s) + 10)).forEach((u, i) => { got[g[i].id] = u; });
    });
    co.staff.forEach(s => {
      const work = on.indexOf(s) >= 0;
      let h = 0, f = 0;
      const u = work ? got[s.id] || 0 : 0;
      if (work) {
        h = DRIVE[s.role] == null ? clamp(7.5 + Math.max(0, (sd - 1) * 1.5 + gauss() * 0.5), 7.5, 10) : clamp(7.5 + Math.max(0, (sd - 1) * 2.5 + gauss() * 1.2), 7.5, 12);
        if (DRIVE[s.role] != null && Z() < Math.min(0.5, u * DRIVE[s.role] * riskOf(s))) f = 1;
      }
      s.dd = s.dd || [];
      s.dd.push({ k: key, wd, h: Math.round(h * 10) / 10, u, f });
      if (s.dd.length > 28) s.dd.shift();
      if (f) fined(co, s);
    });
    if (!co.mgr && (co.ohrs || 0) > 0) {
      const ou = Math.max(0, (co.ows && co.ows.w === S.week ? co.ows.u : 0) - (pre['o' + co.id] || 0));
      co.odd = co.odd || [];
      co.odd.push({ k: key, wd, h: sh[wd] > 0 ? Math.round(co.ohrs / 5 * 10) / 10 : 0, u: ou, f: 0 });
      if (co.odd.length > 28) co.odd.shift();
    }
  }
  addStep('day.before', 20, 'what each person had done this week before today', (d, ph) => {
    const pre = ph.pre11 = {};
    S.cos.forEach(co => {
      co.staff.forEach(s => { pre[s.id] = s.ws && s.ws.w === S.week ? s.ws.u : 0; });
      pre['o' + co.id] = co.ows && co.ows.w === S.week ? co.ows.u : 0;
    });
  });
  addStep('day.after', 10, 'what each person did today', (d, ph) => { S.cos.forEach(co => { try { workDay(co, d, ph.pre11); } catch (e) { console.error(e); } }); });
  /* sellers' money per week, for reports */
  window.R10U = pipeView('window.R10U', window.R10U, 1); /* window.R10U: the screen above, then the steps below and in later files */
  addStep('window.R10U', 10, 'sellers’ money per week, for reports', (co, r) => {
    if (r) co.staff.forEach(s => { if (s.lw && s.lw.w === S.week) { s.rh = (s.rh || []).concat(Math.round(s.lw.r)).slice(-12); } });
    return r;
  });
  function fined(co, s) {
    const n = S.npcs[s.id];
    s.fines = (s.fines || []).concat(S.week).slice(-12);
    const recent = s.fines.filter(w => w > S.week - 5).length;
    if (recent < 2 || (s.fm11 && s.fm11 > S.week - 8)) return;
    s.fm11 = S.week;
    const what = s.role === 'truckd' ? 'the truck' : s.role === 'courier' ? 'the van' : 'the taxi';
    addMsg({ kind: 'ask', from: co.mgr && S.npcs[co.mgr] ? S.npcs[co.mgr].name : 'Traffic police', title: n.name + ' got another speeding fine', body: n.name + ' was caught driving ' + what + ' too fast, ' + recent + ' times in a month. The fine is theirs to pay, but customers notice, and the insurer counts it.', co: co.id, opts: [{ l: 'Give a warning', d: '', fx: {} }, { l: 'Safe-driving course · ' + money(KC(6000)), d: '', fx: {} }, { l: 'Let it go', d: '', fx: {} }], act: 'fine11', data: { sid: s.id }, exp: S.week + 2 });
  }
  ACTS.fine11 = (m, idx) => {
    const co = getCo(m.co), s = co && co.staff.find(x => x.id === m.data.sid);
    if (!s) return true;
    if (idx === 0) s.warn = (s.warn || 0) + 1;
    if (idx === 1) { payCo(co, KC(6000), 'oth', 'Safe-driving course'); s.safe11 = S.week + 26; }
    return true;
  };
  function agg(rec, n) {
    const L = (rec || []).slice(-(n || 28));
    const a = { days: 0, h: 0, u: 0, f: 0, span: L.length };
    L.forEach(x => { if (x.h > 0) a.days++; a.h += x.h; a.u += x.u; a.f += x.f || 0; });
    return a;
  }
  const perDay = (a, k) => a.days ? a.u * (k || 1) / a.days : 0;
  const perWeek = (a, k) => a.span ? a.u * (k || 1) / (a.span / 7) : 0;
  const hrsDay = a => a.days ? a.h / a.days : 0;
  const hrsWeek = a => a.span ? a.h / (a.span / 7) : 0;
  const num = x => String(Math.round(x));
  const wk = x => x >= 0.95 ? num(x) + ' a week' : x * 4.33 >= 0.95 ? num(x * 4.33) + ' a month' : x > 0.01 ? '1 every ' + Math.round(1 / x) + ' weeks' : 'none yet';
  const D = (l, k) => [l, a => num(perDay(a, k)), a => perDay(a, k)];
  const Wk = (l, k) => [l, a => wk(perWeek(a, k)), a => perWeek(a, k)];
  const H = ['Hours a day', a => (Math.round(hrsDay(a) * 10) / 10).toFixed(1), a => hrsDay(a)];
  const FI = ['Speeding fines, 4 weeks', a => String(a.f), a => -a.f];
  const UT = ['Share of their hours billed to clients', a => a.h ? Math.round(Math.min(1, perWeek(a) / Math.max(1, hrsWeek(a))) * 100) + '%' : '–', a => a.h ? perWeek(a) / Math.max(1, hrsWeek(a)) : 0];
  const PW = (l, k) => [l, a => num(hrsWeek(a) / k), a => hrsWeek(a) / k];
  const BILL = [Wk('Hours billed to clients'), UT];
  const T11 = {
    driver: [D('Trips a day'), D('Passengers a day', 1.35), ['Hours on the road a day', H[1], H[2]], ['Km a day', a => num(perDay(a, 7.8) + hrsDay(a) * 6), a => perDay(a)], FI],
    truckd: [Wk('Trips'), ['Driving hours a day', a => (Math.round(Math.min(9, hrsDay(a) * 0.85) * 10) / 10).toFixed(1), a => hrsDay(a)], ['Km a day', a => num(Math.min(720, perDay(a, 240) + hrsDay(a) * 20)), a => perDay(a)], FI],
    courier: [D('Parcels a day'), D('Stops a day', 0.75), ['Km a day', a => num(perDay(a, 0.75) * 2.2 + (a.days ? 25 : 0)), a => perDay(a)], FI],
    estate: [Wk('Homes sold'), PW('Viewings a week', 3.2), PW('Valuations a week', 9), H],
    cardealer: [Wk('Cars sold'), PW('Test drives a week', 2.5), H],
    sales: [Wk('Deals closed'), PW('Client meetings a week', 4), H],
    agent: [Wk('Policies sold'), H], broker: [Wk('Trades'), H],
    barber: [D('Clients a day'), H], physio: [D('Treatments a day'), H], dentist: [D('Patients a day'), H], dentnurse: [D('Patients assisted a day'), H], rentag: [D('Cars handed out a day'), H], vintner: [Wk('Bottles made'), H], groom: [D('Animals cared for a day'), H], trainer: [D('Sessions a day'), H], instr: [D('Lessons a day'), H],
    tutor: [Wk('Lesson hours'), H], photog: [Wk('Shoots'), H], handy: [Wk('Jobs'), H], carwash: [D('Cars a day'), H],
    cleaner: [Wk('Cleaning hours billed to clients'), UT], consult: BILL, lawyer: BILL, acct: BILL, dev: BILL, designer: BILL, marketer: BILL, hr: BILL, paralegal: BILL,
    barista: [D('Orders a day'), H], cook: [D('Meals cooked a day'), H], chef: [D('Meals cooked a day'), H], waiter: [D('Guests served a day'), D('Tables a day', 1 / 2.6), H],
    bartender: [D('Drinks served a day', 2.3), H], cashier: [D('Customers served a day'), H], baker: [D('Items baked a day'), H], dealer: [D('Hands dealt a day', 6), H],
    guard: [D('Guests checked a day'), H], recept: [D('Calls and bookings a day', 1.3), H], housek: [D('Rooms cleaned a day'), H], usher: [D('Guests a day'), H],
    mech: [Wk('Cars prepared'), H], dispatch: [D('Trips planned a day'), H], pilot: [Wk('Flights'), H], fo: [Wk('Flights'), H], cabin: [Wk('Flights'), H],
    shipm: [Wk('Voyages'), H], deckh: [Wk('Voyages'), H], seaman: [Wk('Voyages'), H], eng: [Wk('Voyages'), H],
    mktan: [PW('Rival checks a week', 2), H]
  };
  function tmpl(co, s) {
    const bd = BD[co.type];
    return T11[s.role] || [D(capF(unitPl(bd.unit, 2)) + ' handled a day'), H];
  }
  R11.agg = agg;
  /* what a worker got done lately, next to the average of others in the same job. Hours worked are shown once,
     from their working hours (Profile and the staff list), so the daily-hours rows are left out here. */
  window.workBlock = function (co, s) {
    const bd = BD[co.type];
    if (!R10 || !R10.dailyOk(co, bd)) return '';
    const a = agg(s.dd);
    if (!a.span) return '<p class="muted small">Numbers show after their first working day.</p>';
    const others = co.staff.filter(x => x.role === s.role && x !== s && x.dd && x.dd.length);
    const T = tmpl(co, s).filter(t => t[0] !== 'Hours a day');
    return '<div class="wk11"><b>What they did, last ' + (a.span >= 28 ? '4 weeks' : a.span + ' days') + '</b>' + T.map((t, i) => {
      let tv = '';
      if (i === 0 && others.length) {
        const avg = sum(others, x => t[2](agg(x.dd))) / others.length, me = t[2](a);
        tv = ' <small class="' + (me >= avg ? 'pos' : 'neg') + '">others in the job ' + esc(t[1]({ days: 1, h: 0, u: avg, f: 0, span: 7 }).replace(/^NaN$/, '0')) + '</small>';
      }
      return row(esc(t[0]), esc(t[1](a)) + tv);
    }).join('') + (s.rv11 && s.rv11.n ? row('Named in reviews', s.rv11.n + ' · ' + (s.rv11.sum / s.rv11.n).toFixed(1) + ' ★') : '') + '</div>';
  };
  /* ================= 2. reviews that name the worker, or you ================= */
  const FACE = { dentist: 1, rentag: 1, driver: 1, barber: 1, physio: 1, groom: 1, trainer: 1, instr: 1, tutor: 1, photog: 1, handy: 1, carwash: 1, cleaner: 1, barista: 1, waiter: 1, bartender: 1, cashier: 1, recept: 1, housek: 1, dealer: 1, usher: 1, estate: 1, cardealer: 1, sales: 1, agent: 1, banker: 1, teller: 1, consult: 1, lawyer: 1, acct: 1, chef: 1, guard: 1, courier: 1, dev: 1, designer: 1, marketer: 1, event: 1, elec: 1, plumb: 1, carp: 1, mech: 1 };
  const POS = {
    driver: ['{n} drove safely and knew every shortcut.', 'Clean car and a good chat with {n}. On time, too.'],
    estate: ['{n} sold our flat fast and got more than we hoped.', 'Calm and honest. {n} handled every viewing.'],
    cardealer: ['{n} found the right car for us, no pushy sales talk.'],
    barber: ['{n} gave me the best haircut in years.'], physio: ['{n} fixed my back in three sessions.'], dentist: ['{n} made the dentist something I do not dread any more.'], rentag: ['{n} had the car ready and explained everything.'], trainer: ['{n} pushed me just the right amount.'],
    instr: ['Passed first try thanks to {n}.'], tutor: ['Our son’s grades went up with {n}.'], photog: ['{n} took wonderful photos.'], groom: ['{n} was so gentle with our dog.'],
    handy: ['{n} fixed it quickly and cleaned up after.'], elec: ['{n} found the fault in minutes.'], plumb: ['{n} came the same day and fixed the leak.'], carp: ['Lovely work by {n}.'],
    cleaner: ['Spotless. {n} is very thorough.'], housek: ['Our room was spotless every day. Thanks, {n}.'],
    waiter: ['{n} looked after our table perfectly.'], barista: ['Best coffee in town, thanks to {n}.'], bartender: ['{n} mixes a great drink.'], chef: ['Compliments to {n} in the kitchen.'],
    lawyer: ['{n} explained everything clearly.'], acct: ['{n} sorted our books and saved us money.'], consult: ['{n} saw what we had missed.'], dev: ['{n} built exactly what we needed.'], designer: ['{n} has a great eye.'],
    recept: ['{n} at the front desk sorted everything out.'], courier: ['{n} always delivers on time and with a smile.'], cashier: ['{n} at the till is always friendly.']
  };
  const POSG = ['{n} was friendly and really helpful.', 'Ask for {n}. Made the whole thing easy.', 'Big thanks to {n} for great service.', '{n} went the extra mile for us.'];
  const MIDG = ['{n} was fine, nothing special.', 'Service from {n} was okay.'];
  const NEG = { driver: ['{n} drove far too fast. Felt unsafe.'], waiter: ['{n} forgot our order twice.'], estate: ['{n} never called us back.'], barber: ['{n} cut it far too short.'], courier: ['{n} left the parcel in the rain.'] };
  const NEGG = ['{n} was rude and seemed in a hurry.', 'Had to wait ages. {n} did not seem to care.'];
  const OWNP = ['The owner, {n}, served us personally. You can tell they care.', '{n}, who owns the place, took time to talk to us. Great service.'];
  const OWNN = ['The owner, {n}, was stressed and short with us.'];
  function faceCands(co) {
    const L = [];
    co.staff.forEach(s => {
      if (!FACE[s.role] || !S.npcs[s.id]) return;
      const a = agg(s.dd, 7);
      if (s.dd && s.dd.length && !a.days) return;
      L.push({ s, w: 1 + Math.sqrt(a.u || 1), q: staffSkill(s), name: first(S.npcs[s.id].name) });
    });
    if (!co.mgr && (co.ohrs || 0) > 0 && S.player) L.push({ s: null, w: Math.max(1, (co.ohrs / 40) * 3), q: co.oskill || 40, name: first(S.player.name) });
    return L;
  }
  function nrvWeek(co) {
    const bd = BD[co.type];
    if (!bd || ['fin', 'energy', 'hold', 'club', 'rent'].indexOf(bd.fam) >= 0) return;
    const to = co.rvN || 0;
    if (co.rv11c == null || co.st !== 'open') { co.rv11c = to; return; }
    const from = co.rv11c;
    co.rv11c = to;
    if (to <= from) return;
    const C = faceCands(co);
    if (!C.length) return;
    const share = bd.fam === 'retail' ? 0.12 : 0.25;
    co.nrv = co.nrv || [];
    for (let c = Math.max(from + 1, to - 25); c <= to; c++) {
      const R = hrng(S.seed + ':nrv:' + co.id + ':' + c);
      if (R() > share) continue;
      let x = R() * sum(C, y => y.w), pickd = C[0];
      for (const y of C) { if ((x -= y.w) <= 0) { pickd = y; break; } }
      const mu = clamp(ratingOf(co) + (pickd.q - 50) / 40, 1.2, 4.95);
      const st = pickStar(R, mu);
      const role = pickd.s ? pickd.s.role : null;
      const L = !pickd.s ? (st >= 4 ? OWNP : st <= 2 ? OWNN : MIDG) : st >= 4 ? (POS[role] && R() < 0.6 ? POS[role] : POSG) : st <= 2 ? (NEG[role] && R() < 0.6 ? NEG[role] : NEGG) : MIDG;
      const tx = L[Math.floor(R() * L.length)].replace('{n}', pickd.name);
      co.nrv.push({ c, st, tx, who: pickd.s ? S.npcs[pickd.s.id].name : S.player.name, sid: pickd.s ? pickd.s.id : 'you', w: S.week });
      if (pickd.s) {
        const o = pickd.s.rv11 = pickd.s.rv11 || { n: 0, sum: 0 };
        o.n++;
        o.sum += st;
        if (st >= 5) pickd.s.happy = Math.max(pickd.s.happy || 0, S.week + 4);
      }
    }
    if (co.nrv.length > 120) co.nrv = co.nrv.slice(-120);
  }
  window.R11NRV = function (key, c) {
    const co = S.cos.find(x => 'c' + x.id === key);
    if (!co || !co.nrv) return null;
    for (let i = co.nrv.length - 1; i >= 0; i--) if (co.nrv[i].c === c) return co.nrv[i];
    return null;
  };
  V.rvdetail = pipeView('V.rvdetail', V.rvdetail, 1); /* V.rvdetail: the screen above, then the steps below and in later files */
  addStep('V.rvdetail', 10, 'worker_roles_and_promotions V.rvdetail', (p, h) => {
    const co = p && S.cos.find(x => 'c' + x.id === p.k);
    if (!co || !co.nrv || !co.nrv.length) return h;
    const by = {};
    co.nrv.forEach(r => { const o = by[r.who] = by[r.who] || { n: 0, s: 0, you: r.sid === 'you' }; o.n++; o.s += r.st; });
    const L = Object.keys(by).sort((a, b) => by[b].n - by[a].n).slice(0, 8);
    const c2 = '<div class="card"><h3>Named in reviews<small>Customers who mention someone by name</small></h3>' + L.map(k => row(esc(k) + (by[k].you ? ' <small>(you)</small>' : ''), by[k].n + ' · ' + (by[k].s / by[k].n).toFixed(1) + ' ★')).join('') + '</div>';
    const mm = /<div class="card[ "]/g;
    mm.lastIndex = 5;
    const f2 = mm.exec(h), i = f2 ? f2.index : -1;
    return i > 0 ? h.slice(0, i) + c2 + h.slice(i) : h + c2;
  });

  /* ================= 3. a bought rival: own company, your branch, a franchise office, merged into yours or closed ================= */
  /* one short line each, so all the choices fit on one screen */
  const optB = (t, d, a, p, need) => { const no = need > S.cash; return '<button class="lrow' + (no ? ' cant' : '') + '" data-a="' + a + '" data-p="' + P11(p) + '"' + (no ? ' disabled' : '') + '><span class="ctext"><b>' + t + '</b><small' + (no ? ' class="need">Needs ' + mshort(need) + ' in your account' : '>' + d) + '</small></span><i>›</i></button>'; };
  ACT.rivclose = pipeView('ACT.rivclose', ACT.rivclose, 1);
  addStep('ACT.rivclose.around', 10, 'buying a rival: own company, branch, franchise office, merged or closed', (p, next) => {
    if (p.how === 'own') return next();
    const co = getCo(p.id), r = co && rivalsOf(co).find(x => x.id === p.r);
    if (!co || !r) return next();
    const fr = !!(co.fr && co.fr.on);
    const b = Object.assign({}, p);
    /* what each choice needs in your account (engine/world/rivals.js acquireRivalCore keeps a buffer; absorb below) */
    const nBuy = p.price + KC(200000, co.country), nMerge = p.price * 1.08, nShut = p.price * 1.12;
    openSheet('<h2>Buy ' + esc(r.name) + '</h2><p class="muted small">' + money(p.price) + '. What should it become? You have ' + mshort(S.cash) + '.</p><div class="lrows">' +
      optB('Its own company', 'Keeps its name and customers', 'rivclose', Object.assign({}, b, { how: 'own' }), nBuy) +
      optB('Your branch', 'Your name on the door from day one', 'rivhow', Object.assign({}, b, { how: 'branch' }), nBuy) +
      (fr ? optB('Franchise, owner stays', 'Pays half the fee and ' + pc(co.fr.roy, 0) + ' royalties', 'rivhow', Object.assign({}, b, { how: 'frold' }), nBuy) +
        optB('Franchise, new franchisee', 'Sold on for about half, full fee and royalties', 'rivhow', Object.assign({}, b, { how: 'frnew' }), nBuy) : '') +
      optB('Merge into ' + esc(co.name), 'Customers and some staff move over · about ' + mshort(p.price * 0.08), 'rivhow', Object.assign({}, b, { how: 'merge' }), nMerge) +
      optB('Close it down', 'One rival less · about ' + mshort(p.price * 0.12) + ' in costs', 'rivhow', Object.assign({}, b, { how: 'shut' }), nShut) +
      '</div>' + (fr ? '' : '<p class="muted small">Franchise offices need your franchise system first (Manage › Expand).</p>') +
      btn('Cancel', 'sheetclose', undefined, 'ghost wide'));
  });
  /* round 56: merge a bought rival into your company, or close it down */
  function myShare(co) {
    try { const m = window.R26 && R26.markets && R26.markets().find(x => (x.cos || []).indexOf(co) >= 0); return m ? R26.truthOf(m).share : 0; } catch (e) { return 0; }
  }
  function absorb(co, r, price, how) {
    const extra = rnl(price * (how === 'merge' ? 0.08 : 0.12), 1000);
    if (S.cash < price + extra) return 'cash';
    payMe(price, 'Bought ' + r.name);
    payMe(extra, how === 'merge' ? 'Merging ' + r.name + ' into ' + co.name : 'Closing ' + r.name);
    const m = ensureMk(co), sz = r.size || 1;
    m.riv = (m.riv || []).filter(x => x !== r);
    m.n = Math.max(1, (m.n || 1) - 1);
    if (window.R27 && R27.amb) R27.amb().cnt.buy++;
    if (how === 'merge') {
      co.aware = Math.min(100, (co.aware || 0) + 6 + sz * 8);
      co.wom = (co.wom || 0) + 6;
      co.rep = Math.min(100, (co.rep || 50) + 1);
      const roles = (BD[co.type].std || []).map(x => x[0]).filter(x => ROLES[x]);
      let came = 0;
      for (let i = 0; i < Math.max(1, Math.round(sz * 2)) && roles.length; i++) {
        const n = genCand(roles[i % roles.length], co);
        if (!S.npcs[n.id]) S.npcs[n.id] = n;
        if (hireWorker(co, n, n.ask) === 'ok') came++;
      }
      note(r.name + ' is now part of ' + co.name + '. Their customers come over' + (came ? ', and ' + came + (came === 1 ? ' of their staff joins' : ' of their staff join') + ' you' : '') + '.', 'good', co.id);
      return { came };
    }
    co.aware = Math.min(100, (co.aware || 0) + 2 + sz * 4);
    const sh = myShare(co);
    let fine = 0;
    if (sh > 0.35 && chance(Math.min(0.8, 0.25 + (sh - 0.35)))) {
      fine = rnl(Math.max(KC(100000, co.country), (co.lastW ? co.lastW.rev * 52 : 0) * 0.03), 1000);
      payCo(co, fine, 'fine', 'Competition authority: closing ' + r.name);
      co.rep = Math.max(0, (co.rep || 50) - 4);
      news('The competition authority fines ' + co.name + ' for buying and closing ' + r.name + '.', 'bad');
    }
    note(r.name + ' has closed. ' + co.name + ' has one competitor less' + (fine ? ', but the competition authority fined you ' + money(fine) + ': you hold ' + Math.round(sh * 100) + '% of the market.' : '.'), fine ? 'bad' : 'good', co.id);
    return { fine };
  }
  R11.absorb = absorb;
  ACT.rivhow = p => {
    const co = getCo(p.id), r = co && rivalsOf(co).find(x => x.id === p.r);
    if (!co || !r) return;
    if (p.how === 'merge' || p.how === 'shut') {
      const x = absorb(co, r, p.price, p.how);
      if (typeof x === 'string') { U.res(x); return; }
      closeSheet();
      save();
      render(true);
      toast(p.how === 'merge' ? r.name + ' is now part of ' + co.name + '.' : r.name + ' has closed.');
      return;
    }
    if (p.how === 'branch') {
      const n = acquireRival(co, r, p.price);
      if (typeof n === 'string') { U.res(n); return; }
      const k = S.cos.filter(c => c.branch && c.branch.of === co.id).length + 2;
      n.name = co.name + ' ' + k;
      n.branch = { of: co.id };
      n.aware = Math.max(n.aware, (co.aware || 0) * 0.9);
      n.rep = Math.max(n.rep, (co.rep || 50) * 0.95);
      closeSheet();
      save();
      ui.stack = [];
      ui.tab = 'cos';
      ui.view = { n: 'co', p: { id: n.id, t: 'ov' } };
      render(true);
      toast(r.name + ' is now ' + n.name + '.');
      return;
    }
    const f = co.fr;
    if (!f || !f.on) return;
    const old = p.how === 'frold';
    const back = old ? 0 : rnl(p.price * rng(0.45, 0.6), 1000);
    if (S.cash < p.price - back) { U.res('cash'); return; }
    payMe(p.price, 'Bought ' + r.name);
    if (back) gainMe(back, 'Franchisee takes over ' + r.name);
    const m = ensureMk(co);
    m.riv = (m.riv || []).filter(x => x !== r);
    m.n = Math.max(1, (m.n || 1) - 1);
    const nm = old ? (r.owner || personName()) : personName();
    f.units.push({ id: uid(), name: nm, city: co.city, w0: S.week - 40, skill: old ? rint(60, 82) : rint(40, 80), rev: 0, prof: 0, neg: 0, setup: 0, from: r.name });
    coIn(co, Math.round(f.fee * (old ? 0.5 : 1)), 'rev', 'Franchise fee: ' + nm);
    f.brand = Math.min(100, f.brand + 2);
    co.aware = Math.min(100, (co.aware || 0) + 3);
    note(r.name + ' now runs as a ' + co.name + ' franchise office, led by ' + nm + '.', 'good', co.id);
    closeSheet();
    save();
    render(true);
    toast(r.name + ' is now one of your franchise offices.');
  };

  /* ================= 4. promotions ================= */
  const HQM = { hr: 'hr', acct: 'acc', lawyer: 'law', analyst2: 'ana', analyst: 'ana', marketer: 'mkt', buyer: 'proc', consult: 'strat', designer: 'mkt' };
  const MGR_HQ = ['perf', 'strat', 'proc', 'hr'];
  const AUTHN = ['Ask me first', 'Within limits', 'Full control'];
  const DUTY = {
    mgr: [['hire', 'Hiring staff'], ['buy', 'Buying equipment and space']],
    exec: [['quality', 'Quality checks'], ['coach', 'Coaching managers'], ['hire', 'Finding managers']]
  };
  const REPS = [['week', 'Weekly update'], ['month', 'Monthly report'], ['need', 'Only when needed']];
  function ensureStats(n, role) {
    if (n.stats) return n.stats;
    const b = n.skill || 50, R = hrng('st11:' + n.id), z = () => (R() - 0.5) * 20;
    const st = { ops: b + z(), people: b + z(), sales: b + z(), fin: b - 6 + z(), risk: b + z(), ethic: 55 + z() };
    if (SALES_ROLES[role]) st.sales += 12;
    if (role === 'acct') st.fin += 15;
    if (role === 'hr') st.people += 12;
    if (role === 'lead') { st.people += 6; st.ops += 6; }
    if (role === 'lawyer') st.risk += 12;
    if (role === 'consult') { st.ops += 8; st.fin += 6; }
    Object.keys(st).forEach(k => { st[k] = Math.round(clamp(st[k], 5, 98)); });
    n.stats = st;
    n.mtype = n.mtype || 'gen';
    return st;
  }
  const qOf = n => n && n.stats ? (n.stats.ops + n.stats.people + n.stats.sales + n.stats.fin + n.stats.risk) / 500 : 0.5;
  const mgrBase = c => wageFor(BD[c.type].std[0] ? BD[c.type].std[0][0] : 'helper', c) * 1.55;
  /* who is being promoted: a worker in a company, or that company's manager */
  function candOf(p) {
    const co = getCo(p.id);
    if (!co) return null;
    if (p.m) {
      const n = co.mgr && S.npcs[co.mgr];
      return n ? { co, n, m: 1, pay: co.mgrWage || 0, role: 'mgr', skill: Math.round(mgrQual(co) * 100) } : null;
    }
    const s = co.staff.find(x => x.id === p.s);
    const n = s && S.npcs[s.id];
    return n ? { co, n, s, m: 0, pay: s.wage, role: s.role, skill: staffSkill(s) } : null;
  }
  function postsFor(c) {
    const L = [], co = c.co, cos = liveCos().filter(x => x.st === 'open' || x.st === 'setup');
    if (!c.m) ladderFor(co, c.s).forEach(r => L.push({ k: 'role:' + r, t: ROLES[r][0], where: co.name, base: wageFor(r, co) * (0.8 + c.skill / 200), kind: 'role' }));
    if (!c.m && !co.mgr) L.push({ k: 'mgr@' + co.id, t: titleFor(co, 'mgr'), where: co.name, base: mgrBase(co), kind: 'mgr' });
    cos.filter(x => x.id !== co.id && !x.mgr && BD[x.type].fam !== 'hold').slice(0, 4).forEach(x => L.push({ k: 'mgr@' + x.id, t: titleFor(x, 'mgr'), where: x.name, base: mgrBase(x), kind: 'mgr' }));
    if (window.R12chiefPosts) window.R12chiefPosts(c).forEach(x => L.push(Object.assign({ base: mgrBase(co) * 1.5, kind: 'exec' }, x)));
    const hk = c.m ? MGR_HQ : HQM[c.role] ? [HQM[c.role]] : [];
    hk.forEach(k => {
      if (!HQ_ROLES[k]) return;
      const r = hqRoom(k);
      const off = r === 'ok' ? '' : r === 'have' ? 'Already filled' : r === 'office' ? 'Needs an office' : r === 'homeoffice' ? 'Needs a bigger main office' : r === 'desks' ? 'No free desk' : r === 'locked' ? (typeof hqUnlockText === 'function' ? 'Opens when you run ' + hqUnlockText(k) : 'Not open yet') : 'Not possible';
      L.push({ k: 'hq:' + k, t: HQ_ROLES[k][0], where: 'Your main office', base: KC(HQ_ROLES[k][1]), kind: 'exec', off });
    });
    return L;
  }
  const askFor = (c, post) => r500(Math.max(c.pay * 1.12, post.base * (0.85 + c.skill / 300)));
  const patMax = n => n.pers === 'driven' ? 5 : n.pers === 'loyal' || n.pers === 'steady' ? 8 : 7;
  const dots = (n, left) => '<span class="pdots">' + Array.from({ length: patMax(n) }, (x, i) => '<i class="' + (i < left ? 'on' : '') + '"></i>').join('') + '</span>';

  V.titles.pr11 = 'Promotion';
  V.pr11 = function (p) {
    const c = candOf(p);
    if (!c) return '<div class="calm">This person is no longer here.</div>';
    const { co, n } = c;
    let h = '<div class="card"><div class="cchd">' + faceAv(n) + '<span class="ctext"><b>' + esc(n.name) + '</b><small>' + esc(c.m ? titleFor(co, 'mgr') : ROLES[c.role][0]) + ' · ' + esc(co.name) + ' · ' + money(c.pay) + '/mo</small></span></div>' +
      (c.m ? row('Managing since', dateStr(co.mgrW0 || S.week)) + row('Last month', plus(lastProfit(co) || 0)) : (window.workBlock ? window.workBlock(co, c.s) : '')) + '</div>';
    h += btn((hasHQ('ana') ? 'Analyst report on ' : 'Your notes on ') + esc(first(n.name)) + ' ›', 'go', { n: 'anrep11', p: { id: co.id, s: c.s ? c.s.id : null, m: c.m } }, 'wide');
    const L = postsFor(c);
    h += '<h2 class="sec">Promote to</h2><div class="lrows">' + (L.length ? L.map(x => x.off ? '<div class="lrow dim"><span class="ctext"><b>' + esc(x.t) + '</b><small>' + esc(x.where) + ' · ' + esc(x.off) + '</small></span></div>' : '<button class="lrow" data-a="p11talk" data-p="' + P11({ id: co.id, s: c.s ? c.s.id : null, m: c.m, k: x.k }) + '"><span class="ctext"><b>' + esc(x.t) + '</b><small>' + esc(x.where) + ' · will ask about ' + mshort(askFor(c, x)) + '/mo</small></span><i>›</i></button>').join('') : '<div class="calm">No higher post fits right now.</div>') + '</div>';
    return h;
  };
  ACT.p11talk = p => {
    const c = candOf(p);
    if (!c) return;
    const post = postsFor(c).find(x => x.k === p.k);
    if (!post || post.off) return;
    const n = c.n;
    if (n.p11no && S.week < n.p11no) { toast(first(n.name) + ' does not want to talk about it again yet.', true); return; }
    const ask = askFor(c, post);
    const st = n.p11 && n.p11.k === p.k ? n.p11 : (n.p11 = { k: p.k, ask, pat: patMax(n), log: [], w: S.week });
    st.ask = ask;
    ui.p11 = { id: c.co.id, s: c.s ? c.s.id : null, m: c.m, k: p.k, wage: ui.p11 && ui.p11.k === p.k ? ui.p11.wage : ask, bonus: 0, auth: 1, duties: post.kind === 'role' ? [] : DUTY[post.kind === 'mgr' ? 'mgr' : 'exec'].map(x => x[0]).slice(0, post.kind === 'mgr' ? 2 : 2), rep: 'month' };
    ui.inp['p11w'] = String(Math.round(ask / fxr(CC())));
    go('p11talk', { id: c.co.id });
  };
  V.titles.p11talk = 'Promotion talk';
  V.p11talk = function () {
    const u = ui.p11, c = u && candOf(u);
    if (!c) return '<div class="calm">Nothing to discuss.</div>';
    const n = c.n, post = postsFor(c).find(x => x.k === u.k);
    const st = n.p11;
    if (!post || !st) return '<div class="calm">That post is no longer open.</div>';
    const done = st.done;
    const msgs = [{ sys: 1, t: 'Promotion talk · ' + post.t + ' · ' + post.where }, { me: 0, t: 'Thank you for thinking of me. For ' + (post.kind === 'role' ? 'that job' : 'a step like this') + ' I would expect about ' + money(st.ask) + ' a month.' }].concat(st.log);
    const bub = x => '<div class="bub ' + (x.sys ? 'sys' : x.me ? 'me' : 'them') + '">' + esc(x.t) + '</div>';
    let h = '<div class="ichat phone7"><div class="ph7top"><button class="bk" data-a="p11back" aria-label="Back">‹</button>' + faceAv(n) + '<div class="vht"><h1>' + esc(n.name) + '</h1><p>' + esc(post.t) + ' · now ' + mshort(c.pay) + '/mo</p></div>' + dots(n, st.pat) + '</div>';
    h += '<div class="clog"><div class="cfill"></div>' + msgs.map(bub).join('') + '</div><div class="composer">';
    if (done) return h + '<div class="crow">' + btn(done === 'yes' ? 'Done' : 'Close', 'p11back', {}, 'primary wide') + '</div></div></div>';
    const seg = (items, cur, k) => '<div class="seg7">' + items.map(x => '<button class="' + (x[0] === cur ? 'on' : '') + '" data-a="p11set" data-p="' + P11({ k, v: x[0] }) + '">' + x[1] + '</button>').join('') + '</div>';
    if (post.kind !== 'role') {
      h += '<div class="chips qk">' + DUTY[post.kind === 'mgr' ? 'mgr' : 'exec'].map(x => '<button class="btn chip' + (u.duties.indexOf(x[0]) >= 0 ? ' primary' : '') + '" data-a="p11duty" data-p="' + P11({ v: x[0] }) + '">' + x[1] + '</button>').join('') + '</div>';
      h += seg(AUTHN.map((x, i) => [i, x]), u.auth, 'auth');
      h += seg(REPS, u.rep, 'rep');
    }
    h += seg([[0, 'No bonus'], [0.05, '5% bonus'], [0.1, '10%'], [0.2, '20%']], u.bonus, 'bonus');
    if (c.co.form === 'AS' && c.co.own > 10) h += seg([[0, 'No shares'], [2, '2% shares'], [5, '5%'], [10, '10%']], u.eq || 0, 'eq');
    h += '<div class="chips qk">' + [0.9, 1, 1.1].map(f => { const v = r500(st.ask * f); return '<button class="btn chip' + (rnl(U.inum('p11w', st.ask), 500) === v ? ' primary' : '') + '" data-a="setinp" data-p="' + P11({ k: 'p11w', v }) + '">' + Math.round(f * 100) + '% · ' + mshort(v) + '</button>'; }).join('') + '</div>';
    h += '<div class="crow">' + U.inp('p11w', 'Monthly salary', st.ask) + btn('Send', 'p11offer', {}, 'primary') + '</div>';
    return h + '</div></div>';
  };
  ACT.p11set = p => { if (ui.p11) ui.p11[p.k] = p.v; render(); };
  ACT.p11duty = p => {
    const u = ui.p11;
    if (!u) return;
    const i = u.duties.indexOf(p.v);
    if (i >= 0) u.duties.splice(i, 1); else u.duties.push(p.v);
    render();
  };
  ACT.p11back = () => { ui.p11 = null; U.back(); };
  ACT.p11offer = () => {
    const u = ui.p11, c = u && candOf(u);
    if (!c) return;
    const n = c.n, st = n.p11, post = postsFor(c).find(x => x.k === u.k);
    if (!st || !post || st.done) return;
    const w = r500(U.inum('p11w', st.ask));
    const senior = post.kind === 'exec';
    const need = st.ask * (1 + Math.max(0, u.duties.length - 1) * 0.03 + (post.kind === 'role' ? 0 : u.auth === 2 ? -0.03 : u.auth === 0 && senior ? 0.03 : 0) + (senior && u.rep === 'week' ? 0.02 : 0));
    const eqV = (u.eq || 0) && c.co.form === 'AS' ? Math.max(0, companyValue(c.co)) * u.eq / 100 / 36 : 0;
    const eff = w + w * u.bonus * 0.6 + eqV;
    st.log.push({ me: 1, t: 'I can offer ' + money(w) + ' a month' + ((u.eq || 0) ? ' and ' + u.eq + '% of the shares' : '') + (u.bonus ? ' plus a ' + Math.round(u.bonus * 100) + '% yearly bonus' : '') + (post.kind !== 'role' ? ', ' + AUTHN[u.auth].toLowerCase() + (u.duties.length ? ', you handle ' + u.duties.map(d => DUTY[post.kind === 'mgr' ? 'mgr' : 'exec'].find(x => x[0] === d)[1].toLowerCase()).join(' and ') : '') + ', ' + REPS.find(x => x[0] === u.rep)[1].toLowerCase() : '') + '.' });
    if (eff >= need) {
      st.done = 'yes';
      st.log.push({ me: 0, t: pick(['Deal. Thank you, I will not let you down.', 'Then we have a deal. I start on Monday.', 'Yes. I have wanted this for a while.']) });
      const msg = applyPost(c, post, w, u) + ((u.eq || 0) && c.co.form === 'AS' && c.co.own > u.eq ? (window.R15give ? window.R15give(c.co, n, u.eq) : '') : '');
      st.log.push({ sys: 1, t: msg });
      save();
      render();
      return;
    }
    if (eff >= need * 0.9) {
      st.pat -= 1;
      st.log.push({ me: 0, t: 'Close. Make it ' + money(r500(need / (1 + u.bonus * 0.6))) + (u.duties.length > 2 ? ', or take one duty off me,' : '') + ' and we have a deal.' });
    } else {
      st.pat -= 2;
      st.log.push({ me: 0, t: post.kind === 'role' ? 'That is not much more than I earn now.' : 'That is too little for this much responsibility.' });
    }
    if (st.pat <= 0) {
      st.done = 'no';
      st.log.push({ me: 0, t: 'Let us leave it. I will keep my current job for now.' });
      n.p11no = S.week + 8;
      n.p11 = Object.assign({}, st);
      if (c.s) { c.s.happy = 0; if (chance(0.25)) c.s.notice = 4; }
      else if (c.co) c.co.mood = Math.max(0, (c.co.mood || 60) - 10);
    }
    save();
    render();
  };
  function leaveJob(c) {
    const { co, n } = c;
    if (c.m) {
      co.mgr = null;
      co.mgrWage = 0;
      co.mgrBonus = 0;
      if (co.auth) co.auth.lvl = 0;
    } else co.staff = co.staff.filter(x => x !== c.s);
    n.hired = 0;
  }
  function applyPost(c, post, w, u) {
    const { co, n } = c;
    const k = post.k;
    n.k11 = { post: k, t: post.t, wage: w, bonus: u.bonus, duties: u.duties.slice(), auth: u.auth, rep: u.rep, w0: S.week, from: { co: co.id, role: c.role } };
    n.p11 = null;
    if (k.indexOf('role:') === 0) {
      promoteStaff(co, c.s.id, k.slice(5));
      c.s.wage = w;
      return first(n.name) + ' is now ' + ROLES[k.slice(5)][0] + ' at ' + co.name + '.';
    }
    if (k.indexOf('mgr@') === 0) {
      const to = getCo(+k.slice(4)) || S.cos.find(x => String(x.id) === k.slice(4));
      ensureStats(n, c.role);
      leaveJob(c);
      to.mgr = n.id;
      to.mgrWage = w;
      to.mgrBonus = u.bonus;
      to.mgrW0 = S.week;
      to.ohrs = 0;
      to.mood = Math.max(to.mood || 0, 62);
      to.flags.fraud = 0;
      to.lastRev = null;
      if (to.auth) to.auth.lvl = u.auth;
      n.hired = to.id;
      return first(n.name) + ' now manages ' + to.name + '.';
    }
    ensureStats(n, c.role);
    let ok = false;
    const had = c.m ? co.name : null;
    leaveJob(c);
    if (k.indexOf('chain:') === 0) ok = !!(window.R12hireChief && window.R12hireChief(k.slice(6), n, w, u.auth));
    else if (k.indexOf('hq:') === 0) {
      const role = k.slice(3);
      if (hqRoom(role) === 'ok') { n.hired = -3; S.office.staff.push({ id: n.id, role, name: n.name, wage: w, w0: S.week, onb: {} }); ok = true; }
    }
    if (!ok) {
      n.hired = 0;
      return 'Something blocked the move. Check that your office has a free desk.';
    }
    const seat = window.R12execSeat(n, post);
    /* round 56: someone who moves up appoints their own successor (features/company/chain_hierarchy.js fillManager) */
    if (had) { const sc = window.CHN56 && CHN56.fillManager(co, n.name, n.name.split(' ')[0] + ' moved up to ' + post.t.toLowerCase()); if (sc) co.mgr12 = co.mgr; else note(had + ' has no manager now. Find one, or run it yourself.', 'bad', co.id); }
    return first(n.name) + ' is now ' + post.t + '.' + (seat === 'none' ? '' : seat ? ' ' + first(n.name) + ' joins the board.' : ' The board is full, so no seat.');
  }
  /* the manager's duties are real: without them, those decisions come to you */
  if (typeof window.makeProposal === 'function') {
    window.makeProposal = pipeView('window.makeProposal', window.makeProposal, 2);
    addStep('window.makeProposal.around', 10, 'the manager’s duties are real: without them, those decisions come to you', (co, dp, next) => {
      const n = co && co.mgr && S.npcs[co.mgr];
      const d = n && n.k11 && n.k11.post && n.k11.post.indexOf('mgr@') === 0 ? n.k11.duties : null;
      const need = dp && (dp.t === 'hire' ? 'hire' : dp.t === 'eq' || dp.t === 'veh' || dp.t === 'space' ? 'buy' : null);
      if (d && need && d.indexOf(need) < 0 && co.auth) {
        const l = co.auth.lvl;
        co.auth.lvl = 0;
        try { return next(); } finally { co.auth.lvl = l; }
      }
      return next();
    });
  }
  /* bosses above lift (or drag) every manager under them */
  addStep('mgrQual', 10, 'bosses above lift (or drag) every manager under them', (co, q) => {
    if (!co || !co.mgr) return q;
    let f = 1;
    const rg = co.region && S.group && S.group.regional.find(r => r.id === co.region);
    if (rg && S.npcs[rg.npc]) f *= 1 + 0.1 * (qOf(S.npcs[rg.npc]) - 0.5);
    if (S.group && S.group.ceo && S.npcs[S.group.ceo.npc]) f *= 1 + 0.06 * (qOf(S.npcs[S.group.ceo.npc]) - 0.5);
    return clamp(q * f, 0.05, 1);
  });
  /* report preference of a promoted manager */
  if (typeof window.shouldPack === 'function') {
    window.shouldPack = pipeView('window.shouldPack', window.shouldPack, 2);
    addStep('window.shouldPack.around', 10, 'report preference of a promoted manager', (co, rs, next) => {
      const n = co && co.mgr && S.npcs[co.mgr];
      if (n && n.k11 && n.k11.rep === 'need') { const h = co.hist && co.hist[co.hist.length - 1]; return !!(h && h.profit < 0); }
      if (n && n.k11 && (n.k11.rep === 'month' || n.k11.rep === 'week')) return true;
      return next();
    });
  }
  /* entry points: the old promote buttons open the new flow */
  ACT.promosheet = p => go('pr11', { id: p.id, s: p.s });
  ACT.promoteact = p => {
    const co = getCo(p.id), a = co && window.actingMgr && window.actingMgr(co);
    if (a) go('pr11', { id: co.id, s: a.id });
  };

  /* ---------- analyst report on a person ---------- */
  V.titles.anrep11 = 'Report';
  V.anrep11 = function (p) {
    const c = candOf(p);
    if (!c) return '<div class="calm">This person is no longer here.</div>';
    const { co, n } = c, ana = hasHQ('ana'), acc = ana ? analystAcc() : 0;
    const rng2 = (v, i) => { const e = Math.round((1 - acc) * 22 + 4), R = hrng('ar11:' + n.id + ':' + i + ':' + Math.floor(S.week / 13)), c0 = v + (R() - 0.5) * e; return Math.round(clamp(c0 - e / 2, 0, 100)) + '–' + Math.round(clamp(c0 + e / 2, 0, 100)); };
    let h = '<div class="card"><div class="cchd">' + faceAv(n) + '<span class="ctext"><b>' + esc(n.name) + '</b><small>' + (ana ? 'Prepared by your data analyst' : 'Your own notes. A data analyst in your office writes a full report.') + '</small></span></div></div>';
    if (c.m) {
      const H = co.hist || [], w0 = co.mgrW0 || 0, m0 = monthIdx(w0);
      const bef = H.filter(x => x.m < m0).slice(-3), aft = H.filter(x => x.m >= m0).slice(-3);
      const av = (L, k) => L.length ? sum(L, x => x[k]) / L.length : null;
      const fmt = v => v == null ? '–' : plus(Math.round(v));
      const rb = av(bef, 'rev'), ra = av(aft, 'rev');
      h += '<div class="card"><h3>Results<small>Average month, before and since ' + esc(first(n.name)) + ' took over</small></h3>' + row('Revenue before', rb == null ? '–' : money(Math.round(rb))) + row('Revenue now', ra == null ? '–' : money(Math.round(ra)) + (rb ? ' <small class="' + (ra >= rb ? 'pos' : 'neg') + '">' + (ra >= rb ? '+' : '') + Math.round((ra / rb - 1) * 100) + '%</small>' : '')) + row('Profit before', fmt(av(bef, 'profit'))) + row('Profit now', fmt(av(aft, 'profit'))) +
        (ra ? row('Margin now', Math.round(av(aft, 'profit') / ra * 100) + '% <small>normal for the trade about ' + Math.round((BD[co.type].m || 0.08) * 100) + '%</small>') : '') + row('Customer rating', ratingOf(co).toFixed(1) + ' ★') + row('Staff mood', co.mood != null ? Math.round(co.mood) + ' / 100' : '–') + row('Staff', co.staff.length + ' people') + '</div>';
    } else {
      const s = c.s, a = agg(s.dd);
      h += '<div class="card"><h3>Work</h3>' + (window.workBlock ? window.workBlock(co, s) : '') + '</div>';
      const rh = s.rh || [];
      const share = co.lastW && co.lastW.units && a.span ? Math.min(1, perWeek(a) / co.lastW.units) : 0;
      h += '<div class="card"><h3>Money</h3>' + (rh.length ? row('Sales they made, last ' + rh.length + ' weeks', money(sum(rh, x => x))) : '') + (share ? row('Share of the company’s work', Math.round(share * 100) + '%') : '') + row('Costs you', money(s.wage) + '/mo') + '</div>';
      h += '<div class="card"><h3>Reliability</h3>' + row('Late this quarter', s.late || 0) + row('Client complaints', s.cmp || 0) + row('Warnings', s.warn || 0) + (DRIVE[s.role] != null ? row('Speeding fines, 4 weeks', a.f) : '') + (s.rv11 && s.rv11.n ? row('Named in reviews', s.rv11.n + ' · ' + (s.rv11.sum / s.rv11.n).toFixed(1) + ' ★') : row('Named in reviews', 'not yet')) + '</div>';
      h += '<div class="card"><h3>Growth</h3>' + row('Performance now', skillBand(staffSkill(s))) + row('Better since they started', ((s.skillGain || 0) >= 0 ? '+' : '') + Math.round(s.skillGain || 0) + ' points') + (ana && n.pot ? row('Could reach', rng2(n.pot, 'pot')) : '') + '</div>';
    }
    if (ana) {
      const stt = n.stats || ensureStats(Object.assign({}, n, { stats: null }), c.role);
      h += '<div class="card"><h3>Leadership estimate<small>' + (acc >= 0.8 ? 'Fairly sure' : acc >= 0.5 ? 'Rough' : 'Very rough') + '</small></h3>' + [['ops', 'Running things'], ['people', 'People'], ['sales', 'Sales'], ['fin', 'Money'], ['risk', 'Risk sense']].map((x, i) => row(x[1], rng2(stt[x[0]], i))).join('') + '</div>';
      const sc = c.m ? mgrQual(co) * 100 + ((co.hist || []).slice(-3).every(x => x.profit > 0) ? 8 : -8) : staffSkill(c.s) * 0.6 + qOf({ stats: stt }) * 40;
      const verdict = sc >= 72 ? 'Ready for a bigger job. Strong across the board.' : sc >= 58 ? 'Could grow into a bigger job with support.' : sc >= 45 ? 'Better kept where they are for now.' : 'Not ready. Results and skills point the other way.';
      h += '<div class="card"><h3>Verdict</h3><p>' + esc(verdict) + '</p></div>';
    } else h += btn('Hire a data analyst', 'tab', 'hq', 'wide');
    return h;
  };

  /* ---------- the weekly rhythm: named reviews, exec duties and reports (boards: features/company/shelf_stock_chains_boards.js) ---------- */
  function scopeCos(n) {
    const rg = S.group && S.group.regional.find(r => r.npc === n.id);
    if (rg) return liveCos().filter(c => c.region === rg.id || rg.scope === 'all' || BD[c.type].cat === rg.scope);
    if (S.group && S.group.ceo && S.group.ceo.npc === n.id) return liveCos();
    return [];
  }
  function execWeek() {
    const ex = [];
    if (S.group && S.group.ceo) ex.push(S.group.ceo.npc);
    ((S.group && S.group.regional) || []).forEach(r => ex.push(r.npc));
    ex.forEach(id => {
      const n = S.npcs[id];
      if (!n || !n.k11) return;
      const q = qOf(n), L = scopeCos(n).filter(c => c.st === 'open');
      const d = n.k11.duties || [];
      L.forEach(c => {
        if (d.indexOf('quality') >= 0) c.q = clamp((c.q || 50) + 0.4 * q, 0, 100);
        if (d.indexOf('coach') >= 0 && c.mgr) c.mood = Math.min(85, (c.mood || 60) + 0.5 * q);
      });
      if (d.indexOf('hire') >= 0) {
        const need = L.find(c => !c.mgr && c.staff.length >= 2 && !(c.flags.f11 > S.week - 8));
        if (need) {
          need.flags.f11 = S.week;
          const m = genManager(need, BD[need.type].mgr);
          S.npcs[m.id] = m;
          addMsg({ kind: 'ask', from: n.name, title: 'I found a manager for ' + need.name, body: m.name + ', ' + m.age + ', ' + (m.exp || 5) + ' years of experience. Asks ' + money(m.ask) + ' a month. I checked the references.', co: need.id, opts: [{ l: 'Hire at ' + mshort(m.ask), d: '', fx: {} }, { l: 'No thanks', d: '', fx: {} }], act: 'mfind11', data: { n: m.id }, exp: S.week + 3 });
        }
      }
      const rep = n.k11.rep;
      const me = isMonthEnd(S.week);
      const bad = L.filter(c => { const h = c.hist && c.hist[c.hist.length - 1]; return h && h.profit < 0; });
      if ((rep === 'week') || (rep === 'month' && me) || (rep === 'need' && me && bad.length)) {
        const lines = L.slice(0, 8).map(c => { const h = (c.hist || [])[c.hist.length - 1] || {}; return c.name + ': revenue ' + mshort(h.rev || 0) + ', profit ' + mshort(h.profit || 0) + (c.mgr ? '' : ' (no manager)'); });
        addMsg({ kind: 'info', from: n.name, title: (rep === 'week' ? 'Weekly update' : 'Monthly report') + ' from your ' + (n.k11.t || 'manager').toLowerCase(), body: lines.join('\n') || 'Nothing to report.', tone: bad.length ? 'bad' : 'n', status: 'done' });
      }
      if (isYearEnd(S.week) && n.k11.bonus) {
        const pr = sum(L, c => sum((c.hist || []).slice(-12), x => x.profit || 0));
        if (pr > 0) payHQ(Math.round(n.k11.wage * 12 * n.k11.bonus), 'Bonus: ' + n.name);
      }
    });
  }
  ACTS.mfind11 = (m, idx) => {
    const co = getCo(m.co), n = S.npcs[m.data.n];
    if (!co || !n || idx !== 0 || co.mgr) return true;
    n.ask = n.ask || KC(50000);
    const r = hireManager(co, n, n.ask);
    if (r !== 'ok') info(n.name, 'Changed my mind', 'Sorry, I took another job.', co.id, 'bad');
    return true;
  };
  addStep('week.after', 55, 'worker_roles_and_promotions weekly', () => {
    try { S.cos.forEach(co => { try { nrvWeek(co); } catch (e) { console.error(e); } }); } catch (e) { console.error(e); }
    try { execWeek(); } catch (e) { console.error(e); }
  });
}


/* ===== Round 48: milestones in your own currency, part-time staff, home starts earn their word of mouth.
   (Growth rankings: patch31.py gives every crowd firm a growth figure.) ===== */
window.R48 = window.R48 || {};
(function () {
  'use strict';
  const U = window.UI;
  if (!U) return;
  const { ui, V, ACT, esc, render, go } = U;
  const P = o => esc(JSON.stringify(o));

  /* ================= 1. money milestones are round numbers in your own currency ================= */
  try {
    const A = window.R28 && R28.ACH;
    if (A) {
      const C = () => CO[S.country] || CC();
      const unit = () => ({ JPY: 1e8, KRW: 1e9 }[C().cur] || 1e6);
      const amt = k => unit() * k * fxr(C()); /* local amount → internal */
      const words = v => v >= 1e9 ? (v / 1e9) + ' billion' : (v / 1e6) + ' million';
      const nw = () => { try { return netWorth().total; } catch (e) { return 0; } };
      const set = (id, k, title) => {
        const a = A.find(x => x[0] === id);
        if (!a) return;
        Object.defineProperty(a, 1, { get: title, configurable: true });
        a[3] = () => nw() >= amt(k) && 'Your net worth passed ' + money(amt(k)) + '.';
      };
      set('million', 1, () => unit() === 1e6 ? 'First million' : 'First ' + words(unit()));
      set('tenm', 10, () => 'Net worth of ' + words(10 * unit()));
      set('hm', 100, () => 'Net worth of ' + words(100 * unit()));
      set('bn', 1000, () => unit() === 1e6 ? 'A billionaire' : 'Net worth of ' + words(1000 * unit()));
    }
  } catch (e) { console.error(e); }

  /* ================= 2. how the next person is hired: full time, part time or seasonal, and the pay basis ================= */
  /* hours, pay basis and seasons are in engine/people/people.js (FULL_H, HIRE_HOURS, HIRE_BASIS, HIRE_SEAS, FIX_NORM);
     the year of each trade is in features/people/seasons_and_hours.js. The hire screen picks them per company:
     ui.hk54[company] = { k: 'full' | 'part' | 'sea', basis: null (the custom for the job) | 'hour' | 'fix', ms: months,
     h: weekly hours for part time or seasonal (20 and 25 unless chosen) } */
  const hk = id => (ui.hk54 = ui.hk54 || {})[id] || (ui.pt48 && ui.pt48[id] ? { k: 'part' } : { k: 'full' });
  const setHk = (id, o) => { ui.hk54 = ui.hk54 || {}; ui.hk54[id] = Object.assign({}, hk(id), o); if (ui.pt48) delete ui.pt48[id]; };
  if (ACT.offer) {
    addStep('ACT.offer.around', 60, 'part time, seasonal or full time, and the pay basis', (p, next) => {
      const o = hk(p && p.id);
      HIRE_HOURS = o.k === 'full' ? 0 : o.h || (o.k === 'sea' ? 25 : 20);
      HIRE_SEAS = o.k === 'sea' && o.ms && o.ms.length ? o.ms.slice() : null;
      HIRE_BASIS = o.k === 'full' ? o.basis || null : null;
      try { return next(); } finally { HIRE_HOURS = 0; HIRE_SEAS = null; HIRE_BASIS = null; }
    });
  }
  window.HK54 = hk; /* the hiring screen reads the chosen hours and pay basis (ui/screens/hiring.js) */
  ACT.pt48 = p => { setHk(p.id, { k: p.v ? 'part' : 'full' }); render(); };
  ACT.hk54k = p => { const co = getCo(p.id); setHk(p.id, { k: p.v, ms: p.v === 'sea' && !(hk(p.id).ms || []).length && co && window.R54 ? R54.busyMonths(co) : hk(p.id).ms }); render(); };
  ACT.hk54b = p => { setHk(p.id, { basis: p.v }); render(); };
  ACT.hk54h = p => { setHk(p.id, { h: p.v }); render(); };
  ACT.hk54s = p => {
    const S0 = window.R54 ? R54.SEASONS.find(s => s[0] === p.v) : null;
    if (!S0) return;
    let ms = (hk(p.id).ms || []).slice();
    const all = S0[2].every(m => ms.indexOf(m) >= 0);
    ms = all ? ms.filter(m => S0[2].indexOf(m) < 0) : ms.concat(S0[2].filter(m => ms.indexOf(m) < 0));
    setHk(p.id, { ms: ms.sort((a, b) => a - b) });
    render();
  };
  /* "Hire part-time help" when you are burning out opens Find workers, set to part time */
  if (typeof ACTS === 'object' && ACTS.e27) {
    ACTS.e27 = pipeView('ACTS.e27', ACTS.e27, 2);
    addStep('ACTS.e27.around', 10, 'part_time_and_milestones ACTS.e27', (m, idx, next) => {
      const r = next();
      try {
        if (m && m.data && m.data.id === 's_burnout' && idx === 0 && m.data.co) {
          ui.hk54 = ui.hk54 || {};
          ui.hk54[m.data.co] = { k: 'part' };
          setTimeout(() => { try { ui.sheet = null; go('hire', { id: m.data.co }); } catch (e) { } }, 0);
        }
      } catch (e) { console.error(e); }
      return r;
    });
  }

  /* ================= 3. from home, customers come slowly: word of mouth has to be earned ================= */
  if (typeof demand === 'function') {
    addStep('demand', 110, 'from home, clients come slowly', (co, _1, r) => {
      if (r && r.D && window.R37 && R37.atHome && R37.atHome(co)) r.D *= Math.max(0.72, Math.min(0.95, 0.72 + (co.aware || 0) * 0.005));
    }, true);
  }
})();


/* ===== Round 24: managers who work, and an assistant manager who is a worker first ===== */
window.R24 = window.R24 || {};
(function () {
  const need = (co, bd) => bd.std.reduce((a, s) => a + s[1], 0) * (co.size || 1);
  const mgrOf = co => co.mgr && S.npcs[co.mgr];
  const monthProfit = co => { const H = (co.hist || []).slice(-3); return H.length ? H.reduce((a, x) => a + (x.profit || 0), 0) / H.length : 0; };
  /* how hard the business is pushing against its capacity over the last weeks (0 = slack, 1 = turning many away) */
  function pressure(co) {
    const H = (co.wh22 || []).slice(-3).filter(x => x.d != null);
    if (!H.length) { const w = co.lastW || {}; return w.cap > 0 ? Math.max(0, Math.min(1, ((w.D || 0) / w.cap - 0.95) / 0.3)) : 0; }
    const d = H.reduce((a, x) => a + Math.min(3, x.d), 0) / H.length;
    return Math.max(0, Math.min(1, (d - 0.95) / 0.3));
  }
  R24.pressure = pressure;
  /* the manager's own hands-on time.
     Small places: the manager is a working manager and spends most of the week on the floor.
     Big places: management takes most of the time. A big business that makes a lot of money lets its manager step back,
     but when demand runs ahead of capacity the manager pitches in. */
  R24.mgrBase = function (co, bd) {
    const n = need(co, bd);
    let base = n < 3 ? 0.85 : n < 6 ? 0.7 : n < 10 ? 0.55 : n < 16 ? 0.35 : 0.15;
    const m = mgrOf(co);
    if (n >= 10 && m && monthProfit(co) > (co.mgrWage || m.ask || 50000) * 4) base = 0;
    return base;
  };
  window.mgrFTE = function (co, bd) {
    const base = R24.mgrBase(co, bd), n = need(co, bd);
    const surge = (n < 10 ? 0.35 : 0.6) * pressure(co);
    return Math.min(1, base + surge);
  };
  /* when the manager works, they work like the best person in the team (or better, if their own skill is higher) */
  R24.mgrEff = function (co) {
    const m = mgrOf(co);
    if (!m) return 1;
    const best = co.staff.reduce((a, s) => Math.max(a, staffSkill(s)), 0);
    const sk = Math.min(95, Math.max(m.stats.ops || 50, best + 3));
    return 0.75 + 0.5 * sk / 100;
  };
  /* the assistant manager: a full worker who also takes up to two jobs off your plate */
  R24.asstFTE = function (co, bd) {
    const a = co.asst, n = a && S.npcs[a.npc];
    if (!n || co.st !== 'open') return 0;
    const share = 1 - 0.12 * ((a.duties || []).length);
    const sk = Math.min(95, n.skill || ((n.stats && (n.stats.ops + n.stats.people) / 2) || 55));
    return share * (0.75 + 0.5 * sk / 100);
  };
  /* pay: more than the team's typical hands-on pay, clearly less than a manager */
  R24.asstAsk = function (co, n) {
    const bd = bdOf(co);
    const tot = bd.std.reduce((m, s) => m + s[1], 0) || 1, avg = bd.std.reduce((m, s) => m + wageFor(s[0], co) * s[1], 0) / tot;
    const sk = n.stats ? (n.stats.ops + n.stats.people) / 2 : 55;
    const mgrAsk = n.ask0 || n.ask;
    const ask = Math.max(avg * 1.05, Math.min(mgrAsk * 0.8, avg * (1.1 + sk / 600)));
    return rnl(ask, 500);
  };
})();
/* a manager always earns clearly more than the team they lead (and more than an assistant manager would) */
(function () {
  addStep('genManager', 20, 'managers_who_work genManager', (co, mtype, n) => {
    const bd = co && BD[co.type];
    if (bd && bd.std && bd.std.length) {
      /* the floor is the team's typical pay, not its best-paid specialist: a law firm's office manager does not out-earn its lawyers */
      const tot = bd.std.reduce((m, s) => m + s[1], 0) || 1, avg = bd.std.reduce((m, s) => m + wageFor(s[0], co) * s[1], 0) / tot;
      const st = n.stats || {}, sk = ((st.ops || 60) + (st.people || 60) + (st.sales || 60) + (st.fin || 60)) / 4;
      const floor = avg * (1.2 + sk / 500);
      if (n.ask < floor) n.ask = rl(rnd(floor, 500), co.country);
    }
  });
})();

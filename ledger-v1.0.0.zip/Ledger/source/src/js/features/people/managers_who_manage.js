/* ===== Round 45: managers who manage, prompts after the report, Until needed that says why, and motion.
   - Nothing pops up over the week report; it waits until you press Continue.
   - A new manager starts with "Within limits" and handles everyday decisions; routine news from a managed company
     is filed quietly; only money problems pop up. Managers keep the paperwork current (VAT, renewals, permits).
   - With a manager, you still set the manager's pay and authority and your own hours here.
   - Screens slide in when you open them, pop-ups rise, bars fill; nothing replays when a screen merely refreshes. ===== */
window.R45 = window.R45 || {};
(function () {
  'use strict';
  const R45 = window.R45;
  const U = window.UI;
  if (!U) return;
  const { ui, V, ACT, esc, row, btn, render, save, toast } = U;
  const live = () => S.cos.filter(c => c.st !== 'sold' && c.st !== 'bust');
  const onReport = () => !!(ui.view && ui.view.n === 'weekreport');
  R45.onReport = onReport;

  /* ================= 1. prompts wait for the week report ================= */
  window.showPop = pipeView('window.showPop', window.showPop, 0); /* window.showPop: around-steps, routes, the screen, then its steps */
  addStep('window.showPop.around', 10, '================= 1. prompts wait for the week report =================', (next) => {
    if (onReport()) { ui.popAfterRep = 1; return; }
    return next();
  });

  /* ================= 2. a manager decides everyday matters ================= */
  const mgrName = co => (co.mgr && S.npcs[co.mgr] ? S.npcs[co.mgr].name : 'Your manager');
  function giveAuthority(co) {
    if (!co.mgr || co.auth45 === co.mgr) return;
    co.auth45 = co.mgr;
    co.auth = co.auth || { lvl: 0, buy: 0, hire: 0, ad: 0 };
    if ((co.auth.lvl || 0) === 0) {
      co.auth.lvl = 1;
      co.auth.buy = Math.max(co.auth.buy || 0, niceAmt(KC(50000)));
      note(mgrName(co) + ' now handles everyday decisions at ' + co.name + ' up to ' + mshort(co.auth.buy) + '. Bigger ones come to you. Change it under Staff.', 'n', co.id);
    }
  }
  R45.giveAuthority = giveAuthority;
  /* news from a company someone else runs is filed, not pushed; trouble still reaches you */
  const LOUD = /bankrupt|fraud|unexplained|stealing|police|court|lawsuit|sued|fined|\bfine\b|accident|ransom|is leaving|resign|cannot pay|could not pay|wage claim|not paid|unpaid/i;
  if (typeof addMsg === 'function') {
    addStep('addMsg', 10, 'managers_who_manage addMsg', (m, r) => {
      const co = m && m.co ? getCo(m.co) : null;
      if (co && co.mgr && co.st !== 'sold' && co.st !== 'bust' && m.status === 'done' && !LOUD.test((m.title || '') + ' ' + (m.body || ''))) m.read = 1;
    }, true);
  }
  /* pop-ups for a managed company: only money */
  addStep('window.coAlerts', 60, 'pop-ups for a managed company: only money', (co, out) => {
    try {
      if (co && co.mgr) out.forEach(a => { if (a[1] === 'bad' && !/cash|wage|bill|unpaid|bankrupt/i.test(a[0])) a[1] = 'warn'; });
    } catch (e) { }
    return out;
  });

  /* ================= 3. the manager keeps the paperwork current ================= */
  function mgrDocs(co) {
    if (!co.mgr || co.st !== 'open') return;
    let needs = [];
    try { needs = docNeeds(co); } catch (e) { return; }
    needs.forEach(id => {
      try {
        if (docOk(co, id)) return;
        const d = co.docs[id];
        if (d && d.st === 'applied') return;
        if (id === 'acctr' && !co.acc) return;
        const r = applyDoc(co, id);
        if (r === 'ok') note(mgrName(co) + ' applied for ' + docDef(id, co.country)[0].toLowerCase().replace(/^vat/, 'VAT') + ' for ' + co.name + '.', 'n', co.id);
        else if (r === 'cash') { co.doc45 = co.doc45 || {}; if (!co.doc45[id] || S.week - co.doc45[id] >= 4) { co.doc45[id] = S.week; note(mgrName(co) + ' needs cash at ' + co.name + ' to apply for ' + docDef(id, co.country)[0].toLowerCase() + '.', 'bad', co.id); } }
      } catch (e) { }
    });
  }
  R45.mgrDocs = mgrDocs;
  addStep('week.after', 55, 'managers_who_manage weekly', () => { try { live().forEach(co => { giveAuthority(co); mgrDocs(co); }); } catch (e) { console.error(e); } });
  addStep('day.after', 110, 'managers get their authority', (d) => { live().forEach(giveAuthority); }, true);

  /* ================= 4. with a manager: their pay and authority, and your own hours, stay in reach ================= */
  function youCard(co) {
    const v = co.ohrs || 0;
    return '<div class="card you45"><div class="bhead"><b>You</b><small>' + (v ? v + ' h a week here' : 'Not working here') + '</small></div>' +
      U.chips([0, 10, 20, 30, 40].map(x => [x, x ? x + ' h' : 'None']), v, 'ownhrs', { id: co.id }) +
      '<span class="tipt">Work alongside ' + esc(mgrName(co).split(' ')[0]) + ' if you like. Your own pay is under Money › Pay yourself.</span></div>';
  }
  R45.youCard = youCard; /* on the Staff tab of a managed company (ui/company/view.js) */

  /* ================= 5. Until needed says why it stopped ================= */
  window.untlStop = function () {
    if (ui.sheet) return 'a pop-up needs you';
    if ((S.cel28q || []).length) return 'a milestone';
    try {
      const st = S.al30 || {};
      for (const co of live()) {
        const a = (window.coAlerts(co) || []).find(x => x[1] === 'bad' && !st[co.id + ':' + x[0].replace(/[0-9]+/g, '#')]);
        if (a) return a[0] + ' at ' + co.name;
      }
    } catch (e) { }
    /* V.1.0.0: a company whose manager you have not met for two months starts to slip (features/people/owner_attention.js) */
    if (window.OA59) { const w = OA59.untlWhy(); if (w) return w; }
    return '';
  };

  /* ================= 7. trades that can start from home ================= */
  /* a one-person plumber, electrician, builder, agency, lawyer or accountant can work from home; a place of their own
     is a choice that pays back in shorter trips, a name on the door and clients' trust, at the cost of rent */
  const HOME45 = ['plumber', 'electrician', 'construction', 'mktg', 'webdev', 'acctfirm', 'law', 'cleaning', 'estate', 'engcons', 'event', 'drivsk', 'staffing'];
  HOME45.forEach(id => {
    const b = BD[id];
    if (!b || !b.prem || b.prem[0] === 'home' || b.prem45) return;
    try { calib(b); } catch (e) { } /* the business is designed with its premises; only where you start changes */
    b.prem45 = b.prem;
    b.prem = ['home', 0];
  });
  R45.HOME = HOME45;
  const MOB45 = { plumber: 1, electrician: 1, construction: 1, cleaning: 1, handy: 1, carclean: 1, event: 1 };
  const homeType = co => !!(co && BD[co.type] && BD[co.type].prem && BD[co.type].prem[0] === 'home');
  const hasPlace = co => !!(co && co.prem && co.prem.m2 > 0);
  R45.perks = co => {
    const b = BD[co.type], p = [];
    if (MOB45[co.type]) p.push('shorter trips and stock on hand, so more of the day is paid work');
    p.push('your name on the door' + (MOB45[co.type] ? ' and on the vans' : '') + ', so more people notice you');
    if ((b.b2b || 0) >= 0.4) p.push('business clients trust you more');
    return p.join('; ') + '. It costs rent.';
  };
  addStep('capacity', 70, 'own premises: shorter trips', (co, bd, r) => { if (MOB45[co.type] && homeType(co) && hasPlace(co)) r.cap *= 1.08; }, true);
  addStep('demand', 100, 'own premises: business clients trust you more', (co, bd, r) => {
    if (homeType(co) && hasPlace(co) && ((bd || BD[co.type]).b2b || 0) >= 0.4 && r && r.D) r.D *= 1.06;
  }, true);
  /* a manager never runs a team from your home: they rent a small place */
  addStep('week.after', 55, 'managers_who_manage weekly', () => {
    try {
      live().forEach(co => {
        if (co.st !== 'open' || !co.mgr || !homeType(co) || hasPlace(co) || !(window.R37 && R37.atHome && R37.atHome(co))) return;
        const L = premListings(co), l = L[1] || L[0];
        if (!l) return;
        co.off37 = Date.now();
        const r = setPrem(co, 'home', l.m2, false, l);
        delete co.off37;
        if (r === 'ok') note(mgrName(co) + ' rented a small ' + R37.placeW(co) + ' of ' + l.m2 + ' m² for ' + co.name + ': staff need somewhere to work.', 'n', co.id);
      });
    } catch (e) { console.error(e); }
  });
  addStep('week.after', 55, 'managers_who_manage weekly', () => {
    try {
      live().forEach(co => {
        if (co.st !== 'open' || !homeType(co) || !hasPlace(co)) return;
        if (typeof isFoot === 'function' && isFoot(co.prem.kind)) return;
        co.aware = Math.min(100, (co.aware || 0) + 0.15 * (co.prem.loc || 1));
      });
    } catch (e) { }
  });

  /* ================= 6. motion: only when a screen or pop-up opens ================= */
  let lastKey = null, lastDepth = 0, lastTab = null, lastSheet = null, lastToast = null;
  const reduce = () => { try { return window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) { return false; } };
  function tagMotion() {
    const app = document.getElementById('app');
    if (!app || reduce()) return;
    const sc = app.querySelector('main.screen');
    const key = ui._sk || '';
    if (sc && key !== lastKey) {
      const depth = (ui.stack || []).length + (ui.tab === 'phone' && ui.ph && ui.ph.n !== 'home' ? 1 : 0);
      const cls = lastKey == null ? '' : ui.tab !== lastTab ? 'mo-tab' : depth > lastDepth ? 'mo-fwd' : depth < lastDepth ? 'mo-bk' : 'mo-tab';
      if (cls && !ui.untl && !(window.R47 && R47.swiping)) sc.classList.add(cls);
      lastKey = key; lastDepth = depth; lastTab = ui.tab;
    }
    const scrim = app.querySelector('.scrim');
    const sk = ui.sheet ? (ui.sheet.cls || '') + '|' + ((/<h2[^>]*>([\s\S]*?)<\/h2>/.exec(ui.sheet.html || '') || [])[1] || String(ui.sheet.html || '').slice(0, 80)) : null;
    if (scrim && sk && sk !== lastSheet) scrim.classList.add('mo-sheet');
    lastSheet = sk;
    const t = app.querySelector('.toast');
    const tk = ui.toast ? ui.toast.t : null;
    if (t && tk && tk !== lastToast) t.classList.add('mo-toast');
    lastToast = tk;
  }
  const app = document.getElementById('app');
  if (app) new MutationObserver(() => { try { tagMotion(); } catch (e) { } }).observe(app, { childList: true });
})();



/* the game never zooms: block pinch, double-tap and ctrl+wheel zoom */
['gesturestart','gesturechange','gestureend'].forEach(function(t){document.addEventListener(t,function(e){e.preventDefault();},{passive:false});});
document.addEventListener('touchmove',function(e){if(e.touches&&e.touches.length>1)e.preventDefault();},{passive:false});
document.addEventListener('wheel',function(e){if(e.ctrlKey)e.preventDefault();},{passive:false});

/* ---- src/people/people.js ---- */
function uniqNpcName(n) {
  const used = {};
  Object.keys(S.npcs || {}).forEach(k => {
    used[S.npcs[k].name] = 1;
  });
  if (!used[n.name]) return;
  const parts = n.name.split(' ');
  const ini = 'ABCDEFGHJKLMNOPRSTV';
  for (let i = 0; i < ini.length; i++) {
    const t = parts[0] + ' ' + ini[i] + '. ' + parts.slice(1).join(' ');
    if (!used[t]) {
      n.name = t;
      return;
    }
  }
}
/* ===== People: candidates, staff, managers, accountants, courses ===== */
const TIERS = {
  young: { age: [18, 24], skill: [12, 48], exp: [0, 1.5], ask: 0.82, lie: 0.3 },
  mid: { age: [25, 40], skill: [35, 78], exp: [2, 12], ask: 1.0, lie: 0.22 },
  senior: { age: [41, 63], skill: [42, 90], exp: [10, 35], ask: 1.2, lie: 0.15 }
};
const EXPRO = [
  'Held a similar role for {y} years.',
  'Worked in the industry for {y} years.',
  '{y} years at a competitor.',
  'Short stints at several firms, {y} years in total.',
  'Ran a small operation of their own for {y} years.'
];
/* wageFor: the core below, then the steps features add (skill spread of pay): pipeSteps('wageFor') */
function wageFor(role, co) {
  return runSteps('wageFor', wageForCore(role, co), role, co);
}
function wageForCore(role, co) {
  const r = ROLES[role] || ['Staff', 40000];
  const city = co ? cityOf(co.city) : cityOf('oslo');
  return rlc(rnd(r[1] * city.wage * Math.pow(1 + S.econ.infl, S.week / 52) * (1 + 0.03 * Math.max(0, S.econ.dem - 1) * 4), 100), co && co.country);
}
function genCand(role, co, tier) {
  tier = tier || wpick([{ t: 'young', w: 3 }, { t: 'mid', w: 5 }, { t: 'senior', w: 3 }], x => x.w).t;
  const T = TIERS[tier];
  const lie = !chance(1 - T.lie);
  const age = rint(T.age[0], T.age[1]);
  let skill = Math.round(rng(T.skill[0], T.skill[1]));
  const exp = Math.round(rng(T.exp[0], T.exp[1]) * 2) / 2;
  const superOne = chance(role === 'sales' || role === 'cardealer' || role === 'estate' ? 0.04 : 0.015);
  if (superOne) skill = rint(88, 100);
  /* a company with good perks draws better people, with fewer bad habits, who ask a little less (features/people/perks_and_hosting.js) */
  const pull = co && window.PK58 ? PK58.pull(co) : 0;
  if (pull && !superOne) skill = Math.min(97, skill + Math.round(pull * rng(2, 7)));
  const claimSkill = lie ? clamp(skill + rint(8, 28), 0, 98) : clamp(skill + rint(-4, 4), 0, 98);
  const claimExp = lie ? exp + rint(2, 8) : exp;
  const base = ROLES[role] ? ROLES[role][1] : role.indexOf('hq_') === 0 && hqRole(role.slice(3)) ? hqRole(role.slice(3))[1] : 40000;
  const city = co ? cityOf(co.city).wage : cityOf(S.player.city).wage;
  const ask = rnd(base * city * T.ask * (0.55 + skill / 110 + (lie ? 0.05 : 0)) * Math.pow(1 + S.econ.infl, S.week / 52) * (window.R24 && R24.paySpread && ROLES[role] ? R24.paySpread(role, (co && co.country) || S.country) : 1) * (1 - 0.04 * pull), 100);
  const trait = chance(0.14 * (1 - 0.4 * pull)) ? pick(['late', 'lazy', 'conflict', 'sick', 'theft']) : null;
  const n = {
    id: uid(),
    name: personName(),
    age,
    role,
    tier,
    skill,
    claimSkill,
    exp,
    claimExp,
    lie,
    ask,
    trait,
    rel: clamp(rng(0.55, 1) - (trait ? 0.12 : 0), 0.3, 1),
    super: superOne,
    resume: pick(EXPRO).replace('{y}', claimExp) + (lie && chance(0.4) ? ' References available on request.' : ''),
    checked: 0,
    trial: 0,
    hired: 0,
    pers: persPick(),
    sec: Math.round(rng(0, 1) * 100) / 100,
    golden: tier === 'young' && chance(0.07)
  };
  if (role.indexOf('hq_') === 0) famousCand(n);
  uniqNpcName(n);
  S.npcs[n.id] = n;
  return n;
}
function claimLabel(n) {
  const s = n.claimSkill;
  return s >= 80 ? 'Outstanding' : s >= 65 ? 'Strong' : s >= 45 ? 'Capable' : s >= 28 ? 'Developing' : 'Entry level';
}
function refCheck(n) {
  n.checked = 1;
  return {
    exp: n.exp,
    skillBand: n.skill >= 80 ? 'Outstanding' : n.skill >= 65 ? 'Strong' : n.skill >= 45 ? 'Capable' : n.skill >= 28 ? 'Developing' : 'Entry level',
    trait: n.trait
  };
}
function trialWeek(n) {
  n.trial = 1;
  return Math.round(n.skill + gauss() * 6);
}
/* searching: ads are cheap but few candidates; agency finds more with higher quality */
function searchWorkers(co, role, mode) {
  const nC = mode === 'agency' ? rint(6, 9) : mode === 'network' ? rint(3, 5) : rint(3, 7);
  const out = [];
  for (let i = 0; i < nC; i++) out.push(genCand(role, co, mode === 'agency' ? wpick([{ t: 'young', w: 2 }, { t: 'mid', w: 6 }, { t: 'senior', w: 4 }], x => x.w).t : null));
  return out;
}
/* Hours. Full-time staff work FULL_H hours on a monthly salary. Part-time staff are paid by the hour: s.hrs hours a
   week, s.pt their share of a full week (also used for capacity and fair-pay comparisons), s.wage the monthly pay for
   those hours. Their pay follows their hours, also above full time. Commission-only sellers are paid on sales and a
   fixed + commission plan keeps its fixed monthly part, so their pay does not follow hours. Some part-timers are
   students and can work at most s.maxH hours. HIRE_HOURS: the weekly hours of the next hire (0 = full time). */
const FULL_H = 37.5;
let HIRE_HOURS = 0;
/* Pay basis. s.basis 'hour' (paid for the hours worked) or 'fix' (a fixed monthly salary for a full week). Part-time
   and seasonal staff are always hourly. Full-timers start hourly, except in jobs where a salary is the custom from the
   start (FIX_NORM); a good worker who stays asks for a fixed salary after about half a year. HIRE_BASIS: the basis of
   the next full-time hire (null = the custom for the job). HIRE_SEAS: months (1-12) a seasonal hire works, or null. */
const FIX_NORM = { dentist: 1, dentnurse: 1, vintner: 1, physio: 1, lawyer: 1, paralegal: 1, acct: 1, dev: 1, designer: 1, marketer: 1, consult: 1, foreman: 1, engineer: 1, architect: 1, fishtech: 1, underw: 1, claims: 1, banker: 1, credit: 1, analyst: 1, propm: 1, windtech: 1, geo: 1, offshore: 1, ittech: 1, hr: 1, pilot: 1, fo: 1, deckh: 1, hm: 1, pm: 1, buyer: 1, teller: 1, compl: 1, broker: 1, projc: 1, safety: 1, lab: 1, shipm: 1, eng: 1, chef: 1, cabin: 1, estate: 1, fin: 1, mktan: 1 };
let HIRE_BASIS = null, HIRE_SEAS = null;
const payFollowsHours = s => s.basis !== 'fix' && !(s.pay && s.pay.m && s.pay.m !== 'fix');
/* most people would rather have a fixed salary; younger people mind less (stable per person) */
const wantsFix = n => { if (n.wantFix == null) n.wantFix = hrng('fix:' + n.id)() < (n.age < 26 ? 0.55 : 0.8) ? 1 : 0; return !!n.wantFix; };
function setStaffHours(co, s, h) {
  h = Math.max(5, Math.min(s.maxH || 60, Math.round(h)));
  if (payFollowsHours(s)) s.wage = s.wage * h / (s.hrs || FULL_H); /* exact: hours can change every week */
  s.hrs = h;
  s.pt = h / FULL_H;
  return h;
}
/* What work someone wants (s.wish), stable per person: 'season' (only the seasons they signed up for: they study,
   have other work the rest of the year or like the time off), 'part' (part time all year, not full time) or 'full'.
   About four in ten seasonal workers want only the season and half of part-timers want to stay part time. Life
   changes: once a year with you, someone may want more work than before. A student never wants full time. */
const WISH_N = { season: 0, part: 1, full: 2 };
function workWish(s) {
  const yr = Math.floor((S.week - (s.w0 || 0)) / 52);
  if (!s.wish) { const r = hrng('wish:' + s.id)(); s.wish = s.seas ? (r < 0.4 ? 'season' : r < 0.65 ? 'part' : 'full') : s.hrs ? (r < 0.5 ? 'part' : 'full') : 'full'; s.wishY = yr; }
  if (yr > (s.wishY || 0)) { s.wishY = yr; if (s.wish !== 'full' && hrng('wish:' + s.id + ':' + yr)() < 0.3) s.wish = s.wish === 'season' ? 'part' : 'full'; }
  if (s.maxH && s.maxH < FULL_H && s.wish === 'full') s.wish = 'part';
  return s.wish;
}
/* why they say no, in words (stable per person) */
function wishWhy(s, want) {
  const n = S.npcs[s.id], f = n ? n.name.split(' ')[0] : 'They', r = hrng('why:' + s.id)();
  if (s.maxH && s.maxH < FULL_H) return f + ' studies and can work at most ' + s.maxH + ' h a week.';
  if (want === 'season') return f + (r < 0.4 ? ' has other work the rest of the year' : r < 0.7 ? ' studies outside the season' : ' likes having the rest of the year off') + ' and only wants the seasonal work.';
  return f + (r < 0.4 ? ' has small children at home' : r < 0.7 ? ' has another job on the side' : ' likes the shorter week') + (s.seas ? ' and would work part time all year, but not full time.' : ' and wants to stay part time.');
}
/* a part-timer or seasonal worker asked to go full time says yes only if that is the work they want */
function offerFullTime(co, s) {
  if (!s.hrs) return 'already';
  if (s.maxH && s.maxH < FULL_H) return 'student';
  if (workWish(s) !== 'full') { s.wishNo = S.week; return 'refuse'; }
  if (payFollowsHours(s)) s.wage = rnl(s.wage * FULL_H / s.hrs, 100);
  delete s.hrs; delete s.pt; delete s.maxH; delete s.seas; delete s.off; delete s.wishNo;
  return 'ok';
}
/* the hours someone works this week: part-time and seasonal staff by s.hrs; a full-timer on an hourly wage by s.wh
   (a full week unless a manager plans more or fewer hours). Pay follows the hours for anyone paid by the hour. */
function weekHours(s) {
  return s.hrs || s.wh || FULL_H;
}
function setWeekHours(co, s, h) {
  if (s.hrs) return setStaffHours(co, s, h);
  if (!payFollowsHours(s)) return FULL_H;
  h = Math.max(30, Math.min(45, Math.round(h)));
  s.wage = s.wage * h / (s.wh || FULL_H);
  if (h === FULL_H) { delete s.wh; delete s.pt; } else { s.wh = h; s.pt = h / FULL_H; }
  return h;
}
/* a full-timer moved to a fixed salary works a full week again */
function setFixedPay(co, s) {
  if (s.hrs || s.seas) return 'part';
  if (s.wh) { s.wage = rnl(s.wage * FULL_H / s.wh, 100); delete s.wh; delete s.pt; }
  s.basis = 'fix';
  return 'ok';
}
/* a seasonal worker asked to stay on all year, part time: yes unless they only want the season */
function offerPartTime(co, s, h) {
  if (!s.seas) return 'already';
  if (workWish(s) === 'season') { s.wishNo = S.week; return 'refuse'; }
  delete s.seas; delete s.off; delete s.wishNo;
  setStaffHours(co, s, Math.min(h || s.hrs || 20, s.maxH || 60));
  return 'ok';
}
/* Hiring. The 'hireWorker.check' steps can say no first (a company still at home must rent a place), then the hire
   itself, then the 'hireWorker.done' steps (the manager's kit for the new person, part-time hours). Steps share
   ctx: ctx.no is a refusal, ctx.r the result. hireManager works the same way. */
function hireWorker(co, n, wage0, pay) {
  const ctx = {};
  runChecks('hireWorker.check', ctx, co, n, wage0, pay);
  if (ctx.no) return ctx.no;
  ctx.r = hireWorkerCore(co, n, wage0, pay);
  if (ctx.r === 'ok' && (HIRE_HOURS > 0 || HIRE_SEAS)) {
    /* hired part time or for the season: the offer was a full-time salary, paid for the hours they work; one in four studies */
    const s = co.staff[co.staff.length - 1], R = hrng('stu:' + n.id);
    if (R() < 0.25) s.maxH = R() < 0.5 ? 20 : 30;
    s.basis = 'hour';
    setStaffHours(co, s, Math.min(HIRE_HOURS || 30, s.maxH || 60));
    if (HIRE_SEAS) { s.seas = HIRE_SEAS.slice(); s.off = HIRE_SEAS.indexOf(wMonth(S.week) + 1) < 0; }
  }
  runSteps('hireWorker.done', ctx, co, n, wage0, pay);
  return ctx.r;
}
function hireWorkerCore(co, n, wage0, pay) {
  const acc = n.hired;
  if (acc) return 'taken';
  let wage = wage0;
  if (pay && pay.m !== 'fix' && SALES_ROLES[n.role]) wage = wage0 + commEstimate(co) * pay.rate * (n.pers === 'driven' ? 1.1 : n.pers === 'steady' || n.pers === 'loyal' ? 0.75 : 0.95);
  /* the pay basis is part of the deal: someone who wants a salary weighs an hourly offer a little lower, more so in a
     job where a salary is the custom; a salary where the custom is hourly counts a little in your favour */
  const part = HIRE_HOURS > 0 || !!HIRE_SEAS, basis = part ? 'hour' : HIRE_BASIS || (FIX_NORM[n.role] ? 'fix' : 'hour');
  wage *= basis === 'fix' ? (FIX_NORM[n.role] ? 1 : 1.03) : wantsFix(n) && !part ? (FIX_NORM[n.role] ? 0.94 : 0.98) : 1;
  if (wage < n.ask * 0.82 && !chance(0.1)) return 'refuse';
  const want = n.ask;
  const p = clamp((wage / want - 0.86) / 0.18, 0, 1);
  if (!chance(p) && wage < want) return 'refuse';
  n.hired = co.id;
  co.staff.push({
    id: n.id,
    role: n.role,
    wage: wage0,
    pay: pay && SALES_ROLES[n.role] ? pay : null,
    w0: S.week,
    basis,
    lr: S.week, /* week of the last raise (or the hire) */
    pm: 0,
    skillGain: 0,
    warn: 0,
    crs: 0,
    onb: {}
  });
  return "ok";
}
function staffNpc(s) {
  return S.npcs[s.id];
}
/* Learning and stamina, stable per person (from their id).
   Learning speed: a new hire starts part way up to speed (more with more skill) and is fully up to speed after
   3 weeks (quick), 6 (most people) or 12 (slow). Stamina: one in five never seems to tire, one in five tires quickly.
   Tiredness (s.tired, 0-100) builds in weeks over 40 hours worked (the busier the place, the longer the real week)
   and wears off in normal weeks. Tired people work slower; worn-out people fall sick and leave more often. */
const LEARN_W = { quick: 3, normal: 6, slow: 12 }, STAM_F = { never: 0, normal: 1, quick: 2 };
function learnOf(s) { if (!s.learn) { const r = hrng('learn:' + s.id)(); s.learn = r < 0.25 ? 'quick' : r < 0.75 ? 'normal' : 'slow'; } return s.learn; }
function stamOf(s) { if (!s.stam) { const r = hrng('stam:' + s.id)(); s.stam = r < 0.2 ? 'never' : r < 0.8 ? 'normal' : 'quick'; } return s.stam; }
/* share of full speed while learning the job (1 once learned) */
function rampF(s) {
  if (s.w0 == null) return 1;
  const ten = S.week - s.w0, wk = LEARN_W[learnOf(s)];
  if (ten >= wk) return 1;
  const n = S.npcs[s.id], st = clamp(0.4 + (n ? n.skill : 40) / 250, 0.45, 0.8);
  return st + (1 - st) * Math.max(0, ten) / wk;
}
/* tiredness slows people down: from 40 on, down to 70% speed when worn out */
const tiredF = s => (s.tired || 0) > 40 ? 1 - ((s.tired || 0) - 40) / 200 : 1;
const sickNow = s => s.sick != null && S.week < s.sick;
/* the hours someone really worked last week: their hours, stretched when the place ran over capacity */
function workedHours(co, s) {
  const u = co.lastW && co.lastW.util || 0;
  /* people only work overtime when people are what limits the business: when the premises or the equipment are full,
     longer shifts serve nobody more, so the team works its normal hours (round 56) */
  const bo = co.dbg && co.dbg.botObj;
  if (bo && bo.kind && bo.kind !== 'staff') return weekHours(s);
  return weekHours(s) * Math.max(1, Math.min(1.25, u));
}
/* a week of work: tiredness up or down; a worn-out person may fall sick for a week */
function tireWeek(co, s) {
  if (s.off) { s.tired = Math.max(0, (s.tired || 0) - 20); return false; }
  if (sickNow(s)) return false;
  const h = workedHours(co, s), t0 = s.tired || 0;
  s.tired = h > 40 ? Math.min(100, t0 + (h - 40) * 1.2 * STAM_F[stamOf(s)]) : Math.max(0, t0 - (40 - h) * 0.6 - 6);
  s.hw = Math.round(h);
  if (s.tired > 60 && chance((s.tired - 60) / 400)) { s.sick = S.week + 1; s.tired = Math.max(0, s.tired - 35); return true; }
  return false;
}
function staffSkill(s) {
  const n = S.npcs[s.id];
  return n ? clamp(n.skill + s.skillGain - (s.nr > 0 ? 10 : 0) + (s.pay && SALES_ROLES[s.role] ? (s.pay.m === 'com' ? 9 : s.pay.m === 'mix' ? 4 : 0) : 0), 0, 100) : 40;
}
function fireStaff(co, sid, cause) {
  const i = co.staff.findIndex(s => s.id === sid);
  if (i < 0) return 0;
  const s = co.staff[i];
  const mo = s.w0 < S.week - 52 ? 2 : s.w0 < S.week - 13 ? 1 : 0.5;
  const sev = (cause || s.notice) ? 0 : s.wage * mo * (1 + CC().empNI);
  co.staff.splice(i, 1);
  const n = S.npcs[sid];
  if (n) {
    n.hired = 0;
  }
  if (sev > 0) payCo(co, sev, 'wages', 'Severance');
  return sev;
}
/* The raise that feels like a raise. Most people shrug at 3% (it barely beats prices); 6% is noticed. Younger people
   in lower-paid jobs feel a smaller raise; well-paid professionals expect a bit more. */
function raiseFelt(co, s) {
  const n = S.npcs[s.id], base = ROLES[s.role] ? ROLES[s.role][1] : 50000, age = n ? n.age : 35;
  let need = base >= 70000 ? 0.07 : 0.06;
  if (age < 26) need = base < 45000 ? 0.03 : 0.04;
  else if (age < 30) need -= 0.01;
  return need;
}
function raiseStaff(co, sid, pctUp) {
  const s = co.staff.find(x => x.id === sid);
  if (!s) return;
  const need = raiseFelt(co, s);
  s.wage = payFollowsHours(s) && s.hrs ? s.wage * (1 + pctUp) : rnl(s.wage * (1 + pctUp), 100);
  s.denied = 0;
  if (pctUp >= need) {
    /* a real raise: content for a while, and the next talk about pay is a year away */
    s.lr = S.week;
    s.happy = Math.max(s.happy || 0, S.week + (pctUp >= need * 1.6 ? 52 : 30));
    if (s.notice) {
      s.notice = 0;
      note(S.npcs[sid].name + ' will stay after the raise.', 'good', co.id);
    }
  } else s.lr = S.week - (pctUp >= need * 0.5 ? 26 : 39); /* a token raise: they ask again within half a year */
}
/* managers */
const MQ = [
  ['ops', 'Day-to-day operations'],
  ['people', 'Leading people'],
  ['sales', 'Winning customers'],
  ['fin', 'Numbers and cost control'],
  ['risk', 'Compliance and risk'],
  ['ethic', 'Integrity']
];
/* genManager: the core below, then the steps features add: pipeSteps('genManager') */
function genManager(co, mtype) {
  return runSteps('genManager', genManagerCore(co, mtype), co, mtype);
}
function genManagerCore(co, mtype) {
  const t = wpick([{ t: 'mid', w: 6 }, { t: 'senior', w: 6 }, { t: 'young', w: 3 }], x => x.w).t;
  const T = TIERS[t];
  const stats = {};
  MQ.forEach(q => {
    stats[q[0]] = clamp(Math.round(rng(35, 90) + (t === 'senior' ? 4 : t === 'young' ? -8 : 0)), 5, 99);
  });
  const liar = chance(0.25), claimed = {};
  MQ.forEach(q => {
    claimed[q[0]] = liar && q[0] !== 'ethic' ? clamp(stats[q[0]] + rint(6, 24), 0, 99) : stats[q[0]];
  });
  if (liar) claimed.ethic = clamp(stats.ethic + rint(8, 25), 0, 99);
  const bd = BD[co ? co.type : 'cons'];
  const base = (bd ? 52000 + Math.min(150000, mgrScale(co) * 6000) : 70000) * (1 + (stats.ops + stats.people + stats.sales + stats.fin) / 800) * (t === 'senior' ? 1.12 : t === 'young' ? 0.82 : 1) * (co ? cityOf(co.city).wage : cityOf(S.player.city).wage);
  const n = {
    id: uid(),
    name: personName(),
    age: rint(T.age[0] + (t === 'young' ? 6 : 0), T.age[1]),
    role: 'manager',
    mtype: mtype,
    tier: t,
    stats,
    claimed,
    lie: liar,
    ask: rl(rnd(base * Math.pow(1 + S.econ.infl, S.week / 52), 500)),
    exp: Math.round(rng(T.exp[0], T.exp[1]) * 2) / 2,
    hired: 0,
    q: {},
    pers: persPick(),
    resume: pick([
      'Previously ran a business unit.',
      'Former operations lead at a regional chain.',
      'Started as staff and rose to manager.',
      'Consultant turned operator.',
      'Managed a competitor for years.'
    ])
  };
  n.ask = rnd(n.ask * (0.72 + 0.28 * Math.min(1, n.exp / 9)), 500);
  n.golden = n.exp < 3 && chance(0.12);
  uniqNpcName(n);
  S.npcs[n.id] = n;
  return n;
}
function mgrScale(co) {
  return co ? Math.max(1, sum(co.staff, s => 1) + 1) : 1;
}
const QTXT = {
  ops: [
    '“Walk me through a normal Monday morning.”',
    ['Chaotic', 'Basic routines', 'Well organised', 'Systems and checklists everywhere']
  ],
  people: [
    '“Tell me about a conflict in your team.”',
    ['Avoided it', 'Escalated to HR', 'Mediated it', 'Solved it and improved the team']
  ],
  sales: [
    '“How would you grow revenue by 15%?”',
    [
      'No clear plan',
      'Discounts and ads',
      'Targeted offers and retention',
      'A full plan with channels and numbers'
    ]
  ],
  fin: [
    '“Which three numbers do you look at every week?”',
    ['Cash only', 'Cash and sales', 'Cash, margins, staffing', 'Margins, cash cycle, unit economics']
  ],
  risk: [
    '“A new inspection rule appears. What do you do?”',
    ['Wait and see', 'Ask the owner', 'Check and adapt', 'Own it, train staff, document']
  ],
  ethic: [
    '“You find a way to cut taxes that is legal but grey. Do you use it?”',
    ['Yes, always', 'Probably', 'Only after advice', 'No, we play it straight']
  ]
};
function interview(n, key) {
  const c = n.claimed[key], t = n.stats[key];
  n.q = n.q || {};
  if (n.q[key] != null) return n.q[key];
  // what the candidate says: stated by claim; a perceptive owner might notice (small noise); 20% chance a lie is exposed by inconsistent answer
  const said = clamp(c + gauss() * 3, 0, 100);
  const slip = n.lie && chance(0.2) ? t : said;
  n.q[key] = Math.round(slip);
  return n.q[key];
}
function answerText(key, v) {
  const a = QTXT[key][1];
  return a[v >= 80 ? 3 : v >= 62 ? 2 : v >= 42 ? 1 : 0];
}
/* mgrQual: the core below, then the steps features add: pipeSteps('mgrQual') */
function mgrQual(co) {
  return runSteps('mgrQual', mgrQualCore(co), co);
}
function mgrQualCore(co) { // 0..1
  const n = co.mgr ? S.npcs[co.mgr] : null;
  if (!n) return 0.5 * 0.0;
  const q = (0.34 * n.stats.ops + 0.18 * n.stats.people + 0.2 * n.stats.sales + 0.17 * n.stats.fin + 0.11 * n.stats.risk) / 100;
  const bd = BD[co.type], fit = n.mtype === bd.mgr ? 1 : n.mtype === 'gen' ? 0.85 : (MGR_FIT[n.mtype] || 0.6) * 0.9;
  return clamp(q * fit * (0.88 + 0.24 * ((co.mood != null ? co.mood : 60) / 100)), 0.05, 1);
}
function hireManager(co, n, wage) {
  const ctx = {};
  runChecks('hireManager.check', ctx, co, n, wage);
  if (ctx.no) return ctx.no;
  ctx.r = hireManagerCore(co, n, wage);
  runSteps('hireManager.done', ctx, co, n, wage);
  return ctx.r;
}
function hireManagerCore(co, n, wage) {
  if (n.hired) return 'taken';
  const p = clamp((wage / n.ask - 0.88) / 0.14, 0, 1);
  if (wage < n.ask && !chance(p)) return 'refuse';
  /* a successor for a manager on notice: the old one hands over and goes */
  if (co.mgr && co.mgr !== n.id) { const o = S.npcs[co.mgr]; if (o) o.hired = 0; }
  co.mgrNotice = null;
  n.hired = co.id;
  co.mgr = n.id;
  co.mgrWage = wage;
  co.mgrBonus = co.mgrBonus || 0;
  co.mgrW0 = S.week;
  co.ohrs = 0;
  co.mood = 60;
  co.flags.fraud = 0;
  co.lastRev = null;
  return 'ok';
}
/* a manager who resigns works out the notice period: three to six months (round 56), then leaves. You hear it the
   day they resign, so there is time to find the next one; hiring a new manager before the date lets the old one go.
   to: who they leave for (a rival group's name), why: the reason in a few words */
function mgrResign(co, why, to) {
  const n = S.npcs[co.mgr];
  if (!n || co.mgrNotice) return;
  const wk = 13 + Math.floor(hrng('notice:' + n.id + ':' + S.week)() * 14);
  co.mgrNotice = { w: S.week + wk, npc: n.id, why: why || '', to: to || '' };
  co.mood = Math.max(0, (co.mood != null ? co.mood : 60) - 5);
  addMsg({ kind: 'info', from: n.name, role: titleFor(co, 'mgr'), title: n.name + ' has resigned from ' + co.name, body: (why ? why.charAt(0).toUpperCase() + why.slice(1) + '. ' : '') + 'I will work my notice and leave on ' + dateStr(co.mgrNotice.w) + (to ? ', when I start at ' + to : '') + '. That gives you about ' + Math.round(wk / 4.33) + ' months to find someone. Hire my successor before then and I will hand over and go.', co: co.id, tone: 'bad', status: 'done', go: { l: 'Find a successor', a: 'go', p: { n: 'mgrhire', p: { id: co.id } } } });
}
/* the last day of the notice: they go, and you run the company until there is a new manager */
function mgrNoticeWeek(co) {
  const t = co.mgrNotice;
  if (!t) return;
  if (!co.mgr || co.mgr !== t.npc) { co.mgrNotice = null; return; } /* already replaced or gone */
  if (S.week < t.w) return;
  const n = S.npcs[co.mgr];
  co.mgrNotice = null;
  if (n) n.hired = 0;
  co.mgr = null;
  co.mgrWage = 0;
  co.ohrs = 40;
  co.mood = 60;
  note((n ? n.name : 'Your manager') + ' has left ' + co.name + (t.to ? ' for ' + t.to : '') + '. You run it yourself until you hire a new manager.', 'bad', co.id);
}
addStep('week.after', 30, 'managers on notice leave on their last day', () => { S.cos.forEach(co => { if (co.mgrNotice) mgrNoticeWeek(co); }); });
function fireManager(co) {
  const n = S.npcs[co.mgr];
  if (!n) return;
  n.hired = 0;
  payCo(co, (co.mgrWage || 0) * 3 * (1 + CC().empNI), 'wages', 'Manager severance');
  co.mgr = null;
  co.mgrWage = 0;
  co.ohrs = 40;
}
/* accountants */
/* courses */
function takeCourse(co, sid, cid) {
  const bd = BD[co.type], c = bd.crs.find(x => x[0] === cid);
  if (!c) return 'none';
  if (!payCo(co, c[2], 'oth', 'Course: ' + c[1])) return 'cash';
  const s = sid === 'owner' ? null : co.staff.find(x => x.id === sid), roll = Z(), nm = s ? S.npcs[s.id].name : S.player.name;
  let gain = 0, msg = 'No noticeable change';
  if (roll < 0.18) {
    msg = 'Nothing sticks. Wasted money.';
  } else if (roll < 0.34) {
    gain = c[4] * 0.4;
    msg = 'Small gain';
  } else if (roll < 0.9) {
    gain = c[4];
    msg = 'Solid gain';
  } else {
    gain = c[4] * 1.8;
    msg = 'Great result';
  }
  const poach = s && roll > 0.9 && chance(0.3);
  if (s) s.skillGain = clamp(s.skillGain + gain, -10, 70); else co.oskill = clamp(co.oskill + gain, 0, 100);
  note(nm + ' attended "' + c[1] + '" at ' + co.name + ': ' + msg + '.', gain > 0 ? 'good' : 'n', co.id);
  if (poach) {
    note(nm + ' was poached by a competitor after the course.', 'bad', co.id);
    fireStaff(co, s.id, 1);
  }
  return msg;
}
/* How long people stay. Median years with the same employer, US, January 2024 (BLS, Employee Tenure): leisure and
   hospitality 2.1, wholesale and retail 3.1, professional and business services 3.5, transport 3.7, construction 4.2,
   financial activities 4.7, manufacturing 4.9, mining and energy 5.7. That sets the weekly odds of leaving; each
   person differs: about one in seven loves the work and stays for years, one in five moves on fast (s.fit), the first
   three months end early most often, and long-timers rarely go. Pay that lags and a refused raise make leaving likelier. */
const TENURE_Y = { venue: 2.1, retail: 3.1, svc: 3.5, logi: 3.7, project: 4.2, fin: 4.7, prod: 4.9, energy: 5.7, rent: 4.2, club: 3, hold: 4.7 };
function staffFit(co, s) {
  if (s.fit == null) { const u = hrng('fit:' + s.id + ':' + co.type)(); s.fit = u < 0.15 ? 0.25 : u < 0.8 ? 0.7 + (u - 0.15) * 0.6 : 2; }
  return s.fit;
}
function quitOdds(co, s, n, gap, ten) {
  const T = TENURE_Y[BD[co.type].fam] || 3.5, h0 = Math.LN2 / (52 * T);
  const tenF = ten < 13 ? 1.6 : ten < 104 ? 1 : ten < 260 ? 0.7 : 0.5;
  const persF = { loyal: 0.5, steady: 0.75, driven: 1.1, restless: 1.8, arrogant: 1.2, lazy: 1 }[n.pers] || 1;
  const payF = 1 + Math.max(0, gap) * 2.5 + (s.denied && S.week - s.denied < 26 ? 0.8 : 0);
  /* 'quitF' steps: features that make people stay or leave (features/people/management_team.js: an HR manager) */
  return h0 * tenF * staffFit(co, s) * persF * payF * runSteps('quitF', 1, co, s) * (hasHQ('hr') ? 0.75 : 1) * (hasLead(co) ? 0.8 : 1) * (s.happy && S.week < s.happy ? 0.4 : 1) * (1 + Math.max(0, (s.tired || 0) - 50) / 25);
}
/* weekly staff dynamics: quits, trait problems, pay talks */
function staffWeek(co) {
  const bd = BD[co.type], out = [];
  co.payGap = 0;
  co.staff.forEach(s => {
    const n = S.npcs[s.id];
    if (!n) return;
    if (s.nr > 0) s.nr--;
    if (s.notice > 0) {
      s.notice--;
      if (s.notice <= 0) out.push(['leave', s]);
      return;
    }
    if (staffExtra(co, s, n)) return;
    if (tireWeek(co, s)) out.push(['sick', s]);
    if (s.off) return; /* a seasonal worker between seasons */
    const mkt = (wageFor(s.role, co) * (s.pt || 1));
    const gap = clamp((mkt * (0.7 + n.skill / 160) - effW(s)) / mkt, -0.2, 0.4);
    co.payGap = Math.max(co.payGap, gap);
    const ten = S.week - (s.w0 != null ? s.w0 : S.week), lr = s.lr != null ? s.lr : (s.w0 || 0);
    /* pay talk: when pay has fallen behind or a year has passed without a raise, they ask (a manager handles it himself) */
    if (!co.mgr && ten >= 13 && (gap > 0.06 || S.week - lr >= 52) && (!s.askW || S.week - s.askW >= 13) && !s.notice) { s.askW = S.week; out.push(['payask', s]); }
    /* a good worker on an hourly wage who has stayed half a year asks for a fixed salary */
    else if (!co.mgr && s.basis === 'hour' && !s.hrs && !s.seas && ten >= 26 && staffSkill(s) >= 55 && !s.flag && wantsFix(n) && (!s.fixAskW || S.week - s.fixAskW >= 26)) { s.fixAskW = S.week; out.push(['fixask', s]); }
    if (chance(quitOdds(co, s, n, gap, ten)) && !(co.flags.noquit)) out.push(['quit', s]);
    if (n.trait && !s.flag && chance((hasHQ('hr') ? 0.012 : 0.02) * (hasLead(co) ? 0.6 : 1))) {
      s.flag = n.trait;
      out.push(['problem', s]);
    }
  });
  if (co.staff.some(x => x.gone)) co.staff = co.staff.filter(x => !x.gone);
  return out;
}


/* ---- src/people/staff_extras.js ---- */
/* ===== Staff extras: personalities, onboarding paperwork, promotions, manager autonomy ===== */
ROLES.lead = ['Shift lead', 47000];
const PERS = {
  driven: ['Driven', 1],
  steady: ['Steady', 1],
  loyal: ['Loyal', 1],
  arrogant: ['Arrogant', 0],
  lazy: ['Complacent', 0],
  restless: ['Restless', 0]
};
function persPick() {
  return pick(Object.keys(PERS));
}
function goldenOk(n) {
  return !!(n && n.golden && n.pers && PERS[n.pers] && PERS[n.pers][1]);
}
function hasLead(co) {
  return co.staff.some(s => s.role === 'lead');
}
/* onboarding paperwork */
const ONB_BASE = [
  ['contract', 'Employment contract signed'],
  ['tax', 'Tax deduction registered'],
  ['areg', 'Employment reported to the authorities'],
  ['ins', 'Injury insurance and pension set up'],
  ['hms', 'Workplace safety introduction given']
];
const ONB_X = {
  food: 'Food hygiene training documented',
  police: 'Police certificate ',
  drive: 'Driving licence checked',
  cert: 'Trade certificate verified',
  health: 'Health authorisation verified',
  guard: 'Security guard approval',
  avi: 'Aviation licence verified',
  fin: 'Financial authorisation checked'
};
const ONB_ROLE = {
  cook: 'food',
  chef: 'food',
  baker: 'food',
  barista: 'food',
  waiter: 'food',
  bartender: 'food',
  guard: 'guard',
  physio: 'health',
  dentist: 'health',
  dentnurse: 'health',
  lawyer: 'cert',
  elec: 'cert',
  plumb: 'cert',
  carp: 'cert',
  mech: 'cert',
  driver: 'drive',
  truckd: 'drive',
  driverB: 'drive',
  courier: 'drive',
  instr: 'drive',
  pilot: 'avi',
  fo: 'avi',
  cabin: 'avi',
  banker: 'fin',
  broker: 'fin',
  agent: 'fin',
  underw: 'fin',
  groom: 'police',
  tutor: 'police',
  trainer: 'police'
};
function onbItems(role) {
  role = role || '';
  const l = ONB_BASE.slice();
  const x = ONB_ROLE[role];
  if (x) l.push([x, ONB_X[x]]);
  return l;
}
function onbMissing(s) {
  if (!s.onb) return [];
  return onbItems(s.role).filter(it => !s.onb[it[0]]);
}
function onbTick(co, sid, key) {
  const s = co.staff.find(x => x.id === sid);
  if (s && s.onb) s.onb[key] = 1;
}
/* experienced managers (5+ years) or managers who have been fined before do all paperwork at once;
   newer managers sometimes forget one or two items */
function mgrDoesAll(co, n) {
  return !!(co.flags && co.flags.onbAll) || (n && (n.exp || 0) >= 5);
}
function managerOnboard(co, s) {
  const n = co.mgr ? S.npcs[co.mgr] : null;
  if (!n || !s || !s.onb) return;
  const items = onbItems(s.role);
  if (mgrDoesAll(co, n)) {
    items.forEach(it => {
      s.onb[it[0]] = 1;
    });
    return;
  }
  let missed = 0;
  items.forEach(it => {
    if (missed < 2 && !chance(0.78 + (n.exp || 0) * 0.03)) missed++;
    else s.onb[it[0]] = 1;
  });
}
function staffExtra(co, s, n) {
  // missing paperwork can be caught in an inspection
  const miss = onbMissing(s);
  if (miss.length && S.week - s.w0 >= 3) miss.forEach(it => {
    if (chance(0.009)) {
      const f = Math.round(rng(6000, 20000) * (it[0] === 'police' || it[0] === 'cert' || it[0] === 'avi' || it[0] === 'fin' ? 2 : 1));
      payCo(co, f, 'fine', 'Paperwork fine');
      co.rep = clamp(co.rep - 1, 0, 100);
      if (co.mgr && !co.flags.onbAll) {
        co.flags.onbAll = 1;
        const mn = S.npcs[co.mgr];
        if (mn) note(mn.name + ' got the fine at ' + co.name + ' and now completes all staff paperwork straight away.', 'n', co.id);
      }
      note('Inspectors fined ' + co.name + ' ' + money(f) + ': "' + it[1] + '" missing for ' + n.name + '.', 'bad', co.id);
    }
  });
  if (s.pay && s.pay.m === 'com' && chance(0.003)) {
    const f = Math.round(rng(10000, 40000));
    payCo(co, f, 'fine', 'Mis-selling complaint');
    co.rep = clamp(co.rep - 1.5, 0, 100);
    note('A customer complaint about pushy selling by ' + n.name + ' cost ' + co.name + ' ' + money(f) + '.', 'bad', co.id);
  }
  if (s.pay && s.pay.m === 'com' && chance(0.004 + (co.lastW && co.lastW.util < 0.5 ? 0.01 : 0))) {
    n.hired = 0;
    s.gone = 1;
    note(n.name + ' left ' + co.name + ' after a slow month on commission.', 'bad', co.id);
    return true;
  }
  // hidden potential
  if (goldenOk(n) && (S.week - s.w0) % 4 === 3) {
    s.skillGain = clamp(s.skillGain + 1.6, -10, 30);
    if (S.week - s.w0 === 19 && !n.rev) {
      n.rev = 1;
      note(n.name + ' at ' + co.name + ' is turning into a real star.', 'good', co.id);
    }
  }
}
/* promotions */
function ladderFor(co, s) {
  const bd = BD[co.type];
  const cur = ROLES[s.role][1];
  const roles = bd.std.map(x => x[0]).concat(['lead']);
  return roles.filter((r, i) => roles.indexOf(r) === i && ROLES[r] && r !== s.role && ROLES[r][1] > cur * 1.04);
}
function promoteStaff(co, sid, role) {
  const s = co.staff.find(x => x.id === sid);
  const n = s && S.npcs[sid];
  if (!s || !n || !ROLES[role]) return 'bad';
  s.role = role;
  n.role = role;
  const mk = wageFor(role, co) * (0.7 + n.skill / 160);
  s.wage = Math.max(rnl(s.wage * 1.06, 100), rnl(Math.min(mk, s.wage * 1.5), 100));
  s.nr = 8;
  s.promo = (s.promo || 0) + 1;
  if (s.onb) Object.keys(s.onb).forEach(k => { });
  return 'ok';
}
function raiseToMarket(co, s) {
  const n = S.npcs[s.id];
  const mk = rnl((wageFor(s.role, co) * (s.pt || 1)) * (0.7 + n.skill / 160), 100);
  if (mk > s.wage) {
    s.wage = mk;
    return true;
  }
  return false;
}
/* what a manager does on his own each week */
function mgrStaffWork(co, bd, n, q) {
  const lvl = co.auth.lvl;
  const risk = n.stats.risk;
  // paperwork catch-up: experienced or previously fined managers finish everything, newer ones get to it slowly
  co.staff.forEach(s => {
    const m = onbMissing(s);
    if (!m.length) return;
    if (mgrDoesAll(co, n)) m.forEach(it => {
      s.onb[it[0]] = 1;
    });
    else if (chance(0.25 + risk * 0.003)) s.onb[m[0][0]] = 1;
  });
  // 9A: good managers check business customers before invoicing; weaker ones take longer to think of it
  if (bd.b2b > 0 && !co.flags.ccheck && chance(0.05 + q * 0.5)) {
    co.flags.ccheck = 1;
    note(n.name + ' now credit-checks business customers before invoicing at ' + co.name + '.', 'good', co.id);
  }
  // inexperience: costly mistakes
  const expF = clamp(1 - n.exp / 8, 0, 1);
  if (chance(0.0025 + 0.011 * expF)) {
    const rev = (co.lastW && co.lastW.rev) || 3000;
    const k = pick(['overspend', 'price', 'order']);
    if (k === 'overspend' || k === 'order') {
      const c = Math.round(rev * rng(0.02, 0.07));
      n.mist = (n.mist || 0) + 1;
      payCo(co, c, 'loss', 'Manager mistake');
      note(n.name + ' made a costly mistake at ' + co.name + ' (' + money(c) + ').', 'bad', co.id);
    } else {
      n.mist = (n.mist || 0) + 1;
      co.price = clamp(co.price + (chance(0.5) ? 1 : -1), -2, 2);
      note(n.name + ' mis-set prices at ' + co.name + '.', 'bad', co.id);
    }
  }
  // hidden potential
  if (goldenOk(n) && S.week % 6 === 0 && !n.cap) {
    MQ.forEach(x => {
      n.stats[x[0]] = Math.min(95, n.stats[x[0]] + rint(1, 3));
    });
  }
  if (S.week - (co.mgrW0 || 0) === 26 && !n.rev) {
    n.rev = 1;
    if (goldenOk(n)) note(n.name + ' has grown into a very strong manager at ' + co.name + '.', 'good', co.id); else if (n.golden) note(n.name + ' never lived up to the early promise at ' + co.name + '.', 'n', co.id);
  }
  // monthly pay review
  if (S.week % 4 === 0) co.staff.forEach(s => {
    const nn = S.npcs[s.id];
    if (!nn) return;
    const mk0 = rnl((wageFor(s.role, co) * (s.pt || 1)) * (0.7 + nn.skill / 160), 100);
    const tenW = S.week - (s.w0 || S.week), lrW = S.week - (s.lr != null ? s.lr : (s.w0 || S.week));
    /* a good worker paid by the hour who has stayed half a year gets a fixed salary from a manager who may decide it */
    if (s.basis === 'hour' && !s.hrs && !s.seas && tenW >= 26 && staffSkill(s) >= 60 && !s.flag && wantsFix(nn) && lvl >= 1) { setFixedPay(co, s); s.happy = Math.max(s.happy || 0, S.week + 26); note(n.name + ' moved ' + nn.name + ' to a fixed salary at ' + co.name + '.', 'n', co.id); }
    const why = s.notice > 0 ? 'has handed in notice' : (mk0 > s.wage * 1.25 ? 'is paid far below market and may leave' : lrW >= 52 && tenW >= 52 ? 'has had no raise for ' + (lrW >= 104 ? Math.floor(lrW / 52) + ' years' : 'a year') : (staffSkill(s) >= 68 && tenW >= 26 && mk0 > s.wage * 1.04 ? 'has performed strongly for ' + Math.round(tenW / 4.35) + ' months' : ''));
    const yearOn = lrW >= 52 && tenW >= 52 && !s.notice;
    if (!why || (!yearOn && mk0 <= s.wage * 1.03) || (s.askW && S.week - s.askW < 12)) return;
    /* a better manager closes the deal with a smaller raise that still feels like one; after a year without a raise
       the talk is about a raise that is noticed (raiseFelt), not about the market */
    const felt = raiseFelt(co, s);
    const mk = yearOn && mk0 <= s.wage * (1 + felt) ? rnl(s.wage * (1 + felt + (1 - q) * 0.01), 100) : Math.max(s.wage + 100, rnl((s.wage + (mk0 - s.wage) * (1 - 0.55 * q)), 100));
    const d = mk - s.wage;
    if (lvl >= 2 || (lvl === 1 && d <= co.auth.hire)) {
      const had = s.notice;
      raiseStaff(co, s.id, mk / s.wage - 1);
      if (had && !s.notice) note(nn.name + ' withdrew the notice after the raise.', 'good', co.id);
      note(n.name + ' raised ' + nn.name + "'s pay at " + co.name + ' to ' + money(mk) + '.', 'n', co.id);
    }
    else {
      s.askW = S.week;
      const sd = sender(co, n);
      addMsg({
        kind: 'ask',
        from: sd.name,
        role: sd.role,
        title: 'Pay review: ' + nn.name + ' at ' + co.name,
        body: nn.name + ' (' + ROLES[s.role][0] + ') ' + why + '. I negotiated it down to ' + money(mk) + ' per month (+' + money(d) + ').',
        co: co.id,
        opts: [{ l: 'Approve', d: '+' + money(d) + '/month', fx: {} }, { l: 'Not now', d: 'May leave', fx: {} }],
        act: 'staffx',
        data: { t: 'raise', sid: s.id, w: mk },
        exp: S.week + 3,
        by: 'ask',
        asker: 'mgr'
      });
    }
  });
  // promotions: fill a missing higher role from within
  if (S.week % 4 === 2) {
    const std = stdStaff(bd, co.size);
    for (const st of std) {
      const have = co.staff.filter(x => x.role === st[0] && !x.notice).length;
      if (have >= st[1] || ROLES[st[0]][1] < 40000) continue;
      const c = co.staff.filter(x => ladderFor(co, x).indexOf(st[0]) >= 0 && !x.notice && S.week - x.w0 >= 26 && staffSkill(x) >= 60 && !(x.askP && S.week - x.askP < 26)).sort((a, b) => staffSkill(b) - staffSkill(a))[0];
      if (!c) continue;
      const nn = S.npcs[c.id];
      const d = Math.max(0, Math.round(wageFor(st[0], co) * (0.7 + nn.skill / 160)) - c.wage);
      if (lvl >= 2 || (lvl === 1 && d <= co.auth.hire)) {
        promoteStaff(co, c.id, st[0]);
        note(n.name + ' promoted ' + nn.name + ' to ' + ROLES[st[0]][0] + ' at ' + co.name + '.', 'good', co.id);
      }
      else if (chainOf(co).slice(1).some(b => b.lvl >= 1)) {
        /* round 56: the boss above the manager signs it off (features/company/chain_hierarchy.js) */
        const b = chainOf(co).slice(1).find(x => x.lvl >= 1);
        promoteStaff(co, c.id, st[0]);
        note(b.npc.name + ' (' + titleFor(co, b.kind) + ') approved ' + n.name + '’s promotion of ' + nn.name + ' to ' + ROLES[st[0]][0] + ' at ' + co.name + '.', 'good', co.id);
      }
      else {
        c.askP = S.week;
        const sd2 = sender(co, n);
        addMsg({
          kind: 'ask',
          from: sd2.name,
          role: sd2.role,
          title: 'Promotion: ' + nn.name + ' at ' + co.name,
          body: 'We are short of ' + ROLES[st[0]][0] + '. ' + nn.name + ' is ready to step up from ' + ROLES[c.role][0] + '.',
          co: co.id,
          opts: [{ l: 'Promote', d: d ? '+' + money(d) + '/month' : '', fx: {} }, { l: 'Not now', d: '', fx: {} }],
          act: 'staffx',
          data: { t: 'promo', sid: c.id, role: st[0] },
          exp: S.week + 3,
          by: 'ask',
          asker: 'mgr'
        });
      }
      break;
    }
  }
}


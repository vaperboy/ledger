/* ---- src/people/owner_hours.js ---- */
/* Your own hours: one person, at most HCAP hours a week across everything you run (companies you work in without
   a manager, and startups you build yourself). Above 55 hours you work less well; the owner factor scales the
   hours you put into each company (capacity). Tiredness and burn-out build up week by week (see the weekly steps). */
const HCAP = 80;
/* hours you put into building your own startups (software ones keep them in sw, the other sectors in sw16) */
function devHours() {
  const L = (S.founded || []).filter(f => f.st === 'live');
  return L.filter(f => f.sw && f.sw.selfH).reduce((t, f) => t + f.sw.selfH, 0) + L.filter(f => f.sw16 && f.sw16.selfH).reduce((t, f) => t + f.sw16.selfH, 0);
}
function hoursUsed(except) {
  return S.cos.filter(c => c !== except && c.st !== 'sold' && c.st !== 'bust' && !c.mgr && c.type !== 'hold').reduce((t, c) => t + (c.ohrs || 0), 0) + devHours();
}
function ownerFactor() {
  if (!S) return 1;
  if (S.burnUntil && S.week < S.burnUntil) return 0.15;
  if (S.sickW === S.week) return 0;
  const t = hoursUsed();
  return t <= 55 ? 1 : Math.max(0.6, 1 - (t - 55) * 0.012);
}

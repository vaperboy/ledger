/* ---- src/people/scorecards.js ---- */
/* ===== Performance analyst: manager scorecards ===== */
function mgrReview(co) {
  const n = co.mgr ? S.npcs[co.mgr] : null;
  if (!n) return null;
  const h = co.hist.slice(-3);
  const rev = sum(h, x => x.rev), pr = sum(h, x => x.profit);
  const margin = rev > 0 ? pr / rev : 0;
  const paper = co.staff.filter(s => onbMissing(s).length).length;
  const mist = n.mist || 0;
  const fraud = co.flags.fraud || 0;
  /* the last three months' targets (features/people/targets_and_budgets.js): all met adds 10, none met takes 10 */
  const tl = ((co.tg58 && co.tg58.log) || []).slice(-3), tg = tl.length ? tl.reduce((t, x) => t + x.n / x.of, 0) / tl.length : null;
  const score = Math.round(clamp(50 + clamp(margin * 100, -25, 25) * 0.9 + (co.rep - 50) * 0.3 + (co.q - 50) * 0.2 - mist * 4 - paper * 3 - (fraud ? 25 : 0) + (tg != null ? (tg - 0.5) * 20 : 0), 0, 100));
  return {
    id: co.id,
    name: co.name,
    mgr: n.name,
    w: S.week,
    score,
    margin,
    rep: Math.round(co.rep),
    q: Math.round(co.q),
    mist,
    paper,
    fraud,
    tg,
    wage: co.mgrWage,
    tenure: S.week - (co.mgrW0 || 0),
    stats: Object.assign({}, n.stats),
    hasHist: h.length > 0
  };
}
function runReview(co) {
  const r = mgrReview(co);
  if (r) co.lastRev = r;
  return r;
}
function managerScorecards() {
  const L = S.cos.filter(c => (c.st === 'open' || c.st === 'closed') && c.mgr).map(c => runReview(c)).filter(Boolean).sort((a, b) => b.score - a.score);
  if (!L.length) return;
  const f = x => x.name + ' (' + x.mgr + '): ' + (x.score >= 80 ? 'excellent' : x.score >= 65 ? 'good' : x.score >= 50 ? 'acceptable' : x.score >= 35 ? 'weak' : 'poor');
  addMsg({
    kind: 'info',
    from: ((S.office.staff.find(x => x.role === 'perf') || {}).name) || 'Performance analyst',
    role: 'Performance analyst',
    title: 'Manager scorecards: ' + monthStr(S.week),
    body: 'Best: ' + f(L[0]) + (L.length > 1 ? '. Weakest: ' + f(L[L.length - 1]) : '') + '. Open HQ → Reviews for details.',
    tone: L[L.length - 1].score < 40 ? 'bad' : 'good',
    status: 'done'
  });
}


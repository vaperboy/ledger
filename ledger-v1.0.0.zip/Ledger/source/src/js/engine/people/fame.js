/* ---- src/people/fame.js ---- */
/* ===== Fame: how well known you are decides who applies to you and what they ask for ===== */
function fame() {
  if (S.fameW === S.week && S.fameV != null) return S.fameV;
  const nw = Math.max(1, netWorth().total);
  const live = liveCos();
  let f = 11 * Math.log10(Math.max(1, nw / 3e5)) + 3 * live.length;
  let aw = 0, ol = 1;
  live.forEach(c => {
    aw = Math.max(aw, c.aware || 0);
    ol = Math.max(ol, chainOutlets(c));
  });
  f += 0.25 * aw + 5 * Math.log2(ol) + foreignCountries().length * 4;
  S.fameW = S.week;
  S.fameV = clamp(runSteps('fame', f), 0, 100); /* steps: pipeSteps('fame') */
  return S.fameV;
}
function fameLabel() {
  const f = fame();
  return f >= 80 ? 'World famous' : f >= 60 ? 'Nationally famous' : f >= 40 ? 'Well known in business' : f >= 20 ? 'Known locally' : 'Unknown';
}
function fameSalary() {
  return 0.75 + fame() / 55;
}
function fameSkillCap() {
  return Math.round(42 + fame() * 0.58);
}
/* HQ roles open up as the group grows */
function hqUnlocked(k) {
  if (k.indexOf('cd_') === 0) return true;
  const n = liveCos().length;
  const mgrs = liveCos().filter(c => c.mgr).length;
  const staff = sum(liveCos(), c => c.staff.length);
  const nw = netWorth().total;
  switch (k) {
    case 'pa':
      return true;
    case 'hr':
      return n >= 2 || staff >= 8;
    case 'acc':
      return n >= 2;
    case 'law':
      return n >= 3;
    case 'ana':
      return n >= 3;
    case 'proc':
      return n >= 2;
    case 'perf':
      return mgrs >= 2;
    case 'mkt':
      return n >= 3;
    case 'strat':
      return n >= 4 && nw >= KC(2e7);
    default:
      return true;
  }
}
function hqUnlockText(k) {
  return {
    hr: '2 companies or 8 staff',
    acc: '2 companies',
    law: '3 companies',
    ana: '3 companies',
    proc: '2 companies',
    perf: '2 managed companies',
    mkt: '3 companies',
    strat: '4 companies and a net worth of ' + mshort(KC(2e7))
  }[k] || '';
}
/* applied to every HQ or executive candidate */
function famousCand(n) {
  const f = fame();
  n.ask = rnl(n.ask * fameSalary(), 100);
  const cap = fameSkillCap();
  if (n.skill > cap) {
    n.skill = cap;
    n.claimSkill = Math.min(n.claimSkill, cap + 8);
    n.super = false;
  }
  if (f >= 50 && chance((f - 40) / 150)) {
    n.skill = rint(86, 98);
    n.claimSkill = n.skill;
    n.super = true;
    n.big = 1;
    n.ask = rnl(n.ask * 2.1, 100);
    n.resume = 'A well-known name in the industry. ' + n.resume;
  }
  return n;
}

/* result line shown under each HQ role: what it does for you right now */
function hqResult(k) {
  const cos = liveCos().filter(c => c.st === 'open');
  const n = cos.length;
  switch (k) {
    case 'pa':
      return 'Your right hand: every decision waits one more week, and they sit on every board.';
    case 'hr':
      return 'Fewer quits and problem workers among ' + sum(cos, c => c.staff.length) + ' staff in ' + n + ' companies.';
    case 'acc':
      {
        const base = sum(cos, c => (c.acc ? c.acc.fee : c.form === 'ENK' ? KC(480, c.country) : 0));
        return base > 0 ? 'Accountant fees x0.8: saves about ' + mshort(base * 0.25 * 0.8 * 12) + ' a year.' : 'Fees x0.8 once your companies pay an accountant.';
      }
    case 'law':
      return 'Fines and legal fees x0.85 or less in all companies.';
    case 'ana':
      return 'Detailed reports on sales, capacity and outlook; ask under Reports.';
    case 'perf':
      return 'Monthly scorecards for ' + cos.filter(c => c.mgr).length + ' managed companies.';
    case 'mkt':
      return 'Campaigns work about 10% better in ' + n + ' companies.';
    case 'proc':
      return 'Best supplier deals for every manager.';
    case 'strat':
      return 'A written memo with concrete suggestions for each company every quarter.';
  }
  return '';
}
/* quarterly memo from the strategy analyst */
function stratMemo() {
  if (!hasHQ('strat')) return;
  const an = S.office.staff.find(x => x.role === 'strat');
  const out = [];
  liveCos().filter(c => c.st === 'open').forEach(co => {
    const bd = BD[co.type];
    const u = co.lastW && co.lastW.util != null ? co.lastW.util : null;
    const wc = Math.max(1, coWeekCost(co));
    const h = co.hist.slice(-3);
    const rev = sum(h, x => x.rev), pr = sum(h, x => x.profit);
    const s = [];
    if (rev > 0 && pr / rev < 0.03) s.push('Margins are thin (' + pc(pr / rev, 0) + '). Review prices and supplier terms.');
    if (u != null && u > 0.95) s.push('Demand is above what we can deliver. Add staff, equipment or space.');
    if (u != null && u < 0.5) s.push('Less than half of capacity is used. Push marketing before adding cost.');
    if (co.cash < wc * 8) s.push('Cash is thin. Hold off on new spending.');
    if (co.cash > wc * 40 && pr > 0) s.push('Idle cash. Pay a dividend or expand.');
    if (co.eqc < 0.6) s.push('Equipment is worn. Book maintenance before it fails.');
    if (co.rep < 45) s.push('Reputation is weak. Fix service quality before spending on ads.');
    if (!co.mgr && co.staff.length >= 6) s.push('The team is large enough to justify a manager.');
    if (s.length) out.push(co.name + ': ' + s.slice(0, 3).join(' '));
  });
  addMsg({
    kind: 'info',
    from: an ? an.name : 'Strategy analyst',
    role: 'Strategy analyst',
    title: 'Quarterly strategy memo',
    body: out.length ? out.join('\n') : 'No concerns this quarter. All companies look healthy.',
    tone: 'n',
    status: 'done'
  });
}


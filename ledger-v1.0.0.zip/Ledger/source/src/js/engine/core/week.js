/* ---- src/core/week.js ---- */
/* ===== Week orchestrator: nextWeek, month end, year end, distress, game over ===== */
function nanGuard(snap) {
  const fix = (o, k, v, tag) => {
    if (typeof o[k] === 'number' && !isFinite(o[k])) {
      S.nanLog = S.nanLog || [];
      if (S.nanLog.length < 20) S.nanLog.push({ w: S.week, tag });
      o[k] = isFinite(v) ? v : 0;
    }
  };
  fix(S, 'cash', snap.cash, 'cash');
  S.cos.forEach(co => {
    fix(co, 'cash', snap.cos[co.id], 'co:' + co.type);
    fix(co, 'inv', 0, 'inv:' + co.type);
    fix(co, 'rep', 50, 'rep');
    fix(co, 'q', 50, 'q');
    fix(co, 'aware', 20, 'aw');
    ['wages', 'other', 'rent', 'tax'].forEach(k => {
      if (co.pay) fix(co.pay, k, 0, 'pay');
    });
    fix(co, 'vatAcc', 0, 'vat');
    fix(co, 'lossCarry', 0, 'lc');
    fix(co, 'mgrWage', 0, 'mw');
    fix(co, 'price', 0, 'price');
    fix(co, 'maint', 1, 'maint');
  });
  S.loans.forEach(l => {
    fix(l, 'bal', 0, 'loan');
  });
  fix(S.sav, 'bal', snap.sav, 'sav');
}
/* The weekly turn. Steps that features add run before ('week.before') and after ('week.after') the week itself,
   in order of their numbers: pipeSteps('week.before'), pipeSteps('week.after'). Before-steps can leave notes for
   the after-steps in the shared object they get. While a week runs WEEK_SIM is above zero (monthly bills build up
   instead of being paid on the spot). */
let WEEK_SIM = 0;
function nextWeek() {
  WEEK_SIM++;
  try {
    const ctx = {};
    runSteps('week.before', ctx);
    const r = weekRun();
    runSteps('week.after', ctx);
    return r;
  } finally { WEEK_SIM--; }
}
function weekRun() {
  if (S.over) return false;
  const snap = { cash: S.cash, sav: S.sav ? S.sav.bal : 0, cos: {} };
  S.cos.forEach(c => {
    snap.cos[c.id] = c.cash;
  });
  const r = nextWeek0();
  try {
    nanGuard(snap);
  } catch (e) { }
  return r;
}
function nextWeek0() {
  if (S.over) return false;
  S.week++;
  econWeek();
  marketWeek();
  rivalsWeek();
  fbWeek();
  clubLeaguesWeek();
  fundsWeek();
  investWeek();
  startupsWeek();
  deferredWeek();
  S.cos.slice().forEach(co => {
    if (co.st === 'sold' || co.st === 'bust') return;
    setCtx(co);
    weekCo(co);
    rvWeek(co);
    acctWeek(co);
    tryAutoOpen(co);
    if (co.st === 'open' && co.lastW) {
      co.trf = co.trf || [];
      co.trf.push(Math.round((co.lastW.D || co.lastW.units || 0) * 10) / 10);
      if (co.trf.length > 52) co.trf.shift();
    }
    if (co.st === 'open' || co.st === 'closed') {
      if (co.fr) frWeek(co);
      if (co.franchise && co.franchise.fran && co.lastW) franchiseeWeek(co, co.lastW.rev || 0);
      if (co.st === 'open' && co.type !== 'club') chainWeek(co);
      if (co.flags.coll && chance(0.02)) {
        const f = Math.round(Math.max(50000, ((co.bk.y.rev || 0) + (co.lastW ? co.lastW.rev * 20 : 0)) * 0.08));
        co.flags.coll = 0;
        payCo(co, f, 'fine', 'Competition fine');
        co.rep = clamp(co.rep - 6, 0, 100);
        addMsg({
          kind: 'info',
          from: '{auth:comp}',
          title: 'Price collusion uncovered at ' + co.name,
          body: 'The authority fined ' + co.name + ' ' + money(f) + '. Reputation took a hit.',
          co: co.id,
          tone: 'bad',
          status: 'done'
        });
        news('Competition authority fines a local company for price fixing.', 'bad');
      }
    }
    setCtx(null);
  });
  expireMsgs();
  if (isMonthEnd(S.week)) monthEnd();
  if (isYearEnd(S.week)) yearEnd();
  S.cos.forEach(co => {
    if ((co.st === 'open' || co.st === 'closed') && co.negW > 12 && co.cash < -coOverdraft(co) * 2) bankrupt(co, 'cash');
  });
  snapshot();
  checkOver();
  return true;
}
function settle(co) {
  let left = Math.max(0, co.cash + coOverdraft(co));
  let unpaid = 0;
  const paid = {};
  (window.R29 && R29.on() ? ['tax'] : ['wages', 'rent', 'other', 'tax']).forEach(k => {
    if (k === 'tax' && (!co.taxDue || S.week < (co.taxDueW || 0))) return;
    const due = k === 'tax' ? Math.min(co.pay.tax || 0, co.taxPrev || 0) : (co.pay[k] || 0);
    if (due <= 0) return;
    const p = Math.min(due, left);
    moveCash(co, -(p));
    if (k === 'tax') co.pay.tax = Math.max(0, co.pay.tax - p); else co.pay[k] = due - p;
    left -= p;
    unpaid += due - p;
    paid[k] = p;
    if (p > 0) co.tx.unshift({
      w: S.week,
      a: -Math.round(p),
      l: { wages: 'Payroll and payroll taxes', rent: 'Rent', other: 'Suppliers and costs', tax: 'Corporate tax' }[k]
    });
    if (k === 'tax') {
      S.stats.taxPaid += p;
      co.taxPrev = Math.max(0, (co.taxPrev || 0) - p);
      if (co.taxPrev < 1) co.taxDue = 0;
    }
  });
  if (co.tx.length > 40) co.tx.length = 40;
  if (!(window.R29 && R29.on())) co.wageShort = co.pay.wages || 0;
  return unpaid;
}
/* month end for a company; the month's cost breakdown is kept with its history line */
function monthEndCo(co) {
  const snap = Object.assign({}, co.bk.m || {});
  const r = monthEndCoCore(co);
  try { const h = co.hist[co.hist.length - 1]; if (h && h.m === monthIdx(S.week)) h.bk = snap; } catch (e) { }
  return r;
}
/* the tax a limited company owes so far this year, with losses carried forward and, in a tax group, profit that
   covers a sister company's loss this year (group contribution: groupContrib in engine/money/money.js) */
function taxAccrue(co) {
  const gc = co.gc = groupContrib(co);
  const target = Math.max(0, co.ytdP - co.lc0 - gc.out) * coTaxRate(co);
  const dtx = target - co.taxAcc;
  co.taxAcc = target;
  co.lossCarry = Math.max(0, co.lc0 - co.ytdP - gc.in);
  if (dtx > 0) {
    co.pay.tax += dtx;
    bk(co, 'tax', dtx);
  } else if (dtx < 0) {
    const back = Math.min(-dtx, co.pay.tax);
    co.pay.tax -= back;
    bk(co, 'tax', -back);
  }
}
function monthEndCoCore(co) {
  const bd = BD[co.type];
  if (co.st === 'setup' && co.pay.other < 1 && co.pay.wages < 1 && co.pay.rent < 1) { /* nothing */ }
  // AS tax accrual with loss carry-forward
  const b = co.bk.m;
  /* the manager's profit bonus (agreed when hired, ui/screens/hiring.js): a share of the month's profit on top of the
     salary, booked as wages before tax and paid with the next payroll */
  if (co.mgr && co.mgrBonus > 0 && S.npcs[co.mgr] && co.st === 'open') {
    const p0 = (b.rev || 0) - sumExp(b);
    if (p0 > 0) { const x = p0 * co.mgrBonus * OC(); co.pay.wages += x; bk(co, 'wages', x); co.mgrBonusLast = Math.round(x); } else co.mgrBonusLast = 0;
  }
  const profit = (b.rev || 0) - sumExp(b);
  if (co.form === 'AS' && co.st !== 'setup') {
    if (co.lc0 == null) {
      co.lc0 = co.lossCarry || 0;
      co.ytdP = 0;
      co.taxAcc = 0;
    }
    co.ytdP += profit;
    taxAccrue(co);
  }
  // owner salary (AS), paid only when the company can pay its payroll
  let ownerPay = null;
  if (co.form === 'AS' && co.ownerSalary > 0 && co.st === 'open' && !(window.R29 && R29.on())) {
    const sal = co.ownerSalary, cost = sal * OC();
    co.pay.wages += cost;
    bk(co, 'wages', cost);
    ownerPay = { sal, tax: personalTax(sal * 12, 'wage') / 12 };
  }
  {
    const thr = CC().vatThr || 0;
    if (thr > 0 && co.st === 'open' && !co.flags.vatAsk && !docOk(co, 'mva') && sum(co.hist.slice(-12), x => x.rev || 0) >= thr) {
      co.flags.vatAsk = 1;
      addMsg({
        kind: 'info',
        from: co.acc ? co.acc.name : co.name,
        title: 'VAT registration needed at ' + co.name,
        body: 'Your sales have passed the VAT threshold. You now have to register and charge VAT. Apply under Documents.',
        co: co.id,
        tone: 'bad',
        status: 'done'
      });
    }
  }
  const unpaid = settle(co);
  if (ownerPay) {
    if (co.pay.wages < 1) {
      S.tax.wage = (S.tax.wage || 0) + ownerPay.sal;
      S.tax.withheld = (S.tax.withheld || 0) + ownerPay.tax;
      gainMe(ownerPay.sal - ownerPay.tax, 'Salary from ' + co.name);
    } else if (!co.skipPay || S.week - co.skipPay > 8) {
      co.skipPay = S.week;
      note('You could not pay yourself a salary from ' + co.name + ' this week: the company is short of cash.', 'bad');
    }
  }
  if ((function () {
    const fq = CC().vatFreq || 2;
    return monthIdx(S.week) % fq === fq - 1;
  })()) {
    const v = Math.round(co.vatAcc);
    if (v > 0) {
      moveCash(co, -(v));
      co.tx.unshift({ w: S.week, a: -v, l: 'VAT settlement' });
      S.stats.taxPaid += v;
    } else if (v < 0) coIn(co, -v, null, 'VAT refund');
    co.vatAcc = 0;
  }
  if (unpaid > 1500) {
    co.unpaid = (co.unpaid || 0) + 1;
    if (co.unpaid === 1) addMsg({
      kind: 'info',
      from: co.name,
      title: 'Could not pay all bills at ' + co.name,
      body: 'Missing ' + money(unpaid) + ' this month. Put money in or cut costs, or workers and suppliers will walk.',
      co: co.id,
      tone: 'bad',
      status: 'done'
    });
    if (co.unpaid >= 2 && co.wageShort > 1) {
      co.staff.slice().forEach(s => {
        if (chance(0.25)) {
          note(S.npcs[s.id].name + ' quit ' + co.name + ' over unpaid wages.', 'bad', co.id);
          S.npcs[s.id].hired = 0;
          co.staff = co.staff.filter(x => x !== s);
        }
      });
      co.rep = clamp(co.rep - 3, 0, 100);
    }
    else if (co.unpaid >= 2) co.rep = clamp(co.rep - 1, 0, 100);
    if (co.unpaid >= 4) bankrupt(co, 'unpaid');
  } else co.unpaid = 0;
  if (co.st !== 'bust') {
    co.hist.push({ m: monthIdx(S.week), rev: b.rev || 0, profit, cash: co.cash });
    if (co.hist.length > 60) co.hist.shift();
  }
  const rs = repSettings();
  if (co.st === 'open' && shouldPack(co, rs)) {
    const bp = boardPack(co);
    if (hasHQ('strat')) bp.body += ' Analyst: ' + (profit > 0 ? 'on track.' : 'margins need attention.');
    if (rs.detail === 'full') bp.body += ' Staff ' + co.staff.length + ', equipment ' + condWord(co.eqc).toLowerCase() + ', ' + awWord(co.aware).toLowerCase() + '.'; /* feelings in words */
    addMsg({ kind: 'info', from: bp.from, title: bp.title, body: bp.body, co: co.id, tone: bp.tone, status: 'done' });
  }
  if (co.mgr) co.mood = clamp((co.mood != null ? co.mood : 60) + (profit > 0 ? 1.5 : -2) + (60 - (co.mood != null ? co.mood : 60)) * 0.05, 0, 100);
  if (co.mgr && (co.mood != null ? co.mood : 60) < 25 && chance(0.12)) {
    const mn = S.npcs[co.mgr];
    if (mn) mgrResign(co, 'after months of low morale I have decided to move on');
  }
  co.bk.m = {};
}
function shouldPack(co, rs) {
  const mi = monthIdx(S.week) % 12;
  if (rs.freq === 13 && mi % 3 !== 2) return false;
  if (rs.freq === 52 && mi !== 11) return false;
  if (rs.only === 'managed') return !!co.mgr;
  if (rs.only === 'big') return companyValue(co) >= S.group.big;
  return true;
}
function monthEnd() {
  S.cos.slice().forEach(co => {
    if (co.st !== 'sold' && co.st !== 'bust') {
      setCtx(co);
      monthEndCo(co);
      setCtx(null);
    }
  });
  /* a tax group is settled once every member's month is in */
  S.cos.forEach(co => { if (co.form === 'AS' && co.ytdP != null && co.st !== 'setup' && co.st !== 'sold' && co.st !== 'bust' && taxGroup(co)) taxAccrue(co); });
  regulationMonth();
  personalMonth();
  advTaxMonth();
  officeMonth();
  if (monthIdx(S.week) % 3 === 2 && hasHQ('strat')) stratMemo();
  if (hasHQ('perf') && S.office.perfAuto !== false) managerScorecards();
  const g = groupWagesMonth();
  if (g > 0) payHQ(g, 'Group management salaries');
  S.cos.forEach(co => {
    if (co.hold && co.st === 'open') { /* holding dividends flow handled in deals */ }
  });
}
function yearEnd() {
  S.cos.slice().forEach(co => {
    if (co.st === 'sold' || co.st === 'bust') return;
    co.flags.fraud = 0;
    if (co.form === 'AS') {
      co.taxDue = 1;
      co.taxPrev = co.pay.tax || 0;
      co.taxDueW = S.week + 26;
      co.gcLy = co.gc && (co.gc.out || co.gc.in) ? { out: Math.round(co.gc.out), in: Math.round(co.gc.in), r: coTaxRate(co) } : null;
      co.gc = null;
      co.lc0 = co.lossCarry || 0;
      co.ytdP = 0;
      co.taxAcc = 0;
    }
  });
  yearEndPersonal();
  S.cos.forEach(co => {
    if (co.st !== 'sold' && co.st !== 'bust') {
      co.bk.ly = co.bk.y;
      co.bk.y = {};
      settle(co);
    }
  });
  note('New year. Annual accounts closed for all companies.', 'n');
  news('A new year begins.', 'n');
}
/* distress */
function releaseStaff(co) {
  co.staff.forEach(s => {
    if (S.npcs[s.id]) S.npcs[s.id].hired = 0;
  });
  co.staff = [];
  if (co.mgr && S.npcs[co.mgr]) {
    S.npcs[co.mgr].hired = 0;
    co.mgr = null;
  }
}
/* bankrupt: steps before ('bankrupt.before') and after ('bankrupt.after') share ph (ph.r is the result): pipeSteps('bankrupt.after') */
function bankrupt(co, why) {
  return runPhased('bankrupt', [co, why], () => bankruptCore(co, why));
}
function bankruptCore(co, why) {
  if (co.st === 'bust' || co.st === 'sold') return;
  const assets = Math.max(0, companyAssets(co) - co.cash) * 0.45;
  const debts = sum(S.loans.filter(l => l.co === co.id), l => l.bal) + co.pay.wages + co.pay.other + co.pay.rent + Math.max(0, co.vatAcc) + co.pay.tax - Math.min(0, co.cash);
  const loanBal = sum(S.loans.filter(l => l.co === co.id), l => l.bal);
  let personalHit = 0;
  /* secured lenders are paid first from the sale of what the company owns (vehicles, property, equipment);
     only what is left of a guaranteed loan after that lands on the owner */
  let pool = assets;
  S.loans.slice().forEach(l => {
    if (l.co !== co.id) return;
    if (l.guar || co.form === 'ENK') {
      const cut = Math.min(pool, l.bal);
      l.bal -= cut;
      pool -= cut;
      l.co = 0;
      l.name += ' (taken over by you)';
      personalHit += l.bal;
    } else {
      closeLoan(l, l.bal * 0.4);
    }
  });
  const cashPart = Math.max(0, co.cash);
  let shortfall = Math.max(0, debts - loanBal - pool - cashPart);
  if (co.form === 'ENK') {
    shortfall = Math.max(0, debts - loanBal - pool - cashPart);
    moveCash(ME, -(shortfall), 'Debts of failed ' + co.name);
    personalHit += shortfall;
  }
  else if (pool + cashPart > debts - loanBal) {
    const rest = (pool + cashPart) - (debts - loanBal);
    if (rest > 0 && co.own > 0) {
      gainMe(rest * co.own / 100 * 0.2, 'Remaining value from ' + co.name);
    }
  }
  releaseStaff(co);
  co.st = 'bust';
  setCash(co, 0);
  S.stats.bankrupt++;
  S.credit = clamp(S.credit - (co.form === 'ENK' ? 22 : 14), 0, 100);
  addMsg({
    kind: 'info',
    from: co.name,
    title: co.name + ' has gone bankrupt',
    body: (why === 'unpaid' ? 'Bills went unpaid for months. ' : 'Cash ran out. ') + (personalHit > 0 ? 'About ' + money(personalHit) + ' lands on you personally (' + (co.form === 'ENK' ? 'sole proprietors are personally liable' : 'guarantees you signed') + '). ' : 'As a limited company, your loss is limited to what you put in. ') + 'Credit score hit.',
    co: co.id,
    tone: 'bad',
    status: 'done'
  });
  news(co.name + ' files for bankruptcy.', 'bad');
  S.cos.forEach(c => {
    if (c.hold === co.id) c.hold = 0;
  });
  bankruptHint(co);
}
function forcedSale(co) {
  const v = Math.round(companyValue(co) * co.own / 100 * 0.6);
  if (v <= 0) {
    bankrupt(co, 'cash');
    return;
  }
  S.loans.filter(l => l.co === co.id).forEach(l => closeLoan(l, l.bal));
  moveCash(ME, v, 'Forced sale of ' + co.name);
  releaseStaff(co);
  co.st = 'sold';
  S.stats.sold++;
  addMsg({
    kind: 'info',
    from: 'Bank',
    title: co.name + ' was sold by creditors',
    body: 'You could not cover your overdraft. The bank forced a sale at a discount: ' + money(v) + '.',
    co: co.id,
    tone: 'bad',
    status: 'done'
  });
}
function liquidateInvestments(need) {
  const take = () => S.cash >= need;
  if (S.sav.bal > 0) {
    moveCash(ME, S.sav.bal, 'Savings emptied to cover debts');
    S.sav.bal = 0;
  }
  if (take()) return;
  S.inv.deposits.forEach(d => {
    moveCash(ME, d.bal, 'Fixed deposit broken to cover debts');
  });
  S.inv.deposits = [];
  if (take()) return;
  for (const k of Object.keys(S.inv.funds)) sellAsset('fund', k, 1);
  for (const k of Object.keys(S.inv.stocks)) sellAsset('stock', k, 1);
  for (const k of Object.keys(S.inv.crypto)) sellAsset('crypto', k, 1);
  if (S.fm) {
    moveCash(ME, S.fm.bal, 'Fund manager account cashed in to cover debts');
    S.fm.bal = 0;
  }
}
function coverFromENK() {
  if (S.cash >= 0) return;
  let moved = 0;
  const from = [];
  liveCos().filter(c => c.form === 'ENK' && (c.st === 'open' || c.st === 'closed' || c.st === 'setup')).sort((a, b) => b.cash - a.cash).forEach(c => {
    if (S.cash >= 0) return;
    const spare = c.cash - coWeekCost(c) * 2;
    if (spare <= 0) return;
    const take = Math.min(spare, -S.cash + Math.round(S.overdraftLimit * 0.25));
    if (take <= 0) return;
    if (withdrawCash(c, take) === 'ok') {
      moved += take;
      from.push(c.name);
    }
  });
  if (moved > 0) note('Moved ' + money(moved) + ' from ' + from.join(', ') + ' to your private account to cover a negative balance. As a sole trader it is the same money.', 'n');
}
function checkOver() {
  coverFromENK();
  if (S.cash < -S.overdraftLimit) {
    S.flags.od = (S.flags.od || 0) + 1;
    if (S.flags.od === 1) addMsg({
      kind: 'info',
      from: 'Bank',
      title: 'Overdraft limit exceeded',
      body: 'Your private account is below the limit. Within 8 weeks the bank sells your investments and then forces a sale of a company. Pay yourself a salary or dividend, or put money in.',
      tone: 'bad',
      status: 'done'
    });
    if (S.flags.od === 5) addMsg({
      kind: 'info',
      from: 'Bank',
      title: 'Final warning: forced sale in 3 weeks',
      body: 'Your private account is still below the overdraft limit. Bring it back up or the bank forces a sale.',
      tone: 'bad',
      status: 'done'
    });
    if (S.flags.od >= 8) {
      liquidateInvestments(-S.overdraftLimit * 0.5);
      if (S.cash < -S.overdraftLimit) {
        const list = liveCos().filter(c => !c.hold).sort((a, b) => companyValue(b) - companyValue(a));
        for (const c of list) {
          if (S.cash >= -S.overdraftLimit * 0.5) break;
          forcedSale(c);
        }
      }
    }
  } else S.flags.od = 0;
  const nw = netWorth();
  if (S.cash < -S.overdraftLimit && S.flags.od >= 8 && nw.total <= 0) {
    S.over = { reason: 'insolvent', week: S.week, nw: nw.total };
    return;
  }
  if (S.cash < -S.overdraftLimit * 3 && !liveCos().length) {
    S.over = { reason: 'insolvent', week: S.week, nw: nw.total };
    return;
  }
  if (!liveCos().length && nw.total < 10000 && S.week > 2) {
    S.over = { reason: 'broke', week: S.week, nw: nw.total };
  }
}
/* advance */
function advance(mode) {
  let n = 0;
  const stop = { why: '' };
  const target = mode === 'week' ? 1 : mode === 'month' ? 4 : 26;
  const before = unreadCount();
  S.rep = { ev: [], w: S.week, from: S.week, nw0: netWorth().total, cash0: S.cash };
  while (n < target && !S.over) {
    nextWeek();
    n++;
    if (mode === 'attention' && unreadCount() > before) {
      stop.why = 'decision';
      break;
    }
    if (mode === 'month' && isMonthEnd(S.week)) break;
  }
  return { weeks: n, why: stop.why, over: S.over };
}


/* ---- src/core/api.js ---- */
/* ===== API: high-level helpers used by the UI and by tests ===== */
/* hidden brand strength: how much your existing brands help a new one (0..1) */
function brandStrength(bdId) {
  const bd = BD[bdId];
  let best = 0, from = null;
  S.cos.forEach(c => {
    if (c.st !== 'open' && c.st !== 'closed') return;
    const b2 = BD[c.type];
    if (!b2) return;
    const w = c.type === bdId ? 1 : b2.fam === bd.fam ? 0.45 : 0;
    if (!w) return;
    const v = (c.rep * 0.6 + c.aware * 0.4) / 100 * w * Math.min(1, 0.4 + (S.week - c.w0) / 104);
    if (v > best) {
      best = v;
      from = c;
    }
  });
  return { v: Math.round(best * 100) / 100, from };
}
function startSize(bdId, city, bs, fran) {
  const bd = calib(BD[bdId]);
  const tgt = clamp(recSize(city), bd.minSize, bd.maxSize);
  const k = clamp(Math.max(bs, fran ? 0.5 : 0) * 1.2, 0, 1);
  return Math.max(bd.minSize, Math.round((bd.minSize + (tgt - bd.minSize) * k) * 20) / 20);
}
function abroadFee(bdId, ctry) {
  if (!ctry || ctry === S.country) return 0;
  const bd = calib(BD[bdId]);
  return KC(220000 + bd.open * 1.5, ctry);
}
/* personal money spent when a company is created, before any money is put in */
function startOutlay(bdId, o) {
  const ctry = (o && o.country) || S.country, c = CO[ctry];
  return (o && o.form === 'AS' ? c.asFee + c.asCapital : 0) + (abroadFee(bdId, ctry) || 0);
}
function startCompany(bdId, o) {
  o = o || {};
  const ctry = o.country || S.country;
  const lg = legalStatus(bdId, ctry);
  if (!lg.ok) return 'banned';
  const af = abroadFee(bdId, ctry);
  if (af && S.cash < af + KC(50000, ctry)) return 'cash';
  const prevCtx = CTXCO;
  setCtx({ country: ctry });
  let r;
  try {
    r = startCompany0(bdId, o);
    if (typeof r !== 'string' && af) {
      payMe(af, 'Local representative, travel and legal counsel abroad');
      r.flags.abroadFee = af;
    }
  } finally {
    setCtx(prevCtx);
  }
  if (r && typeof r === 'object' && !r.mgr) {
    /* you work there yourself, within the hours you have left */
    const used = hoursUsed(r);
    r.ohrs = Math.max(0, Math.floor(Math.min(r.ohrs || 0, HCAP - used, Math.max(10, 55 - used)) / 5) * 5);
  }
  /* a brand-new name is known only to friends and family (a franchisee carries its brand's name) */
  try { if (r && typeof r === 'object' && !(r.franchise && r.franchise.fran)) r.aware = Math.min(r.aware, 10 + (r.bs || 0) * 30); } catch (e) { }
  return runSteps('startCompany', r, bdId, o);
}
function startCompany0(bdId, o) {
  const bd = calib(BD[bdId]);
  const bs = brandStrength(bdId);
  const size = o.size || startSize(bdId, o.city || S.player.city, bs.v, o.fran);
  const co = newCompany(bdId, { city: o.city, form: o.form || 'ENK', size, name: o.name, country: o.country });
  co.bs = bs.v;
  if (bs.v > 0.05) {
    co.wom = Math.round(bs.v * 40);
    co.aware = Math.min(80, co.aware + bs.v * 30);
    co.rep = Math.min(80, co.rep + bs.v * 14);
    co.flags.bsFrom = bs.from.name;
  }
  if (o.form === 'AS') {
    const c = CC();
    if (S.cash < c.asCapital + c.asFee) {
      S.cos.pop();
      return 'cash';
    }
    payMe(c.asFee, 'Registration of ' + co.name);
    moveCash(co, 0);
    payMe(c.asCapital, 'Share capital');
    moveCash(co, c.asCapital);
    ownerFlow(co, c.asCapital);
    co.inj += c.asCapital;
    co.tx.unshift({ w: S.week, a: c.asCapital, l: 'Share capital paid in' });
    if (o.acc) pickAccountant(co, o.acc);
  }
  if (o.cash) injectCash(co, o.cash);
  return co;
}
/* automatic setup: paperwork, premises, equipment (one personal item per person, topUpEq), property and staff.
   While it runs AUTO_SETUP is above zero: a company still at home may rent a small place so it can hire. */
let AUTO_SETUP = 0;
function autoSetup(co, o) {
  AUTO_SETUP++;
  try {
    const log = autoSetupCore(co, o);
    try { topUpEq(co); } catch (e) { console.error(e); }
    return log;
  } finally { AUTO_SETUP--; }
}
function autoSetupCore(co, o) {
  o = o || {};
  const bd = BD[co.type];
  const log = [];
  if (!co.mgr && !o.force) return ['Automatic setup needs a manager.'];
  if (!co.acc && (co.form === 'AS' || docNeeds(co).indexOf('acctr') >= 0)) pickAccountant(co, poolFor(co.country).acc[co.form === 'AS' ? 1 : 0].id);
  docNeeds(co).forEach(d => {
    if (d === 'mva_na') return;
    if (!docOk(co, d) && !(co.docs[d] && co.docs[d].st === 'applied')) {
      const r = applyDoc(co, d);
      if (r !== 'ok' && r !== 'have') log.push('doc ' + d + ': ' + r);
    }
  });
  if (bd.prem && bd.prem[0] !== 'none' && !co.prem) {
    const r = setPrem(co, bd.prem[0], premListings(co)[2].m2, false, premListings(co)[2]);
    if (r !== 'ok') log.push('prem: ' + r);
  }
  const need = stdEq(bd, co.size);
  bd.eq.forEach(e => {
    const q = need[e.id] || (e.fl.indexOf('r') >= 0 ? 1 : 0);
    if (q <= 0) return;
    if (e.vo) {
      for (let i = 0; i < q; i++) {
        let r = buyVeh(co, e.id, e.vo[0], o.vehMode || (window.R22 && R22.vehMode ? R22.vehMode(co, e) : 'new'));
        /* a firm that meant to buy used and cannot afford it leases before it takes on a loan for a new vehicle */
        if (r === 'cash' && !o.vehMode && window.R22 && R22.vehMode && R22.vehMode(co, e) === 'used') r = buyVeh(co, e.id, e.vo[0], 'lease');
        if (r === 'cash' && !o.vehMode) r = buyVeh(co, e.id, e.vo[0], 'finance');
        if (r === 'cash' && !o.vehMode) r = buyVeh(co, e.id, e.vo[0], 'lease');
        if (r !== 'ok') {
          log.push('veh ' + e.id + ': ' + r);
          break;
        }
      }
    }
    else {
      let qq = q, r = buyEq(co, e.id, qq, o.eqMode || 'new');
      while (r === 'cash' && qq > 1) {
        qq = Math.max(1, Math.floor(qq / 2));
        r = buyEq(co, e.id, qq, o.eqMode || 'new');
      }
      if (r !== 'ok') log.push('eq ' + e.id + ': ' + r);
    }
  });
  if (bd.fam === 'rent' && !(co.props && co.props.length)) {
    const ls = propListings(co);
    let r = 'cash';
    for (let i = 3; i >= 0 && r !== 'ok'; i--) r = buyProp(co, ls[i], o.ltv != null ? o.ltv : (policy() > 0.09 ? 0.2 : 0.55), ls[i].price * 0.06);
    if (r !== 'ok') log.push('prop: ' + r);
  }
  log.push.apply(log, fillStaff(co));
  if (bd.tw && bd.tw.ins) autoIns(co);
  return log;
}
function tryOpen(co) {
  const r = openCompany(co);
  return r;
}
/* the game: set a company up and open it if it can open now. Time never moves here: a company that cannot open yet
   stays in setup, and the caller tries again later. r: why it could not open ('ok' when it did) */
function setupAndOpenNow(co) {
  const log = autoSetup(co, { force: 1 });
  const r = openCompany(co);
  return { log, st: co.st, r };
}
/* tests only: the same, then whole weeks of the game pass until it opens (up to 130). Never call this from the game */
function setupAndOpen(co) {
  const log = autoSetup(co, { force: 1 });
  let guard = 0;
  while (co.st === 'setup' && guard++ < 130) {
    const m = openCompany(co);
    if (m === 'ok') break;
    nextWeek();
    if (S.over) break;
  }
  return { log, st: co.st };
}

function fillStaff(co) {
  const bd = BD[co.type], log = [];
  if (bd.tw.noStaff || bd.fam === 'rent') return log;
  stdStaff(bd, co.size).forEach((s, i) => {
    const have = co.staff.filter(x => x.role === s[0]).length;
    let n = s[1] - have;
    if (i === 0 && bd.own >= 1 && !co.mgr) n = Math.max(0, n - 1);
    for (let k = 0; k < n; k++) {
      const cs = searchWorkers(co, s[0], 'network').sort((a, b) => a.ask - b.ask);
      const c = cs[Math.floor(cs.length / 2)];
      if (c) {
        const r = hireWorker(co, c, rnl(c.ask * 1.02, 100));
        if (r !== 'ok') log.push('hire ' + s[0] + ': ' + r); else managerOnboard(co, co.staff[co.staff.length - 1]);
      }
    }
  });
  return log;
}
function matchMarket(co) {
  co.staff.forEach(s => {
    const n = S.npcs[s.id];
    if (!n) return;
    const mk = (wageFor(s.role, co) * (s.pt || 1)) * (0.7 + n.skill / 160);
    if (s.wage < mk * 0.97) s.wage = rnl(mk, 100);
  });
}
/* setup cost estimate, part 1: the plain sums for a throw-away company (part 2 is setupEstimate below) */
function setupEstimateBase(bdId, o) {
  o = o || {};
  const keepUid = S.uid, keepRs = S.rs;
  const prevC = CTXCO;
  setCtx({ country: o.country || S.country });
  const co = newCompany(bdId, { city: o.city, form: o.form || 'ENK', size: o.size || 1, name: 'tmp', country: o.country });
  S.cos.pop();
  const bd = BD[bdId];
  const r = { docs: 0, eq: 0, veh: 0, prem: 0, stock: 0, hires: 0, items: [] };
  docNeeds(co).forEach(d => {
    if (d === 'mva_na' || d === 'acctr') return;
    r.docs += docCost(co, d);
  });
  const need = stdEq(bd, co.size);
  bd.eq.forEach(e => {
    const q = need[e.id] || (e.fl.indexOf('r') >= 0 ? 1 : 0);
    if (q <= 0) return;
    if (e.vo) {
      const m = VEH[e.vo[0]];
      r.veh += (m ? m[1] : 300000) * q * Math.pow(1 + S.econ.infl, S.week / 52) * 0.2;
      r.vehFull = (r.vehFull || 0) + (m ? m[1] : 300000) * q;
    } else r.eq += eqPrice(co, e) * q;
  });
  if (bd.prem && PREM[bd.prem[0]] && bd.prem[1] > 0) {
    const m2 = Math.round(bd.prem[1] * co.size), P = PREM[bd.prem[0]];
    const rent = P[1] * cityOf(co.city).rent * Math.pow(1 + S.econ.infl, S.week / 52);
    r.prem = rent * m2 / 12 * 3 + (FIT[bd.prem[0]] || 0) * m2;
    r.rentM = rent * m2 / 12;
  }
  r.stock = initialStockCost(co, bd);
  r.abroad = abroadFee(bdId, o.country);
  if (o.fee) {
    r.fee = o.fee;
    r.eq *= (o.fitMult || 1);
    r.grant = o.cover ? fbSetupGrant(co, { cover: o.cover }) : 0;
  }
  stdStaff(bd, co.size).forEach((s, i) => {
    const n = (i === 0 && bd.own >= 1) ? Math.max(0, s[1] - 1) : s[1];
    r.hires += n * wageFor(s[0], co) * OC();
  });
  r.buffer = (bd.F || 0) * 6 * Math.pow(co.size, 0.9) * cityOf(co.city).rent * 0.5;
  r.total = r.docs + r.eq + r.veh + r.prem + r.stock + r.hires + r.buffer + (r.fee || 0) + (r.abroad || 0) - (r.grant || 0) + (o.form === 'AS' ? CC().asFee : 0); r.cap = o.form === 'AS' ? CC().asCapital : 0;
  ['docs', 'eq', 'veh', 'prem', 'stock', 'hires', 'buffer', 'total'].forEach(k => {
    if (r[k]) r[k] = rlc(r[k], o.country || S.country);
  });
  S.uid = keepUid;
  S.rs = keepRs;
  setCtx(prevC);
  return r;
}
/* setup cost estimate: what it takes to start this business, as shown on the new-company screen and used by
   managers, chains and rivals. o: { city, size, form, country, fee, cover, fitMult, solo }.
   The plain sums come from setupEstimateBase; the adjustments below run in this order. */
function setupEstimate(bdId, o) {
  const r = setupEstimateBase(bdId, o);
  const oo = o || {}, bd = BD[bdId], cc = oo.country || S.country;
  /* contractors wait weeks for the first jobs and the first payments: a bigger cash buffer */
  try {
    if (r && bd && bd.fam === 'project' && !bd.tw.dev && r.buffer) {
      const add = r.buffer * 2.5;
      r.buffer += add;
      r.total += add;
    }
  } catch (e) { }
  /* the months spent waiting for licences cost wages and rent too; fit-out in local prices */
  try {
    if (bd.prem && PREM[bd.prem[0]] && bd.prem[1] > 0 && window.R21) {
      const m2 = Math.round(bd.prem[1] * (oo.size || 1)), base = (FIT[bd.prem[0]] || 0) * m2, loc = KC(base, cc) || 0;
      r.prem = rlc(Math.max(0, r.prem - base + loc), cc);
    }
    let wk = 0;
    Object.keys(DOCS).forEach(k => { if ((bd.docs || []).indexOf(k) >= 0 && DOCS[k][3] > wk) wk = DOCS[k][3]; });
    if (wk > 8) { r.wait = rlc(((r.hires || 0) + (r.rentM || 0) + (r.vehFull || 0) * 0.012) * (wk - 4) / 4.33 * 1.15, cc); r.waitWk = wk; }
    r.total = rlc((r.docs || 0) + (r.eq || 0) + (r.veh || 0) + (r.prem || 0) + (r.stock || 0) + (r.hires || 0) + (r.buffer || 0) + (r.fee || 0) + (r.abroad || 0) - (r.grant || 0) + (r.wait || 0) + (oo.form === 'AS' ? CC().asFee : 0), cc);
  } catch (e) { console.error(e); }
  /* property businesses: the down payment and fees on the smallest listing */
  try {
    if (bd.fam === 'rent' && bd.tw && bd.tw.price) {
      const C = CO[cc] || CC(), city = (oo.city && C.cities.find(x => x.id === oo.city)) || C.cities[0];
      const units = Math.max(2, Math.round((bd.tw.units || 10) * 0.35));
      const price = units * bd.tw.price * Math.pow(city.rent || 1, 0.8) * ((S.econ && S.econ.housing) || 1);
      const ltv = policy() > 0.09 ? 0.2 : 0.55;
      r.prop = rlc((price * (1 - ltv) + price * 0.06) * 1.3, cc); /* listings vary up to about 30% around the typical price */
      r.total = rlc(r.total + r.prop, cc);
    }
  } catch (e) { console.error(e); }
  /* vehicles are traded across borders (prices differ less than local prices); in low-cost countries small firms
     buy used. Regulated finance needs capital before it can trade at a scale that pays its staff. */
  try {
    const C = CO[cc] || CC(), f = 0.4 + 0.6 * Math.min(1.15, C.pl || 1);
    const used = (C.pl || 1) < 0.7 && bdId !== 'airline';
    if (r.veh) {
      const nv = r.veh * f * (used ? 0.52 / 0.2 : 1); /* used vehicles are bought outright at about half the new price */
      r.total = rlc(r.total - r.veh + nv, cc);
      r.veh = rlc(nv, cc);
    }
    if (r.vehFull) r.vehFull *= f;
    const capReq = { bank: [180000000, 'Lending capital (regulator) and buffer'], insco: [45000000, 'Solvency capital (regulator) and buffer'] }[bdId];
    if (capReq) { const add = capReq[0] * (oo.size || 1) - (r.buffer || 0); if (add > 0) { r.buffer = rlc((r.buffer || 0) + add, cc); r.total = rlc(r.total + add, cc); r.capLbl = capReq[1]; } }
  } catch (e) { console.error(e); }
  /* a salmon farm sells nothing for over a year */
  try {
    if (bdId === 'salmon' && !r.grow41) {
      const add = KC(2300000, cc) * Math.pow(oo.size || 1, 0.9) * 0.85 * ((BD.salmon.tw && BD.salmon.tw.grow) || 78);
      r.grow41 = 1;
      r.buffer = rlc((r.buffer || 0) + add, cc);
      r.total = rlc(r.total + add, cc);
      r.capLbl = 'Feed and running costs until the first harvest (about 15 months)';
    }
  } catch (e) { console.error(e); }
  /* starting alone from home (the new-company screen): one set of the kit you need, no staff, a small buffer */
  try {
    if (oo.solo && bd && bd.prem && bd.prem[0] === 'home' && !r.solo45) {
      const need = stdEq(bd, oo.size || 1);
      let all = 0, one = 0, vAll = 0, vOne = 0;
      bd.eq.forEach(e => {
        const req = e.fl.indexOf('r') >= 0 ? 1 : 0, q = need[e.id] || req;
        if (e.vo) { const m = VEH[e.vo[0]], p = m ? m[1] : 300000; vAll += p * q; vOne += p * req; }
        else { all += e.cost * q; one += e.cost * req; }
      });
      const eq = all > 0 ? r.eq * one / all : r.eq, veh = vAll > 0 ? (r.veh || 0) * vOne / vAll : (r.veh || 0), buffer = (r.buffer || 0) * 0.25;
      r.total = rlc(Math.max(0, r.total - r.eq - (r.veh || 0) - (r.hires || 0) - (r.buffer || 0) + eq + veh + buffer), cc);
      r.eq = rlc(eq, cc); r.veh = rlc(veh, cc); r.hires = 0; r.buffer = rlc(buffer, cc); r.solo45 = 1;
    }
  } catch (e) { console.error(e); }
  return r;
}
/* wind up a company: sell assets, settle debts, pay out the rest */
function windUp(co) {
  if (co.st === 'sold' || co.st === 'bust') return 'bad';
  let cash = co.cash;
  for (const id in co.eq) cash += Math.round(co.eq[id].bv * 0.45);
  co.veh.forEach(v => {
    if (v.mode !== 'lease') cash += Math.round(v.bv * 0.7);
  });
  (co.props || []).forEach(p => {
    cash += Math.round(p.val * 0.95);
  });
  cash += Math.round(co.inv * 0.4);
  cash += sum(co.recv, r => r.bad ? 0 : r.a * 0.9);
  const dls = sum(S.loans.filter(l => l.co === co.id), l => l.bal);
  const dbt = co.pay.wages + co.pay.other + co.pay.rent + Math.max(0, co.vatAcc) + co.pay.tax + (co.fm && co.fm.liab ? co.fm.liab : 0);
  let rest = cash - dls - dbt;
  const frac = dls > 0 ? clamp((cash - dbt) / dls, 0, 1) : 1;
  let personal = 0;
  S.loans.filter(l => l.co === co.id).forEach(l => {
    const rep = l.bal * frac, left = l.bal - rep;
    if (left > 1 && (l.guar || co.form === 'ENK')) {
      personal += left;
      closeLoan(l, rep, true);
      l.name += ' (taken over by you)';
    } else closeLoan(l, rep);
  });
  if (rest < 0) {
    if (co.form === 'ENK') {
      moveCash(ME, Math.min(0, rest + personal), 'Shortfall winding up ' + co.name);
    }
    rest = 0;
  }
  if (rest > 0) {
    const mine = rest * co.own / 100;
    if (co.form === 'ENK') {
      moveCash(ME, mine, 'Closing ' + co.name);
    } else {
      const tax = mine * 0;
      moveCash(ME, mine, 'Liquidation of ' + co.name);
      S.tax.ytdDiv = (S.tax.ytdDiv || 0) + mine;
    }
  }
  releaseStaff(co);
  co.st = 'sold';
  setCash(co, 0);
  S.stats.sold++;
  return 'ok';
}
function fireExec(kind, id) {
  if (kind === 'ceo') {
    if (S.group.ceo) {
      if (S.npcs[S.group.ceo.npc]) S.npcs[S.group.ceo.npc].hired = 0;
      S.group.ceo = null;
    }
    return;
  }
  const r = S.group.regional.find(x => x.id === id);
  if (!r) return;
  if (S.npcs[r.npc]) S.npcs[r.npc].hired = 0;
  S.group.regional = S.group.regional.filter(x => x !== r);
  S.cos.forEach(c => {
    if (c.region === id) c.region = 0;
  });
}

function tryAutoOpen(co) {
  if (co.st !== 'setup' || openChecklist(co).some(x => !x.ok)) return false;
  return openCompany(co) === 'ok';
}
/* every business type is calibrated once at load, so a saved game works the same after a reload */
BD_ORDER.forEach(id => calib(BD[id]));


/* ---- src/core/core.js ---- */
'use strict';
/* ===== LEDGER core: state holder, seeded rng, calendar, formatting ===== */
let S = null;
const L = {};
const START = Date.UTC(2026, 9, 5); // Monday 5 Oct 2026
const DAY = 864e5;
function Z() {
  S.rs = (S.rs + 0x6D2B79F5) | 0;
  let t = S.rs;
  t = Math.imul(t ^ t >>> 15, 1 | t);
  t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
  return ((t ^ t >>> 14) >>> 0) / 4294967296;
}
function rng(a, b) {
  return a + (b - a) * Z();
}
function rint(a, b) {
  return Math.floor(a + Z() * (b - a + 1));
}
function chance(p) {
  return Z() < p;
}
function pick(a) {
  return a[Math.floor(Z() * a.length)];
}
function gauss() {
  let u = 0, v = 0;
  while (!u) u = Z();
  while (!v) v = Z();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}
function pois(l) {
  if (l <= 0) return 0;
  if (l > 30) return Math.max(0, Math.round(l + gauss() * Math.sqrt(l)));
  let k = 0, p = 1;
  const e = Math.exp(-l);
  do {
    k++;
    p *= Z();
  } while (p > e);
  return k - 1;
}
function wpick(items, wf) {
  let t = 0;
  const ws = items.map(i => {
    const w = Math.max(0, wf ? wf(i) : i.w);
    t += w;
    return w;
  });
  if (t <= 0) return null;
  let r = Z() * t;
  for (let i = 0; i < items.length; i++) {
    r -= ws[i];
    if (r <= 0) return items[i];
  }
  return items[items.length - 1];
}
function shuffle(a) {
  a = a.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Z() * (i + 1));
    const t = a[i];
    a[i] = a[j];
    a[j] = t;
  }
  return a;
}
function clamp(x, a, b) {
  return x < a ? a : x > b ? b : x;
}
function uid() {
  return ++S.uid;
}
function rnd(x, step) {
  step = step || 1;
  return Math.round(x / step) * step;
}
function sum(a, f) {
  let t = 0;
  for (let i = 0; i < a.length; i++) t += f ? f(a[i], i) : a[i];
  return t;
}
function wDate(w) {
  return new Date(START + w * 7 * DAY);
}
function wEnd(w) {
  return new Date(START + (w * 7 + 6) * DAY);
}
function wMonth(w) {
  return wDate(w).getUTCMonth();
}
function wYear(w) {
  return wDate(w).getUTCFullYear();
}
function monthIdx(w) {
  const d = wDate(w);
  return d.getUTCFullYear() * 12 + d.getUTCMonth();
}
function isMonthEnd(w) {
  return monthIdx(w + 1) !== monthIdx(w);
}
function isYearEnd(w) {
  return wYear(w + 1) !== wYear(w);
}
const MN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
function dateStr(w) {
  const d = wDate(w);
  return d.getUTCDate() + ' ' + MN[d.getUTCMonth()] + ' ' + d.getUTCFullYear();
}
function monthStr(w) {
  const d = wDate(w);
  return MN[d.getUTCMonth()] + ' ' + d.getUTCFullYear();
}
function npad(n) {
  if (!isFinite(n)) n = 0;
  return String(Math.round(Math.abs(n))).replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
}
function npadL(n) {
  return npad((isFinite(n) ? n : 0) / fxr(CC()));
}
function money(n, plain) {
  const c = CC();
  const v = n / fxr(c);
  const neg = Math.round(v) < 0 && Math.abs(v) >= 0.5;
  return (neg ? '−' : '') + (plain ? '' : c.cur + ' ') + npad(v);
}
function mcur(n) {
  return mshort(n);
}
function mshort0(n) {
  n = (isFinite(n) ? n : 0) / fxr(CC());
  const a = Math.abs(n), s = n < 0 ? '−' : '';
  if (a >= 1e9) return s + (+(a / 1e9).toFixed(2)) + ' bn';
  if (a >= 1e6) return s + (+(a / 1e6).toFixed(a >= 1e7 ? 1 : 2)) + ' M';
  if (a >= 1e4) return s + Math.round(a / 1e3) + ' k';
  return s + npad(a);
}
function mshort(n) {
  const c = CC().cur, sy = CC().symbol || c, v = mshort0(n);
  /* kr and zł go after the number; $, €, £ and the others in front */
  if (/^(kr|zł|[A-Z]{3})$/.test(sy)) return v + ' ' + sy;
  return v.charAt(0) === '−' ? '−' + sy + v.slice(1) : sy + v;
}
/* "1 order", "442 orders": plural of a unit label for a count (rounded to one decimal by the caller) */
function unitPl(unit, n) {
  if (unit === 'MWh') return 'MWh';
  if (unit === 'm2-week') return Math.abs((n || 0) - 1) < 0.05 ? 'm²-week' : 'm²-weeks';
  unit = String(unit || '');
  const sd = /^(.+) sold$/.exec(unit);
  if (sd) return unitPl(sd[1], n) + ' sold';
  if (Math.abs(n - 1) < 0.05) return unit;
  if (/[^aeiou]y$/.test(unit)) return unit.slice(0, -1) + 'ies';
  if (/(s|x|ch|sh)$/.test(unit)) return unit + 'es';
  return unit + 's';
}
function pc(x, d) {
  if (!isFinite(x)) x = 0;
  return (x * 100).toFixed(d == null ? 1 : d) + '%';
}

/* per-country names for authorities and institutions. Keys are the Norwegian names used in the data. */
/* Norwegian terms in the data, shown in plain English everywhere */
/* round to a tidy price in the local currency, returned in NOK units */
function rl(v) {
  const f = fxr(CC());
  return nicePrice(v / f) * f;
}
/* round a figure to a price people would really see: two significant figures, with tidy steps above that */
function nicePrice(v) {
  const a = Math.abs(v);
  if (a < 0.5) return v;
  let st;
  if (a < 10) st = 0.5; else if (a < 20) st = 1; else if (a < 100) st = 5; else if (a < 500) st = 10; else if (a < 1000) st = 50; else if (a < 5000) st = 100; else if (a < 10000) st = 500; else if (a < 50000) st = 1000; else if (a < 100000) st = 5000; else {
    const e = Math.pow(10, Math.floor(Math.log10(a)) - 1);
    st = a / e < 25 ? e : a / e < 50 ? 2.5 * e : 5 * e;
  }
  const r = Math.round(a / st) * st;
  return v < 0 ? -r : r;
}
/* rnl(v, n): round an amount to a tidy step in the current country's money. The step is about as big as n NOK
   (100, 500, 1000 ...) but a round local one: in Norway exactly n, in the UK 10, 50 or 100 pounds, in Japan
   1 000 yen. Wages, prices and offers use it, so every country sees round local numbers. */
function rnl(v, n) {
  const f = fxr(CC()), s = n / f, p = Math.pow(10, Math.floor(Math.log10(s))), m = s / p;
  const st = (m < 1.5 ? 1 : m < 3.5 ? 2 : m < 7.5 ? 5 : 10) * p;
  return f === 1 && st === n ? Math.round(v / n) * n : Math.round(v / f / st) * st * f;
}
/* the same, for a given country, in NOK units */
function rlc(v, country) {
  const f = fxr(CO[country] || CC());
  return nicePrice(v / f) * f;
}
/* Text tokens: data and messages may contain {auth:key} (the name of a public body in the
   current country, see auth()) and {m:amount} (an amount set in base units, scaled to the
   country's price level and shown in its currency). Everything shown on screen passes through here. */
function locText(s) {
  if (typeof s !== 'string' || s.indexOf('{') < 0) return s;
  return s.replace(/\{auth:(\w+)\}/g, (m, k) => auth(k)).replace(/\{m:(-?[\d.]+)\}/g, (m, n) => money(rlc(KC(+n), CTXCO ? CTXCO.country : S.country))); /* a round local amount, not a converted Norwegian one */
}
function note(txt, tone, coId) {
  txt = locText(txt);
  if (S.rep && S.rep.ev.length < 300) S.rep.ev.push({ t: txt, tone: tone || 'n', co: coId || 0 });
}
function news(txt, tone) {
  txt = locText(txt);
  S.news.unshift({ w: S.week, t: txt, tone: tone || 'n' });
  if (S.news.length > 60) S.news.length = 60;
}

/* Pipelines. A core calculation (capacity, demand, ...) runs its own work, then the steps that features add,
   in order of their number. A feature adds its step from its own file:
     addStep('capacity', 40, 'startup products', (co, bd, r) => { ... });
   A step gets all the calculation's arguments and then the result: (co, bd, r) for capacity. It changes the
   result in place (or returns a replacement). pipeSteps('capacity') lists what runs, in order.
   Numbers are spaced by ten so a new step can go between two others without renumbering. */
const PIPES = {};
function addStep(pipe, order, id, fn, quiet) {
  const L = PIPES[pipe] = PIPES[pipe] || [];
  L.push({ order, id, fn, quiet });
  L.sort((a, b) => a.order - b.order);
}
/* runSteps(pipe, result, ...args): every step gets all of the calculation's arguments and then the result, so a
   step that wants the result declares every argument first: capacity steps are (co, bd, r). */
function runSteps(pipe, r, ...args) {
  const L = PIPES[pipe];
  if (!L) return r;
  for (let i = 0; i < L.length; i++) {
    const s = L[i];
    try { const x = s.fn(...args, r); if (x !== undefined) r = x; } catch (e) { if (!s.quiet) console.error(e); }
  }
  return r;
}
/* runChecks(pipe, ctx, ...args): like runSteps, for checks that can say no. A step sets ctx.no to a reason
   (for example 'noplace') and the steps after it do not run. */
function runChecks(pipe, ctx, ...args) {
  const L = PIPES[pipe];
  if (!L) return ctx;
  for (let i = 0; i < L.length && !ctx.no; i++) {
    const s = L[i];
    try { s.fn(...args, ctx); } catch (e) { if (!s.quiet) console.error(e); }
  }
  return ctx;
}
/* runAround(pipe, co, fn): steps that must hold something in place while a whole calculation runs (for example the
   audience an event agency targets this week) wrap it: addStep('mktWeek.around', 10, 'id', (co, run) => ...).
   Like the around-steps of pipeView, a higher order wraps a lower one. */
function runAround(pipe, co, fn) {
  const L = PIPES[pipe] || [];
  const call = i => i < 0 ? fn() : L[i].fn(co, () => call(i - 1));
  return call(L.length - 1);
}
/* runPhased(pipe, args, core): around-steps wrap the whole call; before-steps run, then the core, then after-steps.
   Before- and after-steps get the call's arguments and then ph, a shared object: ph.r is the result (an after-step
   may change it), and a before-step can leave notes there for an after-step. A before-step that sets ph.no (a reason)
   stops the call there: no later before-steps, no core and no after-steps, and the call returns ph.r. */
function runPhased(pipe, args, core) {
  return runAround(pipe + '.around', args[0], () => {
    const ph = {};
    runChecks(pipe + '.before', ph, ...args);
    if (ph.no) return ph.r;
    ph.r = core();
    runSteps(pipe + '.after', ph, ...args);
    return ph.r;
  });
}
/* pipeView(pipe, base, n): a function (often a screen or a button's action) that later files adjust, in three kinds
   of step. Around-steps and routes nest like the files that add them: a higher order wraps a lower one.
   - pipe + '.around': gets the first n arguments and next; it can do something of its own, call next() for what is
     underneath (or next(x, y) to call it with other arguments) and change what comes back.
   - pipe + '.route': gets the first n arguments and may return another result (another screen); the highest order
     that does wins, and otherwise the base runs.
   - pipe: each step, in order, gets the first n arguments and then the result, and may return a new result. */
function pipeView(pipe, base, n) {
  return function (...a) {
    const self = this, L = PIPES[pipe + '.around'];
    const pad = A => { const x = A.slice(0, n); while (x.length < n) x.push(undefined); return x; };
    const inner = A => { const r = runRoute(pipe + '.route', pad(A)); return r !== undefined ? r : base.apply(self, A); };
    const call = (i, A) => i < 0 ? inner(A) : L[i].fn(...pad(A), (...b) => call(i - 1, b.length ? b : A));
    return runSteps(pipe, call(L ? L.length - 1 : -1, a), ...pad(a));
  };
}
function runRoute(pipe, args) {
  const L = PIPES[pipe];
  if (L) for (let i = L.length - 1; i >= 0; i--) {
    const s = L[i];
    try { const x = s.fn(...args); if (x !== undefined) return x; } catch (e) { if (!s.quiet) console.error(e); }
  }
}
function pipeSteps(pipe) { return (PIPES[pipe] || []).map(s => s.order + ' ' + s.id); }

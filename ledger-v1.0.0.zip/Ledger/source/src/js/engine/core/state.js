/* ---- src/core/state.js ---- */
/* ===== State, new game, serialise ===== */
/* Save versions. Every save carries v = VERSION. An older save is upgraded on load: UPGRADE[n] turns a version-n
   save into version n + 1, and they run in order up to VERSION. When a change needs old saves adjusted (a renamed
   field, a new required one), add UPGRADE[VERSION] and raise VERSION by one. Old saves are never thrown away;
   only a save from a newer game than this one is refused. */
const VERSION = 5;
const UPGRADE = {
  3: s => { /* round 52: no data changes; from now on every change that needs one gets its step here */ },
  /* round 54: staff have a pay basis and a date of their last raise. People already on full time keep the fixed
     salary they have; part-timers are hourly; the last raise counts from when they joined. */
  4: s => { (s.cos || []).forEach(c => (c.staff || []).forEach(x => { if (!x.basis) x.basis = x.hrs ? 'hour' : 'fix'; if (x.lr == null) x.lr = x.w0 || 0; })); }
};
function upgradeSave(s) {
  let v = s.v || 3;
  while (v < VERSION) { if (UPGRADE[v]) UPGRADE[v](s); v++; }
  s.v = VERSION;
  return s;
}
function newGame(o) {
  o = o || {};
  const seed = o.seed != null ? o.seed : (Date.now() % 2147483647);
  const c = CO[o.country || CO_ORDER[0]];
  setCtx({ country: c.code });
  c.loan = rl(c.loan);
  setCtx(null);
  S = {
    v: VERSION,
    seed,
    rs: seed | 0,
    uid: 1000,
    week: 0,
    country: c.code,
    player: { name: o.name || 'You', age: clamp(o.age || 30, 1, 110), city: o.city || c.cities[0].id, skill: {} },
    cash: c.loan,
    cash0: c.loan,
    flow: {},
    sav: { bal: 0 },
    loans: [],
    credit: 62,
    overdraft: 0,
    overdraftLimit: KC(25000, c.code),
    inv: { stocks: {}, crypto: {}, funds: {}, deposits: [] },
    mk: {},
    rivals: {},
    cos: [],
    npcs: {},
    pool: { acc: [] },
    inbox: [],
    news: [],
    rep: null,
    hist: { nw: [], cash: [] },
    log: [],
    econ: {
      phase: 'steady',
      dem: 1.0,
      infl: 0.03,
      fuel: 1.0,
      mat: 1.0,
      power: 1.0,
      oil: 1.0,
      housing: 1.0,
      rate: Math.max(0.0025, c.policy0),
      left: 12,
      freight: 1.0
    },
    stocks: {},
    crypto: {},
    tax: { ytd: 0, paid: 0, enkIncome: 0, wage: 0, div: 0, ytdDiv: 0, bank: 0 },
    office: null,
    group: { ceo: null, regional: [], big: 5000000 },
    deals: [],
    startups: [],
    fundHold: [],
    wealthPaid: 0,
    stats: { peak: 0, bankrupt: 0, firstWeek: 0, years: 0, sold: 0, dividends: 0, taxPaid: 0, wagesPaid: 0 },
    over: null,
    settings: { adv: 1, confirm: 1 },
    flags: {}
  };
  S.loans.push({
    id: uid(),
    kind: 'start',
    name: 'Start-up loan',
    bal: c.loan,
    rate: 0,
    margin: 0.045,
    pay: 0,
    termM: c.loanTermM,
    co: 0,
    w0: 0,
    guar: 0
  });
  S.loans[0].pay = annuity(c.loan, S.econ.rate + 0.045, c.loanTermM);
  S.rep = { ev: [], w: 0 };
  initMarkets();
  initPool();
  note('Welcome to Ledger. You have a start-up loan of ' + money(c.loan) + '. Open your first business from the Phone.', 'good');
  news(auth('cb') + ': policy rate unchanged at ' + pc(S.econ.rate, 2) + '. New year, new opportunities.', 'n');
  S.office = { tier: 'home', city: S.player.city, since: 0, staff: [], rep: { freq: 4, detail: 'short', only: 'managed' } };
  snapshot();
  return S;
}
function annuity(P, r, n) {
  const i = r / 12;
  return i <= 0 ? P / n : P * i / (1 - Math.pow(1 + i, -n));
}
/* Packed saves (round 56). A big game is stored packed: packText gives a string of safe UTF-16 characters about a
   sixth of the size (the lz-string scheme), packText64 one of plain letters for copying. A save text starts with
   'LZ1:' (packed), 'LZ64:' (packed letters) or '{' (plain JSON); deserialize reads all three. */
function lzPack(src, bits, ch) {
  if (src == null) return '';
  const dict = new Map(), make = new Set(), out = [];
  let w = '', enlarge = 2, size = 3, nb = 2, val = 0, pos = 0;
  const put = (v, n) => { for (let i = 0; i < n; i++) { val = (val << 1) | (v & 1); v >>= 1; if (pos === bits - 1) { pos = 0; out.push(ch(val)); val = 0; } else pos++; } };
  const grow = () => { if (--enlarge === 0) { enlarge = Math.pow(2, nb); nb++; } };
  const emit = () => {
    if (make.has(w)) {
      const c = w.charCodeAt(0);
      if (c < 256) { put(0, nb); put(c, 8); } else { put(1, nb); put(c, 16); }
      grow();
      make.delete(w);
    } else put(dict.get(w), nb);
    grow();
  };
  for (let i = 0; i < src.length; i++) {
    const c = src.charAt(i);
    if (!dict.has(c)) { dict.set(c, size++); make.add(c); }
    const wc = w + c;
    if (dict.has(wc)) w = wc;
    else { emit(); dict.set(wc, size++); w = c; }
  }
  if (w !== '') emit();
  put(2, nb);
  for (;;) { val <<= 1; if (pos === bits - 1) { out.push(ch(val)); break; } pos++; }
  return out.join('');
}
function lzUnpack(len, reset, next) {
  const dict = [0, 1, 2], res = [];
  let enlarge = 4, size = 4, nb = 3, w, c, val = next(0), pos = reset, idx = 1;
  const get = n => { let b = 0, p = 1; for (let i = 0; i < n; i++) { const r = val & pos; pos >>= 1; if (pos === 0) { pos = reset; val = next(idx++); } if (r > 0) b |= p; p <<= 1; } return b; };
  const t = get(2);
  if (t === 2) return '';
  c = String.fromCharCode(get(t === 0 ? 8 : 16));
  dict[3] = c; w = c; res.push(c);
  for (;;) {
    if (idx > len) return '';
    let k = get(nb);
    if (k === 2) return res.join('');
    if (k < 2) { dict[size++] = String.fromCharCode(get(k === 0 ? 8 : 16)); k = size - 1; if (--enlarge === 0) { enlarge = Math.pow(2, nb); nb++; } }
    let e;
    if (dict[k]) e = dict[k]; else if (k === size) e = w + w.charAt(0); else return null;
    res.push(e);
    dict[size++] = w + e.charAt(0);
    w = e;
    if (--enlarge === 0) { enlarge = Math.pow(2, nb); nb++; }
  }
}
const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
function packText(t) { return lzPack(t, 15, a => String.fromCharCode(a + 32)) + ' '; }
function unpackText(p) { return p ? lzUnpack(p.length, 16384, i => p.charCodeAt(i) - 32) : ''; }
function packText64(t) { const r = lzPack(t, 6, a => B64.charAt(a)); return r + '===='.slice(0, (4 - r.length % 4) % 4); }
function unpackText64(p) { p = p.replace(/[^A-Za-z0-9+/=]/g, ''); return p ? lzUnpack(p.length, 32, i => B64.indexOf(p.charAt(i))) : ''; }
function serialize() {
  return JSON.stringify(S);
}
/* a save text in any of the three forms -> the JSON text */
function saveJSON(t) {
  t = String(t || '').trim();
  if (t.slice(0, 4) === 'LZ1:') return unpackText(t.slice(4));
  if (t.slice(0, 5) === 'LZ64:') return unpackText64(t.slice(5));
  return t;
}
/* deserialize: the core below, then the steps features add: pipeSteps('deserialize') */
function deserialize(t) {
  return runSteps('deserialize', deserializeCore(t), t);
}
function deserializeCore(t) {
  const s = JSON.parse(saveJSON(t));
  if (!s || !s.cos || (s.v || 3) > VERSION) return false;
  S = upgradeSave(s);
  return true;
}
function getCo(id) {
  return S.cos.find(c => c.id === id) || null;
}
function openCos() {
  return S.cos.filter(c => c.st === 'open' || c.st === 'setup' || c.st === 'closed');
}
function liveCos() {
  return S.cos.filter(c => c.st !== 'sold' && c.st !== 'bust');
}
function bdOf(co) {
  return BD[co.type];
}
function npc(id) {
  return S.npcs[id] || null;
}
function snapshot() {
  const nw = netWorth();
  S.hist.nw.push(Math.round(nw.total));
  if (S.hist.nw.length > 520) S.hist.nw.splice(1, 1);
  S.stats.peak = Math.max(S.stats.peak, nw.total);
}


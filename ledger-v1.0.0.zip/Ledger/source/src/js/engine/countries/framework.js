/* ---- src/countries/framework.js ---- */
/* ===== Countries: framework =====
   Every country lives in its own file in src/countries/packs/ and calls defineCountry({...}).
   Nothing in the game may assume a particular country: systems read the country's data from here.
   To add a country: copy src/countries/TEMPLATE.md, fill in every field, add the file to manifest.js,
   and run  node tests/countries.js  (it lists anything missing).

   Money: the game counts money internally in one base unit (an internal unit the player never sees; its value is set by REF_ECONOMY and fx). Each country
   says how many base units one unit of its currency is worth (fx); amounts in country files are in
   the local currency and are converted here. */
const BASE_COUNTRY = 'NO'; /* the country whose currency is the internal unit: its exchange rate never moves */
const CO = {};
const CO_ORDER = [];

/* tables filled from the country files, read by the systems named next to them */
const LOCN = {}; /* authority names: news, events, documents */
const TAXO = {}; /* tax authority name */
const DOC_OVR = {}; /* local names, issuers, costs and notes for documents */
const DOC_SKIP = {}; /* documents a country does not have */
const MVA_NAME = {}; /* local name of VAT / sales tax registration */
const DOC_LOCAL = {}; /* real local fees for documents, by document id then country */
const DOC_FREE_ENK = {}; /* documents that are free for sole traders */
const BANNED = {}; /* business types that are not allowed, with the reason */
const TOURISM = {}; /* share of visitors from abroad */
const ORIG = {}; /* where visitors come from */
const AD_HEARD = {}; /* the famous ad slot people mention */
const PREM_CH = {}; /* the most expensive national media moment */
const LOCAL_T = {}; /* job titles: [manager, deputy, shift lead, regional, group CEO] */
const PROVW = {}; /* words used to name accountants, law firms and insurers */
const LEAGUES = {}; /* top football league: [name, clubs, [value range]] */

/* what a country file must contain (tests/countries.js checks every file against this) */
const COUNTRY_SCHEMA = {
  code: 'two-letter code',
  name: 'country name in English',
  flag: 'flag emoji',
  region: 'Europe, Americas, Asia and Pacific or Middle East (groups the start screen list)',
  currency: 'currency code, e.g. EUR',
  symbol: 'short currency sign used in compact amounts, e.g. kr or EUR',
  fx: 'game base units per one unit of the currency',
  population: 'millions',
  economy: { medianWage: 'median gross monthly wage, own currency', priceIndex: 'consumer price level index (EU average = 100)', officeRent: 'typical commercial rent per m2 per year, own currency', spendPerPerson: 'household spending per person per year, own currency', policyRate: 'central bank rate at the start', bureaucracy: 'how slow and costly paperwork is (1 = typical, higher = slower)' },
  start: { loan: 'start-up loan offered to a new player', loanYears: 'years to repay it' },
  tax: {
    corporate: 'company tax on profit',
    special: 'extra company tax for some industries: { oil, salmon, hydro } (empty if none)',
    dividend: 'personal tax on dividends and share gains',
    dividendShield: 'tax-free return on capital paid into a company (0 if none)',
    employer: { social: 'employer social contributions on wages', pension: 'mandatory employer pension', injury: 'mandatory accident insurance' },
    income: { flat: 'flat tax on income after allowance', allowance: 'tax-free amount', wageDeduction: '[share, max] standard deduction for employees, or null', brackets: '[[from, rate], ...] on gross income', social: { employee: 'social tax paid by employees', selfEmployed: 'social tax paid by sole traders', floor: 'no social tax below this income', capShare: 'social tax limited to this share of income above the floor (0 = no limit)' } },
    wealth: 'null, or { rate, threshold, companyShareCounted }',
    inherit: '{ free, rate, biz, bizFree }: inheritance by children'
  },
  vat: { rates: '{ std, food, low, zero }', threshold: 'turnover above which you must register', filingMonths: 'months between returns', salesTax: 'true for US-style sales tax (consumers only)' },
  companies: { forms: '{ ENK, AS, ENKs, ASs }: names of sole trader and limited company, long and short', capital: 'minimum share capital', registrationFee: 'fee to register a limited company', conversionFee: 'fee to convert a sole trader to a limited company' },
  work: { leaveWeeks: 'statutory paid holiday in weeks' },
  authorities: { tax: '', cb: 'central bank', comp: 'competition', fin: 'financial supervisor', lab: 'labour inspection', food: 'food safety', cons: 'consumer', data: 'data protection', road: 'road transport', health: 'health', reg: 'business register', fish: 'fisheries', tv: 'big TV channels', idx: 'index fund name', bond: 'bond fund name' },
  documents: { overrides: 'by document id: [name, issuer, cost, weeks, renewal, note], null keeps the standard', notNeeded: 'document ids this country does not have', fees: 'real local fees by document id' },
  banned: 'business types not allowed: { typeId: reason }',
  cities: 'list of [id, name, population in thousands, rent vs national, wages vs national]',
  names: { first: 'first names', last: 'surnames', companyStart: 'first words of company names', companyEnd: 'last words of company names (list, or by business family)' },
  titles: '[manager, deputy, shift lead, regional manager, group CEO]',
  tourism: { share: 'share of visitors from abroad', origins: 'where they come from, e.g. "DE:20,UK:10"' },
  media: { prime: '[name of the biggest media moment, short description]', bigAd: 'the famous ad slot people mention' },
  providerNames: '[[accountant words], law firm word, insurer word, company suffix]',
  football: '[league name, clubs, [min, max club value in millions]] or null'
};

const NAMEB_DEFAULT = {
  venue: ['House', 'Place', 'Corner', 'Table', 'Kitchen', 'Social'],
  retail: ['Shop', 'Store', 'Market', 'Trading', 'Goods'],
  project: ['Build', 'Construction', 'Works', 'Projects', 'Contracting'],
  prod: ['Foods', 'Works', 'Industries', 'Production', 'Makers'],
  logi: ['Transport', 'Logistics', 'Freight', 'Haulage', 'Lines'],
  rent: ['Property', 'Estates', 'Lettings', 'Homes', 'Holdings'],
  fin: ['Capital', 'Finance', 'Invest', 'Partners', 'Trust'],
  energy: ['Energy', 'Power', 'Renewables', 'Utilities']
};
const MKCITY = (list, c) => list.map(x => ({
  id: x[0],
  name: x[1],
  pop: x[2],
  rent: Math.round(c.rent * x[3] * 100) / 100,
  wage: Math.round(c.wage * x[4] * 100) / 100,
  dem: Math.round(Math.min(2.4, Math.max(0.35, 0.42 + 0.55 * Math.log10(x[2] / 20))) * c.mkt * 100) / 100,
  price: Math.round(c.pl * (0.9 + 0.1 * x[3]) * 100) / 100
}));

/* The game's reference economy, in base units. Every country's real figures (in its own currency)
   are compared with these to get its price, wage, rent and demand levels. */
const REF_ECONOMY = { medianWage: 56000, priceIndex: 137, officeRent: 2500, spendPerPerson: 330000 };
function defineCountry(p) {
  const fx = p.fx, B = v => v * fx;
  const t = p.tax, inc = t.income;
  const c = {
    code: p.code,
    name: p.name,
    flag: p.flag,
    region: p.region || 'Europe',
    cur: p.currency,
    symbol: p.symbol || p.currency,
    fx,
    pop: p.population,
    pl: Math.round(p.economy.priceIndex / REF_ECONOMY.priceIndex * 100) / 100,
    /* real spending power (spending / price level), sublinear: richer people do not buy twice as many haircuts */
    mkt: Math.round(Math.sqrt(B(p.economy.spendPerPerson) / REF_ECONOMY.spendPerPerson / (p.economy.priceIndex / REF_ECONOMY.priceIndex)) * 100) / 100,
    policy0: p.economy.policyRate,
    bur: p.economy.bureaucracy,
    rent: Math.round(B(p.economy.officeRent) / REF_ECONOMY.officeRent * 100) / 100,
    wage: Math.round(B(p.economy.medianWage) / REF_ECONOMY.medianWage * 100) / 100,
    loan: B(p.start.loan),
    loanTermM: Math.round(p.start.loanYears * 12),
    corp: t.corporate,
    special: t.special || {},
    divTax: t.dividend,
    shield: t.dividendShield || 0,
    empNI: t.employer.social,
    otp: t.employer.pension,
    injury: t.employer.injury,
    eeNI: inc.social.employee,
    selfNI: inc.social.selfEmployed,
    income: {
      flat: inc.flat || 0,
      allowance: B(inc.allowance || 0),
      wageDeduction: inc.wageDeduction ? [inc.wageDeduction[0], B(inc.wageDeduction[1])] : null,
      brackets: (inc.brackets || []).map(b => [B(b[0]), b[1]]),
      floor: B(inc.social.floor || 0),
      capShare: inc.social.capShare || 0
    },
    wealthRate: t.wealth ? t.wealth.rate : 0,
    wealthThr: t.wealth ? B(t.wealth.threshold) : 0,
    wealthShare: t.wealth ? t.wealth.companyShareCounted : 0,
    /* inheritance by children (features/player/dynasty.js): allowance, marginal rate, relief on business shares and
       how much business is fully exempt first */
    inhFree: t.inherit ? B(t.inherit.free) : 0,
    inhRate: t.inherit ? t.inherit.rate : 0,
    inhBiz: t.inherit ? t.inherit.biz : 0,
    inhBizFree: t.inherit ? B(t.inherit.bizFree) : 0,
    vat: Object.assign({ std: 0, food: 0, low: 0, zero: 0 }, p.vat.rates),
    vatThr: B(p.vat.threshold || 0),
    vatFreq: p.vat.filingMonths,
    asCapital: B(p.companies.capital),
    asFee: Math.round(B(p.companies.registrationFee)),
    asConvFee: B(p.companies.conversionFee),
    forms: p.companies.forms,
    leaveWk: p.work.leaveWeeks,
    first: p.names.first.slice(),
    last: p.names.last.slice(),
    nameA: p.names.companyStart.slice(),
    pack: p
  };
  if (p.vat.salesTax) c.salesTax = 1;
  c.nameB = Array.isArray(p.names.companyEnd) ? Object.assign({ svc: p.names.companyEnd }, NAMEB_DEFAULT) : p.names.companyEnd;
  c.cities = Array.isArray(p.cities[0]) ? MKCITY(p.cities, c) : p.cities;
  CO[p.code] = c;
  CO_ORDER.push(p.code);
  /* fill the tables used by the systems */
  const a = Object.assign({}, p.authorities);
  TAXO[p.code] = a.tax;
  delete a.tax;
  LOCN[p.code] = a;
  const d = p.documents || {};
  if (d.overrides && Object.keys(d.overrides).length) DOC_OVR[p.code] = d.overrides;
  if (d.notNeeded && d.notNeeded.length) DOC_SKIP[p.code] = d.notNeeded;
  if (p.vat.registrationName) MVA_NAME[p.code] = p.vat.registrationName;
  for (const id in d.fees || {}) (DOC_LOCAL[id] = DOC_LOCAL[id] || {})[p.code] = d.fees[id];
  DOC_FREE_ENK[p.code] = d.freeForSoleTraders || [];
  for (const b in p.banned || {}) (BANNED[b] = BANNED[b] || {})[p.code] = p.banned[b];
  TOURISM[p.code] = p.tourism.share;
  if (p.tourism.origins) ORIG[p.code] = p.tourism.origins;
  if (p.media.bigAd) AD_HEARD[p.code] = p.media.bigAd;
  if (p.media.prime) PREM_CH[p.code] = p.media.prime;
  if (p.titles) LOCAL_T[p.code] = p.titles;
  if (p.providerNames) PROVW[p.code] = p.providerNames;
  if (p.football) LEAGUES[p.code] = p.football;
  return c;
}

/* ----- reading the current country ----- */
let CTXCO = null;
function CC() {
  return CO[(CTXCO && CTXCO.country) || (S && S.country) || BASE_COUNTRY];
}
function fxr(c) {
  return c.fx * ((typeof S !== 'undefined' && S && S.fxd && S.fxd[c.code]) || 1);
}
function costIdx(code) {
  const c = CO[code] || CC();
  return 0.5 + 0.5 * (c.pl || 1);
}
function setCtx(co) {
  CTXCO = co || null;
}
function homeCC() {
  return CO[(S && S.country) || BASE_COUNTRY];
}
function cityOf(id) {
  let c = CC().cities.find(c => c.id === id);
  if (c) return c;
  for (const k in CO) {
    c = CO[k].cities.find(x => x.id === id);
    if (c) return c;
  }
  return CC().cities[0];
}
/* name of a public body in the current country: auth('food'), auth('tax') ... */
function auth(key, cc) {
  cc = cc || CC().code;
  if (key === 'tax') return TAXO[cc];
  return (LOCN[cc] || {})[key] || key;
}
function legalStatus(bdId, country) {
  const b = BANNED[bdId];
  if (b && b[country]) return { ok: false, why: b[country] };
  return { ok: true };
}

/* optional local colour from the country file (flavour section), with a neutral default */
function flavour(key, def, cc) {
  const c = CO[cc || CC().code];
  return (c && c.pack.flavour && c.pack.flavour[key]) || def;
}

/* ----- personal taxes, all driven by the country's data ----- */
function bracketTax(inc, br) {
  let t = 0;
  for (let i = 0; i < br.length; i++) {
    const lo = br[i][0], hi = i + 1 < br.length ? br[i + 1][0] : Infinity;
    if (inc > lo) t += (Math.min(inc, hi) - lo) * br[i][1];
  }
  return t;
}
/* annual personal income tax. kind: 'self' (sole trader profit) or 'wage' */
function personalTax(inc, kind) {
  const c = CC(), I = c.income;
  inc = Math.max(0, inc);
  const rate = kind === 'wage' ? c.eeNI : c.selfNI;
  const ded = kind === 'wage' && I.wageDeduction ? Math.min(I.wageDeduction[1], inc * I.wageDeduction[0]) : 0;
  const flat = I.flat ? Math.max(0, inc - ded - I.allowance) * I.flat : 0;
  const social = I.capShare ? (inc > I.floor ? Math.min(inc * rate, (inc - I.floor) * I.capShare) : 0) : inc * rate;
  return flat + bracketTax(inc, I.brackets) + social;
}
function wealthTax(net) {
  const c = CC();
  return Math.max(0, net - c.wealthThr) * c.wealthRate;
}
function dividendTax(div, shieldAllow) {
  return Math.max(0, div - Math.max(0, shieldAllow || 0)) * CC().divTax;
}
/* company tax rate for a business: special industry rates where the country has them */
function specialTax(co, kind, fallback) {
  const c = CO[co.country] || CC();
  return c.special && c.special[kind] != null ? c.special[kind] : fallback;
}

/* ----- names ----- */
function personName() {
  const c = CC();
  return pick(c.first) + ' ' + pick(c.last);
}
/* Brand-style names: surnames, partner names and coined words built from local roots ("Fjordvik Bygg", "Haugen & Dahl Partners") */
const COIN_END = {
  nordic: ['vik', 'heim', 'dal', 'nes', 'lund', 'berg', 'strand', 'haug', 'sund', 'fjell'],
  germanic: ['feld', 'berg', 'hof', 'bach', 'stein', 'haus', 'werk', 'mark'],
  english: ['field', 'wood', 'ford', 'ley', 'ton', 'brook', 'gate', 'well', 'more', 'stone'],
  romance: ['val', 'mont', 'court', 'ville', 'ia', 'ora', 'ano', 'ard'],
  slavic: ['pol', 'ex', 'tex', 'mar', 'bud', 'ix', 'on'],
  baltic: ['ta', 'ra', 'lis', 'vis', 'nas'],
  asia: ['ra', 'ka', 'to', 'do', 'ya']
};
const COIN_LANG = { NO: 'nordic', SE: 'nordic', DE: 'germanic', NL: 'germanic', UK: 'english', US: 'english', CA: 'english', AU: 'english', FR: 'romance', ES: 'romance', BR: 'romance', PL: 'slavic', LT: 'baltic', JP: 'asia', KR: 'asia', CH: 'germanic', MX: 'romance', AE: 'english', IT: 'romance', DK: 'nordic', FI: 'nordic', IE: 'english', SG: 'english' };
function coinName(c) {
  let r = String(pick(c.nameA)).replace(/[^A-Za-zÀ-ÿ]/g, '');
  if (r.length > 6) r = r.slice(0, 5);
  let s = pick(COIN_END[COIN_LANG[c.code]] || COIN_END.english);
  if (r.slice(-1).toLowerCase() === s[0]) s = s.slice(1);
  return r + s;
}
function brandCoName(c, fam) {
  const end = pick(c.nameB[fam] || c.nameB.svc);
  const r = rng(0, 1);
  if (r < 0.3 && c.last && c.last.length) return pick(c.last) + ' ' + end;
  if (r < 0.42 && (fam === 'svc' || fam === 'fin') && c.last && c.last.length > 1) {
    const a = pick(c.last), b = pick(c.last.filter(x => x !== a));
    return a + ' & ' + b + ' ' + end;
  }
  if (r < 0.82) return coinName(c) + ' ' + end;
  return pick(c.nameA) + ' ' + end;
}
/* coName: defined in features/world/company_names.js (names that fit the business) */


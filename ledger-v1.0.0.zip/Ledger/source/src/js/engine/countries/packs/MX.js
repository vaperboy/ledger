/* ---- src/countries/packs/MX.js ---- */
/* ===== Country: Mexico (round 56) =====
   All money amounts in this file are in MXN. Rates are shares (0.25 = 25%).
   Figures are approximations for a game; check them against official sources before relying on them.
   Company tax 30% plus 10% of profit shared with employees (PTU); VAT 16% (food 0%); employer social security
   (IMSS, housing fund INFONAVIT, retirement SAR) about a quarter of wages; no inheritance tax; a large informal
   economy and a central bank rate well above Europe's.
   The fields are described in src/countries/framework.js (COUNTRY_SCHEMA). */
defineCountry({
  code: 'MX',
  name: 'Mexico',
  flag: '🇲🇽',
  region: 'Americas', /* where the country sits in the start screen's list */
  currency: 'MXN',
  symbol: 'MX$',
  fx: 0.578, /* game base units per 1 MXN */
  population: 131, /* millions */
  economy: {
    medianWage: 9500,
    priceIndex: 62,
    officeRent: 3000,
    spendPerPerson: 120000,
    policyRate: 0.075,
    bureaucracy: 1.5
  },
  start: { loan: 250000, loanYears: 5 },
  tax: {
    corporate: 0.37, /* 30% income tax plus the 10% employee profit share (PTU), counted together */
    special: {},
    dividend: 0.1,
    dividendShield: 0,
    employer: { social: 0.22, pension: 0.07, injury: 0.01 }, /* IMSS; INFONAVIT 5% and SAR 2%; work-risk premium */
    income: {
      flat: 0,
      allowance: 0,
      wageDeduction: null,
      brackets: [[0, 0.0192], [8952, 0.064], [75984, 0.1088], [133536, 0.16], [155229, 0.1792], [185852, 0.2136], [374837, 0.2352], [590796, 0.3], [1127926, 0.32], [1503902, 0.34], [4511707, 0.35]], /* ISR, yearly */
      social: { employee: 0.028, selfEmployed: 0.1, floor: 0, capShare: 0 }
    },
    wealth: null,
    inherit: { free: 0, rate: 0, biz: 0, bizFree: 0 } /* no inheritance tax */
  },
  vat: { rates: { std: 0.16, food: 0, low: 0.16, zero: 0 }, threshold: 0, filingMonths: 1, salesTax: false },
  companies: {
    forms: { ENK: 'Self-employed with business activity', AS: 'Variable-capital company (S.A. de C.V.)', ENKs: 'PFAE', ASs: 'S.A. de C.V.' },
    capital: 1,
    registrationFee: 18000, /* notary and public registry */
    conversionFee: 20000
  },
  work: { leaveWeeks: 2.4 }, /* 12 working days in the first year since 2023 */
  authorities: {
    tax: 'Tax Administration Service (SAT)',
    cb: 'Bank of Mexico',
    comp: 'Competition Commission',
    fin: 'National Banking and Securities Commission',
    lab: 'Ministry of Labour',
    food: 'COFEPRIS',
    cons: 'PROFECO',
    data: 'Transparency and data office',
    road: 'Ministry of Infrastructure and Transport',
    health: 'COFEPRIS',
    reg: 'Public Registry of Commerce',
    fish: 'CONAPESCA',
    tv: 'Televisa and TV Azteca',
    idx: 'IPC Index Fund',
    bond: 'CETES Government Bond Fund'
  },
  documents: { overrides: {}, notNeeded: [], fees: { org: 0, mva: 0 } },
  banned: { salmon: 'No salmon sea-pen licences.' },
  cities: [
    ['cdmx', 'Mexico City', 9200, 1.35, 1.25],
    ['gdl', 'Guadalajara', 1400, 1, 1.05],
    ['mty', 'Monterrey', 1150, 1.15, 1.2],
    ['pue', 'Puebla', 1700, 0.75, 0.85],
    ['tij', 'Tijuana', 1900, 0.9, 1.05],
    ['cun', 'Cancún', 900, 1.1, 0.95],
    ['smallmx', 'Small town', 30, 0.45, 0.7]
  ],
  names: {
    first: ['Santiago', 'Sofía', 'Mateo', 'Valentina', 'Sebastián', 'Regina', 'Leonardo', 'Camila', 'Emiliano', 'Ximena', 'Diego', 'María José', 'Miguel', 'Fernanda', 'Alejandro', 'Daniela', 'José', 'Guadalupe', 'Luis', 'Andrea', 'Carlos', 'Paola', 'Jorge', 'Mariana'],
    last: ['Hernández', 'García', 'Martínez', 'López', 'González', 'Pérez', 'Rodríguez', 'Sánchez', 'Ramírez', 'Cruz', 'Flores', 'Gómez', 'Morales', 'Vázquez', 'Reyes', 'Jiménez', 'Torres', 'Díaz'],
    companyStart: ['Azteca', 'Maya', 'Sol', 'Nuevo', 'Grupo', 'Pacífico', 'Golfo', 'Jalisco', 'Norte', 'Sierra', 'Agave', 'Jaguar', 'Águila', 'Tula', 'Colonial', 'Alamo', 'Plata', 'Cielo'],
    companyEnd: ['S.A. de C.V.', 'Servicios', 'Comercial', 'Constructora', 'Grupo', 'y Asociados']
  },
  titles: ['Store manager', 'Assistant manager', 'Shift supervisor', 'Regional director', 'General director'],
  tourism: { share: 0.3, origins: 'US:60,CA:12,UK:4,ES:4,DE:3,FR:3,BR:3,JP:2,KR:2,AU:2,NL:2,SE:1' },
  media: {
    prime: ['The national team’s World Cup match', 'The whole country stops to watch; a 2026 home World Cup made it bigger still.'],
    bigAd: 'the World Cup match on Televisa'
  },
  providerNames: [['Contadores', 'Despacho Contable', 'Auditores'], 'Abogados', 'Seguros', ' S.A. de C.V.'],
  football: ['Liga MX', 18, [400, 3500]]
});

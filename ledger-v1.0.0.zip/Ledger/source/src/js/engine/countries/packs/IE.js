/* ---- src/countries/packs/IE.js ---- */
/* ===== Country: Ireland (round 57) =====
   All money amounts in this file are in EUR. Rates are shares (0.25 = 25%).
   Figures are approximations for a game; check them against official sources before relying on them.
   Median gross wage about EUR 3 800 a month (CSO), prices about 40% above the EU average (Eurostat), corporation
   tax 12.5% on trading profit, VAT 23% (13.5% reduced, 0% on most food), employer PRSI 11.25% and employee PRSI 4.2%
   from October 2025 (payroll.org), auto-enrolment pensions from 2026 at 1.5% from the employer, income tax 20% and
   40% with about EUR 4 000 of tax credits, USC 0.5-8% (the 2% band to EUR 28 700 in 2026), CAT 33% above the group A
   threshold with 90% business relief.
   The fields are described in src/countries/framework.js (COUNTRY_SCHEMA). */
defineCountry({
  code: 'IE',
  name: 'Ireland',
  flag: '🇮🇪',
  region: 'Europe', /* where the country sits in the start screen's list */
  currency: 'EUR',
  symbol: '€',
  fx: 11.6304348, /* game base units per 1 EUR */
  population: 5.4, /* millions */
  economy: {
    medianWage: 3800,
    priceIndex: 140,
    officeRent: 300,
    spendPerPerson: 25000,
    policyRate: 0.02,
    bureaucracy: 0.8
  },
  start: { loan: 12000, loanYears: 5 },
  tax: {
    corporate: 0.125,
    special: {}, /* higher company tax for some industries: oil, salmon, hydro (power) */
    dividend: 0.52, /* taxed as income: 40% plus USC and PRSI */
    dividendShield: 0,
    employer: { social: 0.1125, pension: 0.015, injury: 0 }, /* employer PRSI; auto-enrolment */
    income: {
      flat: 0,
      allowance: 0,
      wageDeduction: null,
      brackets: [[0, 0], [20000, 0.22], [28700, 0.23], [44000, 0.43], [70044, 0.48]], /* 20% and 40% after the tax credits, with USC */
      social: { employee: 0.042, selfEmployed: 0.042, floor: 5000, capShare: 0 } /* PRSI */
    },
    wealth: null,
    inherit: { free: 400000, rate: 0.33, biz: 0.9, bizFree: 0 } /* CAT, group A threshold; 90% business relief */
  },
  vat: { rates: { std: 0.23, food: 0, low: 0.135, zero: 0 }, threshold: 42500, filingMonths: 2, salesTax: false },
  companies: {
    forms: { ENK: 'Sole trader', AS: 'Private limited company (LTD)', ENKs: 'Sole trader', ASs: 'Ltd' },
    capital: 1,
    registrationFee: 50,
    conversionFee: 1000
  },
  work: { leaveWeeks: 4 },
  authorities: {
    tax: 'Revenue',
    cb: 'Central Bank of Ireland and the ECB',
    comp: 'Competition and Consumer Protection Commission',
    fin: 'Central Bank of Ireland',
    lab: 'Workplace Relations Commission',
    food: 'Food Safety Authority of Ireland',
    cons: 'Competition and Consumer Protection Commission',
    data: 'Data Protection Commission',
    road: 'Road Safety Authority',
    health: 'HIQA',
    reg: 'Companies Registration Office',
    fish: 'Sea-Fisheries Protection Authority',
    tv: 'RTÉ and Virgin Media',
    idx: 'ISEQ 20 Index Fund',
    bond: 'Irish Government Bond Fund'
  },
  documents: { overrides: {}, notNeeded: [], fees: { org: 50, mva: 0, gdpr: 0, mattil: 0 } },
  banned: { casino: 'There are no licensed casinos in Ireland.', oilgas: 'Ireland stopped issuing new oil and gas exploration licences in 2021.' },
  cities: [
    ['dub', 'Dublin', 590, 1.4, 1.12],
    ['cork', 'Cork', 225, 1, 1],
    ['lim', 'Limerick', 100, 0.85, 0.95],
    ['gal', 'Galway', 85, 0.95, 0.95],
    ['wat', 'Waterford', 60, 0.8, 0.92],
    ['smallie', 'Small town', 8, 0.55, 0.88]
  ],
  names: {
    first: ['Jack', 'Grace', 'Noah', 'Emily', 'James', 'Fiadh', 'Conor', 'Sophie', 'Oisín', 'Lucy', 'Seán', 'Ava', 'Cian', 'Ellie', 'Darragh', 'Aoife', 'Liam', 'Niamh', 'Patrick', 'Siobhán', 'Ciarán', 'Róisín', 'Eoin', 'Ciara', 'Declan', 'Mary'],
    last: ['Murphy', 'Kelly', 'O’Sullivan', 'Walsh', 'Smith', 'O’Brien', 'Byrne', 'Ryan', 'O’Connor', 'O’Neill', 'O’Reilly', 'Doyle', 'McCarthy', 'Gallagher', 'O’Doherty', 'Kennedy', 'Lynch', 'Murray', 'Quinn', 'Moore'],
    companyStart: ['Emerald', 'Celtic', 'Shamrock', 'Liffey', 'Shannon', 'Atlantic', 'Wicklow', 'Kerry', 'Connacht', 'Leinster', 'Munster', 'Ulster', 'Claddagh', 'Burren', 'Corrib', 'Boyne', 'Galway', 'Dublin', 'Harbour', 'Clover'],
    companyEnd: ['Ltd', 'Group', 'Services', 'Builders', 'Trading', 'Partners']
  },
  titles: ['Store manager', 'Assistant manager', 'Shift supervisor', 'Regional manager', 'Chief executive'],
  tourism: { share: 0.6, origins: 'UK:35,US:20,DE:8,FR:7,ES:5,IT:5,NL:3,CA:3,AU:3' },
  media: {
    prime: ['The Late Late Toy Show', 'Most of the country watches the Christmas special on RTÉ.'],
    bigAd: 'an ad during the Late Late Show'
  },
  providerNames: [['Accountants', 'Chartered Accountants', 'Bookkeeping'], 'Solicitors', 'Insurance', ' Ltd'],
  football: ['League of Ireland Premier Division', 10, [1, 15]]
});

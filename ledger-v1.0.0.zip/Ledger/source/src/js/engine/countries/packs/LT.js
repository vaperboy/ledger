/* ---- src/countries/packs/LT.js ---- */
/* ===== Country: Lithuania =====
   All money amounts in this file are in EUR. Rates are shares (0.25 = 25%).
   Figures are approximations for a game; check them against official sources before relying on them.
   The fields are described in src/countries/framework.js (COUNTRY_SCHEMA). */
defineCountry({
  code: 'LT',
  name: 'Lithuania',
  flag: '🇱🇹',
  region: 'Europe', /* where the country sits in the start screen's list */
  currency: 'EUR',
  symbol: '€',
  fx: 11.6304348, /* game base units per 1 EUR */
  population: 2.8, /* millions */
  economy: {
    medianWage: 1900,
    priceIndex: 76,
    officeRent: 75,
    spendPerPerson: 15000,
    policyRate: 0.02,
    bureaucracy: 0.8
  },
  start: { loan: 7500, loanYears: 5 },
  tax: {
    corporate: 0.16,
    special: {}, /* higher company tax for some industries: oil, salmon, hydro (power) */
    dividend: 0.15,
    dividendShield: 0, /* tax-free return on paid-in capital */
    employer: { social: 0.0177, pension: 0, injury: 0 },
    income: {
      flat: 0, /* flat tax on income after the allowance */
      allowance: 0,
      wageDeduction: null,
      brackets: [[0, 0.2], [114000, 0.32]], /* [from, rate] on gross income */
      social: { employee: 0.195, selfEmployed: 0.15, floor: 0, capShare: 0 }
    },
    wealth: null,
    inherit: { free: 0, rate: 0, biz: 0, bizFree: 0 } /* children and spouses are exempt */
  },
  vat: { rates: { std: 0.21, food: 0.09, low: 0.05, zero: 0 }, threshold: 45000, filingMonths: 1, salesTax: false },
  companies: {
    forms: { ENK: 'Individual activity', AS: 'Private limited company (UAB)', ENKs: 'IV', ASs: 'UAB' },
    capital: 1000,
    registrationFee: 60,
    conversionFee: 210
  },
  work: { leaveWeeks: 4 },
  authorities: {
    tax: 'State Tax Inspectorate',
    cb: 'Bank of Lithuania',
    comp: 'Competition Council',
    fin: 'Bank of Lithuania',
    lab: 'State Labour Inspectorate',
    food: 'State Food and Veterinary Service',
    cons: 'Consumer Rights Protection Authority',
    data: 'State Data Protection Inspectorate',
    road: 'Road Transport Authority',
    health: 'Ministry of Health',
    reg: 'Centre of Registers',
    fish: 'Ministry of Agriculture',
    tv: 'LRT and LNK',
    idx: 'Vilnius All-Share Index Fund',
    bond: 'Lithuanian Bond Fund'
  },
  documents: {
    overrides: {}, /* [name, issuer, cost, weeks, renewal, note]; null keeps the standard value */
    notNeeded: [],
    fees: { org: 0, mva: 0 }
  },
  banned: { oilgas: 'No petroleum resources to licence.', salmon: 'No sea coast for pens.' },
  cities: [
    ['vln', 'Vilnius', 580, 1.2, 1.2],
    ['kau', 'Kaunas', 290, 0.9, 1],
    ['klp', 'Klaipėda', 150, 0.8, 0.96],
    ['siau', 'Šiauliai', 100, 0.55, 0.85],
    ['smalllt', 'Small town', 15, 0.35, 0.75]
  ],
  names: {
    first: [
      'Jonas',
      'Ona',
      'Tomas',
      'Rūta',
      'Mantas',
      'Gintarė',
      'Andrius',
      'Laura',
      'Darius',
      'Eglė',
      'Lukas',
      'Austėja',
      'Paulius',
      'Monika',
      'Marius',
      'Ieva',
      'Rokas',
      'Kristina',
      'Vytautas',
      'Jurgita',
      'Simas',
      'Agnė',
      'Edvinas',
      'Giedrė',
      'Karolis',
      'Indrė',
      'Arūnas',
      'Milda'
    ],
    last: [
      'Kazlauskas',
      'Petrauskas',
      'Jankauskas',
      'Stankevičius',
      'Vasiliauskas',
      'Butkus',
      'Paulauskas',
      'Urbonas',
      'Navickas',
      'Žukauskas',
      'Ramanauskas',
      'Mockus',
      'Kavaliauskas',
      'Baranauskas',
      'Šimkus',
      'Rimkus',
      'Sakalauskas',
      'Pocius',
      'Matulevičius',
      'Bagdonas',
      'Mikalauskas',
      'Adomaitis',
      'Grigaitis',
      'Vaitkus',
      'Jonaitis',
      'Račkauskas'
    ],
    companyStart: [
      'Baltijos',
      'Nemuno',
      'Auksinis',
      'Žalias',
      'Vilniaus',
      'Saulė',
      'Gintaras',
      'Aušra',
      'Rytas',
      'Pajūrio',
      'Lietuvos',
      'Kauno',
      'Klaipėdos',
      'Dzūkijos',
      'Žemaitijos',
      'Aukštaitijos',
      'Baltasis',
      'Raudonas',
      'Sidabrinis',
      'Pirmas',
      'Gera',
      'Naujas',
      'Šviesa',
      'Miško',
      'Jūros'
    ],
    companyEnd: ['UAB', 'Grupė', 'Paslaugos', 'Prekyba', 'Statyba', 'Servisas']
  },
  titles: ['Director', 'Deputy director', 'Shift manager', 'Regional head', 'General director'],
  tourism: { share: 0.4, origins: 'PL:25,DE:20,UK:12,SE:10,US:10,NO:8,FR:8,NL:7' },
  media: {
    prime: ['National basketball and LRT prime time', 'Lithuania follows basketball closely.'],
    bigAd: 'LRT prime time'
  },
  providerNames: [['Apskaita', 'Buhalterija', 'Auditas'], 'Advokatų kontora', 'Draudimas', ' UAB'],
  football: ['A Lyga', 10, [2, 12]]
});


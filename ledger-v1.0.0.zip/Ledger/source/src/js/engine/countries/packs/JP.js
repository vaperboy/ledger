/* ---- src/countries/packs/JP.js ---- */
/* ===== Country: Japan =====
   All money amounts in this file are in JPY. Rates are shares (0.25 = 25%).
   Figures are approximations for a game; check them against official sources before relying on them.
   The fields are described in src/countries/framework.js (COUNTRY_SCHEMA). */
defineCountry({
  code: 'JP',
  name: 'Japan',
  flag: '🇯🇵',
  region: 'Asia and Pacific', /* where the country sits in the start screen's list */
  currency: 'JPY',
  symbol: '¥',
  fx: 0.0713333, /* game base units per 1 JPY */
  population: 124, /* millions */
  economy: {
    medianWage: 320000,
    priceIndex: 80,
    officeRent: 30000,
    spendPerPerson: 3200000,
    policyRate: 0.0075,
    bureaucracy: 1.3
  },
  start: { loan: 1300000, loanYears: 5 },
  tax: {
    corporate: 0.3,
    special: {}, /* higher company tax for some industries: oil, salmon, hydro (power) */
    dividend: 0.20315,
    dividendShield: 0, /* tax-free return on paid-in capital */
    employer: { social: 0.15, pension: 0, injury: 0.005 },
    income: {
      flat: 0.1, /* flat tax on income after the allowance */
      allowance: 430000,
      wageDeduction: null,
      brackets: [
        [0, 0.05],
        [1950000, 0.1],
        [3300000, 0.2],
        [6950000, 0.23],
        [9000000, 0.33],
        [18000000, 0.4],
        [40000000, 0.45]
      ], /* [from, rate] on gross income */
      social: { employee: 0.15, selfEmployed: 0.15, floor: 0, capShare: 0 }
    },
    wealth: null,
    inherit: { free: 36000000, rate: 0.45, biz: 0.8, bizFree: 0 } /* top rate 55%; tax on shares of a family company can be deferred */
  },
  vat: {
    rates: { std: 0.1, food: 0.08, low: 0.08, zero: 0 },
    threshold: 10000000,
    filingMonths: 12,
    salesTax: false,
    registrationName: 'Consumption tax registration'
  },
  companies: {
    forms: { ENK: 'Sole proprietor', AS: 'Joint-stock company (KK)', ENKs: 'Kojin', ASs: 'KK' },
    capital: 1,
    registrationFee: 200000,
    conversionFee: 275000
  },
  work: { leaveWeeks: 2 },
  authorities: {
    tax: 'National Tax Agency',
    cb: 'Bank of Japan',
    comp: 'Fair Trade Commission',
    fin: 'Financial Services Agency',
    lab: 'Labour Standards Inspection Office',
    food: 'Ministry of Health, Labour and Welfare',
    cons: 'Consumer Affairs Agency',
    data: 'Personal Information Protection Commission',
    road: 'Ministry of Land, Infrastructure and Transport',
    health: 'Ministry of Health',
    reg: 'Legal Affairs Bureau',
    fish: 'Fisheries Agency',
    tv: 'NHK and Nippon TV',
    idx: 'Nikkei All-Share Index Fund',
    bond: 'Japanese Government Bond Fund'
  },
  documents: {
    overrides: {
      ce: ['Product safety mark (PSE)', null, null, null, null, 'Needed to sell electrical products.'],
      gdpr: ['Privacy policy (APPI)', null, null, null, null, 'Needed when you hold customer data.']
    }, /* [name, issuer, cost, weeks, renewal, note]; null keeps the standard value */
    notNeeded: ['eh'],
    fees: {
      org: 0,
      mva: 0,
      hms: 0,
      skjenk: 0,
      salg: 30000,
      drone: 1450,
      tgodk: 90000,
      mattil: 18000,
      megler: 33000,
      hpr: 0
    }
  },
  banned: {
    casino: 'Casinos are only allowed in a few approved integrated resorts. No new private licences.',
    oilgas: 'No significant licensing rounds.'
  },
  cities: [
    ['tyo', 'Tokyo', 14000, 1.5, 1.2],
    ['osa', 'Osaka', 2750, 1, 1.05],
    ['nag', 'Nagoya', 2300, 0.9, 1.02],
    ['fuk', 'Fukuoka', 1600, 0.8, 0.96],
    ['sap', 'Sapporo', 1960, 0.7, 0.92],
    ['smalljp', 'Small town', 40, 0.4, 0.78]
  ],
  names: {
    first: [
      'Haruto',
      'Yui',
      'Sota',
      'Hina',
      'Ren',
      'Aoi',
      'Yuto',
      'Mei',
      'Kaito',
      'Sakura',
      'Takumi',
      'Rin',
      'Daiki',
      'Nana',
      'Kenji',
      'Emi',
      'Shota',
      'Nanami'
    ],
    last: [
      'Sato',
      'Suzuki',
      'Takahashi',
      'Tanaka',
      'Watanabe',
      'Ito',
      'Yamamoto',
      'Nakamura',
      'Kobayashi',
      'Kato',
      'Yoshida',
      'Yamada',
      'Sasaki',
      'Matsumoto'
    ],
    companyStart: [
      'Nihon',
      'Sakura',
      'Fuji',
      'Asahi',
      'Kita',
      'Midori',
      'Hikari',
      'Seiko',
      'Tokyo',
      'Daiwa',
      'Minami',
      'Higashi',
      'Nishi',
      'Hinode',
      'Tsubame',
      'Kaze',
      'Mizu',
      'Take',
      'Matsu',
      'Yamato'
    ],
    companyEnd: ['KK', 'Group', 'Service', 'Shoji', 'Kensetsu', 'Kogyo']
  },
  titles: ['Branch manager', 'Deputy branch manager', 'Shift leader', 'Regional director', 'Representative director'],
  tourism: { share: 0.25, origins: 'KR:30,US:12,AU:8,UK:8,FR:7,DE:7,CA:6,ES:5,BR:5,SE:6,NO:6' },
  media: { prime: ['Prime-time TV and Koshien baseball', 'Reaches the whole country.'], bigAd: 'prime-time TV' },
  providerNames: [['Kaikei', 'Zeirishi', 'Audit'], 'Law Office', 'Hoken', ' KK'],
  football: ['J1 League', 20, [30, 150]]
});


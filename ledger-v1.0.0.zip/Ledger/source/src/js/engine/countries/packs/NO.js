/* ---- src/countries/packs/NO.js ---- */
/* ===== Country: Norway =====
   All money amounts in this file are in NOK. Rates are shares (0.25 = 25%).
   Figures are approximations for a game; check them against official sources before relying on them.
   The fields are described in src/countries/framework.js (COUNTRY_SCHEMA). */
defineCountry({
  code: 'NO',
  name: 'Norway',
  flag: '🇳🇴',
  region: 'Europe', /* where the country sits in the start screen's list */
  currency: 'NOK',
  symbol: 'kr',
  fx: 1, /* game base units per 1 NOK */
  population: 5.5, /* millions */
  economy: {
    medianWage: 56000,
    priceIndex: 137,
    officeRent: 2500,
    spendPerPerson: 330000,
    policyRate: 0.04,
    bureaucracy: 1
  },
  start: { loan: 150000, loanYears: 5 },
  tax: {
    corporate: 0.22,
    special: { oil: 0.78, salmon: 0.47, hydro: 0.35 }, /* higher company tax for some industries: oil, salmon, hydro (power) */
    dividend: 0.3784,
    dividendShield: 0.036, /* tax-free return on paid-in capital */
    employer: { social: 0.141, pension: 0.02, injury: 0.005 },
    income: {
      flat: 0.22, /* flat tax on income after the allowance */
      allowance: 108550,
      wageDeduction: [0.46, 92000],
      brackets: [[226100, 0.017], [318300, 0.04], [725050, 0.137], [980100, 0.168], [1467200, 0.178]], /* [from, rate] on gross income */
      social: { employee: 0.076, selfEmployed: 0.108, floor: 99650, capShare: 0.25 }
    },
    wealth: { rate: 0.01, threshold: 1760000, companyShareCounted: 0.8 },
    inherit: { free: 0, rate: 0, biz: 0, bizFree: 0 } /* abolished in 2014; heirs take over the cost basis */
  },
  vat: { rates: { std: 0.25, food: 0.15, low: 0.12, zero: 0 }, threshold: 50000, filingMonths: 2, salesTax: false },
  companies: {
    forms: { ENK: 'Sole proprietorship', AS: 'Limited company (AS)', ENKs: 'ENK', ASs: 'AS' },
    capital: 30000,
    registrationFee: 6825,
    conversionFee: 9800
  },
  work: { leaveWeeks: 5 },
  authorities: {
    tax: 'Norwegian Tax Administration',
    cb: 'Central Bank of Norway',
    comp: 'Competition Authority',
    fin: 'Financial Supervisory Authority',
    lab: 'Labour Inspection Authority',
    food: 'Food Safety Authority',
    cons: 'Consumer Authority',
    data: 'Data Protection Authority',
    road: 'Public Roads Administration',
    health: 'Health Supervisory Authority',
    reg: 'Business Register',
    fish: 'Fisheries Directorate',
    tv: 'NRK and TV 2',
    idx: 'Oslo All-Share Index Fund',
    bond: 'Norwegian Bond Fund'
  },
  documents: {
    overrides: {
      salg: [
        null,
        null,
        null,
        null,
        null,
        'Shops may sell beer and cider only, up to 4.7%. Stronger drink is sold by the state monopoly.'
      ],
      org: [null, null, null, null, null, 'Gives you the organisation number.']
    }, /* [name, issuer, cost, weeks, renewal, note]; null keeps the standard value */
    notNeeded: [],
    fees: { org: 2181, mva: 0, hms: 0, gdpr: 0, skjenk: 6600, salg: 2130, drone: 0 },
    freeForSoleTraders: ['org']
  },
  banned: { casino: 'Gambling is a state monopoly. Private casinos are illegal.' },
  cities: [
    { id: 'oslo', name: 'Oslo', pop: 710, rent: 1, wage: 1, dem: 1.25, price: 1 },
    { id: 'bergen', name: 'Bergen', pop: 290, rent: 0.82, wage: 0.97, dem: 1, price: 0.97 },
    { id: 'trondheim', name: 'Trondheim', pop: 215, rent: 0.74, wage: 0.96, dem: 0.95, price: 0.96 },
    { id: 'stavanger', name: 'Stavanger', pop: 145, rent: 0.82, wage: 1.04, dem: 0.92, price: 1 },
    { id: 'kristiansand', name: 'Kristiansand', pop: 115, rent: 0.62, wage: 0.94, dem: 0.8, price: 0.94 },
    { id: 'tromso', name: 'Tromsø', pop: 78, rent: 0.62, wage: 1, dem: 0.7, price: 0.98 },
    { id: 'small', name: 'Small town', pop: 20, rent: 0.38, wage: 0.9, dem: 0.42, price: 0.9 }
  ],
  names: {
    first: [
      'Anders',
      'Kari',
      'Ola',
      'Ingrid',
      'Lars',
      'Silje',
      'Erik',
      'Nora',
      'Jonas',
      'Emma',
      'Henrik',
      'Sofie',
      'Magnus',
      'Ida',
      'Tobias',
      'Maja',
      'Kristian',
      'Julie',
      'Sander',
      'Thea',
      'Mohammed',
      'Aisha',
      'Piotr',
      'Anna',
      'Jakub',
      'Mia',
      'Oskar',
      'Linn',
      'Sindre',
      'Marte',
      'Even',
      'Hanna',
      'Per',
      'Randi',
      'Bjørn',
      'Tone',
      'Svein',
      'Eva',
      'Morten',
      'Lise',
      'Daniel',
      'Camilla',
      'Ahmed',
      'Sara',
      'Tomas',
      'Elise',
      'Håkon',
      'Vilde',
      'Mikkel',
      'Frida',
      'Ole',
      'Hanne',
      'Live'
    ],
    last: [
      'Hansen',
      'Johansen',
      'Olsen',
      'Larsen',
      'Andersen',
      'Pedersen',
      'Nilsen',
      'Kristiansen',
      'Jensen',
      'Karlsen',
      'Johnsen',
      'Pettersen',
      'Eriksen',
      'Berg',
      'Haugen',
      'Hagen',
      'Johannessen',
      'Andreassen',
      'Jacobsen',
      'Dahl',
      'Jørgensen',
      'Halvorsen',
      'Henriksen',
      'Lund',
      'Sørensen',
      'Moen',
      'Strand',
      'Bakken',
      'Solberg',
      'Lie',
      'Nygård',
      'Aas',
      'Brekke',
      'Holm',
      'Rød',
      'Vik',
      'Myhre',
      'Tveit',
      'Kowalski',
      'Khan'
    ],
    companyStart: [
      'Nordic',
      'Fjord',
      'Polar',
      'Viking',
      'Aurora',
      'Nord',
      'Bølge',
      'Kvist',
      'Fjell',
      'Solid',
      'Trygg',
      'Rask',
      'Klar',
      'Blå',
      'Gull',
      'Stål',
      'Skog',
      'Hav',
      'Lys',
      'Kyst',
      'Norsk',
      'Nordlys',
      'Vestland',
      'Trønder',
      'Midnatt',
      'Rein',
      'Furu',
      'Ask',
      'Lofoten',
      'Solvang',
      'Bergen'
    ],
    companyEnd: {
      svc: ['Partners', 'Studio', 'Service', 'Group', 'Consulting'],
      venue: ['House', 'Place', 'Kjøkken', 'Stuen', 'Corner'],
      retail: ['Butikk', 'Shop', 'Handel', 'Store'],
      project: ['Bygg', 'Prosjekt', 'Entreprenør', 'Group'],
      prod: ['Produksjon', 'Mat', 'Verk', 'Industri'],
      logi: ['Transport', 'Logistikk', 'Frakt', 'Linjer'],
      rent: ['Eiendom', 'Utleie', 'Bolig', 'Property'],
      fin: ['Capital', 'Finans', 'Forsikring', 'Invest'],
      energy: ['Energi', 'Kraft', 'Energy', 'Power']
    }
  },
  titles: ['General manager', 'Deputy manager', 'Shift leader', 'Regional manager', 'Group CEO'],
  tourism: { share: 0.22, origins: 'SE:25,DE:22,US:14,UK:14,NL:8,FR:7,ES:5,PL:5' },
  media: {
    prime: [
      'Prime-time TV on NRK and TV 2',
      'Everyone in Norway watches. Cheap by US standards, still very costly here.'
    ],
    bigAd: 'NRK and TV 2'
  },
  providerNames: [['Regnskap', 'Økonomi', 'Revisjon', 'Bokføring'], 'Advokatfirma', 'Forsikring', ' AS'],
  football: ['Eliteserien', 16, [15, 80]],
  flavour: {
    stocks: {
      NRDK: 'Nordkraft Energi ASA',
      FJSF: 'Fjordsalmon Group',
      HVBK: 'Havbank ASA',
      STVK: 'Stålverket Industrier',
      TLNR: 'Nordnett ASA',
      SKOG: 'Skogeierne ASA',
      RETL: 'Nordic Retail Holding',
      TECH: 'Polar Software ASA',
      SHIP: 'Kyst Rederi',
      EIEN: 'Byens Eiendom ASA'
    },
    startupWords: ['Nova', 'Fjord', 'Kvant', 'Lumen', 'Nordic', 'Bølge', 'Spire', 'Flux', 'Tind', 'Vekst', 'Ravn', 'Alva'],
    oilFields: ['Draugen', 'Snorre', 'Heidrun', 'Grane', 'Vale', 'Gina', 'Alvheim', 'Fram', 'Troll', 'Njord'],
    oilDiscoveries: ['Johan', 'Edvard', 'Krafla', 'Wisting', 'Sverdrup', 'Hanz', 'Balder', 'Ula']
  }
});


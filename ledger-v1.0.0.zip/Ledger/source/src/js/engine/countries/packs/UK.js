/* ---- src/countries/packs/UK.js ---- */
/* ===== Country: United Kingdom =====
   All money amounts in this file are in GBP. Rates are shares (0.25 = 25%).
   Figures are approximations for a game; check them against official sources before relying on them.
   The fields are described in src/countries/framework.js (COUNTRY_SCHEMA). */
defineCountry({
  code: 'UK',
  name: 'United Kingdom',
  flag: '🇬🇧',
  region: 'Europe', /* where the country sits in the start screen's list */
  currency: 'GBP',
  symbol: '£',
  fx: 13.5443038, /* game base units per 1 GBP */
  population: 68, /* millions */
  economy: {
    medianWage: 2900,
    priceIndex: 116,
    officeRent: 165,
    spendPerPerson: 25000,
    policyRate: 0.0375,
    bureaucracy: 0.8
  },
  start: { loan: 9500, loanYears: 5 },
  tax: {
    corporate: 0.25,
    special: { oil: 0.78 }, /* higher company tax for some industries: oil, salmon, hydro (power) */
    dividend: 0.3375,
    dividendShield: 0, /* tax-free return on paid-in capital */
    employer: { social: 0.15, pension: 0.03, injury: 0 },
    income: {
      flat: 0, /* flat tax on income after the allowance */
      allowance: 0,
      wageDeduction: null,
      brackets: [[0, 0], [12570, 0.2], [50270, 0.4], [125140, 0.45]], /* [from, rate] on gross income */
      social: { employee: 0.08, selfEmployed: 0.06, floor: 0, capShare: 0 }
    },
    wealth: null,
    inherit: { free: 325000, rate: 0.4, biz: 0.5, bizFree: 1000000 } /* nil-rate band; business relief 100% on the first 1 M, 50% above (from April 2026) */
  },
  vat: { rates: { std: 0.2, food: 0, low: 0.05, zero: 0 }, threshold: 90000, filingMonths: 3, salesTax: false },
  companies: {
    forms: { ENK: 'Sole trader', AS: 'Private limited company (Ltd)', ENKs: 'Sole trader', ASs: 'Ltd' },
    capital: 1,
    registrationFee: 50,
    conversionFee: 110
  },
  work: { leaveWeeks: 5.6 },
  authorities: {
    tax: 'HMRC',
    cb: 'Bank of England',
    comp: 'Competition and Markets Authority',
    fin: 'Financial Conduct Authority',
    lab: 'Health and Safety Executive',
    food: 'Food Standards Agency',
    cons: 'Trading Standards',
    data: 'Information Commissioner',
    road: 'Driver and Vehicle Licensing Agency',
    health: 'Care Quality Commission',
    reg: 'Companies House',
    fish: 'Marine Management Organisation',
    tv: 'ITV and the BBC',
    idx: 'FTSE All-Share Index Fund',
    bond: 'Gilt and Corporate Bond Fund'
  },
  documents: {
    overrides: { ce: ['UKCA marking', null, null, null, null, 'Needed to sell machinery and electrical products in Great Britain.'] }, /* [name, issuer, cost, weeks, renewal, note]; null keeps the standard value */
    notNeeded: [],
    fees: {
      org: 0,
      mva: 0,
      gdpr: 52,
      skjenk: 100,
      salg: 100,
      drone: 11.79,
      tobak: 0,
      goods: 658,
      tgodk: 0,
      bygg: 578,
      mattil: 0,
      helse: 196,
      hpr: 0,
      forsik: 28150,
      bank: 28150,
      vik: 0,
      event: 21
    }
  },
  banned: {},
  cities: [
    ['lon', 'London', 8900, 1.5, 1.2],
    ['man', 'Manchester', 550, 0.8, 0.98],
    ['bir', 'Birmingham', 1150, 0.78, 0.96],
    ['edi', 'Edinburgh', 530, 0.85, 1],
    ['bri', 'Bristol', 470, 0.9, 1.02],
    ['smalluk', 'Small town', 25, 0.4, 0.8]
  ],
  names: {
    first: [
      'Oliver',
      'Amelia',
      'George',
      'Olivia',
      'Harry',
      'Isla',
      'Jack',
      'Emily',
      'Noah',
      'Ava',
      'Charlie',
      'Mia',
      'Thomas',
      'Grace',
      'Charlotte',
      'Poppy',
      'William',
      'Callum',
      'Fiona'
    ],
    last: [
      'Smith',
      'Jones',
      'Taylor',
      'Brown',
      'Williams',
      'Wilson',
      'Davies',
      'Evans',
      'Thomas',
      'Johnson',
      'Roberts',
      'Walker',
      'Wright',
      'Hughes',
      'Patel',
      'Campbell'
    ],
    companyStart: [
      'Albion',
      'Crown',
      'Thames',
      'Northern',
      'Royal',
      'British',
      'Union',
      'Highland',
      'Bridge',
      'Oak',
      'English',
      'Cornish',
      'Kingfisher',
      'Heritage',
      'Cotswold',
      'Pennine',
      'Midland'
    ],
    companyEnd: ['Ltd', 'Group', 'Services', 'Trading', 'Construction', 'Partners']
  },
  titles: ['General manager', 'Deputy manager', 'Shift supervisor', 'Regional director', 'Chief executive'],
  tourism: { share: 0.2, origins: 'US:22,FR:12,DE:12,ES:10,NL:8,AU:8,CA:7,NO:5,SE:5,PL:5,JP:6' },
  media: {
    prime: ['Premier League and ITV prime time', 'The most expensive airtime in Britain.'],
    bigAd: 'the Premier League ad breaks'
  },
  providerNames: [['Accountants', 'Accounting', 'Audit'], 'Solicitors', 'Insurance', ' Ltd'],
  football: ['Premier League', 20, [550, 6500]]
});


/* ---- src/countries/packs/CH.js ---- */
/* ===== Country: Switzerland (round 56) =====
   All money amounts in this file are in CHF. Rates are shares (0.25 = 25%).
   Figures are approximations for a game; check them against official sources before relying on them.
   Median wage about CHF 6 800 a month (Federal Statistical Office), prices about 70% above the EU average (Eurostat),
   company tax about 12-21% depending on the canton, VAT 8.1% (2.6% on food, 3.8% on lodging), no inheritance tax for
   children in most cantons, a cantonal wealth tax.
   The fields are described in src/countries/framework.js (COUNTRY_SCHEMA). */
defineCountry({
  code: 'CH',
  name: 'Switzerland',
  flag: '🇨🇭',
  region: 'Europe', /* where the country sits in the start screen's list */
  currency: 'CHF',
  symbol: 'CHF',
  fx: 13.4, /* game base units per 1 CHF */
  population: 9, /* millions */
  economy: {
    medianWage: 6800,
    priceIndex: 170,
    officeRent: 280,
    spendPerPerson: 46000,
    policyRate: 0,
    bureaucracy: 0.8
  },
  start: { loan: 15000, loanYears: 5 },
  tax: {
    corporate: 0.147,
    special: {}, /* higher company tax for some industries: oil, salmon, hydro (power) */
    dividend: 0.2, /* dividends from a qualifying stake are taxed at 50-70% of the income rate */
    dividendShield: 0,
    employer: { social: 0.064, pension: 0.07, injury: 0.01 }, /* AHV/IV/EO and unemployment insurance; BVG pension; accident insurance */
    income: {
      flat: 0,
      allowance: 0,
      wageDeduction: [0.03, 4000],
      brackets: [[0, 0], [18000, 0.05], [40000, 0.12], [80000, 0.2], [150000, 0.28], [300000, 0.34]], /* federal, cantonal and municipal together, roughly Zurich */
      social: { employee: 0.064, selfEmployed: 0.1, floor: 9800, capShare: 0 }
    },
    wealth: { rate: 0.003, threshold: 80000, companyShareCounted: 1 }, /* cantonal wealth tax, about 0.1-1% */
    inherit: { free: 0, rate: 0, biz: 0, bizFree: 0 } /* children are exempt in almost every canton */
  },
  vat: { rates: { std: 0.081, food: 0.026, low: 0.038, zero: 0 }, threshold: 100000, filingMonths: 3, salesTax: false },
  companies: {
    forms: { ENK: 'Sole proprietorship', AS: 'Limited liability company (GmbH)', ENKs: 'Einzelfirma', ASs: 'GmbH' },
    capital: 20000,
    registrationFee: 1800,
    conversionFee: 2500
  },
  work: { leaveWeeks: 4 },
  authorities: {
    tax: 'Federal Tax Administration',
    cb: 'Swiss National Bank',
    comp: 'Competition Commission',
    fin: 'FINMA',
    lab: 'State Secretariat for Economic Affairs',
    food: 'Food Safety and Veterinary Office',
    cons: 'Consumer Affairs Bureau',
    data: 'Data Protection Commissioner',
    road: 'Federal Roads Office',
    health: 'Federal Office of Public Health',
    reg: 'Commercial Register',
    fish: 'Federal Office for the Environment',
    tv: 'SRF and RTS',
    idx: 'SMI Index Fund',
    bond: 'Swiss Confederation Bond Fund'
  },
  documents: { overrides: {}, notNeeded: [], fees: { org: 600, mva: 0, gdpr: 0, mattil: 0 } },
  banned: { salmon: 'No sea pens in a landlocked country.', oilgas: 'There is no oil or gas production in Switzerland.' },
  cities: [
    ['zrh', 'Zurich', 430, 1.35, 1.12],
    ['gva', 'Geneva', 205, 1.3, 1.1],
    ['bsl', 'Basel', 175, 1.05, 1.05],
    ['brn', 'Bern', 145, 1, 1.02],
    ['lsn', 'Lausanne', 140, 1.05, 1],
    ['zug', 'Zug', 31, 1.3, 1.15],
    ['smallch', 'Mountain village', 4, 0.7, 0.9]
  ],
  names: {
    first: ['Noah', 'Mia', 'Liam', 'Emma', 'Luca', 'Sofia', 'Leon', 'Lina', 'Matteo', 'Elena', 'Lukas', 'Laura', 'Jonas', 'Anna', 'Nico', 'Lea', 'Samuel', 'Chloé', 'Julien', 'Camille', 'Marco', 'Giulia', 'Daniel', 'Sara', 'Thomas', 'Nina'],
    last: ['Müller', 'Meier', 'Schmid', 'Keller', 'Weber', 'Huber', 'Schneider', 'Meyer', 'Steiner', 'Fischer', 'Gerber', 'Brunner', 'Baumann', 'Frei', 'Zimmermann', 'Favre', 'Rochat', 'Bianchi', 'Rossi', 'Moser'],
    companyStart: ['Helvetia', 'Alpen', 'Zürcher', 'Genève', 'Berner', 'Rhein', 'Edelweiss', 'Matterhorn', 'Säntis', 'Jura', 'Léman', 'Gotthard', 'Swiss', 'Alpine', 'Ticino', 'Engadin', 'Pilatus', 'Rigi', 'Aare', 'Basler'],
    companyEnd: ['AG', 'GmbH', 'Partner', 'Services', 'Bau', 'Holding']
  },
  titles: ['Store manager', 'Deputy manager', 'Team leader', 'Regional manager', 'Chief executive (CEO)'],
  tourism: { share: 0.5, origins: 'DE:25,US:12,UK:9,FR:8,JP:4,NL:5,ES:4,KR:3,AU:3,CA:3,SE:3,NO:3' },
  media: {
    prime: ['The Lauberhorn ski race broadcast', 'The whole country watches the downhill in January, in three languages.'],
    bigAd: 'the ski race on SRF'
  },
  providerNames: [['Treuhand', 'Fiduciaire', 'Revision'], 'Rechtsanwälte', 'Versicherungen', ' AG'],
  football: ['Swiss Super League', 12, [15, 220]]
});

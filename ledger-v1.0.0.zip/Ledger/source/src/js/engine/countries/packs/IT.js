/* ---- src/countries/packs/IT.js ---- */
/* ===== Country: Italy (round 57) =====
   All money amounts in this file are in EUR. Rates are shares (0.25 = 25%).
   Figures are approximations for a game; check them against official sources before relying on them.
   Median gross wage about EUR 2 300 a month over 13 payments (ISTAT), prices about the EU average (Eurostat), company
   tax IRES 24% plus regional IRAP 3.9% (taxing.it), VAT 22% (10% restaurants and hotels, 4% basic food), employer
   INPS contributions about 30% plus TFR severance accrual 6.9%, IRPEF 23/33/43% from 2026 plus regional and municipal
   surcharges, inheritance by children 4% above EUR 1 M each, family businesses passed on and kept five years exempt.
   The fields are described in src/countries/framework.js (COUNTRY_SCHEMA). */
defineCountry({
  code: 'IT',
  name: 'Italy',
  flag: '🇮🇹',
  region: 'Europe', /* where the country sits in the start screen's list */
  currency: 'EUR',
  symbol: '€',
  fx: 11.6304348, /* game base units per 1 EUR */
  population: 58.9, /* millions */
  economy: {
    medianWage: 2300,
    priceIndex: 101,
    officeRent: 170,
    spendPerPerson: 21000,
    policyRate: 0.02,
    bureaucracy: 1.45
  },
  start: { loan: 12000, loanYears: 5 },
  tax: {
    corporate: 0.279, /* IRES 24% + IRAP 3.9% */
    special: {}, /* higher company tax for some industries: oil, salmon, hydro (power) */
    dividend: 0.26,
    dividendShield: 0,
    employer: { social: 0.3, pension: 0.069, injury: 0.01 }, /* INPS; TFR severance accrual; INAIL */
    income: {
      flat: 0,
      allowance: 0,
      wageDeduction: null,
      brackets: [[0, 0], [8500, 0.25], [28000, 0.35], [50000, 0.45]], /* IRPEF 23/33/43% with the regional and municipal surcharges; no-tax area about EUR 8 500 */
      social: { employee: 0.0919, selfEmployed: 0.24, floor: 0, capShare: 0 }
    },
    wealth: null,
    inherit: { free: 1000000, rate: 0.04, biz: 1, bizFree: 0 } /* 4% above EUR 1 M per child; a family business kept 5 years is exempt */
  },
  vat: { rates: { std: 0.22, food: 0.1, low: 0.04, zero: 0 }, threshold: 85000, filingMonths: 3, salesTax: false }, /* under EUR 85 000 the flat-rate regime charges no VAT */
  companies: {
    forms: { ENK: 'Sole proprietorship (ditta individuale)', AS: 'Limited company (SRL)', ENKs: 'Ditta individuale', ASs: 'SRL' },
    capital: 10000,
    registrationFee: 2000, /* notary deed, registration tax and chamber of commerce fees */
    conversionFee: 2500
  },
  work: { leaveWeeks: 4 },
  authorities: {
    tax: 'Revenue Agency (Agenzia delle Entrate)',
    cb: 'Bank of Italy and the ECB',
    comp: 'Competition Authority (AGCM)',
    fin: 'CONSOB',
    lab: 'National Labour Inspectorate',
    food: 'NAS and the local health authority',
    cons: 'Competition Authority (AGCM)',
    data: 'Garante Privacy',
    road: 'Motorizzazione Civile',
    health: 'Ministry of Health',
    reg: 'Business Register (Camera di Commercio)',
    fish: 'Ministry of Agriculture',
    tv: 'RAI and Mediaset',
    idx: 'FTSE MIB Index Fund',
    bond: 'BTP Bond Fund'
  },
  documents: { overrides: {}, notNeeded: [], fees: { org: 300, mva: 0, gdpr: 0, mattil: 0 } },
  banned: { casino: 'Only four municipal casinos hold a licence (Sanremo, Venice, Saint-Vincent, Campione).', salmon: 'No salmon farming in the Mediterranean.' },
  cities: [
    ['rom', 'Rome', 2750, 1.3, 1.05],
    ['mil', 'Milan', 1370, 1.6, 1.22],
    ['nap', 'Naples', 910, 0.85, 0.85],
    ['tor', 'Turin', 840, 1, 1],
    ['pal', 'Palermo', 630, 0.75, 0.82],
    ['bol', 'Bologna', 390, 1.15, 1.06],
    ['flr', 'Florence', 360, 1.25, 1],
    ['smallit', 'Small town', 15, 0.55, 0.85]
  ],
  names: {
    first: ['Leonardo', 'Sofia', 'Francesco', 'Giulia', 'Alessandro', 'Aurora', 'Lorenzo', 'Ginevra', 'Mattia', 'Alice', 'Andrea', 'Beatrice', 'Gabriele', 'Martina', 'Matteo', 'Chiara', 'Tommaso', 'Francesca', 'Riccardo', 'Elena', 'Marco', 'Sara', 'Luca', 'Valentina', 'Giuseppe', 'Anna'],
    last: ['Rossi', 'Russo', 'Ferrari', 'Esposito', 'Bianchi', 'Romano', 'Colombo', 'Ricci', 'Marino', 'Greco', 'Bruno', 'Gallo', 'Conti', 'De Luca', 'Mancini', 'Costa', 'Giordano', 'Rizzo', 'Lombardi', 'Moretti'],
    companyStart: ['Italia', 'Tricolore', 'Romana', 'Milanese', 'Toscana', 'Adriatica', 'Tirrena', 'Padana', 'Etrusca', 'Lombarda', 'Siciliana', 'Veneta', 'Ligure', 'Sole', 'Aurora', 'Vesuvio', 'Dolomiti', 'Appennino', 'Laguna', 'Fiorentina'],
    companyEnd: ['S.r.l.', 'S.p.A.', 'Servizi', 'Costruzioni', 'Commerciale', 'Group']
  },
  titles: ['Store manager', 'Deputy manager', 'Shift supervisor', 'Area manager', 'Managing director (amministratore delegato)'],
  tourism: { share: 0.5, origins: 'DE:26,US:12,FR:9,UK:8,CH:6,NL:5,ES:5,PL:4,AU:3,JP:3' },
  media: {
    prime: ['The Sanremo Music Festival', 'Five nights in February when most of the country watches the same show.'],
    bigAd: 'an ad during Sanremo'
  },
  providerNames: [['Studio commercialista', 'Consulenze', 'Servizi contabili'], 'Studio legale', 'Assicurazioni', ' S.r.l.'],
  football: ['Serie A', 20, [80, 1400]]
});

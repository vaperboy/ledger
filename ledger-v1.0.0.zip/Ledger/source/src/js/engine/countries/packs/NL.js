/* ---- src/countries/packs/NL.js ---- */
/* ===== Country: Netherlands =====
   All money amounts in this file are in EUR. Rates are shares (0.25 = 25%).
   Figures are approximations for a game; check them against official sources before relying on them.
   The fields are described in src/countries/framework.js (COUNTRY_SCHEMA). */
defineCountry({
  code: 'NL',
  name: 'Netherlands',
  flag: '🇳🇱',
  region: 'Europe', /* where the country sits in the start screen's list */
  currency: 'EUR',
  symbol: '€',
  fx: 11.6304348, /* game base units per 1 EUR */
  population: 17.9, /* millions */
  economy: {
    medianWage: 3600,
    priceIndex: 116,
    officeRent: 180,
    spendPerPerson: 28000,
    policyRate: 0.02,
    bureaucracy: 1
  },
  start: { loan: 12000, loanYears: 5 },
  tax: {
    corporate: 0.258,
    special: {}, /* higher company tax for some industries: oil, salmon, hydro (power) */
    dividend: 0.31,
    dividendShield: 0, /* tax-free return on paid-in capital */
    employer: { social: 0.18, pension: 0.05, injury: 0 },
    income: {
      flat: 0, /* flat tax on income after the allowance */
      allowance: 0,
      wageDeduction: null,
      brackets: [[0, 0.3582], [38400, 0.3748], [76800, 0.495]], /* [from, rate] on gross income */
      social: { employee: 0, selfEmployed: 0, floor: 0, capShare: 0 }
    },
    wealth: null,
    inherit: { free: 25000, rate: 0.2, biz: 0.83, bizFree: 1500000 } /* BOR: business 100% exempt up to about 1.5 M, 83% above */
  },
  vat: { rates: { std: 0.21, food: 0.09, low: 0.09, zero: 0 }, threshold: 20000, filingMonths: 3, salesTax: false },
  companies: {
    forms: { ENK: 'Sole proprietorship', AS: 'Private company (BV)', ENKs: 'Eenmanszaak', ASs: 'BV' },
    capital: 1,
    registrationFee: 85,
    conversionFee: 750
  },
  work: { leaveWeeks: 4 },
  authorities: {
    tax: 'Tax Administration',
    cb: 'Dutch central bank and the ECB',
    comp: 'Authority for Consumers and Markets',
    fin: 'Authority for the Financial Markets',
    lab: 'Labour Inspectorate',
    food: 'Food and Consumer Product Safety Authority',
    cons: 'Authority for Consumers and Markets',
    data: 'Data Protection Authority',
    road: 'Vehicle Authority',
    health: 'Health and Youth Care Inspectorate',
    reg: 'Chamber of Commerce',
    fish: 'Food and Consumer Product Safety Authority',
    tv: 'NPO and RTL',
    idx: 'AEX All-Share Index Fund',
    bond: 'Dutch Bond Fund'
  },
  documents: {
    overrides: {}, /* [name, issuer, cost, weeks, renewal, note]; null keeps the standard value */
    notNeeded: [],
    fees: { org: 82.25, mva: 0, gdpr: 0, drone: 0, tgodk: 0, mattil: 0, megler: 0 }
  },
  banned: { casino: 'A single state-linked operator holds the casino licence.', salmon: 'No sea-pen licences.' },
  cities: [
    ['ams', 'Amsterdam', 930, 1.4, 1.15],
    ['rtm', 'Rotterdam', 660, 0.95, 1.02],
    ['hag', 'The Hague', 560, 1, 1.05],
    ['utr', 'Utrecht', 360, 1.05, 1.05],
    ['ein', 'Eindhoven', 240, 0.85, 1],
    ['smallnl', 'Small town', 25, 0.5, 0.85]
  ],
  names: {
    first: [
      'Daan',
      'Emma',
      'Sem',
      'Julia',
      'Lucas',
      'Sophie',
      'Levi',
      'Tess',
      'Finn',
      'Anna',
      'Bram',
      'Lotte',
      'Jesse',
      'Noor',
      'Sanne',
      'Thijs',
      'Femke',
      'Ruben',
      'Anouk',
      'Joost',
      'Eva',
      'Sven',
      'Iris',
      'Pieter',
      'Marloes'
    ],
    last: [
      'de Jong',
      'Jansen',
      'de Vries',
      'van den Berg',
      'van Dijk',
      'Bakker',
      'Janssen',
      'Visser',
      'Smit',
      'Meijer',
      'de Boer',
      'Mulder',
      'de Groot',
      'Bos',
      'Vos',
      'Peters'
    ],
    companyStart: [
      'Holland',
      'Delta',
      'Oranje',
      'Noord',
      'Tulp',
      'Rijn',
      'Zeeuwse',
      'Hollandse',
      'Maas',
      'Dijk',
      'Nederlandse',
      'Amsterdamse',
      'Rotterdamse',
      'Noordzee',
      'Gouden',
      'Groene',
      'Blauwe',
      'Polder',
      'Duin',
      'Vlaamse'
    ],
    companyEnd: ['BV', 'Groep', 'Diensten', 'Handel', 'Bouw', 'Advies']
  },
  titles: ['Director', 'Deputy director', 'Team leader', 'Regional director', 'Chief executive'],
  tourism: { share: 0.25, origins: 'DE:30,UK:15,FR:10,US:10,ES:8,PL:7,SE:5,NO:5,JP:5,AU:5' },
  media: {
    prime: ['Prime time on NPO and King’s Day events', 'Reaches nearly every Dutch household.'],
    bigAd: 'prime-time TV'
  },
  providerNames: [['Accountants', 'Administratie', 'Audit'], 'Advocaten', 'Verzekeringen', ' B.V.'],
  football: ['Eredivisie', 18, [30, 450]]
});


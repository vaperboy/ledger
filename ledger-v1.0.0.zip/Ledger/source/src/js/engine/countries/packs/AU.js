/* ---- src/countries/packs/AU.js ---- */
/* ===== Country: Australia =====
   All money amounts in this file are in AUD. Rates are shares (0.25 = 25%).
   Figures are approximations for a game; check them against official sources before relying on them.
   The fields are described in src/countries/framework.js (COUNTRY_SCHEMA). */
defineCountry({
  code: 'AU',
  name: 'Australia',
  flag: '🇦🇺',
  region: 'Asia and Pacific', /* where the country sits in the start screen's list */
  currency: 'AUD',
  symbol: 'A$',
  fx: 7.1333333, /* game base units per 1 AUD */
  population: 27, /* millions */
  economy: {
    medianWage: 7400,
    priceIndex: 125,
    officeRent: 345,
    spendPerPerson: 55000,
    policyRate: 0.036,
    bureaucracy: 1
  },
  start: { loan: 20000, loanYears: 5 },
  tax: {
    corporate: 0.25,
    special: {}, /* higher company tax for some industries: oil, salmon, hydro (power) */
    dividend: 0.2,
    dividendShield: 0, /* tax-free return on paid-in capital */
    employer: { social: 0.05, pension: 0.12, injury: 0.01 },
    income: {
      flat: 0, /* flat tax on income after the allowance */
      allowance: 0,
      wageDeduction: null,
      brackets: [[0, 0], [18200, 0.16], [45000, 0.3], [135000, 0.37], [190000, 0.45]], /* [from, rate] on gross income */
      social: { employee: 0.02, selfEmployed: 0.02, floor: 0, capShare: 0 }
    },
    wealth: null,
    inherit: { free: 0, rate: 0, biz: 0, bizFree: 0 } /* no inheritance tax */
  },
  vat: {
    rates: { std: 0.1, food: 0, low: 0.1, zero: 0 },
    threshold: 75000,
    filingMonths: 3,
    salesTax: false,
    registrationName: 'GST registration'
  },
  companies: {
    forms: { ENK: 'Sole trader', AS: 'Proprietary limited (Pty Ltd)', ENKs: 'Sole trader', ASs: 'Pty Ltd' },
    capital: 1,
    registrationFee: 650,
    conversionFee: 850
  },
  work: { leaveWeeks: 4 },
  authorities: {
    tax: 'the ATO',
    cb: 'Reserve Bank of Australia',
    comp: 'Competition and Consumer Commission',
    fin: 'Securities and Investments Commission',
    lab: 'Fair Work and SafeWork',
    food: 'Food Standards Australia New Zealand',
    cons: 'Competition and Consumer Commission',
    data: 'Information Commissioner',
    road: 'State Roads Authority',
    health: 'Health Practitioner Regulation Agency',
    reg: 'Australian Business Register',
    fish: 'Fisheries Management Authority',
    tv: 'Channel 7 and the ABC',
    idx: 'ASX 200 Index Fund',
    bond: 'Australian Bond Fund'
  },
  documents: {
    overrides: {
      ce: ['Compliance mark (RCM)', null, null, null, null, 'Needed to sell electrical products.'],
      gdpr: ['Privacy policy', null, null, null, null, 'Needed when you hold customer data.']
    }, /* [name, issuer, cost, weeks, renewal, note]; null keeps the standard value */
    notNeeded: ['eh'],
    fees: { org: 47, mva: 0, skjenk: 965, salg: 2760, tgodk: 883, mattil: 0, brygg: 0, elvirk: 403, vvs: 403 }
  },
  banned: {},
  cities: [
    ['syd', 'Sydney', 5300, 1.4, 1.15],
    ['mel', 'Melbourne', 5100, 1.2, 1.1],
    ['bne', 'Brisbane', 2600, 1, 1.05],
    ['per', 'Perth', 2200, 0.95, 1.08],
    ['ade', 'Adelaide', 1400, 0.85, 1],
    ['smallau', 'Small town', 20, 0.4, 0.8]
  ],
  names: {
    first: [
      'Oliver',
      'Charlotte',
      'William',
      'Olivia',
      'Jack',
      'Amelia',
      'Noah',
      'Isla',
      'Thomas',
      'Mia',
      'Lachlan',
      'Matilda',
      'Henry',
      'Ruby',
      'Cooper',
      'Hunter',
      'Chloe',
      'Mitchell',
      'Georgia'
    ],
    last: [
      'Smith',
      'Jones',
      'Williams',
      'Brown',
      'Wilson',
      'Taylor',
      'Nguyen',
      'Johnson',
      'Martin',
      'White',
      'Thompson',
      'Kelly',
      'Anderson',
      'Walker',
      'Ryan',
      'Campbell',
      'Murphy'
    ],
    companyStart: [
      'Southern',
      'Outback',
      'Coastal',
      'Aussie',
      'Harbour',
      'Bluegum',
      'Red Centre',
      'Golden Wattle',
      'Pacific',
      'Kookaburra',
      'Australian',
      'Southern Cross',
      'Gum Tree',
      'Murray',
      'Golden',
      'Bluestone',
      'Wattle',
      'Reef',
      'Sunburnt'
    ],
    companyEnd: ['Pty Ltd', 'Group', 'Services', 'Trading', 'Building', 'Partners']
  },
  titles: ['General manager', 'Assistant manager', 'Shift supervisor', 'Regional manager', 'Chief executive officer'],
  tourism: { share: 0.08, origins: 'JP:15,US:15,UK:15,KR:10,DE:10,FR:10,CA:10,SE:5,NL:5,ES:5' },
  media: {
    prime: ['AFL Grand Final and Melbourne Cup', 'Australia’s biggest sporting days.'],
    bigAd: 'the AFL grand final ads'
  },
  providerNames: [['Accountants', 'Accounting', 'Tax'], 'Lawyers', 'Insurance', ' Pty Ltd'],
  football: ['A-League Men', 12, [8, 40]]
});


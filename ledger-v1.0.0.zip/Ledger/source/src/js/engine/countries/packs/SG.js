/* ---- src/countries/packs/SG.js ---- */
/* ===== Country: Singapore (round 57) =====
   All money amounts in this file are in SGD. Rates are shares (0.25 = 25%).
   Figures are approximations for a game; check them against official sources before relying on them.
   Median gross wage about SGD 5 300 a month before the employer's CPF (Ministry of Manpower), prices about 20% above
   the EU average, company tax 17% (lower in practice with the partial exemption), GST 9% with no reduced rates,
   no tax on dividends (one-tier system), CPF 17% from the employer and 20% from the employee up to the SGD 8 000 ordinary
   wage ceiling in 2026 (Endowus), resident income tax from 0% to 24%, no inheritance tax since 2008.
   The fields are described in src/countries/framework.js (COUNTRY_SCHEMA). */
defineCountry({
  code: 'SG',
  name: 'Singapore',
  flag: '🇸🇬',
  region: 'Asia and Pacific', /* where the country sits in the start screen's list */
  currency: 'SGD',
  symbol: 'S$',
  fx: 8.29, /* game base units per 1 SGD */
  population: 6, /* millions */
  economy: {
    medianWage: 5300,
    priceIndex: 120,
    officeRent: 800,
    spendPerPerson: 40000,
    policyRate: 0.015,
    bureaucracy: 0.5
  },
  start: { loan: 15000, loanYears: 5 },
  tax: {
    corporate: 0.17,
    special: {}, /* higher company tax for some industries: oil, salmon, hydro (power) */
    dividend: 0, /* one-tier: dividends are tax-free for the shareholder */
    dividendShield: 0,
    employer: { social: 0.17, pension: 0, injury: 0.005 }, /* CPF for citizens and PRs; work injury insurance */
    income: {
      flat: 0,
      allowance: 0,
      wageDeduction: null,
      brackets: [[0, 0], [20000, 0.02], [30000, 0.035], [40000, 0.07], [80000, 0.115], [120000, 0.15], [160000, 0.18], [200000, 0.19], [320000, 0.22], [500000, 0.23], [1000000, 0.24]],
      social: { employee: 0.2, selfEmployed: 0.105, floor: 6000, capShare: 0 } /* CPF; MediSave for the self-employed */
    },
    wealth: null,
    inherit: { free: 0, rate: 0, biz: 0, bizFree: 0 } /* estate duty abolished in 2008 */
  },
  vat: { rates: { std: 0.09, food: 0.09, low: 0.09, zero: 0 }, threshold: 1000000, filingMonths: 3, salesTax: false, registrationName: 'GST registration' },
  companies: {
    forms: { ENK: 'Sole proprietorship', AS: 'Private limited company (Pte. Ltd.)', ENKs: 'Sole proprietorship', ASs: 'Pte. Ltd.' },
    capital: 1,
    registrationFee: 315,
    conversionFee: 1000
  },
  work: { leaveWeeks: 2 },
  authorities: {
    tax: 'Inland Revenue Authority of Singapore (IRAS)',
    cb: 'Monetary Authority of Singapore',
    comp: 'Competition and Consumer Commission (CCCS)',
    fin: 'Monetary Authority of Singapore',
    lab: 'Ministry of Manpower',
    food: 'Singapore Food Agency',
    cons: 'Competition and Consumer Commission (CCCS)',
    data: 'Personal Data Protection Commission',
    road: 'Land Transport Authority',
    health: 'Ministry of Health',
    reg: 'ACRA',
    fish: 'Singapore Food Agency',
    tv: 'Mediacorp',
    idx: 'Straits Times Index Fund',
    bond: 'Singapore Government Securities Fund'
  },
  documents: { overrides: {}, notNeeded: [], fees: { org: 315, mva: 0, gdpr: 0, mattil: 0 } },
  banned: { casino: 'Only the two integrated resorts hold casino licences.', oilgas: 'Singapore refines oil but has no fields of its own.', salmon: 'There is no sea space for salmon pens.' },
  cities: [
    ['sgc', 'Central (CBD and Orchard)', 940, 1.45, 1.12],
    ['sgw', 'Jurong', 400, 0.8, 0.95],
    ['sge', 'Tampines', 270, 0.9, 0.96],
    ['sgn', 'Woodlands', 255, 0.75, 0.92],
    ['sgne', 'Punggol', 190, 0.85, 0.95],
    ['sgs', 'Sentosa', 6, 1.6, 1]
  ],
  names: {
    first: ['Ethan', 'Chloe', 'Ryan', 'Sophia', 'Jayden', 'Emma', 'Lucas', 'Isabelle', 'Wei Jie', 'Hui Min', 'Jun Hao', 'Xin Yi', 'Muhammad', 'Nur Aisyah', 'Arjun', 'Priya', 'Marcus', 'Rachel', 'Daniel', 'Shi Ting', 'Kai', 'Mei Ling', 'Haziq', 'Siti', 'Ravi', 'Kavya'],
    last: ['Tan', 'Lim', 'Lee', 'Ng', 'Ong', 'Wong', 'Goh', 'Chua', 'Chan', 'Koh', 'Teo', 'Ang', 'Yeo', 'Tay', 'Ho', 'Low', 'Rahman', 'Ismail', 'Kumar', 'Pillai'],
    companyStart: ['Lion City', 'Merlion', 'Straits', 'Orchard', 'Marina', 'Temasek', 'Raffles', 'Jurong', 'Changi', 'Sentosa', 'Kallang', 'Bukit', 'Pasir', 'Harbour', 'Garden', 'Lucky', 'Golden', 'Prosperity', 'Asia', 'Pacific'],
    companyEnd: ['Pte. Ltd.', 'Holdings', 'Services', 'Engineering', 'Trading', 'Group']
  },
  titles: ['Outlet manager', 'Assistant manager', 'Shift supervisor', 'Regional manager', 'Chief executive officer'],
  tourism: { share: 0.4, origins: 'AU:12,JP:9,KR:7,US:7,UK:6,DE:3,FR:2,MX:1' },
  media: {
    prime: ['The National Day Parade', 'On 9 August the whole island watches the parade and the fireworks.'],
    bigAd: 'an ad during the National Day Parade broadcast'
  },
  providerNames: [['Accounting', 'Corporate Services', 'Bookkeeping'], 'LLP', 'Insurance', ' Pte. Ltd.'],
  football: ['Singapore Premier League', 8, [1, 6]]
});

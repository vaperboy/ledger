/* ---- src/countries/packs/DE.js ---- */
/* ===== Country: Germany =====
   All money amounts in this file are in EUR. Rates are shares (0.25 = 25%).
   Figures are approximations for a game; check them against official sources before relying on them.
   The fields are described in src/countries/framework.js (COUNTRY_SCHEMA). */
defineCountry({
  code: 'DE',
  name: 'Germany',
  flag: '🇩🇪',
  region: 'Europe', /* where the country sits in the start screen's list */
  currency: 'EUR',
  symbol: '€',
  fx: 11.6304348, /* game base units per 1 EUR */
  population: 84, /* millions */
  economy: {
    medianWage: 4100,
    priceIndex: 107,
    officeRent: 160,
    spendPerPerson: 27000,
    policyRate: 0.02,
    bureaucracy: 1.3
  },
  start: { loan: 11000, loanYears: 5 },
  tax: {
    corporate: 0.3,
    special: {}, /* higher company tax for some industries: oil, salmon, hydro (power) */
    dividend: 0.26375,
    dividendShield: 0, /* tax-free return on paid-in capital */
    employer: { social: 0.21, pension: 0, injury: 0.01 },
    income: {
      flat: 0, /* flat tax on income after the allowance */
      allowance: 0,
      wageDeduction: null,
      brackets: [[0, 0], [12100, 0.3], [68500, 0.42], [278000, 0.45]], /* [from, rate] on gross income */
      social: { employee: 0.205, selfEmployed: 0.2, floor: 0, capShare: 0 }
    },
    wealth: null,
    inherit: { free: 400000, rate: 0.23, biz: 0.85, bizFree: 0 } /* class I, top rates 19-30%; 85% relief on business assets kept going */
  },
  vat: { rates: { std: 0.19, food: 0.07, low: 0.07, zero: 0 }, threshold: 25000, filingMonths: 1, salesTax: false },
  companies: {
    forms: { ENK: 'Sole proprietorship', AS: 'Limited company (GmbH)', ENKs: 'EU', ASs: 'GmbH' },
    capital: 25000,
    registrationFee: 700,
    conversionFee: 2100
  },
  work: { leaveWeeks: 4 },
  authorities: {
    tax: 'Tax Office',
    cb: 'German central bank and the ECB',
    comp: 'Federal Cartel Office',
    fin: 'Federal Financial Supervisory Authority',
    lab: 'Trade Supervisory Office',
    food: 'Food Inspection Authority',
    cons: 'Consumer Advice Centre',
    data: 'Data Protection Authority',
    road: 'Federal Motor Transport Authority',
    health: 'Public Health Office',
    reg: 'Commercial Register',
    fish: 'Fisheries Authority',
    tv: 'ARD and ZDF',
    idx: 'DAX All-Share Index Fund',
    bond: 'German Bond Fund'
  },
  documents: {
    overrides: {}, /* [name, issuer, cost, weeks, renewal, note]; null keeps the standard value */
    notNeeded: [],
    fees: { org: 30, mva: 0, drone: 20 }
  },
  banned: { oilgas: 'No new licensing rounds.', salmon: 'No licences for sea pens.' },
  cities: [
    ['ber', 'Berlin', 3700, 1.15, 1.05],
    ['ham', 'Hamburg', 1900, 1.1, 1.08],
    ['muc', 'Munich', 1500, 1.4, 1.15],
    ['col', 'Cologne', 1100, 1, 1.02],
    ['fra', 'Frankfurt', 760, 1.15, 1.12],
    ['smallde', 'Small town', 25, 0.45, 0.82]
  ],
  names: {
    first: [
      'Lukas',
      'Anna',
      'Jonas',
      'Laura',
      'Felix',
      'Lea',
      'Max',
      'Marie',
      'Paul',
      'Sophie',
      'Tim',
      'Hannah',
      'Jan',
      'Lena',
      'Maximilian',
      'Tobias',
      'Katharina',
      'Stefan',
      'Julia',
      'Matthias',
      'Anke'
    ],
    last: [
      'Müller',
      'Schmidt',
      'Schneider',
      'Fischer',
      'Weber',
      'Meyer',
      'Wagner',
      'Becker',
      'Schulz',
      'Hoffmann',
      'Koch',
      'Richter',
      'Klein',
      'Wolf'
    ],
    companyStart: [
      'Deutsche',
      'Rhein',
      'Nord',
      'Alpen',
      'Berliner',
      'Hansa',
      'Königs',
      'Eisen',
      'Blau',
      'Neue',
      'Bayerische',
      'Süd',
      'Hanse',
      'Schwarzwald',
      'Elbe',
      'Goldene',
      'Grüne',
      'Blaue',
      'Erste'
    ],
    companyEnd: ['GmbH', 'Gruppe', 'Dienste', 'Handel', 'Bau', 'Werke']
  },
  titles: ['Managing director', 'Deputy head', 'Team leader', 'Regional head', 'Chairman of the board'],
  tourism: { share: 0.15, origins: 'NL:20,PL:12,US:12,UK:12,FR:10,ES:8,SE:6,NO:5' },
  media: {
    prime: ['Bundesliga and ARD prime time', 'Massive audience across a big country.'],
    bigAd: 'the Bundesliga ad breaks'
  },
  providerNames: [['Steuerberatung', 'Buchhaltung', 'Wirtschaftsprüfung'], 'Rechtsanwälte', 'Versicherung', ' GmbH'],
  football: ['Bundesliga', 18, [150, 4800]]
});


/* ---- src/countries/packs/CA.js ---- */
/* ===== Country: Canada =====
   All money amounts in this file are in CAD. Rates are shares (0.25 = 25%).
   Figures are approximations for a game; check them against official sources before relying on them.
   The fields are described in src/countries/framework.js (COUNTRY_SCHEMA). */
defineCountry({
  code: 'CA',
  name: 'Canada',
  flag: '🇨🇦',
  region: 'Americas', /* where the country sits in the start screen's list */
  currency: 'CAD',
  symbol: 'C$',
  fx: 7.6428571, /* game base units per 1 CAD */
  population: 40, /* millions */
  economy: {
    medianWage: 5300,
    priceIndex: 115,
    officeRent: 280,
    spendPerPerson: 45000,
    policyRate: 0.0225,
    bureaucracy: 1
  },
  start: { loan: 19000, loanYears: 5 },
  tax: {
    corporate: 0.122,
    special: {}, /* higher company tax for some industries: oil, salmon, hydro (power) */
    dividend: 0.3,
    dividendShield: 0, /* tax-free return on paid-in capital */
    employer: { social: 0.075, pension: 0, injury: 0.01 },
    income: {
      flat: 0, /* flat tax on income after the allowance */
      allowance: 0,
      wageDeduction: null,
      brackets: [[0, 0.2], [55000, 0.28], [110000, 0.34], [170000, 0.41], [240000, 0.48]], /* [from, rate] on gross income */
      social: { employee: 0.07, selfEmployed: 0.12, floor: 0, capShare: 0 }
    },
    wealth: null,
    inherit: { free: 0, rate: 0.18, biz: 0, bizFree: 1250000 } /* no inheritance tax: gains are taxed at death (deemed disposition); small-business shares exempt up to 1.25 M */
  },
  vat: {
    rates: { std: 0.13, food: 0, low: 0.05, zero: 0 },
    threshold: 30000,
    filingMonths: 3,
    salesTax: false,
    registrationName: 'GST/HST registration'
  },
  companies: {
    forms: { ENK: 'Sole proprietorship', AS: 'Corporation (Inc.)', ENKs: 'Sole prop.', ASs: 'Inc.' },
    capital: 0,
    registrationFee: 300,
    conversionFee: 550
  },
  work: { leaveWeeks: 2 },
  authorities: {
    tax: 'the CRA',
    cb: 'Bank of Canada',
    comp: 'Competition Bureau',
    fin: 'Office of the Superintendent of Financial Institutions',
    lab: 'Provincial Labour Ministry',
    food: 'Canadian Food Inspection Agency',
    cons: 'Consumer Protection Office',
    data: 'Privacy Commissioner',
    road: 'Provincial Transport Ministry',
    health: 'Provincial Health Ministry',
    reg: 'Corporations Canada',
    fish: 'Fisheries and Oceans Canada',
    tv: 'CBC and CTV',
    idx: 'TSX Composite Index Fund',
    bond: 'Canadian Bond Fund'
  },
  documents: {
    overrides: {
      ce: ['Product safety listing (CSA / ISED)', null, null, null, null, 'Needed to sell electrical products.'],
      gdpr: ['Privacy policy (PIPEDA)', null, null, null, null, 'Needed when you hold customer data.']
    }, /* [name, issuer, cost, weeks, renewal, note]; null keeps the standard value */
    notNeeded: ['eh'],
    fees: { org: 60, mva: 0, skjenk: 1055, salg: 500, drone: 10, tgodk: 0, brygg: 3150 }
  },
  banned: {},
  cities: [
    ['tor', 'Toronto', 2800, 1.3, 1.15],
    ['van', 'Vancouver', 660, 1.35, 1.12],
    ['mtl', 'Montréal', 1760, 0.95, 1],
    ['cal', 'Calgary', 1340, 0.95, 1.08],
    ['ott', 'Ottawa', 1020, 0.95, 1.05],
    ['smallca', 'Small town', 20, 0.4, 0.8]
  ],
  names: {
    first: [
      'Liam',
      'Olivia',
      'Noah',
      'Emma',
      'Jackson',
      'Charlotte',
      'Lucas',
      'Chloe',
      'Ethan',
      'Sophie',
      'Logan',
      'Ava',
      'Mason',
      'Zoe',
      'Jacob',
      'Mia',
      'Nathan'
    ],
    last: [
      'Smith',
      'Brown',
      'Tremblay',
      'Martin',
      'Roy',
      'Wilson',
      'MacDonald',
      'Gagnon',
      'Johnson',
      'Taylor',
      'Campbell',
      'Anderson',
      'Singh',
      'Chen',
      'Bouchard',
      'Morin',
      'Lavoie',
      'Clarke',
      'Murray'
    ],
    companyStart: [
      'Maple',
      'Northern',
      'Great Lakes',
      'Prairie',
      'Pacific',
      'Atlantic',
      'Boreal',
      'Laurentian',
      'Rocky',
      'True North',
      'Canadian',
      'Beaver',
      'Polar',
      'Cascade',
      'Tundra'
    ],
    companyEnd: ['Inc.', 'Group', 'Services', 'Trading', 'Construction', 'Partners']
  },
  titles: ['General manager', 'Assistant manager', 'Shift lead', 'Regional director', 'Chief executive officer'],
  tourism: { share: 0.1, origins: 'US:55,UK:10,FR:8,AU:6,JP:5,KR:5,DE:6,BR:5' },
  media: { prime: ['Hockey Night in Canada', 'The national ritual.'], bigAd: 'the hockey night ads' },
  providerNames: [['Chartered Accountants', 'Accounting', 'Tax'], 'Law Group', 'Insurance', ' Inc.'],
  football: ['Canadian Premier League', 8, [4, 15]]
});


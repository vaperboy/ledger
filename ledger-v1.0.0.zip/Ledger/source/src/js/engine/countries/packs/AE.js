/* ---- src/countries/packs/AE.js ---- */
/* ===== Country: United Arab Emirates (round 56) =====
   All money amounts in this file are in AED. Rates are shares (0.25 = 25%).
   Figures are approximations for a game; check them against official sources before relying on them.
   No personal income tax; company tax 9% on profit above AED 375 000 (0% in qualifying free zones); VAT 5%; a trade
   licence that is renewed every year; most workers are expatriates, whose employers pay an end-of-service gratuity
   instead of social security; commercial gambling only under a federal licence.
   The fields are described in src/countries/framework.js (COUNTRY_SCHEMA). */
defineCountry({
  code: 'AE',
  name: 'United Arab Emirates',
  flag: '🇦🇪',
  region: 'Middle East', /* where the country sits in the start screen's list */
  currency: 'AED',
  symbol: 'AED',
  fx: 2.9135, /* game base units per 1 AED */
  population: 10.2, /* millions */
  economy: {
    medianWage: 9000,
    priceIndex: 95,
    officeRent: 1800,
    spendPerPerson: 85000,
    policyRate: 0.04,
    bureaucracy: 0.8
  },
  start: { loan: 50000, loanYears: 5 },
  tax: {
    corporate: 0.08, /* 9% above AED 375 000 of profit, nothing below: about 8% for a growing company */
    special: {},
    dividend: 0,
    dividendShield: 0,
    employer: { social: 0, pension: 0.06, injury: 0.005 }, /* end-of-service gratuity (21 days a year) and medical/work cover */
    income: {
      flat: 0,
      allowance: 0,
      wageDeduction: null,
      brackets: [[0, 0]], /* no personal income tax */
      social: { employee: 0, selfEmployed: 0, floor: 0, capShare: 0 }
    },
    wealth: null,
    inherit: { free: 0, rate: 0, biz: 0, bizFree: 0 } /* no inheritance tax */
  },
  vat: { rates: { std: 0.05, food: 0.05, low: 0.05, zero: 0 }, threshold: 375000, filingMonths: 3, salesTax: false },
  companies: {
    forms: { ENK: 'Sole establishment', AS: 'Limited liability company (LLC)', ENKs: 'Sole est.', ASs: 'LLC' },
    capital: 1,
    registrationFee: 16000, /* trade licence and establishment card, renewed every year */
    conversionFee: 12000
  },
  work: { leaveWeeks: 4.3 }, /* 30 calendar days */
  authorities: {
    tax: 'Federal Tax Authority',
    cb: 'Central Bank of the UAE',
    comp: 'Ministry of Economy (competition)',
    fin: 'Securities and Commodities Authority',
    lab: 'Ministry of Human Resources and Emiratisation',
    food: 'Municipality food safety department',
    cons: 'Ministry of Economy (consumer protection)',
    data: 'UAE Data Office',
    road: 'Roads and Transport Authority',
    health: 'Health Authority',
    reg: 'Department of Economy and Tourism',
    fish: 'Ministry of Climate Change and Environment',
    tv: 'MBC and Dubai TV',
    idx: 'UAE Index Fund',
    bond: 'UAE Sukuk Fund'
  },
  documents: { overrides: {}, notNeeded: [], fees: { org: 0, mva: 0 } },
  banned: {
    casino: 'Commercial gaming needs a federal licence, and only one resort project holds one.',
    salmon: 'No salmon farming licences.'
  },
  cities: [
    ['dxb', 'Dubai', 3800, 1.3, 1.15],
    ['auh', 'Abu Dhabi', 1600, 1.2, 1.15],
    ['shj', 'Sharjah', 1800, 0.75, 0.9],
    ['aan', 'Al Ain', 770, 0.7, 0.9],
    ['rak', 'Ras Al Khaimah', 400, 0.65, 0.85],
    ['smallae', 'Small town', 30, 0.5, 0.8]
  ],
  names: {
    first: ['Mohammed', 'Fatima', 'Ahmed', 'Mariam', 'Omar', 'Aisha', 'Khalid', 'Noura', 'Rashid', 'Hessa', 'Rahul', 'Priya', 'Arjun', 'Anjali', 'Jose', 'Maria', 'James', 'Sarah', 'Ali', 'Layla', 'Hamdan', 'Shamma', 'Vikram', 'Grace'],
    last: ['Al Mansoori', 'Al Nuaimi', 'Al Hashimi', 'Al Ketbi', 'Al Shamsi', 'Al Falasi', 'Al Mazrouei', 'Al Suwaidi', 'Nair', 'Menon', 'Sharma', 'Pillai', 'Santos', 'Reyes', 'Khan', 'Hussain', 'Smith', 'Haddad'],
    companyStart: ['Emirates', 'Gulf', 'Desert', 'Falcon', 'Pearl', 'Oasis', 'Dubai', 'Abu Dhabi', 'Al Noor', 'Palm', 'Creek', 'Marina', 'Sahara', 'Dune', 'Golden', 'Royal', 'Arabian', 'Crescent'],
    companyEnd: ['LLC', 'Trading LLC', 'General Trading', 'Contracting', 'Group', 'Services']
  },
  titles: ['Branch manager', 'Assistant manager', 'Supervisor', 'Regional manager', 'Chief executive officer'],
  tourism: { share: 0.7, origins: 'UK:12,DE:6,US:6,FR:4,KR:3,JP:3,AU:3,ES:3,NL:2,BR:2,SE:2,NO:2' },
  media: {
    prime: ['The Dubai World Cup night', 'The richest night in racing, watched across the Gulf and beyond.'],
    bigAd: 'a billboard on Sheikh Zayed Road'
  },
  providerNames: [['Accounting', 'Auditing', 'Chartered Accountants'], 'Advocates and Legal Consultants', 'Insurance', ' LLC'],
  football: ['UAE Pro League', 14, [20, 600]]
});

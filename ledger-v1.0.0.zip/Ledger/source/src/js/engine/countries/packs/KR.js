/* ---- src/countries/packs/KR.js ---- */
/* ===== Country: South Korea =====
   All money amounts in this file are in KRW. Rates are shares (0.25 = 25%).
   Figures are approximations for a game; check them against official sources before relying on them.
   The fields are described in src/countries/framework.js (COUNTRY_SCHEMA). */
defineCountry({
  code: 'KR',
  name: 'South Korea',
  flag: '🇰🇷',
  region: 'Asia and Pacific', /* where the country sits in the start screen's list */
  currency: 'KRW',
  symbol: '₩',
  fx: 0.0076429, /* game base units per 1 KRW */
  population: 51, /* millions */
  economy: {
    medianWage: 3300000,
    priceIndex: 82,
    officeRent: 230000,
    spendPerPerson: 26000000,
    policyRate: 0.025,
    bureaucracy: 1.1
  },
  start: { loan: 12000000, loanYears: 5 },
  tax: {
    corporate: 0.22,
    special: {}, /* higher company tax for some industries: oil, salmon, hydro (power) */
    dividend: 0.154,
    dividendShield: 0, /* tax-free return on paid-in capital */
    employer: { social: 0.1, pension: 0, injury: 0.01 },
    income: {
      flat: 0, /* flat tax on income after the allowance */
      allowance: 0,
      wageDeduction: null,
      brackets: [
        [0, 0.06],
        [14000000, 0.15],
        [50000000, 0.24],
        [88000000, 0.35],
        [150000000, 0.38],
        [300000000, 0.4],
        [500000000, 0.42],
        [1000000000, 0.45]
      ], /* [from, rate] on gross income */
      social: { employee: 0.09, selfEmployed: 0.09, floor: 0, capShare: 0 }
    },
    wealth: null,
    inherit: { free: 500000000, rate: 0.45, biz: 0.5, bizFree: 0 } /* top rate 50%; business succession deduction for smaller firms */
  },
  vat: { rates: { std: 0.1, food: 0, low: 0.1, zero: 0 }, threshold: 104000000, filingMonths: 6, salesTax: false },
  companies: {
    forms: { ENK: 'Sole proprietorship', AS: 'Company limited (Co., Ltd.)', ENKs: 'Sole prop.', ASs: 'Co., Ltd.' },
    capital: 1000000,
    registrationFee: 500000,
    conversionFee: 750000
  },
  work: { leaveWeeks: 3 },
  authorities: {
    tax: 'National Tax Service',
    cb: 'Bank of Korea',
    comp: 'Fair Trade Commission',
    fin: 'Financial Supervisory Service',
    lab: 'Ministry of Employment and Labor',
    food: 'Ministry of Food and Drug Safety',
    cons: 'Korea Consumer Agency',
    data: 'Personal Information Protection Commission',
    road: 'Transportation Safety Authority',
    health: 'Ministry of Health',
    reg: 'Court Registry',
    fish: 'Ministry of Oceans and Fisheries',
    tv: 'KBS and SBS',
    idx: 'KOSPI All-Share Index Fund',
    bond: 'Korean Bond Fund'
  },
  documents: {
    overrides: {
      ce: ['Product safety certification (KC)', null, null, null, null, 'Needed to sell electrical products.'],
      gdpr: ['Privacy policy (PIPA)', null, null, null, null, 'Needed when you hold customer data.']
    }, /* [name, issuer, cost, weeks, renewal, note]; null keeps the standard value */
    notNeeded: ['eh'],
    fees: { org: 0, mva: 0, hms: 0 }
  },
  banned: {
    casino: 'Casinos for locals are banned (only a few foreigner-only licences exist).',
    oilgas: 'No petroleum resources to licence.',
    salmon: 'Not available for foreign operators.'
  },
  cities: [
    ['sel', 'Seoul', 9400, 1.4, 1.2],
    ['pus', 'Busan', 3300, 0.9, 1],
    ['inc', 'Incheon', 3000, 0.85, 1],
    ['dae', 'Daegu', 2400, 0.75, 0.95],
    ['dej', 'Daejeon', 1450, 0.75, 0.95],
    ['smallkr', 'Small town', 40, 0.4, 0.78]
  ],
  names: {
    first: [
      'Minjun',
      'Seo-yeon',
      'Jiho',
      'Ha-eun',
      'Joon',
      'Ji-woo',
      'Hyun',
      'Soo-ah',
      'Dong-hyun',
      'Yuna',
      'Tae-yang',
      'Min-seo',
      'Seung',
      'Eun-ji',
      'Seoyeon',
      'Jiwoo',
      'Hyunwoo',
      'Soyeon',
      'Seungmin',
      'Dongho',
      'Eunji',
      'Taehyun',
      'Minseo',
      'Haeun'
    ],
    last: ['Kim', 'Lee', 'Park', 'Choi', 'Jung', 'Kang', 'Cho', 'Yoon', 'Jang', 'Lim', 'Han', 'Oh', 'Seo', 'Shin'],
    companyStart: [
      'Hanguk',
      'Daehan',
      'Seoul',
      'Mirae',
      'Dongyang',
      'Hana',
      'Sejong',
      'Bitna',
      'Pacific',
      'Samwon',
      'Busan',
      'Haedong',
      'Sae',
      'Namsan',
      'Hanbit',
      'Areum',
      'Sunrise',
      'Bluesky',
      'Jeil',
      'Chungsol'
    ],
    companyEnd: ['Co., Ltd.', 'Group', 'Service', 'Trading', 'Construction', 'Partners']
  },
  titles: ['Branch head', 'Deputy branch head', 'Team leader', 'Regional head', 'Representative director'],
  tourism: { share: 0.1, origins: 'JP:30,US:15,AU:10,UK:8,DE:7,FR:7,CA:6,ES:5,BR:5,NL:7' },
  media: {
    prime: ['Drama product placement and prime-time TV', 'K-dramas move products fast.'],
    bigAd: 'prime-time TV'
  },
  providerNames: [['Hoegye', 'Segmu', 'Audit'], 'Law Office', 'Boheom', ' Co.'],
  football: ['K League 1', 12, [20, 90]]
});


/* ---- src/countries/packs/FR.js ---- */
/* ===== Country: France =====
   All money amounts in this file are in EUR. Rates are shares (0.25 = 25%).
   Figures are approximations for a game; check them against official sources before relying on them.
   The fields are described in src/countries/framework.js (COUNTRY_SCHEMA). */
defineCountry({
  code: 'FR',
  name: 'France',
  flag: '🇫🇷',
  region: 'Europe', /* where the country sits in the start screen's list */
  currency: 'EUR',
  symbol: '€',
  fx: 11.6304348, /* game base units per 1 EUR */
  population: 68, /* millions */
  economy: {
    medianWage: 2600,
    priceIndex: 106,
    officeRent: 160,
    spendPerPerson: 25000,
    policyRate: 0.02,
    bureaucracy: 1.3
  },
  start: { loan: 10000, loanYears: 5 },
  tax: {
    corporate: 0.25,
    special: {}, /* higher company tax for some industries: oil, salmon, hydro (power) */
    dividend: 0.3,
    dividendShield: 0, /* tax-free return on paid-in capital */
    employer: { social: 0.42, pension: 0, injury: 0.01 },
    income: {
      flat: 0, /* flat tax on income after the allowance */
      allowance: 0,
      wageDeduction: null,
      brackets: [[0, 0], [11500, 0.11], [29300, 0.3], [83800, 0.41], [180300, 0.45]], /* [from, rate] on gross income */
      social: { employee: 0.22, selfEmployed: 0.22, floor: 0, capShare: 0 }
    },
    wealth: null,
    inherit: { free: 100000, rate: 0.4, biz: 0.75, bizFree: 0 } /* allowance per child; Pacte Dutreil: 75% of a family business exempt */
  },
  vat: { rates: { std: 0.2, food: 0.055, low: 0.1, zero: 0 }, threshold: 37500, filingMonths: 1, salesTax: false },
  companies: {
    forms: { ENK: 'Micro-entrepreneur', AS: 'Simplified company (SAS)', ENKs: 'Micro', ASs: 'SAS' },
    capital: 1,
    registrationFee: 210,
    conversionFee: 700
  },
  work: { leaveWeeks: 5 },
  authorities: {
    tax: 'Public Finance Directorate',
    cb: 'Bank of France and the ECB',
    comp: 'Competition Authority',
    fin: 'Financial Markets Authority',
    lab: 'Labour Inspectorate',
    food: 'Consumer Fraud and Food Safety Directorate',
    cons: 'Consumer Fraud Directorate',
    data: 'Data Protection Authority',
    road: 'Prefecture',
    health: 'Regional Health Agency',
    reg: 'Commercial Court Registry',
    fish: 'Agricultural and Marine Products Agency',
    tv: 'TF1 and France 2',
    idx: 'CAC All-Share Index Fund',
    bond: 'French Bond Fund'
  },
  documents: {
    overrides: {}, /* [name, issuer, cost, weeks, renewal, note]; null keeps the standard value */
    notNeeded: [],
    fees: { org: 25, mva: 0, gdpr: 0, skjenk: 0, drone: 0, mattil: 0, helse: 0 }
  },
  banned: { oilgas: 'New exploration licences are banned.', salmon: 'No licences for sea pens.' },
  cities: [
    ['par', 'Paris', 2100, 1.5, 1.2],
    ['lyo', 'Lyon', 520, 0.9, 1],
    ['mrs', 'Marseille', 870, 0.8, 0.96],
    ['tls', 'Toulouse', 500, 0.8, 0.98],
    ['nan', 'Nantes', 320, 0.78, 0.97],
    ['smallfr', 'Small town', 20, 0.38, 0.8]
  ],
  names: {
    first: [
      'Lucas',
      'Emma',
      'Hugo',
      'Léa',
      'Louis',
      'Chloé',
      'Jules',
      'Camille',
      'Gabriel',
      'Manon',
      'Théo',
      'Inès',
      'Arthur',
      'Sarah',
      'Antoine',
      'Julien',
      'Nicolas',
      'Marie',
      'Pierre',
      'Mathieu',
      'Élise'
    ],
    last: [
      'Martin',
      'Bernard',
      'Dubois',
      'Thomas',
      'Robert',
      'Richard',
      'Petit',
      'Durand',
      'Leroy',
      'Moreau',
      'Simon',
      'Laurent',
      'Lefebvre',
      'Fontaine'
    ],
    companyStart: [
      'Atelier',
      'Provence',
      'Seine',
      'Grand',
      'Belle',
      'Nouvelle',
      'Maison',
      'Lumière',
      'Riviera',
      'Terre',
      'Française',
      'Atlantique',
      'Bretonne',
      'Alsacienne',
      'Normande',
      'Royale',
      'Bon',
      'Doré',
      'Bleu',
      'Soleil',
      'Parisienne',
      'Lyonnaise',
      'Rivière'
    ],
    companyEnd: ['SAS', 'Groupe', 'Services', 'Commerce', 'Construction', 'Conseil']
  },
  titles: ['Director', 'Deputy director', 'Team leader', 'Regional director', 'Chairman and CEO'],
  tourism: { share: 0.35, origins: 'DE:20,UK:20,ES:10,NL:10,US:10,BR:5,JP:5,PL:5,SE:5,NO:5,AU:5' },
  media: {
    prime: ['Tour de France and TF1 prime time', 'A national event with huge crowds.'],
    bigAd: 'the Tour de France ads'
  },
  providerNames: [['Cabinet Comptable', 'Expertise', 'Audit'], 'Avocats', 'Assurances', ' SARL'],
  football: ['Ligue 1', 18, [70, 4000]]
});


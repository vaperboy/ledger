/* ---- src/countries/packs/PL.js ---- */
/* ===== Country: Poland =====
   All money amounts in this file are in PLN. Rates are shares (0.25 = 25%).
   Figures are approximations for a game; check them against official sources before relying on them.
   The fields are described in src/countries/framework.js (COUNTRY_SCHEMA). */
defineCountry({
  code: 'PL',
  name: 'Poland',
  flag: '🇵🇱',
  region: 'Europe', /* where the country sits in the start screen's list */
  currency: 'PLN',
  symbol: 'zł',
  fx: 2.675, /* game base units per 1 PLN */
  population: 37.5, /* millions */
  economy: {
    medianWage: 7500,
    priceIndex: 64,
    officeRent: 480,
    spendPerPerson: 48000,
    policyRate: 0.04,
    bureaucracy: 1.1
  },
  start: { loan: 32500, loanYears: 5 },
  tax: {
    corporate: 0.19,
    special: {}, /* higher company tax for some industries: oil, salmon, hydro (power) */
    dividend: 0.19,
    dividendShield: 0, /* tax-free return on paid-in capital */
    employer: { social: 0.205, pension: 0, injury: 0.0167 },
    income: {
      flat: 0, /* flat tax on income after the allowance */
      allowance: 0,
      wageDeduction: null,
      brackets: [[0, 0], [30000, 0.12], [120000, 0.32]], /* [from, rate] on gross income */
      social: { employee: 0.22, selfEmployed: 0.19, floor: 0, capShare: 0 }
    },
    wealth: null,
    inherit: { free: 0, rate: 0, biz: 0, bizFree: 0 } /* children are exempt when the inheritance is reported */
  },
  vat: { rates: { std: 0.23, food: 0.05, low: 0.08, zero: 0 }, threshold: 200000, filingMonths: 1, salesTax: false },
  companies: {
    forms: { ENK: 'Sole proprietorship', AS: 'Limited company (Sp. z o.o.)', ENKs: 'JDG', ASs: 'Sp. z o.o.' },
    capital: 5000,
    registrationFee: 350,
    conversionFee: 1500
  },
  work: { leaveWeeks: 4 },
  authorities: {
    tax: 'Revenue Office',
    cb: 'National Bank of Poland',
    comp: 'Competition and Consumer Protection Office',
    fin: 'Financial Supervision Authority',
    lab: 'National Labour Inspectorate',
    food: 'Sanitary Inspection',
    cons: 'Competition and Consumer Protection Office',
    data: 'Personal Data Protection Office',
    road: 'Road Transport Inspection',
    health: 'National Health Fund',
    reg: 'National Court Register',
    fish: 'Ministry of Agriculture',
    tv: 'TVP and Polsat',
    idx: 'Warsaw All-Share Index Fund',
    bond: 'Polish Bond Fund'
  },
  documents: {
    overrides: {}, /* [name, issuer, cost, weeks, renewal, note]; null keeps the standard value */
    notNeeded: [],
    fees: {
      org: 0,
      mva: 0,
      hms: 0,
      gdpr: 0,
      skjenk: 3150,
      salg: 3150,
      drone: 0,
      tobak: 0,
      goods: 1000,
      tgodk: 0,
      mattil: 0,
      megler: 0
    }
  },
  banned: { oilgas: 'No meaningful licensing rounds.', salmon: 'Not possible at scale.' },
  cities: [
    ['waw', 'Warsaw', 1800, 1.25, 1.2],
    ['krk', 'Kraków', 800, 1, 1.05],
    ['wro', 'Wrocław', 670, 0.95, 1.02],
    ['gdn', 'Gdańsk', 470, 0.92, 1],
    ['poz', 'Poznań', 540, 0.9, 1],
    ['smallpl', 'Small town', 25, 0.4, 0.8]
  ],
  names: {
    first: [
      'Piotr',
      'Anna',
      'Jakub',
      'Katarzyna',
      'Michał',
      'Agnieszka',
      'Tomasz',
      'Magdalena',
      'Paweł',
      'Ewa',
      'Marek',
      'Zofia',
      'Łukasz',
      'Julia',
      'Krzysztof',
      'Małgorzata',
      'Andrzej',
      'Joanna',
      'Adam',
      'Monika',
      'Rafał',
      'Aleksandra',
      'Marcin',
      'Natalia',
      'Grzegorz',
      'Karolina',
      'Szymon',
      'Weronika'
    ],
    last: [
      'Nowak',
      'Kowalski',
      'Wiśniewski',
      'Wójcik',
      'Kowalczyk',
      'Kamiński',
      'Lewandowski',
      'Zieliński',
      'Szymański',
      'Woźniak',
      'Dąbrowski',
      'Kozłowski',
      'Mazur',
      'Krawczyk',
      'Piotrowski',
      'Grabowski',
      'Pawłowski',
      'Michalski',
      'Król',
      'Wieczorek',
      'Jabłoński',
      'Wróbel',
      'Majewski',
      'Olszewski',
      'Jaworski',
      'Malinowski'
    ],
    companyStart: [
      'Polska',
      'Wisła',
      'Baltic',
      'Orzeł',
      'Zielona',
      'Złoty',
      'Nowa',
      'Stal',
      'Tatra',
      'Mazur',
      'Krakowska',
      'Gdańska',
      'Mazowiecka',
      'Śląska',
      'Wielkopolska',
      'Bałtycka',
      'Karpacka',
      'Biała',
      'Czerwona',
      'Srebrna',
      'Dobra',
      'Pierwsza',
      'Słoneczna',
      'Mazurska',
      'Pomorska'
    ],
    companyEnd: ['Sp. z o.o.', 'Handel', 'Usługi', 'Bud', 'Grupa', 'Serwis']
  },
  titles: ['Director', 'Deputy director', 'Shift manager', 'Regional director', 'President of the board'],
  tourism: { share: 0.15, origins: 'DE:35,UK:15,US:10,NL:10,FR:8,SE:6,ES:6,NO:5,LT:5' },
  media: {
    prime: ['TVP prime time and league football', 'The biggest stage in Polish media.'],
    bigAd: 'TVP prime time'
  },
  providerNames: [['Biuro Rachunkowe', 'Księgowość', 'Audyt'], 'Kancelaria Prawna', 'Ubezpieczenia', ' Sp. z o.o.'],
  football: ['Ekstraklasa', 18, [15, 90]]
});


/* ---- src/countries/packs/ES.js ---- */
/* ===== Country: Spain =====
   All money amounts in this file are in EUR. Rates are shares (0.25 = 25%).
   Figures are approximations for a game; check them against official sources before relying on them.
   The fields are described in src/countries/framework.js (COUNTRY_SCHEMA). */
defineCountry({
  code: 'ES',
  name: 'Spain',
  flag: '🇪🇸',
  region: 'Europe', /* where the country sits in the start screen's list */
  currency: 'EUR',
  symbol: '€',
  fx: 11.6304348, /* game base units per 1 EUR */
  population: 48, /* millions */
  economy: {
    medianWage: 2000,
    priceIndex: 92,
    officeRent: 130,
    spendPerPerson: 18000,
    policyRate: 0.02,
    bureaucracy: 1.2
  },
  start: { loan: 7500, loanYears: 5 },
  tax: {
    corporate: 0.25,
    special: {}, /* higher company tax for some industries: oil, salmon, hydro (power) */
    dividend: 0.23,
    dividendShield: 0, /* tax-free return on paid-in capital */
    employer: { social: 0.3, pension: 0, injury: 0.01 },
    income: {
      flat: 0, /* flat tax on income after the allowance */
      allowance: 0,
      wageDeduction: null,
      brackets: [[0, 0], [5550, 0.19], [12450, 0.24], [20200, 0.3], [35200, 0.37], [60000, 0.45], [300000, 0.47]], /* [from, rate] on gross income */
      social: { employee: 0.0648, selfEmployed: 0.3, floor: 0, capShare: 0 }
    },
    wealth: { rate: 0.007, threshold: 700000, companyShareCounted: 0.3 },
    inherit: { free: 100000, rate: 0.05, biz: 0.95, bizFree: 0 } /* the regions give children large reliefs; 95% relief on a family business */
  },
  vat: { rates: { std: 0.21, food: 0.04, low: 0.1, zero: 0 }, threshold: 0, filingMonths: 3, salesTax: false },
  companies: {
    forms: { ENK: 'Self-employed', AS: 'Limited company (SL)', ENKs: 'Autónomo', ASs: 'SL' },
    capital: 1,
    registrationFee: 600,
    conversionFee: 1000
  },
  work: { leaveWeeks: 4.4 },
  authorities: {
    tax: 'Tax Agency',
    cb: 'Bank of Spain and the ECB',
    comp: 'Markets and Competition Commission',
    fin: 'Securities Market Commission',
    lab: 'Labour Inspectorate',
    food: 'Food Safety Agency',
    cons: 'Consumer Office',
    data: 'Data Protection Agency',
    road: 'Traffic Authority',
    health: 'Regional Health Ministry',
    reg: 'Mercantile Registry',
    fish: 'Ministry of Agriculture and Fisheries',
    tv: 'TVE and Antena 3',
    idx: 'IBEX All-Share Index Fund',
    bond: 'Spanish Bond Fund'
  },
  documents: {
    overrides: {}, /* [name, issuer, cost, weeks, renewal, note]; null keeps the standard value */
    notNeeded: [],
    fees: { org: 0, mva: 0, gdpr: 0, drone: 0, tobak: 0, megler: 0 }
  },
  banned: { oilgas: 'No new licences.' },
  cities: [
    ['mad', 'Madrid', 3300, 1.25, 1.15],
    ['bcn', 'Barcelona', 1600, 1.25, 1.12],
    ['val', 'Valencia', 800, 0.85, 0.98],
    ['sev', 'Seville', 690, 0.75, 0.94],
    ['bil', 'Bilbao', 345, 0.85, 1.02],
    ['smalles', 'Small town', 20, 0.38, 0.8]
  ],
  names: {
    first: [
      'Hugo',
      'Lucía',
      'Martín',
      'Sofía',
      'Pablo',
      'Paula',
      'Daniel',
      'Valeria',
      'Álvaro',
      'Julia',
      'Adrián',
      'Carmen',
      'Javier',
      'Marta',
      'Alejandro',
      'Carlos',
      'Elena',
      'Diego',
      'Sergio',
      'Isabel',
      'Nuria'
    ],
    last: [
      'García',
      'Rodríguez',
      'González',
      'Fernández',
      'López',
      'Martínez',
      'Sánchez',
      'Pérez',
      'Gómez',
      'Ruiz',
      'Hernández',
      'Díaz',
      'Moreno',
      'Navarro'
    ],
    companyStart: [
      'Iberia',
      'Sol',
      'Costa',
      'Nueva',
      'Gran',
      'Mediterránea',
      'Castilla',
      'Andaluza',
      'Levante',
      'Real',
      'Española',
      'Ibérica',
      'Catalana',
      'Castellana',
      'Gallega',
      'Dorada',
      'Mar',
      'Verde',
      'Madrileña'
    ],
    companyEnd: ['SL', 'Grupo', 'Servicios', 'Comercio', 'Construcciones', 'Consultores']
  },
  titles: ['Director', 'Deputy director', 'Shift leader', 'Regional director', 'Chief executive'],
  tourism: { share: 0.5, origins: 'UK:25,FR:20,DE:20,NL:7,US:8,SE:5,NO:5,PL:5,BR:5' },
  media: { prime: ['La Liga clásico broadcast', 'Spain gathers for it.'], bigAd: 'the Clásico ads' },
  providerNames: [['Gestoría', 'Contabilidad', 'Auditoría'], 'Abogados', 'Seguros', ' S.L.'],
  football: ['La Liga', 20, [110, 6500]]
});


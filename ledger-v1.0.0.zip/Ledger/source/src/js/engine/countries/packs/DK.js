/* ---- src/countries/packs/DK.js ---- */
/* ===== Country: Denmark (round 57) =====
   All money amounts in this file are in DKK. Rates are shares (0.25 = 25%).
   Figures are approximations for a game; check them against official sources before relying on them.
   Median gross wage about DKK 42 000 a month (Statistics Denmark), prices about 40% above the EU average (Eurostat),
   company tax 22%, VAT 25% on almost everything, almost no employer social contributions (ATP and small schemes; the
   labour market pensions come from collective agreements), the 8% labour market contribution, then bottom tax 12.01%
   plus municipal tax about 25%, the new middle tax 7.5% from DKK 641 200, top tax 7.5% from DKK 777 900 and top-top
   tax 5% from DKK 2.59 M after the contribution (2026, The Local), inheritance tax 15% above about DKK 343 000.
   The fields are described in src/countries/framework.js (COUNTRY_SCHEMA). */
defineCountry({
  code: 'DK',
  name: 'Denmark',
  flag: '🇩🇰',
  region: 'Europe', /* where the country sits in the start screen's list */
  currency: 'DKK',
  symbol: 'kr',
  fx: 1.562, /* game base units per 1 DKK */
  population: 6, /* millions */
  economy: {
    medianWage: 42000,
    priceIndex: 140,
    officeRent: 1200,
    spendPerPerson: 220000,
    policyRate: 0.016,
    bureaucracy: 0.7
  },
  start: { loan: 100000, loanYears: 5 },
  tax: {
    corporate: 0.22,
    special: {}, /* higher company tax for some industries: oil, salmon, hydro (power) */
    dividend: 0.42, /* 27% on the first part, 42% above */
    dividendShield: 0,
    employer: { social: 0.01, pension: 0.08, injury: 0.005 }, /* ATP and small schemes; agreement pensions; workplace injury insurance */
    income: {
      flat: 0,
      allowance: 0,
      wageDeduction: null,
      brackets: [[0, 0], [54100, 0.34], [697000, 0.41], [845500, 0.48], [2818000, 0.52]], /* bottom and municipal tax, then middle, top and top-top tax (thresholds after the 8% contribution, as gross) */
      social: { employee: 0.08, selfEmployed: 0.08, floor: 0, capShare: 0 } /* the labour market contribution */
    },
    wealth: null,
    inherit: { free: 342800, rate: 0.15, biz: 0.67, bizFree: 0 } /* 15% above the allowance; family businesses about 5% */
  },
  vat: { rates: { std: 0.25, food: 0.25, low: 0.25, zero: 0 }, threshold: 50000, filingMonths: 3, salesTax: false },
  companies: {
    forms: { ENK: 'Sole proprietorship (enkeltmandsvirksomhed)', AS: 'Private limited company (ApS)', ENKs: 'Enkeltmandsvirksomhed', ASs: 'ApS' },
    capital: 40000,
    registrationFee: 670,
    conversionFee: 15000 /* an accountant's statement for a tax-free conversion */
  },
  work: { leaveWeeks: 5 },
  authorities: {
    tax: 'Danish Tax Agency (Skattestyrelsen)',
    cb: 'Danmarks Nationalbank',
    comp: 'Competition and Consumer Authority',
    fin: 'Danish FSA (Finanstilsynet)',
    lab: 'Working Environment Authority',
    food: 'Veterinary and Food Administration',
    cons: 'Consumer Ombudsman',
    data: 'Data Protection Agency',
    road: 'Danish Road Traffic Authority',
    health: 'Danish Health Authority',
    reg: 'Danish Business Authority (CVR)',
    fish: 'Danish Fisheries Agency',
    tv: 'DR and TV 2',
    idx: 'OMX Copenhagen 25 Index Fund',
    bond: 'Danish Government Bond Fund'
  },
  documents: { overrides: {}, notNeeded: [], fees: { org: 670, mva: 0, gdpr: 0, mattil: 0 } },
  banned: { salmon: 'No new sea-pen licences are issued in Danish waters.', oilgas: 'Denmark has stopped issuing new oil and gas licences.' },
  cities: [
    ['cph', 'Copenhagen', 660, 1.35, 1.1],
    ['aar', 'Aarhus', 290, 1.05, 1],
    ['ode', 'Odense', 185, 0.9, 0.95],
    ['aal', 'Aalborg', 120, 0.85, 0.95],
    ['esb', 'Esbjerg', 72, 0.8, 0.97],
    ['smalldk', 'Small town', 12, 0.55, 0.9]
  ],
  names: {
    first: ['William', 'Ida', 'Noah', 'Emma', 'Oscar', 'Alma', 'Lucas', 'Ella', 'Carl', 'Freja', 'Victor', 'Karla', 'Malthe', 'Sofie', 'Frederik', 'Clara', 'Magnus', 'Anna', 'Mads', 'Mette', 'Søren', 'Lene', 'Rasmus', 'Camilla', 'Jesper', 'Louise'],
    last: ['Nielsen', 'Jensen', 'Hansen', 'Pedersen', 'Andersen', 'Christensen', 'Larsen', 'Sørensen', 'Rasmussen', 'Jørgensen', 'Petersen', 'Madsen', 'Kristensen', 'Olsen', 'Thomsen', 'Christiansen', 'Poulsen', 'Johansen', 'Møller', 'Mortensen'],
    companyStart: ['Dansk', 'Nordisk', 'Jysk', 'Sjællands', 'Fyns', 'København', 'Øresund', 'Limfjord', 'Skagen', 'Kronborg', 'Vesterhavs', 'Bornholm', 'Lindholm', 'Grøn', 'Nord', 'Syd', 'Øst', 'Vest', 'Hav', 'Klit'],
    companyEnd: ['ApS', 'A/S', 'Service', 'Byg', 'Handel', 'Gruppen']
  },
  titles: ['Store manager', 'Assistant manager', 'Shift leader', 'Regional manager', 'Chief executive (administrerende direktør)'],
  tourism: { share: 0.45, origins: 'DE:40,SE:12,NO:12,NL:6,UK:6,US:5,IT:3,FR:3,PL:3' },
  media: {
    prime: ['TV 2 news and the Saturday prime time', 'The evening news and the big Saturday shows reach most of the country.'],
    bigAd: 'an ad on TV 2 before the news'
  },
  providerNames: [['Revision', 'Regnskab', 'Bogføring'], 'Advokater', 'Forsikring', ' ApS'],
  football: ['Superliga', 12, [10, 300]]
});

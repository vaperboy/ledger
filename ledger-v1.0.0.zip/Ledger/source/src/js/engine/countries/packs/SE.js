/* ---- src/countries/packs/SE.js ---- */
/* ===== Country: Sweden =====
   All money amounts in this file are in SEK. Rates are shares (0.25 = 25%).
   Figures are approximations for a game; check them against official sources before relying on them.
   The fields are described in src/countries/framework.js (COUNTRY_SCHEMA). */
defineCountry({
  code: 'SE',
  name: 'Sweden',
  flag: '🇸🇪',
  region: 'Europe', /* where the country sits in the start screen's list */
  currency: 'SEK',
  symbol: 'kr',
  fx: 1.0190476, /* game base units per 1 SEK */
  population: 10.5, /* millions */
  economy: {
    medianWage: 36000,
    priceIndex: 113,
    officeRent: 1900,
    spendPerPerson: 250000,
    policyRate: 0.0175,
    bureaucracy: 1
  },
  start: { loan: 120000, loanYears: 5 },
  tax: {
    corporate: 0.206,
    special: {}, /* higher company tax for some industries: oil, salmon, hydro (power) */
    dividend: 0.3,
    dividendShield: 0, /* tax-free return on paid-in capital */
    employer: { social: 0.3142, pension: 0, injury: 0 },
    income: {
      flat: 0, /* flat tax on income after the allowance */
      allowance: 0,
      wageDeduction: null,
      brackets: [[0, 0], [45000, 0.32], [625800, 0.52]], /* [from, rate] on gross income */
      social: { employee: 0.07, selfEmployed: 0.29, floor: 0, capShare: 0 }
    },
    wealth: null,
    inherit: { free: 0, rate: 0, biz: 0, bizFree: 0 } /* abolished in 2004 */
  },
  vat: { rates: { std: 0.25, food: 0.12, low: 0.06, zero: 0 }, threshold: 120000, filingMonths: 3, salesTax: false },
  companies: {
    forms: { ENK: 'Sole trader', AS: 'Limited company (AB)', ENKs: 'EF', ASs: 'AB' },
    capital: 25000,
    registrationFee: 2200,
    conversionFee: 4750
  },
  work: { leaveWeeks: 5 },
  authorities: {
    tax: 'Swedish Tax Agency',
    cb: 'Swedish central bank',
    comp: 'Swedish Competition Authority',
    fin: 'Swedish Financial Supervisory Authority',
    lab: 'Swedish Work Environment Authority',
    food: 'Swedish Food Agency',
    cons: 'Swedish Consumer Agency',
    data: 'Swedish Data Protection Authority',
    road: 'Swedish Transport Agency',
    health: 'National Board of Health and Welfare',
    reg: 'Companies Registration Office',
    fish: 'Marine and Water Management Agency',
    tv: 'SVT and TV4',
    idx: 'Stockholm All-Share Index Fund',
    bond: 'Swedish Bond Fund'
  },
  documents: {
    overrides: { salg: [
      null,
      null,
      null,
      null,
      null,
      'Shops may sell only light beer, up to 3.5%. Everything stronger is sold by the state monopoly.'
    ] }, /* [name, issuer, cost, weeks, renewal, note]; null keeps the standard value */
    notNeeded: [],
    fees: {
      org: 0,
      mva: 0,
      hms: 0,
      gdpr: 0,
      skjenk: 13000,
      salg: 0,
      drone: 0,
      tobak: 8750,
      taxi: 12500,
      goods: 12500,
      buslic: 12500,
      tgodk: 0,
      bygg: 20100
    }
  },
  banned: {
    casino: 'Physical casinos are run by a state-owned operator only.',
    oilgas: 'No petroleum resources to licence.',
    salmon: 'No sea-pen licences.'
  },
  cities: [
    ['sthlm', 'Stockholm', 980, 1.15, 1.08],
    ['gbg', 'Gothenburg', 600, 0.85, 1],
    ['malmo', 'Malmö', 350, 0.78, 0.97],
    ['uppsala', 'Uppsala', 235, 0.72, 0.96],
    ['sundsvall', 'Sundsvall', 100, 0.45, 0.9],
    ['smallse', 'Small town', 20, 0.35, 0.86]
  ],
  names: {
    first: [
      'Erik',
      'Anna',
      'Lars',
      'Maria',
      'Karl',
      'Emma',
      'Johan',
      'Sara',
      'Oskar',
      'Elin',
      'Nils',
      'Ida',
      'Axel',
      'Maja',
      'Gustav',
      'Linnea',
      'Fredrik',
      'Frida',
      'Anders',
      'Hanna',
      'Viktor',
      'Josefin',
      'Mikael',
      'Amanda',
      'Emil',
      'Karin',
      'Per',
      'Moa'
    ],
    last: [
      'Andersson',
      'Johansson',
      'Karlsson',
      'Nilsson',
      'Eriksson',
      'Larsson',
      'Olsson',
      'Persson',
      'Svensson',
      'Gustafsson',
      'Lindberg',
      'Bergström',
      'Lindgren',
      'Berg',
      'Holm',
      'Nyström',
      'Lundqvist',
      'Forsberg',
      'Sandberg',
      'Ekström',
      'Wallin',
      'Dahlberg',
      'Strand',
      'Åberg',
      'Hedlund',
      'Sjöberg'
    ],
    companyStart: [
      'Nordisk',
      'Svea',
      'Fjäll',
      'Trygg',
      'Blå',
      'Skog',
      'Hav',
      'Ljus',
      'Stål',
      'Solid',
      'Svensk',
      'Norrlands',
      'Götalands',
      'Östersjö',
      'Mälar',
      'Dala',
      'Vasa',
      'Lapland',
      'Skåne',
      'Gyllene',
      'Björk',
      'Kust',
      'Vit',
      'Röd',
      'Klar'
    ],
    companyEnd: ['AB', 'Gruppen', 'Tjänster', 'Handel', 'Bygg', 'Partner']
  },
  titles: ['Managing director', 'Deputy manager', 'Team leader', 'Regional manager', 'Group CEO'],
  tourism: { share: 0.2, origins: 'NO:30,DE:20,UK:12,US:12,PL:8,NL:8,FR:5,ES:5' },
  media: {
    prime: ['Eurovision and SVT prime time', 'Sweden stops for it. Big audience, big price.'],
    bigAd: 'the Eurovision ads'
  },
  providerNames: [['Redovisning', 'Revision', 'Ekonomi'], 'Advokatbyrå', 'Försäkring', ' AB'],
  football: ['Allsvenskan', 16, [15, 70]]
});


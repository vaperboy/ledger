/* ---- src/countries/packs/US.js ---- */
/* ===== Country: United States =====
   All money amounts in this file are in USD. Rates are shares (0.25 = 25%).
   Figures are approximations for a game; check them against official sources before relying on them.
   The fields are described in src/countries/framework.js (COUNTRY_SCHEMA). */
defineCountry({
  code: 'US',
  name: 'United States',
  flag: '🇺🇸',
  region: 'Americas', /* where the country sits in the start screen's list */
  currency: 'USD',
  symbol: '$',
  fx: 10.7, /* game base units per 1 USD */
  population: 335, /* millions */
  economy: {
    medianWage: 5000,
    priceIndex: 125,
    officeRent: 240,
    spendPerPerson: 55000,
    policyRate: 0.0363,
    bureaucracy: 1
  },
  start: { loan: 16000, loanYears: 5 },
  tax: {
    corporate: 0.26,
    special: {}, /* higher company tax for some industries: oil, salmon, hydro (power) */
    dividend: 0.238,
    dividendShield: 0, /* tax-free return on paid-in capital */
    employer: { social: 0.09, pension: 0.03, injury: 0.01 },
    income: {
      flat: 0, /* flat tax on income after the allowance */
      allowance: 0,
      wageDeduction: null,
      brackets: [
        [0, 0],
        [15000, 0.1],
        [26925, 0.12],
        [63475, 0.22],
        [118350, 0.24],
        [212300, 0.32],
        [265525, 0.35],
        [641350, 0.37]
      ], /* [from, rate] on gross income */
      social: { employee: 0.0765, selfEmployed: 0.153, floor: 0, capShare: 0 }
    },
    wealth: null,
    inherit: { free: 15000000, rate: 0.4, biz: 0, bizFree: 0 } /* federal estate tax above the exemption (15 M from 2026) */
  },
  vat: {
    rates: { std: 0.066, food: 0.02, low: 0.066, zero: 0 },
    threshold: 0,
    filingMonths: 1,
    salesTax: true,
    registrationName: 'Sales tax permit'
  },
  companies: {
    forms: { ENK: 'Sole proprietorship', AS: 'Limited liability company (LLC)', ENKs: 'Sole prop.', ASs: 'LLC' },
    capital: 0,
    registrationFee: 300,
    conversionFee: 375
  },
  work: { leaveWeeks: 0 },
  authorities: {
    tax: 'the IRS',
    cb: 'Federal Reserve',
    comp: 'Federal Trade Commission',
    fin: 'Securities and Exchange Commission',
    lab: 'OSHA',
    food: 'Food and Drug Administration',
    cons: 'Federal Trade Commission',
    data: 'State Attorney General',
    road: 'Department of Motor Vehicles',
    health: 'State Health Department',
    reg: 'Secretary of State',
    fish: 'NOAA Fisheries',
    tv: 'NBC and ABC',
    idx: 'S&P 500 Index Fund',
    bond: 'US Treasury and Corporate Bond Fund'
  },
  documents: {
    overrides: {
      casino: [null, null, null, null, null, 'Casinos are licensed in selected states only.'],
      ce: [
        'Product safety listing (UL / FCC)',
        null,
        null,
        null,
        null,
        'Needed to sell electrical and electronic products.'
      ],
      garanti: [null, 'Federal Trade Commission', null, null, null, 'Clear written warranty terms. State rules differ.'],
      skjenk: ['Liquor licence', null, null, null, null, 'State licence. The fee depends on the state and the seats.'],
      salg: ['Liquor retail licence', null, null, null, null, 'State licence for shops selling beer, wine and spirits.'],
      taxi: ['For-hire vehicle permit', 'City licensing office', null, null, null, 'City-issued permit for paid rides.'],
      mattil: [
        'Food service permit',
        'State Health Department',
        null,
        null,
        null,
        'Health inspection before you handle food.'
      ],
      org: [
        'Business licence and state registration',
        'Secretary of State',
        null,
        null,
        null,
        'State registration plus a city business licence.'
      ]
    }, /* [name, issuer, cost, weeks, renewal, note]; null keeps the standard value */
    notNeeded: ['gdpr', 'eh'],
    fees: { org: 25, mva: 0, drone: 5, tobak: 202.5, goods: 300, buslic: 300, tgodk: 0, brygg: 0 }
  },
  banned: { salmon: 'Very limited licensing. Not available.' },
  cities: [
    ['nyc', 'New York', 8300, 1.7, 1.3],
    ['la', 'Los Angeles', 3900, 1.4, 1.2],
    ['chi', 'Chicago', 2700, 1, 1.1],
    ['hou', 'Houston', 2300, 0.8, 1],
    ['den', 'Denver', 710, 0.95, 1.05],
    ['smallus', 'Small town', 30, 0.4, 0.75]
  ],
  names: {
    first: [
      'James',
      'Mary',
      'Michael',
      'Jennifer',
      'Robert',
      'Linda',
      'David',
      'Emily',
      'Daniel',
      'Ashley',
      'Matthew',
      'Jessica',
      'Chris',
      'Sarah',
      'Megan',
      'Lauren',
      'Tyler',
      'Hannah'
    ],
    last: [
      'Smith',
      'Johnson',
      'Williams',
      'Brown',
      'Jones',
      'Garcia',
      'Miller',
      'Davis',
      'Martinez',
      'Wilson',
      'Anderson',
      'Taylor',
      'Thomas',
      'Moore',
      'Jackson',
      'Martin'
    ],
    companyStart: [
      'American',
      'Liberty',
      'Eagle',
      'Pioneer',
      'Summit',
      'Heritage',
      'Patriot',
      'Lone Star',
      'Golden',
      'Evergreen',
      'National',
      'United',
      'Midwest',
      'Pacific',
      'Atlantic',
      'Heartland',
      'Red Oak',
      'Blue Ridge',
      'Golden State'
    ],
    companyEnd: ['LLC', 'Inc', 'Services', 'Co', 'Construction', 'Group']
  },
  titles: ['General manager', 'Assistant manager', 'Shift lead', 'Regional vice president', 'Chief executive officer'],
  tourism: { share: 0.1, origins: 'CA:25,UK:12,DE:8,JP:8,BR:8,KR:7,AU:6,FR:6,ES:5,NL:5,NO:5,SE:5' },
  media: {
    prime: [
      'Super Bowl ad',
      'The most expensive 30 seconds in the world, and thousands of rivals. Only reaches Americans.'
    ],
    bigAd: 'the Super Bowl ad'
  },
  providerNames: [['CPA', 'Accounting', 'Tax Advisors'], 'Law Group', 'Insurance', ' LLC'],
  football: ['Major League Soccer', 30, [600, 1900]]
});


/* ---- src/countries/packs/FI.js ---- */
/* ===== Country: Finland (round 57) =====
   All money amounts in this file are in EUR. Rates are shares (0.25 = 25%).
   Figures are approximations for a game; check them against official sources before relying on them.
   Median gross wage about EUR 3 700 a month (Statistics Finland), prices about 25% above the EU average (Eurostat),
   company tax 20%, VAT 25.5% (13.5% food and restaurants from 2026, 10% on some services), employer contributions:
   TyEL pension about 17.1%, health insurance 1.91%, unemployment 0.31%, accident about 0.7% (RemotePass); employees
   pay TyEL 7.3%, unemployment 0.89% and health insurance; state income tax is progressive with municipal tax on top.
   The fields are described in src/countries/framework.js (COUNTRY_SCHEMA). */
defineCountry({
  code: 'FI',
  name: 'Finland',
  flag: '🇫🇮',
  region: 'Europe', /* where the country sits in the start screen's list */
  currency: 'EUR',
  symbol: '€',
  fx: 11.6304348, /* game base units per 1 EUR */
  population: 5.6, /* millions */
  economy: {
    medianWage: 3700,
    priceIndex: 125,
    officeRent: 230,
    spendPerPerson: 25000,
    policyRate: 0.02,
    bureaucracy: 0.75
  },
  start: { loan: 12000, loanYears: 5 },
  tax: {
    corporate: 0.2,
    special: {}, /* higher company tax for some industries: oil, salmon, hydro (power) */
    dividend: 0.28,
    dividendShield: 0,
    employer: { social: 0.023, pension: 0.171, injury: 0.007 }, /* health and unemployment insurance; TyEL pension; accident insurance */
    income: {
      flat: 0,
      allowance: 0,
      wageDeduction: null,
      brackets: [[0, 0], [15000, 0.2], [21200, 0.265], [31500, 0.38], [52100, 0.415], [88200, 0.49]], /* state tax with the municipal tax on top */
      social: { employee: 0.095, selfEmployed: 0.24, floor: 0, capShare: 0 } /* TyEL, unemployment and health insurance; YEL for the self-employed */
    },
    wealth: null,
    inherit: { free: 20000, rate: 0.13, biz: 0.6, bizFree: 0 } /* class I 7-19%; a generational transfer is valued at 40% */
  },
  vat: { rates: { std: 0.255, food: 0.135, low: 0.1, zero: 0 }, threshold: 20000, filingMonths: 1, salesTax: false },
  companies: {
    forms: { ENK: 'Sole trader (toiminimi)', AS: 'Limited company (Oy)', ENKs: 'Toiminimi', ASs: 'Oy' },
    capital: 0,
    registrationFee: 275,
    conversionFee: 2000
  },
  work: { leaveWeeks: 5 },
  authorities: {
    tax: 'Finnish Tax Administration (Vero)',
    cb: 'Bank of Finland and the ECB',
    comp: 'Competition and Consumer Authority',
    fin: 'Financial Supervisory Authority',
    lab: 'Occupational Safety and Health Authority',
    food: 'Finnish Food Authority',
    cons: 'Consumer Ombudsman',
    data: 'Data Protection Ombudsman',
    road: 'Traficom',
    health: 'Valvira',
    reg: 'Finnish Patent and Registration Office (PRH)',
    fish: 'Natural Resources Institute',
    tv: 'Yle and MTV3',
    idx: 'OMX Helsinki 25 Index Fund',
    bond: 'Finnish Government Bond Fund'
  },
  documents: { overrides: {}, notNeeded: [], fees: { org: 275, mva: 0, gdpr: 0, mattil: 0 } },
  banned: { casino: 'Veikkaus holds the gambling monopoly and runs Casino Helsinki.', oilgas: 'Finland has no oil or gas fields.', salmon: 'Sea-pen salmon is not licensed; Finnish fish farms raise rainbow trout.' },
  cities: [
    ['hel', 'Helsinki', 680, 1.35, 1.1],
    ['esp', 'Espoo', 315, 1.2, 1.12],
    ['tam', 'Tampere', 260, 0.95, 0.98],
    ['oul', 'Oulu', 215, 0.85, 0.97],
    ['tku', 'Turku', 205, 0.9, 0.96],
    ['rov', 'Rovaniemi', 65, 0.75, 0.92],
    ['smallfi', 'Small town', 10, 0.5, 0.88]
  ],
  names: {
    first: ['Leo', 'Aino', 'Eino', 'Olivia', 'Oliver', 'Helmi', 'Väinö', 'Isla', 'Elias', 'Eevi', 'Onni', 'Venla', 'Mikko', 'Sanna', 'Juha', 'Laura', 'Antti', 'Johanna', 'Timo', 'Kaisa', 'Jari', 'Riikka', 'Ville', 'Noora', 'Matti', 'Anna'],
    last: ['Korhonen', 'Virtanen', 'Mäkinen', 'Nieminen', 'Mäkelä', 'Hämäläinen', 'Laine', 'Heikkinen', 'Koskinen', 'Järvinen', 'Lehtonen', 'Lehtinen', 'Saarinen', 'Salminen', 'Heinonen', 'Niemi', 'Heikkilä', 'Kinnunen', 'Salonen', 'Turunen'],
    companyStart: ['Suomen', 'Pohjolan', 'Lapin', 'Saimaan', 'Karjalan', 'Hämeen', 'Kalevan', 'Revontuli', 'Järvi', 'Metsä', 'Kivi', 'Tunturi', 'Aalto', 'Koski', 'Sisu', 'Pohjoinen', 'Itä', 'Länsi', 'Helsingin', 'Tampereen'],
    companyEnd: ['Oy', 'Oy Ab', 'Palvelut', 'Rakennus', 'Kauppa', 'Group']
  },
  titles: ['Store manager', 'Deputy manager', 'Shift supervisor', 'Regional manager', 'CEO (toimitusjohtaja)'],
  tourism: { share: 0.3, origins: 'DE:14,SE:13,UK:9,US:7,FR:5,NO:4,NL:4,JP:4,ES:3,IT:3,CH:3' },
  media: {
    prime: ['The Independence Day Ball broadcast', 'On 6 December most of the country watches the President’s reception.'],
    bigAd: 'an ad on MTV3 prime time'
  },
  providerNames: [['Tilitoimisto', 'Kirjanpito', 'Talous'], 'Asianajotoimisto', 'Vakuutus', ' Oy'],
  football: ['Veikkausliiga', 12, [2, 25]]
});

/* ---- src/countries/packs/BR.js ---- */
/* ===== Country: Brazil =====
   All money amounts in this file are in BRL. Rates are shares (0.25 = 25%).
   Figures are approximations for a game; check them against official sources before relying on them.
   The fields are described in src/countries/framework.js (COUNTRY_SCHEMA). */
defineCountry({
  code: 'BR',
  name: 'Brazil',
  flag: '🇧🇷',
  region: 'Americas', /* where the country sits in the start screen's list */
  currency: 'BRL',
  symbol: 'R$',
  fx: 1.8448276, /* game base units per 1 BRL */
  population: 216, /* millions */
  economy: {
    medianWage: 3100,
    priceIndex: 55,
    officeRent: 460,
    spendPerPerson: 30000,
    policyRate: 0.15,
    bureaucracy: 1.6
  },
  start: { loan: 45000, loanYears: 5 },
  tax: {
    corporate: 0.34,
    special: {}, /* higher company tax for some industries: oil, salmon, hydro (power) */
    dividend: 0.1,
    dividendShield: 0, /* tax-free return on paid-in capital */
    employer: { social: 0.28, pension: 0, injury: 0.02 },
    income: {
      flat: 0, /* flat tax on income after the allowance */
      allowance: 0,
      wageDeduction: null,
      brackets: [[0, 0], [27500, 0.075], [40000, 0.15], [55000, 0.225], [65000, 0.275]], /* [from, rate] on gross income */
      social: { employee: 0.09, selfEmployed: 0.11, floor: 0, capShare: 0 }
    },
    wealth: null,
    inherit: { free: 0, rate: 0.06, biz: 0, bizFree: 0 } /* state ITCMD, 4-8% */
  },
  vat: {
    rates: { std: 0.17, food: 0.07, low: 0.12, zero: 0 },
    threshold: 0,
    filingMonths: 1,
    salesTax: false,
    registrationName: 'Simplified tax regime registration'
  },
  companies: {
    forms: { ENK: 'Individual micro-entrepreneur', AS: 'Limited company (Ltda)', ENKs: 'MEI', ASs: 'Ltda' },
    capital: 1100,
    registrationFee: 1000,
    conversionFee: 1800
  },
  work: { leaveWeeks: 5 },
  authorities: {
    tax: 'Federal Revenue Service',
    cb: 'Central Bank of Brazil',
    comp: 'Administrative Council for Economic Defense',
    fin: 'Securities Commission',
    lab: 'Ministry of Labour',
    food: 'Health Surveillance Agency',
    cons: 'Consumer Protection Office',
    data: 'National Data Protection Authority',
    road: 'State Traffic Department',
    health: 'Local Health Surveillance',
    reg: 'Commercial Registry',
    fish: 'Ministry of Fisheries',
    tv: 'Globo and Record',
    idx: 'Ibovespa Index Fund',
    bond: 'Brazilian Bond Fund'
  },
  documents: {
    overrides: {
      ce: ['Product certification (INMETRO)', null, null, null, null, 'Needed to sell regulated products.'],
      gdpr: ['Privacy policy (LGPD)', null, null, null, null, 'Needed when you hold customer data.']
    }, /* [name, issuer, cost, weeks, renewal, note]; null keeps the standard value */
    notNeeded: ['eh'],
    fees: { org: 0, mva: 0 }
  },
  banned: { casino: 'Physical casinos are illegal.', salmon: 'Not available.' },
  cities: [
    ['sp', 'São Paulo', 12300, 1.3, 1.25],
    ['rio', 'Rio de Janeiro', 6700, 1.15, 1.1],
    ['bsb', 'Brasília', 3000, 1, 1.15],
    ['ssa', 'Salvador', 2400, 0.7, 0.85],
    ['cur', 'Curitiba', 1900, 0.85, 1],
    ['smallbr', 'Small town', 30, 0.35, 0.7]
  ],
  names: {
    first: [
      'Miguel',
      'Helena',
      'Arthur',
      'Alice',
      'Heitor',
      'Laura',
      'Gabriel',
      'Manuela',
      'Davi',
      'Júlia',
      'Pedro',
      'Sophia',
      'Lucas',
      'Isabella',
      'Ana',
      'Beatriz',
      'Rafael',
      'Juliana',
      'Felipe',
      'Camila',
      'Bruno',
      'Larissa',
      'Thiago',
      'Fernanda',
      'Gustavo',
      'Mariana'
    ],
    last: [
      'Silva',
      'Santos',
      'Oliveira',
      'Souza',
      'Rodrigues',
      'Ferreira',
      'Alves',
      'Pereira',
      'Lima',
      'Gomes',
      'Costa',
      'Ribeiro',
      'Martins',
      'Carvalho'
    ],
    companyStart: [
      'Brasil',
      'Nova',
      'Sol',
      'Grande',
      'Amazônia',
      'Verde',
      'Atlântico',
      'Cruzeiro',
      'Bandeirante',
      'Tropical',
      'Brasileira',
      'Paulista',
      'Carioca',
      'Mineira',
      'Gaúcha',
      'Nordeste',
      'Atlântica',
      'Dourada',
      'Real'
    ],
    companyEnd: ['Ltda', 'Grupo', 'Serviços', 'Comércio', 'Construções', 'Consultoria']
  },
  titles: ['Director', 'Deputy director', 'Shift supervisor', 'Regional director', 'Chief executive'],
  tourism: { share: 0.03, origins: 'US:20,UK:12,FR:12,ES:12,DE:12,AU:8,CA:8,JP:8,KR:8' },
  media: {
    prime: ['Carnival and World Cup broadcast', 'Brazil’s biggest moments.'],
    bigAd: 'the Globo prime-time ads'
  },
  providerNames: [['Contabilidade', 'Assessoria', 'Auditoria'], 'Advocacia', 'Seguros', ' Ltda'],
  football: ['Série A', 20, [40, 700]]
});


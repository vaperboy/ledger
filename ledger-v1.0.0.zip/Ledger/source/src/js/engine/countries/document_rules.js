/* ---- src/countries/document_rules.js ---- */
/* ===== Country-specific document rules: overrides on top of the base DOCS list ===== */
/* [name, issuer, cost, weeks, renew, note]; null keeps the base value. Issuers named with Norwegian keys are localised by locText. */
const FREQ_WORD = { 1: 'monthly', 2: 'every second month', 3: 'quarterly', 6: 'twice a year', 12: 'once a year' };
function docDef(id, cc) {
  cc = cc || CC().code;
  const base = DOCS[id];
  if (!base) return base;
  const o = DOC_OVR[cc] && DOC_OVR[cc][id];
  let d = base;
  if (o) {
    d = base.map((v, i) => (o[i] != null ? o[i] : v));
  }
  if (id === 'mva') {
    const C = CO[cc] || CC();
    const thr = C.vatThr || 0;
    const fq = FREQ_WORD[C.vatFreq || 2] || 'regularly';
    d = d.slice();
    d[0] = MVA_NAME[cc] || (C.salesTax ? 'Sales tax permit' : 'VAT registration');
    d[1] = TAXO[cc] || d[1];
    d[5] = (thr > 0 ? 'Required above ' + money(rl(thr)) + ' turnover. ' : 'Required from your first sale. ') + (C.salesTax ? 'Sales tax' : 'Returns') + ' filed ' + fq + '.';
  }
  return d;
}
function docSkipped(id, cc) {
  cc = cc || CC().code;
  return !!(DOC_SKIP[cc] && DOC_SKIP[cc].indexOf(id) >= 0);
}
/* scale a Norwegian-priced fixed amount to a country's price level, rounded to a tidy local figure (returned in NOK units) */
function KC(v, cc) {
  cc = cc || CC().code;
  if (!v) return v;
  const s = v < 0 ? -1 : 1;
  return s * rlc(Math.abs(v) * costIdx(cc), cc);
}


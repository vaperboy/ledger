/* ---- src/data/brand_names.js ---- */
/* ===== Names of international franchise brands (not tied to one country) ===== */
const FB_GLOBAL = [
  'Everest',
  'Nova',
  'Atlas',
  'Orbit',
  'Zenith',
  'Vertex',
  'Aurora',
  'Meridian',
  'Pulse',
  'Horizon',
  'Quantum',
  'Apex',
  'Lumen',
  'Titan',
  'Spark',
  'Cosmos',
  'Vanguard',
  'Elevate',
  'Unity',
  'Crest',
  'Fusion',
  'Stellar',
  'Axis',
  'Radiant',
  'Polaris'
];
const FB_ORIGINS = ['US', 'US', 'US', 'UK', 'DE', 'FR', 'SE', 'NL', 'JP', 'ES', 'CA', 'AU', 'KR'];


/* ---- src/data/shared.js ---- */
/* ===== Shared libraries ===== */
const SEAS = {
  flat: [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
  summer: [.6, .6, .7, .9, 1.2, 1.5, 1.7, 1.5, 1.0, .8, .6, .8],
  xmas: [.8, .7, .8, .9, .9, .9, .8, .9, 1, 1.1, 1.4, 1.9],
  build: [.7, .7, .9, 1.1, 1.2, 1.2, .9, 1.1, 1.2, 1.2, 1, .7],
  winter: [1.5, 1.4, 1.2, .9, .7, .6, .6, .7, .9, 1, 1.2, 1.4],
  hosp: [.85, .85, .95, 1, 1, 1.1, 1.1, 1.1, 1, 1, 1, 1.2],
  study: [1.3, 1, 1, .9, .8, .5, .4, 1.4, 1.3, 1.1, 1.1, .8],
  newyear: [1.5, 1.1, 1.05, .95, .9, .85, .8, .85, 1.0, 1.0, .95, .8],
  spring: [.8, .85, 1.1, 1.3, 1.3, 1.1, .8, .8, 1, 1, .9, .8],
  fish: [.9, .9, .95, 1, 1, 1.05, 1.05, 1.1, 1.1, 1.05, 1, 1.0]
};
/* roles: monthly wage at Oslo index 1.0. 'tier' used by candidate generator. */
const ROLES = {
  helper: ['General helper', 34000],
  cleaner: ['Cleaner', 34000],
  cashier: ['Shop assistant', 34500],
  waiter: ['Waiter / server', 33500],
  cook: ['Cook', 42000],
  chef: ['Head chef', 56000],
  barista: ['Barista', 34000],
  baker: ['Baker', 41000],
  bartender: ['Bartender', 37000],
  guard: ['Security guard', 39000],
  recept: ['Receptionist', 37000],
  housek: ['Housekeeper', 34000],
  trainer: ['Personal trainer', 41000],
  physio: ['Physiotherapist', 57000],
  lawyer: ['Lawyer', 88000],
  paralegal: ['Paralegal', 52000],
  acct: ['Accountant', 60000],
  dev: ['Developer', 76000],
  designer: ['Designer', 62000],
  marketer: ['Marketer', 58000],
  sales: ['Salesperson', 46000],
  consult: ['Consultant', 79000],
  carp: ['Carpenter', 50000],
  elec: ['Electrician', 55000],
  plumb: ['Plumber', 53000],
  labour: ['Construction worker', 43000],
  foreman: ['Site foreman', 66000],
  engineer: ['Engineer', 76000],
  architect: ['Architect', 69000],
  operator: ['Machine operator', 47000],
  fworker: ['Factory worker', 41000],
  farmh: ['Farm hand', 38000],
  fishtech: ['Fish-farm technician', 53000],
  dealer: ['Casino dealer', 41000],
  cardealer: ['Car salesperson', 52000],
  mech: ['Mechanic', 51000],
  underw: ['Underwriter', 82000],
  claims: ['Claims handler', 59000],
  banker: ['Bank advisor', 67000],
  credit: ['Credit analyst', 73000],
  analyst: ['Fund analyst', 92000],
  propm: ['Property manager', 56000],
  caretaker: ['Caretaker', 40000],
  windtech: ['Energy technician', 63000],
  geo: ['Geologist', 96000],
  offshore: ['Offshore operator', 88000],
  instr: ['Driving instructor', 52000],
  estate: ['Estate agent', 56000],
  ittech: ['IT technician', 63000],
  hr: ['HR advisor', 61000],
  analyst2: ['Data analyst', 71000],
  av: ['AV / sound tech', 46000],
  event: ['Event coordinator', 51000],
  driver: ['Taxi driver', 39000],
  truckd: ['Truck driver', 49000],
  courier: ['Courier', 37000],
  pilot: ['Pilot', 135000],
  fo: ['First officer', 95000],
  cabin: ['Cabin crew', 43000],
  deckh: ['Deck officer', 72000],
  seaman: ['Seaman', 46000],
  groom: ['Groomer / carer', 36000],
  barber: ['Hair stylist', 38000],
  tutor: ['Tutor', 45000],
  photog: ['Photographer', 52000],
  handy: ['Handyman', 44000],
  carwash: ['Car detailer', 38000],
  hm: ['Hotel manager', 82000],
  pm: ['Project manager', 78000],
  buyer: ['Buyer / purchaser', 58000],
  driverB: ['Bus driver', 46000],
  teller: ['Bank teller', 48000],
  compl: ['Compliance officer', 85000],
  agent: ['Insurance agent', 55000],
  broker: ['Broker / trader', 80000],
  dispatch: ['Dispatcher', 47000],
  tech: ['Technician', 54000],
  waiterB: ['Bar staff', 35000],
  dj: ['Booker / DJ', 42000],
  usher: ['Usher / floor staff', 33000],
  projc: ['Project coordinator', 62000],
  safety: ['Safety officer (workplace safety)', 62000],
  lab: ['Quality / lab tech', 56000],
  shipm: ['Ship captain', 105000],
  eng: ['Ship / plant engineer', 85000],
  chefP: ['Pastry / production lead', 52000],
  butcher: ['Butcher / fish cutter', 42000],
  /* round 56 */
  whw: ['Warehouse worker', 40000],
  liftop: ['Lift operator', 36000],
  skiinst: ['Ski instructor', 39000],
  snowtech: ['Snowmaker and groomer driver', 50000]
};
/* DOCS: id -> [name, issuer, cost, weeks, renew NOK/yr, note] */
const DOCS = {
  org: [
    'Business registration',
    '{auth:reg}',
    0,
    1,
    0,
    'Gives you the organisation number.'
  ],
  mva: ['VAT registration', '{auth:tax}', 0, 1, 0, ''],
  hms: [
    'Workplace health and safety system',
    '{auth:lab}',
    3500,
    1,
    0,
    'Written safety and working-environment routines. Inspectors ask for it.'
  ],
  acctr: ['Accountant agreement', 'Accountant', 0, 1, 0, 'Required for limited companies.'],
  gdpr: [
    'Privacy policy and data processing records',
    '{auth:data}',
    4000,
    1,
    0,
    'Needed when you hold customer data.'
  ],
  mattil: ['Food business registration', '{auth:food}', 1500, 3, 0, 'Register before you handle food.'],
  haccp: [
    'Food safety plan (HACCP)',
    '{auth:food}',
    6000,
    2,
    0,
    'Written plan for hygiene, temperatures and traceability.'
  ],
  skjenk: [
    'Alcohol serving licence',
    'Municipality',
    22000,
    10,
    9000,
    'Annual fee based on sales. Needs a responsible manager and a knowledge test.'
  ],
  salg: ['Alcohol sales licence', 'Municipality', 14000, 8, 6000, 'For shops selling beer and wine.'],
  tobak: ['Tobacco sales licence', 'Municipality', 6000, 3, 3000, 'Annual fee. Strict display rules.'],
  taxi: [
    'Taxi licence',
    'County authority',
    160000,
    12,
    0,
    'Licence needed to run paid rides. The fee and any quota depend on the city.'
  ],
  ysk: [
    'Professional driver certificate',
    '{auth:road}',
    9500,
    6,
    0,
    'For paid driving of trucks and buses.'
  ],
  goods: ['Goods transport licence', '{auth:road}', 32000, 8, 4000, 'Needed for commercial freight over 3.5 t.'],
  buslic: ['Passenger transport licence (bus)', '{auth:road}', 45000, 10, 5000, ''],
  tgodk: [
    'Building contractor approval',
    'Building Authority',
    15000,
    6,
    5000,
    'Needed to take responsibility for building work.'
  ],
  elvirk: [
    'Electrical contractor registration',
    'Electrical Safety Authority',
    11500,
    6,
    3000,
    'Needs a qualified electrician as responsible person.'
  ],
  vvs: ['Plumbing central approval', 'Building Authority', 9500, 6, 2500, ''],
  bygg: [
    'Building permit process',
    'Municipality',
    45000,
    12,
    0,
    'Fees, drawings, neighbour notice. Needed to build.'
  ],
  regplan: [
    'Zoning plan work',
    'Municipality',
    160000,
    26,
    0,
    'Zoning plan: slow, costly and uncertain, but the land is worth more after.'
  ],
  lawyer: [
    'Lawyer licence',
    'Legal Profession Supervisory Council',
    12000,
    8,
    4000,
    'Needs a qualified lawyer with practice experience.'
  ],
  rev: ['Accounting firm approval', '{auth:fin}', 14000, 8, 3500, ''],
  megler: ['Estate agency licence', '{auth:fin}', 25000, 10, 6000, 'Needs a licensed estate agent in charge.'],
  helse: ['Health personnel authorisation', 'Health Directorate', 4000, 4, 0, 'For physiotherapists and similar.'],
  hpr: ['Clinic approval', 'Municipality / {auth:health}', 12000, 6, 0, ''],
  trafikk: [
    'Driving school approval',
    '{auth:road}',
    35000,
    14,
    6000,
    'Approved premises, vehicles and instructors.'
  ],
  forsik: [
    'Insurance licence',
    '{auth:fin}',
    450000,
    40,
    80000,
    'Strict capital requirements. Needs a fit and proper board.'
  ],
  bank: ['Banking licence', '{auth:fin}', 900000, 52, 150000, 'High capital requirements. Ongoing supervision.'],
  aif: [
    'Fund manager authorisation',
    '{auth:fin}',
    350000,
    30,
    60000,
    'Alternative investment fund manager authorisation.'
  ],
  casino: [
    'Casino licence',
    'Gaming Authority',
    2500000,
    40,
    600000,
    'Private casinos are tightly restricted or banned in many countries. This game uses an invented licence.'
  ],
  aml: [
    'Anti-money-laundering programme',
    '{auth:fin}',
    25000,
    4,
    12000,
    'Know your customer, reporting, training.'
  ],
  brygg: [
    'Brewery licence and excise registration',
    'Customs Authority',
    18000,
    8,
    6000,
    'Excise duty on every litre.'
  ],
  vinm: ['Alcohol wholesale licence', 'Health Directorate', 30000, 10, 8000, ''],
  aqua: [
    'Aquaculture licence',
    '{auth:fish}',
    52000000,
    40,
    0,
    'Salmon licences are limited. The price reflects the auction level.'
  ],
  fishq: ['Fish health and welfare approval', '{auth:food}', 28000, 8, 6000, ''],
  skog: ['Forestry management plan', 'Municipality / Agriculture Directorate', 9000, 6, 0, ''],
  landb: ['Agricultural production grant registration', 'Agriculture Directorate', 2500, 4, 0, ''],
  fabrik: ['Environmental permit (emissions)', 'Environment Agency', 85000, 16, 7000, 'Emissions to air and water.'],
  ce: [
    'Product certification (CE)',
    'Notified body',
    60000,
    10,
    8000,
    'Needed to sell machinery and electrical products in the EU and EEA.'
  ],
  nve: ['Power generation licence', 'Energy Regulator', 650000, 40, 0, 'Concession for hydro, wind or solar.'],
  nveLite: ['Solar installation notification', 'Energy Regulator', 25000, 6, 0, ''],
  grid: ['Grid connection agreement', 'National grid operator / local grid', 400000, 20, 0, ''],
  oil: [
    'Production licence',
    'Ministry of Energy',
    75000000,
    52,
    0,
    'Awarded in licensing rounds. Needs proof of technical and financial capacity.'
  ],
  oilsafe: ['Safety management consent', 'Petroleum Safety Authority', 450000, 26, 150000, ''],
  aoc: [
    'Air operator certificate',
    'Civil Aviation Authority',
    4500000,
    52,
    800000,
    'Strict safety management, trained crews, approved aircraft.'
  ],
  skip: ['Ship registration and safety certificates', 'Maritime Authority', 180000, 14, 40000, ''],
  vinn: [
    'Handling of used goods / car trade',
    '{auth:road}',
    12000,
    4,
    3000,
    'Registration for motor-vehicle trade.'
  ],
  garanti: [
    'Warranty and returns policy',
    '{auth:cons}',
    3000,
    1,
    0,
    'Clear returns and warranty terms, as consumer law requires.'
  ],
  eh: [
    'E-commerce consumer terms',
    '{auth:cons}',
    5000,
    1,
    0,
    'Distance selling: a 14-day right to withdraw.'
  ],
  child: ['Police certificate', 'Police', 0, 1, 0, 'Staff who work with children.'],
  ped: ['Pet business registration', '{auth:food}', 3500, 3, 0, ''],
  drone: ['Drone operator registration', 'Civil Aviation Authority', 1500, 1, 0, ''],
  forb: ['Mandatory liability insurance', 'Insurer', 0, 1, 0, 'Covered under Insurance in Phone.'],
  vik: ['Fire safety approval of premises', 'Fire service', 6500, 3, 0, ''],
  kunnsk: [
    'Competence certificate',
    'Municipality',
    3500,
    3,
    0,
    'Responsible manager takes the alcohol knowledge test.'
  ],
  stat: ['Commercial lease agreement', 'Landlord', 0, 1, 0, 'Signed lease. Deposit of 3 months.'],
  event: ['Event permit', 'Municipality / police', 7500, 3, 0, ''],
  mfinans: ['Credit provider notification', '{auth:fin}', 40000, 8, 8000, '']
};
/* marketing channels: id -> {name, eff (awareness gain at saturation), scale (NOK/wk for 63% of eff), local?, b2b, minWeeks, note, aud (default weights)} */
const CH = {
  flyer: {
    n: 'Flyers and posters',
    eff: 4,
    sc: 1500,
    loc: 1,
    b2b: 0.2,
    mw: 0,
    note: 'Cheap and local. Fades fast.',
    opts: [0, 500, 1000, 2000]
  },
  google: {
    n: 'Search ads',
    eff: 7,
    sc: 4500,
    loc: 0.6,
    b2b: 0.9,
    mw: 0,
    note: 'People already searching. Works for services.',
    opts: [0, 1500, 3500, 7000, 15000]
  },
  meta: {
    n: 'Social ads (Instagram / Facebook)',
    eff: 8,
    sc: 6000,
    loc: 0.7,
    b2b: 0.3,
    mw: 0,
    note: 'Broad reach, best for consumer brands.',
    opts: [0, 1500, 4000, 8000, 20000]
  },
  tiktok: {
    n: 'Video and influencers',
    eff: 12,
    sc: 9000,
    loc: 0.3,
    b2b: 0.1,
    mw: 2,
    note: 'High variance: a few go viral, most do not.',
    opts: [0, 3000, 8000, 20000],
    var: 1
  },
  local: {
    n: 'Local paper and radio',
    eff: 5,
    sc: 5000,
    loc: 1,
    b2b: 0.4,
    mw: 4,
    note: 'Trust in smaller places. Slow.',
    opts: [0, 2000, 5000, 10000]
  },
  bill: {
    n: 'Billboards and transit ads',
    eff: 9,
    sc: 14000,
    loc: 1,
    b2b: 0.2,
    mw: 8,
    note: 'Brand awareness. Minimum 8-week commitment.',
    opts: [0, 7000, 15000, 30000]
  },
  seo: {
    n: 'Website and SEO',
    eff: 5,
    sc: 3000,
    loc: 0.8,
    b2b: 0.8,
    mw: 12,
    note: 'Builds slowly and keeps working.',
    opts: [0, 1000, 2500, 5000],
    slow: 1
  },
  mail: {
    n: 'Loyalty club and newsletter',
    eff: 4,
    sc: 1200,
    loc: 1,
    b2b: 0.3,
    mw: 0,
    note: 'Keeps regulars coming back. Needs customers.',
    opts: [0, 400, 1000, 2500],
    loyal: 1
  },
  b2b: {
    n: 'B2B outreach / LinkedIn',
    eff: 8,
    sc: 6500,
    loc: 0.5,
    b2b: 1.6,
    mw: 0,
    note: 'For selling to companies.',
    opts: [0, 2000, 5000, 12000]
  },
  fair: {
    n: 'Sponsorship and trade fairs',
    eff: 9,
    sc: 16000,
    loc: 0.7,
    b2b: 1.0,
    mw: 4,
    note: 'Brand and contacts. Pricey.',
    opts: [0, 5000, 12000, 30000]
  }
};
/* vehicles: id -> [name, price new, class, kmLife, fuelPerKm, capacityFactor, tags] */
const VEH = {
  van_s: ['Small van (Berlingo class)', 330000, 'van', 300000, 0.9, 1],
  van_l: ['Large van (Sprinter class)', 560000, 'van', 350000, 1.5, 1.6],
  ev_van: ['Electric van', 590000, 'van', 300000, 0.5, 1.4],
  pickup: ['Pickup (Hilux class)', 520000, 'van', 300000, 1.3, 1.3],
  car_s: ['Small car (Golf class)', 340000, 'car', 250000, 0.8, 1],
  car_ev: ['Electric car', 460000, 'car', 280000, 0.4, 1],
  car_lux: ['Luxury sedan', 880000, 'car', 280000, 1.0, 1.2],
  taxi_ev: ['Taxi (electric estate)', 540000, 'car', 400000, 0.4, 1.2],
  minibus: ['Minibus (16 seats)', 1100000, 'bus', 450000, 2.2, 3],
  bus: ['City bus', 3200000, 'bus', 800000, 3.4, 8],
  truck_s: ['Distribution truck 12 t', 950000, 'truck', 700000, 2.8, 2.2],
  truck_h: ['Tractor unit + trailer 40 t', 2150000, 'truck', 1200000, 4.3, 4],
  truck_ev: ['Electric truck', 3300000, 'truck', 700000, 1.8, 4],
  bike: ['Cargo e-bike', 65000, 'bike', 60000, 0.05, 0.4],
  scooter: ['Delivery scooter', 38000, 'bike', 80000, 0.15, 0.3],
  excav: ['Excavator 14 t', 1250000, 'plant', 12000, 0, 2],
  crane: ['Mobile crane', 2900000, 'plant', 15000, 0, 3]
};
/* insurance products: id -> [name, covers-event-category, premium % of covered value/yr or per revenue, deductible] */
const INSP = {
  prop: [
    'Property and contents',
    'prop',
    'Covers fire, water, theft and storm to your equipment and premises.',
    0.0045,
    10000
  ],
  liab: ['Business liability', 'liab', 'Covers claims from customers and third parties.', 0.0035, 15000],
  cyber: ['Cyber insurance', 'cyber', 'Covers ransomware, breach costs and downtime.', 0.0030, 25000],
  bi: ['Business interruption', 'bi', 'Pays lost profit when you must close after an insured event.', 0.0040, 0],
  key: ['Key-person insurance', 'key', 'Pays if the owner or manager is out long term.', 0.0025, 0],
  prof: [
    'Professional indemnity',
    'prof',
    'Covers advice that goes wrong. Compulsory for law, accounting, brokers.',
    0.0060,
    30000
  ]
};
/* choices every business shares */
const PRICE_STEPS = [-2, -1, 0, 1, 2];
const MGR_TYPES = {
  gen: 'General manager',
  ops: 'Operations manager',
  host: 'Hospitality manager',
  site: 'Site / construction manager',
  sales: 'Sales-driven manager',
  tech: 'Technical manager',
  fin: 'Financial / compliance manager',
  ind: 'Industrial plant manager',
  fleet: 'Fleet and logistics manager',
  prop: 'Property manager',
  fund: 'Investment manager',
  energy: 'Energy / asset manager',
  pro: 'Professional-services partner',
  retail: 'Retail manager',
  game: 'Gaming and licence manager',
  clin: 'Clinical lead'
};
const MGR_FIT = { // how well each manager type fits each other (0..1)
  gen: 0.8,
  ops: 0.75,
  host: 0.6,
  site: 0.6,
  sales: 0.7,
  tech: 0.6,
  fin: 0.6,
  ind: 0.55,
  fleet: 0.55,
  prop: 0.55,
  fund: 0.45,
  energy: 0.5,
  pro: 0.55,
  retail: 0.65,
  game: 0.4,
  clin: 0.5
};
Object.assign(DOCS, {
  renhold: ['Cleaning-company approval', '{auth:lab}', 2000, 3, 0, 'Approved cleaning business register.'],
  bemanning: [
    'Staffing-agency registration',
    '{auth:lab}',
    4500,
    4,
    0,
    'Register to hire out labour. Strict rules on equal pay and duration.'
  ],
  torg: ['Street-trading permit', 'Municipality', 4500, 3, 2500, 'For selling from a truck on public ground.'],
  safety: [
    'Site safety plan (SHA)',
    '{auth:lab}',
    8500,
    2,
    0,
    'Safety, health and working-environment plan for construction.'
  ],
  mva_na: [
    'VAT: not applicable (exempt letting)',
    '-',
    0,
    0,
    0,
    'Letting of property is generally exempt from VAT unless registered voluntarily.'
  ]
});
Object.assign(VEH, {
  foodtruck: ['Food truck (fitted)', 520000, 'truck', 400000, 1.4, 1],
  ship_s: ['Small coaster', 42000000, 'ship', 900000, 12, 1.2],
  ship_l: ['Medium bulk carrier', 180000000, 'ship', 1000000, 25, 3.5],
  ferry: ['Passenger ferry', 140000000, 'ship', 900000, 20, 2.2],
  plane_s: ['Turboprop 70 seats', 180000000, 'plane', 90000, 200, 1]
});
SEAS.wedding = [.4, .5, .6, .9, 1.3, 1.8, 1.9, 1.6, 1.3, .8, .6, .8];


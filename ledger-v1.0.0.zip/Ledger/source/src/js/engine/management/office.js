/* ---- src/management/office.js ---- */
/* ===== Your main office: one place, from the kitchen table to a headquarters building. Desks, meeting rooms, the
   staff who work for the whole group, report settings. At home there is one desk besides yours: for your personal
   assistant, who is your right hand on every board (features/company/shelf_stock_chains_boards.js LH). ===== */
const OFFICE_T = [
  { id: 'home', n: 'Home office', rentM: 0, desks: 1, rooms: 0, note: 'Free. You, a laptop, and room for an assistant.' },
  {
    id: 'cow',
    n: 'Coworking space',
    rentM: 14000,
    desks: 6,
    rooms: 0,
    note: 'Six flexible desks. Month-to-month.'
  },
  {
    id: 'small',
    n: 'Small office',
    rentM: 38000,
    desks: 12,
    rooms: 1,
    note: 'Twelve desks and one meeting room.'
  },
  {
    id: 'floor',
    n: 'Office floor',
    rentM: 110000,
    desks: 40,
    rooms: 3,
    note: 'A full floor in a business centre.'
  },
  {
    id: 'hq',
    n: 'Headquarters',
    rentM: 320000,
    desks: 120,
    rooms: 8,
    note: 'A proper HQ. Costs a lot, looks the part.'
  }
];
const HQ_ROLES = {
  pa: ['Personal assistant', 36000, 'Your right hand: one extra week on every decision, a seat on every board, briefings, and decisions for you when you do not answer.'],
  hr: ['HR manager', 52000, 'Fewer quits and fewer problem workers across all your companies.'],
  acc: ['Group accountant', 62000, 'Cuts external accountant fees by 20% in all companies.'],
  law: ['In-house lawyer', 78000, 'Cuts fines and outside legal fees by about 15%.'],
  ana: ['Data analyst', 64000, 'Unlocks detailed analytics: demand drivers and capacity limits for every company.'],
  perf: ['Performance analyst', 68000, 'Tracks every manager. Monthly scorecards, and reviews whenever you ask.'],
  mkt: ['Marketing director', 66000, 'Campaigns across your companies work about 10% better.'],
  proc: [
    'Procurement manager',
    58000,
    'Finds the best supplier deals for every manager and keeps supplier relationships warm.'
  ],
  strat: ['Strategy analyst', 70000, 'A quarterly memo with 2 to 3 concrete suggestions per company.']
};
function officeTier() {
  return S.office ? OFFICE_T.find(t => t.id === S.office.tier) : null;
}
function staffDesks(t) {
  return t.desks;
}
function hasHQ(role) {
  return !!(S && S.office && S.office.staff && S.office.staff.some(x => x.role === role));
}
function officeRent(tier, city) {
  const infl = Math.pow(1 + S.econ.infl, S.week / 52);
  return rl(tier.rentM * cityOf(city).rent * infl);
}
function deskUse() {
  return (S.office ? S.office.staff.length : 0) + S.group.regional.length + (S.group.ceo ? 1 : 0);
}
function rentOffice(tierId, city) {
  const t = OFFICE_T.find(x => x.id === tierId);
  if (!t) return 'bad';
  const old = S.office;
  const o = {
    tier: tierId,
    city: city || S.player.city,
    since: S.week,
    staff: old ? old.staff : [],
    rep: old ? old.rep : { freq: 4, detail: 'short', only: 'managed' }
  };
  if (o.staff.length + S.group.regional.length + (S.group.ceo ? 1 : 0) > staffDesks(t)) return 'desks';
  if (old && old.tier !== tierId) payMe(Math.round(officeRent(t, o.city) * 1), 'Office move: first month deposit');
  S.office = o;
  return 'ok';
}
function hqRoom(role) {
  if (!S.office) return 'office';
  if (!hqRole(role)) return 'bad';
  if (!hqUnlocked(role)) return 'locked';
  if (hasHQ(role)) return 'have';
  if (S.office.tier === 'home') return role === 'pa' ? 'ok' : 'homeoffice';
  if (deskUse() >= staffDesks(officeTier())) return 'desks';
  return 'ok';
}
function hireHQnpc(role, n, wage) {
  const r = hqRoom(role);
  if (r !== 'ok') return r;
  if (n.hired) return 'taken';
  if (wage < n.ask * 0.82 && !chance(0.1)) return 'refuse';
  const p = clamp((wage / n.ask - 0.86) / 0.18, 0, 1);
  if (!chance(p) && wage < n.ask) return 'refuse';
  n.hired = -3;
  S.office.staff.push({ id: n.id, role, name: n.name, wage, w0: S.week, onb: {} });
  return 'ok';
}
function fireHQ(id) {
  if (!S.office) return;
  const n = S.npcs[id];
  if (n) n.hired = 0;
  S.office.staff = S.office.staff.filter(x => x.id !== id);
}
function setReports(o) {
  if (!S.office) S.office = {
    tier: 'home',
    since: S.week,
    staff: [],
    rep: { freq: 4, detail: 'short', only: 'managed' },
    city: S.player.city
  };
  Object.assign(S.office.rep, o);
}
function officeMonth() {
  if (!S.office) return;
  const t = officeTier();
  let c = officeRent(t, S.office.city) * (1 + 0.02);
  S.office.staff.forEach(x => {
    c += x.wage * OC();
  });
  if (c > 0) payHQ(c, 'Main office and its staff');
  S.office.staff.forEach(x => {
    if (!x.onb) return;
    const m = onbMissing({ role: 'hq_' + x.role, onb: x.onb });
    if (m.length && S.week - x.w0 >= 3 && chance(0.035 * m.length)) {
      const f = Math.round(rng(8000, 25000) * (hasHQ('law') ? 0.85 : 1));
      payMe(f, 'Paperwork fine: main office staff');
      news('Inspectors fined you ' + money(f) + ' for missing paperwork at your main office.');
    }
  });
}
function repSettings() {
  return S.office ? S.office.rep : { freq: 4, detail: 'short', only: 'managed' };
}


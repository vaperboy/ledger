/* ---- src/management/managers.js ---- */
/* ===== Managers, authority, regional managers, board packs ===== */
/* decision routing: chain = company manager -> the company's managing director (or its holding's) -> regional
   manager -> group CEO -> owner (the managing director: features/people/management_team.js) */
/* who stands above a company's manager, lowest first (round 56):
   store manager -> regional manager -> chain manager -> CEO (one per chain) -> managing director (the group);
   above them the board and you. A company outside a chain has its own managing director (TEAM56) and the group's. */
/* a duty the manager looks after unless you keep it (co.duty56[k] = 0): 'sec' IT security, 'ins' insurance,
   'prem' asking to expand the premises (features/people/manager_duties.js) */
function mgrDuty(co, k) {
  return !co.duty56 || co.duty56[k] !== 0;
}
function chainOf(co) {
  const ch = [], N = x => x && S.npcs[x.npc];
  if (co.mgr && S.npcs[co.mgr]) ch.push({ kind: 'mgr', npc: S.npcs[co.mgr], lvl: co.auth.lvl, buy: co.auth.buy });
  const chn = window.R12 && R12.chainOf ? R12.chainOf(co) : null;
  if (chn) {
    const L = S.group.regional || [], area = L.find(r => r.scope === 'chain:' + chn.id + ':' + co.city), cm = L.find(r => r.scope === 'chain:' + chn.id);
    if (N(area)) ch.push({ kind: 'region', npc: N(area), lvl: area.lvl, buy: area.buy, rg: area });
    if (N(cm)) ch.push({ kind: 'chainmgr', npc: N(cm), lvl: cm.lvl, buy: cm.buy, rg: cm });
    if (N(chn.ceo56)) ch.push({ kind: 'ceo56', npc: N(chn.ceo56), lvl: chn.ceo56.lvl, buy: chn.ceo56.buy });
  } else {
    const md = co.team && N(co.team.ceo) ? co.team.ceo : (() => { const h = co.hold && getCo(co.hold); return h && h.team && N(h.team.ceo) ? h.team.ceo : null; })();
    if (md) ch.push({ kind: 'mdir', npc: N(md), lvl: md.lvl, buy: md.buy });
    const rg = co.region ? S.group.regional.find(r => r.id === co.region) : null;
    if (N(rg)) ch.push({ kind: 'region', npc: N(rg), lvl: rg.lvl, buy: rg.buy, rg });
  }
  const gm = (S.org56 && S.org56.md) || S.group.ceo;
  if (N(gm)) ch.push({ kind: 'md', npc: N(gm), lvl: gm.lvl, buy: gm.buy });
  return ch;
}
function cost0(opts) {
  return Math.max.apply(null, opts.map(o => -(o.fx.cash || 0) - Math.abs(o.fx.loss || 0) - (o.fx.fine || 0) - (o.cost || 0)));
}
function decider(co, opts, extraCost) {
  const ch = chainOf(co);
  if (!ch.length) return { by: 'owner' };
  const cost = Math.max(extraCost || 0, cost0(opts));
  const big = S.group.big;
  if (cost > big) return { by: 'ask', asker: ch[0], big: 1 };
  for (let i = 0; i < ch.length; i++) {
    const c = ch[i];
    if (c.lvl >= 2 || (c.lvl === 1 && cost <= c.buy)) return { by: 'mgr', who: c };
  }
  return { by: 'ask', asker: ch[ch.length - 1] };
}
function setAuth(co, lvl, buy, hire, ad) {
  co.auth.lvl = clamp(lvl, 0, 2);
  if (buy != null) co.auth.buy = buy;
  if (hire != null) co.auth.hire = hire;
  if (ad != null) co.auth.ad = ad;
}
/* weekly manager behaviour */
/* managerWeek: the core below, then the steps features add: pipeSteps('managerWeek') */
function managerWeek(co, bd, ctx) {
  return runSteps('managerWeek', managerWeekCore(co, bd, ctx), co, bd, ctx);
}
function managerWeekCore(co, bd, ctx) {
  if (!co.mgr || !S.npcs[co.mgr]) return;
  const n = S.npcs[co.mgr];
  const q = mgrQual(co);
  co.mgrQ = q;
  co.flags.mgrCool = Math.max(0, (co.flags.mgrCool || 0) - 1);
  // honesty problems
  if (n.stats.ethic < 45 && chance(0.004 * (1 - n.stats.ethic / 100))) {
    const steal = Math.round(ctx.rev * rng(0.01, 0.04));
    payCo(co, steal, 'loss', 'Unexplained expense');
    co.flags.fraud = (co.flags.fraud || 0) + steal;
    if (chance(0.35)) note('An audit flags unexplained expenses at ' + co.name + ' (' + money(steal) + '). Check your manager.', 'bad', co.id);
  }
  // raise demand
  if ((S.week - (co.mgrW0 || 0)) % 52 === 51 && chance(0.7)) {
    const ask = rnl(co.mgrWage * 0.06, 100);
    addMsg({
      kind: 'ask',
      from: n.name,
      title: n.name + ' asks for a raise at ' + co.name,
      body: 'A year in the role, they want +' + money(ask) + ' per month (6%).',
      co: co.id,
      opts: [
        { l: 'Grant the raise', d: '+' + money(ask) + '/month', fx: {} },
        { l: 'Decline', d: 'They may leave', fx: {} }
      ],
      act: 'mgrraise',
      data: { ask },
      exp: S.week + 3
    });
  }
  mgrStaffWork(co, bd, n, q);
  if (S.week % 3 !== 0 || co.flags.mgrCool > 0) {
    return;
  }
  const dp = decideProposal(co, bd, ctx, n, q);
  if (dp) {
    const pk = dp.t + (dp.id || dp.role || '');
    co.flags.propLast = co.flags.propLast || {};
    const open = S.inbox.some(m => m.co === co.id && m.status === 'open' && m.act === 'prop' && m.data && m.data.t === dp.t);
    if (!open && S.week - (co.flags.propLast[pk] != null ? co.flags.propLast[pk] : -99) >= 20) {
      co.flags.propLast[pk] = S.week;
      co.flags.mgrCool = 3;
      makeProposal(co, dp, n, q);
    }
  }
  // routine small tuning always done by manager if authority exists
  if (co.auth.lvl >= 1) tune(co, bd, ctx, q);
}
function decideProposal(co, bd, ctx, n, q) {
  if (ctx.util == null || !ctx.cap) return null;
  const sense = 1 + gauss() * 0.24 * (1 - q);
  {
    const std = stdStaff(bd, co.size || 1);
    let tot = 0, have = 0, miss = null;
    std.forEach(x => {
      const h = co.staff.filter(w => w.role === x[0] && !w.notice).length;
      tot += x[1];
      have += Math.min(h, x[1]);
      if (!miss && h < x[1] && ROLES[x[0]]) miss = x[0];
    });
    /* hire only when the manager sees enough demand to pay for the extra person */
    const dd = (co.dbg && co.dbg.D != null ? co.dbg.D : ctx.D) * sense, cp = co.dbg && co.dbg.cap ? co.dbg.cap : ctx.cap;
    const wage = miss && ROLES[miss] ? wageFor(miss, co) * OC() : 0;
    const perHead = cp / Math.max(1, co.staff.length || 1);
    const extraUnits = Math.max(0, Math.min(perHead, dd - cp * 0.85));
    const margin = (ctx.price ? ctx.price * (1 - (ctx.cr != null ? ctx.cr : 0.4)) : 0);
    const pays = margin > 0 ? extraUnits * margin > wage * 0.9 : dd > cp * 0.95;
    if (miss && dd > cp * 0.85 && pays) return { t: 'hire', role: miss, cost: wageFor(miss, co) * 12 * OC() };
  }
  const dbg = co.dbg;
  if (!dbg) return null;
  const over = dbg.D * sense > dbg.cap * 1.12 && ctx.util > 0.9;
  const bo = dbg.botObj;
  if (over && bo) {
    if (bo.kind === 'staff') {
      const role = bo.k.split(':')[1];
      if (ROLES[role]) return { t: 'hire', role, cost: wageFor(role, co) * 12 * OC() };
    }
    if (bo.kind === 'equip') {
      const e = bd.eq.find(x => 'eq:' + x.id === bo.k);
      if (e && !e.vo) return { t: 'eq', id: e.id, cost: eqPrice(co, e) };
      if (e && e.vo) return { t: 'veh', id: e.id, cost: VEH[e.vo[0]][1] * 0.5 };
    }
    if (bo.kind === 'space' && mgrDuty(co, 'prem')) return { t: 'space', cost: PREM[co.prem.kind][1] * cityOf(co.city).rent * co.prem.m2 * 0.25 };
  }
  if (ctx.util < 0.5 && co.staff.length > 2 && co.cash > 0 && ctx.D < dbg.cap * 0.62) return { t: 'cut', cost: 0 };
  if (co.aware < 26 && co.cash > coWeekCost(co) * 6) return { t: 'ad', cost: KC(2500, co.country) };
  if (co.cash < coWeekCost(co) * 2 && co.cash < KC(50000, co.country)) return { t: 'cash', cost: 0 };
  return null;
}
function makeProposal(co, dp, n, q) {
  const bd = BD[co.type];
  const ch = chainOf(co);
  const dec = decider(co, [{ fx: {} }], dp.cost);
  const doIt = () => execProposal(co, dp, n, q);
  const title = proposalTitle(co, dp, bd);
  const afford = dp.t !== 'hire' ? co.cash > (dp.cost || 0) * 0.5 + coWeekCost(co) * 6 : hireShort(co, dp.cost || 0) <= 0;
  /* a manager never spends on growth alone: a boss with his own margins decides if there is one, otherwise it comes to the owner */
  /* round 56: within the budget you gave them (co.auth.buy), a manager buys the equipment or hires the person the
     business is short of without waiting for an answer, when the company can afford it */
  if ((dp.t === 'eq' || dp.t === 'veh' || dp.t === 'hire') && (co.auth.lvl || 0) >= 1 && afford && (dp.t === 'hire' ? (dp.cost || 0) / 12 : dp.cost || 0) <= (co.auth.buy || 0)) {
    doIt();
    if (dp.t !== 'hire') note(n.name + ' ' + (dp.t === 'veh' ? 'added a vehicle' : 'bought equipment') + ' at ' + co.name + ' within the budget you set: customers were being turned away.', 'n', co.id);
    return;
  }
  /* round 56: the boss above the manager judges it first and only passes on what is above their budget or a close
     call (features/company/chain_hierarchy.js) */
  if (window.CHN56 && !(dec.by === 'ask' && dec.big) && CHN56.decide(co, dp, n, title, doIt, afford)) return;
  const opts = dp.t === 'cut' ? [
    { l: 'Approve: let someone go', d: 'Cut payroll; severance applies.', fx: {} },
    { l: 'Keep staff', d: '', fx: {} }
  ] : dp.t === 'cash' ? [
    { l: 'Inject {m:100000}', d: 'From your personal account.', fx: {} },
    { l: 'Inject {m:30000}', d: '', fx: {} },
    { l: 'Not now', d: 'Cash may run out.', fx: {} }
  ] : [
    {
      l: 'Approve',
      d: dp.t === 'hire' ? (() => {
        const need = propNeed(co, dp);
        return need > 0 ? 'Puts in about ' + money(need) + ' from your account' : 'The company can cover it';
      })() : dp.cost ? 'About ' + money(dp.cost) : '',
      fx: {}
    },
    { l: 'Decline', d: '', fx: {} }
  ];
  const ab = aboveMgr(co);
  const frm = ab ? ab.npc.name : n.name;
  const why = proposalWhy(co, dp, bd) + (dp.t === 'hire' && !afford ? ' We cannot afford it from the cash we have.' : '') + (ab ? ' ' + n.name + ' (' + titleFor(co, 'mgr') + ') asked for this.' : '') + (dp.view56 ? ' ' + dp.view56 : '');
  addMsg({
    kind: 'ask',
    from: frm,
    role: ab ? titleFor(co, ab.kind) : titleFor(co, 'mgr'),
    title,
    body: why,
    co: co.id,
    opts,
    act: 'prop',
    data: dp,
    exp: S.week + 3,
    by: 'ask',
    asker: dec.asker ? dec.asker.kind : 'mgr'
  });
}
/* money the player must put in to approve a hire proposal (0 = the company can cover it) */
function propNeed(co, dp) {
  return dp.t === 'hire' ? hireShort(co, dp.cost || 0) : 0;
}
/* cash missing before a hire costing `cost` a year is safe. A company whose profit already pays the new wage
   only needs a buffer of six weeks of that wage plus two weeks of running costs; a weak one needs half a year of it. */
/* How much money is missing before a manager can safely hire someone costing `cost` a year. When the hire clearly
   pays for itself (gain: the extra profit a year it brings, at least 1.2 times its cost, as when customers are being
   turned away), a month of their pay and two weeks of running costs is enough, and half the overdraft counts.
   Otherwise the company keeps the usual cushion: six weeks of pay if profit covers it, else half a year. */
function hireShort(co, cost, gain) {
  const wk = cost / 52, last = co.hist && co.hist.length ? co.hist[co.hist.length - 1] : null;
  if (gain && gain >= cost * 1.2) return Math.max(0, Math.round(wk * 4.33 + coWeekCost(co) * 2 - co.cash - coOverdraft(co) * 0.5));
  const wkProfit = last ? (last.profit || 0) / 4.33 : 0;
  const need = wkProfit >= wk * 0.8 ? wk * 6 + coWeekCost(co) * 2 : cost * 0.5 + coWeekCost(co) * 6;
  return Math.max(0, Math.round(need - co.cash));
}
/* why an option cannot be chosen right now, or '' */
function optBlock(m, i) {
  if (m.act === 'prop' && i === 0 && m.data && m.data.t === 'hire') {
    const co = getCo(m.co), need = co ? propNeed(co, m.data) : 0;
    if (need > liquid()) return 'Needs ' + money(need) + ' from your account; you have ' + money(Math.max(0, liquid())) + '.';
  }
  return '';
}
function proposalTitle(co, dp, bd) {
  return dp.t === 'hire' ? 'Hire a ' + ROLES[dp.role][0] + ' at ' + co.name : dp.t === 'eq' ? 'Buy ' + bd.eq.find(e => e.id === dp.id).n + ' for ' + co.name : dp.t === 'veh' ? 'Add a vehicle at ' + co.name : dp.t === 'space' ? 'Expand the premises of ' + co.name : dp.t === 'cut' ? 'Reduce staffing at ' + co.name : dp.t === 'ad' ? 'Start advertising at ' + co.name : 'Cash is running low at ' + co.name;
}
function proposalWhy(co, dp, bd) {
  const d = co.dbg || {};
  const f = v => !isFinite(v) ? '?' : v < 10 ? (Math.round(v * 10) / 10 + '').replace('.', ',') : Math.round(v) + '';
  const u = bd.unit || 'job';
  return dp.t === 'hire' ? (d.D > d.cap * 1.03
    ? 'Customers want about ' + rateW(d.D, u) + ', but we can only do ' + rateW(d.cap, u) + '. What holds us back: ' + (d.bot || 'staff') + '.'
    : 'We are almost fully booked (' + rateW(d.D, u) + ' wanted, room for ' + rateW(d.cap, u) + '). Another ' + ROLES[dp.role][0].toLowerCase() + ' would let us take on more work.') : dp.t === 'eq' || dp.t === 'veh' || dp.t === 'space' ? 'We are turning customers away. The bottleneck is ' + (d.bot || 'capacity') + '.' : dp.t === 'cut' ? 'We use less than half our capacity.' : dp.t === 'ad' ? 'Awareness is very low, few people know about us.' : 'About ' + Math.max(0, Math.round(co.cash / Math.max(1, coWeekCost(co)))) + ' weeks of costs left.';
}
function execProposal(co, dp, n, q) {
  const bd = BD[co.type];
  if (dp.t === 'hire') {
    const cands = searchWorkers(co, dp.role, 'ads');
    cands.sort((a, b) => ((b.claimSkill - b.ask / 1500) - (a.claimSkill - a.ask / 1500)) + gauss() * 8 * (1 - q));
    const c = cands[0];
    if (hireWorker(co, c, c.ask) === 'ok') {
      managerOnboard(co, co.staff[co.staff.length - 1]);
    }
    if (c.hired === co.id) note(n.name + ' hired ' + c.name + ' (' + ROLES[dp.role][0] + ') at ' + co.name + '.', 'good', co.id);
  }
  else if (dp.t === 'eq') {
    const r = buyEq(co, dp.id, 1, 'new');
    if (r === 'ok') note(n.name + ' bought equipment for ' + co.name + '.', 'n', co.id); else if (r === 'cash' && (!co.flags.cashAsk || S.week - co.flags.cashAsk > 8)) {
      co.flags.cashAsk = S.week;
      addMsg({
        kind: 'info',
        from: n.name,
        role: titleFor(co, 'mgr'),
        title: 'Could not buy equipment',
        body: 'I could not buy the equipment for ' + co.name + ': not enough cash. Put money in or tell me to wait.',
        co: co.id,
        tone: 'bad',
        status: 'done'
      });
    }
  }
  else if (dp.t === 'veh') {
    const e = bd.eq.find(x => x.id === dp.id);
    const r = buyVeh(co, dp.id, e.vo[0], 'finance');
    if (r === 'ok') note(n.name + ' financed a vehicle for ' + co.name + '.', 'n', co.id);
  }
  else if (dp.t === 'space') {
    const add = Math.round(co.prem.m2 * 0.25);
    co.prem.m2 += add;
    if (co.prem.owned) {
      const dv = add * PREM[co.prem.kind][2] * cityOf(co.city).rent;
      payCo(co, dv, null, 'Extension of the premises');
      co.prem.val += dv;
    } else {
      payCo(co, (dp.cost || 0) * 0.5, 'oth', 'Fit-out of the extra space'); /* rent is per m2, so the bigger space costs more by itself */
    }
    note(n.name + ' expanded the premises of ' + co.name + ' by ' + add + ' m2.', 'n', co.id);
  }
  else if (dp.t === 'cut') {
    const s = co.staff.slice().sort((a, b) => staffSkill({ id: a.id, skillGain: a.skillGain }) - staffSkill({ id: b.id, skillGain: b.skillGain }))[0];
    if (s) {
      fireStaff(co, s.id);
      note(n.name + ' reduced staffing at ' + co.name + '.', 'n', co.id);
    }
  }
  else if (dp.t === 'ad') {
    const ch = bd.aud > 0.5 ? 'google' : 'meta';
    setMkt(co, ch, 1500);
    note(n.name + ' started ' + CH[ch].n + ' ads for ' + co.name + '.', 'n', co.id);
  }
  else if (dp.t === 'cash') {
    /* cash needs owner */
    info(co.name, 'Cash is low at ' + co.name, 'Your manager ' + n.name + ' recommends putting in money or taking a loan.', co.id, 'bad');
  }
}
ACTS.prop = (m, idx) => {
  const co = getCo(m.co);
  if (!co) return true;
  const dp = m.data;
  const n = S.npcs[co.mgr];
  if (dp.t === 'cash') {
    if (idx === 0) {
      if (!injectCash(co, KC(100000))) return false;
    } else if (idx === 1) {
      if (!injectCash(co, KC(30000))) return false;
    }
    return true;
  }
  if (idx === 0 && n) {
    if (dp.t === 'hire') {
      const need = propNeed(co, dp);
      if (need > 0 && !injectCash(co, need)) return false;
    }
    execProposal(co, dp, n, mgrQual(co));
  }
  return true;
};
ACTS.mgrraise = (m, idx) => {
  const co = getCo(m.co);
  if (!co) return true;
  if (idx === 0) {
    co.mgrWage += m.data.ask;
    co.mood = Math.min(100, (co.mood != null ? co.mood : 60) + 8);
  } else {
    co.mood = Math.max(0, (co.mood != null ? co.mood : 60) - 10);
  }
  if (idx === 0) { /* raise given */ } else if (chance(0.55)) {
    mgrResign(co, 'without the raise I have to look elsewhere');
  }
  return true;
};
ACTS.hire = ACTS.prop;
ACTS.staffx = (m, idx) => {
  const co = getCo(m.co);
  if (!co) return true;
  const d = m.data;
  const s = co.staff.find(x => x.id === d.sid);
  if (!s) return true;
  if (d.t === 'payask') {
    if (idx === 0 || idx === 1) raiseStaff(co, s.id, idx === 0 ? d.big : d.small);
    else s.denied = S.week;
    return true;
  }
  if (d.t === 'fixask') {
    if (idx === 0) { setFixedPay(co, s); s.happy = Math.max(s.happy || 0, S.week + 26); }
    else s.denied = S.week;
    return true;
  }
  if (idx === 0) {
    if (d.t === 'raise') raiseStaff(co, s.id, Math.max(0, d.w / s.wage - 1));
    else if (d.t === 'promo') promoteStaff(co, d.sid, d.role);
  } else if (d.t === 'raise') s.denied = S.week;
  return true;
};
/* tune: steps before ('tune.before') and after ('tune.after') share ph (ph.r is the result): pipeSteps('tune.after') */
function tune(co, bd, ctx, q) {
  return runPhased('tune', [co, bd, ctx, q], () => tuneCore(co, bd, ctx, q));
}
function tuneCore(co, bd, ctx, q) {
  // small autonomous adjustments by a manager with authority
  if (S.week - (co.flags.priceAt || -99) < 10) { /* prices were just changed */ }
  else if (ctx.util > 0.97 && co.price < 2 && chance(0.25 * q)) {
    co.flags.priceAt = S.week;
    co.price += 1;
    note(S.npcs[co.mgr].name + ' raised prices at ' + co.name + '.', 'n', co.id);
  }
  else if (ctx.util < 0.55 && co.price > -1 && chance(0.2 * q)) {
    co.flags.priceAt = S.week;
    co.price -= 1;
    note(S.npcs[co.mgr].name + ' lowered prices at ' + co.name + ' to fill capacity.', 'n', co.id);
  }
  if (co.eqc < 0.55 && co.maint < 1) co.maint = 1;
  if (co.aware < 35 && Object.keys(co.mkt).length === 0 && co.cash > coWeekCost(co) * 6 && co.auth.ad >= 1000 && chance(0.3)) {
    const ch = bd.aud > 0.5 ? 'google' : 'meta';
    setMkt(co, ch, Math.min(co.auth.ad, 1500));
  }
}
/* board pack at month end */
/* boardPack: the core below, then the steps features add: pipeSteps('boardPack') */
function boardPack(co) {
  return runSteps('boardPack', boardPackCore(co), co);
}
function boardPackCore(co) {
  const b = co.bk.m;
  const rev = b.rev || 0, profit = rev - sumExp(b);
  const n = co.mgr ? S.npcs[co.mgr] : null;
  const lines = [
    'Revenue ' + money(rev) + ', profit ' + money(profit) + ' (' + (rev ? pc(profit / rev, 0) : '-') + ').',
    'Cash ' + money(co.cash) + '. Reputation: ' + repWord(co.rep).toLowerCase() + '. Quality: ' + qualWord(co.q).toLowerCase() + '.'
  ];
  if (co.dbg) lines.push('Utilisation ' + pc(co.lastW ? co.lastW.util || 0 : 0, 0) + ', bottleneck: ' + (co.dbg.bot || '-') + '.');
  if (co.flags.fraud && n) lines.push('Warning: unexplained costs of ' + money(co.flags.fraud) + ' this year.');
  return {
    title: 'Board pack: ' + co.name + ' (' + monthStr(S.week) + ')',
    body: lines.join(' '),
    from: n ? n.name : co.name,
    co: co.id,
    tone: profit >= 0 ? 'good' : 'bad'
  };
}
/* group structure: executives (chain chiefs; a group CEO or group-wide regional manager hired in older games) */
function genExec(kind) {
  const n = genManager(null, 'gen');
  n.exec = kind;
  {
    const cap = fameSkillCap();
    ['ops', 'fin'].forEach(k => {
      if (n.stats[k] > cap) n.stats[k] = cap;
    });
    n.ask = rnl(n.ask * fameSalary(), 100);
  }
  const sc = kind === 'ceo' ? 2.8 : 1.7;
  n.ask = rnl(n.ask * sc, 1000);
  n.stats.ops = clamp(n.stats.ops + 8, 5, 99);
  n.stats.fin = clamp(n.stats.fin + 6, 5, 99);
  return n;
}
function groupWagesMonth() {
  let t = 0;
  S.group.regional.forEach(r => {
    if (!r.payCo) t += r.wage; /* a regional manager hired by one company is on that company's payroll */
  });
  if (S.group.ceo) t += S.group.ceo.wage;
  return t * OC();
}
/* the owner asks the manager for a change; he answers in the inbox */
const ASK_OPTS = [
  ['price_up', 'Raise prices a little'],
  ['price_down', 'Lower prices a little'],
  ['hire', 'Hire more people'],
  ['cut', 'Cut staff costs'],
  ['mkt_more', 'Spend more on marketing'],
  ['mkt_less', 'Spend less on marketing'],
  ['quality', 'Improve maintenance and quality'],
  ['save', 'Reduce running costs']
];
/* askManager: steps before ('askManager.before') and after ('askManager.after') share ph (ph.r is the result): pipeSteps('askManager.after') */
function askManager(co, k) {
  return runPhased('askManager', [co, k], () => askManagerCore(co, k));
}
function askManagerCore(co, k) {
  const n = co.mgr ? S.npcs[co.mgr] : null;
  if (!n) return 'none';
  const bd = BD[co.type];
  const q = mgrQual(co);
  let say = '';
  if (co.askW != null && S.week - co.askW < 2) say = 'Give me a couple of weeks to see how the last change works out.';
  else {
    co.askW = S.week;
    const util = co.lastW ? co.lastW.util || 0 : 0;
    if (k === 'price_up') {
      if (co.price >= 2) say = 'We are already at the top of what the market accepts.'; else {
        co.price++;
        say = util < 0.6 ? 'Done, but demand is soft, so we may lose some customers.' : 'Done. We have room for it.';
      }
    }
    else if (k === 'price_down') {
      if (co.price <= -3) say = 'We are already the cheapest around. Going lower only eats the margin.'; else {
        co.price--;
        say = 'Done. We should see more customers.';
      }
    }
    else if (k === 'hire') {
      const std = stdStaff(bd, co.size || 1);
      let role = null;
      std.forEach(x => {
        if (!role && co.staff.filter(w => w.role === x[0] && !w.notice).length < x[1] && ROLES[x[0]]) role = x[0];
      });
      if (!role && std[0]) role = std[0][0];
      const cost = role ? wageFor(role, co) * 12 * OC() : 0;
      if (!role) say = 'I do not see who we would need.'; else if (hireShort(co, cost) > 0) say = 'A new ' + ROLES[role][0].toLowerCase() + ' costs about ' + money(cost / 12) + ' a month. To hire safely we need about ' + money(hireShort(co, cost)) + ' more in the company. Put that in under Finance and ask me again.'; else {
        execProposal(co, { t: 'hire', role, cost }, n, q);
        say = 'I am hiring a ' + ROLES[role][0].toLowerCase() + ' now.';
      }
    }
    else if (k === 'cut') {
      if (co.staff.length <= 1) say = 'We are down to the bone already.'; else {
        execProposal(co, { t: 'cut', cost: 0 }, n, q);
        say = 'I let one person go. Expect a little less capacity.';
      }
    }
    else if (k === 'mkt_more') {
      const ch = bd.aud > 0.5 ? 'google' : 'meta';
      const cur = co.mkt[ch] ? co.mkt[ch].b : 0;
      const next = CH[ch].opts.find(o => o > cur);
      if (!next) say = 'We are already spending the most that channel makes sense for.'; else {
        const r = setMkt(co, ch, next);
        say = r === 'ok' ? 'I raised the ' + CH[ch].n + ' budget to ' + money(next) + ' a week.' : 'I could not change the budget right now.';
      }
    }
    else if (k === 'mkt_less') {
      const act = Object.keys(co.mkt).filter(x => co.mkt[x] && co.mkt[x].b);
      if (!act.length) say = 'We are not spending anything on marketing.'; else {
        const ch = act[0];
        const lower = CH[ch].opts.slice().reverse().find(o => o < co.mkt[ch].b) || 0;
        const r = setMkt(co, ch, lower);
        say = r === 'ok' ? 'I cut ' + CH[ch].n + ' to ' + (lower ? money(lower) + ' a week' : 'nothing') + '.' : 'Some of it is locked in for now.';
      }
    }
    else if (k === 'quality') {
      if (co.maint >= 2) say = 'We already maintain everything thoroughly.'; else {
        co.maint++;
        say = 'Done. It costs more, but breakdowns should drop.';
      }
    }
    else if (k === 'save') {
      if (co.maint <= 0) say = 'There is nothing left to trim without hurting the business.'; else {
        co.maint--;
        say = 'I will trim upkeep. Quality may slip a little.';
      }
    }
  }
  addMsg({
    kind: 'info',
    from: n.name,
    role: titleFor(co, 'mgr'),
    title: 'Re: ' + co.name,
    body: say,
    co: co.id,
    tone: 'n',
    status: 'done'
  });
  return 'ok';
}


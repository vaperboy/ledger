/* ---- src/management/meetings.js ---- */
/* Meetings with managers, and reports from the data analyst */
const MEET_GOALS = [
  ['review', 'Go through the results'],
  ['growth', 'Push for growth'],
  ['costs', 'Cut costs'],
  ['quality', 'Raise quality'],
  ['morale', 'Boost morale'],
  ['pay', 'Talk about pay']
];
const MEET_SEV = [['casual', 'A casual chat'], ['serious', 'A serious talk'], ['final', 'A final warning']];
function meetCos(who) {
  return who === 'all' ? liveCos().filter(c => c.mgr && S.npcs[c.mgr] && c.st !== 'sold') : [getCo(who)].filter(c => c && c.mgr && S.npcs[c.mgr]);
}
function meetOne(co, goal, sev) {
  const n = S.npcs[co.mgr];
  const first = n.name.split(' ')[0];
  const bd = BD[co.type];
  const tone = sev === 'casual' ? 0 : sev === 'serious' ? 1 : 2;
  const steps = tone ? 2 : 1;
  let say = '';
  co.mood = co.mood != null ? co.mood : 60;
  co.meetW = S.week;
  const run = k => {
    for (let i = 0; i < steps; i++) {
      co.askW = null;
      askManagerQuiet(co, k);
    }
  };
  if (goal === 'review') {
    const b = co.bk && co.bk.m ? co.bk.m : {};
    const rev = b.rev || 0, pr = rev - sumExp(b);
    say = 'Last month we took in ' + money(rev) + ' and ' + (pr >= 0 ? 'made ' + money(pr) : 'lost ' + money(-pr)) + '. ' + (co.lastW && co.lastW.util != null ? 'We are running at about ' + Math.round(co.lastW.util * 100) + '% of what we can deliver. ' : '') + (pr < 0 ? 'I know it needs to turn around.' : 'I will keep it on track.');
  }
  else if (goal === 'growth') {
    run('mkt_more');
    say = 'Understood. I will push harder for customers' + (tone ? ' and I know you expect results' : '') + '. It will cost more in marketing first.';
    if (tone === 2) {
      co.price = Math.max(-2, co.price - 1);
    }
  }
  else if (goal === 'costs') {
    run('save');
    if (tone) run('mkt_less');
    if (tone === 2) askManagerQuiet(co, 'cut');
    say = tone === 2 ? 'I will cut where I can, including staff. Quality may suffer.' : 'I will look for savings without hurting the service.';
  }
  else if (goal === 'quality') {
    run('quality');
    say = 'I will spend more on upkeep and standards. Costs go up a little, complaints should go down.';
  }
  else if (goal === 'morale') {
    co.mood = Math.min(100, co.mood + (tone === 0 ? 10 : 4));
    say = tone === 2 ? 'I would rather hear that in a different way, but I will try.' : 'Thank you. It means something to the team to hear that.';
  }
  else if (goal === 'pay') {
    if (tone === 2) {
      co.mgrWage = Math.round(co.mgrWage * 0.95);
      say = 'A pay cut. I will remember that.';
    } else {
      co.mgrWage = Math.round(co.mgrWage * (tone ? 1.03 : 1.05));
      say = 'Thank you, that is fair.';
    }
    co.mood = Math.min(100, co.mood + (tone === 2 ? -15 : 8));
  }
  if (tone === 1) co.mood -= 3;
  if (tone === 2) co.mood -= 10;
  let quit = false;
  if (tone === 2 && co.mood < 30 && chance(0.3)) {
    quit = true;
    mgrResign(co, 'after the final warning I do not see a future here');
  }
  addMsg({
    kind: 'info',
    from: n.name,
    role: quit ? '' : titleFor(co, 'mgr'),
    title: quit ? 'I resign' : 'After the meeting: ' + co.name,
    body: quit ? 'After that meeting I cannot continue. I am handing in my notice.' : first + ': ' + say,
    co: co.id,
    tone: quit ? 'bad' : 'n',
    status: 'done'
  });
  return quit ? 'quit' : 'ok';
}
function askManagerQuiet(co, k) {
  const n0 = S.inbox.length;
  askManager(co, k);
  if (S.inbox.length > n0) S.inbox.splice(n0);
}
function callMeeting(who, goal, sev) {
  const cos = meetCos(who);
  if (!cos.length) return 'none';
  const fresh = cos.filter(c => c.meetW == null || S.week - c.meetW >= 3);
  if (!fresh.length) return 'wait';
  fresh.forEach(c => meetOne(c, goal, sev));
  return 'ok';
}
/* a report from your data analyst, delivered on the Stats app and as a message */
function analystReport(who) {
  if (!hasHQ('ana')) return 'noana';
  S.areports = S.areports || [];
  const cos = who === 'all' ? liveCos().filter(c => c.st === 'open') : [getCo(who)].filter(Boolean);
  if (!cos.length) return 'none';
  const an = S.office.staff.find(x => x.role === 'ana');
  const out = [];
  cos.forEach(co => {
    const ol = marketOutlook(co);
    const h = ol ? ol.hist : [];
    const u = co.lastW && co.lastW.util != null ? co.lastW.util : null;
    const ln = [];
    if (h.length >= 6) {
      const a = sum(h.slice(-4), x => x) / 4, b = sum(h.slice(-8, -4), x => x) / Math.max(1, h.slice(-8, -4).length);
      if (b > 0) ln.push('Sales over the last four weeks are ' + (a >= b ? 'up ' : 'down ') + Math.round(Math.abs(a / b - 1) * 100) + '% on the four before.');
    }
    if (u != null) ln.push(u > 0.95 ? 'We are at the limit of what we can deliver and turn people away.' : u < 0.5 ? 'We use less than half our capacity.' : 'We use about ' + Math.round(u * 100) + '% of our capacity.');
    if (co.dbg && co.dbg.bot) ln.push('The weakest link is ' + co.dbg.bot + '.');
    if (ol) {
      const m = (ol.lift[0] + ol.lift[1]) / 2;
      ln.push('Our brand adds about ' + Math.round(m * 100) + '% to demand' + (ol.top ? '.' : ' (a rough estimate).'));
      if (ol.fc.length) {
        const e = ol.fc[ol.fc.length - 1], l = h.length ? h[h.length - 1] : 0;
        if (l > 0) ln.push('In two months I expect weekly sales ' + (e >= l ? 'around ' + Math.round((e / l - 1) * 100) + '% higher' : 'around ' + Math.round((1 - e / l) * 100) + '% lower') + '.');
      }
    }
    out.push({ co: co.id, name: co.name, lines: ln, hist: h, fc: ol ? ol.fc : [] });
  });
  S.areports.unshift({ w: S.week, who: who === 'all' ? 'all' : cos[0].id, items: out });
  if (S.areports.length > 6) S.areports.length = 6;
  addMsg({
    kind: 'info',
    from: an ? an.name : 'Data analyst',
    role: 'Data analyst',
    title: who === 'all' ? 'Report: all companies' : 'Report: ' + cos[0].name,
    body: out.map(o => o.name + ': ' + o.lines.join(' ')).join('\n'),
    tone: 'n',
    status: 'done'
  });
  return 'ok';
}


/* ---- src/events/engine.js ---- */
/* ===== Events, messages, effects ===== */
function avgWk(co) {
  const h = co.hist.slice(-3);
  if (h.length) return Math.max(sum(h, x => x.rev) / (h.length * 4.35), 1000);
  return co.lastW ? Math.max(co.lastW.rev, 1000) : 3000;
}
function evCtx(co) {
  return {
    co,
    bd: BD[co.type],
    wk: avgWk(co),
    pay: sum(co.staff, s => s.wage) * 12 / 52 * OC(),
    eqv: co.eqv || eqBook(co) || 50000
  };
}
function resolveFx(fx, c) {
  const o = {};
  for (const k in fx) {
    const v = fx[k];
    if (typeof v === 'function') o[k] = Math.round(v(c)); else if (k === 'gamble') o[k] = { p: v.p, ok: resolveFx(v.ok || {}, c), bad: resolveFx(v.bad || {}, c) }; else o[k] = v;
  }
  return o;
}
function fxText(fx) {
  const t = [];
  if (fx.cash) t.push((fx.cash < 0 ? 'Pay ' : 'Receive ') + money(Math.abs(fx.cash)));
  if (fx.loss) t.push('Loss ' + money(Math.abs(fx.loss)));
  if (fx.fine) t.push('Fine ' + money(fx.fine));
  if (fx.rep) t.push(fx.rep > 0 ? (fx.rep >= 5 ? 'Reputation improves a lot' : 'Reputation improves a little') : (fx.rep <= -5 ? 'Reputation suffers badly' : 'Reputation dips'));
  if (fx.dem) t.push((fx.dem[0] >= 1 ? 'Demand up' : 'Demand down') + ' for ' + fx.dem[1] + ' wk');
  if (fx.cap) t.push('Capacity x' + fx.cap[0] + ' for ' + fx.cap[1] + ' wk');
  if (fx.raise) t.push('Pay +' + Math.round(fx.raise * 100) + '%');
  if (fx.close) t.push('Closed ' + fx.close + ' wk');
  if (fx.gamble) t.push('Uncertain: ' + Math.round(fx.gamble.p * 100) + '% good outcome');
  return t.join(' · ');
}
let MSGID = 0;
/* addMsg: the core below, then the steps features add: pipeSteps('addMsg') */
function addMsg(m) {
  return runSteps('addMsg', addMsgCore(m), m);
}
function addMsgCore(m) {
  if (m.co && !m.role) {
    const c = getCo(m.co);
    if (c) {
      const mg = c.mgr && S.npcs[c.mgr];
      if (mg && mg.name === m.from) m.role = titleFor(c, 'mgr'); else {
        const ab = aboveMgr(c);
        if (ab && ab.npc.name === m.from) m.role = titleFor(c, ab.kind);
      }
    }
  }
  m.from = locText(m.from);
  m.title = locText(m.title);
  m.body = locText(m.body);
  if (m.opts) m.opts.forEach(o => {
    o.l = locText(o.l);
    o.d = locText(o.d);
  });
  m.id = uid();
  m.w = S.week;
  m.dn = S.week * 7 + (S.day || 0);
  /* the channel is fixed when it arrives (ui/screens/home.js): a text from someone you know or from the team of your
     own company (the company name as sender), otherwise an email */
  if (!m.ch) {
    const c0 = m.co && getCo(m.co);
    const staffOf = nm => S.cos.some(c => (c.staff || []).some(x => S.npcs[x.id] && S.npcs[x.id].name === nm));
    m.ch = isKnownMsg(m) || (c0 && m.from === c0.name) || (m.from && staffOf(m.from)) ? 'msg' : 'mail';
  }
  if (m.exp && m.kind === 'decision' && hasHQ('pa')) {
    m.exp += 1;
    m.pa = 1;
  }
  m.status = m.status || 'open';
  m.read = 0;
  S.inbox.unshift(m);
  /* conversations keep their history: the oldest answered messages go once there are more than 300 */
  if (S.inbox.length > 300) {
    for (let i = S.inbox.length - 1; i >= 0; i--) if (S.inbox[i].status !== 'open') {
      S.inbox.splice(i, 1);
      if (S.inbox.length <= 260) break;
    }
  }
  return m;
}
function info(from, title, body, co, tone) {
  return addMsg({ kind: 'info', from, title, body, co: co || 0, tone: tone || 'n', status: 'done' });
}
const SOLO_CUST = { g_late: 1, g_review: 1, g_lawsuit: 1, g_offer: 1, c_scope: 1, c_clientloss: 1, c_damage: 1, c_wedding: 1, c_malprac: 1, c_patient: 1, v_critic: 1, v_poison: 1, v_overbook: 1, v_injury: 1, v_churn: 1, v_bigwin: 1, v_cheat: 1, v_addict: 1, r_return: 1, p_defect: 1, p_nopay: 1, p_leak: 1, rn_nopay: 1, rn_pet: 1, rn_vacant: 1, rn_anchor: 1, pr_cust: 1, pr_bigcontract: 1, f_fund: 1 };
const SOLO_MKT = { g_press: 1, g_award: 1, v_ota: 1 };
function soloCo(co) {
  return !co.staff.length && !co.mgr;
}
function soloOk(e, co) {
  if (SOLO_CUST[e.id]) return true;
  if (SOLO_MKT[e.id]) return Object.keys(co.mkt || {}).some(k => co.mkt[k] && co.mkt[k].b > 0);
  return false;
}
function spawnEvents(co, bd) {
  if (co.flags.evCool > 0) {
    co.flags.evCool--;
  }
  const risk = knobFx(co, 'r');
  const c = evCtx(co);
  const sizeAdj = 1;
  bd.ev.forEach(id => {
    const e = EV[id];
    if (!e) return;
    if (e.minWeek && S.week - co.w0 < e.minWeek) return;
    if ((e.tone === 'good' || e.id === 'g_press' || e.id === 'g_offer') && !(co.lastW && co.lastW.units > 0.5 && co.wOpen != null && S.week - co.wOpen >= 12)) return; /* praise, awards and big orders need real customers */
    if (!co.staff.length && (/employee|staff|worker|colleague/i.test(e.t) || e.opts.some(o => o.fx && (o.fx.quit || o.fx.raise || o.fx.sick)))) return;
    if (soloCo(co) && !soloOk(e, co)) return;
    let p = e.w * risk * sizeAdj * 0.6 * (e.cond ? e.cond(c) : 1);
    if (p <= 0 || !chance(p)) return;
    if (e.opts.length && co.flags.evCool > 0) return;
    co.flags.evCool = e.opts.length ? 6 : co.flags.evCool;
    fireEvent(co, bd, e, c);
  });
}
/* fireEvent: a 'fireEvent.before' step can stop an event (ph.no) or note something for 'fireEvent.after' */
function fireEvent(co, bd, e, c) {
  return runPhased('fireEvent', [co, bd, e, c], () => fireEventCore(co, bd, e, c));
}
function fireEventCore(co, bd, e, c) {
  c = c || evCtx(co);
  const SP = SPEC[e.id];
  if (SP) {
    SP(co, bd, e, c);
    return;
  }
  let title = e.t.replace('{n}', co.name).replace('{eq}', pickEqName(co, bd));
  if (e.auto && e.fx) {
    applyFx(co, resolveFx(e.fx, c), c, e);
    info(co.name, title, '', co.id, e.tone);
    note(title, e.tone, co.id);
    return;
  }
  if (!e.opts.length) {
    note(title, e.tone, co.id);
    return;
  }
  if (e.lawyer && co.law && co.law.own) {
    title += ' Your law firm handles it, costs drop.';
  }
  const opts = e.opts.map(o => ({ l: o.l, d: o.d, fx: resolveFx(o.fx, c) }));
  const dec = decider(co, opts);
  const m = {
    kind: 'decision',
    from: co.name,
    title,
    co: co.id,
    tone: e.tone,
    opts,
    cat: e.cat,
    ev: e.id,
    exp: S.week + e.exp,
    by: dec.by
  };
  if (dec.by === 'mgr') {
    const pick = chooseOpt(co, opts, dec.who.npc);
    m.status = 'done';
    m.pick = pick;
    m.mgrName = dec.who.npc.name;
    addMsg(m);
    applyFx(co, opts[pick].fx, c, e);
    note(co.name + ': ' + dec.who.npc.name + ' handled "' + title + '" by choosing: ' + opts[pick].l + '.', 'n', co.id);
  }
  else {
    if (dec.asker) {
      m.ask = 1;
      m.rec = chooseOpt(co, opts, dec.asker.npc);
      m.mgrName = dec.asker.npc.name;
    }
    addMsg(m);
    note('Decision needed: ' + title, e.tone, co.id);
  }
}
function pickEqName(co, bd) {
  const items = [];
  bd.eq.forEach(e => {
    if ((e.vo ? co.veh.some(v => v.eq === e.id) : co.eq[e.id])) items.push(e.n);
  });
  return items.length ? pick(items) : 'A key machine';
}
function scoreFx(co, fx, c) {
  let s = 0;
  const wk = c.wk;
  const add = f => {
    s += (f.cash || 0) - Math.abs(f.loss || 0) * (hasInsCat(co, null) ? 1 : 1) - (f.fine || 0);
    s += (f.rep || 0) * wk * 0.5;
    s += (f.aware || 0) * wk * 0.15;
    if (f.dem) s += (f.dem[0] - 1) * wk * f.dem[1] * 0.45;
    if (f.cap) s += (f.cap[0] - 1) * wk * f.cap[1] * 0.5;
    if (f.close) s -= wk * f.close * 0.8;
    if (f.raise) s -= c.pay * f.raise * 20;
    if (f.quit) s -= wk * 0.8;
    if (f.pr) s -= wk * 0.3;
  };
  add(fx);
  if (fx.gamble) {
    const g = fx.gamble;
    const a = [0, 0];
    let st = s;
    s = st;
    const sv = s;
    s = 0;
    add(g.ok);
    const sok = s;
    s = 0;
    add(g.bad);
    const sbad = s;
    s = sv + g.p * sok + (1 - g.p) * sbad;
  }
  return s;
}
function hasInsCat() {
  return false;
}
function chooseOpt(co, opts, who) {
  const c = evCtx(co);
  const q = who && who.stats ? (who.stats.ops * 0.4 + who.stats.fin * 0.3 + who.stats.risk * 0.3) / 100 : mgrQual(co);
  const sc = opts.map(o => scoreFx(co, o.fx, c) + gauss() * c.wk * (1.2 - q) * 0.4);
  let b = 0;
  for (let i = 1; i < sc.length; i++) if (sc[i] > sc[b]) b = i;
  return b;
}
function resolveMsg(id, idx) {
  const m = S.inbox.find(x => x.id === id);
  if (!m || m.status !== 'open') return false;
  const co = getCo(m.co);
  const c = co ? evCtx(co) : null;
  const o = m.opts ? m.opts[idx] : null;
  if (!o) return false;
  if (m.kind === 'decision' && co) applyFx(co, o.fx, c, EV[m.ev] || {});
  else if (m.act) {
    const r = runAct(m, idx);
    if (r === false) return false;
  }
  m.status = 'done';
  m.pick = idx;
  m.read = 1;
  return true;
}
function expireMsgs() {
  S.inbox.forEach(m => {
    if (m.status === 'open' && m.exp && S.week >= m.exp) {
      const co = getCo(m.co);
      if (!co && m.kind === 'decision') {
        m.status = 'done';
        return;
      }
      if (m.kind === 'decision') {
        let bi = 0, best = -1e18;
        m.opts.forEach((o, i) => {
          const v = -(Math.abs(o.fx.cash || 0));
          if (v > best) {
            best = v;
            bi = i;
          }
        });
        const o = m.opts[bi];
        applyFx(co, o.fx, evCtx(co), EV[m.ev] || {});
        m.status = 'done';
        m.pick = bi;
        m.auto = 1;
        note('No answer in time on "' + m.title + '". Default taken: ' + o.l + '.', 'bad', co.id);
      } else if (m.act) {
        m.status = 'done';
        m.pick = -1;
        m.auto = 1;
      }
    }
  });
}
function applyFx(co, fx, c, e) {
  if (!fx) return;
  c = c || evCtx(co);
  const cat = e && e.cat || 'none';
  if (fx.gamble) {
    const g = fx.gamble;
    applyFx(co, chance(g.p) ? g.ok : g.bad, c, e);
  }
  if (fx.cash) {
    const fc = Number.isInteger(fx.cash) && Math.abs(fx.cash) % 1000 === 0 ? KC(fx.cash, co.country) : fx.cash;
    if (fc < 0) payCo(co, -fc, 'oth', 'Event cost'); else coIn(co, fc, 'rev', 'Event income');
  }
  if (fx.loss) {
    const amt = Math.abs(fx.loss);
    const cover = cat !== 'none' && co.ins[cat];
    let net = amt;
    if (cover) {
      const ded = INSP[cat] ? INSP[cat][4] : 10000;
      net = Math.min(amt, KC(ded, co.country));
      let paid = amt - net;
      if (chance(1 - insrPay(co)) && paid > 0) {
        paid = Math.round(paid * rng(0.3, 0.7));
        note('Your insurer paid only part of the claim at ' + co.name + '.', 'bad', co.id);
      }
      const insr = S.cos.find(x => x.type === 'insco' && x.st === 'open' && x.id !== co.id);
      if (paid > 0) {
        if (insr && co.insr && co.insr.own) {
          payCo(insr, paid, 'oth', 'Claim paid for ' + co.name);
          insr.fm.claims = (insr.fm.claims || 0) + paid;
        }
        coIn(co, paid, null, 'Insurance payout');
        bk(co, 'loss', -paid);
      }
    }
    payCo(co, amt, 'loss', 'Loss: ' + (EV[e && e.id] ? 'incident' : 'damage'));
    if (cover && amt > net) { /* payout already credited */ }
  }
  if (fx.coord) {
    co.flags.coll = 1;
    co.price = clamp(co.price + 1, -3, 3);
    const mm = S.mk[mkKey(co)];
    if (mm) mm.pi = Math.min(1.4, mm.pi + 0.04);
  }
  if (fx.warn) addMod(co, 'dem', 0.93, 6);
  if (fx.fine) {
    const fl = (co.country && deskFor(co.country) ? 0.85 : 1);
    payCo(co, (Number.isInteger(fx.fine) && fx.fine % 1000 === 0 ? KC(fx.fine, co.country) : fx.fine) * fl, 'fine', 'Fine');
    if (hasHQ('law')) note('Your in-house legal team cut the fine at ' + co.name + ' by about ' + money(fx.fine * fl * 0.15) + '.', 'good', co.id);
  }
  if (fx.rep) co.rep = clamp(co.rep + fx.rep * 1.5, 0, 100);
  if (fx.aware) co.aware = clamp(co.aware + fx.aware, 0, 100);
  if (fx.q) co.q = clamp(co.q + fx.q, 0, 100);
  if (fx.dem) {
    let dm = fx.dem[0];
    if (fx.needCap && co.lastW && co.lastW.util > 0.9) dm = 1 + (dm - 1) * 0.35;
    addMod(co, 'dem', dm, fx.dem[1]);
  }
  if (fx.cap) addMod(co, 'cap', fx.cap[0], fx.cap[1]);
  if (fx.price) addMod(co, 'price', fx.price[0], fx.price[1]);
  if (fx.cogsUp) addMod(co, 'cogsup', fx.cogsUp[0], fx.cogsUp[1]);
  if (fx.pr) {
    co.price = clamp(co.price + fx.pr, -3, 3);
  }
  if (fx.fixeq) fixWorn(co, fx.fixeq);
  if (fx.brk) breakEq(co);
  if (fx.quit && co.staff.length) {
    const s = co.staff.slice().sort((a, b) => (b.wage - a.wage))[rint(0, co.staff.length - 1)];
    note(S.npcs[s.id].name + ' left ' + co.name + '.', 'bad', co.id);
    co.staff = co.staff.filter(x => x !== s);
    S.npcs[s.id].hired = 0;
  }
  if (fx.raise) {
    let who = co.staff;
    if (fx.stay != null && co.staff.length) {
      co.flags.raiseOne = pick(co.staff);
      who = [co.flags.raiseOne];
    }
    who.forEach(s => {
      s.wage = rnl(s.wage * (1 + fx.raise), 100);
    });
    if (co.mgr && fx.raise > 0.09 && fx.stay == null) {
      co.mgrWage = rnl(co.mgrWage * (1 + fx.raise), 100);
    }
    if (fx.stay != null && !chance(fx.stay) && co.staff.length) {
      const s = co.flags.raiseOne && co.staff.indexOf(co.flags.raiseOne) >= 0 ? co.flags.raiseOne : pick(co.staff);
      co.staff = co.staff.filter(x => x !== s);
      S.npcs[s.id].hired = 0;
      note(S.npcs[s.id].name + ' left anyway.', 'bad', co.id);
    }
  }
  if (fx.bonus) payCo(co, fx.bonus, 'wages', 'Bonus');
  if (fx.close) {
    if (co.st === 'open') {
      const bi = co.ins.bi;
      if (bi) {
        const pay = c.wk * 0.6 * fx.close;
        coIn(co, pay, null, 'Business-interruption cover');
        bk(co, 'rev', pay);
      }
      co.st = 'closed';
      co.closeW = fx.close;
      co.closeTot = fx.close;
    }
  }
  if (fx.stock) {
    const l = Math.round(co.inv * fx.stock);
    co.inv -= l;
    payCo(co, l * 0.0, 'loss');
    bk(co, 'loss', l);
  }
  if (fx.collect != null) {
    const r = co.recv.find(x => x.bad) || co.recv.slice().sort((a, b) => b.a - a.a)[0];
    if (r) {
      if (chance(fx.collect)) {
        coIn(co, r.a, null, 'Collected invoice');
      } else recvLoss(co, r.a);
      co.recv = co.recv.filter(x => x !== r);
    }
  }
  if (fx.loseR) {
    const r = co.recv[0];
    if (r) {
      const cut = Math.round(r.a * fx.loseR);
      recvLoss(co, cut);
      r.a -= cut;
      r.bad = false;
      r.due = S.week;
    }
  }
  if (fx.writeoff) {
    const r = co.recv.find(x => x.bad) || co.recv[0];
    if (r) {
      recvLoss(co, r.a);
      co.recv = co.recv.filter(x => x !== r);
    }
  }
  if (fx.doc) {
    if (co.docs[fx.doc]) co.docs[fx.doc].st = 'lapsed';
  }
  if (fx.secure) co.flags.secure = 1;
  if (fx.riskUp) co.flags.riskUp = 1;
  if (fx.riskDown) co.flags.riskDown = 1;
  if (fx.licRisk) co.flags.licRisk = (co.flags.licRisk || 0) + 1;
  if (fx.owner) {
    if (fx.owner > 0) gainMe(fx.owner, 'Event'); else payMe(-fx.owner, 'Event');
  }
  if (fx.news) news(co.name + ': ' + fx.news, 'n');
  const F = FAM[BD[co.type].fam];
  if (F && F.fx) F.fx(co, BD[co.type], fx);
  if (fx.sell) {
    addMsg({
      kind: 'info',
      from: co.name,
      title: 'You may consider selling ' + co.name + '.',
      body: 'Selling is under Money › Ownership and value in the company.',
      co: co.id,
      go: { l: 'Sell the company', a: 'go', p: { n: 'sale', p: { id: co.id } } },
      status: 'done'
    });
  }
}
function fixWorn(co, lvl) {
  let w = null, wc = 2;
  for (const id in co.eq) {
    if (id === 'fit') continue;
    if (co.eq[id].cond < wc) {
      wc = co.eq[id].cond;
      w = co.eq[id];
    }
  }
  co.veh.forEach(v => {
    if (v.cond < wc) {
      wc = v.cond;
      w = v;
    }
  });
  if (w) w.cond = lvl >= 2 ? 1 : Math.max(w.cond, 0.75);
}
function breakEq(co) {
  const arr = [];
  for (const id in co.eq) if (id !== 'fit') arr.push(co.eq[id]);
  co.veh.forEach(v => arr.push(v));
  if (arr.length) pick(arr).cond *= 0.5;
}
/* specials: auto-resolved events with custom logic */
const SPEC = {};
SPEC.g_review = (co, bd, e, c) => {
  const d = (co.q - 55) / 18 + gauss() * 0.9;
  const r = clamp(Math.round(d), -3, 3);
  if (!r) return;
  co.rep = clamp(co.rep + r * 0.8, 0, 100);
  co.aware = clamp(co.aware + r * 2, 0, 100);
  const t = r > 0 ? 'Good reviews boost ' + co.name + ' (+' + r + ').' : 'Bad reviews hurt ' + co.name + ' (' + r + ').';
  note(t, r > 0 ? 'good' : 'bad', co.id);
};
SPEC.v_critic = SPEC.g_review;
SPEC.g_award = (co) => {
  co.rep = clamp(co.rep + 3, 0, 100);
  co.aware = clamp(co.aware + 6, 0, 100);
  note(co.name + ' wins a local business award!', 'good', co.id);
  info(co.name, 'Award won', 'Your reputation rises.', co.id, 'good');
};
SPEC.g_audit = (co, bd, e, c) => {
  const yrProf = Math.max(0, (co.bk.y.rev || 0) - sumExp(co.bk.y)) * (52 / Math.max(8, wWeekOfYear()));
  const aq = co.acc ? co.acc.q : 0.45;
  const err = co.acc ? co.acc.err : 0.15;
  if (chance(err * 1.8 + (1 - aq) * 0.25)) {
    const pen = Math.round(Math.max(6000, yrProf * 0.04) * (1.3 - aq));
    payCo(co, pen, 'fine', 'Tax audit adjustment');
    info('{auth:tax}', 'Audit finished for ' + co.name, 'The auditors found errors. Adjustment and penalty: ' + money(pen) + '.', co.id, 'bad');
    note('Tax audit at ' + co.name + ': errors found, ' + money(pen) + ' to pay.', 'bad', co.id);
  }
  else {
    info('{auth:tax}', 'Audit finished for ' + co.name, 'No issues. ' + (co.acc ? co.acc.name + ' kept the books clean.' : ''), co.id, 'good');
    note('Tax audit at ' + co.name + ': all clear.', 'good', co.id);
  }
};
SPEC.g_inspect = (co, bd, e, c) => {
  const bad = !docOk(co, 'hms') && bd.docs.indexOf('hms') >= 0;
  const mq = co.mgr ? mgrQual(co) : 0.55;
  const p = 0.18 + (1 - mq) * 0.25 + (1 - co.q / 100) * 0.2 + (bad ? 0.5 : 0) + (co.flags.shrinkUp ? 0.05 : 0);
  if (chance(p)) {
    const f = Math.round(Math.max(8000, c.wk * 0.2));
    payCo(co, f, 'fine', 'Inspection fine');
    note('Inspectors found issues at ' + co.name + ': fine ' + money(f) + '.', 'bad', co.id);
    info('{auth:lab}', 'Inspection at ' + co.name, 'Deviations were found. Fine ' + money(f) + '. Improve routines and training.', co.id, 'bad');
  }
  else {
    note('Inspection at ' + co.name + ': passed.', 'good', co.id);
  }
};
SPEC.v_health = (co, bd, e, c) => {
  const hq = co.q / 100 + (docOk(co, 'haccp') ? 0.12 : -0.2) + (co.mgr ? mgrQual(co) * 0.1 : 0) + (co.maint === 0 ? -0.08 : 0);
  if (chance(clamp(0.5 - hq, 0.02, 0.8))) {
    const f = Math.round(Math.max(12000, c.wk * 0.25));
    payCo(co, f, 'fine', 'Food safety fine');
    co.rep = clamp(co.rep - 3, 0, 100);
    note('{auth:food} found hygiene deviations at ' + co.name + ': fine ' + money(f) + '.', 'bad', co.id);
    info('{auth:food}', 'Inspection at ' + co.name, 'Deviations in hygiene routines. Fine ' + money(f) + '.', co.id, 'bad');
  }
  else {
    co.rep = clamp(co.rep + 0.5, 0, 100);
    note('{auth:food} visits ' + co.name + ': passed.', 'good', co.id);
  }
};
SPEC.v_bigwin = (co, bd, e, c) => {
  const hi = knobFx(co, 'risk') || 1;
  const m = rng(0.25, 1.4) * hi * (co.fm.vol || 1);
  const amt = Math.round(c.wk * m);
  payCo(co, amt, 'loss', 'Big payout');
  note('A lucky player wins big at ' + co.name + ': ' + money(amt) + ' paid out.', 'bad', co.id);
};
SPEC.c_market = (co, bd, e, c) => {
  const h = S.econ.housing;
  if (h < 0.98) addMod(co, 'dem', clamp(0.8 + (h - 0.9) * 1.2, 0.6, 1), 12);
};
SPEC.d_market = (co, bd, e, c) => {
  const h = S.econ.housing;
  if (chance(0.5)) {
    S.econ.housing = clamp(h * (1 + gauss() * 0.012), 0.7, 1.5);
    note('The housing market moves: price index ' + S.econ.housing.toFixed(2) + '.', S.econ.housing > h ? 'good' : 'bad', co.id);
  }
};
SPEC.f_storm = (co, bd, e, c) => {
  if (co.fm.prem == null && !co.fm.pol) return;
  const prem = (co.fm.premW || co.lastW && co.lastW.rev || 50000);
  const amt = Math.round(prem * rng(2, 7) * knobFx(co, 'r'));
  payCo(co, amt, 'loss', 'Storm claims');
  co.fm.claims = (co.fm.claims || 0) + amt;
  news('A winter storm triggers insurance claims across the region.', 'bad');
  note('Storm claims hit ' + co.name + ': ' + money(amt) + '.', 'bad', co.id);
};
SPEC.f_run = (co, bd, e, c) => {
  if (!co.fm.dep) return;
  const out = co.fm.dep * rng(0.04, 0.16) * (bd.tw.bank && co.knob.liq === 1 ? 1.5 : 1) * (1.1 - mgrQual(co) * 0.2);
  co.fm.dep -= out;
  co.fm.depPrev = (co.fm.depPrev || 0) - out;
  moveCash(co, -(out));
  note('Rumours trigger withdrawals at ' + co.name + ': ' + money(out) + ' of deposits leave.', 'bad', co.id);
};
SPEC.f_default = (co, bd, e, c) => {
  if (!co.fm.book) return;
  const loss = co.fm.book * rng(0.004, 0.02) * knobFx(co, 'r');
  co.fm.book -= loss;
  bk(co, 'loss', loss);
  note('Loan losses at ' + co.name + ': ' + money(loss) + ' written off.', 'bad', co.id);
};
SPEC.e_price = (co, bd, e, c) => {
  if (bd.tw.oil) {
    const m = clamp(1 + gauss() * 0.14, 0.6, 1.5);
    S.econ.oil = clamp(S.econ.oil * m, 0.3, 2.5);
    news('Oil price ' + (m > 1 ? 'jumps' : 'falls') + ': index ' + S.econ.oil.toFixed(2) + '.', m > 1 ? 'good' : 'bad');
  } else {
    const m = clamp(1 + gauss() * 0.2, 0.55, 1.7);
    S.econ.power = clamp(S.econ.power * m, 0.3, 3);
    news('Power prices ' + (m > 1 ? 'spike' : 'drop') + ': index ' + S.econ.power.toFixed(2) + '.', m > 1 ? 'good' : 'bad');
  }
};
SPEC.e_geo = (co, bd) => {
  if (co.fm.prospects && co.fm.prospects.length) {
    const p = pick(co.fm.prospects);
    p.vol *= clamp(1 + gauss() * 0.25, 0.5, 1.8);
    note('New data revises prospect "' + p.name + '" to ' + Math.round(p.vol / 1000) + ' k barrels.', 'n', co.id);
  }
};

function wWeekOfYear() {
  const d = wDate(S.week);
  const y0 = Date.UTC(d.getUTCFullYear(), 0, 1);
  return Math.max(1, Math.floor((d - y0) / (7 * DAY)) + 1);
}
function runAct(m, idx) {
  const A = ACTS[m.act];
  if (!A) return true;
  return A(m, idx);
}
const ACTS = {};
function unreadCount() {
  return S.inbox.filter(m => m.status === 'open').length;
}


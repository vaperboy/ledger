/* ---- src/events/library.js ---- */
/* ===== Event library (company-level problems and chances). =====
   fx keys (numbers or functions of ctx c = {co,bd,wk,pay,eqv,mk}):
   cash, rep, aware, dem:[mult,weeks], cap:[mult,weeks], brk, quit, sick, fine, loss(insurable by cat), stock (fraction lost), close (weeks),
   fixeq (repair break), owner (personal cash), doc:id(lapse), cust, ovr (project overrun fraction), defect, bigwin(casino multiplier),
   ill (fish/animal disease fraction), price:[mult,weeks] (supplier/commodity), tenant, vac, news                                         */
const EV = {};
function ev(id, w, t, opts, o) {
  EV[id] = Object.assign({ id, w, t, opts: opts || [], cat: 'none', tone: 'bad', exp: 2, cond: null }, o || {});
}
const WK = c => Math.max(3000, c.wk), PAY = c => Math.max(4000, c.pay);
/* generic */
ev('g_break', 0.022, '{eq} has broken down at {n}.', [
  {
    l: 'Repair now',
    d: 'Pay for a quick fix. Back in a day or two.',
    fx: { cash: c => -Math.max(2500, c.eqv * 0.04), fixeq: 1 }
  },
  {
    l: 'Run without it for two weeks',
    d: 'Save the money, lose capacity.',
    fx: { cap: [0.78, 2], cash: c => -Math.max(1500, c.eqv * 0.02), fixeq: 1 }
  },
  {
    l: 'Replace with a new unit',
    d: 'Costs more, resets condition to like-new.',
    fx: { cash: c => -Math.max(6000, c.eqv * 0.14), fixeq: 2 }
  }
], { cat: 'prop', cond: c => 1 + (1 - c.co.eqc) * 1.5 });
ev('g_quit', 0.012, 'An employee at {n} has handed in notice.', [
  {
    l: 'Counter-offer a raise (+8%)',
    d: 'They may stay. Costs ongoing payroll.',
    fx: { raise: 0.08, stay: 0.7 }
  },
  { l: 'Let them go and hire a replacement', d: 'Notice period, then recruitment time.', fx: { quit: 1 } }
], { cond: c => 0.7 + (1 - c.co.mgrQ) * 0.6 + c.co.payGap * 2 });
ev('g_sick', 0.008, 'A key person at {n} is on long-term sick leave.', [
  {
    l: 'Cover with overtime and temps',
    d: 'Costs extra but keeps operating.',
    fx: { cash: c => -PAY(c) * 0.5 }
  },
  { l: 'Run short-staffed', d: 'Capacity drops for a few weeks.', fx: { cap: [0.82, 4] } }
], { exp: 1 });
ev('g_late', 0.016, 'A customer at {n} is paying very late and disputes an invoice.', [
  {
    l: 'Send a collection notice',
    d: 'Pay a fee. Likely to get paid but may lose the customer.',
    fx: { collect: 0.85, cash: -1500, rep: -1 }
  },
  { l: 'Negotiate a 15% discount', d: 'Get cash quickly.', fx: { collect: 1, loseR: 0.15 } },
  { l: 'Write it off', d: 'Absorb the loss and move on.', fx: { writeoff: 1 } }
], { exp: 3 });
ev('g_review', 0.014, 'A wave of customer reviews about {n}.', [], { auto: 1, tone: 'n', cond: c => 1 });
ev('g_theft', 0.012, 'Theft and shrinkage at {n}.', [
  {
    l: 'Upgrade security (camera/locks)',
    d: 'Costs now and cuts future losses.',
    fx: { cash: c => -Math.max(6000, c.eqv * 0.03), loss: c => Math.max(3000, WK(c) * 0.1), secure: 1 }
  },
  { l: 'Accept the loss', d: 'Do nothing.', fx: { loss: c => Math.max(4000, WK(c) * 0.18) } }
], { cat: 'prop' });
ev('g_supply', 0.012, 'Your main supplier is raising prices at {n}.', [
  { l: 'Accept the increase', d: 'Costs up ~5% for two months.', fx: { price: [1.05, 8] } },
  {
    l: 'Switch supplier',
    d: 'Lose a week of sales while moving; costs back to normal.',
    fx: { dem: [0.9, 1], price: [1.0, 1], cash: -3000 }
  },
  {
    l: 'Pass it on to customers',
    d: 'Keep margin, some customers leave.',
    fx: { dem: [0.96, 8], price: [1.05, 8] }
  }
]);
ev('g_it', 0.012, 'IT outage hits {n} for several days.', [
  {
    l: 'Pay for emergency support',
    d: 'Fix it fast.',
    fx: { cash: c => -Math.max(4000, WK(c) * 0.08), cap: [0.9, 1] }
  },
  { l: 'Wait for the standard fix', d: 'Slow and costly in lost sales.', fx: { cap: [0.7, 2] } }
], { cat: 'cyber', exp: 1 });
ev('g_audit', 0.007, '{auth:tax} wants to audit the books of {n}.', [], { auto: 1, cat: 'none', cond: c => 0.6 + c.co.books * 0.6 });
ev('g_inspect', 0.01, 'Authorities visit {n} for an unannounced inspection.', [], { auto: 1, cond: c => 1 });
ev('g_fire', 0.003, 'A fire or flood damages the premises of {n}.', [
  {
    l: 'Close while repairs run',
    d: 'Insurance covers if you have it.',
    fx: { close: 3, loss: c => Math.max(60000, c.eqv * 0.22) }
  },
  {
    l: 'Partial reopen with a temporary setup',
    d: 'Less lost revenue, more hassle.',
    fx: { cap: [0.5, 4], loss: c => Math.max(60000, c.eqv * 0.22), cash: -8000 }
  }
], { cat: 'prop', exp: 1 });
ev('g_rival', 0.012, 'A new competitor opens near {n}.', [
  { l: 'Cut prices 5% for a while', d: 'Defend share, thinner margin.', fx: { dem: [0.97, 10], pr: -1 } },
  { l: 'Invest in marketing ({m:8000})', d: 'Lift awareness.', fx: { cash: -8000, aware: 8 } },
  { l: 'Ignore them', d: 'They take a slice of your customers.', fx: { dem: [0.93, 12] } }
], { tone: 'n' });
ev('g_union', 0.006, 'Staff at {n} are asking for higher wages; the union is involved.', [
  { l: 'Agree to a 5% raise', d: 'Permanent increase to payroll.', fx: { raise: 0.05, stay: 1 } },
  {
    l: 'Offer 2% and a bonus',
    d: 'Risk a short walk-out.',
    fx: { raise: 0.02, bonus: c => PAY(c) * 0.5, cap: [0.8, 1] }
  },
  { l: 'Refuse', d: 'A strike hits you for a few weeks.', fx: { cap: [0.4, 3], rep: -2 } }
]);
ev('g_lawsuit', 0.005, 'A customer is suing {n}.', [
  {
    l: 'Settle quietly',
    d: 'Pay now, avoid a trial.',
    fx: { loss: c => Math.max(20000, WK(c) * 0.35), rep: 0 }
  },
  {
    l: 'Fight in court (lawyer fees)',
    d: 'Might win, might lose big.',
    fx: {
      cash: c => -Math.max(15000, WK(c) * 0.15),
      gamble: { p: 0.55, ok: {}, bad: { loss: c => Math.max(60000, WK(c) * 0.9), rep: -3 } }
    }
  }
], { cat: 'liab', exp: 3, lawyer: 1 });
ev('g_offer', 0.01, 'A big customer offers {n} a large order.', [
  {
    l: 'Accept (needs spare capacity)',
    d: 'Revenue boost for a month, but you must deliver.',
    fx: { dem: [1.4, 5], needCap: 1 }
  },
  {
    l: 'Accept at a better price',
    d: 'May walk away.',
    fx: { dem: [1.15, 5], gamble: { p: 0.5, ok: { dem: [1.3, 5] }, bad: { dem: [1, 1] } } }
  },
  { l: 'Decline', d: 'Stay focused.', fx: {} }
], { tone: 'good', exp: 2 });
ev('g_award', 0.005, '{n} wins a local business award.', [], { auto: 1, tone: 'good', cond: c => 0.3 + c.co.rep / 80 });
ev('g_press', 0.006, 'Local media wants to feature {n}.', [
  {
    l: 'Do the interview',
    d: 'Free exposure, depends on how you perform.',
    fx: { gamble: { p: 0.65, ok: { rep: 3, aware: 8 }, bad: { rep: -2 } } }
  },
  { l: 'Decline', d: '', fx: {} }
], { tone: 'good', exp: 2 });
ev('g_grant', 0.005, 'Innovation Norge has a grant window that fits {n}.', [
  {
    l: 'Apply ({m:6000} in consultant help)',
    d: '35% chance of a NOK grant worth about 8 weeks of revenue.',
    fx: { cash: -6000, gamble: { p: 0.35, ok: { cash: c => WK(c) * 8, news: 'Grant approved.' }, bad: {} } }
  },
  { l: 'Skip it', d: '', fx: {} }
], { tone: 'good', exp: 3, minWeek: 8 });
/* families */
ev('c_scope', 0.014, 'A client at {n} keeps expanding the scope of a fixed-price job.', [
  {
    l: 'Hold the line and bill extras',
    d: 'Risk of friction.',
    fx: { gamble: { p: 0.6, ok: { cash: c => WK(c) * 0.6 }, bad: { rep: -2, lose: 1 } } }
  },
  { l: 'Absorb it for the relationship', d: 'Lose hours.', fx: { cash: c => -WK(c) * 0.3, rep: 1 } }
], { exp: 2 });
ev('c_clientloss', 0.01, 'A major client leaves {n} for a competitor.', [
  {
    l: 'Offer a retention discount',
    d: 'Might keep them.',
    fx: { gamble: { p: 0.45, ok: {}, bad: { dem: [0.88, 8] } }, cash: c => -WK(c) * 0.3 }
  },
  { l: 'Let them go', d: 'Lose a big chunk of demand.', fx: { dem: [0.86, 8] } }
]);
ev('c_damage', 0.012, 'A customer claims {n} damaged their car.', [
  { l: 'Pay for the repair', d: '', fx: { loss: -3500 } },
  {
    l: 'Dispute it',
    d: 'Photos might back you up.',
    fx: { gamble: { p: 0.5, ok: {}, bad: { loss: -7000, rep: -2 } } }
  }
], { cat: 'liab' });
ev('c_gear', 0.01, 'Photo gear is stolen from the car at {n}.', [
  { l: 'File an insurance claim', d: '', fx: { loss: -28000 } },
  { l: 'Replace with used gear', d: 'Cheaper.', fx: { cash: -16000 } }
], { cat: 'prop' });
ev('c_wedding', 0.008, 'A wedding client demands a refund because of weather delays.', [{ l: 'Offer a partial refund', d: '', fx: { cash: -4000, rep: 1 } }, { l: 'Refuse', d: '', fx: { rep: -3 } }]);
ev('c_blackmkt', 0.01, 'Cheap competitors using undeclared labour undercut {n}.', [
  { l: 'Report to {auth:lab}', d: 'Slow but fair.', fx: { cash: -1500, dem: [0.95, 8] } },
  { l: 'Lower prices', d: 'Margins squeezed.', fx: { dem: [0.96, 6], pr: -1 } }
]);
ev('c_devquit', 0.01, 'A senior developer at {n} receives a competing offer.', [
  { l: 'Match with +12%', d: '', fx: { raise: 0.12, stay: 1 } },
  { l: 'Let them go', d: 'Hard to replace.', fx: { quit: 1, cap: [0.85, 6] } }
]);
ev('c_malprac', 0.004, 'A client alleges bad advice from {n}.', [
  {
    l: 'Notify professional indemnity insurer',
    d: '',
    fx: { loss: c => Math.max(40000, WK(c) * 0.5), rep: -1 }
  },
  { l: 'Settle privately', d: '', fx: { cash: c => -Math.max(30000, WK(c) * 0.4) } }
], { cat: 'prof', exp: 3 });
ev('c_acctError', 0.008, 'An error in a client tax return from {n} triggers a penalty.', [
  { l: 'Pay the penalty', d: '', fx: { cash: -9000, rep: -1 } },
  { l: 'Appeal', d: '', fx: { gamble: { p: 0.5, ok: {}, bad: { cash: -15000, rep: -1 } } } }
], { cat: 'prof' });
ev('c_labour', 0.008, 'Authorities investigate whether {n} complies with equal-pay rules for temp workers.', [
  { l: 'Cooperate fully', d: '', fx: { cash: -6000 } },
  { l: 'Delay', d: 'Risk of bigger fine.', fx: { fine: 40000, rep: -2 } }
]);
ev('c_stylistLeaves', 0.012, 'A popular stylist is leaving {n} and taking regulars.', [
  { l: 'Give a booth-rent share', d: '', fx: { raise: 0.1, stay: 0.6 } },
  { l: 'Let them go', d: '', fx: { quit: 1, dem: [0.9, 10] } }
]);
ev('c_passrate', 0.008, 'Your pass rate dropped and the driving authority takes notice.', [
  { l: 'Extra instructor training', d: '{m:10000}.', fx: { cash: -10000, rep: 1 } },
  { l: 'Ignore', d: '', fx: { rep: -3 } }
]);
ev('c_patient', 0.007, 'A patient files a complaint against {n}.', [
  { l: 'Cooperate and apologise', d: '', fx: { rep: -1, cash: -4000 } },
  { l: 'Contest', d: '', fx: { gamble: { p: 0.5, ok: {}, bad: { rep: -4, fine: 20000 } } } }
], { cat: 'prof' });
ev('c_market', 0.012, 'The housing market cools. Fewer buyers show up at {n}.', [], { auto: 1, fx: { dem: [0.82, 14] }, cond: c => 1 });
ev('c_dogBite', 0.01, 'A dog bites another dog at {n}.', [{ l: 'Pay vet bills and ban the dog', d: '', fx: { loss: -9000 } }, { l: 'Dispute', d: '', fx: { rep: -3 } }], { cat: 'liab' });
/* venue */
ev('v_health', 0.012, '{auth:food} inspects {n}.', [], { auto: 1, cond: c => 1 });
ev('v_poison', 0.004, 'Guests report stomach illness after visiting {n}.', [
  { l: 'Close and deep clean (2 days) and publish findings', d: '', fx: { close: 1, cash: -12000, rep: -2 } },
  {
    l: 'Deny and carry on',
    d: 'Risk of a harsh ruling.',
    fx: { gamble: { p: 0.4, ok: { rep: -1 }, bad: { rep: -8, fine: 60000, close: 2 } } }
  }
], { cat: 'liab', cond: c => 0.4 + (1 - c.co.q / 100) * 1.4 });
ev('v_cold', 0.01, 'The cooling at {n} fails overnight.', [
  { l: 'Throw it all out and restock', d: '', fx: { stock: 0.4, cash: -8000 } },
  {
    l: 'Salvage what you can',
    d: 'Risk of serving bad food.',
    fx: { gamble: { p: 0.7, ok: { stock: 0.1 }, bad: { stock: 0.1, rep: -5 } } }
  }
], { cat: 'prop' });
ev('v_critic', 0.007, 'A well-known critic visits {n}.', [], { auto: 1, tone: 'n', cond: c => 1 });
ev('v_fight', 0.03, 'A fight breaks out at {n}; police are called.', [
  { l: 'Cooperate and review door policy', d: '', fx: { rep: -1, cash: -5000, riskDown: 1 } },
  { l: 'Downplay it', d: 'Licence risk grows.', fx: { rep: -1, licRisk: 1 } }
], { cat: 'liab', cond: c => 1 });
ev('v_licence', 0.006, 'The municipality reviews the serving licence of {n} after complaints.', [
  { l: 'Hire a compliance consultant ({m:12000})', d: '', fx: { cash: -12000 } },
  {
    l: 'Argue your case',
    d: '',
    fx: { gamble: { p: 0.55, ok: {}, bad: { doc: 'skjenk', close: 4, rep: -4 } } }
  }
], { exp: 3 });
ev('v_noise', 0.012, 'Neighbours complain about noise from {n}.', [
  { l: 'Soundproof ({m:25000})', d: '', fx: { cash: -25000 } },
  { l: 'Earlier closing on weekdays', d: '', fx: { dem: [0.95, 8] } }
]);
ev('v_ota', 0.02, 'A booking platform changes its ranking algorithm; visibility at {n} shifts.', [
  { l: 'Pay for a boosted listing', d: '', fx: { cash: c => -WK(c) * 0.08, dem: [1.1, 6] } },
  { l: 'Wait', d: '', fx: { dem: [0.92, 6] } }
], { tone: 'n' });
ev('v_overbook', 0.01, 'You overbooked rooms at {n}.', [
  { l: 'Relocate guests to a partner hotel and compensate', d: '', fx: { cash: -7000, rep: 0 } },
  { l: 'Offer vouchers', d: '', fx: { cash: -3000, rep: -2 } }
]);
ev('v_bigwin', 0.04, 'A lucky high roller breaks the bank at {n}.', [], { auto: 1, cond: c => 1 });
ev('v_aml', 0.008, 'The regulator opens an anti-money-laundering review of {n}.', [
  { l: 'Open the books and fix the gaps', d: '', fx: { cash: c => -Math.max(60000, WK(c) * 0.08), rep: 1 } },
  { l: 'Fight it', d: '', fx: { gamble: { p: 0.35, ok: {}, bad: { fine: 800000, rep: -6, doc: 'casino' } } } }
], { exp: 3 });
ev('v_cheat', 0.008, 'A card-counting ring targets the tables at {n}.', [
  { l: 'Ban them and tighten surveillance', d: '', fx: { cash: -25000, loss: -50000 } },
  { l: 'Ignore', d: '', fx: { loss: c => -Math.max(90000, WK(c) * 0.04) } }
]);
ev('v_addict', 0.006, 'A gambling-addiction case is publicised against {n}.', [
  { l: 'Fund a prevention programme', d: '', fx: { cash: -45000, rep: 0 } },
  { l: 'Decline comment', d: '', fx: { rep: -5 } }
], { cat: 'liab' });
ev('v_robbery', 0.003, 'An armed robbery hits {n}.', [{ l: 'Improve security and counselling', d: '', fx: { cash: -60000, loss: -200000 } }], { cat: 'prop', exp: 1 });
ev('v_injury', 0.01, 'A member is injured on equipment at {n}.', [
  { l: 'Settle and inspect equipment', d: '', fx: { loss: -18000, cash: -4000 } },
  { l: 'Deny liability', d: '', fx: { gamble: { p: 0.5, ok: {}, bad: { loss: -60000, rep: -3 } } } }
], { cat: 'liab' });
ev('v_churn', 0.012, 'A cheaper gym opens down the road from {n}; members start to leave.', [
  { l: 'Launch a loyalty offer', d: '', fx: { cash: -9000, memb: 0.97 } },
  { l: 'Do nothing', d: '', fx: { memb: 0.9 } }
]);
/* retail */
ev('r_stockout', 0.02, 'A best-seller is out of stock at {n}.', [
  { l: 'Rush an expensive reorder', d: '', fx: { cash: c => -WK(c) * 0.05 } },
  { l: 'Wait for normal delivery', d: '', fx: { dem: [0.88, 2] } }
]);
ev('r_shoplift', 0.02, 'A shoplifting wave hits {n}.', [
  { l: 'Hire a guard for a month', d: '', fx: { cash: -16000, secure: 1 } },
  { l: 'Accept', d: '', fx: { loss: c => -WK(c) * 0.06 } }
], { cat: 'prop' });
ev('r_return', 0.01, 'A bad batch causes lots of returns at {n}.', [
  { l: 'Refund everyone and claim from the supplier', d: '', fx: { cash: c => -WK(c) * 0.1, rep: 1 } },
  { l: 'Fight each case', d: '', fx: { rep: -3 } }
]);
ev('r_priceWar', 0.012, 'A big chain starts a price war near {n}.', [
  { l: 'Match their prices', d: '', fx: { dem: [1.0, 8], pr: -1, cogsUp: [1.03, 8] } },
  { l: 'Hold prices and emphasise service', d: '', fx: { dem: [0.88, 8] } }
]);
ev('r_chain', 0.006, 'A national chain announces a store next to {n}.', [
  { l: 'Differentiate with a niche range', d: '', fx: { cash: -12000, dem: [0.95, 20], q: 3 } },
  { l: 'Join forces (affiliation)', d: '', fx: { dem: [1.0, 1] } },
  { l: 'Sell up', d: 'Take a lower multiple.', fx: { sell: 1 } }
], { exp: 3 });
ev('r_robbery', 0.01, 'A robbery at {n} at night.', [{ l: 'Add alarms and cash policy', d: '', fx: { cash: -9000, loss: -9000 } }], { cat: 'prop', exp: 1 });
ev('r_trend', 0.012, 'The fashion trend shifts and last season stock at {n} stops selling.', [
  { l: 'Mark down 40%', d: '', fx: { stock: 0.18, cash: c => WK(c) * 0.05 } },
  { l: 'Hold for next season', d: '', fx: { stock: 0.06 } }
]);
ev('r_adCost', 0.02, 'Ad prices spike on social platforms; your ROAS at {n} falls.', [
  { l: 'Cut ad spend', d: '', fx: { aware: -4 } },
  { l: 'Keep spending', d: '', fx: { cash: c => -WK(c) * 0.06 } }
], { tone: 'n' });
ev('r_carrier', 0.01, 'Your parcel carrier raises rates at {n}.', [
  { l: 'Switch to a cheaper carrier', d: '', fx: { cogsUp: [0.99, 10], dem: [0.97, 3] } },
  { l: 'Accept', d: '', fx: { cogsUp: [1.03, 10] } }
]);
ev('r_wasteWeek', 0.02, 'A freezer fault and a promotion misjudgement cause heavy waste at {n}.', [{ l: 'Learn from it and change ordering', d: '', fx: { stock: 0.12 } }]);
ev('r_evShift', 0.012, 'EV subsidies change; used-car values for combustion cars drop.', [
  { l: 'Sell old stock fast', d: '', fx: { stock: 0.12 } },
  { l: 'Wait it out', d: '', fx: { stock: 0.06, dem: [0.95, 8] } }
]);
ev('r_tradeWarranty', 0.012, 'A used car sold by {n} has a major engine fault.', [
  { l: 'Repair under warranty', d: '', fx: { cash: -22000, rep: 1 } },
  { l: 'Dispute it', d: '', fx: { gamble: { p: 0.5, ok: {}, bad: { cash: -40000, rep: -3 } } } }
], { cat: 'liab' });
/* project */
ev('p_overrun', 0.03, 'A job at {n} runs into unexpected problems.', [
  { l: 'Absorb the cost', d: '', fx: { ovr: 0.08 } },
  {
    l: 'Negotiate a variation order',
    d: '',
    fx: { gamble: { p: 0.5, ok: { ovr: 0.01 }, bad: { ovr: 0.1, rep: -2 } } }
  }
]);
ev('p_defect', 0.015, 'A client claims defects on a finished job from {n}.', [
  { l: 'Fix at your cost', d: '', fx: { defect: 1 } },
  { l: 'Dispute', d: '', fx: { gamble: { p: 0.5, ok: {}, bad: { defect: 2, rep: -3 } } } }
], { cat: 'liab' });
ev('p_noshow', 0.015, 'A subcontractor does not show up for a job at {n}.', [
  { l: 'Pay a replacement premium', d: '', fx: { cash: c => -WK(c) * 0.25 } },
  { l: 'Delay the job', d: '', fx: { delay: 2, rep: -1 } }
]);
ev('p_nopay', 0.008, 'A client of {n} goes insolvent while owing for finished work.', [{ l: 'File your claim', d: '', fx: { writeoff: 1 } }], { exp: 3 });
ev('p_accident', 0.006, 'A serious accident on site at {n}.', [
  { l: 'Stop work, cooperate with {auth:lab}', d: '', fx: { close: 1, fine: 25000, rep: -2 } },
  { l: 'Fix it quietly', d: '', fx: { gamble: { p: 0.4, ok: {}, bad: { fine: 120000, rep: -5 } } } }
], { cat: 'liab', cond: c => 0.5 + (1 - c.co.mgrQ) * 0.8 });
ev('p_permit', 0.012, 'A building permit at {n} is delayed.', [
  { l: 'Hire a planning consultant', d: '', fx: { cash: -12000, delay: 0 } },
  { l: 'Wait it out', d: '', fx: { delay: 3 } }
]);
ev('p_matprice', 0.015, 'Material prices spike on building sites.', [
  { l: 'Pass costs to clients where contracts allow', d: '', fx: { price: [1.04, 10] } },
  { l: 'Swallow the cost', d: '', fx: { price: [1.07, 10] } }
], { tone: 'bad' });
ev('p_scaffold', 0.006, 'A scaffolding collapse is narrowly avoided at {n}.', [{ l: 'Retrain the whole crew on safety', d: '', fx: { cash: -9000, rep: 1 } }]);
ev('p_shock', 0.01, 'An electrical fault on a job from {n} causes a fire alarm.', [{ l: 'Pay for the damage', d: '', fx: { loss: -22000 } }], { cat: 'liab' });
ev('p_leak', 0.014, 'A pipe fitting from {n} leaks into a client apartment.', [{ l: 'Repair and compensate', d: '', fx: { loss: -26000, rep: -1 } }], { cat: 'liab' });
ev('p_weather', 0.012, 'A storm hits an outdoor event organised by {n}.', [
  { l: 'Reschedule, pay extra', d: '', fx: { cash: c => -WK(c) * 0.15 } },
  { l: 'Cancel and refund', d: '', fx: { cash: c => -WK(c) * 0.4, rep: -1 } }
], { cat: 'bi' });
/* real-estate development */
ev('d_zoning', 0.02, 'The municipality changes the zoning conditions for your site.', [
  { l: 'Redraw plans', d: '', fx: { cash: -80000, delay: 6 } },
  { l: 'Appeal', d: '', fx: { gamble: { p: 0.4, ok: {}, bad: { delay: 14, cash: -120000 } } } }
], { exp: 3 });
ev('d_market', 0.018, 'The housing market shifts.', [], { auto: 1, tone: 'n', cond: c => 1 });
ev('d_costOver', 0.02, 'Construction cost on your project rises.', [{ l: 'Absorb', d: '', fx: { ovr: 0.05 } }, { l: 'Redesign to cut cost', d: '', fx: { ovr: 0.02, delay: 3 } }]);
/* prod */
ev('pr_machine', 0.016, 'A machine line at {n} stops. Production is delayed.', [
  {
    l: 'Emergency repair crew',
    d: '',
    fx: { cash: c => -Math.max(10000, c.eqv * 0.02), cap: [0.8, 1], fixeq: 1 }
  },
  { l: 'Standard service slot', d: '', fx: { cap: [0.55, 2], fixeq: 1 } }
], { cat: 'prop', cond: c => 1 + (1 - c.co.eqc) * 1.5 });
ev('pr_raw', 0.015, 'Raw material prices jump for {n}.', [
  { l: 'Lock in a 6-month contract', d: '', fx: { price: [1.03, 24] } },
  { l: 'Buy spot', d: '', fx: { price: [1.07, 6] } }
], { tone: 'bad' });
ev('pr_recall', 0.004, 'A quality fault forces {n} to recall a batch.', [
  { l: 'Recall publicly', d: '', fx: { loss: c => -Math.max(30000, WK(c) * 0.5), rep: -2 } },
  {
    l: 'Quietly replace',
    d: 'Risk of exposure.',
    fx: { gamble: { p: 0.5, ok: { cash: -10000 }, bad: { rep: -7, fine: 90000 } } }
  }
], { cat: 'liab', cond: c => 0.5 + (1 - c.co.q / 100) * 1.4 });
ev('pr_bigcontract', 0.008, 'A large retailer wants a supply contract with {n}.', [
  { l: 'Sign with low prices', d: '', fx: { dem: [1.3, 20], pr: -1 } },
  { l: 'Sign at fair prices', d: '', fx: { gamble: { p: 0.4, ok: { dem: [1.3, 20] }, bad: {} } } },
  { l: 'Decline', d: '', fx: {} }
], { tone: 'good' });
ev('pr_flour', 0.01, 'Wheat prices surge, hitting {n}.', [
  { l: 'Raise prices 4%', d: '', fx: { price: [1.04, 10], dem: [0.97, 10] } },
  { l: 'Hold prices', d: '', fx: { price: [1.07, 10] } }
]);
ev('pr_batch', 0.012, 'A batch at {n} turns out infected.', [
  { l: 'Dump the batch', d: '', fx: { loss: c => -Math.max(25000, WK(c) * 0.3) } },
  { l: 'Sell as a discounted special', d: '', fx: { rep: -3 } }
]);
ev('pr_wood', 0.01, 'Timber prices climb for {n}.', [{ l: 'Accept', d: '', fx: { price: [1.06, 10] } }]);
ev('pr_cust', 0.01, 'A key customer of {n} moves production abroad.', [
  { l: 'Find replacement customers', d: '', fx: { cash: -25000, dem: [0.9, 14] } },
  { l: 'Match their foreign price', d: '', fx: { pr: -1, dem: [0.95, 14] } }
]);
ev('pr_lice', 0.03, 'Sea lice levels rise in the pens at {n}.', [
  { l: 'Treat now (thermal / mechanical)', d: '', fx: { cash: -420000, ill: 0.01 } },
  {
    l: 'Delay treatment',
    d: '',
    fx: { gamble: { p: 0.5, ok: { ill: 0.01 }, bad: { ill: 0.08, fine: 150000 } } }
  }
], { cat: 'prop' });
ev('pr_storm', 0.01, 'A winter storm damages sea pens at {n}.', [{ l: 'Repair pens and re-moor', d: '', fx: { cash: -900000, ill: 0.01 } }], { cat: 'prop', exp: 1 });
ev('pr_algae', 0.012, 'A harmful algae bloom approaches {n}.', [
  { l: 'Feed down and aerate', d: '', fx: { cash: -180000, ill: 0.01 } },
  { l: 'Do nothing', d: '', fx: { gamble: { p: 0.5, ok: {}, bad: { ill: 0.12 } } } }
], { cat: 'prop', exp: 1 });
ev('pr_weather', 0.02, 'Weather hits the harvest of {n}.', [], { auto: 1, fx: { dem: [0.85, 6] } });
ev('pr_subsidy', 0.006, 'The agricultural settlement changes support rates.', [], { auto: 1, tone: 'n', fx: { dem: [1.05, 20] } });
/* logistics */
ev('l_accident', 0.012, 'A vehicle of {n} is in an accident.', [
  { l: 'Repair and replace temporarily', d: '', fx: { loss: -35000, cap: [0.9, 2], fixeq: 1 } },
  {
    l: 'Scrap it and buy a replacement',
    d: '',
    fx: { loss: -35000, fixeq: 2, cash: c => -Math.max(20000, c.eqv * 0.04) }
  }
], { cat: 'prop' });
ev('l_fuel', 0.02, 'Fuel prices jump.', [
  { l: 'Add a fuel surcharge', d: '', fx: { price: [1.1, 8], dem: [0.97, 8] } },
  { l: 'Absorb', d: '', fx: { price: [1.18, 8] } }
], { tone: 'bad' });
ev('l_hours', 0.01, 'Roadside inspection finds driver-hours violations at {n}.', [
  { l: 'Pay fine and fix scheduling', d: '', fx: { fine: 30000 } },
  { l: 'Contest', d: '', fx: { gamble: { p: 0.4, ok: {}, bad: { fine: 70000, rep: -1 } } } }
]);
ev('l_break', 0.025, 'A vehicle at {n} breaks down.', [
  { l: 'Repair', d: '', fx: { cash: c => -Math.max(4000, c.eqv * 0.01), fixeq: 1 } },
  { l: 'Tow and rent a replacement', d: '', fx: { cash: -9000, fixeq: 1, cap: [0.95, 1] } }
], { cat: 'prop', cond: c => 1 + (1 - c.co.eqc) * 1.5 });
ev('l_gig', 0.006, 'A court rules some gig couriers are employees.', [
  { l: 'Convert to employees', d: '', fx: { raise: 0.05 } },
  { l: 'Appeal', d: '', fx: { gamble: { p: 0.4, ok: {}, bad: { fine: 120000 } } } }
], { exp: 3 });
ev('l_gigRule', 0.006, 'New rules for platform workers raise costs at {n}.', [{ l: 'Adapt', d: '', fx: { cogsUp: [1.03, 30] } }]);
ev('l_app', 0.012, 'The ride-hailing app raises its fee.', [
  { l: 'Absorb', d: '', fx: { cogsUp: [1.03, 20] } },
  { l: 'Promote your own app', d: '', fx: { cash: -9000, aware: 6 } }
]);
ev('l_toll', 0.012, 'Toll roads add a new road fee.', [{ l: 'Add surcharge', d: '', fx: { price: [1.03, 12] } }]);
ev('l_freight', 0.02, 'Global freight rates swing.', [], { auto: 1, tone: 'n', fx: { dem: [1.1, 4] } });
ev('l_port', 0.01, 'Port congestion delays your ship.', [{ l: 'Pay for priority', d: '', fx: { cash: -60000 } }, { l: 'Wait', d: '', fx: { cap: [0.8, 2] } }]);
ev('l_ground', 0.008, 'Weather grounds flights for a few days.', [{ l: 'Rebook passengers', d: '', fx: { cash: c => -WK(c) * 0.05 } }], { cat: 'bi' });
ev('l_atc', 0.006, 'Air traffic control capacity limits cause cancellations.', [{ l: 'Compensate passengers', d: '', fx: { cash: c => -WK(c) * 0.04, rep: -1 } }]);
/* rent */
ev('rn_nopay', 0.04, 'A tenant stops paying rent.', [
  { l: 'Start eviction process', d: 'Slow and costly.', fx: { tenant: 'evict' } },
  { l: 'Agree a payment plan', d: '', fx: { tenant: 'plan' } },
  { l: 'Write off the arrears', d: '', fx: { tenant: 'write' } }
], { exp: 2 });
ev('rn_leak', 0.02, 'A water leak damages a unit.', [{ l: 'Fix properly', d: '', fx: { loss: c => -Math.max(25000, c.eqv * 0.002), vac: 1 } }], { cat: 'prop' });
ev('rn_reg', 0.004, 'New rent regulation limits increases.', [], { auto: 1, fx: { dem: [0.96, 52] } });
ev('rn_vacant', 0.012, 'A wave of tenants leaves.', [
  { l: 'Cut rents 5% for 2 months', d: '', fx: { vacAdd: -2, dem: [0.95, 8] } },
  { l: 'Hold and wait', d: '', fx: { vacAdd: 3 } }
]);
ev('rn_pet', 0.012, 'A tenant causes damage.', [{ l: 'Deduct from deposit', d: '', fx: { cash: -2000 } }]);
ev('rn_anchor', 0.01, 'An anchor tenant announces it will not renew.', [
  { l: 'Offer incentives (rent-free months)', d: '', fx: { cash: c => -WK(c) * 1.2 } },
  { l: 'Let them go and re-let', d: '', fx: { vacAdd: 8 } }
], { exp: 3 });
ev('rn_vandal', 0.015, 'Vandalism at {n}.', [{ l: 'Repair and add lighting', d: '', fx: { cash: -22000 } }], { cat: 'prop' });
/* finance */
ev('f_storm', 0.015, 'A winter storm causes a wave of claims at {n}.', [], { auto: 1, cond: c => 1 });
ev('f_fraud', 0.01, 'Fraud ring uncovered at {n}.', [{ l: 'Cooperate with police, tighten checks', d: '', fx: { loss: -120000, cash: -30000 } }]);
ev('f_run', 0.004, 'Rumours trigger a run on deposits at {n}.', [], { auto: 1, cond: c => 1 });
ev('f_default', 0.012, 'A loan-loss spike hits the book of {n}.', [], { auto: 1, cond: c => 1 });
ev('f_fsa', 0.008, '{auth:fin} reviews {n}.', [
  { l: 'Open the books and fix issues', d: '', fx: { cash: c => -Math.max(40000, WK(c) * 0.03) } },
  { l: 'Push back', d: '', fx: { gamble: { p: 0.4, ok: {}, bad: { fine: 500000, rep: -4 } } } }
], { exp: 3 });
ev('f_fund', 0.012, 'Investors request redemptions from {n}.', [
  { l: 'Honour all requests', d: '', fx: { aum: 0.92 } },
  { l: 'Gate redemptions', d: '', fx: { aum: 0.97, rep: -4 } }
]);
/* energy */
ev('e_price', 0.04, 'Power / commodity prices jump or fall sharply.', [], { auto: 1, tone: 'n', cond: c => 1 });
ev('e_outage', 0.012, 'An outage hits {n}.', [{ l: 'Emergency repair', d: '', fx: { cash: c => -Math.max(80000, c.eqv * 0.003), cap: [0.5, 1] } }], { cat: 'prop' });
ev('e_tax', 0.005, 'The government proposes a new resource tax.', [], { auto: 1, tone: 'bad', fx: { dem: [0.93, 52] } });
ev('e_dry', 0.012, 'A dry spell reduces output for {n}.', [], { auto: 1, fx: { cap: [0.7, 6] } });
ev('e_curtail', 0.008, 'The grid operator curtails production at {n}.', [], { auto: 1, fx: { cap: [0.8, 2] } });
ev('e_dryHole', 0.02, 'An exploration well at {n} comes in dry.', [], { auto: 1, fx: { cash: -4000000 } });
ev('e_spill', 0.003, 'An oil spill incident at {n}.', [{ l: 'Immediate clean-up and disclosure', d: '', fx: { loss: -9000000, rep: -4 } }], { cat: 'liab', exp: 1 });
ev('e_geo', 0.01, 'New seismic data changes the outlook for a prospect.', [], { auto: 1, tone: 'n' });


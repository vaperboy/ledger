/* ---- src/businesses/services.js ---- */
/* ===== Services: solo hours-based and professional firms ===== */
B('cons', 'Freelance consultant', 'svc', 'Services', {
  blurb: 'Sell your expertise by the hour to companies. Almost no costs, but your time is the product.',
  unit: 'billable hour',
  ticket: 1150,
  cogs: 0.02,
  D: 26,
  ela: 1.4,
  b2b: 0.95,
  terms: 4,
  own: 1,
  std: [['consult', 1]],
  mgr: 'pro',
  fixed: 650,
  open: 2500,
  vat: 'std',
  aud: 0.9,
  skill: 'Consulting',
  prem: ['home', 0],
  docs: ['org', 'mva', 'gdpr'],
  dq: {},
  minSize: 1,
  maxSize: 4,
  eq: [
    E('lap', 'Work laptop and phone', 24000, 4, 1, 'rq'),
    E('sw', 'Software and cloud licences', 9000, 2, 1, 'q'),
    E('web', 'Professional website and portfolio', 12000, 3, 1, 'q')
  ],
  knobs: [
    K('niche', 'Positioning', 'How you present yourself to buyers.', [
      O('gen', 'Generalist', 'Easy to start, lots of competition.', { d: 1.1, t: 0.9 }),
      O('spec', 'Narrow specialist', 'Fewer leads but they pay more.', { d: 0.8, t: 1.25, q: 4 }),
      O('interim', 'Interim / long contracts', 'Steady hours at a lower rate.', { d: 0.9, t: 0.88, r: 0.8 })
    ], 0),
    K('contract', 'Contract model', 'How you bill.', [
      O('hour', 'Hourly rate', 'Simple. Risk stays with the client.', {}),
      O('fixed', 'Fixed fee per deliverable', 'Higher upside, scope creep risk.', { t: 1.12, r: 1.3 }),
      O('retain', 'Monthly retainer', 'Reliable cash, lower rate.', { t: 0.92, d: 1.05, r: 0.8 })
    ], 0)
  ],
  crs: [['c1', 'Advanced certification', 18000, 4, 6], ['c2', 'Sales and negotiation course', 9500, 2, 3]],
  ev: ['c_scope']
});
B('tutor', 'Online tutoring', 'svc', 'Services', {
  blurb: 'Teach pupils and students online. School terms decide your year.',
  unit: 'lesson hour',
  ticket: 520,
  cogs: 0.03,
  D: 22,
  ela: 1.6,
  vat: 'zero',
  seas: 'study',
  b2b: 0,
  own: 1,
  std: [['tutor', 1]],
  mgr: 'gen',
  fixed: 450,
  open: 1800,
  aud: 0.2,
  skill: 'Teaching',
  minSize: 1,
  maxSize: 5,
  prem: ['home', 0],
  docs: ['org', 'gdpr', 'child'],
  eq: [
    E('lap', 'Laptop with webcam', 14000, 4, 1, 'rq'),
    E('tab', 'Drawing tablet and whiteboard software', 5000, 3, 1, 'q'),
    E('mat', 'Teaching materials and platform', 7000, 2, 1, 'q')
  ],
  knobs: [
    K('lvl', 'Pupil level', 'Who you tutor.', [
      O('prim', 'Primary school', 'Many pupils, low rate.', { d: 1.2, t: 0.8 }),
      O('upper', 'Upper secondary / exam prep', 'The classic sweet spot.', {}),
      O('uni', 'University and adult learners', 'Pays well, hard subjects.', { d: 0.75, t: 1.45, q: 3 })
    ], 1),
    K('fmt', 'Format', 'One by one or groups.', [
      O('one', 'One-to-one', 'Best quality, limited by your hours.', { q: 3 }),
      O('grp', 'Small groups (up to 5)', 'Multiplies your hourly income, results suffer if overfilled.', { t: 1.6, q: -3, k: 1.0, d: 0.85 })
    ], 0)
  ],
  crs: [['c1', 'Pedagogy certificate', 12000, 6, 5]]
});
B('carclean', 'Mobile car cleaning', 'svc', 'Services', {
  blurb: 'Wash and detail cars at the customer’s home or workplace. Needs a van, water and good hands.',
  unit: 'car',
  ticket: 750,
  cogs: 0.12,
  D: 18,
  ela: 1.5,
  seas: 'spring',
  b2b: 0.25,
  terms: 3,
  own: 1,
  std: [['carwash', 1]],
  mgr: 'ops',
  fixed: 900,
  open: 3000,
  aud: 0.2,
  skill: 'Detailing',
  minSize: 1,
  maxSize: 5,
  prem: ['home', 0],
  docs: ['org', 'mva', 'hms'],
  eq: [
    E('van', 'Service van', 190000, 7, 1, 'rcv', ['van_s', 'van_l', 'ev_van', 'pickup']),
    E('wash', 'Pressure washer and water tank', 18000, 5, 1, 'rc'),
    E('steam', 'Steam cleaner and extractor', 22000, 5, 1, 'q'),
    E('pol', 'Polisher kit and compounds', 9500, 3, 1, 'q'),
    E('ceram', 'Ceramic coating kit', 14000, 3, 0, 'q')
  ],
  knobs: [
    K('tier', 'Service mix', 'What you push.', [
      O('basic', 'Quick wash volume', 'Many cars, thin margin.', { t: 0.7, k: 1.35, q: -3, d: 1.15 }),
      O('valet', 'Full valet', 'The normal mix.', {}),
      O('ceram', 'Detailing and ceramic coating', 'Few cars, high ticket, needs the coating kit.', { t: 2.1, k: 0.5, q: 6, d: 0.55 })
    ], 1),
    K('fleet', 'Fleet contracts', 'Regular work for companies.', [
      O('none', 'Private customers only', 'Walk-in cars, paid on the spot.', {}),
      O('fleet', 'Chase fleet contracts', 'Steady volume, 30-day payment terms.', { d: 1.12, t: 0.88, r: 1.1 })
    ], 0)
  ],
  crs: [['c1', 'Ceramic coating certification', 14000, 2, 6], ['c2', 'Paint correction workshop', 9000, 1, 4]],
  ev: ['c_damage']
});
B('photo', 'Photography and video', 'svc', 'Services', {
  blurb: 'Weddings, portraits and corporate shoots. Editing hours eat your week.',
  unit: 'shoot',
  ticket: 6500,
  cogs: 0.07,
  D: 3.2,
  ela: 1.3,
  seas: 'wedding',
  b2b: 0.55,
  terms: 4,
  own: 1,
  std: [['photog', 1]],
  mgr: 'gen',
  fixed: 700,
  open: 4500,
  aud: 0.35,
  skill: 'Photography',
  minSize: 1,
  maxSize: 4,
  prem: ['home', 0],
  docs: ['org', 'mva', 'gdpr'],
  eq: [
    E('cam', 'Camera body', 28000, 4, 1, 'rc'),
    E('lens', 'Lens set', 32000, 6, 1, 'q'),
    E('light', 'Lighting and backdrops', 14000, 5, 1, 'q'),
    E('ed', 'Editing workstation and software', 26000, 3, 1, 'rc'),
    E('drone', 'Drone (registered)', 18000, 3, 0, 'q')
  ],
  knobs: [
    K('niche', 'Niche', 'What you shoot.', [
      O('wed', 'Weddings and events', 'Huge variance by season. Highest tickets.', { t: 1.35, d: 0.75 }),
      O('corp', 'Corporate and brand', 'Contracts, 30-day terms.', { t: 1.0, d: 1.0, r: 0.9 }),
      O('real', 'Real-estate and product', 'Volume work with low rates.', { t: 0.45, d: 2.0, k: 1.5, q: -2 })
    ], 1),
    KM('also', 'Also offer', 'Several can run together.', [
      O('prints', 'Prints, frames and albums', 'Clients buy more after the shoot.', { t: 1.12, c: 0.04 }),
      O('booth', 'Photo booth hire', 'Parties and fairs book the booth.', { d: 1.08, w: 600 }),
      O('class', 'Beginner workshops', 'Weekend classes fill the quiet days.', { d: 1.04, w: 300, q: 1 })
    ], 0)
  ],
  crs: [['c1', 'Lighting masterclass', 8500, 1, 4], ['c2', 'Video storytelling course', 15000, 3, 5]],
  ev: ['c_gear', 'c_wedding']
});
B('handy', 'Handyman', 'svc', 'Services', {
  blurb: 'Fix, assemble and renovate small jobs for households and landlords.',
  unit: 'job',
  ticket: 2200,
  cogs: 0.22,
  D: 12.5,
  ela: 1.3,
  seas: 'build',
  b2b: 0.25,
  own: 1,
  std: [['handy', 1]],
  mgr: 'ops',
  fixed: 900,
  open: 3500,
  aud: 0.2,
  skill: 'Trades',
  minSize: 1,
  maxSize: 5,
  prem: ['home', 0],
  docs: ['org', 'mva', 'hms'],
  eq: [
    E('tools', 'Tool set and power tools', 38000, 6, 1, 'rc'),
    E('van', 'Work van', 190000, 7, 1, 'rcv', ['van_s', 'van_l', 'pickup']),
    E('lad', 'Ladders and scaffolding tower', 14000, 8, 1, 'q'),
    E('meas', 'Measuring and moisture instruments', 8500, 5, 1, 'q')
  ],
  knobs: [
    K('mix', 'Job mix', 'Small repairs or bigger bathrooms.', [
      O('small', 'Small repair jobs', 'Many jobs, quick turns.', { t: 0.7, k: 1.3, d: 1.25 }),
      O('mid', 'Mixed', 'Small fixes and the odd bigger job.', {}),
      O('reno', 'Bathrooms and renovations', 'Bigger tickets, needs certified subcontractors for wet rooms.', { t: 2.8, k: 0.4, d: 0.45, r: 1.4 })
    ], 1),
    K('call', 'Emergency call-outs', 'Evenings and weekends.', [
      O('no', 'Office hours only', 'No nights or weekends.', {}),
      O('yes', 'Take call-outs (+50% price)', 'Higher rates, more wear.', { t: 1.15, d: 1.1, r: 1.1 })
    ], 0)
  ],
  crs: [['c1', 'Wet-room certification', 16500, 3, 6]]
});
B('cleaning', 'Cleaning company', 'svc', 'Services', {
  blurb: 'Contract cleaning for offices, shops and homes. High staff turnover, thin margins, strict labour rules.',
  unit: 'cleaning hour',
  ticket: 520,
  cogs: 0.07,
  m: 0.09,
  ela: 1.6,
  b2b: 0.8,
  terms: 4,
  own: 1,
  std: [['cleaner', 6]],
  mgr: 'ops',
  fixed: 1800,
  open: 12000,
  aud: 0.6,
  skill: 'Operations',
  minSize: 0.4,
  maxSize: 4,
  prem: ['office', 40],
  docs: ['org', 'mva', 'hms', 'renhold', 'gdpr'],
  needAS: false,
  ev: ['c_blackmkt'], /* cleaning contracts go out to tender in features/sales/public_tenders.js */
  eq: [
    E('vac', 'Commercial vacuums', 5200, 5, 6, 'rc'),
    E('scrub', 'Floor scrubbing machine', 38000, 6, 2, 'rc'),
    E('van', 'Service van', 190000, 7, 2, 'rcv', ['van_s', 'van_l', 'ev_van']),
    E('chem', 'Dosing system and chemicals stock', 16000, 3, 1, 'q'),
    E('uni', 'Uniforms and ID badges', 9000, 2, 1, 'q')
  ],
  knobs: [
    K('crew', 'Crew model', 'Employees or cheaper subcontractors.', [
      O('own', 'Own employees', 'Reliable but costs full on-costs.', {}),
      O('sub', 'Subcontractors', 'Cheaper by 15%, but audit and quality risk.', { c: -0.06, q: -4, r: 1.5 })
    ], 0),
    K('seg', 'Customers', 'Where you sell.', [
      O('home', 'Homes', 'Small ticket, flexible.', { t: 1.15, d: 0.8 }),
      O('office', 'Offices and shops', 'Contracts at set hours.', {}),
      O('indus', 'Industrial and hospitals', 'Higher rates, strict standards.', { t: 1.3, d: 0.6, q: 5 })
    ], 1)
  ],
  crs: [['c1', 'Hygiene and chemical safety course', 3500, 1, 4], ['c2', 'Team-leader training', 8500, 2, 3]]
});
B('webdev', 'Software and web agency', 'svc', 'Services', {
  blurb: 'Build websites, apps and internal systems for clients. Developers cost a lot and scope creep never sleeps.',
  unit: 'dev hour',
  ticket: 1150,
  cogs: 0.04,
  m: 0.17,
  ela: 1.4,
  b2b: 0.95,
  terms: 4,
  own: 1,
  std: [['dev', 3], ['designer', 1], ['projc', 1]],
  mgr: 'tech',
  fixed: 3500,
  open: 18000,
  aud: 0.9,
  skill: 'Software',
  minSize: 0.4,
  maxSize: 4,
  prem: ['office', 60],
  docs: ['org', 'mva', 'gdpr', 'hms'],
  ev: ['c_scope', 'c_devquit'],
  eq: [
    E('lap', 'Developer laptops', 26000, 3, 5, 'rc'),
    E('cloud', 'Cloud and CI infrastructure', 16000, 2, 1, 'rq'),
    E('lic', 'Software licences and tools', 24000, 2, 1, 'q'),
    E('desk', 'Desks and meeting room kit', 8000, 6, 6, 'q')
  ],
  knobs: [
    K('model', 'Pricing model', 'Hourly vs fixed price.', [
      O('t', 'Time and materials', 'Client carries the risk.', {}),
      O('f', 'Fixed price projects', 'Higher margins and big overrun risk.', { t: 1.15, r: 1.45 }),
      O('prod', 'Own product (SaaS)', 'Slow start, recurring revenue.', { t: 0.75, d: 0.85, q: 4 })
    ], 0),
    K('stack', 'Tech focus', '', [
      O('web', 'Websites and shops', 'Many small customers.', { d: 1.15, t: 0.9 }),
      O('app', 'Apps and integrations', 'Custom apps and system integrations at normal rates.', {}),
      O('ai', 'AI and data projects', 'Premium rates, hard to staff.', { t: 1.3, d: 0.8, r: 1.2 })
    ], 1)
  ],
  crs: [['c1', 'Cloud architecture certification', 22000, 4, 6], ['c2', 'Security training (OWASP)', 9500, 2, 4]]
});
B('mktg', 'Marketing agency', 'svc', 'Services', {
  blurb: 'Run campaigns for other companies. If you own one, your own companies can use it for their marketing.',
  unit: 'billable hour',
  ticket: 1050,
  cogs: 0.06,
  m: 0.15,
  ela: 1.4,
  b2b: 0.95,
  terms: 4,
  own: 1,
  std: [['marketer', 3], ['designer', 1], ['sales', 1]],
  mgr: 'sales',
  fixed: 3200,
  open: 15000,
  aud: 0.9,
  skill: 'Marketing',
  minSize: 0.4,
  maxSize: 4,
  group: 'mkt',
  prem: ['office', 60],
  docs: ['org', 'mva', 'gdpr', 'hms'],
  ev: ['c_clientloss'],
  eq: [
    E('lap', 'Laptops and design screens', 24000, 3, 5, 'rc'),
    E('tools', 'Analytics and ad-management tools', 30000, 1, 1, 'rq'),
    E('studio', 'Small photo and video studio', 55000, 5, 1, 'q')
  ],
  knobs: [
    K('focus', 'Focus', 'Who you serve.', [
      O('sme', 'Small business packages', 'Many small clients.', { d: 1.25, t: 0.8 }),
      O('mid', 'Mid-size brands', 'Mid-size clients, steady retainers.', {}),
      O('ent', 'Large accounts and tenders', 'Slow to win, large invoices.', { d: 0.6, t: 1.6, r: 1.2 })
    ], 1),
    K('pay', 'How you charge', 'How clients pay you.', [
      O('ret', 'Monthly retainers', 'Steady clients on a monthly fee.', {}),
      O('proj', 'By the project', 'Higher fees per job, fewer steady clients.', { t: 1.15, d: 0.9 }),
      O('perf', 'Paid on results', 'A share of the sales you bring: more when it works, risky when it does not.', { t: 1.3, d: 0.85, r: 1.2 })
    ], 0)
  ],
  crs: [['c1', 'Performance-marketing certification', 12000, 2, 5]]
});
B('law', 'Law firm', 'svc', 'Services', {
  blurb: 'Sell legal advice by the hour. Needs a licensed lawyer. Own companies can use it for contracts and disputes.',
  unit: 'billable hour',
  ticket: 2150,
  cogs: 0.04,
  m: 0.2,
  ela: 1.0,
  b2b: 0.85,
  terms: 5,
  own: 0.6,
  std: [['lawyer', 3], ['paralegal', 1], ['recept', 1]],
  mgr: 'pro',
  fixed: 6500,
  open: 35000,
  aud: 0.8,
  skill: 'Law',
  minSize: 0.4,
  maxSize: 4,
  group: 'law',
  needAS: true,
  prem: ['office', 110],
  docs: ['org', 'mva', 'acctr', 'lawyer', 'aml', 'gdpr', 'hms'],
  ev: ['c_malprac'],
  eq: [
    E('lap', 'Laptops and secure phones', 24000, 3, 5, 'rc'),
    E('case', 'Case-management system', 45000, 3, 1, 'rq'),
    E('lib', 'Legal research subscriptions', 38000, 1, 1, 'q'),
    E('desk', 'Furniture and meeting room', 120000, 8, 1, 'q')
  ],
  knobs: [
    K('area', 'Practice area', '', [
      O('corp', 'Corporate and contracts', 'Reliable demand.', {}),
      O('lit', 'Litigation', 'Bigger ticket, uncertain outcome.', { t: 1.2, r: 1.3, d: 0.8 }),
      O('prop', 'Property and family law', 'High volume.', { t: 0.8, d: 1.3 })
    ], 0),
    K('fee', 'Fee model', '', [
      O('hr', 'Hourly billing', 'Clients pay for the hours you put in.', {}),
      O('fix', 'Fixed fee packages', 'Lower rate, more clients.', { t: 0.85, d: 1.2 })
    ], 0)
  ],
  crs: [['c1', 'Continuing legal education', 14000, 2, 5]]
});
B('acctfirm', 'Accounting firm', 'svc', 'Services', {
  blurb: 'Do bookkeeping and tax for other businesses. Deadlines drive the year. Your own limited companies can use you.',
  unit: 'billable hour',
  ticket: 950,
  cogs: 0.03,
  m: 0.17,
  ela: 1.1,
  b2b: 0.9,
  terms: 3,
  own: 0.6,
  std: [['acct', 4], ['recept', 1]],
  mgr: 'fin',
  fixed: 3800,
  open: 22000,
  aud: 0.8,
  skill: 'Accounting',
  minSize: 0.4,
  maxSize: 4,
  group: 'acct',
  needAS: true,
  prem: ['office', 90],
  docs: ['org', 'mva', 'acctr', 'rev', 'aml', 'gdpr'],
  seas: 'spring',
  ev: ['c_acctError'],
  eq: [
    E('lap', 'Laptops and dual screens', 22000, 3, 5, 'rc'),
    E('sw', 'Accounting software and portal', 40000, 1, 1, 'rq'),
    E('desk', 'Furniture and archive', 70000, 8, 1, 'q')
  ],
  knobs: [
    K('svc', 'Service mix', '', [
      O('basic', 'Bookkeeping packages', 'Volume and automation.', { t: 0.8, d: 1.3, k: 1.15 }),
      O('full', 'Full service with advice', 'Accounts, tax and advice for the same clients.', {}),
      O('adv', 'Advisory and transactions', 'Premium, few clients.', { t: 1.4, d: 0.65, q: 4 })
    ], 1),
    KM('also', 'Also offer', 'Several can run together.', [
      O('payroll', 'Payroll service', 'Run payroll for your clients every month.', { d: 1.08, w: 400 }),
      O('private', 'Tax returns for private clients', 'A busy spring every year.', { d: 1.06 }),
      O('advice', 'Advice for start-ups', 'Higher fees, fewer clients.', { t: 1.08, d: 0.97 })
    ], 0)
  ],
  crs: [['c1', 'Authorised accountant exam course', 24000, 8, 6]]
});
B('staffing', 'Staffing agency', 'svc', 'Services', {
  blurb: 'Place temporary workers at client companies. Big revenue, thin margin, strict rules on hiring out labour.',
  unit: 'placed hour',
  ticket: 395,
  cogs: 0.76,
  m: 0.055,
  ela: 1.7,
  b2b: 0.95,
  terms: 4,
  own: 1,
  std: [['sales', 2], ['hr', 2]],
  mgr: 'sales',
  fixed: 2400,
  open: 24000,
  aud: 0.9,
  skill: 'Staffing',
  minSize: 0.4,
  maxSize: 4,
  prem: ['office', 80],
  docs: ['org', 'mva', 'acctr', 'bemanning', 'hms', 'gdpr'],
  ev: ['c_clientloss', 'c_labour'],
  eq: [
    E('lap', 'Laptops', 22000, 3, 4, 'rc'),
    E('ats', 'Applicant-tracking system', 36000, 1, 1, 'rq'),
    E('pay', 'Payroll integration', 20000, 2, 1, 'q')
  ],
  knobs: [
    K('seg', 'Segments', '', [
      O('gen', 'General labour', 'Volume, thin margin.', { t: 0.9, d: 1.3 }),
      O('skilled', 'Skilled trades and technical', 'Electricians, welders and engineers: higher rates, fewer placements.', { t: 1.15, d: 0.9 }),
      O('exec', 'Specialists and interim managers', 'High fees, hard to find.', { t: 1.6, d: 0.5, q: 3 })
    ], 0),
    K('terms', 'Contracts', 'What you place people for.', [
      O('temp', 'Temps by the hour', 'Many short assignments.', {}),
      O('t2h', 'Temp to hire', 'A placement fee when the client keeps them.', { t: 1.1, d: 0.92 }),
      O('exec', 'Executive search', 'Few searches, big fees.', { t: 1.6, d: 0.5, q: 2 })
    ], 0)
  ],
  crs: [['c1', 'Labour-law course', 8000, 1, 4]]
});
B('barber', 'Hair salon', 'svc', 'Services', {
  blurb: 'Cut, colour and style. Chairs and a good team of stylists decide everything.',
  unit: 'treatment',
  ticket: 520,
  cogs: 0.09,
  m: 0.12,
  ela: 1.2,
  b2b: 0,
  own: 0.8,
  std: [['barber', 3]],
  mgr: 'ops',
  fixed: 1800,
  open: 14000,
  aud: 0.2,
  skill: 'Styling',
  minSize: 0.4,
  maxSize: 3,
  seas: 'xmas',
  prem: ['shop', 55],
  docs: ['org', 'mva', 'hms'],
  ev: ['c_stylistLeaves'],
  eq: [
    E('chair', 'Styling chairs and stations', 22000, 8, 3, 'rc'),
    E('wash', 'Wash basins', 16000, 8, 2, 'r'),
    E('dry', 'Dryers and tools', 12000, 4, 1, 'q'),
    E('pos', 'Booking system and POS', 9000, 3, 1, 'rq'),
    E('prod', 'Product retail stock', 15000, 1, 1, 'q')
  ],
  knobs: [
    K('pos', 'Positioning', '', [
      O('bar', 'Barber, walk-ins', 'Volume at lower prices.', { t: 0.75, d: 1.3 }),
      O('std', 'Standard salon', 'Cuts and colour by appointment, at normal prices.', {}),
      O('prem', 'Premium colour studio', 'High price, appointment only.', { t: 1.6, d: 0.65, q: 5, c: 0.04 })
    ], 1),
    KM('also', 'Also offer', 'Several can run together.', [
      O('beard', 'Beard trims and shaves', 'A bigger bill per visit.', { t: 1.08 }),
      O('prod', 'Hair products for sale', 'Shampoo and styling at the till.', { t: 1.06, c: 0.03 }),
      O('walkin', 'Walk-ins without booking', 'More customers, a bit more rush.', { d: 1.1, q: -1 })
    ], 0)
  ],
  crs: [['c1', 'Colour technique course', 9000, 1, 5], ['c2', 'Barbering masterclass', 6500, 1, 4]]
});
B('drivsk', 'Driving school', 'svc', 'Services', {
  blurb: 'Teach people to drive. Training cars, approved instructors and a pass rate to protect.',
  unit: 'lesson',
  ticket: 780,
  cogs: 0.1,
  m: 0.15,
  ela: 1.1,
  vat: 'zero',
  b2b: 0,
  own: 0.6,
  std: [['instr', 3], ['recept', 1]],
  mgr: 'ops',
  fixed: 2200,
  open: 20000,
  aud: 0.2,
  skill: 'Instruction',
  minSize: 0.4,
  maxSize: 3,
  seas: 'study',
  prem: ['office', 70],
  docs: ['org', 'trafikk', 'hms', 'gdpr', 'child'],
  ev: ['c_passrate'],
  eq: [
    E('car', 'Training cars (dual controls)', 380000, 5, 3, 'rcv', ['car_s', 'car_ev']),
    E('sim', 'Driving simulator', 280000, 6, 1, 'q'),
    E('room', 'Theory classroom and projector', 40000, 8, 1, 'q'),
    E('book', 'Booking and student system', 24000, 2, 1, 'rq')
  ],
  knobs: [
    K('fmt', 'Course style', '', [
      O('std', 'Standard lessons', 'Weekly lessons at the usual pace.', {}),
      O('int', 'Intensive courses', 'Higher ticket, more car wear.', { t: 1.2, d: 0.85, r: 1.15 })
    ], 0),
    KM('also', 'Also offer', 'Several can run together.', [
      O('mc', 'Motorcycle licences', 'A second kind of pupil. Needs a bike.', { d: 1.08, w: 900 }),
      O('heavy', 'Truck and bus licences', 'Long courses that pay well.', { d: 1.06, t: 1.1, w: 1500 }),
      O('online', 'Theory course online', 'Pupils study at home and book their lessons with you.', { d: 1.05, w: 200 })
    ], 0)
  ],
  crs: [['c1', 'Instructor refresher', 8500, 1, 4]]
});
B('physio', 'Physiotherapy clinic', 'svc', 'Services', {
  blurb: 'Treat patients with a mix of private payment and public refunds. Authorisation matters and the clinical lead carries the risk.',
  unit: 'treatment',
  ticket: 640,
  cogs: 0.04,
  m: 0.14,
  ela: 0.8,
  vat: 'zero',
  b2b: 0.15,
  own: 0.6,
  std: [['physio', 3], ['recept', 1]],
  mgr: 'clin',
  fixed: 2400,
  open: 26000,
  aud: 0.2,
  skill: 'Clinical',
  minSize: 0.4,
  maxSize: 3,
  prem: ['clinic', 100],
  docs: ['org', 'helse', 'hpr', 'hms', 'gdpr'],
  ev: ['c_patient'],
  eq: [
    E('bench', 'Treatment benches', 36000, 8, 3, 'rc'),
    E('ex', 'Exercise and rehab equipment', 120000, 8, 1, 'q'),
    E('shock', 'Shockwave / ultrasound unit', 95000, 6, 1, 'q'),
    E('ehr', 'Patient journal system', 26000, 2, 1, 'rq')
  ],
  knobs: [
    K('ref', 'Payment mix', '', [
      O('priv', 'Private patients only', 'Higher fee but fewer patients.', { t: 1.2, d: 0.8 }),
      O('mix', 'Private and public refund', 'Some private patients, some on the public scheme.', {}),
      O('pub', 'Public refund focus', 'More patients, price capped.', { t: 0.85, d: 1.3 })
    ], 1),
    KM('also', 'Also offer', 'Several can run together.', [
      O('massage', 'Sports massage', 'Athletes book between treatments.', { d: 1.06 }),
      O('group', 'Group training classes', 'Back and knee classes in the evenings.', { d: 1.08, w: 500 }),
      O('home', 'Home visits', 'Higher fees, more time on the road.', { t: 1.1, k: 0.95 })
    ], 0)
  ],
  crs: [['c1', 'Manual therapy course', 18000, 2, 5]]
});
B('estate', 'Estate agency', 'svc', 'Services', {
  blurb: 'Sell homes for commission. Follows the housing market and interest rates. Needs a licensed estate agent in charge.',
  unit: 'home sold',
  ticket: 76000,
  cogs: 0.36,
  m: 0.12,
  ela: 1.0,
  seas: 'spring',
  b2b: 0,
  own: 0.4,
  std: [['estate', 5], ['recept', 1]],
  mgr: 'pro',
  fixed: 5500,
  open: 32000,
  aud: 0.5,
  skill: 'Sales',
  minSize: 0.4,
  maxSize: 3,
  needAS: true,
  prem: ['shop', 120],
  docs: ['org', 'mva', 'acctr', 'megler', 'aml', 'gdpr'],
  ev: ['c_market'],
  eq: [
    E('lap', 'Laptops and phones', 18000, 3, 6, 'rc'),
    E('photo', 'Photo / 3D tour kit', 40000, 4, 1, 'q'),
    E('crm', 'CRM and listing system', 38000, 1, 1, 'rq'),
    E('car', 'Company cars', 340000, 5, 2, 'v', ['car_s', 'car_ev', 'car_lux'])
  ],
  knobs: [
    K('fee', 'Fee approach', '', [
      O('low', 'Low fixed fee', 'More listings, lower income each.', { t: 0.8, d: 1.3 }),
      O('std', 'Normal commission', 'The usual percentage of the sale price.', {}),
      O('prem', 'Premium service', 'Photographers, staging, fewer listings.', { t: 1.3, d: 0.75, q: 5 })
    ], 1),
    KM('also', 'Also offer', 'Several can run together.', [
      O('let', 'Lettings', 'Find tenants for landlords for a fee.', { d: 1.1 }),
      O('val', 'Valuations', 'Banks and owners pay for a valuation.', { d: 1.05 }),
      O('new', 'New-build projects', 'Sell whole projects for developers.', { d: 1.06, t: 1.06 })
    ], 0)
  ],
  crs: [['c1', 'Valuation and negotiation course', 14000, 2, 5]]
});
B('pets', 'Pet daycare and grooming', 'svc', 'Services', {
  blurb: 'Daycare, boarding and grooming. Animals get sick, owners complain.',
  unit: 'visit',
  ticket: 340,
  cogs: 0.1,
  m: 0.12,
  ela: 1.3,
  b2b: 0,
  own: 0.8,
  std: [['groom', 3], ['helper', 2]],
  mgr: 'ops',
  fixed: 1800,
  open: 16000,
  aud: 0.2,
  skill: 'Animal care',
  minSize: 0.4,
  maxSize: 3,
  seas: 'summer',
  prem: ['warehouse', 140],
  docs: ['org', 'mva', 'ped', 'hms', 'gdpr'],
  ev: ['c_dogBite'],
  eq: [
    E('kennel', 'Kennels and play zones', 18000, 8, 6, 'rc'),
    E('groom', 'Grooming stations', 28000, 6, 2, 'rc'),
    E('van', 'Pet taxi van', 190000, 7, 1, 'v', ['van_s', 'ev_van']),
    E('cctv', 'Cameras and climate control', 42000, 8, 1, 'q')
  ],
  knobs: [
    K('svc', 'Services', '', [
      O('day', 'Daycare focus', 'Dog daycare during working hours.', {}),
      O('groom', 'Grooming focus', 'Higher ticket, fewer visits.', { t: 1.4, d: 0.75 }),
      O('board', 'Boarding and holidays', 'Seasonal peaks.', { t: 1.6, d: 0.6 })
    ], 0),
    KM('also', 'Also offer', 'Several can run together.', [
      O('groom', 'Grooming', 'A wash and cut while they stay.', { t: 1.08 }),
      O('shop', 'Food and toys for sale', 'Owners buy at pick-up.', { t: 1.06, c: 0.03 }),
      O('taxi', 'Pick-up and drop-off', 'A van collects the dogs in the morning.', { d: 1.06, w: 700 })
    ], 0)
  ],
  crs: [['c1', 'Animal first aid course', 3500, 1, 4]]
});
/* round 56: a car repair workshop. Labour is billed by the hour (about 1 200-1 600 kr an hour ex VAT in Norway, 2 500
   and more at premium brands, klikk.no), parts come on top with a margin; tyre changes peak in spring and autumn;
   approved workshops can do the periodic roadworthiness test. */
SEAS.tyres = [.8, .8, 1, 1.45, 1.1, .85, .7, .8, .95, 1.45, 1.3, .8];
DOCS.verk = ['Workshop approval', '{auth:road}', 8500, 6, 2500, 'Approval to repair vehicles; periodic inspections need their own approval and an inspection lane.'];
B('carrepair', 'Car repair workshop', 'svc', 'Services', {
  blurb: 'Service, repairs, tyres and inspections. Mechanics bill by the hour and parts carry a margin.',
  unit: 'job',
  ticket: 4200,
  cogs: 0.36,
  m: 0.07,
  ela: 1.1,
  seas: 'tyres',
  b2b: 0.3,
  terms: 2,
  own: 1,
  std: [['mech', 3], ['recept', 1]],
  mgr: 'ops',
  fixed: 2600,
  open: 15000,
  aud: 0.35,
  skill: 'Mechanics',
  minSize: 0.5,
  maxSize: 3,
  prem: ['industrial', 420],
  docs: ['org', 'mva', 'acctr', 'hms', 'vik', 'verk'],
  eq: [
    E('lift', 'Two-post car lifts', 85000, 12, 3, 'rc'),
    E('diag', 'Diagnostic computer and software', 120000, 6, 1, 'rq'),
    E('tyre', 'Tyre changer and wheel balancer', 65000, 10, 1, 'r'),
    E('tools', 'Workshop tools and air system', 60000, 6, 1, 'c'),
    E('align', 'Wheel alignment rig', 180000, 10, 0, 'q'),
    E('inspect', 'Inspection lane (brakes, emissions)', 450000, 12, 0, 'q')
  ],
  knobs: [
    K('focus', 'Workshop focus', 'What kind of work you go after.', [
      O('quick', 'Tyres and quick service', 'Many short jobs, steady in spring and autumn.', { t: 0.55, k: 1.6, d: 1.25 }),
      O('all', 'All makes, all repairs', 'Service and repairs for any car at normal rates.', {}),
      O('brand', 'Brand-authorised workshop', 'Higher rates and warranty work for one brand; needs the diagnostic kit and training.', { t: 1.35, d: 0.8, q: 5, c: 0.02 })
    ], 1),
    K('parts', 'Parts', 'What goes into the cars.', [
      O('oem', 'Original parts', 'Costs more, fewer comebacks.', { c: 0.03, q: 3 }),
      O('pattern', 'Quality pattern parts', 'The usual choice for older cars.', {}),
      O('cheap', 'Cheapest parts', 'Lower prices, more cars back with problems.', { c: -0.04, q: -5, r: 1.3 })
    ], 1)
  ],
  crs: [['c1', 'Electric and hybrid vehicle safety', 12000, 2, 6], ['c2', 'Advanced diagnostics', 9500, 1, 4]],
  ev: ['c_damage']
});

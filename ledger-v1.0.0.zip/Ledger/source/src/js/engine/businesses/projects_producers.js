/* ---- src/businesses/projects_producers.js ---- */
/* ===== Project-based firms and producers ===== */
/* project: tw.job = avg contract NOK, tw.wks = duration, tw.over = overrun sd, tw.mgn = bid margin baseline */
B('construction', 'Construction firm', 'project', 'Building and projects', {
  blurb: 'Bid for building contracts. Winning is easy if you undercut; surviving the overruns is not.',
  unit: 'contract',
  ticket: 2400000,
  cogs: 0.0,
  m: 0.26,
  ela: 2.0,
  seas: 'build',
  b2b: 0.9,
  terms: 6,
  own: 0.5,
  std: [['labour', 8], ['carp', 4], ['foreman', 1], ['pm', 1]],
  mgr: 'site',
  fixed: 6500,
  open: 120000,
  aud: 0.7,
  skill: 'Construction',
  minSize: 0.4,
  maxSize: 3,
  needAS: true,
  prem: ['industrial', 350],
  docs: ['org', 'mva', 'acctr', 'tgodk', 'hms', 'safety'],
  tw: { job: 2400000, wks: 14, over: 0.09, mat: 0.42, sub: 0.18 },
  ev: ['p_scaffold'],
  eq: [
    E('tools', 'Tools and formwork', 320000, 7, 1, 'rc'),
    E('scaf', 'Scaffolding system', 450000, 10, 1, 'rc'),
    E('exc', 'Excavator 14 t', 1250000, 10, 1, 'v', ['excav']),
    E('vans', 'Work vans', 330000, 7, 3, 'rv', ['van_s', 'van_l', 'pickup']),
    E('crane', 'Mobile crane', 2900000, 15, 0, 'v', ['crane']),
    E('it', 'Estimating software', 85000, 2, 1, 'rq')
  ],
  knobs: [
    K('seg', 'Market segment', '', [
      O('house', 'Houses and extensions', 'Many small jobs, consumer disputes.', { t: 0.4, d: 1.8, r: 1.1 }),
      O('comm', 'Commercial building', 'Offices and shops for businesses: fewer, bigger jobs.', {}),
      O('pub', 'Public tenders', 'Slow, price-driven, steady.', { t: 2.2, d: 0.55, r: 0.9 })
    ], 1),
    K('subs', 'Subcontractors', '', [
      O('own', 'Mostly own crews', 'Control and quality.', { q: 3 }),
      O('sub', 'Use subcontractors for peaks', 'Flexible, margin leakage.', { k: 1.25, c: 0.03, r: 1.2 })
    ], 0)
  ],
  crs: [['c1', 'Project management (PMP)', 28000, 6, 5], ['c2', 'workplace safety and fall-protection course', 7500, 1, 3]]
});
B('electrician', 'Electrical contractor', 'project', 'Building and projects', {
  blurb: 'Installations and service for homes and buildings. Certified staff are the bottleneck.',
  unit: 'job',
  ticket: 85000,
  cogs: 0.0,
  m: 0.1,
  ela: 1.5,
  seas: 'build',
  b2b: 0.6,
  terms: 4,
  own: 0.7,
  std: [['elec', 6], ['helper', 1]],
  mgr: 'site',
  fixed: 3500,
  open: 60000,
  aud: 0.5,
  skill: 'Electrical',
  minSize: 0.4,
  maxSize: 3,
  prem: ['industrial', 160],
  docs: ['org', 'mva', 'acctr', 'elvirk', 'hms'],
  tw: { job: 85000, wks: 3, over: 0.06, mat: 0.38, sub: 0.0 },
  ev: ['p_shock'],
  eq: [
    E('tools', 'Tools and test instruments', 120000, 6, 1, 'rc'),
    E('vans', 'Fitted vans', 400000, 7, 3, 'rcv', ['van_s', 'van_l', 'ev_van']),
    E('lift', 'Lift platform / ladders', 90000, 10, 1, 'q'),
    E('sw', 'Job and quoting software', 38000, 2, 1, 'rq')
  ],
  knobs: [
    K('seg', 'Focus', '', [
      O('home', 'Homes and service', 'Quick jobs, higher hourly pay.', { t: 0.35, d: 2.2, r: 0.9 }),
      O('mix', 'Mixed', 'Some homes, some businesses. Steady work, no extremes.', {}),
      O('ind', 'Industrial and solar installs', 'Big jobs, strict documentation.', { t: 2.4, d: 0.5, r: 1.1 })
    ], 1),
    KM('also', 'Also offer', 'Several can run together.', [
      O('solar', 'Solar panels and car chargers', 'Bigger jobs. Needs training and stock.', { t: 1.12, d: 1.05, w: 800 }),
      O('night', '24-hour call-outs', 'Emergency rates, tired electricians.', { t: 1.08, q: -1 }),
      O('svcag', 'Service agreements', 'Regular checks for buildings at a lower rate.', { d: 1.06, t: 0.97 })
    ], 0)
  ],
  crs: [['c1', 'High-voltage and solar course', 24000, 3, 6]]
});
B('plumber', 'Plumbing firm', 'project', 'Building and projects', {
  blurb: 'Pipes, bathrooms and heating. Emergency work pays well, big bathrooms are risky.',
  unit: 'job',
  ticket: 78000,
  cogs: 0.0,
  m: 0.1,
  ela: 1.5,
  seas: 'winter',
  b2b: 0.5,
  terms: 4,
  own: 0.7,
  std: [['plumb', 6], ['helper', 1]],
  mgr: 'site',
  fixed: 3200,
  open: 55000,
  aud: 0.4,
  skill: 'Plumbing',
  minSize: 0.4,
  maxSize: 3,
  prem: ['industrial', 150],
  docs: ['org', 'mva', 'acctr', 'vvs', 'hms'],
  tw: { job: 78000, wks: 3, over: 0.07, mat: 0.36, sub: 0.0 },
  ev: ['p_leak'],
  eq: [
    E('tools', 'Pipe tools and press equipment', 140000, 6, 1, 'rc'),
    E('vans', 'Fitted vans', 400000, 7, 3, 'rcv', ['van_s', 'van_l', 'ev_van']),
    E('cam', 'Drain camera and leak detector', 85000, 6, 1, 'q'),
    E('sw', 'Job software', 38000, 2, 1, 'rq')
  ],
  knobs: [
    K('seg', 'Focus', '', [
      O('em', '24h emergency service', 'Premium rates, nights.', { t: 0.4, d: 1.8, w: 2500, r: 1.1 }),
      O('mix', 'Mixed', 'Ordinary repairs and installations at normal rates.', {}),
      O('bath', 'Bathroom renovation', 'Large tickets, moisture claims.', { t: 2.0, d: 0.6, r: 1.3 })
    ], 1),
    KM('also', 'Also offer', 'Several can run together.', [
      O('night', 'Emergency call-outs', 'Burst pipes at night pay well.', { t: 1.08, q: -1 }),
      O('bath', 'Bathroom renovations', 'Long jobs at a good price.', { t: 1.15, d: 0.97 }),
      O('heat', 'Heat pumps', 'Fit heat pumps as heating changes.', { t: 1.1, d: 1.04, w: 600 })
    ], 0)
  ],
  crs: [['c1', 'Heat pump installer certificate', 18000, 2, 5]]
});
B('realdev', 'Real-estate development', 'project', 'Building and projects', {
  blurb: 'Buy land, get it zoned, build and sell homes. Huge capital, slow cycles, and the housing market can turn on you.',
  unit: 'unit sold',
  ticket: 4800000,
  cogs: 0.0,
  m: 0.12,
  ela: 1.0,
  vat: 'zero',
  seas: 'spring',
  b2b: 0.0,
  terms: 0,
  own: 0.1,
  std: [['pm', 2], ['projc', 1], ['recept', 1]],
  mgr: 'prop',
  fixed: 12000,
  open: 800000,
  aud: 0.4,
  skill: 'Development',
  minSize: 0.4,
  maxSize: 3,
  needAS: true,
  prem: ['office', 120],
  docs: ['org', 'mva', 'acctr', 'tgodk', 'bygg', 'regplan', 'hms', 'aml'],
  tw: { dev: 1, units: 24, land: 18000000, build: 31000000, wks: 70 },
  ev: ['d_zoning', 'd_market', 'd_costOver'],
  eq: [
    E('cad', 'Design and cost software', 180000, 2, 1, 'rq'),
    E('lap', 'Laptops', 22000, 3, 5, 'rc'),
    E('show', 'Showroom and sales material', 240000, 3, 1, 'q')
  ],
  knobs: [
    K('seg', 'Segment', '', [
      O('apt', 'Apartments (starter homes)', 'Fastest to sell.', {}),
      O('lux', 'Premium apartments', 'Higher margin, slower buyers.', { t: 1.35, d: 0.7, r: 1.2 }),
      O('town', 'Townhouses and detached', 'Land-heavy.', { t: 1.1, d: 0.85 })
    ], 0),
    K('fin', 'Funding of projects', '', [
      O('lev', 'Construction loan (up to 70%)', 'Interest meter runs. Bank wants presales.', {}),
      O('eq', 'Mostly equity', 'Safer, ties up capital.', { r: 0.8 })
    ], 0)
  ],
  crs: [['c1', 'Development finance course', 20000, 3, 5]]
});
B('event', 'Event and production agency', 'project', 'Building and projects', {
  blurb: 'Conferences, concerts and weddings. Deposits are paid late and deadlines are immovable.',
  unit: 'event',
  ticket: 380000,
  cogs: 0.0,
  m: 0.1,
  ela: 1.5,
  seas: 'hosp',
  b2b: 0.9,
  terms: 4,
  own: 0.6,
  std: [['event', 3], ['av', 2], ['sales', 1]],
  mgr: 'sales',
  fixed: 4000,
  open: 50000,
  aud: 0.7,
  skill: 'Events',
  minSize: 0.4,
  maxSize: 3,
  prem: ['warehouse', 220],
  docs: ['org', 'mva', 'acctr', 'event', 'hms'],
  tw: { job: 380000, wks: 4, over: 0.1, mat: 0.55, sub: 0.0 },
  ev: ['p_weather'],
  eq: [
    E('sound', 'Sound, light and LED screens', 650000, 6, 1, 'rcq'),
    E('stage', 'Stage, truss and rigging', 420000, 8, 1, 'rc'),
    E('van', 'Production van', 400000, 7, 2, 'v', ['van_l', 'van_s']),
    E('sw', 'Ticketing and planning software', 45000, 2, 1, 'rq')
  ],
  knobs: [
    K('seg', 'Focus', '', [
      O('corp', 'Corporate events', 'Reliable budgets.', {}),
      O('conc', 'Concerts and festivals', 'Big upside, weather and sales risk.', { t: 2.0, d: 0.6, r: 1.4 }),
      O('wed', 'Weddings', 'Seasonal and emotional.', { t: 0.35, d: 2.4 })
    ], 0),
    KM('also', 'Also offer', 'Several can run together.', [
      O('cater', 'Catering partners', 'Food from one hand, with your margin.', { t: 1.1, c: 0.03 }),
      O('stage', 'Stage and sound hire', 'Rent out your rig between events.', { d: 1.05, w: 1000 }),
      O('own', 'Your own ticketed events', 'Big nights of your own: more to gain, more to lose.', { t: 1.12, r: 1.15 })
    ], 0)
  ],
  crs: [['c1', 'Safety and crowd management', 12500, 1, 4]]
});
B('engcons', 'Engineering and architecture office', 'project', 'Building and projects', {
  blurb: 'Design buildings and infrastructure for developers and municipalities. Winning tenders is a craft.',
  unit: 'contract',
  ticket: 770000,
  cogs: 0.0,
  m: 0.13,
  ela: 1.2,
  seas: 'build',
  b2b: 0.95,
  terms: 4,
  own: 0.5,
  std: [['engineer', 5], ['architect', 2], ['pm', 1]],
  mgr: 'pro',
  fixed: 7000,
  open: 90000,
  aud: 0.8,
  skill: 'Engineering',
  minSize: 0.4,
  maxSize: 3,
  needAS: true,
  prem: ['office', 160],
  docs: ['org', 'mva', 'acctr', 'tgodk', 'hms', 'gdpr'],
  tw: { job: 770000, wks: 10, over: 0.07, mat: 0.0, sub: 0.0 },
  ev: ['p_defect'],
  eq: [
    E('cad', 'CAD/BIM licences', 420000, 1, 1, 'rq'),
    E('lap', 'Workstations', 36000, 3, 8, 'rc'),
    E('plot', 'Plotter and survey gear', 120000, 6, 1, 'q')
  ],
  knobs: [
    K('seg', 'Focus', '', [
      O('bld', 'Buildings', 'Design for houses, offices and public buildings.', {}),
      O('inf', 'Roads and infrastructure', 'Public tenders, big sums.', { t: 1.9, d: 0.55 }),
      O('res', 'Residential and rehab', 'Small commissions, many.', { t: 0.4, d: 2.2 })
    ], 0),
    KM('also', 'Also offer', 'Several can run together.', [
      O('tender', 'Public tenders', 'More work at tighter prices.', { d: 1.08, t: 0.95 }),
      O('insp', 'Inspections and reports', 'Small paid jobs between projects.', { d: 1.05 }),
      O('pm', 'Project management', 'Run the building site for the client.', { t: 1.1 })
    ], 0)
  ],
  crs: [['c1', 'BIM and sustainability certification', 25000, 4, 6]]
});
/* producers: tw.stock days of finished goods, tw.perish per week of waste */
B('bakery', 'Bakery and pastry', 'prod', 'Production and primary', {
  blurb: 'Bake for the shop counter and wholesale to cafés. Early hours, waste, ovens and cold-chain.',
  unit: 'item',
  ticket: 54,
  cogs: 0.28,
  m: 0.14,
  ela: 1.6,
  vat: 'food',
  seas: 'xmas',
  b2b: 0.4,
  terms: 3,
  own: 0.8,
  std: [['baker', 4], ['helper', 2], ['cashier', 2]],
  mgr: 'ind',
  fixed: 2800,
  open: 70000,
  aud: 0.3,
  skill: 'Baking',
  minSize: 0.4,
  maxSize: 2.5,
  prem: ['kitchen', 180],
  docs: ['org', 'mva', 'mattil', 'haccp', 'hms', 'vik'],
  tw: { perish: 0.08, stock: 1, shrink: 0.01 },
  ev: ['pr_flour'],
  eq: [
    E('oven', 'Deck and rack ovens', 160000, 10, 3, 'rc'),
    E('mix', 'Mixers and dough sheeter', 90000, 10, 2, 'rc'),
    E('proof', 'Proofers and retarders', 65000, 10, 2, 'r'),
    E('disp', 'Shop counter and display', 80000, 8, 1, 'rq'),
    E('van', 'Delivery van', 190000, 7, 1, 'v', ['van_s', 'ev_van'])
  ],
  knobs: [
    K('mix', 'Mix', '', [
      O('ret', 'Mostly own shop', 'Higher price per item.', { t: 1.15, d: 0.9 }),
      O('mix', 'Shop and wholesale', 'Half over the counter, half to cafés and shops.', {}),
      O('wh', 'Mostly wholesale to cafés and shops', 'Volume at lower price.', { t: 0.75, d: 1.3 })
    ], 1),
    K('craft', 'Craft level', '', [
      O('ind', 'Industrial speed', 'Faster and cheaper, a little lower quality.', { c: -0.03, q: -3 }),
      O('std', 'Standard', 'Ordinary recipes at ordinary speed.', {}),
      O('sour', 'Slow-fermented sourdough', 'Premium, takes time.', { t: 1.3, q: 6, k: 0.85, c: 0.03 })
    ], 1)
  ],
  crs: [['c1', 'Pastry masterclass', 12000, 1, 4]]
});
B('brewery', 'Craft brewery', 'prod', 'Production and primary', {
  blurb: 'Brew beer for bars, shops and a taproom. Excise duty is a big slice of every litre.',
  unit: 'litre',
  ticket: 82,
  cogs: 0.5,
  m: 0.14,
  ela: 1.3,
  seas: 'summer',
  b2b: 0.7,
  terms: 4,
  own: 0.6,
  std: [['operator', 3], ['helper', 1], ['sales', 1]],
  mgr: 'ind',
  fixed: 4200,
  open: 120000,
  aud: 0.4,
  skill: 'Brewing',
  minSize: 0.4,
  maxSize: 3,
  prem: ['industrial', 450],
  docs: ['org', 'mva', 'acctr', 'mattil', 'haccp', 'brygg', 'vinm', 'hms', 'vik'],
  tw: { perish: 0.012, stock: 14, shrink: 0.005, excise: 1 },
  ev: ['pr_batch'],
  eq: [
    E('brew', 'Brewhouse', 1400000, 15, 1, 'rc'),
    E('fer', 'Fermentation tanks', 220000, 15, 6, 'rc'),
    E('bot', 'Bottling and kegging line', 650000, 12, 1, 'rc'),
    E('cold', 'Cold room', 260000, 12, 1, 'r'),
    E('tap', 'Taproom fit-out', 480000, 10, 1, 'q'),
    E('van', 'Distribution truck', 950000, 8, 1, 'v', ['truck_s', 'van_l'])
  ],
  knobs: [
    K('line', 'Product line', '', [
      O('core', 'Core lagers and ales', 'Stable, price-competitive.', {}),
      O('craft', 'Experimental craft beers', 'Higher price, batch failures.', { t: 1.35, d: 0.75, q: 5, r: 1.4 }),
      O('zero', 'Low-alcohol and cider', 'Growing segment.', { t: 0.95, d: 1.1 })
    ], 0),
    KM('tap', 'Also run', 'Several can run together.', [
      O('tap', 'A taproom', 'High retail margin. Needs a serving licence.', { t: 1.12, d: 1.1, w: 3500, req: ['skjenk'] }),
      O('tour', 'Brewery tours', 'Visitors pay and take beer home.', { d: 1.04, t: 1.03, w: 300 }),
      O('contract', 'Brewing for others', 'Steady volume at lower prices.', { d: 1.12, t: 0.92 })
    ], 0)
  ],
  crs: [['c1', 'Brewmaster course', 28000, 4, 6]]
});
B('furniture', 'Furniture workshop', 'prod', 'Production and primary', {
  blurb: 'Make quality furniture to order. Wood prices, craftspeople and retail partners decide the margin.',
  unit: 'piece',
  ticket: 14500,
  cogs: 0.38,
  m: 0.1,
  ela: 1.4,
  seas: 'xmas',
  b2b: 0.5,
  terms: 5,
  own: 0.7,
  std: [['carp', 5], ['helper', 1], ['sales', 1]],
  mgr: 'ind',
  fixed: 3200,
  open: 80000,
  aud: 0.4,
  skill: 'Craft',
  minSize: 0.4,
  maxSize: 3,
  prem: ['industrial', 700],
  docs: ['org', 'mva', 'acctr', 'hms', 'fabrik'],
  tw: { stock: 20, perish: 0, shrink: 0.004 },
  ev: ['pr_wood'],
  eq: [
    E('cnc', 'CNC router', 780000, 10, 1, 'rc'),
    E('saw', 'Panel saw and edge bander', 420000, 12, 1, 'rc'),
    E('paint', 'Finishing booth', 320000, 12, 1, 'r'),
    E('fork', 'Forklift', 280000, 10, 1, 'r'),
    E('van', 'Delivery van', 330000, 7, 1, 'v', ['van_l'])
  ],
  knobs: [
    K('seg', 'Customers', '', [
      O('bsp', 'Custom for homes', 'High price, slow.', { t: 1.5, d: 0.7 }),
      O('ser', 'Series for retail partners', 'Volume, bigger buyers, thinner margin.', { t: 0.8, d: 1.3 }),
      O('contract', 'Contract: offices and hotels', 'Large invoices, long terms.', { t: 1.15, d: 0.9, r: 1.1 })
    ], 0),
    KM('also', 'Also offer', 'Several can run together.', [
      O('custom', 'Made to order', 'Higher prices, slower work.', { t: 1.12, k: 0.92 }),
      O('web', 'Sell online direct', 'No shop in between.', { d: 1.08, w: 1000 }),
      O('uph', 'Upholstery and repairs', 'Old chairs come back to life.', { d: 1.04 })
    ], 0)
  ],
  crs: [['c1', 'CNC programming', 16000, 2, 5]]
});
B('salmon', 'Salmon farm', 'prod', 'Production and primary', {
  blurb: 'Raise salmon in sea pens for 18 months, then harvest at the market price. Licences are expensive, lice and storms can wipe out a cycle.',
  unit: 'tonne',
  ticket: 84000,
  cogs: 0.0,
  m: 0.12,
  ela: 0.0,
  seas: 'fish',
  b2b: 1.0,
  terms: 3,
  own: 0,
  std: [['fishtech', 6], ['operator', 2]],
  mgr: 'ind',
  fixed: 18000,
  open: 2000000,
  aud: 0.0,
  skill: 'Aquaculture',
  minSize: 1,
  maxSize: 3,
  needAS: true,
  prem: ['yard', 400],
  docs: ['org', 'mva', 'acctr', 'aqua', 'fishq', 'hms', 'fabrik'],
  tw: { cycle: 1, tonnes: 3500, smolt: 14.0, feed: 11.5, grow: 78 },
  ev: ['pr_lice', 'pr_storm', 'pr_algae'],
  eq: [
    E('pens', 'Sea pens and moorings', 22000000, 12, 1, 'rc'),
    E('feedb', 'Feed barge', 14000000, 15, 1, 'rc'),
    E('boat', 'Work boats', 4200000, 12, 2, 'r'),
    E('cam', 'Underwater cameras and sensors', 1800000, 6, 1, 'q'),
    E('lice', 'Lice treatment system', 5500000, 8, 1, 'q')
  ],
  knobs: [
    K('feed', 'Feed strategy', '', [
      O('std', 'Standard feed', 'Normal cost and growth.', {}),
      O('prem', 'Premium feed (faster growth)', 'Cost up, growth up.', { c: 0.05, q: 4 }),
      O('eco', 'Cheap feed', 'Lower cost, slower growth and more disease.', { c: -0.04, q: -4, r: 1.3 })
    ], 0),
    K('den', 'Stocking density', '', [
      O('low', 'Low density', 'Safer.', { r: 0.7, k: 0.8 }),
      O('std', 'Standard', 'The usual number of fish per pen.', {}),
      O('high', 'High density', 'More fish, more disease.', { r: 1.5, k: 1.2 })
    ], 1)
  ],
  crs: [['c1', 'Fish-health and welfare', 22000, 3, 5]]
});
B('factory', 'Manufacturing factory', 'prod', 'Production and primary', {
  blurb: 'Machine parts and components for industrial buyers. Capital intensive with long customer terms.',
  unit: 'order lot',
  ticket: 62000,
  cogs: 0.52,
  m: 0.09,
  ela: 1.4,
  seas: 'flat',
  b2b: 0.95,
  terms: 8,
  own: 0.1,
  std: [['operator', 14], ['tech', 3], ['lab', 1], ['engineer', 2], ['buyer', 1], ['sales', 2]],
  mgr: 'ind',
  fixed: 22000,
  open: 600000,
  aud: 0.6,
  skill: 'Manufacturing',
  minSize: 0.4,
  maxSize: 2.5,
  needAS: true,
  prem: ['industrial', 4000],
  docs: ['org', 'mva', 'acctr', 'fabrik', 'ce', 'hms', 'vik'],
  tw: { stock: 12, perish: 0, shrink: 0.003 },
  ev: ['pr_cust'],
  eq: [
    E('cnc', 'CNC machining lines', 2400000, 12, 6, 'rc'),
    E('robot', 'Robot cell and automation', 3800000, 10, 1, 'qc'),
    E('fork', 'Forklifts and cranes', 380000, 10, 3, 'r'),
    E('air', 'Compressors and utilities', 650000, 12, 1, 'r'),
    E('lab', 'Quality lab and measuring', 900000, 10, 1, 'rq'),
    E('erp', 'ERP / planning', 380000, 3, 1, 'rq')
  ],
  knobs: [
    K('line', 'Product line', 'Vehicles are made here too. Cars, trucks and boats are sold through dealers, and you can open your own.', [
      O('parts', 'Machine parts and components', 'Industrial buyers.', {}),
      O('cars', 'Cars and vans', 'Large ticket, sold to dealers and fleets.', { t: 1.6, d: 0.75, q: 3 }),
      O('trucks', 'Trucks and buses', 'Few, very large orders.', { t: 2.0, d: 0.6 }),
      O('boats', 'Boats and vessels', 'Slow builds, big tickets.', { t: 2.3, d: 0.5, r: 1.1 })
    ], 0),
    K('seg', 'Customers', '', [
      O('oem', 'OEM contracts', 'Volume, hard price pressure.', { t: 0.85, d: 1.25 }),
      O('mix', 'Mixed', 'Some contract volume, some special orders.', {}),
      O('spec', 'Special parts and prototypes', 'High price, small series.', { t: 1.4, d: 0.65, q: 5 })
    ], 1)
  ],
  crs: [['c1', 'Lean manufacturing', 18000, 3, 5], ['c2', 'CNC advanced programming', 22000, 3, 5]]
});
/* round 57: what a farm grows depends on the climate of its country (O(..., cc): the countries it fits) */
const FARM_CC = {
  grain: 'NO SE PL LT DE UK FR ES NL US CA AU BR CH MX IT DK FI IE',
  milk: 'NO SE PL LT DE UK FR ES NL US CA AU JP KR BR CH MX AE IT DK FI IE',
  forest: 'NO SE FI CA US DE PL LT FR JP KR BR AU CH UK IE',
  potato: 'NO SE FI DK IE UK NL PL LT DE CA US JP',
  orchard: 'NO SE PL LT DE FR IT US CA CH UK NL DK JP KR',
  rice: 'JP KR IT ES US BR',
  olive: 'IT ES FR US AU',
  citrus: 'ES IT US BR MX AU JP KR',
  coffee: 'BR MX',
  soy: 'BR US CA MX',
  beef: 'BR AU US MX CA IE',
  sheep: 'AU IE UK NO',
  green: 'NL DK FI NO SE CA ES AE KR JP',
  vert: 'SG AE JP KR NL US UK',
  dates: 'AE',
  tea: 'JP KR',
  avo: 'MX',
  sugar: 'BR AU MX'
};
const FC = k => FARM_CC[k].split(' ');
B('farm', 'Farm and forestry', 'prod', 'Production and primary', {
  blurb: 'Grow what your climate allows: grain, milk, timber, rice, olives, coffee, dates or greens under lights. Weather, subsidies and prices drive results; land is a safe asset.',
  unit: 'tonne',
  ticket: 5200,
  cogs: 0.34,
  m: 0.22,
  ela: 0.3,
  vat: 'food',
  seas: 'fish',
  b2b: 0.9,
  terms: 4,
  own: 0.8,
  std: [['farmh', 2]],
  mgr: 'ind',
  fixed: 5500,
  open: 200000,
  aud: 0.0,
  skill: 'Agriculture',
  minSize: 0.4,
  maxSize: 3,
  prem: ['yard', 2000],
  docs: ['org', 'mva', 'landb', 'skog', 'hms'],
  tw: { stock: 30, perish: 0.004, harvest: 1, subsidy: 0.12 },
  ev: ['pr_weather', 'pr_subsidy'],
  eq: [
    E('tract', 'Tractor and implements', 1100000, 12, 1, 'rc'),
    E('harv', 'Harvester / forwarder (shared)', 3600000, 12, 1, 'rc'),
    E('barn', 'Barn and storage', 1400000, 25, 1, 'r'),
    E('dry', 'Grain dryer / sawmill access', 700000, 15, 1, 'q')
  ],
  knobs: [
    K('mix', 'What you grow', 'Only what fits the climate of your country.', [
      O('grain', 'Grain and oilseeds', 'Wheat, barley and rapeseed: weather risk.', {}, FC('grain')),
      O('milk', 'Milk and livestock', 'Daily work, steady price.', { t: 1.15, d: 0.9 }, FC('milk')),
      O('forest', 'Forestry', 'Slow growth, big harvests.', { t: 1.35, d: 0.7, r: 0.9 }, FC('forest')),
      O('potato', 'Potatoes and root vegetables', 'Big volumes at low prices.', { t: 0.9, d: 1.15 }, FC('potato')),
      O('orchard', 'Apples and pears', 'Orchards take years to grow; a frost can take a year’s crop.', { t: 1.2, d: 0.85, r: 1.2 }, FC('orchard')),
      O('rice', 'Rice', 'Paddies that need plenty of water.', { d: 1.05 }, FC('rice')),
      O('olive', 'Olives and olive oil', 'A premium oil from old trees; drought years hurt.', { t: 1.3, d: 0.8, r: 1.1 }, FC('olive')),
      O('citrus', 'Citrus fruit', 'Oranges, lemons and mandarins for shops and juice.', { t: 1.2, d: 0.9 }, FC('citrus')),
      O('coffee', 'Coffee', 'Beans for roasters at home and abroad; the world price swings.', { t: 1.4, d: 0.8, r: 1.3 }, FC('coffee')),
      O('soy', 'Soy and maize', 'Huge fields for feed and export.', { t: 0.9, d: 1.2 }, FC('soy')),
      O('beef', 'Beef cattle on open range', 'Big herds on cheap land.', { t: 1.1, d: 0.95 }, FC('beef')),
      O('sheep', 'Sheep and wool', 'Lamb and wool from grazing land.', { t: 0.95 }, FC('sheep')),
      O('green', 'Greenhouse vegetables', 'Tomatoes and cucumbers all year; heating costs.', { t: 1.3, c: 0.05 }, FC('green')),
      O('vert', 'Vertical farm (leafy greens)', 'Salad and herbs under LED lights in a warehouse; power is the big cost.', { t: 1.6, d: 0.7, c: 0.08 }, FC('vert')),
      O('dates', 'Date palms', 'Dates for the home market and for export.', { t: 1.3, d: 0.85 }, FC('dates')),
      O('tea', 'Tea', 'Green tea from terraced fields.', { t: 1.2, d: 0.85 }, FC('tea')),
      O('avo', 'Avocados', 'Export demand is strong; water and theft are risks.', { t: 1.4, d: 0.85, r: 1.2 }, FC('avo')),
      O('sugar', 'Sugar cane', 'Cane for sugar and ethanol.', { t: 0.85, d: 1.25 }, FC('sugar'))
    ], 0),
    K('how', 'How you farm', 'The method behind the crop.', [
      O('conv', 'Conventional', 'Normal yields at market prices.', {}),
      O('organic', 'Organic', 'Better prices for less from each field.', { t: 1.3, k: 0.85, w: 600, q: 2 }),
      O('contract', 'Grown for a buyer', 'A wholesaler takes it all at an agreed, lower price.', { t: 0.92, d: 1.3 })
    ], 0)
  ],
  crs: [['c1', 'Precision-farming course', 9000, 1, 4]]
});


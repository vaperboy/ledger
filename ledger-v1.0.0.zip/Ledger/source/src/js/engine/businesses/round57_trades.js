/* ---- src/businesses/round57_trades.js ---- */
/* ===== Round 57: six new trades.
   Amounts are Norway-priced base units (the game scales them by each country's price and wage level).
   - Dental clinic: check-ups and fillings at about 1 000-1 600 kr in Norway (Den norske tannlegeforening price surveys),
     dentists earn about 80 000 kr a month; X-ray units must be registered with the radiation authority.
   - Game studio: work for other studios by the hour, or your own games: free-to-play mobile titles and premium games
     are hit-driven (most earn little, a few earn a lot).
   - Private security: guarding billed at about 450-650 kr an hour, low margins, a licence from the police.
   - Vineyard: only where wine grapes ripen (BANNED.vineyard); harvest in the autumn, the wine sells all year with a
     peak before Christmas; alcohol excise and a wholesale licence.
   - PC gaming café: hours at gaming PCs, snacks and tournaments. Very big in Korea (the PC bang), well known in Japan,
     a niche elsewhere (features/world/round57_trade_fit.js).
   - Car rental: a fleet rented by the day, busiest in the tourist summer; airport desks pay more rent and get more
     customers. ===== */
ROLES.dentist = ['Dentist', 82000];
ROLES.dentnurse = ['Dental nurse', 43000];
ROLES.vintner = ['Winemaker', 52000];
ROLES.rentag = ['Rental agent', 38000];
DOCS.xray = ['X-ray equipment registration', 'Radiation authority', 3500, 4, 0, 'Dental X-ray units are registered before they are used.'];
DOCS.vakt = ['Security company licence', 'The police', 6000, 8, 0, 'Guards need approved training and a clean record.'];
B('dental', 'Dental clinic', 'svc', 'Services', {
  blurb: 'Check-ups, fillings, crowns and whitening. Patients come back twice a year when you treat them well.',
  unit: 'treatment',
  ticket: 1400,
  cogs: 0.08,
  m: 0.16,
  ela: 0.7,
  vat: 'zero',
  b2b: 0.05,
  own: 0.5,
  std: [['dentist', 2], ['dentnurse', 2], ['recept', 1]],
  mgr: 'clin',
  fixed: 3000,
  open: 30000,
  aud: 0.2,
  skill: 'Clinical',
  minSize: 0.4,
  maxSize: 3,
  prem: ['clinic', 140],
  docs: ['org', 'helse', 'hpr', 'xray', 'hms', 'gdpr'],
  ev: ['c_patient'],
  eq: [
    E('unit', 'Dental treatment units', 420000, 10, 2, 'rc'),
    E('xray', 'Dental X-ray and scanner', 350000, 10, 1, 'rq'),
    E('steril', 'Sterilisation room', 180000, 10, 1, 'r'),
    E('ehr', 'Patient journal and booking system', 30000, 2, 1, 'rq'),
    E('cad', 'Intraoral scanner and crown mill', 650000, 8, 0, 'q')
  ],
  knobs: [
    K('care', 'Treatments', 'What the clinic is known for.', [
      O('gen', 'General dentistry', 'Check-ups, fillings and crowns at normal prices.', {}),
      O('cos', 'Cosmetic and implants', 'Whitening, aligners and implants: higher prices, fewer patients.', { t: 1.5, d: 0.7, q: 4 }),
      O('pub', 'Public contracts and children', 'Many patients at capped prices.', { t: 0.8, d: 1.35 })
    ], 0),
    KM('also', 'Also offer', 'Several can run together.', [
      O('white', 'Teeth whitening', 'Cosmetic work that pays well.', { t: 1.08 }),
      O('ortho', 'Braces and aligners', 'Long treatments at high prices.', { t: 1.12, d: 0.98 }),
      O('acute', 'Emergency appointments', 'Toothache cannot wait: more patients, a busier day.', { d: 1.05, q: -1 })
    ], 0)
  ],
  crs: [['c1', 'Implant surgery course', 45000, 3, 6]]
});
B('gamestudio', 'Game studio', 'svc', 'Services', {
  blurb: 'Make games for other studios, or your own. Your own games are a lottery: most earn little, one hit pays for everything.',
  unit: 'dev hour',
  ticket: 1100,
  cogs: 0.08,
  m: 0.12,
  ela: 1.3,
  b2b: 0.7,
  terms: 4,
  own: 1,
  std: [['dev', 3], ['designer', 2]],
  mgr: 'tech',
  fixed: 3200,
  open: 20000,
  aud: 0.85,
  skill: 'Software',
  minSize: 0.4,
  maxSize: 4,
  prem: ['office', 80],
  docs: ['org', 'mva', 'gdpr', 'hms'],
  ev: ['c_scope', 'c_devquit'],
  eq: [
    E('ws', 'Developer workstations', 32000, 3, 5, 'rc'),
    E('lic', 'Engine and tool licences', 30000, 2, 1, 'rq'),
    E('kits', 'Console dev kits and test devices', 90000, 4, 1, 'q'),
    E('mocap', 'Motion capture and audio booth', 220000, 8, 0, 'q')
  ],
  knobs: [
    K('model', 'What you make', 'Steady work for others, or games of your own.', [
      O('hire', 'Work for other studios', 'Paid by the hour: steady and safe.', {}),
      O('f2p', 'Free-to-play mobile games', 'In-app purchases: more players, hit or miss.', { t: 0.85, d: 1.25, r: 1.6 }),
      O('prem', 'Premium games for PC and console', 'Higher price per game, long gaps between releases.', { t: 1.45, d: 0.7, q: 4, r: 1.8 })
    ], 0),
    KM('also', 'Also offer', 'Several can run together.', [
      O('ports', 'Ports to consoles', 'The same game on more machines.', { d: 1.06, w: 1500 }),
      O('merch', 'Merchandise', 'Shirts and figures for the fans.', { t: 1.05, c: 0.02 }),
      O('early', 'Early access', 'Players pay to play before it is finished.', { d: 1.08, q: -2 })
    ], 0)
  ],
  crs: [['c1', 'Game design masterclass', 15000, 2, 4]]
});
B('security', 'Private security', 'svc', 'Services', {
  blurb: 'Guards for offices, shops, building sites and events, alarm response and cash transport. Thin margins, long contracts.',
  unit: 'guard hour',
  ticket: 520,
  cogs: 0.05,
  m: 0.07,
  ela: 1.2,
  b2b: 0.9,
  terms: 4,
  own: 1,
  std: [['guard', 8], ['dispatch', 1]],
  mgr: 'ops',
  fixed: 2000,
  open: 15000,
  aud: 0.6,
  skill: 'Security',
  minSize: 0.4,
  maxSize: 4,
  prem: ['office', 60],
  docs: ['org', 'mva', 'hms', 'gdpr', 'vakt'],
  eq: [
    E('radio', 'Radios and body cameras', 14000, 4, 8, 'rc'),
    E('car', 'Patrol cars', 420000, 6, 1, 'rcv', ['car_s', 'car_ev']),
    E('alarm', 'Alarm monitoring centre', 260000, 8, 0, 'q'),
    E('uni', 'Uniforms and equipment', 6000, 2, 8, 'q')
  ],
  knobs: [
    K('svc', 'Services', 'What the guards do.', [
      O('guard', 'Guarding', 'Guards on site at offices, shops and building sites.', {}),
      O('patrol', 'Patrols and alarm response', 'Cars on the road answering alarms at night.', { t: 1.2, d: 0.9 }),
      O('event', 'Events and door staff', 'Concerts, festivals and nightlife.', { t: 1.1, d: 1.1, r: 1.2 }),
      O('vip', 'Cash transport and close protection', 'High rates, strict rules, high risk.', { t: 1.6, d: 0.5, q: 5, r: 1.4 })
    ], 0),
    KM('also', 'Also offer', 'Several can run together.', [
      O('alarm', 'Alarm monitoring centre', 'A control room watching alarms day and night.', { d: 1.06, w: 1200 }),
      O('cash', 'Cash in transit', 'Well paid, and a target.', { t: 1.15, r: 1.3 }),
      O('events', 'Event security', 'Concerts and matches at weekends.', { d: 1.05 })
    ], 0)
  ],
  crs: [['c1', 'Security guard certification', 6000, 2, 4]]
});
SEAS.wine = [.8, .7, .8, .85, .9, 1, 1, .95, .95, 1.05, 1.3, 1.7];
B('vineyard', 'Vineyard and winery', 'prod', 'Production and primary', {
  blurb: 'Grow grapes, make wine and sell it to shops, restaurants and visitors. One bad harvest hurts for a year.',
  unit: 'bottle',
  ticket: 160,
  cogs: 0.3,
  m: 0.14,
  ela: 1,
  seas: 'wine',
  b2b: 0.6,
  terms: 4,
  own: 0.7,
  std: [['vintner', 1], ['farmh', 3], ['sales', 1]],
  mgr: 'ind',
  fixed: 3800,
  open: 150000,
  aud: 0.35,
  skill: 'Winemaking',
  minSize: 0.4,
  maxSize: 3,
  prem: ['yard', 2500],
  docs: ['org', 'mva', 'acctr', 'mattil', 'haccp', 'vinm', 'landb', 'hms'],
  tw: { stock: 40, perish: 0.001, harvest: 1, excise: 1 },
  ev: ['pr_weather'],
  eq: [
    E('vines', 'Vineyard (vines and trellis)', 900000, 25, 1, 'rc'),
    E('press', 'Press and crusher', 260000, 15, 1, 'rc'),
    E('tanks', 'Fermentation tanks and barrels', 380000, 15, 4, 'rc'),
    E('bottle', 'Bottling line', 450000, 12, 1, 'r'),
    E('tract', 'Vineyard tractor', 600000, 12, 1, 'r'),
    E('cellar', 'Tasting room', 300000, 12, 0, 'q')
  ],
  knobs: [
    K('wine', 'Wine', 'What goes in the bottle.', [
      O('table', 'Everyday wine', 'Supermarkets and bars: volume at low prices.', { t: 0.8, d: 1.25 }),
      O('estate', 'Estate wine', 'Good wine from your own grapes at normal prices.', {}),
      O('grand', 'Premium aged wine', 'Years in barrel: high prices, few bottles, a bad vintage hurts.', { t: 1.6, d: 0.6, q: 5, r: 1.3 })
    ], 1),
    KM('also', 'Also run', 'Several can run together.', [
      O('tast', 'Tastings at the cellar door', 'Visitors taste and buy. Needs a serving licence.', { t: 1.1, d: 1.05, w: 2500, req: ['skjenk'] }),
      O('event', 'Weddings and wine tours', 'Busy summer weekends.', { d: 1.05, t: 1.05, w: 800 })
    ], 0)
  ],
  crs: [['c1', 'Oenology course', 24000, 3, 5]]
});
B('pcbang', 'PC gaming café', 'venue', 'Food and leisure', {
  blurb: 'Rows of gaming PCs by the hour, snacks and tournaments. Huge in Korea, a niche in most places.',
  unit: 'hour played',
  ticket: 55,
  cogs: 0.15,
  m: 0.1,
  ela: 1.4,
  seas: 'winter',
  b2b: 0.05,
  own: 0.6,
  std: [['cashier', 2], ['ittech', 1]],
  mgr: 'host',
  fixed: 2500,
  open: 40000,
  aud: 0.3,
  skill: 'Hospitality',
  minSize: 0.4,
  maxSize: 3,
  prem: ['shop', 220],
  docs: ['org', 'mva', 'hms', 'mattil', 'gdpr'],
  tw: { perish: 0.02, hours: 100 },
  eq: [
    E('pcs', 'Gaming PCs and monitors', 22000, 4, 40, 'rc'),
    E('seats', 'Gaming chairs and desks', 4500, 6, 40, 'r'),
    E('net', 'Fibre line and network', 60000, 5, 1, 'rq'),
    E('snack', 'Snack bar and drinks', 90000, 8, 1, 'q'),
    E('stage', 'Tournament stage and streaming', 150000, 6, 0, 'q')
  ],
  knobs: [
    K('concept', 'Concept', 'Who you play for.', [
      O('budget', 'Cheap hours', 'Low hourly price, full rooms.', { t: 0.8, d: 1.25 }),
      O('lounge', 'Gaming lounge', 'Good PCs, food and drinks at normal prices.', {}),
      O('arena', 'Esports arena', 'Tournaments and teams: higher prices, fewer walk-ins.', { t: 1.3, d: 0.85, q: 4 })
    ], 1),
    KM('also', 'Also offer', 'Several can run together.', [
      O('tourn', 'Tournaments', 'Weekend cups fill every seat.', { d: 1.06, w: 600 }),
      O('snack', 'Snacks and drinks', 'Players eat at the desk.', { t: 1.12, c: 0.04 }),
      O('vr', 'VR corner', 'Something new to try.', { d: 1.04, t: 1.05, w: 900 })
    ], 0)
  ],
  crs: [['c1', 'Esports event organiser course', 6500, 1, 3]]
});
B('carrental', 'Car rental', 'logi', 'Transport and logistics', {
  blurb: 'Cars and vans by the day for tourists, business travellers and people moving house. The fleet is the business.',
  unit: 'rental day',
  ticket: 750,
  cogs: 0.12,
  m: 0.1,
  ela: 1.3,
  seas: 'summer',
  b2b: 0.3,
  terms: 2,
  own: 0.5,
  std: [['rentag', 2], ['carwash', 1]],
  mgr: 'fleet',
  fixed: 2500,
  open: 30000,
  aud: 0.5,
  skill: 'Logistics',
  minSize: 0.4,
  maxSize: 3,
  prem: ['yard', 600],
  docs: ['org', 'mva', 'acctr', 'hms', 'gdpr'],
  eq: [
    E('cars', 'Rental cars (compact and estate)', 320000, 4, 12, 'rcv', ['car_s', 'car_ev']),
    E('vans', 'Vans for hire', 380000, 5, 2, 'v', ['van_s', 'van_l', 'ev_van']),
    E('desk', 'Rental desk and booking system', 120000, 5, 1, 'rq'),
    E('lux', 'Premium cars', 800000, 4, 0, 'qv', ['car_lux'])
  ],
  knobs: [
    K('where', 'Where you rent out', 'Where the desk is.', [
      O('city', 'City office', 'Locals, businesses and people moving house.', {}),
      O('air', 'Airport desk', 'Travellers all year: more customers, higher rent.', { t: 1.15, d: 1.2, w: 4000 }),
      O('resort', 'Tourist resort', 'Busy holiday seasons, quiet winters.', { t: 1.1, d: 1.1 })
    ], 0),
    K('fleet', 'Fleet', 'What you rent out.', [
      O('budget', 'Older budget cars', 'Cheapest in town; more breakdowns.', { t: 0.75, d: 1.3, q: -4, r: 1.2 }),
      O('std', 'Recent standard cars', 'Clean, recent cars at normal prices.', {}),
      O('prem', 'Premium and electric', 'Business travellers pay more.', { t: 1.35, d: 0.8, q: 4 })
    ], 1)
  ],
  crs: [['c1', 'Damage inspection and customer service', 3500, 1, 3]]
});
/* wine grapes need a warm, dry enough summer */
BANNED.vineyard = BANNED.vineyard || {};
[['NO', 'Norway'], ['SE', 'Sweden'], ['FI', 'Finland'], ['DK', 'Denmark'], ['IE', 'Ireland'], ['LT', 'Lithuania']].forEach(x => { BANNED.vineyard[x[0]] = 'The summers in ' + x[1] + ' are too short and cool for wine grapes to ripen.'; });
BANNED.vineyard.SG = 'Singapore is too hot and wet all year for wine grapes, and there is no farmland.';
BANNED.vineyard.AE = 'The desert is too hot and dry for vineyards.';
BANNED.vineyard.KR = 'The monsoon summers are too wet for wine grapes; Korea makes fruit wines instead.';

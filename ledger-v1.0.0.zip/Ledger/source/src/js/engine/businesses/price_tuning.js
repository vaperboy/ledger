/* ---- src/businesses/price_tuning.js ---- */
/* per-business price calibration: scales realised prices so a well-run business lands near its design margin */
const RM_TUNE = {
  'carrental': 1.25, /* round 57 */
  'salmon': 0.79,
  'factory': 0.94,
  'courier': 1.03,
  'farm': 1.22,
  'shipping': 1.1,
  'cleaning': 0.81,
  'webdev': 0.77,
  'mktg': 0.91,
  'law': 0.78,
  'acctfirm': 0.93,
  'staffing': 1.04,
  'barber': 0.74,
  'drivsk': 1.1,
  'physio': 0.94,
  'estate': 0.94,
  'pets': 1.04,
  'foodtruck': 0.91,
  'cafe': 0.957,
  'restaurant': 0.933,
  'nightclub': 0.95,
  'gym': 1.11,
  'hotel': 1.17,
  'fun': 0.94,
  'kiosk': 0.853,
  'boutique': 0.8,
  'webshop': 1.23,
  'grocery': 0.89,
  'hardware': 0.832,
  'cardealer': 1.365,
  'electrician': 0.88,
  'plumber': 0.94,
  'event': 0.86,
  'engcons': 1.093,
  'bakery': 1.07,
  'brewery': 1.06,
  'furniture': 0.77,
  'taxi': 1.05,
  'trucking': 0.91
};
Object.keys(RM_TUNE).forEach(k => {
  if (BD[k]) BD[k].rm = RM_TUNE[k];
});


/* ---- src/businesses/transport_property_finance_energy.js ---- */
/* ===== Transport, property, finance, energy ===== */
B('taxi', 'Taxi service', 'logi', 'Transport and logistics', {
  blurb: 'Rides on demand. Licences are limited and costly; apps and fuel swing your margin.',
  unit: 'ride',
  ticket: 295,
  cogs: 0.1,
  m: 0.09,
  ela: 1.4,
  vat: 'low',
  seas: 'newyear',
  b2b: 0.15,
  terms: 3,
  own: 0.5,
  std: [['driver', 5]],
  mgr: 'fleet',
  fixed: 2400,
  open: 30000,
  aud: 0.5,
  skill: 'Driving',
  minSize: 0.4,
  maxSize: 3,
  prem: ['none', 0],
  docs: ['org', 'mva', 'acctr', 'taxi', 'ysk', 'hms'],
  dq: { taxi: 'veh' },
  tw: { fuel: 0.1, km: 1900 },
  ev: ['l_app'],
  eq: [
    E('car', 'Taxi cars (electric estate)', 540000, 5, 4, 'rcv', ['taxi_ev', 'car_ev', 'car_s']),
    E('mdt', 'Dispatch app and meters', 28000, 3, 1, 'rq'),
    E('wrap', 'Branding and roof signs', 9000, 3, 4, 'q')
  ],
  knobs: [
    K('app', 'Booking channel', '', [
      O('stand', 'Street ranks and phone', 'Local but fading.', { d: 0.85 }),
      O('mix', 'Own app and ride platforms', 'Rides from your own app and from the platforms.', {}),
      O('plat', 'Ride platform only', 'Volume, platform takes 20%.', { d: 1.2, c: 0.07 })
    ], 1),
    K('shift', 'Hours', '', [
      O('day', 'Daytime', 'Office hours only: calmer, less to earn.', { d: 0.8, r: 0.8 }),
      O('std', 'Day and evening', 'Normal shifts from morning to late evening.', {}),
      O('night', 'Nights and weekends', 'Higher ticket, higher risk.', { t: 1.18, d: 1.1, r: 1.3 })
    ], 1)
  ],
  crs: [['c1', 'Customer service for drivers', 3500, 1, 3]]
});
B('courier', 'Courier and last-mile delivery', 'logi', 'Transport and logistics', {
  blurb: 'Deliver parcels and meals. High volume, price pressure, and strict rules on who counts as an employee.',
  unit: 'parcel',
  ticket: 62,
  cogs: 0.14,
  m: 0.07,
  ela: 1.8,
  seas: 'xmas',
  b2b: 0.9,
  terms: 4,
  own: 0.5,
  std: [['courier', 8], ['helper', 2]],
  mgr: 'fleet',
  fixed: 3200,
  open: 40000,
  aud: 0.6,
  skill: 'Logistics',
  minSize: 0.4,
  maxSize: 3,
  prem: ['warehouse', 400],
  docs: ['org', 'mva', 'acctr', 'hms', 'gdpr'],
  tw: { fuel: 0.08, km: 900 },
  ev: ['l_gigRule'],
  eq: [
    E('van', 'Delivery vans', 330000, 6, 6, 'rcv', ['van_s', 'ev_van', 'van_l']),
    E('bike', 'E-bikes and scooters', 45000, 3, 4, 'cv', ['bike', 'scooter']),
    E('sort', 'Sorting line and scanners', 280000, 8, 1, 'rc'),
    E('sw', 'Routing and tracking software', 55000, 2, 1, 'rq')
  ],
  knobs: [
    K('seg', 'Customers', '', [
      O('ecom', 'Webshop parcels', 'Volume, tough price.', { t: 0.85, d: 1.3 }),
      O('b2b', 'Business-to-business', 'Regular deliveries for companies, invoiced monthly.', {}),
      O('food', 'Meal and grocery delivery', 'Peaks at dinner, apps take cuts.', { t: 1.2, d: 1.0, c: 0.04 })
    ], 1),
    K('crew', 'Workforce', '', [
      O('emp', 'Employees', 'Costly, stable.', {}),
      O('gig', 'Self-employed couriers', 'Cheaper, legal risk.', { c: -0.05, r: 1.6, q: -3 })
    ], 0)
  ],
  crs: [['c1', 'Route optimisation', 8500, 1, 3]]
});
B('trucking', 'Freight trucking', 'logi', 'Transport and logistics', {
  blurb: 'Haul goods for industry and retail. Fuel, tolls, driver shortages and spot-market rates.',
  unit: 'trip',
  ticket: 11500,
  cogs: 0.18,
  m: 0.06,
  ela: 1.8,
  seas: 'build',
  b2b: 0.98,
  terms: 6,
  own: 0.4,
  std: [['truckd', 8], ['dispatch', 1]],
  mgr: 'fleet',
  fixed: 6000,
  open: 80000,
  aud: 0.5,
  skill: 'Logistics',
  minSize: 0.4,
  maxSize: 3,
  needAS: true,
  prem: ['warehouse', 600],
  docs: ['org', 'mva', 'acctr', 'goods', 'ysk', 'hms'],
  tw: { fuel: 0.22, km: 3200 },
  ev: ['l_toll'],
  eq: [
    E('truck', 'Tractor units', 2150000, 7, 8, 'rcv', ['truck_h', 'truck_ev', 'truck_s']),
    E('trail', 'Trailers', 520000, 10, 8, 'rc'),
    E('tms', 'Fleet and tachograph system', 90000, 3, 1, 'rq'),
    E('wash', 'Yard, workshop and fuel tank', 600000, 15, 1, 'r')
  ],
  knobs: [
    K('mk', 'Market', '', [
      O('spot', 'Spot market', 'Volatile rates, flexible.', { t: 1.05, d: 1.05, r: 1.2 }),
      O('mix', 'Mix', 'Some contracts, some spot loads.', {}),
      O('contr', 'Long contracts with retailers', 'Stable, lower rate.', { t: 0.92, d: 1.15, r: 0.8 })
    ], 1),
    K('fuel', 'Fuel strategy', '', [
      O('dsl', 'Diesel', 'Diesel trucks: proven, no range limits.', {}),
      O('ev', 'Electric/biogas where possible', 'Lower running cost, range limits.', { c: -0.02, d: 0.95, q: 2 })
    ], 0)
  ],
  crs: [['c1', 'Eco-driving', 5500, 1, 3]]
});
B('shipping', 'Shipping company', 'logi', 'Transport and logistics', {
  blurb: 'Small coasters and ferries along the coast. Charter rates move with global trade; ships cost tens of millions.',
  unit: 'voyage',
  ticket: 780000,
  cogs: 0.18,
  m: 0.12,
  ela: 1.0,
  vat: 'zero',
  seas: 'flat',
  b2b: 0.98,
  terms: 4,
  own: 0,
  std: [['shipm', 2], ['deckh', 4], ['seaman', 8], ['eng', 2]],
  mgr: 'fleet',
  fixed: 30000,
  open: 3000000,
  aud: 0.3,
  skill: 'Maritime',
  minSize: 1,
  maxSize: 3,
  needAS: true,
  prem: ['office', 80],
  docs: ['org', 'mva', 'acctr', 'skip', 'hms', 'aml'],
  tw: { fuel: 0.2, km: 700, rateIdx: 1 },
  ev: ['l_freight', 'l_port'],
  eq: [
    E('ship', 'Coastal cargo vessels', 42000000, 18, 2, 'rcv', ['ship_s', 'ship_l', 'ferry']),
    E('nav', 'Navigation and safety systems', 4500000, 8, 1, 'rq'),
    E('dock', 'Port and crane agreements', 1800000, 10, 1, 'r')
  ],
  knobs: [
    K('chart', 'Contract model', '', [
      O('spot', 'Spot charters', 'Volatile rates.', { t: 1.05, r: 1.3 }),
      O('time', 'Time charter', 'Fixed daily income.', { t: 0.9, r: 0.7 }),
      O('pass', 'Passenger ferry service', 'Seasonal tourism demand.', { t: 0.95, d: 1.1 })
    ], 1),
    K('fuel', 'Fuel and speed', 'How the ships run.', [
      O('std', 'Normal speed', 'Standard fuel at standard speed.', {}),
      O('slow', 'Slow steaming', 'Less fuel, fewer trips.', { c: -0.03, k: 0.92 }),
      O('lng', 'LNG-ready ships', 'Cleaner fuel that some shippers pay for.', { c: -0.02, d: 1.04, w: 3000 })
    ], 0)
  ],
  crs: [['c1', 'ISM safety management', 38000, 4, 5]]
});
B('airline', 'Regional airline', 'logi', 'Transport and logistics', {
  blurb: 'Short-haul flights between smaller airports. Extreme fixed costs, thin margins and a regulator that never sleeps.',
  unit: 'flight',
  ticket: 192000,
  cogs: 0.3,
  m: 0.05,
  ela: 1.3,
  vat: 'low',
  seas: 'summer',
  b2b: 0.2,
  terms: 3,
  own: 0,
  std: [['pilot', 4], ['fo', 4], ['cabin', 6], ['mech', 6], ['dispatch', 3], ['recept', 6]],
  mgr: 'fleet',
  fixed: 180000,
  open: 20000000,
  aud: 0.6,
  skill: 'Aviation',
  minSize: 1,
  maxSize: 3,
  needAS: true,
  prem: ['hotel', 1200],
  docs: ['org', 'mva', 'acctr', 'aoc', 'aml', 'hms', 'vik'],
  tw: { fuel: 0.28, km: 700, rateIdx: 0 },
  ev: ['l_ground', 'l_atc'],
  eq: [
    E('plane', 'Turboprop aircraft (lease or buy)', 180000000, 20, 2, 'rcv', ['plane_s']),
    E('hangar', 'Hangar and tools', 28000000, 25, 1, 'r'),
    E('ops', 'Flight operations system', 4800000, 4, 1, 'rq'),
    E('sim', 'Crew simulator access', 1800000, 5, 1, 'q')
  ],
  knobs: [
    K('net', 'Network', '', [
      O('reg', 'Regional routes with public service contracts', 'Subsidised, steady.', { t: 0.9, d: 1.1, r: 0.8 }),
      O('mix', 'Mixed', 'A mix of subsidised and commercial routes.', {}),
      O('comm', 'Commercial popular routes', 'Higher yields, higher competition.', { t: 1.1, d: 0.9, r: 1.3 })
    ], 1),
    KM('also', 'Also offer', 'Several can run together.', [
      O('cargo', 'Cargo in the hold', 'Freight on every passenger flight.', { t: 1.06 }),
      O('prem', 'Lounge and premium seats', 'Business travellers pay more.', { t: 1.08, d: 0.98, w: 2000 }),
      O('loyal', 'Loyalty programme', 'Points keep travellers coming back.', { d: 1.05, w: 1500 })
    ], 0)
  ],
  crs: [['c1', 'CRM and safety culture', 45000, 3, 5]]
});
/* round 56: warehousing and order fulfilment for other companies (a 3PL). UK benchmarks: storage about £10-14 a pallet a
   month, pick and pack £1.50-4.20 an order (Expert Market); thin margins, a Christmas peak, contracts with webshops
   and retail chains. A unit here is an order handled, storage included. */
B('wh3pl', 'Warehouse and fulfilment', 'logi', 'Transport and logistics', {
  blurb: 'Store, pick, pack and ship for webshops and shops. Volume, accuracy and the Christmas rush decide the year.',
  unit: 'order',
  ticket: 55,
  cogs: 0.1,
  m: 0.05,
  ela: 1.4,
  seas: 'xmas',
  b2b: 1,
  terms: 4,
  own: 0.4,
  std: [['whw', 8], ['operator', 2], ['dispatch', 1]],
  mgr: 'fleet',
  fixed: 6500,
  open: 80000,
  aud: 0.5,
  skill: 'Logistics',
  minSize: 0.6,
  maxSize: 4,
  prem: ['warehouse', 3200],
  docs: ['org', 'mva', 'acctr', 'hms', 'vik', 'gdpr'],
  eq: [
    E('rack', 'Pallet racking', 450000, 20, 1, 'rc'),
    E('fork', 'Forklifts and reach trucks', 320000, 8, 2, 'rc'),
    E('pack', 'Packing stations and conveyor', 380000, 10, 1, 'c'),
    E('wms', 'Warehouse management software', 90000, 3, 1, 'rq'),
    E('scan', 'Handheld scanners and printers', 40000, 4, 1, 'q'),
    E('robot', 'Automated picking system', 6500000, 12, 0, 'cq')
  ],
  knobs: [
    K('cust', 'Customers', 'Who you work for.', [
      O('ecom', 'Webshops', 'Many small orders and a big Christmas peak.', { d: 1.25, t: 0.9 }),
      O('mix', 'Webshops and shops', 'Parcels for webshops, pallets for shops.', {}),
      O('retail', 'Retail chains', 'Steady pallets, lower price per order, long contracts.', { d: 0.85, t: 0.8, r: 0.8, k: 1.25 })
    ], 1),
    K('svc', 'Service', 'How much you do for them.', [
      O('store', 'Storage and shipping', 'The basics.', { t: 0.85 }),
      O('full', 'Full fulfilment', 'Pick, pack, ship and track every order.', {}),
      O('returns', 'Fulfilment with returns and kitting', 'Returns, gift wrap and bundles: more per order, more work.', { t: 1.25, k: 0.85, c: 0.02 })
    ], 1)
  ],
  crs: [['c1', 'Forklift certificate', 6000, 1, 3], ['c2', 'Lean warehouse operations', 9000, 1, 4]],
  ev: []
});
B('resrent', 'Residential rentals', 'rent', 'Property', {
  blurb: 'Own flats and let them out. Steady rent, mortgage interest, repairs and the occasional bad tenant. Property values follow the market.',
  unit: 'unit-week',
  ticket: 3350,
  cogs: 0.0,
  m: 0.3,
  ela: 1.0,
  vat: 'zero',
  seas: 'study',
  b2b: 0,
  terms: 0,
  own: 1,
  std: [['caretaker', 1], ['propm', 1]],
  mgr: 'prop',
  fixed: 1400,
  open: 20000,
  aud: 0.3,
  skill: 'Property',
  minSize: 0.4,
  maxSize: 4,
  prem: null,
  docs: ['org', 'mva_na', 'hms', 'gdpr'],
  tw: { kind: 'res', units: 8, price: 3100000, perM2: 70000, yield: 0.045, maint: 0.008, ptax: 0.0025 },
  ev: ['rn_pet'],
  eq: [],
  knobs: [
    K('seg', 'Tenants', '', [
      O('stud', 'Students and young people', 'Seasonal churn.', { d: 1.05, t: 0.95 }),
      O('fam', 'Families', 'Long leases.', { d: 0.95, t: 1.05, r: 0.8 }),
      O('short', 'Short-term lets', 'Premium rates, high effort.', { d: 0.8, t: 1.5, r: 1.3, w: 2500 })
    ], 1),
    K('rent', 'Rent policy', '', [
      O('mkt', 'Market rent', 'What similar places rent for.', {}),
      O('low', 'Below market, long contracts', 'Low vacancy.', { t: 0.92, d: 1.1 }),
      O('high', 'Push to the cap', 'Max income, more vacancy.', { t: 1.1, d: 0.85, r: 1.1 })
    ], 0)
  ],
  crs: [['c1', 'Tenancy law course', 6500, 1, 3]]
});
B('comrent', 'Commercial property', 'rent', 'Property', {
  blurb: 'Offices, shops and light industry for rent. Longer leases and bigger tickets, but tenants can walk and vacancy hurts.',
  unit: 'm2-week',
  ticket: 52,
  cogs: 0.0,
  m: 0.34,
  ela: 0.8,
  vat: 'zero',
  seas: 'flat',
  b2b: 0.95,
  terms: 4,
  own: 0.5,
  std: [['caretaker', 1], ['propm', 1]],
  mgr: 'prop',
  fixed: 4500,
  open: 60000,
  aud: 0.3,
  skill: 'Property',
  minSize: 0.4,
  maxSize: 4,
  needAS: true,
  prem: null,
  docs: ['org', 'acctr', 'hms', 'vik', 'gdpr'],
  tw: { kind: 'com', units: 2400, price: 54000, perM2: 54000, yield: 0.065, maint: 0.006, ptax: 0.003 },
  ev: ['rn_anchor'],
  eq: [],
  knobs: [
    K('seg', 'Tenants', '', [
      O('off', 'Office space', 'Hybrid-work risk.', {}),
      O('shop', 'Retail units', 'Footfall risk.', { t: 1.2, d: 0.85 }),
      O('log', 'Logistics and light industry', 'Steady demand.', { t: 0.75, d: 1.25, r: 0.8 })
    ], 0),
    KM('also', 'Also offer', 'Several can run together.', [
      O('fitout', 'Fit-out for tenants', 'Ready-to-use offices rent for more.', { t: 1.08, w: 800 }),
      O('cowork', 'Short leases and co-working', 'Higher rents, tenants come and go.', { t: 1.06, r: 1.1 }),
      O('green', 'Green certification', 'Big tenants ask for it.', { t: 1.04, w: 600 })
    ], 0)
  ],
  crs: [['c1', 'Lease negotiation course', 9500, 1, 3]]
});
B('parking', 'Parking and self-storage', 'rent', 'Property', {
  blurb: 'Car parks, EV charging and storage units. Low staff, low drama, and a surprisingly steady yield.',
  unit: 'space-week',
  ticket: 420,
  cogs: 0.02,
  m: 0.4,
  ela: 1.1,
  vat: 'std',
  seas: 'flat',
  b2b: 0.2,
  terms: 3,
  own: 0.5,
  std: [['caretaker', 1]],
  mgr: 'prop',
  fixed: 2500,
  open: 40000,
  aud: 0.3,
  skill: 'Property',
  minSize: 0.4,
  maxSize: 4,
  prem: null,
  docs: ['org', 'mva', 'hms', 'gdpr'],
  tw: { kind: 'park', units: 160, price: 330000, perM2: 330000, yield: 0.07, maint: 0.012, ptax: 0.002 },
  ev: ['rn_vandal'],
  eq: [E('gate', 'Gates, cameras and payment system', 380000, 7, 1, 'rq'), E('ev', 'EV chargers', 85000, 8, 4, 'q')],
  knobs: [
    K('type', 'Offer', '', [
      O('park', 'Parking only', 'Car parking spaces only.', {}),
      O('store', 'Self-storage units', 'Higher yield, slower fill.', { t: 1.3, d: 0.85 }),
      O('ev', 'EV charging hub', 'Capital heavy, high margin per kWh.', { t: 1.5, d: 0.7, w: 3000 })
    ], 0),
    KM('also', 'Also offer', 'Several can run together.', [
      O('ev', 'Car charging', 'Charge while they park.', { t: 1.1, w: 900 }),
      O('permit', 'Monthly permits', 'Commuters on a fixed monthly price.', { t: 0.95, d: 1.06 }),
      O('wash', 'Car wash', 'A wash while they shop.', { t: 1.05 })
    ], 0)
  ],
  crs: []
});
B('insco', 'Insurance company', 'fin', 'Finance', {
  blurb: 'Collect premiums, pay claims, hold reserves. A bad storm year can wipe you out. Your own companies can be insured by you.',
  unit: 'policy',
  ticket: 5200,
  cogs: 0.0,
  m: 0.1,
  ela: 1.2,
  vat: 'zero',
  seas: 'flat',
  b2b: 0.2,
  own: 0,
  std: [['underw', 3], ['claims', 5], ['agent', 5], ['compl', 1], ['hm', 1]],
  mgr: 'fin',
  fixed: 60000,
  open: 5000000,
  aud: 0.6,
  skill: 'Insurance',
  minSize: 1,
  maxSize: 3,
  needAS: true,
  group: 'ins',
  prem: ['office', 600],
  docs: ['org', 'acctr', 'forsik', 'aml', 'gdpr', 'hms'],
  tw: { ins: 1, lossR: 0.66, expR: 0.22, solv: 1.2, capital: 40000000, policies: 30000, premium: 5200 },
  ev: ['f_storm', 'f_fraud'],
  eq: [
    E('core', 'Core policy and claims system', 4500000, 5, 1, 'rq'),
    E('cyber', 'Security and data platform', 1800000, 4, 1, 'rq'),
    E('lap', 'Workstations', 22000, 3, 20, 'rc')
  ],
  knobs: [
    K('price', 'Underwriting stance', '', [
      O('tight', 'Tight (price for profit)', 'Lower volume, better loss ratio.', { d: 0.8, r: 0.8, t: 1.1 }),
      O('std', 'Market', 'Prices in line with the market.', {}),
      O('grow', 'Grow (price to win)', 'Volume with loose terms.', { d: 1.3, r: 1.3, t: 0.9 })
    ], 1),
    KM('also', 'Also offer', 'Several can run together.', [
      O('travel', 'Travel insurance', 'Sold with every holiday.', { d: 1.06, r: 1.02 }),
      O('bank', 'Sold through banks', 'A bank sells your policies for a share.', { d: 1.12, t: 0.95 }),
      O('pet', 'Pet insurance', 'A growing market with many small claims.', { d: 1.04, r: 1.04 })
    ], 0)
  ],
  crs: [['c1', 'Actuarial and risk-pricing', 40000, 6, 6]]
});
B('bank', 'Bank', 'fin', 'Finance', {
  blurb: 'Take deposits and lend. Net interest margin versus loan losses, with capital rules and the risk of a run. Your own companies can borrow from you.',
  unit: 'customer',
  ticket: 12000,
  cogs: 0.0,
  m: 0.12,
  ela: 1.0,
  vat: 'zero',
  seas: 'flat',
  b2b: 0.2,
  own: 0,
  std: [['banker', 6], ['credit', 3], ['teller', 4], ['compl', 2], ['hm', 1]],
  mgr: 'fin',
  fixed: 120000,
  open: 20000000,
  aud: 0.6,
  skill: 'Banking',
  minSize: 1,
  maxSize: 3,
  needAS: true,
  group: 'bank',
  prem: ['office', 800],
  docs: ['org', 'acctr', 'bank', 'aml', 'gdpr', 'hms'],
  tw: { bank: 1, capitalReq: 0.16, nim: 0.031, depRate: 0.85, capital: 400000000 },
  ev: ['f_run', 'f_default', 'f_fraud'],
  eq: [
    E('core', 'Core banking platform', 9000000, 5, 1, 'rq'),
    E('sec', 'Security, ATM and fraud system', 3500000, 4, 1, 'rq'),
    E('lap', 'Workstations', 22000, 3, 20, 'rc'),
    E('vault', 'Branch fit-out', 2400000, 12, 1, 'q')
  ],
  knobs: [
    K('seg', 'Loan book', '', [
      O('mort', 'Mortgages (low risk)', 'Thin margin, steady.', { t: 0.8, r: 0.5 }),
      O('mix', 'Mortgages and business loans', 'Home loans and loans to businesses.', {}),
      O('sme', 'SME and consumer credit', 'Higher margin, higher losses.', { t: 1.5, r: 1.8 })
    ], 1),
    K('liq', 'Funding', '', [
      O('dep', 'Deposits only', 'Stable, costly to grow.', { r: 0.8 }),
      O('wh', 'Wholesale funding', 'Fast growth, rollover risk.', { d: 1.3, r: 1.4 })
    ], 0)
  ],
  crs: [['c1', 'Credit-risk course', 38000, 4, 6]]
});
B('fund', 'Investment fund', 'fin', 'Finance', {
  blurb: 'Raise outside money, invest it in markets or private deals and earn management and performance fees. Your skill is the product.',
  unit: 'client',
  ticket: 120000,
  cogs: 0.0,
  m: 0.25,
  ela: 0.8,
  vat: 'zero',
  seas: 'flat',
  b2b: 0.9,
  own: 0.5,
  std: [['analyst', 1], ['compl', 1]],
  mgr: 'fund',
  fixed: 9000,
  open: 800000,
  aud: 0.6,
  skill: 'Finance',
  minSize: 1,
  maxSize: 3,
  needAS: true,
  prem: ['office', 140],
  docs: ['org', 'mva_na', 'acctr', 'aif', 'aml', 'gdpr'],
  tw: { fund: 1, mgmt: 0.015, perf: 0.2, aum0: 0 },
  ev: ['f_fund'],
  eq: [
    E('term', 'Bloomberg-style terminals and data', 480000, 1, 1, 'rq'),
    E('lap', 'Workstations', 28000, 3, 5, 'rc'),
    E('risk', 'Risk and compliance system', 280000, 3, 1, 'r')
  ],
  knobs: [
    K('strat', 'Strategy', '', [
      O('index', 'Index and low risk', 'Little alpha, stable inflows.', { r: 0.6 }),
      O('act', 'Active equities', 'Picking shares to beat the market.', {}),
      O('pe', 'Private equity and venture', 'Illiquid, lumpy results.', { r: 1.5, t: 1.3 })
    ], 1),
    K('fees', 'Fees', 'What investors pay you each year.', [
      O('std', 'Standard fee', 'The usual management fee.', {}),
      O('low', 'Low-cost share class', 'A lower fee draws far more money in.', { t: 0.6, d: 1.35 }),
      O('prem', 'Premium share class', 'A higher fee for fewer, richer investors.', { t: 1.25, d: 0.85 })
    ], 0)
  ],
  crs: [['c1', 'CFA-style programme', 45000, 8, 6]]
});
B('power', 'Renewable power producer', 'energy', 'Energy', {
  blurb: 'Wind, hydro or solar plants selling power at the spot price. Output depends on weather, income on prices, and building takes years of licensing.',
  unit: 'MWh',
  ticket: 780,
  cogs: 0.0,
  m: 0.5,
  ela: 0,
  vat: 'std',
  seas: 'winter',
  b2b: 1.0,
  terms: 3,
  own: 0,
  std: [['windtech', 4], ['eng', 1]],
  mgr: 'energy',
  fixed: 30000,
  open: 3000000,
  aud: 0.0,
  skill: 'Energy',
  minSize: 1,
  maxSize: 4,
  needAS: true,
  prem: ['yard', 600],
  docs: ['org', 'mva', 'acctr', 'nve', 'grid', 'hms', 'fabrik'],
  tw: { power: 1, mw: 30, capex: 14000000, cf: 0.36, opex: 0.025 },
  ev: ['e_dry', 'e_curtail'],
  eq: [
    E('turb', 'Wind turbines (per MW)', 14000000, 25, 30, 'rcq'),
    E('grid', 'Substation and grid link', 28000000, 30, 1, 'r'),
    E('scada', 'Monitoring and control (SCADA)', 3500000, 8, 1, 'rq'),
    E('road', 'Roads and site works', 12000000, 30, 1, 'r')
  ],
  knobs: [
    K('src', 'Source', '', [
      O('wind', 'Onshore wind', 'Windy winters, local opposition risk.', {}),
      O('hydro', 'Small hydro', 'Dry-year risk.', { k: 1.15, t: 1.0 }),
      O('solar', 'Solar park', 'Summer-heavy, short winter.', { k: 0.5, t: 1.0 })
    ], 0),
    K('hedge', 'Price strategy', '', [
      O('spot', 'Sell at spot', 'Full price exposure.', {}),
      O('half', 'Hedge half with fixed contracts', 'Half the output sold ahead at a fixed price.', { r: 0.7, t: 0.97 }),
      O('fix', 'Long fixed-price contract', 'Predictable, may miss high prices.', { r: 0.4, t: 0.92 })
    ], 0)
  ],
  crs: [['c1', 'High-voltage safety', 25000, 2, 4]]
});
B('oilgas', 'Oil and gas company', 'energy', 'Energy', {
  blurb: 'Explore, develop and produce. Dry wells, price swings and heavy petroleum taxes. A single discovery can change your life.',
  unit: 'barrel',
  ticket: 920,
  cogs: 0.0,
  m: 0.4,
  ela: 0,
  vat: 'zero',
  seas: 'flat',
  b2b: 1.0,
  terms: 3,
  own: 0,
  std: [['offshore', 10], ['geo', 2], ['eng', 3], ['safety', 1]],
  mgr: 'energy',
  fixed: 250000,
  open: 60000000,
  aud: 0.0,
  skill: 'Petroleum',
  minSize: 1,
  maxSize: 4,
  needAS: true,
  prem: ['office', 400],
  docs: ['org', 'mva', 'acctr', 'oil', 'oilsafe', 'aml', 'hms'],
  tw: { oil: 1, explore: 1 },
  ev: ['e_dryHole', 'e_spill', 'e_geo'],
  eq: [
    E('seis', 'Seismic data and software', 18000000, 5, 1, 'rq'),
    E('rig', 'Rig and drilling services contract', 120000000, 10, 1, 'r'),
    E('plat', 'Production platform share', 800000000, 25, 1, 'rc')
  ],
  knobs: [
    K('risk', 'Strategy', '', [
      O('safe', 'Buy producing stakes', 'Lower upside, steady.', { r: 0.6 }),
      O('mix', 'Balanced portfolio', 'Some producing fields, some exploration.', {}),
      O('wild', 'Frontier exploration', 'Rare giant discovery, mostly dry holes.', { r: 1.8 })
    ], 1),
    K('sell', 'How you sell', 'Your oil at the day\'s price, or on contract.', [
      O('spot', 'At the market price', 'Every swing in the oil price hits you in full.', {}),
      O('term', 'Term contracts', 'Most of the oil at a fixed price a little under the long-run average: steadier, less upside.', {})
    ], 0)
  ],
  crs: [['c1', 'Petroleum safety culture', 60000, 4, 5]]
});


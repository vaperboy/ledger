/* ---- src/businesses/_helpers.js ---- */
/* ===== business-definition helpers ===== */
const BD = {};
const BD_ORDER = [];
const EQ_BRANDS = [
  [/dental|medical|x-ray|treatment|massage|clinic|laser|ultrasound|patient/i, ['Medora', 'Clarion', 'Vitalis', 'Sanomed']],
  [/laptop|computer|\bpc\b|phone|tablet|software|server|printer|camera|monitor|screen|scanner|router|wifi|\bpos\b|till|terminal|headset|drone|projector|speaker|sound|webcam/i, ['Corvane', 'Lumetra', 'Arkline', 'Novix', 'Stratel', 'Brightwave', 'Helix']],
  [/\bvan\b|truck|\bcar\b|\bbus\b|boat|trailer|forklift|lorry|vessel|ship|\btractor|excavator|crane|aircraft|plane|\bjet\b|helicopter|bike|scooter|ambulance|taxi/i, ['Valmont', 'Nordtrans', 'Kestrel', 'Ostrava', 'Hadeland Motor', 'Brenna']],
  [/oven|fridge|kitchen|coffee|espresso|grill|freezer|dishwasher|fryer|cooler|beer|ice machine|mixer|cold room|stove/i, ['Brenner', 'Kalvø', 'Gastrona', 'Rossi & Lund', 'Fornell']],
  [/machine|drill|press|\bsaw|pump|compressor|polisher|washer|lathe|cnc|generator|turbine|welder|robot|loom|kiln|boiler|furnace|hoist|scaffold|vacuum/i, ['Hallberg', 'Ferrox', 'Stalheim', 'Durano', 'Torvik', 'Maxell & Strøm']],
  [/chair|table|furniture|shelving|shelves|counter|\bbed|desk|sofa|rack|display|mirror/i, ['Formhaus', 'Linde', 'Oakridge', 'Sandmo']]
];
function brandEq(id, n) {
  const g = EQ_BRANDS.find(x => x[0].test(n));
  if (!g) return n;
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) | 0;
  const b = g[1][Math.abs(h) % g[1].length];
  return b + ' ' + (/^[A-Z]{2}/.test(n) ? n : n.charAt(0).toLowerCase() + n.slice(1));
}
const E = (id, n, cost, life, std, fl, vo) => ({ id, n: brandEq(id, n), cost, life, std, fl: fl || '', vo: vo || null });
const O = (id, n, d, fx, cc) => ({ id, n, d, fx: fx || {}, cc: cc || null });
/* an option only some countries have (round 57: what a farm can grow in the climate): o.cc lists the country codes */
function knobOk(co, o) {
  return !o || !o.cc || o.cc.indexOf((co && co.country) || (typeof S !== 'undefined' && S && S.country) || 'NO') >= 0;
}
/* the first option of a choice the company's country allows, the default when it can */
function knobDef(co, k) {
  if (k.multi) return k.def || 0;
  if (knobOk(co, k.opts[k.def || 0])) return k.def || 0;
  const i = k.opts.findIndex(o => knobOk(co, o));
  return i < 0 ? 0 : i;
}
const K = (id, n, d, opts, def) => ({ id, n, d, opts, def: def || 0 });
/* a group of add-ons that can run together (round 56): the value is a bitmask, one bit per option; none on is 0 */
const KM = (id, n, d, opts, def) => ({ id, n, d, opts, def: def || 0, multi: 1 });
const FAM_EV = {
  club: [],
  svc: [
    'g_late',
    'g_quit',
    'g_sick',
    'g_review',
    'g_it',
    'g_audit',
    'g_offer',
    'g_award',
    'g_rival',
    'g_press',
    'g_grant',
    'g_lawsuit'
  ],
  venue: [
    'g_break',
    'g_quit',
    'g_sick',
    'g_review',
    'g_theft',
    'g_supply',
    'g_it',
    'g_audit',
    'g_inspect',
    'g_fire',
    'g_rival',
    'g_union',
    'g_award',
    'g_press',
    'g_lawsuit'
  ],
  retail: [
    'g_break',
    'g_quit',
    'g_review',
    'g_theft',
    'g_supply',
    'g_it',
    'g_audit',
    'g_inspect',
    'g_fire',
    'g_rival',
    'g_union',
    'g_press',
    'r_stockout',
    'r_shoplift',
    'r_return',
    'r_priceWar',
    'r_chain'
  ],
  project: [
    'g_break',
    'g_quit',
    'g_sick',
    'g_late',
    'g_it',
    'g_audit',
    'g_inspect',
    'g_rival',
    'g_offer',
    'g_lawsuit',
    'g_supply',
    'p_overrun',
    'p_defect',
    'p_noshow',
    'p_nopay',
    'p_accident',
    'p_permit',
    'p_matprice'
  ],
  prod: [
    'g_break',
    'g_quit',
    'g_sick',
    'g_late',
    'g_supply',
    'g_it',
    'g_audit',
    'g_inspect',
    'g_fire',
    'g_rival',
    'g_union',
    'g_offer',
    'pr_machine',
    'pr_raw',
    'pr_recall',
    'pr_bigcontract'
  ],
  logi: [
    'g_break',
    'g_quit',
    'g_sick',
    'g_late',
    'g_it',
    'g_audit',
    'g_inspect',
    'g_rival',
    'g_union',
    'g_offer',
    'l_accident',
    'l_fuel',
    'l_hours',
    'l_break',
    'l_gig'
  ],
  rent: [
    'g_break',
    'g_audit',
    'g_fire',
    'g_inspect',
    'g_lawsuit',
    'g_offer',
    'rn_nopay',
    'rn_leak',
    'rn_reg',
    'rn_vacant',
    'd_market'
  ],
  fin: ['g_it', 'g_audit', 'g_quit', 'g_press', 'g_lawsuit', 'f_fsa'],
  energy: ['g_break', 'g_quit', 'g_audit', 'g_inspect', 'g_fire', 'g_union', 'g_press', 'e_price', 'e_outage', 'e_tax']
};
/* B(): register a business with defaults. o.eq are E() items. */
function B(id, n, fam, cat, o) {
  const d = {
    id,
    n,
    fam,
    cat,
    vat: 'std',
    unit: 'job',
    ticket: 1000,
    cogs: 0.05,
    m: 0.1,
    D: 0,
    ela: 1.1,
    seas: 'flat',
    b2b: 0.2,
    terms: 4,
    prem: null,
    std: [],
    own: 1,
    eq: [],
    docs: ['org'],
    mgr: 'gen',
    fixed: 800,
    knobs: [],
    ev: [],
    crs: [],
    tw: {},
    open: 3000,
    blurb: '',
    needAS: false,
    dq: {},
    roleCap: {},
    minSize: 0.4,
    maxSize: 3,
    aud: 0.5,
    up: 1.0,
    skill: 'Craft'
  };
  Object.assign(d, o);
  /* readable errors for add-on authors */
  if (!FAM_EV[fam]) throw new Error('Business ' + id + ': unknown family "' + fam + '" (known: ' + Object.keys(FAM_EV).join(', ') + ')');
  d.std.forEach(s => { if (!ROLES[s[0]]) throw new Error('Business ' + id + ': unknown role "' + s[0] + '" - add it to ROLES in an add-on data file'); });
  d.docs.forEach(x => { if (!DOCS[x]) throw new Error('Business ' + id + ': unknown document "' + x + '"'); });
  d.ev = FAM_EV[fam].concat(o.ev || []);
  BD[id] = d;
  BD_ORDER.push(id);
  return d;
}
/* premises kinds: annual NOK per m2 at Oslo index 1.0 (rent), purchase price per m2 */
const PREM = {
  home: ['Home office', 0, 0, 'Works from home. No rent.'],
  office: ['Office', 2500, 48000, 'Standard office space.'],
  shop: ['Shop / retail unit', 3600, 52000, 'Street-level retail.'],
  kitchen: ['Restaurant / food premises', 3900, 56000, 'Ventilation, grease trap and approved kitchen.'],
  industrial: ['Industrial hall', 950, 13000, 'Workshop or production hall.'],
  warehouse: ['Warehouse', 850, 11000, 'Storage and logistics hall.'],
  hotel: ['Hotel building', 1700, 36000, 'Per m2 of gross area; large building.'],
  clinic: ['Clinic space', 2900, 46000, 'Treatment rooms.'],
  yard: ['Yard / lot', 480, 6500, 'Open storage or sales yard.'],
  gym: ['Large open hall (gym/leisure)', 1700, 26000, 'High ceilings, floor loads.'],
  none: ['No premises', 0, 0, '']
};

for (const k in SEAS) {
  const m = SEAS[k].reduce((a, b) => a + b, 0) / SEAS[k].length;
  SEAS[k] = SEAS[k].map(x => x / m);
}


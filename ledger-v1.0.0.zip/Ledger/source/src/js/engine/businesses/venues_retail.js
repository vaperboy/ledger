/* ---- src/businesses/venues_retail.js ---- */
/* ===== Venues (food, hospitality, leisure) and retail ===== */
B('foodtruck', 'Food truck', 'venue', 'Food and leisure', {
  blurb: 'Street food from a truck. Cheap to start, weather and permits rule your week.',
  unit: 'meal',
  ticket: 135,
  cogs: 0.34,
  m: 0.1,
  ela: 1.5,
  vat: 'food',
  seas: 'summer',
  b2b: 0.05,
  own: 1,
  std: [['cook', 1], ['helper', 1]],
  mgr: 'ops',
  fixed: 1200,
  open: 9000,
  aud: 0.3,
  skill: 'Cooking',
  minSize: 1,
  maxSize: 3,
  prem: ['none', 0],
  docs: ['org', 'mva', 'mattil', 'haccp', 'torg', 'hms'],
  tw: { perish: 0.06, hours: 40 },
  ev: [],
  eq: [
    E('truck', 'Food truck (fitted)', 520000, 8, 1, 'rcv', ['foodtruck']),
    E('grill', 'Grill and fryers', 42000, 6, 1, 'rc'),
    E('fridge', 'Cold storage', 22000, 8, 1, 'r'),
    E('gen', 'Generator and gas system', 38000, 6, 1, 'r'),
    E('pos', 'Card terminal and POS', 5500, 3, 1, 'rq')
  ],
  knobs: [
    K('menu', 'Menu', '', [
      O('burger', 'Burgers and fries', 'Fast, reliable.', {}),
      O('street', 'Street-food fusion', 'Higher ticket, more prep.', { t: 1.2, d: 0.9, q: 3, k: 0.9 }),
      O('gourmet', 'Gourmet small plates', 'Foodie following.', { t: 1.55, d: 0.7, q: 6, c: 0.05, k: 0.75 })
    ], 0),
    K('place', 'Where you park', '', [
      O('fixed', 'One fixed spot', 'Predictable.', { d: 1.0 }),
      O('events', 'Festivals and events', 'Big crowds, fees per day.', { d: 1.3, w: 1500, r: 1.2 }),
      O('lunch', 'Office parks at lunch', 'Weekday only.', { d: 1.1, t: 1.0 })
    ], 0)
  ],
  crs: [['c1', 'Food hygiene course', 3500, 1, 3], ['c2', 'Street-food workshop', 7500, 1, 4]]
});
B('cafe', 'Café', 'venue', 'Food and leisure', {
  blurb: 'Coffee, pastry and lunch. Location and staff warmth decide the footfall.',
  unit: 'order',
  ticket: 98,
  cogs: 0.3,
  m: 0.09,
  ela: 1.4,
  vat: 'food',
  seas: 'hosp',
  b2b: 0.03,
  own: 0.8,
  std: [['barista', 3], ['cook', 1], ['helper', 1]],
  mgr: 'host',
  fixed: 1700,
  open: 35000,
  aud: 0.3,
  skill: 'Hospitality',
  minSize: 0.4,
  maxSize: 2.5,
  prem: ['kitchen', 70],
  docs: ['org', 'mva', 'mattil', 'haccp', 'hms', 'vik'],
  tw: { perish: 0.05, hours: 70 },
  eq: [
    E('esp', 'Espresso machine', 95000, 7, 1, 'rc'),
    E('grind', 'Grinders and brewing', 22000, 6, 1, 'q'),
    E('disp', 'Display fridge', 28000, 8, 1, 'r'),
    E('oven', 'Oven and prep kitchen', 68000, 8, 1, 'rc'),
    E('dish', 'Dishwasher', 24000, 8, 1, 'r'),
    E('furn', 'Furniture and interior', 130000, 8, 1, 'qc'),
    E('pos', 'POS and card terminals', 12000, 3, 1, 'rq')
  ],
  knobs: [
    K('menu', 'Concept', '', [
      O('quick', 'Quick coffee and pastries', 'Fast turnover.', { d: 1.15, t: 0.85, k: 1.15 }),
      O('brunch', 'Café with brunch and lunch', 'Coffee plus brunch and lunch plates.', {}),
      O('spec', 'Specialty coffee roaster', 'Premium, a loyal crowd.', { t: 1.35, d: 0.8, q: 6, c: 0.03 })
    ], 1),
    KM('alc', 'Also offer', 'Each one brings more guests or a bigger bill; several can run together.', [
      O('wine', 'Beer and wine', 'Evening guests and a higher bill. Needs a serving licence and a knowledge test.', { t: 1.12, d: 1.05, req: ['skjenk', 'kunnsk'] }),
      O('take', 'Lunch to take away', 'Boxed lunches for people in a hurry.', { d: 1.07, t: 0.97, c: 0.01 }),
      O('beans', 'Coffee beans and gear', 'Bags of beans and brewers to take home.', { t: 1.05, c: 0.01 })
    ], 0)
  ],
  crs: [['c1', 'Barista championship course', 8500, 1, 5], ['c2', 'Customer service training', 4500, 1, 3]]
});
B('restaurant', 'Restaurant', 'venue', 'Food and leisure', {
  blurb: 'Full-service dining. Margins are thin, chefs matter, and one bad inspection can close you.',
  unit: 'cover',
  ticket: 410,
  cogs: 0.31,
  m: 0.08,
  ela: 1.3,
  vat: 'food',
  seas: 'hosp',
  b2b: 0.04,
  own: 0.6,
  std: [['chef', 1], ['cook', 3], ['waiter', 4], ['helper', 1]],
  mgr: 'host',
  fixed: 3200,
  open: 90000,
  aud: 0.3,
  skill: 'Cooking',
  minSize: 0.4,
  maxSize: 3,
  needAS: false,
  prem: ['kitchen', 220],
  docs: ['org', 'mva', 'acctr', 'mattil', 'haccp', 'skjenk', 'kunnsk', 'hms', 'vik'],
  tw: { perish: 0.07, hours: 80 },
  eq: [
    E('range', 'Professional kitchen line', 380000, 8, 1, 'rc'),
    E('hood', 'Ventilation and grease trap', 160000, 10, 1, 'r'),
    E('cool', 'Walk-in cooler and freezer', 120000, 8, 1, 'r'),
    E('dish', 'Dishwashing system', 85000, 8, 1, 'r'),
    E('seat', 'Tables, chairs and interior', 420000, 8, 1, 'qc'),
    E('wine', 'Wine and bar setup', 95000, 8, 1, 'q'),
    E('pos', 'POS, booking and printers', 38000, 3, 1, 'rq')
  ],
  knobs: [
    K('con', 'Concept', '', [
      O('cas', 'Casual dining', 'Volume and moderate prices.', { d: 1.15, t: 0.82 }),
      O('bis', 'Bistro', 'Honest food at mid-range prices.', {}),
      O('fine', 'Fine dining', 'High prices, fewer covers, demanding chefs.', { d: 0.55, t: 1.9, q: 8, c: 0.05, k: 0.7 })
    ], 1),
    K('src', 'Sourcing', '', [
      O('bud', 'Budget suppliers', 'Lower cost, lower quality.', { c: -0.04, q: -4 }),
      O('std', 'Standard', 'Ordinary wholesale suppliers.', {}),
      O('loc', 'Local premium ingredients', 'Costs more, builds reputation.', { c: 0.05, q: 5, t: 1.1 })
    ], 1),
    K('bar', 'Drinks focus', '', [
      O('low', 'Light drinks menu', 'A few wines and beers with the food.', {}),
      O('high', 'Strong wine and cocktail programme', 'Margins on drinks are high.', { t: 1.12, c: -0.01, w: 800 })
    ], 0),
    KM('xtra', 'Also offer', 'Several can run together.', [
      O('deliv', 'Delivery apps', 'More orders; the app takes about a quarter of each.', { d: 1.12, t: 0.9 }),
      O('cater', 'Catering', 'Office lunches and private parties.', { d: 1.05, t: 1.05, w: 500 })
    ], 0)
  ],
  crs: [
    ['c1', 'Menu development with a guest chef', 25000, 1, 6],
    ['c2', 'Sommelier course', 14000, 2, 4],
    ['c3', 'Service excellence', 5500, 1, 3]
  ]
});
B('nightclub', 'Bar and nightclub', 'venue', 'Food and leisure', {
  blurb: 'Late-night drinks and music. High margins on drinks, serious risk from licences, fights and noise complaints.',
  unit: 'guest',
  ticket: 320,
  cogs: 0.24,
  m: 0.12,
  ela: 1.1,
  vat: 'std',
  seas: 'newyear',
  b2b: 0.02,
  own: 0.4,
  std: [['bartender', 6], ['guard', 3], ['dj', 1], ['helper', 2]],
  mgr: 'host',
  fixed: 4200,
  open: 120000,
  aud: 0.5,
  skill: 'Hospitality',
  minSize: 0.4,
  maxSize: 2.5,
  needAS: true,
  prem: ['kitchen', 350],
  docs: ['org', 'mva', 'acctr', 'skjenk', 'kunnsk', 'hms', 'vik', 'aml'],
  tw: { perish: 0.02, hours: 40 },
  ev: ['v_fight', 'v_licence', 'v_noise'],
  eq: [
    E('bar', 'Bar installation and coolers', 380000, 8, 1, 'rc'),
    E('sound', 'Sound and light system', 520000, 6, 1, 'qc'),
    E('cctv', 'CCTV and ID scanners', 85000, 5, 1, 'r'),
    E('glass', 'Glassware and dispensing', 70000, 4, 1, 'r'),
    E('vip', 'VIP area and furniture', 240000, 6, 1, 'q'),
    E('pos', 'POS and cloakroom system', 45000, 3, 1, 'rq')
  ],
  knobs: [
    K('hrs', 'Opening hours', '', [
      O('e', 'Until 02:00', 'Lower risk.', { d: 0.85, r: 0.8 }),
      O('l', 'Until 03:00', 'The usual late licence.', {}),
      O('x', 'Extended weekends (needs licence extension)', 'More revenue, more incidents.', { d: 1.2, r: 1.5, req: ['skjenk'] })
    ], 1),
    K('door', 'Door policy', '', [
      O('open', 'Open door', 'Many guests, lower spend, more incidents.', { d: 1.25, t: 0.85, r: 1.4 }),
      O('sel', 'Selective', 'The door picks who comes in.', {}),
      O('excl', 'Exclusive and table service', 'Few guests, high spend.', { d: 0.6, t: 1.6, q: 5, r: 0.8 })
    ], 1)
  ],
  crs: [['c1', 'Responsible serving and de-escalation', 4500, 1, 4]]
});
B('gym', 'Gym', 'venue', 'Food and leisure', {
  blurb: 'Sell memberships. Revenue builds with members, churn is the enemy, equipment makes the quality.',
  unit: 'member-week',
  ticket: 120,
  cogs: 0.05,
  m: 0.12,
  ela: 1.5,
  vat: 'std',
  seas: 'newyear',
  b2b: 0.05,
  own: 0.4,
  std: [['trainer', 4], ['recept', 2], ['cleaner', 1], ['helper', 1]],
  mgr: 'ops',
  fixed: 4500,
  open: 70000,
  aud: 0.4,
  skill: 'Fitness',
  minSize: 0.4,
  maxSize: 3,
  needAS: false,
  prem: ['gym', 900],
  docs: ['org', 'mva', 'hms', 'vik', 'gdpr'],
  tw: { sub: 1, churn: 0.012, perish: 0 },
  ev: ['v_injury', 'v_churn'],
  eq: [
    E('cardio', 'Cardio machines', 42000, 6, 25, 'rc'),
    E('str', 'Strength machines and racks', 38000, 8, 20, 'rc'),
    E('lock', 'Lockers and changing rooms', 220000, 10, 1, 'rq'),
    E('sauna', 'Sauna and wellness', 190000, 10, 1, 'q'),
    E('desk', 'Reception, access control and app', 90000, 5, 1, 'rq')
  ],
  knobs: [
    K('pos', 'Positioning', '', [
      O('low', 'Low-cost 24/7 gym', 'Many members, cheaper fee, few staff.', { t: 0.7, d: 1.5, q: -4, c: -0.01 }),
      O('mid', 'Mid-market with classes', 'A normal fee with group classes.', {}),
      O('prem', 'Premium club', 'High fee, towel service and coaching.', { t: 1.6, d: 0.55, q: 7, w: 5000 })
    ], 1),
    KM('pt', 'Extras', 'Several can run together.', [
      O('pt', 'Personal training', 'Trainers earn commission on packages.', { t: 1.1, c: 0.02 }),
      O('shop', 'Drinks and supplements', 'A small shop by the desk.', { t: 1.04, c: 0.01 }),
      O('kids', 'Kids and youth classes', 'Families join together.', { d: 1.06, w: 600 })
    ], 1)
  ],
  crs: [['c1', 'Group-class instructor course', 7500, 1, 4], ['c2', 'Sales training for memberships', 6000, 1, 3]]
});
B('hotel', 'Hotel (50 rooms)', 'venue', 'Food and leisure', {
  blurb: 'Rooms, breakfast and events. Occupancy and rate move with season, reviews and booking platforms.',
  unit: 'room-night',
  ticket: 1350,
  cogs: 0.16,
  m: 0.14,
  ela: 1.2,
  vat: 'low',
  seas: 'hosp',
  b2b: 0.2,
  own: 0,
  std: [['recept', 4], ['housek', 7], ['cook', 2], ['waiter', 2], ['hm', 1]],
  mgr: 'host',
  fixed: 12000,
  open: 400000,
  aud: 0.5,
  skill: 'Hospitality',
  minSize: 0.4,
  maxSize: 3,
  needAS: true,
  prem: ['hotel', 2200],
  docs: ['org', 'mva', 'acctr', 'mattil', 'haccp', 'skjenk', 'kunnsk', 'hms', 'vik', 'gdpr'],
  tw: { perish: 0.03, hours: 168, ota: 0.17 },
  ev: ['v_ota', 'v_overbook'],
  eq: [
    E('rooms', 'Room furniture and beds (per room)', 52000, 8, 50, 'rcq'),
    E('pms', 'Hotel management system', 150000, 4, 1, 'rq'),
    E('laun', 'Laundry equipment', 420000, 8, 1, 'r'),
    E('kit', 'Breakfast kitchen', 520000, 8, 1, 'r'),
    E('lift', 'Lift and fire systems', 900000, 15, 1, 'r'),
    E('lobby', 'Lobby, bar and conference room', 800000, 8, 1, 'q')
  ],
  knobs: [
    K('star', 'Star level', '', [
      O('b', 'Budget (2-star)', 'Low rates and many bookings.', { t: 0.62, d: 1.25, c: -0.02, q: -5 }),
      O('m', 'Midscale (3-star)', 'Comfortable rooms at mid-range prices.', {}),
      O('u', 'Upscale (4-star)', 'High rates, high expectations.', { t: 1.5, d: 0.75, q: 8, w: 8000 })
    ], 1),
    K('dist', 'Distribution', 'Booking platforms charge commission.', [
      O('ota', 'Mostly booking platforms', 'Easy volume, high commission.', { d: 1.15, ota: 1.2 }),
      O('mix', 'Mix', 'Some platform bookings, some direct.', {}),
      O('dir', 'Direct bookings focus', 'Needs marketing, commission low.', { d: 0.9, ota: 0.4, q: 2 })
    ], 1),
    KM('ev', 'Also offer', 'Several can run together; each costs to run.', [
      O('conf', 'Conferences and weddings', 'Fills quiet days, needs sales staff.', { d: 1.08, w: 4000, t: 1.04 }),
      O('rest', 'Restaurant and bar open to all', 'Locals eat here too. Needs a serving licence.', { t: 1.08, d: 1.04, w: 6000, req: ['skjenk'] }),
      O('spa', 'Spa and wellness', 'Guests stay longer and pay more.', { t: 1.07, d: 1.03, w: 5000 })
    ], 0)
  ],
  crs: [['c1', 'Revenue-management course', 16000, 2, 5], ['c2', 'Front-desk excellence', 6500, 1, 3]]
});
B('casino', 'Casino', 'venue', 'Food and leisure', {
  blurb: 'Tables and slot machines under a fictional licence. The house wins on average, but a bad week can be brutal. Heavy compliance and anti-money-laundering duties.',
  unit: 'guest visit',
  ticket: 1400,
  cogs: 0.2,
  m: 0.22,
  ela: 0.8,
  vat: 'zero',
  seas: 'newyear',
  b2b: 0,
  own: 0,
  std: [['dealer', 12], ['guard', 6], ['recept', 2], ['cashier', 3], ['bartender', 4], ['hm', 1]],
  mgr: 'game',
  fixed: 30000,
  open: 1500000,
  aud: 0.5,
  skill: 'Gaming',
  minSize: 0.4,
  maxSize: 2,
  needAS: true,
  prem: ['hotel', 1800],
  docs: ['org', 'mva', 'acctr', 'casino', 'aml', 'skjenk', 'kunnsk', 'hms', 'vik', 'gdpr'],
  tw: { variance: 0.5, hours: 168 },
  ev: ['v_bigwin', 'v_aml', 'v_cheat', 'v_addict', 'v_robbery'],
  eq: [
    E('tables', 'Gaming tables (roulette, blackjack, poker)', 85000, 8, 24, 'rc'),
    E('slots', 'Slot machines', 160000, 6, 90, 'rc'),
    E('cctv', 'CCTV and surveillance room', 650000, 6, 1, 'r'),
    E('vault', 'Cash vault and counting room', 900000, 20, 1, 'r'),
    E('cage', 'Cage and chip system', 380000, 6, 1, 'r'),
    E('lounge', 'VIP lounge and bar', 1400000, 8, 1, 'q')
  ],
  knobs: [
    K('mix', 'Game mix', '', [
      O('slot', 'Mostly slots', 'Steady, low variance.', { d: 1.1, t: 0.85 }),
      O('mix', 'Balanced floor', 'Slots and tables in balance.', {}),
      O('tab', 'Table-game focus', 'High variance, high ceiling.', { d: 0.8, t: 1.3, q: 3 })
    ], 1),
    K('vip', 'High-roller policy', '', [
      O('cap', 'Low table limits', 'Less variance.', { d: 0.9, t: 0.85, risk: 0.7 }),
      O('std', 'Normal limits', 'The usual table limits.', {}),
      O('high', 'High-roller programme', 'Large swings, comps cost cash.', { d: 1.05, t: 1.45, risk: 1.7, c: 0.04 })
    ], 1),
    K('rg', 'Responsible gaming', '', [
      O('min', 'Legal minimum', 'More revenue, more complaints.', { t: 1.05, r: 1.4 }),
      O('std', 'Strong programme', 'Clear limits and help for players at risk.', {}),
      O('max', 'Strict player protection', 'Less revenue, great standing with regulators.', { t: 0.92, r: 0.6, q: 3 })
    ], 1)
  ],
  crs: [['c1', 'Dealer training', 15000, 3, 6], ['c2', 'AML and fraud detection', 18000, 2, 4]]
});
B('fun', 'Entertainment centre', 'venue', 'Food and leisure', {
  blurb: 'Bowling, arcade or escape rooms with a bar. Birthday parties pay the bills.',
  unit: 'ticket',
  ticket: 210,
  cogs: 0.18,
  m: 0.12,
  ela: 1.3,
  vat: 'low',
  seas: 'winter',
  b2b: 0.12,
  own: 0.5,
  std: [['usher', 3], ['bartender', 2], ['tech', 1], ['cashier', 1]],
  mgr: 'host',
  fixed: 3500,
  open: 60000,
  aud: 0.4,
  skill: 'Hospitality',
  minSize: 0.4,
  maxSize: 2.5,
  prem: ['gym', 1100],
  docs: ['org', 'mva', 'acctr', 'mattil', 'hms', 'vik', 'skjenk', 'kunnsk'],
  tw: { perish: 0.04, hours: 70 },
  ev: ['v_injury'],
  eq: [
    E('lanes', 'Attractions (lanes, arcade, rooms)', 150000, 8, 10, 'rc'),
    E('bar', 'Bar and kitchen', 280000, 8, 1, 'r'),
    E('sound', 'Sound, light and screens', 190000, 6, 1, 'q'),
    E('pos', 'Ticketing and booking system', 36000, 3, 1, 'rq')
  ],
  knobs: [
    K('mix', 'Offering', '', [
      O('arc', 'Arcade and bowling', 'Lanes and games for walk-in guests.', {}),
      O('esc', 'Escape rooms and VR', 'Higher ticket, small groups.', { t: 1.4, d: 0.75, q: 4 }),
      O('party', 'Birthday and corporate events', 'Booked in advance, great margin.', { t: 1.2, d: 0.85 })
    ], 0),
    KM('also', 'Also offer', 'Several can run together.', [
      O('bday', 'Birthday parties', 'Weekends booked by parents.', { d: 1.08, t: 1.05 }),
      O('cafe', 'Café and snacks', 'Families stay longer and eat.', { t: 1.1, c: 0.03 }),
      O('corp', 'Company events', 'Team days on weekday evenings.', { d: 1.04, t: 1.08 })
    ], 0)
  ],
  crs: [['c1', 'Event host training', 5500, 1, 3]]
});
/* retail */
/* round 56: a ski resort and an indoor ski hall (features/world/ski_resorts.js gives the snow, the season and the
   hemisphere). SkiStar: SEK 2.5 billion from 5.8 million skier days in 2017/18 (about SEK 440 a day with lodging and
   shops), profit after tax SEK 486 million. A day pass in Norway costs about 600-700 kr; a chairlift costs tens of
   millions. An indoor hall (Ski Dubai, SNØ in Oslo) runs all year but costs hundreds of millions to build and a lot of
   power to keep cold. */
/* the year's skiing, scaled so a year averages 1 like the other seasons (north, and south for Australia) */
SEAS.ski = (a => a.map(x => x * 12 / a.reduce((t, y) => t + y, 0)))([1.75, 1.95, 1.85, 1.1, 0.04, 0.04, 0.04, 0.04, 0.04, 0.04, 0.3, 1.25]);
SEAS.skiS = (a => a.map(x => x * 12 / a.reduce((t, y) => t + y, 0)))([0.04, 0.04, 0.04, 0.04, 0.3, 1.25, 1.95, 1.95, 1.4, 0.6, 0.04, 0.04]);
DOCS.lift = ['Ski lift approval', 'Lift and cableway authority', 65000, 12, 18000, 'Every lift is inspected and approved before the season.'];
DOCS.zone = ['Zoning and land lease for the slopes', 'Municipality', 45000, 16, 0, 'The slopes, lift lines and parking need a zoning plan and land agreements.'];
PREM.slope = ['Mountain land (lease)', 6, 0, 'Lease of slopes, lift lines and car parks. Per m² a year.'];
B('skires', 'Ski resort', 'venue', 'Food and leisure', {
  blurb: 'Lifts, slopes, rentals and a mountain restaurant. Four months decide the year, and the snow decides the four months.',
  unit: 'skier day',
  ticket: 560,
  cogs: 0.1,
  m: 0.17,
  ela: 0.9,
  vat: 'low',
  seas: 'ski',
  b2b: 0.08,
  own: 0.2,
  std: [['liftop', 8], ['snowtech', 3], ['skiinst', 4], ['cashier', 3], ['cook', 2]],
  mgr: 'host',
  fixed: 24000,
  open: 350000,
  aud: 0.6,
  skill: 'Hospitality',
  minSize: 1,
  maxSize: 4,
  prem: ['slope', 400000],
  docs: ['org', 'mva', 'acctr', 'hms', 'vik', 'mattil', 'lift', 'zone'],
  tw: { hours: 56 },
  ev: ['v_injury'],
  eq: [
    E('chair', 'Chairlift', 42000000, 30, 1, 'rc'),
    E('tbar', 'T-bar and button lifts', 5500000, 25, 3, 'c'),
    E('groom', 'Snow groomers', 3800000, 10, 2, 'rq'),
    E('snowm', 'Snowmaking system', 14000000, 15, 0, 'q'), /* optional: it keeps a poor winter from being a lost one */
    E('rent', 'Rental skis and boards', 1600000, 4, 1, 'q'),
    E('gates', 'Lift pass gates and system', 2200000, 8, 1, 'r'),
    E('kitch', 'Mountain restaurant kitchen', 1300000, 10, 1, 'q')
  ],
  knobs: [
    K('price', 'Lift passes', 'How you sell the skiing.', [
      O('cheap', 'Affordable family skiing', 'Lower prices, full slopes.', { t: 0.8, d: 1.2 }),
      O('std', 'Day passes and season cards', 'The usual mix of day passes and season cards.', {}),
      O('prem', 'Premium resort', 'High prices, short queues, ski-in hotels nearby.', { t: 1.3, d: 0.8, q: 5 })
    ], 1),
    K('summer', 'Summer', 'What happens when the snow is gone.', [
      O('closed', 'Closed in summer', 'Low costs between seasons.', {}),
      O('bike', 'Downhill biking and hiking lifts', 'Some summer guests on the lifts; more staff.', { c: 0.02 })
    ], 0)
  ],
  crs: [['c1', 'Ski instructor certification', 9000, 2, 6], ['c2', 'Avalanche and slope safety', 6500, 1, 4]]
});
B('indoorski', 'Indoor ski hall', 'venue', 'Food and leisure', {
  blurb: 'Real snow all year in a cooled hall. Very expensive to build and to keep cold, busy whatever the weather.',
  unit: 'visit',
  ticket: 470,
  cogs: 0.1,
  m: 0.12,
  ela: 1.1,
  vat: 'low',
  seas: 'hosp',
  b2b: 0.15,
  own: 0.2,
  std: [['liftop', 6], ['snowtech', 3], ['skiinst', 6], ['cashier', 4], ['cook', 3]],
  mgr: 'host',
  fixed: 290000,
  open: 1200000,
  aud: 0.8,
  skill: 'Hospitality',
  minSize: 1,
  maxSize: 2,
  prem: ['none', 0],
  docs: ['org', 'mva', 'acctr', 'hms', 'vik', 'mattil', 'lift'],
  tw: { hours: 84 },
  ev: ['v_injury'],
  eq: [
    E('hall', 'Insulated slope hall', 620000000, 40, 1, 'rc'),
    E('cool', 'Cooling plant and snow production', 140000000, 20, 1, 'r'),
    E('ilift', 'Chairlift and conveyor lifts', 38000000, 25, 1, 'c'),
    E('igroom', 'Snow groomer', 3500000, 10, 1, 'q'),
    E('irent', 'Rental skis and boards', 1800000, 4, 1, 'q'),
    E('ikitch', 'Restaurant and après-ski bar', 6000000, 10, 1, 'q')
  ],
  knobs: [
    K('mix', 'Offering', 'Who you build the hall for.', [
      O('pub', 'Public skiing and lessons', 'Day tickets, lessons and families.', {}),
      O('club', 'Clubs and national teams', 'Training slots sold by the hour: steady, lower price.', { t: 0.8, d: 0.85, r: 0.7 }),
      O('event', 'Events and après-ski', 'Parties and corporate events on snow; bar income, louder nights.', { t: 1.2, d: 0.9 })
    ], 0),
    KM('also', 'Also offer', 'Several can run together.', [
      O('school', 'Ski school', 'Lessons for beginners and children.', { d: 1.06, t: 1.05 }),
      O('hire', 'Equipment hire', 'Skis, boards and boots by the hour.', { t: 1.12, w: 800 }),
      O('apres', 'Après-ski bar', 'Drinks after the slope. Needs a serving licence.', { t: 1.08, w: 1500, req: ['skjenk'] })
    ], 0)
  ],
  crs: [['c1', 'Ski instructor certification', 9000, 2, 6]]
});
B('kiosk', 'Convenience store', 'retail', 'Retail', {
  blurb: 'Snacks, drinks, tobacco, lottery and late hours. Many small baskets.',
  unit: 'basket',
  ticket: 175,
  cogs: 0.74,
  m: 0.06,
  ela: 1.6,
  vat: 'std',
  seas: 'flat',
  b2b: 0,
  own: 1,
  std: [['cashier', 3]],
  mgr: 'retail',
  fixed: 1600,
  open: 40000,
  aud: 0.2,
  skill: 'Retail',
  minSize: 0.4,
  maxSize: 2.5,
  prem: ['shop', 60],
  docs: ['org', 'mva', 'mattil', 'hms'],
  tw: { stock: 12, shrink: 0.012 },
  ev: ['r_robbery'],
  eq: [
    E('shelf', 'Shelving and counter', 55000, 10, 1, 'r'),
    E('frz', 'Freezers and chillers', 18000, 8, 3, 'rc'),
    E('pos', 'POS and scanner', 14000, 3, 1, 'rq'),
    E('cof', 'Coffee machine', 28000, 6, 1, 'q'),
    E('cctv', 'CCTV and alarm', 14500, 5, 1, 'r')
  ],
  knobs: [
    K('hrs', 'Opening hours', '', [
      O('day', '8:00 to 22:00', 'Shorter days, fewer late sales.', { d: 0.85 }),
      O('late', '7:00 to 24:00', 'Early to midnight, every day.', {}),
      O('all', '24 hours', 'More sales, night robbery risk, staffing costs.', { d: 1.18, r: 1.4, w: 5500 })
    ], 1),
    KM('cat', 'Also sell', 'On top of snacks and drinks. Several can run together: more reasons to come in.', [
      O('tob', 'Tobacco', 'Margin and footfall. Needs a tobacco licence.', { d: 1.12, t: 1.1, req: ['tobak'] }),
      O('alc', 'Beer and cider', 'A bigger basket. Needs a sales licence.', { d: 1.05, t: 1.18, req: ['salg'] }),
      O('lotto', 'Lottery and betting', 'Regulars every week, a small commission.', { d: 1.08, t: 0.98 }),
      O('parcel', 'Parcel pickup point', 'People come to collect and buy something while they are here.', { d: 1.1, t: 0.95 })
    ], 0)
  ],
  crs: [['c1', 'Age-check and robbery training', 2500, 1, 3]]
});
B('boutique', 'Clothing boutique', 'retail', 'Retail', {
  blurb: 'Fashion for a niche. Stock risk: unsold seasons turn into discounts.',
  unit: 'basket',
  ticket: 740,
  cogs: 0.52,
  m: 0.09,
  ela: 1.8,
  vat: 'std',
  seas: 'xmas',
  b2b: 0,
  own: 1,
  std: [['cashier', 2]],
  mgr: 'retail',
  fixed: 1500,
  open: 55000,
  aud: 0.3,
  skill: 'Retail',
  minSize: 0.4,
  maxSize: 2.5,
  prem: ['shop', 90],
  docs: ['org', 'mva', 'garanti', 'hms'],
  tw: { stock: 70, shrink: 0.02, season: 1 },
  ev: ['r_trend'],
  eq: [
    E('rack', 'Racks, mannequins and fixtures', 85000, 8, 1, 'rq'),
    E('pos', 'POS and inventory system', 16000, 3, 1, 'rq'),
    E('cctv', 'Security tags and cameras', 24000, 5, 1, 'r'),
    E('web', 'Webshop add-on', 38000, 3, 0, 'q')
  ],
  knobs: [
    K('brand', 'Brands', '', [
      O('fast', 'Fast fashion', 'Cheap, high turnover.', { t: 0.6, d: 1.5, c: -0.04 }),
      O('mid', 'Mid-range labels', 'Known brands at mid-range prices.', {}),
      O('lux', 'Premium designer labels', 'Big baskets, big stock risk.', { t: 2.0, d: 0.5, c: 0.04, q: 6 })
    ], 1),
    KM('also', 'Also offer', 'Several can run together.', [
      O('alter', 'Alterations', 'Hems and fittings while they wait.', { t: 1.04, d: 1.03 }),
      O('web', 'Online shop', 'Sell to the whole country.', { d: 1.1, w: 1200 }),
      O('personal', 'Personal shopping by appointment', 'Fewer customers who spend more.', { t: 1.1, d: 0.98 })
    ], 0)
  ],
  crs: [['c1', 'Visual merchandising', 6500, 1, 3]]
});
B('webshop', 'Webshop', 'retail', 'Retail', {
  blurb: 'Sell products online. Ad spend, returns and shipping decide whether you earn.',
  unit: 'order',
  ticket: 850,
  cogs: 0.47,
  m: 0.12,
  ela: 2.0,
  vat: 'std',
  seas: 'xmas',
  b2b: 0,
  own: 1,
  std: [['helper', 2], ['marketer', 1], ['dev', 1]],
  mgr: 'tech',
  fixed: 4000,
  open: 45000,
  aud: 0.9,
  skill: 'E-commerce',
  minSize: 0.4,
  maxSize: 3,
  prem: ['warehouse', 180],
  docs: ['org', 'mva', 'eh', 'gdpr', 'garanti'],
  tw: { stock: 35, shrink: 0.006, ecom: 1, returns: 0.18 },
  ev: ['r_adCost', 'r_carrier'],
  eq: [
    E('shelf', 'Warehouse shelving and packing benches', 90000, 10, 1, 'rc'),
    E('shop', 'Shop platform and payment', 30000, 2, 1, 'rq'),
    E('scan', 'Scanners and label printers', 14000, 4, 1, 'rc'),
    E('van', 'Delivery van', 190000, 7, 1, 'v', ['van_s', 'ev_van'])
  ],
  knobs: [
    K('ship', 'Shipping', '', [
      O('paid', 'Customers pay shipping', 'Cart abandonment.', { d: 0.9 }),
      O('free', 'Free over {m:799}', 'Bigger baskets.', { d: 1.12, t: 1.05, w: 1800 }),
      O('all', 'Free shipping always', 'Conversion up, margin down.', { d: 1.25, c: 0.05 })
    ], 1),
    K('ret', 'Returns', '', [
      O('strict', 'Strict (14 days, customer pays)', 'Fewer returns, but some shoppers go elsewhere.', { d: 0.93, r: 0.7 }),
      O('std', 'Standard', 'Returns within 30 days for unused items.', {}),
      O('free', 'Free 30-day returns', 'Trust up, returns up.', { d: 1.12, r: 1.4 })
    ], 1)
  ],
  crs: [['c1', 'Conversion optimisation', 9000, 1, 4]]
});
B('grocery', 'Supermarket', 'retail', 'Retail', {
  blurb: 'A neighbourhood supermarket. Tiny margins, huge volume, waste and the big chains. Affiliation with a chain changes your costs.',
  unit: 'basket',
  ticket: 285,
  cogs: 0.75,
  m: 0.03,
  ela: 2.2,
  vat: 'food',
  seas: 'newyear',
  b2b: 0,
  own: 0.3,
  std: [['cashier', 14], ['helper', 8], ['butcher', 2]],
  mgr: 'retail',
  fixed: 12000,
  open: 400000,
  aud: 0.4,
  skill: 'Retail',
  minSize: 0.4,
  maxSize: 2,
  prem: ['shop', 1200],
  docs: ['org', 'mva', 'acctr', 'mattil', 'haccp', 'salg', 'tobak', 'hms', 'vik'],
  tw: { stock: 9, shrink: 0.018, perish: 0.04 },
  ev: ['r_wasteWeek'],
  eq: [
    E('ref', 'Refrigeration and freezers', 1800000, 10, 1, 'rc'),
    E('shelf', 'Shelving and fixtures', 900000, 12, 1, 'r'),
    E('tills', 'Tills and self-checkout', 320000, 5, 1, 'rc'),
    E('bake', 'In-store bakery', 350000, 8, 1, 'q'),
    E('cctv', 'Cameras and EAS gates', 150000, 6, 1, 'r')
  ],
  knobs: [
    K('chain', 'Chain affiliation', '', [
      O('ind', 'Independent', 'Free pricing, weaker purchasing power.', { c: 0.025, d: 0.92 }),
      O('chain', 'Join a chain (fee 1.5% of sales)', 'Better terms and brand pull.', { c: -0.02, d: 1.1, w: 3500 })
    ], 1),
    K('range', 'Range', '', [
      O('disc', 'Discount-led', 'Low prices, more shoppers, smaller baskets.', { t: 0.9, d: 1.2 }),
      O('std', 'Mainstream', 'The everyday range most shoppers expect.', {}),
      O('loc', 'Local produce and deli', 'Premium baskets.', { t: 1.15, d: 0.88, q: 4, c: 0.02 })
    ], 1),
    KM('xtra', 'Also sell', 'Several can run together.', [
      O('alc', 'Beer and cider', 'A bigger basket. Needs a sales licence.', { d: 1.05, t: 1.06, req: ['salg'] }),
      O('tob', 'Tobacco', 'Footfall at the till. Needs a tobacco licence.', { d: 1.04, t: 1.03, req: ['tobak'] }),
      O('parcel', 'Parcel pickup point', 'People come to collect and shop.', { d: 1.06, t: 0.98 }),
      O('pharm', 'Non-prescription medicines', 'Painkillers and plasters by the till.', { d: 1.03, t: 1.02 })
    ], 0)
  ],
  crs: [['c1', 'Fresh-food management', 7500, 1, 4]]
});
B('hardware', 'Building-supplies store', 'retail', 'Retail', {
  blurb: 'Tools, timber and materials for hobbyists and trades. Season and construction cycle matter.',
  unit: 'basket',
  ticket: 1150,
  cogs: 0.7,
  m: 0.06,
  ela: 1.5,
  vat: 'std',
  seas: 'build',
  b2b: 0.45,
  terms: 4,
  own: 0.5,
  std: [['cashier', 3], ['helper', 4], ['sales', 2]],
  mgr: 'retail',
  fixed: 6000,
  open: 250000,
  aud: 0.4,
  skill: 'Retail',
  minSize: 0.4,
  maxSize: 2.5,
  prem: ['warehouse', 1500],
  docs: ['org', 'mva', 'acctr', 'hms', 'vik'],
  tw: { stock: 45, shrink: 0.008 },
  ev: ['r_priceWar'],
  eq: [
    E('rack', 'Heavy racking and timber shed', 750000, 15, 1, 'rc'),
    E('fork', 'Forklift and pallet trucks', 380000, 8, 1, 'rc'),
    E('tills', 'Tills and trade-counter system', 150000, 4, 1, 'rq'),
    E('van', 'Delivery truck', 950000, 8, 1, 'v', ['truck_s', 'van_l']),
    E('saw', 'Cutting and paint-mixing station', 220000, 8, 1, 'q')
  ],
  knobs: [
    K('seg', 'Customers', '', [
      O('diy', 'Hobbyists', 'Higher margin, seasonal.', { t: 1.0, d: 1.0 }),
      O('trade', 'Trade accounts', 'Invoice customers, volume, discounts.', { t: 0.9, d: 1.2, r: 1.1 })
    ], 0),
    KM('also', 'Also offer', 'Several can run together.', [
      O('hire', 'Tool hire', 'Drills, mixers and scaffolding by the day.', { d: 1.06, w: 900 }),
      O('keys', 'Key cutting and repairs', 'Small jobs that bring people in.', { d: 1.04 }),
      O('deliv', 'Delivery to building sites', 'Builders order by phone.', { d: 1.08, w: 1200 })
    ], 0)
  ],
  crs: [['c1', 'Product knowledge course', 5500, 1, 3]]
});
B('cardealer', 'Vehicle dealership', 'retail', 'Retail', {
  blurb: 'Buy, finance and sell cars, trucks and boats. Own a vehicle plant and you can sell its brand. Stock is expensive, floor-plan interest bites, and EVs change the market.',
  unit: 'car sold',
  ticket: 420000,
  cogs: 0.86,
  m: 0.08,
  ela: 1.6,
  vat: 'std',
  seas: 'spring',
  b2b: 0.15,
  terms: 2,
  own: 0.4,
  std: [['cardealer', 3], ['mech', 3], ['recept', 1]],
  mgr: 'retail',
  fixed: 12000,
  open: 600000,
  aud: 0.5,
  skill: 'Sales',
  minSize: 0.4,
  maxSize: 2.5,
  needAS: true,
  prem: ['yard', 2500],
  docs: ['org', 'mva', 'acctr', 'vinn', 'garanti', 'aml', 'hms'],
  tw: { stock: 40, shrink: 0.002, floor: 1, perish: 0 },
  ev: ['r_evShift', 'r_tradeWarranty'],
  eq: [
    E('yard', 'Showroom fit-out and yard lighting', 700000, 10, 1, 'rq'),
    E('lift', 'Workshop lifts and tools', 480000, 10, 2, 'rc'),
    E('diag', 'Diagnostics and charging', 180000, 5, 1, 'q'),
    E('dms', 'Dealer management system', 120000, 3, 1, 'rq'),
    E('demo', 'Demo cars', 400000, 4, 2, 'v', ['car_s', 'car_ev', 'car_lux'])
  ],
  knobs: [
    K('mix', 'Stock', '', [
      O('used', 'Used cars', 'Thin margin, high turnover.', { t: 0.55, d: 1.5, c: -0.02 }),
      O('mix', 'New and used', 'Both new and used cars on the lot.', {}),
      O('ev', 'EV specialist', 'Premium, fast-changing price.', { t: 1.15, d: 0.9, q: 4, r: 1.2 })
    ], 1),
    KM('also', 'Also offer', 'Several can run together.', [
      O('workshop', 'Workshop and service', 'Owners come back for servicing.', { d: 1.06, t: 1.03 }),
      O('finance', 'Car loans through a bank', 'The bank pays you a commission.', { t: 1.05 }),
      O('tradein', 'Trade-ins', 'Take the old car as part payment.', { d: 1.08, c: 0.02 })
    ], 0)
  ],
  crs: [['c1', 'Car finance and sales course', 9500, 1, 4]]
});


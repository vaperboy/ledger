/* ---- src/world/investing.js ---- */
/* ===== Investing: stocks, crypto, savings, funds, finance manager, startups ===== */
function fundPx(k) {
  const f = S.fundPx;
  return f ? f[k] : 100;
}
function initFunds() {
  S.fundPx = { idx: 100, bond: 100, mm: 100 };
  S.inv.funds = S.inv.funds || {};
  S.fm = null;
}
const BOND_DUR = 6; /* average duration of a mixed government and corporate bond fund, in years */
function fundsWeek() {
  if (!S.fundPx) initFunds();
  const F = S.fundPx;
  F.idx *= (1 + S.idxRet - 0.0002);
  F.mm *= (1 + Math.max(0.001, policy() - 0.006) / 52);
  /* a bond fund earns its yield and moves against interest rates: a rise of one point costs about BOND_DUR % */
  const dr = S.econ.rate - (S.econ.rate0 == null ? S.econ.rate : S.econ.rate0);
  F.bond *= (1 + (policy() + 0.008) / 52 - dr * BOND_DUR + gauss() * 0.0015);
  S.econ.rate0 = S.econ.rate;
}
const FUNDS = {
  idx: ['{auth:idx}', 'Tracks the whole listed market. Fee 0.3% a year.'],
  bond: ['{auth:bond}', 'Government and corporate bonds. Lower risk.'],
  mm: ['Money Market Fund', 'Follows the policy rate, very low risk.']
};
function brokerFee(v) {
  return Math.max(29, v * 0.001);
}
function buyAsset(kind, sym, amt) {
  amt = Math.round(amt);
  if (amt < 100) return 'small';
  const px = kind === 'stock' ? S.stocks[sym].p : kind === 'crypto' ? S.crypto[sym].p * 1.008 : fundPx(sym);
  const fee = kind === 'crypto' ? amt * 0.004 : brokerFee(amt);
  if (S.cash < amt + fee) {
    if (liquid() < amt + fee) return 'cash';
    fromSavings(amt + fee);
  }
  if (kind === 'crypto' && S.crypto[sym].dead) return 'dead';
  moveCash(ME, -(amt + fee), 'Bought ' + sym);
  const q = amt / px;
  const bag = kind === 'stock' ? S.inv.stocks : kind === 'crypto' ? S.inv.crypto : S.inv.funds;
  const pos = bag[sym] || (bag[sym] = { q: 0, cost: 0 });
  pos.q += q;
  pos.cost += amt;
  return 'ok';
}
function sellAsset(kind, sym, frac) {
  const bag = kind === 'stock' ? S.inv.stocks : kind === 'crypto' ? S.inv.crypto : S.inv.funds;
  const pos = bag[sym];
  if (!pos || pos.q <= 0) return 0;
  const px = kind === 'stock' ? S.stocks[sym].p : kind === 'crypto' ? S.crypto[sym].p * 0.992 : fundPx(sym);
  const q = pos.q * clamp(frac, 0, 1);
  const v = q * px;
  const cost = pos.cost * clamp(frac, 0, 1);
  const fee = kind === 'crypto' ? v * 0.004 : brokerFee(v);
  pos.q -= q;
  pos.cost -= cost;
  if (pos.q < 1e-9) delete bag[sym];
  moveCash(ME, v - fee, 'Sold ' + sym);
  S.tax.gain = (S.tax.gain || 0) + (v - fee - cost);
  return v;
}
function posValue(kind, sym) {
  const bag = kind === 'stock' ? S.inv.stocks : kind === 'crypto' ? S.inv.crypto : S.inv.funds;
  const p = bag[sym];
  if (!p) return 0;
  const px = kind === 'stock' ? S.stocks[sym].p : kind === 'crypto' ? S.crypto[sym].p : fundPx(sym);
  return p.q * px;
}
function saveMove(amt) {
  amt = Math.round(amt);
  if (amt > 0) {
    if (S.cash < amt) return false;
    moveCash(ME, -(amt), 'To savings');
    S.sav.bal += amt;
  } else {
    if (S.sav.bal < -amt) return false;
    S.sav.bal += amt;
    moveCash(ME, -(amt), 'From savings');
  }
  return true;
}
function openDeposit(amt, weeks) {
  if (S.cash < amt) return false;
  const rate = Math.max(0.01, policy() - 0.002 + weeks / 52 * 0.004);
  moveCash(ME, -(amt), 'Fixed deposit opened');
  S.inv.deposits.push({ id: uid(), bal: amt, rate, wEnd: S.week + weeks, w0: S.week });
  return true;
}
function investWeek() {
  // dividends quarterly
  if (S.week % 13 === 0) {
    for (const k in S.inv.stocks) {
      const pos = S.inv.stocks[k], s = S.stocks[k];
      const d = pos.q * s.p * s.dy / 4;
      if (d > 0) {
        moveCash(ME, d, 'Dividend ' + k);
        S.tax.ytdDiv = (S.tax.ytdDiv || 0) + d;
      }
    }
  }
  S.inv.deposits = S.inv.deposits.filter(d => {
    if (S.week >= d.wEnd) {
      const i = d.bal * d.rate * (d.wEnd - d.w0) / 52;
      moveCash(ME, d.bal + i, 'Deposit matured');
      S.tax.int = (S.tax.int || 0) + i;
      return false;
    }
    return true;
  });
  const fm = S.fm;
  if (fm) {
    const mand = { cons: [0.5, 0.0003, 0.004], bal: [0.8, 0.0006, 0.007], aggr: [1.15, 0.0009, 0.013] }[fm.mandate];
    const alpha = (fm.skill - 55) / 100 * 0.0035;
    const r = mand[0] * S.idxRet + mand[1] + alpha + gauss() * mand[2] * 0.4 - fm.fee / 52;
    const eff = (S.office && S.office.staff && S.office.staff.some(s => s.role === 'fin')) ? 0 : 0;
    fm.bal *= (1 + r);
    fm.ret = (fm.ret || 0) * 0.97 + r;
    if (fm.bal < fm.cost * 0.3 && !fm.warned) {
      fm.warned = 1;
      info('Finance manager', 'Heavy losses in managed portfolio', 'Your finance manager ' + S.npcs[fm.npc].name + ' has lost over 70%.', 0, 'bad');
    }
  }
}
/* finance manager */
function genFinManagers() {
  const out = [];
  for (let i = 0; i < 3; i++) {
    const n = { id: uid(), name: personName(), age: rint(32, 60), role: 'fin', skill: rint(30, 92), hired: 0 };
    n.claim = clamp(n.skill + (chance(0.3) ? rint(8, 25) : rint(-4, 4)), 20, 99);
    n.fee = [0.008, 0.012, 0.016][i];
    n.track = Math.round(clamp((n.claim - 50) / 4 + 6 + gauss() * 2, 1, 18) * 10) / 10;
    S.npcs[n.id] = n;
    out.push(n.id);
  }
  return out;
}
function hireFinManager(nid, mandate, amt) {
  const n = S.npcs[nid];
  if (!n || S.fm) return 'busy';
  amt = Math.round(amt);
  if (liquid() < amt) return 'cash';
  fromSavings(amt);
  moveCash(ME, -(amt), 'To ' + n.name + ', your fund manager');
  S.fm = { npc: nid, mandate, fee: n.fee, bal: amt, cost: amt, skill: n.skill, ret: 0 };
  n.hired = -3;
  return 'ok';
}
function fmAdd(amt) {
  if (!S.fm || S.cash < amt) return false;
  moveCash(ME, -(amt), 'To your fund manager');
  S.fm.bal += amt;
  S.fm.cost += amt;
  return true;
}
function fmWithdraw(amt) {
  if (!S.fm) return false;
  amt = Math.min(amt, S.fm.bal);
  const frac = amt / S.fm.bal;
  const cb = S.fm.cost * frac;
  S.fm.bal -= amt;
  S.fm.cost *= (1 - frac);
  moveCash(ME, amt, 'From your fund manager');
  S.tax.gain = (S.tax.gain || 0) + (amt - cb);
  return true;
}
function fireFinManager() {
  if (!S.fm) return;
  moveCash(ME, S.fm.bal, 'Fund manager let go: money back');
  S.npcs[S.fm.npc].hired = 0;
  S.fm = null;
}
/* startups */
const SU_SECT = [
  'Fintech',
  'Clean energy',
  'Food tech',
  'Health tech',
  'AI software',
  'Maritime tech',
  'Gaming',
  'Retail tech',
  'Biotech',
  'Mobility'
];
const SU_NEUT = [
  'Nova',
  'Harbor',
  'Quanta',
  'Lumen',
  'Meridian',
  'Wave',
  'Spire',
  'Flux',
  'Summit',
  'Growth',
  'Raven',
  'Alba'
];
function genStartup() {
  const q = rng(0.2, 0.92);
  const raise = Math.round(rng(0.8, 6) * 1e6 / 1e5) * 1e5;
  const pre = Math.round(raise * rng(2.5, 6) / 1e5) * 1e5;
  const sec = pick(SU_SECT);
  return {
    id: uid(),
    name: pick(flavour('startupWords', SU_NEUT)) + pick(['ly', 'ify', 'io', 'works', ' Labs', ' ' + CC().forms.ASs, 'tech']),
    sec,
    q,
    raise,
    pre,
    post: pre + raise,
    stage: 0,
    blurb: pick([
      pick(['Founders from a big energy company.', 'Founders from a large bank.', 'Founders from a media group.', 'Founders from a telecom company.', 'Founders who built an app before.']),
      'Two engineers with a working prototype.',
      'Early customers and a waitlist.',
      'Serial founder, second company.',
      'University spin-out with a patent.'
    ]),
    sig: {
      team: clamp(Math.round(q * 100 + gauss() * 12), 5, 99),
      market: clamp(Math.round(rng(35, 90)), 5, 99),
      traction: clamp(Math.round(q * 90 + gauss() * 18), 3, 99)
    }
  };
}
function startupDeals() {
  if (!S.deals_su || S.week - S.deals_suW >= 4) {
    S.deals_su = [genStartup(), genStartup(), genStartup()];
    S.deals_suW = S.week;
  }
  return S.deals_su;
}
function investStartup(deal, amt) {
  amt = rnl(amt, 10000);
  if (amt < KC(50000)) return 'small';
  amt = Math.min(amt, deal.raise);
  if (liquid() < amt) return 'cash';
  fromSavings(amt);
  moveCash(ME, -(amt), 'Invested in ' + deal.name);
  const pct = amt / deal.post * 100;
  const f = {
    id: uid(),
    name: deal.name,
    sec: deal.sec,
    q: deal.q,
    st: 'live',
    stage: 0,
    pct,
    in: amt,
    val: deal.post,
    w0: S.week,
    wNext: S.week + rint(26, 52),
    seat: pct >= 20,
    help: 0,
    rounds: [{ w: S.week, amt, pct }],
    sig: deal.sig
  };
  S.startups.push(f);
  S.deals_su = (S.deals_su || []).filter(d => d.id !== deal.id);
  if (f.seat) note('You hold ' + pct.toFixed(1) + '% of ' + f.name + ' and get a board seat.', 'good');
  return 'ok';
}
const SU_STAGES = ['Seed (building product)', 'Launch (finding the market)', 'Growth (scaling)', 'Exit-ready'];
function startupsWeek() {
  S.startups.forEach(f => {
    if (f.st !== 'live' || S.week < f.wNext) return;
    const pS = clamp(f.q * 0.85 + f.help * 0.08 + (S.econ.dem - 1) * 0.5 - f.stage * 0.06 + (S.mkt && S.mkt.regime === 'bear' ? -0.1 : 0), 0.08, 0.92);
    if (!chance(pS)) {
      if (f.stage <= 2 && !f.bridged && chance(0.5)) {
        f.bridged = 1;
        const need = rnl(f.val * 0.15, 10000);
        addMsg({
          kind: 'ask',
          from: f.name,
          title: f.name + ' is running out of money before the next milestone',
          body: 'Founders ask for a bridge round of ' + money(need) + ' at a flat valuation. Without it they shut down.',
          co: 0,
          opts: [
            {
              l: 'Invest ' + money(need) + ' (' + Math.round(need / f.val * 1000) / 10 + '% more)',
              d: 'Chance of survival 55%.',
              fx: {}
            },
            { l: 'Pass (and be diluted)', d: 'Others may fund it.', fx: {} }
          ],
          act: 'bridge',
          data: { sid: f.id, need },
          exp: S.week + 3
        });
        f.wNext = S.week + 4;
        f.pending = 1;
        return;
      }
      f.st = 'failed';
      f.val = 0;
      note(f.name + ' shut down. Your investment of ' + money(f.in) + ' is lost.', 'bad');
      news('Startup ' + f.name + ' shuts down.', 'n');
      return;
    }
    f.stage++;
    const mult = rng(1.8, 4.2) * (f.stage >= 3 ? 1.5 : 1);
    const oldPost = f.val;
    f.val = f.val * mult;
    if (f.stage >= 3) { // exit
      const type = chance(f.q * 0.7) ? 'acq' : 'small';
      const exitV = f.val * (type === 'acq' ? rng(1.5, 4) : rng(0.7, 1.4));
      const proceeds = exitV * f.pct / 100;
      f.st = 'exit';
      f.val = 0;
      moveCash(ME, proceeds, 'Exit: ' + f.name);
      S.tax.gain = (S.tax.gain || 0) + proceeds - f.in;
      note('EXIT! ' + f.name + ' was acquired. Your stake pays ' + money(proceeds) + ' (' + (proceeds / f.in).toFixed(1) + 'x).', 'good');
      news(f.name + ' is acquired in a deal valued at ' + mshort(exitV) + '.', 'good');
      return;
    }
    // next funding round: dilution unless pro-rata
    const raise = rnl(f.val * 0.2, 10000);
    const myShare = rnl(raise * f.pct / 100, 10000);
    addMsg({
      kind: 'ask',
      from: f.name,
      title: f.name + ' reaches "' + SU_STAGES[f.stage] + '" and raises a round',
      body: 'New valuation ' + money(f.val) + '. They raise ' + money(raise) + ' (20%). Take your pro-rata of ' + money(myShare) + ' to avoid dilution?',
      co: 0,
      opts: [
        { l: 'Take pro-rata ' + money(myShare), d: 'Keep your share.', fx: {} },
        { l: 'Skip (diluted by 20%)', d: 'Your stake shrinks but value rose.', fx: {} }
      ],
      act: 'round',
      data: { sid: f.id, raise, myShare },
      exp: S.week + 3
    });
    f.pending = 1;
    f.wNext = S.week + rint(30, 60);
  });
  S.startups.forEach(f => {
    if (f.st === 'live' && f.pending && f.wNext - S.week > 20) f.pending = 0;
  });
}
ACTS.round = (m, idx) => {
  const f = S.startups.find(x => x.id === m.data.sid);
  if (!f) return true;
  if (idx === 0) {
    if (liquid() < m.data.myShare) return false;
    fromSavings(m.data.myShare);
    moveCash(ME, -(m.data.myShare), 'New funding round: ' + f.name);
    f.in += m.data.myShare;
    f.rounds.push({ w: S.week, amt: m.data.myShare, pct: f.pct });
  } else f.pct *= 0.8;
  f.seat = f.pct >= 20;
  return true;
};
ACTS.bridge = (m, idx) => {
  const f = S.startups.find(x => x.id === m.data.sid);
  if (!f) return true;
  if (idx === 0) {
    if (liquid() < m.data.need) return false;
    fromSavings(m.data.need);
    moveCash(ME, -(m.data.need), 'Bridge money for ' + f.name);
    f.in += m.data.need;
    f.pct += m.data.need / f.val * 100;
    f.help += 0.5;
    if (chance(0.55)) {
      f.wNext = S.week + 20;
      note('The bridge worked: ' + f.name + ' continues.', 'good');
    } else {
      f.st = 'failed';
      f.val = 0;
      note(f.name + ' failed anyway. The bridge is lost.', 'bad');
    }
  } else {
    f.pct *= 0.9;
    if (chance(0.35)) {
      f.wNext = S.week + 20;
    } else {
      f.st = 'failed';
      f.val = 0;
      note(f.name + ' shut down.', 'bad');
    }
  }
  f.pending = 0;
  return true;
};
function helpStartup(f) {
  if (!f.seat || f.st !== 'live') return false;
  if (f.helpedW === S.week) return false;
  f.help = Math.min(2, f.help + 0.25);
  f.helpedW = S.week;
  return true;
}
function sellStartupStake(f, frac) {
  if (f.st !== 'live') return 0;
  const v = f.val * f.pct / 100 * frac * 0.72;
  moveCash(ME, v, 'Sold shares in ' + f.name);
  S.tax.gain = (S.tax.gain || 0) + v - f.in * frac;
  f.pct *= (1 - frac);
  f.in *= (1 - frac);
  f.seat = f.pct >= 20;
  if (f.pct < 0.05) f.st = 'exit';
  return v;
}


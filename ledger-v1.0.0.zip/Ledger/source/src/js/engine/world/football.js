/* ---- src/world/football.js ---- */
/* ===== Football: the top league of each country. Buy a club (if it will sell) or found one; the manager picks the players ===== */
B('club', 'Football club', 'club', 'Sport', {
  blurb: 'A professional club. You own it and set the budget, sponsors and ticket prices. The manager picks the players.',
  unit: 'match',
  ticket: 1000,
  cogs: 0,
  m: 0.05,
  vat: 'zero',
  b2b: 0.3,
  terms: 4,
  own: 0.1,
  std: [],
  mgr: 'gen',
  fixed: 0,
  open: 0,
  docs: ['org', 'acctr'],
  needAS: true,
  noStart: true,
  tw: { club: 1 },
  prem: null,
  skill: 'Sport',
  aud: 0.2
});
BD_ORDER.splice(BD_ORDER.indexOf('club'), 1);
FAM.club = { custom: (co, bd, ctx) => clubWeek(co, bd, ctx), fx() { }, checklist() { } };
const USD = 10.5; /* NOK-equivalent per US dollar */
/* league name, number of clubs, value range of the clubs in USD millions (approximate market values) */
const CLUB_SUF = ['United', 'FC', 'Athletic', 'City', 'Sporting', 'Rovers', 'Town', 'Wanderers', 'Albion', 'Rangers'];
function clubsOf(country) {
  S.clubs = S.clubs || {};
  if (S.clubs[country]) return S.clubs[country];
  const L = LEAGUES[country];
  const c = CO[country];
  const save = S.rs;
  S.rs = (fbHash('club' + country) * 2654435761 + (S.seed || 1)) | 0;
  const n = L[1], lo = L[2][0] * USD * 1e6, hi = L[2][1] * USD * 1e6;
  const out = [];
  const used = {};
  const cities = c.cities.map(x => x.name);
  for (let i = 0; i < n; i++) {
    let nm;
    let g = 0;
    do {
      nm = (i < cities.length && g < 1 ? cities[i] : pick(c.last).replace(/[^A-Za-zÀ-ž ]/g, '') ) + ' ' + pick(CLUB_SUF);
      g++;
    } while (used[nm] && g < 20);
    if (used[nm]) nm = pick(FB_A) + ' ' + nm;
    used[nm] = 1;
    const val = Math.round(lo * Math.pow(hi / lo, Math.pow((n - 1 - i) / Math.max(1, n - 1), 1.6)) / 100000) * 100000;
    out.push({
      id: country + ':' + i,
      name: nm,
      country,
      city: (c.cities[i % c.cities.length]).id,
      rank0: i,
      val,
      owner: 'ai',
      fixed: i < Math.max(2, Math.round(n / 6)) && val > 2000 * USD * 1e6,
      listed: false,
      rel: 40,
      ign: 0,
      lock: 0
    });
  }
  S.rs = save;
  return (S.clubs[country] = out);
}
function clubBase(club, N) {
  return 28 + 57 * ((N - 1 - club.rank0) / Math.max(1, N - 1));
}
function leagueOf(country) {
  S.lg = S.lg || {};
  if (S.lg[country]) return S.lg[country];
  const cl = clubsOf(country);
  const N = cl.length;
  return (S.lg[country] = { season: 1, w0: S.week, t: cl.map(c => ({ id: c.id, s: clubBase(c, N), pts: 0, gp: 0 })), res: {}, last: {} });
}
function clubVal(c) {
  return c.val;
}
/* ---- buying ---- */
function clubMonth() {
  if (!S.clubs) return;
  for (const k in S.clubs) S.clubs[k].forEach(c => {
    if (c.owner !== 'ai' || c.fixed) return;
    if (!c.listed && chance(c.val > 1e9 * 2 ? 0.01 : 0.03)) c.listed = true; else if (c.listed && chance(0.1)) c.listed = false;
    c.rel += (40 - c.rel) * 0.03;
  });
}
/* proposeClub: the core below, then the steps features add: pipeSteps('proposeClub') */
function proposeClub(club, mult) {
  return runSteps('proposeClub', proposeClubCore(club, mult), club, mult);
}
function proposeClubCore(club, mult) {
  if (S.week < club.lock) return { r: 'ignore', msg: 'The club board does not answer.' };
  if (club.fixed) {
    club.ign++;
    return { r: 'reject', msg: 'The owners say the club is not for sale, at any price.' };
  }
  const price = Math.round(club.val * mult / 100000) * 100000;
  if (!club.listed && club.rel < 45 && chance(0.4)) return { r: 'ignore', msg: 'Your offer is ignored.' };
  const need = (club.listed ? 1.0 : 2.3) * (1.1 - club.rel / 400);
  if (mult >= need && (club.listed || chance(0.1))) return { r: 'accept', price, msg: 'The owners agree to sell at ' + money(price) + '.' };
  if (club.listed && mult >= need * 0.88) {
    const p2 = Math.round(club.val * need / 100000) * 100000;
    return { r: 'counter', price: p2, msg: 'The owners will sell for ' + money(p2) + ' and not less.' };
  }
  club.ign++;
  club.rel = Math.max(0, club.rel - 5);
  if (club.ign >= 3) {
    club.lock = S.week + 52;
    return { r: 'reject', msg: 'The board ends the talks. They will not take your calls for a year.' };
  }
  return {
    r: 'reject',
    msg: club.listed ? 'The offer is far below what the owners want.' : 'The club is not for sale.'
  };
}
function genCoach(club, kind, boost) {
  const N = (LEAGUES[club.country] || [0, 16])[1];
  const top = clamp(1 - club.rank0 / N, 0, 1);
  const skill = Math.round(clamp(40 + top * 28 + gauss() * 10 + (boost || 0) + (kind === 'asst' ? -6 : 0), 25, 96));
  const R = clubRev(club);
  const ask = rnl(R / 52 * 0.03 * (0.5 + skill / 70) * (kind === 'asst' ? 0.4 : 1), 100);
  return { id: uid(), name: personName(), skill, wage: ask, age: rint(34, 63), kind };
}
function clubRev(club, fm) {
  const d = fm && fm.div === 2 ? 0.45 : 1;
  return club.val / 3 * d;
}
function foundClub(country, city) {
  const L = LEAGUES[country];
  const val = Math.round(L[2][0] * USD * 1e6 * 0.5 / 100000) * 100000;
  if (S.cash < val * 0.4) return 'cash';
  const cl = clubsOf(country);
  const club = {
    id: country + ':new' + uid(),
    name: pick(CO[country].last).replace(/[^A-Za-zÀ-ž ]/g, '') + ' ' + pick(CLUB_SUF),
    country,
    city: city || CO[country].cities[0].id,
    rank0: cl.length - 1,
    val,
    owner: 'you',
    fixed: false,
    listed: false,
    rel: 50,
    ign: 0,
    lock: 0,
    founded: 1
  };
  cl.push(club);
  const lg = leagueOf(country);
  lg.t.push({ id: club.id, s: 34, pts: 0, gp: 0 });
  payMe(Math.round(val * 0.4), 'Founding of ' + club.name);
  return makeClubCo(club, 2, Math.round(val * 0.4 * 0.5));
}
/* buyClub: steps before ('buyClub.before') and after ('buyClub.after') share ph (ph.r is the result): pipeSteps('buyClub.after') */
function buyClub(club, price) {
  return runPhased('buyClub', [club, price], () => buyClubCore(club, price));
}
function buyClubCore(club, price) {
  if (S.cash < price) return 'cash';
  payMe(price, 'Purchase of ' + club.name);
  club.owner = 'you';
  club.listed = false;
  return makeClubCo(club, 1, Math.round(club.val * 0.03));
}
function makeClubCo(club, div, cash) {
  const prev = CTXCO;
  setCtx({ country: club.country });
  const co = newCompany('club', { city: club.city, form: 'AS', size: 1, name: club.name, country: club.country });
  co.st = 'open';
  co.wOpen = S.week;
  setCash(co, cash);
  co.acc = null;
  pickAccountant(co, poolFor(club.country).acc[1].id);
  ['org', 'acctr', 'mva'].forEach(d => {
    co.docs[d] = { st: 'ok', done: S.week, ok: S.week };
  });
  setCtx(prev);
  const N = LEAGUES[club.country][1];
  co.rep = 55 + (N - club.rank0) * 1.2;
  co.aware = Math.min(100, 50 + (N - club.rank0) * 2.2);
  co.fm = {
    club: club.id,
    div,
    wage: 0.62,
    tix: 0,
    coach: genCoach(club, 'coach'),
    asst: genCoach(club, 'asst'),
    sp: {},
    offers: {},
    offW: -99,
    last: [],
    hist: [],
    titles: 0,
    s: 50,
    val: club.val
  };
  const lg = leagueOf(club.country);
  const row = lg.t.find(x => x.id === club.id);
  if (row) {
    row.s = clubBase(club, lg.t.length);
  }
  co.fm.s = row ? row.s : 50;
  sponsorOffers(co);
  for (const k in SP_SLOTS) {
    const o = (co.fm.offers[k] || [])[0];
    if (o) takeSponsor(co, k, o.id);
  }
  sponsorOffers(co);
  return co;
}
/* ---- sponsors ---- */
const SP_SLOTS = {
  shirt: ['Shirt sponsor', 0.08],
  stad: ['Stadium naming rights', 0.06],
  kit: ['Kit supplier', 0.04],
  p1: ['Official partner', 0.02],
  p2: ['Official partner', 0.02]
};
const SP_IND = [
  'Bank',
  'Telecom',
  'Energy',
  'Airlines',
  'Brewery',
  'Insurance',
  'Motors',
  'Sportswear',
  'Foods',
  'Betting',
  'Cola',
  'Logistics'
];
function sponsorOffers(co) {
  const fm = co.fm, club = clubOf(co);
  const R = clubRev(club, fm);
  fm.offW = S.week;
  for (const k in SP_SLOTS) {
    if (fm.sp[k] && fm.sp[k].until > S.week) continue;
    fm.offers[k] = [];
    for (let i = 0; i < 3; i++) fm.offers[k].push({
      id: uid(),
      name: pick(FB_A) + ' ' + pick(SP_IND),
      wk: rnl(R * SP_SLOTS[k][1] / 52 * rng(0.8, 1.25) * (0.7 + (fm.s || 50) / 150), 100),
      yrs: rint(1, 3)
    });
  }
}
function takeSponsor(co, slot, oid) {
  const o = (co.fm.offers[slot] || []).find(x => x.id === oid);
  if (!o) return 'gone';
  co.fm.sp[slot] = { name: o.name, wk: o.wk, until: S.week + o.yrs * 52 };
  co.fm.offers[slot] = [];
  return 'ok';
}
function clubOf(co) {
  for (const k in S.clubs) {
    const c = S.clubs[k].find(x => x.id === co.fm.club);
    if (c) return c;
  }
  return null;
}
/* ---- the leagues: all clubs play once a week during the season ---- */
function clubLeaguesWeek() {
  const owned = S.cos.filter(c => c.type === 'club' && c.st === 'open' && c.fm);
  const done = {};
  owned.forEach(co => {
    const k = co.country;
    if (done[k]) return;
    done[k] = 1;
    leagueStep(k);
  });
}
function sig(x) {
  return 1 / (1 + Math.exp(-x));
}
function leagueStep(country) {
  const lg = leagueOf(country);
  const own = S.cos.filter(c => c.type === 'club' && c.st === 'open' && c.fm && c.country === country);
  const N = lg.t.length;
  own.forEach(co => {
    const row = lg.t.find(x => x.id === co.fm.club);
    if (row) {
      row.s = ownStrength(co);
      co.fm.s = row.s;
    }
  });
  const sw = S.week - lg.w0;
  const M = Math.min(2 * (N - 1), 40);
  lg.res = {};
  if (sw >= 6 && sw < 6 + M) {
    const ids = lg.t.slice().sort(() => rng(-1, 1));
    for (let i = 0; i + 1 < ids.length; i += 2) {
      const a = ids[i], b = ids[i + 1];
      const ownDiv = (r) => {
        const co = own.find(c => c.fm.club === r.id);
        return co ? co.fm.div : 1;
      };
      const sa = a.s - (ownDiv(a) === 2 ? 10 : 0), sb = b.s - (ownDiv(b) === 2 ? 10 : 0);
      const e = (sa - sb) / 22 + 0.22;
      const pw = sig(e), pd = 0.26 * (1 - Math.abs(pw - 0.5));
      const x = rng(0, 1);
      let ra;
      if (x < pd) ra = 'D'; else if (x < pd + (1 - pd) * pw) ra = 'W'; else ra = 'L';
      const rb = ra === 'W' ? 'L' : ra === 'L' ? 'W' : 'D';
      a.gp++;
      b.gp++;
      a.pts += ra === 'W' ? 3 : ra === 'D' ? 1 : 0;
      b.pts += rb === 'W' ? 3 : rb === 'D' ? 1 : 0;
      const ah = (a.hg || 0) < (b.hg || 0) || ((a.hg || 0) === (b.hg || 0) && chance(0.5));
      if (ah) a.hg = (a.hg || 0) + 1; else b.hg = (b.hg || 0) + 1;
      lg.res[a.id] = { r: ra, home: ah, opp: b.id };
      lg.res[b.id] = { r: rb, home: !ah, opp: a.id };
    }
  }
  if (sw >= 51) seasonEnd(lg, country, own);
}
function ownStrength(co) {
  const fm = co.fm, club = clubOf(co);
  const N = (S.lg[co.country] || { t: [1] }).t.length;
  let s = clubBase(club, N) + (fm.wage - 0.62) * 70 + ((fm.coach ? fm.coach.skill : 35) - 60) * 0.35 - (fm.asst ? 0 : 3) + (fm.form || 0) + (fm.sq || 0);
  if (fm.div === 2) s = Math.max(s, 40);
  return clamp(s, 8, 98);
}
function tableRank(lg, id) {
  const t = lg.t.slice().sort((a, b) => b.pts - a.pts || b.s - a.s);
  return t.findIndex(x => x.id === id) + 1;
}
/* seasonEnd: the core below, then the steps features add: pipeSteps('seasonEnd') */
function seasonEnd(lg, country, own) {
  return runSteps('seasonEnd', seasonEndCore(lg, country, own), lg, country, own);
}
function seasonEndCore(lg, country, own) {
  const N = lg.t.length;
  const sorted = lg.t.slice().sort((a, b) => b.pts - a.pts || b.s - a.s);
  own.forEach(co => {
    const fm = co.fm, club = clubOf(co);
    const rank = sorted.findIndex(x => x.id === fm.club) + 1;
    const exp = club.rank0 + 1;
    const R = clubRev(club, fm);
    const prize = R * 0.04 * (N - rank) / Math.max(1, N - 1);
    coIn(co, prize, 'rev', 'League prize money');
    fm.hist.unshift({ season: lg.season, rank, div: fm.div, pts: (lg.t.find(x => x.id === fm.club) || {}).pts });
    if (fm.hist.length > 12) fm.hist.pop();
    if (rank === 1 && fm.div === 1) {
      fm.titles++;
      co.rep = Math.min(100, co.rep + 6);
      note(co.name + ' win the ' + LEAGUES[country][0] + '!', 'good', co.id);
    }
    let msg = co.name + ' finish ' + rank + ' of ' + N + '.';
    if (fm.div === 1 && rank > N - 3) {
      fm.div = 2;
      msg += ' They are relegated.';
      for (const k in fm.sp) if (fm.sp[k]) fm.sp[k].wk *= 0.6;
    } else if (fm.div === 2 && rank <= 3) {
      fm.div = 1;
      msg += ' They are promoted!';
    }
    club.val = Math.round(club.val * clamp(1 + (exp - rank) / N * 0.12, 0.88, 1.15) * 1.02 / 100000) * 100000;
    fm.val = club.val;
    fm.R = clubRev(club, fm);
    note(msg, rank <= 3 ? 'good' : 'n', co.id);
    fm.s0 = null;
  });
  lg.t.forEach(r => {
    const owned = own.some(c => c.fm.club === r.id);
    const rk = sorted.findIndex(x => x.id === r.id);
    if (!owned) r.s = clamp(r.s * 0.75 + (28 + 57 * ((N - 1 - rk) / Math.max(1, N - 1))) * 0.25 + gauss() * 3, 18, 92);
    r.pts = 0;
    r.gp = 0;
    r.hg = 0;
  });
  lg.season++;
  lg.w0 = S.week + 1;
  lg.res = {};
  own.forEach(co => sponsorOffers(co));
}
/* ---- the club week ---- */
/* clubWeek: the core below, then the steps features add: pipeSteps('clubWeek') */
function clubWeek(co, bd, ctx) {
  return runSteps('clubWeek', clubWeekCore(co, bd, ctx), co, bd, ctx);
}
function clubWeekCore(co, bd, ctx) {
  const fm = co.fm;
  const lg = leagueOf(co.country);
  const club = clubOf(co);
  const R = clubRev(club, fm);
  fm.R = R;
  const res = lg.res[fm.club];
  let rev = 0;
  const tv = R * 0.46 / 52; /* R already counts the division (clubRev) */
  rev += tv;
  let spons = 0;
  for (const k in fm.sp) {
    const s = fm.sp[k];
    if (s && s.until > S.week) spons += s.wk; else if (s) delete fm.sp[k];
  }
  rev += spons;
  const merch = R * 0.12 / 52 * (0.7 + (fm.s || 50) / 200 + (co.rep - 50) / 400);
  rev += merch;
  const M = Math.min(2 * (lg.t.length - 1), 40);
  let md = 0;
  if (res && res.home) {
    const fill = clamp(0.5 + (fm.s || 50) / 250 + (co.rep - 50) / 250 - fm.tix * 0.07, 0.3, 1);
    md = R * 0.20 / (M / 2) * (fill / 0.75) * (1 + fm.tix * 0.15);
    rev += md;
    fm.fill = fill;
  }
  const tr = 0; /* transfers now happen in the transfer windows (round 24) */
  rev += tr; /* transfers handled by the manager */
  const wages = fm.wage * R / 52;
  const coachW = ((fm.coach ? fm.coach.wage : 0) + (fm.asst ? fm.asst.wage : 0));
  const ops = R * 0.3 / 52; /* stadium, travel, academy, staff: about 30% of revenue in a top-flight club */
  const mt = res ? res.r : null;
  if (mt) {
    fm.last.push(mt);
    if (fm.last.length > 8) fm.last.shift();
    co.rep = clamp(co.rep + (mt === 'W' ? 0.35 : mt === 'L' ? -0.3 : 0.02), 0, 100);
  }
  if (mt && fm.coach && fm.last.length >= 8 && !fm.coachNew) {
    const pts = fm.last.reduce((a, x) => a + (x === 'W' ? 3 : x === 'D' ? 1 : 0), 0);
    const rank = tableRank(lg, fm.club), N = lg.t.length;
    if (pts <= 5 && rank > N * 0.6 && chance(0.12)) clubSack(co, 'poor results');
  }
  if (fm.coachNew && S.week - fm.coachNew > 8) fm.coachNew = 0;
  ctx.rev = rev;
  ctx.cogs = wages + coachW + ops;
  ctx.units = res ? 1 : 0;
  ctx.D = 1;
  ctx.cap = 1;
  ctx.util = fm.fill || 0.7;
  ctx.price = 1;
  ctx.cr = 0.8;
  co.dbg = { D: 1, cap: 1, dp: {}, cp: [], bot: '', club: 1 };
  if (S.week % 4 === 0 && S.week - fm.offW >= 13) sponsorOffers(co);
}
function clubSack(co, why) {
  const fm = co.fm;
  const old = fm.coach;
  if (!old) return;
  if (fm.asst) {
    const a = fm.asst;
    fm.coach = Object.assign({}, a, { kind: 'coach', skill: Math.max(25, a.skill - 4), wage: rnl(a.wage * 1.5, 100), interim: 1 });
    fm.asst = null;
    fm.coachNew = S.week;
    addMsg({
      kind: 'info',
      from: co.name,
      title: old.name + ' sacked, ' + a.name + ' takes over',
      body: 'After ' + why + ', the club parted with the manager. The assistant ' + a.name + ' is in charge for now. Find a permanent manager and a new assistant as soon as you can.',
      co: co.id,
      tone: 'bad',
      status: 'done'
    });
  }
  else {
    fm.coach = { id: uid(), name: 'Caretaker', skill: 35, wage: 1000, age: 50, kind: 'coach', interim: 1 };
    fm.coachNew = S.week;
    addMsg({
      kind: 'info',
      from: co.name,
      title: old.name + ' sacked',
      body: 'There is no assistant to step in, so a caretaker leads the team. Hire a manager quickly.',
      co: co.id,
      tone: 'bad',
      status: 'done'
    });
  }
}
function clubCands(co, kind) {
  const club = clubOf(co);
  const out = [];
  for (let i = 0; i < 4; i++) out.push(genCoach(club, kind, rng(-8, 12)));
  return out;
}
function hireCoach(co, c, kind) {
  const fm = co.fm;
  if (kind === 'coach') {
    fm.coach = c;
    fm.coachNew = 0;
  } else fm.asst = c;
  return 'ok';
}


/* ---- src/world/rivals.js ---- */
/* ===== Named rivals: relationships, buyouts and friendly-supplier discounts ===== */
/* rivalName: defined in features/world/company_names.js (names that fit the business) */
/* rivalsOf: the core below, then the steps features add: pipeSteps('rivalsOf') */
function rivalsOf(co) {
  return runSteps('rivalsOf', rivalsOfCore(co), co);
}
function rivalsOfCore(co) {
  const m = ensureMk(co);
  m.riv = m.riv || [];
  const bd = BD[co.type];
  const want = Math.min(5, Math.max(1, m.n));
  const save = S.rs;
  S.rs = (fbHash(mkKey(co)) * 2654435761 + (S.seed || 1) + m.riv.length * 17) | 0;
  while (m.riv.length < want) m.riv.push({
    id: uid(),
    name: (() => {
      let nm, g = 0;
      do {
        nm = rivalName(bd, co.city, co.country);
      } while (g++ < 40 && (m.riv.some(r => r.name === nm) || S.cos.some(c => c.name === nm)));
      return nm;
    })(),
    owner: (() => {
      const C = CO[co.country] || CC();
      return pick(C.first) + ' ' + pick(C.last);
    })(),
    size: Math.round(rng(0.45, 1.5) * 100) / 100,
    rel: Math.round(rng(30, 55)),
    listed: chance(0.12),
    ign: 0,
    lock: 0,
    meet: -99
  });
  S.rs = save;
  if (m.riv.length > want + 1) m.riv.length = want + 1;
  return m.riv;
}
function rivalValue(co, r) {
  const bd = BD[co.type];
  const rev = (bd.Dc || 1) * bd.ticket * cityOf(co.city).dem * r.size * 0.9;
  return rnl(rev * 52 * (Math.max(0.04, bd.m) * 4.5 + 0.15), 1000);
}
function relLabel(r) {
  try { if (window.R31 && R31.known && r && r.owner && !R31.known(r)) return 'Never met'; } catch (e) { }
  return relWord(r.rel);
}
function meetRival(co, r) {
  if (S.week - r.meet < 4) return 'wait';
  const c = KC(4000, co.country);
  if (S.cash < c) return 'cash';
  payMe(c, 'Lunch and a meeting with ' + r.owner);
  r.meet = S.week;
  r.rel = Math.min(100, r.rel + rint(4, 9));
  return 'ok';
}
/* proposeBuy: features adjust the terms first: 'proposeBuy.terms' steps get (co, r, t) with t = { mult, listed, scale }
   (listed: whether the owner is treated as ready to sell; scale: the offer is judged at mult but the price is divided by
   scale afterwards). pipeSteps('proposeBuy.terms') */
function proposeBuy(co, r, mult) {
  const t = { mult, listed: r.listed, scale: 1 };
  runSteps('proposeBuy.terms', t, co, r);
  const x = proposeBuyCore(co, r, t.mult, t.listed);
  if (t.scale !== 1 && x.price) x.price = rnl(x.price / t.scale, 1000);
  return x;
}
function proposeBuyCore(co, r, mult, listed) {
  if (S.week < r.lock) return { r: 'ignore', msg: r.owner + ' does not answer your calls.' };
  const V = rivalValue(co, r);
  const price = rnl(V * mult, 1000);
  if (!listed && r.rel < 45 && chance(0.35)) {
    r.rel = Math.max(0, r.rel - 2);
    return { r: 'ignore', msg: r.owner + ' never replies to your offer.' };
  }
  const need = (listed ? 0.95 : 1.55) * (1.1 - r.rel / 400);
  if (mult >= need) return {
    r: 'accept',
    price,
    msg: r.owner + ' accepts: "' + (listed ? 'Good timing. I was ready to step back.' : 'Not what I planned, but that price is hard to refuse.') + '"'
  };
  if (mult >= need * 0.85) {
    const p2 = rnl(V * need, 1000);
    r.rel = Math.max(0, r.rel - 1);
    return {
      r: 'counter',
      price: p2,
      msg: r.owner + ' counters: "I would sell at ' + money(p2) + '. Not a krone less."'
    };
  }
  r.ign++;
  r.rel = Math.max(0, r.rel - (listed ? 3 : 6));
  if (r.ign >= 3) {
    r.lock = S.week + 26;
    return { r: 'reject', msg: r.owner + ' is fed up with lowball offers and ends contact for now.' };
  }
  return {
    r: 'reject',
    msg: r.owner + ' turns you down: "' + (listed ? 'That is well below what this business is worth.' : 'It is not for sale.') + '"'
  };
}
/* acquireRival: steps before ('acquireRival.before') and after ('acquireRival.after', ph.r is the new company) */
function acquireRival(co, r, price) {
  return runPhased('acquireRival', [co, r, price], () => acquireRivalCore(co, r, price));
}
function acquireRivalCore(co, r, price) {
  if (S.cash < price + KC(200000, co.country)) return 'cash';
  const m = ensureMk(co);
  const bd = calib(BD[co.type]);
  const size = clamp(r.size * 0.8, bd.minSize, bd.maxSize);
  const n = startCompany(co.type, { city: co.city, form: 'AS', country: co.country, size, name: r.name });
  if (typeof n === 'string') return n;
  payMe(price, 'Acquisition of ' + r.name);
  const est = setupEstimate(co.type, { city: co.city, size, form: 'AS', country: co.country });
  moveCash(n, Math.round(est.total * 1.15));
  n.flags.assets = 1;
  if (setupAndOpenNow(n).st === 'setup') n.open13 = S.week + 1; /* not ready yet: it tries again each week (chain_registration_and_boards.js) */
  n.rep = Math.max(n.rep, 50 + r.size * 6);
  n.aware = Math.max(n.aware, 36 + r.size * 22);
  n.wom = (n.wom || 0) + 10;
  n.flags.acq = S.week;
  m.riv = (m.riv || []).filter(x => x !== r);
  m.n = Math.max(1, m.n - 1);
  note('You bought ' + r.name + '. Its customers now belong to you.', 'good', n.id);
  return n;
}
function rivalSupply(co) {
  if (co.st !== 'open' || !co.lastW || !co.lastW.rev) return;
  const bd = BD[co.type];
  if (bd.fam === 'fin' || bd.fam === 'energy' || bd.fam === 'rent') return;
  const m = S.mk[mkKey(co)];
  if (!m || !m.riv) return;
  let best = 0;
  m.riv.forEach(r => {
    if (r.rel > best) best = r.rel;
  });
  if (best >= 55 && co.lastW.cogs > 0) rebate(co, Math.min(co.lastW.rev * Math.min(0.05, (best - 50) * 0.0011), co.lastW.cogs * 0.1));
}
function rivalMonth() {
  for (const k in S.mk) {
    const m = S.mk[k];
    if (!m.riv) continue;
    m.riv.forEach(r => {
      r.rel += (45 - r.rel) * 0.03;
      if (!r.listed && chance(0.03)) r.listed = true; else if (r.listed && chance(0.12)) r.listed = false;
    });
  }
}


/* ---- src/world/deals.js ---- */
/* ===== Deals: selling companies and shares, franchising, holding company, pay yourself ===== */
function saleOffers(co) {
  const V = Math.max(0, companyValue(co));
  const sd = (S.week >> 2) * 77 + co.id;
  const save = S.rs;
  S.rs = (sd * 2654435761) | 0;
  const out = [];
  const prof = coEbit12(co) > 0, strong = co.rep > 55 && prof;
  if (strong) out.push({
    id: 1,
    buyer: 'Strategic buyer',
    price: Math.round(V * rng(1.05, 1.25)),
    now: 1,
    note: 'Pays a premium for a healthy business.'
  });
  out.push({
    id: 2,
    buyer: 'Investment group',
    price: Math.round(V * 0.72),
    later: Math.round(V * 0.38),
    laterW: 52,
    note: '72% now, 38% a year later if profits hold.'
  });
  out.push({
    id: 3,
    buyer: 'Competitor',
    price: Math.round(V * rng(0.92, 1.08)),
    now: 1,
    note: 'Includes a 3-year non-compete.'
  });
  out.push({
    id: 4,
    buyer: 'Quick buyer (distressed price)',
    price: Math.round(V * 0.6),
    now: 1,
    note: 'Closes in a week.'
  });
  S.rs = save;
  return out.map(o => Object.assign(o, { V }));
}
function acceptSale(co, offer) {
  if (co.st === 'sold' || co.st === 'bust') return 'gone';
  const V = offer.V;
  const mine = co.own / 100;
  const proceeds = offer.price * mine;
  const basis = co.form === 'AS' ? co.inj + co.capital * 0 : Math.max(0, co.inj);
  const gain = Math.max(0, proceeds - basis * mine);
  S.tax.gain = (S.tax.gain || 0) + gain;
  moveCash(ME, proceeds, 'Sold ' + co.name + ' (' + offer.buyer + ')');
  if (offer.later) S.deferred = (S.deferred || []).concat([{
    w: S.week + offer.laterW,
    amt: offer.later * mine,
    co: co.id,
    name: co.name,
    hurdle: Math.max(0, coEbit12(co)) * 0.7
  }]);
  S.loans.filter(l => l.co === co.id).forEach(l => closeLoan(l, l.bal));
  co.staff.forEach(s => {
    if (S.npcs[s.id]) S.npcs[s.id].hired = 0;
  });
  if (co.mgr && S.npcs[co.mgr]) S.npcs[co.mgr].hired = 0;
  co.st = 'sold';
  setCash(co, 0);
  S.stats.sold++;
  S.inbox.forEach(m => {
    if (m.co === co.id && m.status === 'open') m.status = 'done';
  });
  S.cos.forEach(c => {
    if (c.hold === co.id) c.hold = 0;
  });
  note('Sold ' + co.name + ' for ' + money(proceeds) + ' to ' + offer.buyer + '.', 'good');
  return 'ok';
}
function deferredWeek() {
  if (!S.deferred) return;
  S.deferred = S.deferred.filter(d => {
    if (S.week >= d.w) {
      const co = S.cos.find(x => x.id === d.co);
      const e = co ? coEbit12(co) : 0;
      const full = e >= (d.hurdle || 0) && chance(0.85);
      const paid = Math.round(d.amt * (full ? 1 : 0.35));
      moveCash(ME, paid, 'Earn-out ' + d.name);
      S.tax.gain = (S.tax.gain || 0) + paid;
      note('Earn-out for ' + d.name + (full ? ' paid in full.' : ' paid in part: the company missed its target.'), full ? 'good' : 'n');
      return false;
    }
    return true;
  });
}
/* private shares */
function shareOffers(co) {
  const V = Math.max(0, companyValue(co));
  return [5, 10, 20, 30, 49].map(p => ({ pct: p, secondary: Math.round(V * p / 100 * 0.85), primary: Math.round(V * p / (100 - p) * 0.9) }));
}
function sellShares(co, pct, mode) {
  if (co.form !== 'AS') return 'notAS';
  if (co.own - pct < 1) return 'toomuch';
  const V = Math.max(1, companyValue(co));
  const inv = personName();
  if (mode === 'primary') {
    const amt = Math.round(V * pct / (100 - pct) * 0.9);
    moveCash(co, amt);
    co.inj += 0;
    co.tx.unshift({ w: S.week, a: amt, l: 'New shares sold to ' + inv });
    co.holders.push({ name: inv, pct: pct * co.own / 100, in: amt });
    co.own = co.own * (1 - pct / 100);
    note('Sold ' + pct + '% of ' + co.name + ' to ' + inv + ' for ' + money(amt) + ' (new shares).', 'good');
    return amt;
  }
  const amt = Math.round(V * pct / 100 * 0.85 * co.own / 100);
  moveCash(ME, amt, 'Sold ' + pct + '% of ' + co.name);
  S.tax.gain = (S.tax.gain || 0) + Math.max(0, amt * 0.7);
  co.holders.push({ name: inv, pct, in: amt });
  co.own -= pct * co.own / 100;
  if (pct >= 20) co.flags.boardSeat = (co.flags.boardSeat || 0) + 1;
  note('Sold ' + pct + '% of ' + co.name + ' to ' + inv + ' for ' + money(amt) + '.', 'good');
  return amt;
}
function dividendHolders(co, amt) {
  co.holders.forEach(h => { /* outside holders paid from company cash via payDividend share handling */ });
}
/* franchising: you are the franchisor */
const FR = { fee0: 0.06 };
function unitSetupCost(co) {
  const bd = BD[co.type];
  let eq = 0;
  bd.eq.forEach(e => {
    if (e.std > 0 && !e.vo) eq += e.cost * Math.max(1, Math.round(e.std * 0.7)); else if (e.vo && e.std > 0) eq += VEH[e.vo[0]][1] * Math.max(1, Math.round(e.std * 0.7));
  });
  const pm = bd.prem ? bd.prem[1] * 0.7 * (FIT[bd.prem[0]] || 0) : 0;
  return rnl((eq + pm + bd.open), 1000);
}
/* V.1.0.0: franchising is for a chain that has proven itself: three stores open for a year, three years as a
   chain, a year in profit, customers who like it, and a chain or managing director to look after franchisees.
   [{t, ok, sub}] for the checklist on the chain page; the franchise documents wait for it (applyDoc.check). */
function frReq(co) {
  const ch = window.R12 && R12.chainOf ? R12.chainOf(co) : null;
  const L = ch ? R12.storesOf(ch) : [], open1y = L.filter(c => c.st === 'open' && S.week - (c.wOpen != null ? c.wOpen : S.week) >= 52).length;
  const age = ch ? S.week - (ch.w0 || S.week) : 0, prof = sum(L, c => sum((c.hist || []).slice(-12), x => x.profit || 0));
  const rep = L.length ? sum(L, c => c.rep || 0) / L.length : 0;
  const boss = ch && ((R12.chiefs && R12.chiefs(ch).length) || (S.org56 && S.org56.md && S.npcs[S.org56.md.npc]) || ch.ceo56);
  const mo = w => Math.max(0, Math.ceil(w / 4.33));
  return [
    { t: 'A registered chain', ok: !!ch, sub: ch ? ch.name : 'Register the first store as a chain first' },
    { t: 'Three stores open for a year', ok: open1y >= 3, sub: open1y + ' of 3' },
    { t: 'Three years as a chain', ok: age >= 156, sub: age >= 156 ? 'Since ' + dateStr(ch.w0) : mo(156 - age) + ' months to go' },
    { t: 'The chain made money last year', ok: prof > 0, sub: prof > 0 ? 'Yes' : 'Not yet' },
    { t: 'Customers like the chain', ok: rep >= 60, sub: L.length ? repWord(rep) : '–' },
    { t: 'Someone to look after franchisees', ok: !!boss, sub: boss ? 'Your chain team does' : 'Hire a chain manager or a managing director' }
  ];
}
addStep('applyDoc.check', 20, 'franchising needs a proven chain', (co, id, ctx) => {
  if (id !== 'fran' || (co.fr && co.fr.on)) return;
  const miss = frReq(co).find(x => !x.ok);
  if (miss) ctx.no = 'Not yet: ' + miss.t.toLowerCase() + ' (' + miss.sub.toLowerCase() + ').';
});
function frSetup(co, o) {
  if (co.fr && co.fr.on) return 'already';
  if (frReq(co).some(x => !x.ok)) return 'Not yet: the chain has to prove itself first.';
  if (!docOk(co, 'fran')) return 'doc';
  co.fr = {
    on: 1,
    fee: o.fee,
    roy: o.roy,
    supp: o.supp,
    share: o.share || 0.45,
    brand: 15,
    mkt: 0.02,
    units: [],
    app: [],
    w0: S.week
  };
  return 'ok';
}
function frApplicants(co) {
  const f = co.fr;
  if (!f || !f.on) return;
  if (f.units.length + f.app.length >= 14) return;
  /* prospects you hosted (features/people/perks_and_hosting.js) come twice as often, keener and with more money */
  const hs = window.PK58 ? PK58.hosted('fr') : 0;
  if (S.week % (hs ? 3 : 6) !== 0 || !chance(0.55 + f.brand / 200 + 0.2 * hs)) return;
  const city = pick(CC().cities);
  const cap = KC(rint(120, 900) * 1000 * (1 + 0.3 * hs), co.country);
  const skill = rint(30, 85);
  /* experience in the trade follows skill; some are eager to start, some careful, some hard bargainers */
  f.app.push({ id: uid(), name: personName(), city: city.id, capital: cap, skill, exp: Math.max(0, Math.round((skill - 30) / 3.5 + rng(-2, 3))), pers: hs && chance(0.5) ? 'eager' : pick(['eager', 'careful', 'tough']), age: rint(26, 58), w: S.week });
}
/* frAccept: steps before ('frAccept.before') and after ('frAccept.after') share ph (ph.r is the result): pipeSteps('frAccept.after') */
function frAccept(co, aid) {
  return runPhased('frAccept', [co, aid], () => frAcceptCore(co, aid));
}
function frAcceptCore(co, aid) {
  const f = co.fr;
  const a = f.app.find(x => x.id === aid);
  if (!a) return 'gone';
  const setup = unitSetupCost(co);
  /* terms agreed with this applicant (features/company/franchise_talks.js), or the franchise's standard terms */
  const t = a.terms;
  const cover = t ? t.grant : [0, 0.5, 1][f.supp];
  const loan = t ? Math.round(setup * t.loan) : 0;
  if (!t && a.capital < setup * (1 - cover) * 0.5 && f.supp === 0) return 'poor';
  if (co.cash < setup * cover + loan) return 'cash';
  if (cover > 0) payCo(co, setup * cover, 'oth', 'Franchise support: ' + a.name);
  if (loan) { moveCash(co, -loan); co.tx.unshift({ w: S.week, a: -loan, l: 'Loan to franchisee ' + a.name }); }
  coIn(co, f.fee * (t ? t.feeF : 1), 'rev', 'Franchise fee');
  const u = { id: a.id, name: a.name, city: a.city, w0: S.week, skill: a.skill, rev: 0, prof: 0, neg: 0, setup };
  if (t) Object.assign(u, { roy: t.roy, supp: cover >= 1 ? 2 : cover > 0 ? 1 : 0, share: t.share, term: t.term, feeF: t.feeF, loan: loan ? { bal: loan, rate: t.rate, pay: Math.round(annuity(loan, t.rate, 60) * 12 / 52) } : null });
  f.units.push(u);
  f.app = f.app.filter(x => x !== a);
  f.brand = Math.min(100, f.brand + 1);
  return 'ok';
}
/* frWeek: defined in features/world/franchise_lifecycle.js */
/* you are the franchisee */
function franchiseTerms(bdId) {
  const bd = BD[bdId];
  return { fee: KC(150000 + bd.open * 2), roy: 0.06, mkt: 0.02, brand: 45 };
}
function applyFranchisee(co) {
  const t = franchiseTerms(co.type);
  co.franchise = { fran: 1, fee: t.fee, roy: t.roy, mkt: t.mkt, brand: t.brand };
  co.rep = Math.max(co.rep, 52);
  co.aware = Math.max(co.aware, 45);
  co.docs.fran_op = { st: 'ok', done: S.week, ok: S.week };
}
/* franchiseeWeek: defined in features/world/franchise_lifecycle.js */
/* holding company */
function createHolding(name, accId) {
  const co = newCompany('hold', { city: S.player.city, form: 'AS', name: name || 'Holding AS' });
  pickAccountant(co, accId);
  const c = CC();
  if (S.cash < c.asCapital + c.asFee) {
    S.cos.pop();
    return null;
  }
  payMe(c.asCapital + c.asFee, 'Holding company set-up');
  setCash(co, c.asCapital);
  co.st = 'open';
  co.wOpen = S.week;
  co.capital = c.asCapital;
  co.inj = c.asCapital;
  co.docs.org = { st: 'ok', ok: S.week, done: S.week };
  co.docs.acctr = { st: 'ok', ok: S.week, done: S.week };
  return co;
}
function moveToHolding(co, hid) {
  const h = getCo(hid);
  if (!h || h.type !== 'hold' || co.form !== 'AS' || co.type === 'hold') return false;
  co.hold = hid;
  return true;
}
function holdInvest(h, amt) {
  if (h.cash < amt) return false;
  moveCash(h, -(amt));
  h.fm.idxU = (h.fm.idxU || 0) + amt / fundPx('idx');
  h.fm.idxCost = (h.fm.idxCost || 0) + amt;
  return true;
}
function holdDivest(h, amt) {
  const v = (h.fm.idxU || 0) * fundPx('idx');
  amt = Math.min(amt, v);
  if (amt <= 0) return false;
  const fr = amt / v;
  h.fm.idxU -= h.fm.idxU * fr;
  h.fm.idxCost *= (1 - fr);
  moveCash(h, amt * 0.9934);
  return true;
}
FAM.hold = {
  custom(co, bd, ctx) {
    const fm = co.fm;
    const px = (fm.idxU || 0) * fundPx('idx');
    fm.assets = px + sum(S.cos.filter(c => c.hold === co.id && c.st !== 'sold' && c.st !== 'bust'), c => companyValue(c) * c.own / 100);
    const i = Math.max(0, co.cash) * Math.max(0, policy() - 0.01) / 52;
    ctx.rev = i;
    ctx.cogs = 0;
    ctx.units = 0;
    ctx.D = 0;
    ctx.cap = 0;
    ctx.util = 0;
    co.dbg = { D: 0, cap: 0, dp: {}, cp: [], bot: '' };
    co.lastW = { units: 0, rev: i, cogs: 0, D: 0, cap: 0, util: 0 };
  },
  checklist() { }
};
B('hold', 'Holding company', 'svc', 'Structure', {
  blurb: 'A company that owns your other companies and investments.',
  unit: 'x',
  ticket: 1,
  cogs: 0,
  D: 1,
  fixed: 400,
  std: [],
  own: 0,
  docs: ['org', 'acctr'],
  needAS: true,
  open: 0,
  eq: []
});
BD_ORDER.pop();
BD.hold.fam = 'hold';
BD.hold.ev = [];
DOCS.fran = [
  'Franchise disclosure document and concept manual',
  'Franchise lawyer',
  25000,
  6,
  0,
  'Describes the concept, fees, support and obligations.'
];


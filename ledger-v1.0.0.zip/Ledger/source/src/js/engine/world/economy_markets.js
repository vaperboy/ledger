/* ---- src/world/economy_markets.js ---- */
/* ===== World: economy, markets (stocks, crypto), rivals ===== */
const STOCK_DEF = [ /* [symbol, neutral name, sector, price, volatility, beta, dividend yield]; a country file can rename them (flavour.stocks) */
  ['NRDK', 'Northpower Energy', 'Energy', 214, 0.034, 0.9, 0.035],
  ['FJSF', 'Bay Seafood Group', 'Seafood', 168, 0.04, 1.0, 0.02],
  ['HVBK', 'Harbour Bank', 'Finance', 122, 0.03, 1.1, 0.045],
  ['STVK', 'Steelworks Industries', 'Industrial', 86, 0.036, 1.2, 0.03],
  ['TLNR', 'Telenet Group', 'Telecom', 142, 0.022, 0.5, 0.055],
  ['SKOG', 'Forest Owners Group', 'Materials', 64, 0.032, 0.9, 0.04],
  ['RETL', 'Metro Retail Holding', 'Retail', 98, 0.035, 1.0, 0.03],
  ['TECH', 'Polar Software', 'Tech', 310, 0.05, 1.5, 0.0],
  ['SHIP', 'Coastal Shipping', 'Shipping', 76, 0.045, 1.3, 0.06],
  ['EIEN', 'City Property', 'Property', 54, 0.03, 0.8, 0.04]
];
const CRYPTO_DEF = [
  ['BTC', 'Bitcoin', 980000, 0.055, 1.0],
  ['ETH', 'Ethereum', 36000, 0.07, 1.2],
  ['SOL', 'Solana', 1700, 0.095, 1.5],
  ['NRC', 'NorCoin (small-cap)', 12, 0.14, 1.8],
  ['MEME', 'MemeX (meme coin)', 0.8, 0.22, 2.0]
];
function initMarkets() {
  S.stocks = {};
  STOCK_DEF.forEach(d => {
    S.stocks[d[0]] = {
      sym: d[0],
      n: flavour('stocks', {})[d[0]] || d[1],
      sec: d[2],
      p: d[3] * rng(0.9, 1.1),
      vol: d[4],
      beta: d[5],
      dy: d[6],
      h: [],
      p0: 0
    };
    S.stocks[d[0]].p0 = S.stocks[d[0]].p;
    for (let i = 0; i < 52; i++) S.stocks[d[0]].h.push(Math.round(S.stocks[d[0]].p * 100) / 100);
  });
  S.crypto = {};
  CRYPTO_DEF.forEach(d => {
    S.crypto[d[0]] = { sym: d[0], n: d[1], p: d[2] * rng(0.9, 1.1), vol: d[3], beta: d[4], h: [], dead: 0 };
    for (let i = 0; i < 52; i++) S.crypto[d[0]].h.push(S.crypto[d[0]].p);
  });
  S.mkt = { regime: 'bull', left: 40, m: 0 };
  S.idxRet = 0;
  S.econ.salmon = 1.0;
  S.idx = 100;
}
function econWeek() {
  const E = S.econ;
  E.left--;
  if (E.left <= 0) {
    const nxt = {
      boom: ['steady', 'slowdown'],
      steady: ['boom', 'slowdown', 'steady'],
      slowdown: ['recession', 'steady'],
      recession: ['steady', 'steady', 'boom']
    }[E.phase];
    E.phase = pick(nxt);
    E.left = rint(20, 80);
    news('The economy shifts to a "' + E.phase + '" phase.', E.phase === 'recession' ? 'bad' : E.phase === 'boom' ? 'good' : 'n');
  }
  const tgt = { boom: 1.05, steady: 1.0, slowdown: 0.96, recession: 0.9 }[E.phase];
  E.dem += (tgt - E.dem) * 0.04 + gauss() * 0.002;
  const mr = (x, m, k, v) => x + (m - x) * k + gauss() * v;
  E.fuel = clamp(mr(E.fuel, 1.0 + (E.phase === 'boom' ? 0.1 : 0), 0.03, 0.02), 0.6, 2.2);
  E.mat = clamp(mr(E.mat, 1.0, 0.02, 0.012), 0.75, 1.6);
  E.power = clamp(mr(E.power, 1.0, 0.03, 0.05), 0.3, 3);
  E.oil = clamp(mr(E.oil, 1.0, 0.02, 0.03), 0.3, 2.5);
  E.freight = clamp(mr(E.freight, E.dem, 0.04, 0.03), 0.5, 2.2);
  E.salmon = clamp(mr(E.salmon || 1, 1.0, 0.03, 0.03), 0.55, 1.8);
  E.housing = clamp(E.housing * (1 + 0.0007 + (E.dem - 1) * 0.004 - (E.rate - 0.04) * 0.012 / 4 + gauss() * 0.0025), 0.6, 2.2);
  E.infl = clamp(E.infl + (0.025 + (E.dem - 1) * 0.15 - E.infl) * 0.01 + gauss() * 0.0003, 0.0, 0.1);
  if (isMonthEnd(S.week)) {
    const cc = homeCC();
    const want = clamp(cc.policy0 + (E.infl - 0.03) * 0.9 + (E.dem - 1) * 0.5, 0.0025, 0.2);
    if (Math.abs(want - E.rate) > 0.0035 && chance(0.35)) {
      const old = E.rate;
      E.rate = Math.round((E.rate + Math.sign(want - E.rate) * 0.0025) * 10000) / 10000;
      news(auth('cb', S.country) + ' ' + (E.rate > old ? 'raises' : 'cuts') + ' the policy rate to ' + pc(E.rate, 2) + '.', E.rate > old ? 'bad' : 'good');
    }
  }
}
function marketWeek() {
  const M = S.mkt;
  M.left--;
  if (M.left <= 0) {
    const nx = {
      bull: ['bull', 'correction', 'bear'],
      correction: ['bull', 'bear'],
      bear: ['bull', 'recovery'],
      recovery: ['bull', 'bull', 'bear'],
      crash: ['bear', 'recovery']
    }[M.regime] || ['bull'];
    M.regime = chance(0.03) ? 'crash' : pick(nx);
    M.left = M.regime === 'crash' ? rint(3, 8) : rint(10, 40);
    if (M.regime === 'crash') news('MARKETS PANIC: stocks and crypto plunge.', 'bad');
  }
  const drift = { bull: 0.0035, correction: -0.003, bear: -0.005, recovery: 0.004, crash: -0.04 }[M.regime];
  const vol = { bull: 0.012, correction: 0.02, bear: 0.022, recovery: 0.018, crash: 0.04 }[M.regime];
  M.m = drift + gauss() * vol + (S.econ.dem - 1) * 0.01;
  let tot = 0, n = 0;
  for (const k in S.stocks) {
    const s = S.stocks[k];
    const r = s.beta * M.m + gauss() * s.vol * 0.4 + (s.sec === 'Energy' ? (S.econ.oil - 1) * 0.004 : 0) + (s.sec === 'Seafood' ? (S.econ.salmon - 1) * 0.004 : 0) + (s.sec === 'Property' ? (S.econ.housing - 1) * 0.003 : 0);
    s.p = Math.max(1, s.p * (1 + r));
    s.h.push(Math.round(s.p * 100) / 100);
    if (s.h.length > 104) s.h.shift();
    tot += r;
    n++;
    if (S.week % 13 === 0) {
      const d = s.p * s.dy / 4;
      for (const q in S.inv.stocks) { }
      s.divW = d;
    } else s.divW = 0;
  }
  S.idxRet = tot / n;
  S.idx *= (1 + S.idxRet);
  for (const k in S.crypto) {
    const c = S.crypto[k];
    if (c.dead) continue;
    let r = c.beta * M.m * 1.8 + gauss() * c.vol * 0.55 + (M.regime === 'bull' ? 0.002 : 0);
    if (k === 'MEME' && chance(0.012)) r += rng(0.2, 1.4);
    if ((k === 'MEME' || k === 'NRC') && chance(0.006)) {
      r = -rng(0.5, 0.93);
      if (chance(0.25)) {
        c.dead = 1;
        news(c.n + ' collapses: rug pull.', 'bad');
      }
    }
    c.p = Math.max(0.0001, c.p * (1 + r));
    c.h.push(c.p);
    if (c.h.length > 104) c.h.shift();
  }
}
/* competitor markets */
function ensureMk(co) {
  const key = mkKey(co);
  if (!S.mk[key]) {
    const city = cityOf(co.city);
    const bd = BD[co.type];
    S.mk[key] = {
      key,
      n: Math.max(1, Math.round(1 + city.pop / 120 + rng(0, 2) * (bd.fam === 'fin' || bd.fam === 'energy' ? 0.3 : 1))),
      pi: 1.0,
      str: rng(0.3, 0.8),
      aggr: rng(0.2, 0.9),
      since: 0,
      uw: 0,
      calls: 0,
      ev: 0
    };
  }
  return S.mk[key];
}
/* rivalsWeek: steps before ('rivalsWeek.before') and after ('rivalsWeek.after') share ph (ph.r is the result): pipeSteps('rivalsWeek.after') */
function rivalsWeek() {
  return runPhased('rivalsWeek', [], () => rivalsWeekCore());
}
function rivalsWeekCore() {
  const groups = {};
  S.cos.forEach(c => {
    if (c.st === 'open' && c.type !== 'club') {
      (groups[mkKey(c)] = groups[mkKey(c)] || []).push(c);
    }
  });
  for (const key in groups) {
    const m = ensureMk(groups[key][0]);
    const cos = groups[key];
    m.pi += (1 - m.pi) * 0.012 + gauss() * 0.003;
    m.pi = clamp(m.pi, 0.78, 1.25);
    const bd = BD[cos[0].type];
    let share = 0;
    cos.forEach(co => {
      const p = priceMult(co);
      const marketRev = Math.max(1, (bd.Dc || 1) * bd.ticket * cityOf(co.city).dem * (m.n + 1));
      share += (co.lastW ? co.lastW.rev : 0) / marketRev;
      const costRatio = co.lastW && co.lastW.rev ? (co.bk.m.cogs || 0) / Math.max(1, co.bk.m.rev || 1) : 0.5;
      if (p < m.pi - 0.035 && chance(0.12 * m.aggr)) {
        m.pi = Math.max(0.8, p + 0.01);
        rivalCall(co, bd, m, 'match');
      }
      else if (p > m.pi + 0.07 && chance(0.04 * m.aggr)) {
        m.pi = Math.min(1.2, m.pi + 0.03);
      }
      if (p < 0.9 && co.lastW && co.lastW.rev && (co.bk.m.rev || 0) > 0 && (sumExp(co.bk.m) > (co.bk.m.rev || 0) * 1.05)) m.uw = (m.uw || 0) + 1; else m.uw = Math.max(0, (m.uw || 0) - 1);
    });
    disruptWeek(m, cos, bd);
    foreignRival(m, cos, bd);
    if (share > 0.4 && m.uw > 6 && chance(0.06)) {
      competitionProbe(cos[0], m);
      m.uw = 0;
    }
    // market dynamics
    if (chance(0.0035 + (S.econ.dem > 1.02 ? 0.002 : 0)) && m.n < 10) {
      m.n++;
      m.pi = Math.max(0.8, m.pi - 0.015);
      const c0 = cos[0];
      note('A new competitor enters the ' + BD[c0.type].n.toLowerCase() + ' market in ' + cityOf(c0.city).name + '.', 'n');
    }
    else if (chance(0.0025 + (S.econ.dem < 0.96 ? 0.003 : 0)) && m.n > 1) {
      m.n--;
      note('A competitor in ' + cityOf(cos[0].city).name + ' closes down.', 'good', cos[0].id);
    }
    if (chance(0.01 * m.aggr) && cos.length) rivalCall(pick(cos), bd, m, 'chat');
  }
}
/* rivalCall: a 'rivalCall.before' step can keep a rival quiet (ph.no) or note something for 'rivalCall.after' */
function rivalCall(co, bd, m, kind) {
  return runPhased('rivalCall', [co, bd, m, kind], () => rivalCallCore(co, bd, m, kind));
}
function rivalCallCore(co, bd, m, kind) {
  if (S.week - (co.flags.lastCall || -99) < 6) return;
  co.flags.lastCall = S.week;
  const rname = personName() + ' (owner, rival ' + bd.n + ')';
  let title, body, opts;
  if (kind === 'match') {
    title = rname + ' calls about your prices';
    body = '"What are you doing? We matched your price cut. If you keep this up, we both bleed."';
    opts = [
      { l: 'Hold your prices', d: 'Stay aggressive.', fx: {} },
      { l: 'Raise prices back a step', d: 'Cool things down.', fx: { pr: 1 } },
      { l: 'Propose to "coordinate" prices', d: 'Illegal. If caught: fine of 8% of turnover.', fx: { coord: 1 } }
    ];
  }
  else {
    title = rname + ' calls to ask what\'s up';
    body = '"Heard you are expanding. Just checking where you stand on prices and customers."';
    opts = [
      { l: 'Be friendly, say nothing', d: '', fx: {} },
      { l: 'Warn them off', d: 'They may react aggressively.', fx: { dem: [1, 1], warn: 1 } },
      { l: 'Hint at a price understanding', d: 'Illegal collusion.', fx: { coord: 1 } }
    ];
  }
  const dec = decider(co, opts);
  if (dec.by === 'mgr') {
    const pck = (S.npcs[co.mgr] && S.npcs[co.mgr].stats.ethic > 50) ? 0 : 0;
    if (pck === 0) addMsg({
      kind: 'info',
      from: co.name,
      title: 'Rival call handled by ' + dec.who.npc.name,
      body: title,
      co: co.id,
      status: 'done'
    });
    return;
  }
  addMsg({
    kind: 'decision',
    from: rname,
    title,
    body,
    co: co.id,
    opts,
    exp: S.week + 2,
    ev: 'rival_call',
    by: dec.by,
    tone: 'n'
  });
}
EV.rival_call = { id: 'rival_call', cat: 'none', t: 'Rival call' };
function competitionProbe(co, m) {
  const f = Math.round(Math.max(30000, (co.bk.y.rev || 0) * 0.02));
  addMsg({
    kind: 'decision',
    from: '{auth:comp}',
    title: 'Competition authority opens a pricing review of ' + co.name,
    body: 'You hold a large local share and have been selling below cost. Authorities suspect predatory pricing.',
    co: co.id,
    opts: [
      {
        l: 'Raise prices to cost level and cooperate',
        d: 'Pay a small administrative fine.',
        fx: { fine: f, pr: 2 }
      },
      {
        l: 'Fight the claim',
        d: '50% chance of heavy fine.',
        fx: { gamble: { p: 0.5, ok: {}, bad: { fine: f * 6, rep: -3 } } }
      }
    ],
    exp: S.week + 3,
    ev: 'probe',
    tone: 'bad'
  });
  note('Competition authority reviews pricing at ' + co.name + '.', 'bad', co.id);
}
EV.probe = { id: 'probe', cat: 'none' };


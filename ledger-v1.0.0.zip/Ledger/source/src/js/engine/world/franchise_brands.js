/* ---- src/world/franchise_brands.js ---- */
/* ===== Franchise brands you can join, terms negotiation, and leasing your buildings ===== */
DOCS.fran_op = ['Franchise operating agreement', 'Franchisor', 0, 0, 0, 'Your signed agreement with the brand.'];
const FB_TYPES = [
  'carclean',
  'carrepair',
  'cleaning',
  'tutor',
  'handy',
  'barber',
  'drivsk',
  'physio',
  'estate',
  'pets',
  'foodtruck',
  'cafe',
  'restaurant',
  'gym',
  'hotel',
  'fun',
  'kiosk',
  'boutique',
  'grocery',
  'hardware',
  'cardealer',
  'bakery',
  'courier'
];
const FB_A = [
  'Nordic',
  'Fjord',
  'Urban',
  'Bright',
  'Prime',
  'Hearth',
  'Peak',
  'Harbor',
  'Golden',
  'Fresh',
  'Anchor',
  'Summit',
  'Birch',
  'Clear',
  'Northern',
  'Blue',
  'Maple',
  'Ember'
];
const FB_TIER = [
  null,
  { n: 'Local brand', u: [3, 12], b: [25, 45], fee: 0.8, roy: [0.04, 0.06], flex: [20, 45], who: 'owner' },
  { n: 'Regional chain', u: [15, 80], b: [45, 62], fee: 1.5, roy: [0.05, 0.07], flex: [35, 60], who: 'owner' },
  {
    n: 'National chain',
    u: [90, 400],
    b: [62, 80],
    fee: 2.6,
    roy: [0.06, 0.085],
    flex: [55, 78],
    who: 'manager'
  },
  { n: 'Global brand', u: [500, 2500], b: [80, 95], fee: 4.2, roy: [0.07, 0.1], flex: [70, 92], who: 'manager' }
];
function fbOk(bdId) {
  return FB_TYPES.indexOf(bdId) >= 0;
}
function fbHash(s) {
  let h = 7;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
  return h;
}
function fbCCode() {
  return (CTXCO && CTXCO.country) || (S && S.country) || CO_ORDER[0];
}
function fbBoss(origin, p) {
  const ks = Object.keys(CO);
  const c = CO[origin] && chance(p) ? origin : pick(ks.filter(k => k !== origin));
  const C = CO[c];
  return pick(C.first) + ' ' + pick(C.last);
}
function fbMake(bdId, t, name, origin, id, used) {
  const bd = calib(BD[bdId]);
  const T = FB_TIER[t];
  const open = rng(0, 1) < (t >= 3 ? 0.35 : 0.65) ? 'open' : (rng(0, 1) < 0.65 ? 'exp' : 'closed');
  const roy = Math.round(Math.min(rng(T.roy[0], T.roy[1]), Math.max(0.03, bd.m * 0.4)) * 1000) / 1000;
  const str = Math.round(rng(T.b[0], T.b[1]));
  const base = (150000 + bd.open * 2) * T.fee * rng(0.9, 1.15);
  return {
    id,
    bd: bdId,
    name,
    origin,
    tier: t,
    tn: T.n,
    units: rint(T.u[0], T.u[1]),
    str,
    open,
    roy,
    mkt: Math.round(Math.min(rng(0.02, 0.04), Math.max(0.01, bd.m * 0.15)) * 100) / 100,
    supp: t >= 3 ? (rng(0, 1) < 0.3 ? 1 : 0) : rint(0, 2),
    term: rint(5, 10),
    fail: Math.round(rng(4, 22 - t * 2)),
    std: rint(52, 80),
    flex: Math.round(rng(T.flex[0], T.flex[1])),
    who: T.who,
    fee0: base,
    contact: fbBoss(origin, [0, 0.93, 0.9, 0.85, 0.8][t]),
    fitMult: 1 + (t - 1) * 0.07,
    size: t
  };
}
/* the word a brand name uses for each trade ("Nordic Plumbing", not "Nordic Plumbing firm") */
const FB_NOUNS = { cons: 'Consulting', tutor: 'Tutoring', carclean: 'Car Care', carrepair: 'Auto Service', photo: 'Photo', handy: 'Handyman', cleaning: 'Cleaning', webdev: 'Digital', mktg: 'Marketing', law: 'Law', acctfirm: 'Accounting', staffing: 'Staffing', barber: 'Hair', drivsk: 'Driving School', physio: 'Physio', estate: 'Estate', pets: 'Pet Care', foodtruck: 'Street Food', cafe: 'Café', restaurant: 'Restaurant', nightclub: 'Club', gym: 'Gym', hotel: 'Hotel', casino: 'Casino', fun: 'Entertainment', kiosk: 'Convenience', boutique: 'Clothing', webshop: 'Online', grocery: 'Supermarket', hardware: 'Building Supplies', cardealer: 'Motors', construction: 'Construction', electrician: 'Electric', plumber: 'Plumbing', realdev: 'Property', event: 'Events', engcons: 'Engineering', bakery: 'Bakery', brewery: 'Brewing', furniture: 'Furniture', salmon: 'Seafood', factory: 'Industries', farm: 'Farms', taxi: 'Taxi', courier: 'Courier', trucking: 'Haulage', shipping: 'Shipping', airline: 'Air', resrent: 'Homes', comrent: 'Properties', parking: 'Parking', insco: 'Insurance', bank: 'Bank', fund: 'Capital', power: 'Power', oilgas: 'Energy' };
function fbNoun(bdId) {
  if (FB_NOUNS[bdId]) return FB_NOUNS[bdId];
  return BD[bdId].n.split(' ')[0].replace(/s$/, '');
}
/* brands of one country: local, regional and national chains named from that country */
function fbLocalList(bdId, cc) {
  S.fb = S.fb || {};
  const key = bdId + '|' + cc;
  if (S.fb[key]) return S.fb[key];
  if (!fbOk(bdId) || !CO[cc]) return (S.fb[key] = []);
  const save = S.rs;
  S.rs = (fbHash(bdId + cc) * 2654435761 + (S.seed || 1) * 97) | 0;
  const C = CO[cc];
  const nb = rint(2, 3);
  const tiers = [1, 2, 3].sort(() => rng(-1, 1)).slice(0, nb).sort();
  const used = [];
  const out = [];
  tiers.forEach(t => {
    let a, g = 0;
    do {
      a = pick(C.nameA);
    } while (used.indexOf(a) >= 0 && g++ < 40);
    used.push(a);
    out.push(fbMake(bdId, t, a + ' ' + fbNoun(bdId), cc, bdId + ':' + cc + ':' + a, used));
  });
  S.rs = save;
  return (S.fb[key] = out);
}
/* worldwide brands: the same in every country, with a home country of their own */
function fbGlobalList(bdId) {
  S.fb = S.fb || {};
  const key = bdId + '|GL';
  if (S.fb[key]) return S.fb[key];
  if (!fbOk(bdId)) return (S.fb[key] = []);
  const save = S.rs;
  S.rs = (fbHash(bdId + 'GL') * 2654435761 + (S.seed || 1) * 97) | 0;
  const out = [];
  if (chance(0.7)) {
    const a = pick(FB_GLOBAL);
    out.push(fbMake(bdId, 4, a + ' ' + fbNoun(bdId), pick(FB_ORIGINS), bdId + ':GL:' + a, []));
  }
  S.rs = save;
  return (S.fb[key] = out);
}
function brandsFor(bdId, cc) {
  cc = cc || fbCCode();
  return fbLocalList(bdId, cc).concat(fbGlobalList(bdId));
}
function fbBrand(id) {
  const p = id.split(':');
  const bdId = p[0];
  if (p.length === 2) return ((S.fb || {})[bdId] || []).find(b => b.id === id) || null;
  return (p[1] === 'GL' ? fbGlobalList(bdId) : fbLocalList(bdId, p[1])).find(b => b.id === id) || null;
}
function fbBrandTier(co) {
  const b = co.franchise && co.franchise.brandId ? fbBrand(co.franchise.brandId) : null;
  return b ? b.tier : 1;
}
function fbFee(b) {
  return KC(b.fee0);
}
function fbUnitStats(b) {
  const bd = calib(BD[b.bd]);
  const rev = bd.Dc * bd.ticket * 0.55 * (0.35 + b.str / 100 * 0.6);
  const mu = bd.m + b.str / 100 * 0.04 - b.roy - b.mkt;
  return { rev, mu };
}
function fbExp(bdId) {
  return S.cos.filter(c => c.type === bdId && c.st !== 'bust' && c.st !== 'sold' && S.week - (c.wOpen || S.week) >= 26 && c.rep >= 52).length;
}
function fbLocked(b) {
  return S.fbLock && S.fbLock[b.id] && S.week < S.fbLock[b.id];
}
function fbStatus(b) {
  if (fbLocked(b)) return { ok: false, why: 'They will not talk to you again for ' + (S.fbLock[b.id] - S.week) + ' weeks.' };
  if (b.open === 'closed') return { ok: false, why: 'This brand does not take new franchisees.' };
  if (b.open === 'exp' && !fbExp(b.bd)) return {
    ok: false,
    why: 'They only franchise to operators with a proven record: run a company of this kind for 6 months with reputation 52+.'
  };
  return { ok: true };
}
function fbFreeProps(bdId, city, m2) {
  const out = [];
  S.cos.forEach(c => {
    if (c.st !== 'open' || c.type !== 'comrent') return;
    (c.props || []).forEach(p => {
      if (p.kind === 'com' && p.city === city && p.units - (p.lu || 0) >= m2) out.push({ co: c.id, pid: p.id, name: p.name, free: p.units - (p.lu || 0) });
    });
  });
  return out;
}
function fbPower(b, ask) {
  const exp = fbExp(b.bd);
  let p = 34 + exp * 14 + (S.credit - 50) * 0.2 + (S.cash > fbFee(b) * 4 ? 8 : 0);
  if (ask && ask.prem) p += 16;
  return { pow: clamp(p, 0, 100), exp };
}
/* ask: {fee, roy, cover 0-2, rent 0-2 (0/6/12 months), veh 0|1, bld 0|1, prem} -> {r, terms, msg} */
function brandWord(v) {
  return v >= 85 ? 'A household name' : v >= 70 ? 'Very well known' : v >= 55 ? 'Well regarded' : v >= 40 ? 'Known locally' : v >= 25 ? 'Still building a name' : 'Little known';
}
function fbWho(b) {
  return [
    '',
    b.contact + ', the founder,',
    b.contact + ', the owner,',
    b.contact + ', the franchise manager,',
    b.contact + ', the CEO,'
  ][b.tier];
}
function fbRole(b) {
  return ['', 'founder', 'owner', 'franchise manager', 'CEO'][b.tier];
}
function fbBan(b) {
  S.fbLock = S.fbLock || {};
  S.fbLock[b.id] = S.week + 9999;
  const a = (S.fbApps || {})[b.id];
  if (a) a.st = 'banned';
}
/* each brand boss has a taste: some want money up front, some want a lasting royalty, some care about the unit looking right */
function fbTaste(b) {
  let h = 7;
  for (let i = 0; i < b.id.length; i++) h = (h * 31 + b.id.charCodeAt(i)) % 9973;
  const u = k => ((h * (k + 3) * 7919) % 1000) / 1000;
  return { fee: 0.55 + u(1) * 1.1, roy: 0.55 + u(2) * 1.1, cover: 0.8 + u(3) * 0.5 };
}
function fbTermsOf(b, ask) {
  const cover = Math.max(ask.cover || 0, 0);
  return {
    fee: Math.round(fbFee(b) * (1 - (ask.fee || 0))),
    roy: Math.max(0, Math.round((b.roy - (ask.roy || 0)) * 1000) / 1000),
    mkt: b.mkt,
    cover: Math.max(cover, b.supp),
    rent: ask.rent || 0,
    veh: ask.veh || 0,
    bld: ask.bld || 0,
    prem: ask.prem || null,
    brand: b.id
  };
}
function fbNegotiate(b, ask, round) {
  const st = fbStatus(b);
  if (!st.ok) return { r: 'closed', msg: st.why };
  const P = fbPower(b, ask);
  const cover = Math.max(ask.cover || 0, 0);
  const extraCover = Math.max(0, cover - b.supp);
  const who = fbWho(b);
  const ta = fbTaste(b);
  const parts = {
    fee: (ask.fee || 0) * 100 * 0.55 * ta.fee,
    roy: (ask.roy || 0) * 100 * 9 * ta.roy,
    cover: extraCover * 13 * ta.cover,
    rent: (ask.rent || 0) * 7,
    veh: ask.veh ? 10 : 0,
    bld: ask.bld ? 16 : 0
  };
  const cost = parts.fee + parts.roy + parts.cover + parts.rent + parts.veh + parts.bld;
  const terms = fbTermsOf(b, ask);
  const gives = !!((ask.fee || 0) < 0 || (ask.roy || 0) < 0);
  if (cost <= 0 && !(ask.fee > 0 || ask.roy > 0 || extraCover || ask.rent || ask.veh || ask.bld)) return {
    r: 'accept',
    cask: Object.assign({}, ask),
    terms,
    msg: who + ' says: "' + (gives ? 'That works for us. Thank you.' : 'Standard terms. We would be glad to have you.') + '"'
  };
  const slack = P.pow - b.flex - cost;
  if (slack >= 0) return {
    r: 'accept',
    cask: Object.assign({}, ask),
    terms,
    msg: who + ' agrees: "' + (gives && cost < 0 ? 'That suits us well. Let us do it.' : b.tier <= 2 ? 'You seem serious. I can live with that.' : 'Head office approved this exception for you.') + '"'
  };
  S.fbIrr = S.fbIrr || {};
  const irr = S.fbIrr[b.id] = (S.fbIrr[b.id] || 0) + 1;
  if (slack >= -34) {
    const pos = Math.max(0, parts.fee) + Math.max(0, parts.roy) + parts.cover + parts.rent + parts.veh + parts.bld;
    const credit = Math.max(0, -parts.fee) + Math.max(0, -parts.roy);
    const f = clamp((P.pow - b.flex + credit) / Math.max(pos, 0.01), 0.15, 0.95);
    const q = (v, st) => Math.round(v / st) * st;
    const cask = Object.assign({}, ask, {
      fee: ask.fee > 0 ? q(ask.fee * f, 0.05) : ask.fee,
      roy: ask.roy > 0 ? q(ask.roy * f, 0.005) : ask.roy,
      cover: Math.max(b.supp, Math.min(cover, b.supp + Math.round(extraCover * f))),
      rent: Math.floor((ask.rent || 0) * f),
      veh: f > 0.5 ? (ask.veh || 0) : 0,
      bld: f > 0.6 ? (ask.bld || 0) : 0
    });
    const lines = [
      'I cannot give you all of that, but I can go part of the way.',
      'Let us find a middle ground. This is what I can do.',
      'That is a bit much, but I like your plan. How about this?'
    ];
    const likes = gives ? ' I do like that you give something back.' : '';
    return {
      r: 'counter',
      cask,
      terms: fbTermsOf(b, cask),
      msg: who + ' says: "' + lines[(irr + b.tier) % 3] + likes + '"'
    };
  }
  if (slack < -60 && irr >= 4 && chance(0.2)) {
    S.fbLock = S.fbLock || {};
    S.fbLock[b.id] = S.week + 12;
    const a = (S.fbApps || {})[b.id];
    if (a) a.st = 'refused';
    return {
      r: 'refuse',
      msg: who + ' says: "We keep going in circles. Come back in a few months, when you have more to show."'
    };
  }
  return {
    r: 'push',
    msg: who + ' says: "' + (slack < -50 ? 'That is far more than a new partner gets. Start smaller and we can talk.' : 'That is more than I can offer right now. Ask for a little less, or give something back.') + '"'
  };
}
/* applying: the brand answers after a week or three, then invites you to talk terms */
function fbApply(b, country, city) {
  S.fbApps = S.fbApps || {};
  const a = S.fbApps[b.id];
  const st = fbStatus(b);
  if (!st.ok) return 'closed';
  if (a && (a.st === 'pending' || a.st === 'invited' || a.st === 'agreed')) return 'already';
  const delay = clamp(Math.round(b.tier * 0.7 + rng(0, 1.2)), 1, 3);
  S.fbApps[b.id] = { st: 'pending', w0: S.week, due: S.week + delay, country, city };
  return 'ok';
}
function fbWeek() {
  if (!S.fbApps) return;
  for (const id in S.fbApps) {
    const a = S.fbApps[id];
    const b = fbBrand(id);
    if (!b) continue;
    if (a.st === 'pending' && S.week >= a.due) {
      const P = fbPower(b).pow;
      if (P < b.flex - 28 && chance(0.55)) {
        a.st = 'refused';
        S.fbLock = S.fbLock || {};
        S.fbLock[id] = S.week + 26;
        addMsg({
          kind: 'info',
          from: b.name,
          title: b.name + ' declines your application',
          body: 'They are not looking for a partner with your background right now. Build a record and try again later.',
          tone: 'bad',
          status: 'done'
        });
      }
      else {
        a.st = 'invited';
        a.exp = S.week + 8;
        addMsg({
          kind: 'info',
          from: b.name,
          title: b.name + ' wants to talk',
          body: fbWho(b).replace(/,$/, '') + ' invites you to discuss terms. The invitation stands for eight weeks.',
          tone: 'good',
          status: 'done',
          go: { a: 'brandopen', p: { b: b.id }, l: 'Meet the ' + fbRole(b) }
        });
      }
    }
    else if (a.st === 'invited' && S.week > a.exp) {
      delete S.fbApps[id];
    }
    else if (a.st === 'agreed' && S.week > a.exp) {
      delete S.fbApps[id];
    }
  }
}
function fbSetupGrant(co, terms) {
  const bd = BD[co.type];
  let eq = 0;
  bd.eq.forEach(e => {
    if (e.std > 0 && !e.vo) eq += e.cost * Math.max(1, Math.round(e.std * 0.7));
  });
  let g = (eq + (bd.prem && bd.prem[0] !== 'none' ? (FIT[bd.prem[0]] || 0) * bd.prem[1] * co.size : 0)) * [0, 0.4, 0.7][terms.cover || 0];
  if (terms.rent && bd.prem && PREM[bd.prem[0]] && bd.prem[1] > 0) g += PREM[bd.prem[0]][1] * cityOf(co.city).rent * bd.prem[1] * co.size / 12 * [0, 6, 12][terms.rent];
  if (terms.veh) bd.eq.forEach(e => {
    if (e.vo && VEH[e.vo[0]]) g += VEH[e.vo[0]][1] * e.std * 0.5;
  });
  return KC(g, co.country);
}
function applyBrand(co, b, terms) {
  co.franchise = {
    fran: 1,
    brandId: b.id,
    brandName: b.name,
    fee: terms.fee,
    roy: terms.roy,
    mkt: terms.mkt,
    brand: b.str,
    std: b.std,
    cover: terms.cover,
    bld: terms.bld,
    term: b.term,
    w0: S.week
  };
  co.rep = Math.max(co.rep, 38 + b.tier * 6);
  co.aware = Math.max(co.aware, 25 + b.str * 0.55);
  co.docs.fran_op = { st: 'ok', done: S.week, ok: S.week };
  const g = fbSetupGrant(co, terms);
  if (g > 0) {
    moveCash(co, g);
    co.inj = (co.inj || 0) + g;
    co.tx.unshift({ w: S.week, a: g, l: 'Franchisor setup support: ' + b.name });
    co.flags.fbGrant = g;
  }
  if (terms.prem) {
    co.landlord = terms.prem;
  }
}
function leaseNote(co) {
  const lo = co.landlord;
  if (!lo || co.prem.leased) return;
  const L = getCo(lo.co);
  const p = L && (L.props || []).find(x => x.id === lo.pid);
  if (!p || !co.prem.m2) return;
  p.lu = (p.lu || 0) + co.prem.m2;
  p.leases = p.leases || [];
  p.leases.push({ co: co.id, m2: co.prem.m2 });
  co.prem.leased = 1;
}
function leaseClean() {
  S.cos.forEach(L => {
    if (L.type !== 'comrent' || !L.props) return;
    L.props.forEach(p => {
      if (!p.leases) return;
      p.leases = p.leases.filter(l => {
        if (l.co) {
          const t = getCo(l.co);
          if (!t || t.st === 'sold' || t.st === 'bust') {
            p.lu = Math.max(0, (p.lu || 0) - l.m2);
            return false;
          }
          return true;
        }
        if (S.week >= l.until) {
          p.lu = Math.max(0, (p.lu || 0) - l.m2);
          note('A tenant (' + l.name + ') left ' + p.name + '.', 'n', L.id);
          return false;
        }
        return true;
      });
    });
  });
}
/* marketing your own buildings */
function propTenants(co, p) {
  const seed = (S.week >> 2) * 977 + p.id;
  const save = S.rs;
  S.rs = (seed * 2654435761) | 0;
  const out = [];
  const free = p.units - (p.lu || 0);
  if (free < 20) {
    S.rs = save;
    return out;
  }
  const ids = FB_TYPES.filter(id => BD[id].prem && BD[id].prem[0] !== 'none' && BD[id].prem[0] !== 'home');
  for (let i = 0; i < 3; i++) {
    const id = pick(ids), bd = BD[id];
    const bs = brandsFor(id);
    const nm = bs.length && chance(0.6) ? pick(bs).name + ' (franchisee)' : personName().split(' ')[1] + ' ' + bd.n.split(' ')[0];
    const m2 = Math.min(free, Math.round(bd.prem[1] * rng(0.7, 1.4) / 10) * 10 || 20);
    out.push({ i, name: nm, type: id, m2, rw: p.rentU * rng(1.0, 1.12), yrs: rint(3, 8), buyPct: rng(1.02, 1.12) });
  }
  S.rs = save;
  return out;
}
function leaseTo(co, pid, o) {
  const p = (co.props || []).find(x => x.id === pid);
  if (!p || p.units - (p.lu || 0) < o.m2) return 'bad';
  p.lu = (p.lu || 0) + o.m2;
  (p.leases = p.leases || []).push({ name: o.name, m2: o.m2, rw: o.rw, until: S.week + o.yrs * 52 });
  return 'ok';
}
function sellPropTo(co, pid, o) {
  const i = (co.props || []).findIndex(x => x.id === pid);
  if (i < 0) return 0;
  const p = co.props[i];
  if ((p.leases || []).some(l => l.co)) return 'leased';
  const net = Math.round(p.val * o.buyPct);
  co.props.splice(i, 1);
  coIn(co, net, null, 'Property sold to ' + o.name);
  if (p.loan) {
    const l = S.loans.find(x => x.id === p.loan);
    if (l) {
      moveCash(co, -(l.bal));
      S.loans = S.loans.filter(x => x !== l);
    }
  }
  const gain = net - p.cost;
  if (gain > 0) bk(co, 'rev', gain); else bk(co, 'loss', -gain);
  return net;
}
function fbTn(b) {
  return b.tn + (b.tier === 4 && b.origin && CO[b.origin] ? ' · from ' + CO[b.origin].name : '');
}


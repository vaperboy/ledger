/* ---- src/world/abroad.js ---- */
/* ===== Abroad: foreign branches, master franchises, country desks, loophole rivals ===== */
DOCS.forreg = [
  'Foreign entity registration and tax representative',
  'Local registry and tax office',
  30000,
  3,
  0,
  'Needed to trade through a subsidiary in another country. Takes longer without an HQ country desk.'
];
function hqRole(k) {
  if (HQ_ROLES[k]) return HQ_ROLES[k];
  if (k && k.indexOf('cd_') === 0 && CO[k.slice(3)]) {
    const c = CO[k.slice(3)];
    return [
      c.name + ' compliance manager',
      rnl(62000 * Math.sqrt(c.wage || 1), 100),
      'Handles permits, registrations and new rules for everything you run in ' + c.name + '. Paperwork there takes about 40% less time and surprise rule changes are absorbed.'
    ];
  }
  return null;
}
function foreignCountries() {
  const out = [];
  S.cos.forEach(c => {
    if (c.st === 'sold' || c.st === 'bust') return;
    if (c.country && c.country !== S.country && out.indexOf(c.country) < 0) out.push(c.country);
    if (c.fr && c.fr.masters) c.fr.masters.forEach(m => {
      if (m.c !== S.country && out.indexOf(m.c) < 0) out.push(m.c);
    });
  });
  return out;
}
function hqRoleKeys() {
  return Object.keys(HQ_ROLES).concat(foreignCountries().map(c => 'cd_' + c));
}
function deskFor(country) {
  return hasHQ('cd_' + country);
}
function expandAbroad(co, country, city) {
  if (co.st !== 'open') return 'bad';
  if (!CO[country] || country === co.country) return 'bad';
  if (co.rep < 35) return 'brand';
  const lg = legalStatus(co.type, country);
  if (!lg.ok) return 'banned';
  const prev = CTXCO;
  setCtx({ country });
  const n = startCompany(co.type, { country, city: city || CO[country].cities[0].id, form: 'AS', name: co.name + ' ' + CO[country].name });
  setCtx(prev);
  if (typeof n === 'string') return n;
  n.foreignOf = co.id;
  n.rep = Math.max(n.rep, Math.round(co.rep * 0.55));
  n.aware = Math.max(n.aware, Math.round(co.aware * 0.4));
  n.wom = Math.max(n.wom || 0, Math.round(co.aware * 0.2));
  note(n.name + ' is registered in ' + CO[country].name + '. Complete the foreign registration and local permits before opening.', 'n', n.id);
  return n;
}
function frMasterCap(country) {
  return clamp(Math.round(Math.sqrt(CO[country].pop) * 2), 4, 30);
}
function frMaster(co, country) {
  const f = co.fr;
  if (!f || !f.on) return 'nofr';
  if (!CO[country] || country === co.country) return 'bad';
  f.masters = f.masters || [];
  if (f.masters.some(m => m.c === country)) return 'already';
  if (!legalStatus(co.type, country).ok) return 'banned';
  const fee = KC(f.fee * 3, country);
  const legal = KC(DOCS.fran[2] * CO[country].bur, country);
  if (co.cash < legal) return 'cash';
  payCo(co, legal, 'oth', 'Master franchise legal work: ' + CO[country].name);
  coIn(co, fee, 'rev', 'Master franchise fee: ' + CO[country].name);
  f.masters.push({
    c: country,
    w0: S.week,
    ready: S.week + Math.ceil(6 * CO[country].bur * (deskFor(country) ? 0.6 : 1.3)),
    n: 0,
    cap: frMasterCap(country),
    rev: 0
  });
  return 'ok';
}
function masterWeek(co) {
  const f = co.fr;
  if (!f || !f.masters || !f.masters.length) return 0;
  const bd = BD[co.type];
  let tot = 0;
  f.masters.forEach(m => {
    if (S.week < m.ready) return;
    const c = CO[m.c];
    if (S.week % 8 === 0 && m.n < m.cap && chance(0.35 + f.brand / 200)) m.n++;
    if (m.n > 0 && chance(0.0015 * m.n)) {
      m.n--;
    }
    const rev = m.n * bd.Dc * bd.ticket * c.mkt * c.pl * (0.35 + f.brand / 100 * 0.6) * (1 + (S.econ.dem - 1) * 0.8) * 0.7;
    m.rev = rev;
    const roy = rev * f.roy * 0.5;
    tot += roy;
  });
  if (tot) coIn(co, tot, 'rev', 'Master franchise royalties');
  return tot;
}
/* regulation orders: each country with your operations may issue new rules */
/* fxMonth: the core below, then the steps features add: pipeSteps('fxMonth') */
function fxMonth() {
  return runSteps('fxMonth', fxMonthCore());
}
function fxMonthCore() {
  S.fxd = S.fxd || {};
  CO_ORDER.forEach(k => {
    if (k === BASE_COUNTRY || k === S.country) return;
    const p = S.fxd[k] || 1;
    S.fxd[k] = clamp(p * (1 + gauss() * 0.012 + (1 - p) * 0.06), 0.8, 1.25);
  });
}
function regulationMonth() {
  clubMonth();
  vendMonth();
  rivalMonth();
  fxMonth();
  leaseClean();
  foreignCountries().forEach(k => {
    const c = CO[k];
    if (!chance(0.1 * c.bur)) return;
    const desk = deskFor(k);
    const live = S.cos.filter(x => x.st === 'open' && x.country === k);
    const target = live[0] || S.cos.find(x => x.st === 'open' && x.fr && x.fr.masters && x.fr.masters.some(m => m.c === k));
    if (!target) return;
    const what = pick([
      'new data and labelling rules',
      'a stricter permit regime',
      'higher local reporting duties',
      'a changed employment regulation'
    ]);
    if (desk) {
      note('Your ' + c.name + ' desk handled ' + what + ' with no trouble.', 'good', target.id);
      return;
    }
    const f = KC(rng(8000, 30000) * c.bur, k);
    payCo(target, f, 'fine', 'Late compliance with ' + what + ' in ' + c.name);
    addMsg({
      kind: 'info',
      from: c.name + ' authorities',
      title: 'New rules in ' + c.name,
      body: 'You missed ' + what + ' and were fined ' + money(f) + '. An HQ country desk for ' + c.name + ' would have caught it.',
      co: target.id,
      tone: 'bad',
      status: 'done'
    });
  });
}
/* cheap-loophole rivals */
function disruptWeek(m, cos, bd) {
  const c0 = cos[0];
  const cc = CO[c0.country || S.country] || CC();
  if (m.dis) {
    const d = m.dis;
    if (S.week - d.w0 > d.dur || chance(0.004)) {
      note('The cheap rival ' + d.name + ' is shut down by regulators. Prices recover.', 'good', c0.id);
      m.dis = null;
      m.dcool = S.week + 52;
    }
    return;
  }
  if (S.week < 30 || (m.dcool && S.week < m.dcool) || bd.fam === 'fin' || bd.fam === 'energy') return;
  if (chance(0.0016 * (0.6 + cc.pl))) {
    const d = {
      w0: S.week,
      depth: rng(0.12, 0.32),
      dur: rint(40, 110),
      name: pick(['Budget', 'Quick', 'Smart', 'Value', 'Low Cost']) + ' ' + pick(['Group', 'Direct', 'Partners']),
      why: pick([
        'uses undeclared cheap labour',
        'dumps products below cost',
        'found a loophole in the licensing rules',
        'is backed by investors and burning cash',
        'skips costly safety routines'
      ])
    };
    m.dis = d;
    cos.forEach(co => addMsg({
      kind: 'info',
      from: 'Market',
      title: 'A cheap rival enters your market',
      body: d.name + ' ' + d.why + ' and sells far below normal prices in ' + cityOf(co.city).name + '. Expensive operations are hit hardest. You can cut costs, lower prices, or build quality and brand to keep loyal customers. If it drags on you can run out of cash.',
      co: co.id,
      tone: 'bad',
      status: 'done'
    }));
  }
}
function disMult(co) {
  const m = S.mk[mkKey(co)];
  if (!m || !m.dis) return 1;
  const cc = CO[co.country || S.country] || CC();
  const expo = clamp(0.45 + 0.6 * ((cc.pl || 1) - 0.5) + (co.price > 0 ? 0.08 * co.price : 0), 0.35, 1.3);
  const shield = clamp((co.q - 60) / 120, 0, 0.3) + clamp((co.rep - 60) / 200, 0, 0.12);
  return 1 - clamp(m.dis.depth * expo * (1 - shield), 0, 0.45);
}
function bankruptHint(co) {
  const m = S.mk[mkKey(co)];
  const hit = m && m.dis;
  const left = S.cash + (S.sav ? S.sav.bal : 0);
  addMsg({
    kind: 'info',
    from: 'Advisor',
    title: left > 150000 ? 'You can still start again' : 'You are in deep trouble',
    body: (hit ? 'A cheaper rival squeezed ' + co.name + ' out. ' : '') + (left > 150000 ? 'You still have ' + money(left) + '. Start smaller: a cheaper business with low fixed costs rebuilds cash faster than another big bet.' : 'You have almost nothing left. Any further loss may end the game. Take the cheapest business you can run yourself.'),
    tone: left > 150000 ? 'n' : 'bad',
    status: 'done'
  });
}

/* big companies attract foreign rivals. Nothing is listed: it just shows up in the market */
function foreignRival(m, cos, bd) {
  const c0 = cos[0];
  if (bd.fam === 'fin' || bd.fam === 'energy' || (m.fcount || 0) >= 2) return;
  if (m.fcool && S.week < m.fcool) return;
  const big = Math.max.apply(null, cos.map(c => chainOutlets(c))) >= 8 || cos.some(c => c.lastW && c.lastW.rev * 52 > (bd.Dc || 1) * bd.ticket * 52 * cityOf(c.city).dem * 1.6);
  if (!big || !chance(0.0012)) return;
  const home = c0.country || S.country;
  const opts = CO_ORDER.filter(k => k !== home && legalStatus(c0.type, k).ok && (CO[k].mkt >= 0.9 || CO[k].pl <= 0.7));
  if (!opts.length) return;
  const k = pick(opts);
  m.fcount = (m.fcount || 0) + 1;
  m.fcool = S.week + 80;
  if (m.n < 10) m.n++;
  m.str = Math.min(1, m.str + 0.12);
  m.pi = Math.max(0.8, m.pi - 0.02);
  cos.forEach(c => note('A ' + CO[k].name + ' chain has noticed your success and opens ' + (bd.n.toLowerCase().indexOf('shop') < 0 ? 'an outlet' : 'a shop') + ' in ' + cityOf(c.city).name + '.', 'n', c.id));
  news('A ' + CO[k].name + ' ' + bd.n.toLowerCase() + ' brand expands into ' + (CO[home] ? CO[home].name : 'the market') + '.', 'n');
}


/* ---- src/suppliers/vendors.js ---- */
/* ===== Suppliers: named vendors (brands) with owners, relationship words, discounts, board agreements ===== */
const REL_WORDS = [
  [8, 'Stranger'],
  [22, 'Acquaintance'],
  [36, 'Familiar'],
  [50, 'Friendly'],
  [64, 'Close'],
  [78, 'Good friend'],
  [92, 'Close friend'],
  [101, 'Best friend']
];
const REL_DISC = [0, 0, 0.01, 0.03, 0.05, 0.08, 0.12, 0.17];
function relIdx(r) {
  for (let i = 0; i < REL_WORDS.length; i++) if (r < REL_WORDS[i][0]) return i;
  return 7;
}
function relWord(r) {
  return REL_WORDS[relIdx(r)][1];
}
function relDisc(r) {
  return REL_DISC[relIdx(r)];
}
const CLASS_N = ['Basic', 'Standard', 'Premium'];
const GOODS_CLS = [{ c: 0.9, q: -3 }, { c: 1, q: 0 }, { c: 1.12, q: 2.5 }];
const _vend = {};
function vendors() {
  const k = S.seed;
  if (_vend[k]) return _vend[k];
  const R = hrng(k + ':vend');
  const F = [
    'Thord',
    'Ingrid',
    'Kasper',
    'Mina',
    'Odd',
    'Sigrun',
    'Jonas',
    'Elin',
    'Rune',
    'Tora',
    'Henrik',
    'Live',
    'Arne',
    'Silje',
    'Dag',
    'Maja'
  ];
  const Ln = ['Halvorsen', 'Berg', 'Lund', 'Moen', 'Dahl', 'Strand', 'Aas', 'Holm', 'Vik', 'Nygaard', 'Solheim', 'Brekke'];
  const L = [], used = {};
  while (L.length < 16) {
    let b = BR_A[Math.floor(R() * BR_A.length)] + BR_B[Math.floor(R() * BR_B.length)];
    b = b[0].toUpperCase() + b.slice(1);
    if (used[b]) continue;
    used[b] = 1;
    L.push({
      id: 'v' + L.length,
      name: b,
      owner: F[Math.floor(R() * F.length)] + ' ' + Ln[Math.floor(R() * Ln.length)],
      q: Math.round((R() - 0.5) * 70) / 100
    });
  }
  return _vend[k] = L;
}
const FAM_NOUN = {
  svc: ['Supplies', 'Systems', 'Tools', 'Services'],
  venue: ['Foods', 'Wholesale', 'Beverages', 'Catering Supply'],
  retail: ['Wholesale', 'Trading', 'Distribution', 'Imports'],
  prod: ['Materials', 'Components', 'Industries', 'Works'],
  logi: ['Fleet', 'Motors', 'Vehicles', 'Trucks'],
  project: ['Building Supply', 'Tools', 'Materials', 'Machinery'],
  rent: ['Supplies', 'Maintenance', 'Systems'],
  fin: ['Systems', 'Software', 'Services'],
  energy: ['Energy Systems', 'Technology', 'Components'],
  club: ['Sports', 'Equipment', 'Supplies']
};
const _vpool = {};
const FAMS = Object.keys(FAM_NOUN);
const GEN_NOUN = ['Group', 'Trading', 'Supply Group', 'Holding', 'Partners'];
/* one pool of supplier companies per country. A company can supply several kinds of business, and it is the same company, owner and relationship everywhere */
function vpoolAll(cc) {
  const key = S.seed + ':' + cc;
  if (_vpool[key]) return _vpool[key];
  const R = hrng(key + ':vpa');
  const C = CO[cc] || CC();
  const L = [], used = {};
  let g = 0;
  while (L.length < 60 && g++ < 600) {
    const i = L.length;
    const fams = [FAMS[i % FAMS.length]];
    if (R() < 0.4) {
      const x = FAMS[Math.floor(R() * FAMS.length)];
      if (fams.indexOf(x) < 0) fams.push(x);
    }
    if (R() < 0.15) {
      const x = FAMS[Math.floor(R() * FAMS.length)];
      if (fams.indexOf(x) < 0) fams.push(x);
    }
    const nouns = fams.length > 1 ? GEN_NOUN : (FAM_NOUN[fams[0]] || GEN_NOUN);
    const b = C.nameA[Math.floor(R() * C.nameA.length)] + ' ' + nouns[Math.floor(R() * nouns.length)];
    if (used[b]) continue;
    used[b] = 1;
    L.push({
      id: 'V-' + cc + '-' + i,
      name: b,
      owner: C.first[Math.floor(R() * C.first.length)] + ' ' + C.last[Math.floor(R() * C.last.length)],
      q: Math.round((R() - 0.5) * 70) / 100,
      cc,
      fams
    });
  }
  return _vpool[key] = L;
}
/* older saves used one pool per kind of business */
function vpool(cc, fam) {
  const key = S.seed + ':' + cc + ':' + fam;
  if (_vpool[key]) return _vpool[key];
  const R = hrng(key + ':vp');
  const C = CO[cc] || CC();
  const nouns = FAM_NOUN[fam] || FAM_NOUN.svc;
  const L = [], used = {};
  let g = 0;
  while (L.length < 12 && g++ < 200) {
    const b = C.nameA[Math.floor(R() * C.nameA.length)] + ' ' + nouns[Math.floor(R() * nouns.length)];
    if (used[b]) continue;
    used[b] = 1;
    L.push({
      id: 'V-' + cc + '-' + fam + '-' + L.length,
      name: b,
      owner: C.first[Math.floor(R() * C.first.length)] + ' ' + C.last[Math.floor(R() * C.last.length)],
      q: Math.round((R() - 0.5) * 70) / 100,
      cc,
      fam,
      fams: [fam]
    });
  }
  return _vpool[key] = L;
}
function famOfKey(key) {
  const p = String(key).split(':');
  const t = (p[0] === 'goods' || p[0] === 'fix') ? p[1] : p[0];
  return BD[t] ? BD[t].fam : 'svc';
}
function vendById(id) {
  if (!id) return null;
  if (id.indexOf('V-') === 0) {
    const p = id.split('-');
    if (p.length === 3) return vpoolAll(p[1])[+p[2]] || null;
    const l = vpool(p[1], p[2]);
    return l[+p[3]] || null;
  }
  return vendors().find(v => v.id === id) || null;
}
function vendorsFor(key, n, cc) {
  cc = cc || CC().code || S.country;
  const fam = famOfKey(key);
  const all = vpoolAll(cc).filter(v => v.fams.indexOf(fam) >= 0);
  const R = hrng(S.seed + ':vf:' + cc + ':' + key);
  return all.map((v, i) => [R(), i]).sort((a, b) => a[0] - b[0]).slice(0, n).map(x => all[x[1]]);
}
function knownVendors() {
  return Object.keys(S.vr || {}).map(vendById).filter(Boolean);
}
function brandN(co) {
  const m = co && S.mk ? S.mk[mkKey(co)] : null;
  const n = m ? m.n : 0;
  return 3 + (n >= 6 ? 1 : 0) + (n >= 12 ? 1 : 0);
}
function vrel(id) {
  return S.vr && S.vr[id] ? S.vr[id].r : 0;
}
function vbump(id, d) {
  S.vr = S.vr || {};
  const o = S.vr[id] || (S.vr[id] = { r: 0, w: S.week, meet: -99 });
  o.r = Math.min(100, o.r + d * (1 - Math.pow(o.r / 100, 1.6)) * (hasHQ('proc') ? 1.4 : 1));
  o.w = S.week;
}
function vbuy(id, amt, big) {
  if (!id || !(amt > 0)) return;
  vbump(id, big ? Math.min(3.5, Math.max(0.3, amt / 120000)) : Math.min(0.15, Math.max(0.01, Math.sqrt(amt) / 4000)));
}
function vmeet(id) {
  S.vr = S.vr || {};
  const o = S.vr[id] || (S.vr[id] = { r: 0, w: S.week, meet: -99 });
  if (S.week - o.meet < 4) return 'wait';
  const c = KC(5000, S.country);
  if (S.cash < c) return 'cash';
  payMe(c, 'Lunch with ' + vendById(id).owner + ' of ' + vendById(id).name);
  o.meet = S.week;
  vbump(id, rint(5, 9));
  return 'ok';
}
function vendMonth() {
  if (!S.vr) return;
  for (const id in S.vr) {
    const o = S.vr[id];
    if (S.week - o.w > 10) o.r = Math.max(0, o.r - 0.8);
  }
}
function vdisc(scope, id) {
  if (!id) return 0;
  return relDisc(vrel(id)) + (S.agree && S.agree[scope] === id ? 0.03 : 0);
}
/* the person who buys: a manager with a poor eye does not always find the best deal */
function buyerSkill(co) {
  return hasHQ('proc') ? 1 : co && co.mgr ? mgrQual(co) : 0.4;
}
function goodsPick(co) {
  const s = co.src || {};
  const list = vendorsFor('goods:' + co.type, brandN(co), co.country);
  if (s.v && s.v !== 'auto') return vendById(s.v);
  if (S.agree && S.agree.goods) return vendById(S.agree.goods);
  const ac = co.srcAuto;
  if (ac && S.week - ac.w < 26) {
    const v = vendById(ac.v);
    if (v) return v;
  }
  const best = list.slice().sort((a, b) => (vdisc('goods', b.id) - b.q * 0.06) - (vdisc('goods', a.id) - a.q * 0.06))[0];
  const v = chance(buyerSkill(co)) ? best : list[Math.floor(rng(0, list.length))];
  co.srcAuto = { v: v.id, w: S.week };
  return v;
}
function hasGoods(co) {
  const bd = BD[co.type];
  return !!bd && !(bd.cogs < 0.03 || ['fin', 'energy', 'rent', 'club', 'svc'].indexOf(bd.fam) >= 0 || /^(engcons|event)/.test(co.type));
}
function goodsEff(co) {
  const bd = BD[co.type];
  if (!bd || bd.cogs < 0.03 || ['fin', 'energy', 'rent', 'club', 'svc'].indexOf(bd.fam) >= 0 || /^(engcons|event)/.test(co.type)) return { m: 1, q: 0, v: null };
  const v = goodsPick(co), cl = GOODS_CLS[(co.src && co.src.c != null) ? co.src.c : 1];
  if (!v) return { m: cl.c, q: cl.q, v: null };
  return { m: clamp(cl.c * (1 + v.q * 0.3) * (1 - vdisc('goods', v.id)), 0.7, 1.4), q: cl.q + v.q * 10, v };
}
function fixPick(co) {
  const list = vendorsFor('fix:' + co.type, brandN(co), co.country);
  if (co.fixv && co.fixv !== 'auto') return vendById(co.fixv);
  if (S.agree && S.agree.fix) return vendById(S.agree.fix);
  return null;
}
function fixDisc(co) {
  const v = fixPick(co);
  return v ? vdisc('fix', v.id) : 0;
}
/* equipment catalogue: brands x three classes */
function eqCat(bdId, eqId, nb, cc) {
  cc = cc || CC().code || S.country;
  nb = nb || 3;
  const key = S.seed + ':' + cc + ':' + bdId + ':' + eqId + ':' + nb;
  if (_catMemo[key]) return _catMemo[key];
  const R = hrng(key);
  const list = [];
  const vs = vendorsFor(bdId + ':' + eqId, nb, cc);
  const base = [0.68, 1.0, 1.36];
  const eqd = (BD[bdId] && BD[bdId].eq.find(x => x.id === eqId)) || null;
  const mcat = eqMakerCat(eqd ? eqd.n : '', bdId);
  const usedM = {};
  vs.forEach((v, b) => {
    const bf = 0.94 + R() * 0.12;
    for (let c = 0; c < 3; c++) {
      let rating = 3.0 + c * 0.65 + v.q + (R() - 0.5) * 0.5;
      rating = Math.round(clamp(rating, 2.5, 4.9) * 10) / 10;
      const model = MD_A[Math.floor(R() * MD_A.length)] + ' ' + (['S', 'X', 'K', 'M', 'R'][Math.floor(R() * 5)]) + (c + 1) + '0' + (Math.floor(R() * 9));
      list.push({
        i: b * 3 + c,
        vid: v.id,
        seller: v.name,
        brand: makerName(mcat, cc, R, usedM),
        model,
        tier: CLASS_N[c],
        cls: c,
        cm: eqComment(rating),
        f: Math.round(base[c] * bf * 100) / 100,
        rating,
        reviews: Math.round(30 + R() * R() * 1800),
        perf: Math.round((0.88 + 0.0957 * (rating - 2.6)) * 1000) / 1000,
        rel: Math.round((1.4 - 0.3 * (rating - 2.6)) * 100) / 100
      });
    }
  });
  return _catMemo[key] = list;
}
function eqDefault(bdId, eqId) {
  return eqCat(bdId, eqId, 3)[1];
}
/* what a manager picks when he buys by himself */
function mgrCat(co, eqId) {
  const nb = brandN(co);
  const cat = eqCat(co.type, eqId, nb, co.country);
  const stdc = cat.filter(c => c.cls === 1);
  if (S.agree && S.agree.eq) {
    const a = stdc.find(c => c.vid === S.agree.eq);
    if (a) return a;
  }
  const net = c => c.f * (1 - vdisc('eq', c.vid)) / c.perf;
  const best = stdc.slice().sort((a, b) => net(a) - net(b))[0];
  return chance(buyerSkill(co)) ? best : stdc[Math.floor(rng(0, stdc.length))];
}
function boardDeal(scope, vid) {
  if (liveCos().length < 2) return 'few';
  const c = KC(9000, S.country);
  if (S.cash < c) return 'cash';
  payMe(c, 'Board meeting and dinner');
  S.agree = S.agree || {};
  S.agree[scope] = vid || null;
  if (vid) vbump(vid, 2);
  return 'ok';
}
function pword(x) {
  return x < 0.88 ? 'Far below average' : x < 0.96 ? 'Below average' : x <= 1.04 ? 'Average' : x <= 1.12 ? 'Above average' : 'Far above average';
}

/* five premises on offer: size, rent and location quality differ */
const PL_TIERS_B = [
  'Far out of town',
  'On the outskirts',
  'Standard commercial area',
  'Close to the city centre',
  'Central location'
];
const PL_TIERS = [
  ['Back street unit', 0.7, 0.75, 0.93],
  ['Small neighbourhood unit', 0.9, 0.9, 0.98],
  ['Standard commercial unit', 1.0, 1.0, 1.0],
  ['Good high-street unit', 1.15, 1.25, 1.06],
  ['Prime central location', 1.3, 1.7, 1.13]
];
const PL_WORDS = ['Properties', 'Estates', 'Commercial', 'Real Estate', 'Holdings', 'Property Group'];
function premListings(co) {
  if (window.R37 && R37.homeListings && R37.homeTrade(co)) return R37.homeListings(co); /* a trade that started at home looks for a workshop or office of its size */
  const bd = BD[co.type];
  const key = S.seed + ':pl:' + co.type + ':' + co.city + ':' + Math.floor(S.week / 26);
  if (_catMemo[key]) return _catMemo[key];
  const R = hrng(key);
  const C = CO[co.country || S.country] || CC();
  const rec = Math.max(10, Math.round(bd.prem[1] * (co.size || 1)));
  const L = PL_TIERS.map((t, i) => {
    const m2 = Math.max(10, Math.round(rec * t[1] * (0.92 + R() * 0.16) / 5) * 5);
    return {
      i,
      n: isFoot(co.prem ? co.prem.kind : bd.prem[0]) ? t[0] : PL_TIERS_B[i],
      m2,
      rentF: t[2] * (0.94 + R() * 0.12),
      loc: t[3],
      landlord: C.nameA[Math.floor(R() * C.nameA.length)] + ' ' + PL_WORDS[Math.floor(R() * PL_WORDS.length)]
    };
  });
  _catMemo[key] = L;
  return L;
}


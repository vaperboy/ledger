/* ---- src/suppliers/makers.js ---- */
/* ===== equipment and vehicle makers: invented, real-sounding, flavoured by country ===== */
const MK = {
  pay:     {
    s: ['Pay', 'Term', 'Tap', 'Cash', 'Vero', 'Kasse', 'Swipe', 'Merit'],
    x: ['Payment Systems', 'Terminals', 'Retail Systems', 'Solutions', 'Pay'],
    o: ['SE', 'NL', 'US', 'KR', 'DE', 'UK']
  },
  it:      {
    s: ['Nex', 'Tek', 'Core', 'Volt', 'Pixel', 'Logic', 'Byte', 'Omni'],
    x: ['Computers', 'Electronics', 'Digital', 'Devices', 'Technologies'],
    o: ['US', 'KR', 'JP', 'DE', 'NL', 'UK']
  },
  soft:    {
    s: ['Cloud', 'Flow', 'Data', 'Logi', 'Sync', 'Insight', 'Nimbus', 'Craft'],
    x: ['Software', 'Systems', 'Labs', 'Digital', 'Cloud'],
    o: ['US', 'UK', 'NL', 'SE', 'DE', 'CA']
  },
  photo:   {
    s: ['Lumen', 'Optic', 'Focus', 'Vista', 'Aperture', 'Shutter', 'Clear', 'Frame'],
    x: ['Optics', 'Imaging', 'Camera Works', 'Photonics', 'Visual'],
    o: ['JP', 'DE', 'KR', 'US', 'SE']
  },
  secur:   {
    s: ['Guard', 'Sentry', 'Vigil', 'Aegis', 'Watch', 'Safe', 'Argus', 'Shield'],
    x: ['Security', 'Surveillance', 'Protection Systems', 'Safety Technology', 'Alarm'],
    o: ['SE', 'DE', 'JP', 'US', 'UK', 'NL']
  },
  food:    {
    s: ['Gastro', 'Cook', 'Therm', 'Chef', 'Fornax', 'Brew', 'Kitchen', 'Savor'],
    x: ['Kitchen Systems', 'Foodservice Equipment', 'Catering Technology', 'Gastro', 'Professional Kitchens'],
    o: ['DE', 'FR', 'ES', 'NL', 'JP', 'US']
  },
  refrig:  {
    s: ['Frost', 'Cryo', 'Polar', 'Glacier', 'Kühl', 'Chill', 'Nordic', 'Arctic'],
    x: ['Refrigeration', 'Cooling Systems', 'Cold Chain', 'Cooling', 'Climate Technology'],
    o: ['DE', 'ES', 'NL', 'JP', 'US', 'NO']
  },
  furn:    {
    s: ['Form', 'Nest', 'Oak', 'Atelier', 'Studio', 'Habit', 'Linea', 'Haven'],
    x: ['Furniture', 'Interiors', 'Contract Furniture', 'Fit-out', 'Design'],
    o: ['SE', 'NO', 'PL', 'DE', 'ES', 'NL']
  },
  tools:   {
    s: ['Forge', 'Torque', 'Grip', 'Bolt', 'Anvil', 'Drive', 'Strike', 'Precise'],
    x: ['Tools', 'Power Tools', 'Tool Works', 'Instruments', 'Hardware'],
    o: ['DE', 'SE', 'JP', 'US', 'PL', 'KR']
  },
  machine: {
    s: ['Mach', 'Titan', 'Kraft', 'Dyna', 'Prime', 'Hydro', 'Robo', 'Stahl'],
    x: ['Machinery', 'Industrial', 'Engineering', 'Machine Works', 'Automation'],
    o: ['DE', 'JP', 'SE', 'US', 'KR', 'PL']
  },
  clean:   {
    s: ['Pure', 'Spark', 'Aqua', 'Fresh', 'Rein', 'Sweep', 'Clean', 'Shine'],
    x: ['Cleaning Systems', 'Hygiene', 'Cleaning Machines', 'Care Products', 'Clean Technology'],
    o: ['DE', 'SE', 'US', 'NL', 'UK']
  },
  fit:     {
    s: ['Power', 'Iron', 'Flex', 'Motion', 'Stride', 'Peak', 'Vital', 'Athlete'],
    x: ['Fitness', 'Sports Equipment', 'Wellness', 'Training Systems', 'Active'],
    o: ['US', 'DE', 'UK', 'SE', 'KR']
  },
  med:     {
    s: ['Medi', 'Vita', 'Thera', 'Physio', 'Cura', 'Salus', 'Clinic', 'Pulse'],
    x: ['Medical', 'Healthcare', 'Therapy Systems', 'Clinical Equipment', 'Medtech'],
    o: ['DE', 'SE', 'US', 'JP', 'NL', 'KR']
  },
  av:      {
    s: ['Sonic', 'Lume', 'Arena', 'Echo', 'Vivid', 'Stage', 'Beam', 'Pulse'],
    x: ['Audio Visual', 'Entertainment Systems', 'Sound and Light', 'Stage Technology', 'Gaming Systems'],
    o: ['US', 'DE', 'UK', 'JP', 'NL', 'KR']
  },
  energy:  {
    s: ['Volt', 'Ampere', 'Terra', 'Wind', 'Helio', 'Grid', 'Watt', 'Fluxo'],
    x: ['Energy', 'Power Systems', 'Electric', 'Renewables', 'Energy Technology'],
    o: ['DE', 'ES', 'NO', 'US', 'SE', 'JP']
  },
  marine:  {
    s: ['Mar', 'Tide', 'Anchor', 'Hav', 'Wave', 'Aqua', 'Fjord', 'Keel'],
    x: ['Marine', 'Offshore', 'Marine Technology', 'Shipyard Supply', 'Aquaculture Systems'],
    o: ['NO', 'NL', 'DE', 'JP', 'KR', 'US']
  },
  serv:    {
    s: ['Terra', 'Deep', 'Bridge', 'Core', 'Summit', 'Strata', 'Harbour', 'Vector'],
    x: ['Services', 'Engineering Services', 'Contracting', 'Group', 'Solutions'],
    o: ['NO', 'US', 'UK', 'NL', 'BR', 'DE']
  },
  general: {
    s: ['Prime', 'Alpha', 'Nova', 'Delta', 'Meridian', 'Sterling', 'Union', 'Pioneer'],
    x: ['Industries', 'Group', 'Works', 'Supply', 'Manufacturing'],
    o: ['DE', 'US', 'SE', 'JP', 'UK', 'NL', 'PL']
  },
  auto:    {
    s: ['Veloce', 'Aero', 'Motiv', 'Terra', 'Strada', 'Vista', 'Nova', 'Kinetic'],
    x: ['Motors', 'Automotive', 'Auto', 'Motor Works', 'Mobility'],
    o: ['DE', 'FR', 'JP', 'KR', 'SE', 'US', 'ES', 'PL']
  },
  truck:   {
    s: ['Titan', 'Haul', 'Frakt', 'Road', 'Vector', 'Mack', 'Stahl', 'Atlas'],
    x: ['Trucks', 'Commercial Vehicles', 'Heavy Vehicles', 'Bus and Coach', 'Truck Works'],
    o: ['SE', 'DE', 'NL', 'JP', 'US', 'BR']
  },
  cycle:   {
    s: ['Pedal', 'Volt', 'Urban', 'Glide', 'Cargo', 'Swift', 'Zip', 'Roll'],
    x: ['Cycles', 'E-Mobility', 'Bikes', 'Mobility', 'Scooters'],
    o: ['NL', 'DE', 'JP', 'KR', 'ES', 'SE']
  },
  air:     {
    s: ['Aero', 'Sky', 'Altus', 'Cirrus', 'Vento', 'Zephyr', 'Stratos', 'Aviator'],
    x: ['Aerospace', 'Aircraft', 'Aviation', 'Aeronautics', 'Air Works'],
    o: ['FR', 'CA', 'BR', 'US', 'DE', 'ES']
  }
};
function eqMakerCat(name, bdId) {
  const n = (name || '').toLowerCase();
  const R = [
    [/pos\b|pos,|till|card terminal|self-checkout|payment|cage and chip|ticketing/, 'pay'],
    [/laptop|workstation|phone|screens|tablet|plotter|scanner|label/, 'it'],
    [
      /software|licen|cloud|platform|crm|erp|portal|integration|analytics|journal|booking|planning|ats\b|dms|scada|bim|case-management|claims|banking|system and|management system|monitoring and control|policy|dealer management|webshop|job and|data/,
      'soft'
    ],
    [/camera body|lens|drone|backdrops|photo|3d tour|studio/, 'photo'],
    [/cctv|surveillance|alarm|eas|tags|security|gates, cameras|cameras and climate|id scanners/, 'secur'],
    [/cold|freezer|chiller|fridge|cooler|refrigerat/, 'refrig'],
    [
      /kitchen|grill|fryer|oven|dishwash|espresso|grinder|coffee|brew|proofer|mixer|dough|glassware|bar |wine|fermentation|bottling|taproom|cold room|breakfast|bakery/,
      'food'
    ],
    [
      /furniture|chairs|desks|tables|interior|fit-out|shelving|racks|counter|lockers|display|mannequin|fixtures|beds|lobby|showroom|reception|vip|classroom|kennels|play zones|stations|basins|benches|barn|shed|hangar|archive|signs/,
      'furn'
    ],
    [/vacuum|scrub|laundry|pressure|steam|polisher|ceramic|dosing|uniform|cleaning/, 'clean'],
    [/shockwave|ultrasound|treatment|patient|rehab/, 'med'],
    [/cardio|strength|exercise|sauna|wellness|grooming/, 'fit'],
    [/sound|light|led|stage|truss|rigging|gaming|slot|attractions|arcade/, 'av'],
    [/turbine|substation|generator|ev charger|charging|diagnostics|gas system|wind/, 'energy'],
    [/boat|barge|sea pens|underwater|lice|moorings|navigation|port and crane/, 'marine'],
    [
      /contract|agreement|seismic|rig and|platform share|roads|site works|vault|branch|crew|flight|fleet|tachograph|yard/,
      'serv'
    ],
    [
      /tool|ladder|scaffold|formwork|pipe|drain|measuring|instrument|test|panel saw|finishing|lab\b|lift platform|power/,
      'tools'
    ],
    [
      /cnc|robot|forklift|crane|tractor|harvester|trailer|compressor|lifts|machining|lift and|dryer|sorting|automation/,
      'machine'
    ]
  ];
  for (const r of R) if (r[0].test(n)) return r[1];
  return 'general';
}
function vehMakerCat(m) {
  return /^(van|ev_van|pickup|car|taxi)/.test(m) ? 'auto' : /^(minibus|bus|truck)/.test(m) ? 'truck' : /^(bike|scooter)/.test(m) ? 'cycle' : /^(ship|ferry)/.test(m) ? 'marine' : /^plane/.test(m) ? 'air' : /^(excav|crane)/.test(m) ? 'machine' : /^foodtruck/.test(m) ? 'truck' : 'general';
}
/* one maker name: about 55% from the buyer's own country, the rest from countries known for that kind of product */
function makerName(cat, cc, R, used) {
  const M = MK[cat] || MK.general;
  let nm, g = 0;
  do {
    const home = R() < 0.55;
    const oc = home ? cc : M.o[Math.floor(R() * M.o.length)];
    const C = CO[oc] || CO[cc] || CC();
    const r = R();
    const sur = C.last[Math.floor(R() * C.last.length)];
    const stem = M.s[Math.floor(R() * M.s.length)];
    const suf = M.x[Math.floor(R() * M.x.length)];
    const a = C.nameA[Math.floor(R() * C.nameA.length)];
    nm = r < 0.3 ? sur + ' ' + suf : r < 0.55 ? a + ' ' + suf : r < 0.8 ? sur + ' ' + stem : sur + ' & ' + C.last[Math.floor(R() * C.last.length)] + ' ' + suf.split(' ')[0];
    nm = nm.replace(/\s+/g, ' ').trim();
  } while (used && used[nm] && g++ < 30);
  if (used) used[nm] = 1;
  return nm;
}


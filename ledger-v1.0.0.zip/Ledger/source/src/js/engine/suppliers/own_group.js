/* ---- src/suppliers/own_group.js ---- */
/* ===== Your own group companies as suppliers and service providers; sites instead of franchising for heavy industry ===== */
function canFranchise(type) {
  return fbOk(type);
}
function vehPlant(except) {
  return S.cos.find(c => c.type === 'factory' && c.st === 'open' && c.id !== (except && except.id) && (c.knob.line || 0) >= 1);
}
function plantLine(c) {
  return ['', 'cars', 'trucks', 'boats'][c.knob.line || 0];
}
function ownSupply(co) {
  if (co.type !== 'cardealer' || co.st !== 'open') return;
  const pl = vehPlant(co);
  if (!pl || !co.lastW || !co.lastW.rev) return;
  const rev = co.lastW.rev;
  rebate(co, Math.min(rev * 0.06, (co.lastW.cogs || 0) * 0.12));
  coIn(pl, rev * 0.04, 'rev', 'Wholesale to ' + co.name);
  co.aware = Math.max(co.aware, Math.min(reachOf(co).cap, pl.aware * 0.5));
}
/* your own accountant office, law firm or insurance company as a provider, with the same numbers the others are
   judged on: its star rating comes from its own reviews, its accuracy, record or payout from how good it is, and its
   fee or premium is the market's with a group discount. The fee or premium is paid to your own firm. */
function ownProv(kind, oc) {
  const r = typeof ratingOf === 'function' ? ratingOf(oc) : 3.8, q = ratQ(r);
  const p = { id: 'own' + oc.id, name: oc.name + ' (yours)', rating: r, reviews: Math.round(oc.rvN || (oc.units || 0) / 20) || null, q: 0.4 + q * 0.52, own: oc.id, w0: S.week };
  const w = (CO[oc.country] || CC()).wage || 1;
  if (kind === 'acc') { p.tier = ''; p.fee = rnl(1400 * (0.7 + q * 1.9) * w * 0.85, 100); p.err = Math.max(0.015, 0.14 - q * 0.12); }
  else if (kind === 'law') p.fee = rnl(3500 * (0.7 + q * 2.4) * w * 0.85, 100);
  else { p.premM = Math.round((0.82 + q * 0.35 - 0.08) * 100) / 100; p.payM = Math.round((0.7 + q * 0.29) * 100) / 100; p.fee = 0; }
  return p;
}
function pickOwn(co, kind, oc) {
  const p = ownProv(kind, oc);
  if (kind === 'acc') {
    co.acc = { id: p.id, name: p.name, tier: p.tier, fee: p.fee, q: p.q, err: p.err, rating: p.rating, own: oc.id, w0: S.week };
    if (co.docs.acctr) co.docs.acctr = { st: 'ok', done: S.week, ok: S.week }; else co.docs.acctr = { st: 'applied', done: S.week + 1, w0: S.week };
  }
  else if (kind === 'law') co.law = { id: p.id, name: p.name, fee: p.fee, q: p.q, rating: p.rating, own: oc.id, w0: S.week };
  else co.insr = { id: p.id, name: p.name, premM: p.premM, payM: p.payM, rating: p.rating, own: oc.id };
}
function ownFirms(co, kind) {
  return S.cos.filter(c => c.type === ({ law: 'law', acc: 'acctfirm' }[kind] || 'insco') && c.st === 'open' && c.id !== co.id);
}


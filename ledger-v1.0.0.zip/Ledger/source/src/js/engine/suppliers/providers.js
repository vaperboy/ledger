/* ---- src/suppliers/providers.js ---- */
/* ===== Providers (accountants, law firms, insurers) and the equipment catalogue, all with star ratings ===== */
function provName(kind) {
  const w = PROVW[CC().code] || [['Accounting', 'Accountants', 'Audit'], 'Law', 'Insurance', ' Ltd'];
  const stems = CC().last;
  const a = pick(stems), b = pick(stems.filter(x => x !== a));
  return kind === 'law' ? a + ' & ' + b + ' ' + w[1] : kind === 'ins' ? a + ' ' + w[2] : a + ' ' + pick(w[0]) + w[3];
}
function genRating() {
  return Math.round(clamp(3.9 + gauss() * 0.62, 2.6, 4.9) * 10) / 10;
}
function ratQ(r) {
  return clamp((r - 2.6) / 2.3, 0, 1);
}
function genProviders(kind, n) {
  const out = [];
  for (let i = 0; i < n; i++) {
    const r = genRating(), q = ratQ(r);
    const rev = Math.round(12 + Math.pow(rng(0, 1), 2) * 1400);
    const p = { id: uid(), name: provName(kind), rating: r, reviews: rev, q: 0.4 + q * 0.52 };
    if (kind === 'acc') {
      p.tier = '';
      p.fee = rnd(1400 * (0.7 + q * 1.9) * rng(0.85, 1.2), 100);
      p.err = Math.max(0.015, 0.14 - q * 0.12);
    }
    else if (kind === 'law') {
      p.fee = rnd(3500 * (0.7 + q * 2.4) * rng(0.85, 1.2), 100);
    }
    else {
      p.premM = Math.round((0.82 + q * 0.35 + rng(-0.06, 0.08)) * 100) / 100;
      p.payM = Math.round((0.7 + q * 0.29) * 100) / 100;
      p.fee = 0;
    }
    out.push(p);
  }
  return out.sort((a, b) => b.rating - a.rating);
}
function genAccountants() {
  return genProviders('acc', 6);
}
function poolFor(code) {
  code = code || S.country;
  S.poolc = S.poolc || {};
  if (!S.poolc[code]) {
    const prev = CTXCO;
    setCtx({ country: code });
    const w = CO[code].wage || 1;
    const p = { acc: genAccountants(), law: genProviders('law', 6), ins: genProviders('ins', 6) };
    setCtx(prev);
    p.acc.forEach(a => {
      if (a.fee) a.fee = rnl(a.fee * w, 100);
    });
    p.law.forEach(a => {
      if (a.fee) a.fee = rnl(a.fee * w, 100);
    });
    S.poolc[code] = p;
  }
  return S.poolc[code];
}
function initPool() {
  S.poolc = {};
  const p = poolFor(S.country);
  S.pool.acc = p.acc;
  S.pool.law = p.law;
  S.pool.ins = p.ins;
}
function pickLaw(co, id) {
  const a = (poolFor(co.country).law || []).find(x => x.id === id);
  if (!a) return false;
  co.law = { id: a.id, name: a.name, fee: a.fee, q: a.q, rating: a.rating, w0: S.week };
  return true;
}
function pickInsurer(co, id) {
  const a = (poolFor(co.country).ins || []).find(x => x.id === id);
  if (!a) return false;
  co.insr = { id: a.id, name: a.name, premM: a.premM, payM: a.payM, rating: a.rating };
  return true;
}
function insrMult(co) {
  return co.insr ? co.insr.premM : 1;
}
function insrPay(co) {
  return co.insr ? co.insr.payM : 0.93;
}
function lawWeek(co) {
  if (co.law) {
    const f = co.law.fee * 12 / 52 * (hasHQ('law') ? 0.85 : 1);
    payCo(co, f, 'oth', null);
    if (co.law.own) {
      const o = getCo(co.law.own);
      if (o && o.st === 'open') coIn(o, f, 'rev', 'Legal fees from ' + co.name);
    }
  }
}
/* deterministic fake brands and models for every piece of equipment */
function hrng(str) {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return function () {
    h = (h + 0x6D2B79F5) | 0;
    let t = Math.imul(h ^ (h >>> 15), 1 | h);
    t ^= t + Math.imul(t ^ (t >>> 7), 61 | t);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const BR_A = [
  'Nor',
  'Kjel',
  'Fjord',
  'Halde',
  'Vest',
  'Bryn',
  'Strand',
  'Tind',
  'Skog',
  'Lofot',
  'Rauma',
  'Sol',
  'Brev',
  'Stav',
  'Mjøs',
  'Sunn',
  'Ask',
  'Eik',
  'Ulv',
  'Hav'
];
const BR_B = ['tek', 'mark', 'vik', 'line', 'tronic', 'werk', 'dal', 'pro', 'tech', 'hus', 'mek', 'star', 'lab', 'ro'];
const MD_A = ['Classic', 'Pro', 'Compact', 'Max', 'Core', 'Prime', 'Flex', 'One', 'Edge', 'Lite', 'Ultra', 'Smart'];
const CAT_TIER = [['Value', 0.62], ['Standard', 0.85], ['Plus', 1.0], ['Premium', 1.3], ['Pro', 1.65]];
const _catMemo = {};
function vehCat(modelId, cc) {
  cc = cc || fbCCode();
  const key = S.seed + ':veh:' + cc + ':' + modelId;
  if (_catMemo[key]) return _catMemo[key];
  const R = hrng(key);
  const list = [];
  const used = {};
  for (let i = 0; i < 2; i++) {
    const brand = makerName(vehMakerCat(modelId), cc, R, used);
    const rating = Math.round(clamp(3.6 + (R() - 0.35) * 1.5 + i * 0.1, 2.7, 4.9) * 10) / 10;
    list.push({
      i,
      brand,
      model: ['Trek', 'Nova', 'Vista', 'Rapid', 'Terra'][Math.floor(R() * 5)] + ' ' + (Math.floor(R() * 8) + 2) + '00',
      f: Math.round((0.92 + R() * 0.2 + (rating - 3.6) * 0.08) * 100) / 100,
      rating,
      reviews: Math.round(40 + R() * R() * 1500),
      rel: Math.round((1.4 - 0.3 * (rating - 2.6)) * 100) / 100
    });
  }
  return _catMemo[key] = list;
}


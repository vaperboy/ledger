/* ---- src/company/sales_insurance.js ---- */
/* ===== Sales pay models and insurance products ===== */
const SALES_ROLES = { sales: 1, cardealer: 1, estate: 1, agent: 1, broker: 1 };
const PAY_M = { fix: 'Fixed salary', mix: 'Lower salary + bonus', com: 'Commission only' };
function effW(s) {
  return s.wage + (s.pay && s.pay.m !== 'fix' ? (s.commEma || 0) * 52 / 12 : 0);
}
function commEstimate(co) {
  const rev = (co.lastW && co.lastW.rev) || avgWk(co);
  const n = Math.max(1, co.staff.filter(s => SALES_ROLES[s.role]).length + 1);
  return rev / n * 52 / 12;
}
/* commissionWeek: defined in features/sales/daily_sales.js (commission on each seller's own sales) */
function setPay(co, sid, m, rate) {
  const s = co.staff.find(x => x.id === sid);
  if (!s) return;
  const n = S.npcs[sid];
  const mk = rnl((wageFor(s.role, co) * (s.pt || 1)) * (0.7 + n.skill / 160), 100);
  if (m === 'fix') s.wage = Math.max(s.wage, rnl(mk * 0.95, 100)); else if (m === 'mix') s.wage = rnl(mk * 0.6, 100); else s.wage = 0;
  s.pay = { m, rate: m === 'fix' ? 0 : rate };
  s.commEma = 0;
}
/* insurance products */
const INS_PRODS = {
  life: ['Life insurance', { vol: 0.5, prem: 1.5, lr: 0.55, doc: 'ins_life', ver: 9000 }],
  skade: ['Property and casualty', { vol: 0.9, prem: 1.0, lr: 1.0, doc: 'ins_skade', ver: 5000 }],
  bil: ['Car insurance', { vol: 1.0, prem: 0.9, lr: 1.05, doc: 'ins_bil', ver: 4000 }],
  hjem: ['Home and contents', { vol: 0.9, prem: 0.8, lr: 0.8, doc: 'ins_hjem', ver: 4000 }],
  reise: ['Travel insurance', { vol: 0.4, prem: 0.25, lr: 0.7, doc: 'ins_reise', ver: 2500 }],
  naring: ['Business insurance', { vol: 0.7, prem: 2.2, lr: 1.15, doc: 'ins_naring', ver: 8000 }]
};
DOCS.ins_life = [
  'Product approval: life insurance',
  '{auth:fin}',
  180000,
  12,
  25000,
  'Needs extra capital and actuarial sign-off.'
];
DOCS.ins_skade = [
  'Product approval: property and casualty',
  '{auth:fin}',
  120000,
  10,
  15000,
  'Terms and reinsurance must be documented.'
];
DOCS.ins_bil = [
  'Product approval: car insurance',
  '{auth:fin}',
  90000,
  8,
  12000,
  'Includes the traffic-injury scheme membership.'
];
DOCS.ins_hjem = ['Product approval: home insurance', '{auth:fin}', 80000, 8, 10000, 'Standard terms and claims routines.'];
DOCS.ins_reise = ['Product approval: travel insurance', '{auth:fin}', 40000, 4, 5000, 'Needs an assistance partner.'];
DOCS.ins_naring = [
  'Product approval: business insurance',
  '{auth:fin}',
  150000,
  10,
  20000,
  'Needs commercial underwriting rules.'
];
function prodOn(co, k) {
  return !!(co.fm && co.fm.prods && co.fm.prods[k]);
}
function prodActive(co, k) {
  return prodOn(co, k) && docOk(co, INS_PRODS[k][1].doc);
}
function verOk(s, k) {
  return !!(s.ver && s.ver[k] && s.ver[k].done <= S.week);
}
function verAgents(co, k) {
  let t = 0;
  co.staff.forEach(s => {
    if (s.role === 'agent' && verOk(s, k)) t += 0.92 * (0.75 + 0.5 * staffSkill(s) / 100);
  });
  return t;
}
function setProd(co, k, on) {
  co.fm.prods = co.fm.prods || {};
  if (on) {
    co.fm.prods[k] = 1;
    const r = applyDoc(co, INS_PRODS[k][1].doc);
    return r === 'cash' ? (delete co.fm.prods[k], 'cash') : 'ok';
  }
  delete co.fm.prods[k];
  return 'ok';
}
function verifyAgent(co, sid, k) {
  const s = co.staff.find(x => x.id === sid);
  if (!s) return 'bad';
  const c = INS_PRODS[k][1].ver;
  if (co.cash < c) return 'cash';
  payCo(co, c, 'oth', 'Verification: ' + INS_PRODS[k][0]);
  s.ver = s.ver || {};
  s.ver[k] = { done: S.week + rint(2, 4) };
  return 'ok';
}
function autoIns(co) {
  ['bil', 'hjem', 'skade'].forEach(k => {
    setProd(co, k, true);
  });
  co.staff.forEach(s => {
    if (s.role === 'agent') ['bil', 'hjem', 'skade'].forEach(k => {
      if (!s.ver || !s.ver[k]) verifyAgent(co, s.id, k);
    });
  });
}
FAM.fin.checklist = function (co, bd, items) {
  if (!bd.tw.ins) return;
  const any = Object.keys(INS_PRODS).some(k => prodOn(co, k));
  items.push({ k: 'prod', t: 'Choose at least one insurance product', ok: any, sub: any ? '' : 'See Operations' });
  items.push({
    k: 'ver',
    t: 'At least one verified salesperson',
    ok: Object.keys(INS_PRODS).some(k => prodOn(co, k) && verAgents(co, k) > 0),
    sub: 'Each salesperson is verified per product'
  });
};


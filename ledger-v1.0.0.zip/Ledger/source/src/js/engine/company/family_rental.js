/* ---- src/company/family_rental.js ---- */
/* ===== Rental property: portfolio of properties with tenants, vacancy and valuation ===== */
function propListings(co) {
  const bd = BD[co.type], tw = bd.tw, city = cityOf(co.city);
  const seedKey = (S.week >> 2) * 131 + co.id;
  const out = [];
  const save = S.rs;
  S.rs = (seedKey * 2654435761) | 0;
  [0.35, 0.6, 1, 1.7].forEach((f, i) => {
    const units = Math.max(2, Math.round(tw.units * f * rng(0.85, 1.2)));
    const per = rnl(tw.price * Math.pow(city.rent, 0.8) * S.econ.housing * rng(0.9, 1.12), 1000);
    const rentU = Math.round((tw.kind === 'com' ? 1.8 : 1.3) * bd.ticket * Math.pow(city.rent, 0.8) * rng(0.9, 1.1) * Math.pow(1 + S.econ.infl, S.week / 52));
    out.push({
      i,
      name: (tw.kind === 'res' ? 'Block of ' + units + ' flats' : tw.kind === 'com' ? units + ' m2 ' + pick(['office floor', 'retail parade', 'logistics hall', 'mixed building']) : units + ' ' + pick(['parking spaces', 'storage units', 'spaces in a car park'])) + ', ' + city.name,
      units,
      per,
      price: per * units,
      rentU,
      cond: rng(0.55, 0.95),
      yieldG: rentU * 52 / per
    });
  });
  S.rs = save;
  return out;
}
function buyProp(co, L, ltv, reserve) {
  const bd = BD[co.type];
  const price = L.price, fee = price * 0.025;
  const loan = rnl(price * ltv, 1000);
  const down = price - loan + fee;
  if (co.cash < down + (reserve || 0)) return 'cash';
  if (loan > 0) {
    const off = loanOffer('biz', loan, co);
    const bank = off.max + (coEbit12(co) > 0 ? 0 : 0);
    if (loan > Math.max(off.max, price * 0.25 * 0 + 0) && loan > price * 0.6 + 1) return 'loan';
    const l = {
      id: uid(),
      kind: 'biz',
      name: 'Property mortgage',
      bal: loan,
      margin: Math.max(0.012, creditMargin() * 0.45) + 0.003,
      pay: 0,
      termM: 240,
      co: co.id,
      w0: S.week,
      guar: co.form === 'ENK' ? 1 : 1
    };
    l.pay = annuity(loan, policy() + l.margin, 240);
    S.loans.push(l);
    moveCash(co, loan);
    L.loan = l.id;
  }
  payCo(co, price, null, 'Property purchase');
  payCo(co, fee, 'oth', 'Stamp duty and fees');
  co.props = co.props || [];
  co.props.push({
    id: uid(),
    name: L.name,
    units: L.units,
    kind: bd.tw.kind,
    cost: price,
    val: price,
    idx0: S.econ.housing,
    loan: L.loan || 0,
    rentU: L.rentU,
    vac: 0.18,
    cond: L.cond,
    city: co.city,
    w0: S.week
  });
  return 'ok';
}
function sellProp(co, pid) {
  const i = (co.props || []).findIndex(p => p.id === pid);
  if (i < 0) return 0;
  const p = co.props[i];
  const net = Math.round(p.val * 0.975);
  co.props.splice(i, 1);
  coIn(co, net, null, 'Property sold');
  if (p.loan) {
    const l = S.loans.find(x => x.id === p.loan);
    if (l) {
      const r = l.bal;
      moveCash(co, -(r));
      closeLoan(l, r);
    }
  }
  const gain = net - p.val;
  if (gain > 0) {
    bk(co, 'rev', gain);
  } else bk(co, 'loss', -gain);
  return net;
}
function renovateProp(co, pid) {
  const p = (co.props || []).find(x => x.id === pid);
  if (!p) return 'bad';
  const c = Math.round(p.units * (BD[co.type].tw.price * 0.02));
  if (co.cash < c) return 'cash';
  payCo(co, c, 'oth', 'Renovation');
  p.cond = Math.min(1, p.cond + 0.25);
  revalue(co, p.val * 0.015);
  p.val *= 1.015;
  return 'ok';
}
FAM.rent = {
  custom(co, bd, ctx) {
    const tw = bd.tw;
    co.props = co.props || [];
    const city = cityOf(co.city);
    let rent = 0, units = 0, occU = 0, maint = 0, ptax = 0;
    const need = tw.kind === 'res' ? sum(co.props, p => p.units) / 60 : tw.kind === 'com' ? sum(co.props, p => p.units) / 4000 : sum(co.props, p => p.units) / 450;
    const fte = staffFTE(co, 'caretaker') + staffFTE(co, 'propm') * 0.6 + (co.mgr ? 0.3 : co.ohrs / 40 * 0.5);
    const cover = need > 0 ? clamp(fte / need, 0, 1.4) : 1;
    const pr = (1 + 0.08 * co.price) * knobFx(co, 't');
    const dm = modProd(co, 'dem');
    co.props.forEach(p => {
      const target = clamp(0.03 + 0.28 * (pr - 1) * (bd.ela) + (1 - p.cond) * 0.16 + (1 - S.econ.dem) * 0.6 - (co.aware / 100) * 0.03 - (co.rep - 50) / 100 * 0.05 + (1 - dm) * 0.8 + (1 - knobFx(co, 'd')) * 0.18 + (cover < 1 ? (1 - cover) * 0.06 : 0) + (bd.seas === 'study' && tw.kind === 'res' ? (1 - SEAS.study[wMonth(S.week)]) * 0.012 : 0) + (S.mk[mkKey(co)] ? Math.min(0.02, S.mk[mkKey(co)].n * 0.0005) : 0), 0.01, 0.8);
      p.vac += (target - p.vac) * 0.12;
      const occ = 1 - p.vac;
      const lu = Math.min(p.lu || 0, p.units), fu = p.units - lu;
      units += p.units;
      occU += lu + fu * occ;
      const fixed = (p.leases || []).reduce((a, l) => a + (l.rw ? l.m2 * l.rw : 0), 0);
      rent += fixed;
      const r = fu * occ * p.rentU * pr * (0.93 + 0.07 * p.cond) * Math.pow(S.econ.housing / (p.idx0 || S.econ.housing), 0.6) * (1 + (co.rep - 50) / 700);
      rent += r;
      const m = p.val * tw.maint / 52 * (1.7 - p.cond) * (1.1 - mgrQual(co) * 0.2 * (co.mgr ? 1 : 0));
      maint += m;
      ptax += p.val * tw.ptax / 52;
      p.cond = clamp(p.cond - 0.0006 * (cover < 1 ? 2 : 1) * [1.5, 1, 0.7][co.maint], 0.1, 1);
      if (co.maint === 2) p.cond = clamp(p.cond + 0.0005, 0, 1);
      const nv = p.cost * (S.econ.housing / p.idx0) * (0.88 + 0.12 * p.cond) * (tw.kind === 'com' ? (0.92 + 0.08 * (1 - p.vac) / 0.9) : 1);
      revalue(co, nv - p.val);
      p.val = nv;
    });
    const outsrc = cover < 0.8 && need > 0 ? rent * 0.07 : 0;
    ctx.D = units;
    ctx.cap = units;
    ctx.units = occU;
    ctx.util = units ? occU / units : 0;
    ctx.price = bd.ticket;
    ctx.rev = rent;
    ctx.cogs = maint + ptax + outsrc;
    co.dbg = {
      D: occU,
      cap: units,
      dp: {},
      cp: [],
      bot: need > 0 && cover < 1 ? 'Property management staff' : '',
      props: co.props.length,
      cover
    };
    co.lastW = { units: occU, rev: Math.round(rent), cogs: Math.round(ctx.cogs), D: units, cap: units, util: ctx.util };
    co.fm.assets = 0;
  },
  fx(co, bd, fx) {
    if (fx.vacAdd) (co.props || []).forEach(p => {
      p.vac = clamp(p.vac + fx.vacAdd * 0.02, 0, 0.9);
    });
    if (fx.vac) (co.props || []).forEach(p => {
      p.vac = clamp(p.vac + 0.08, 0, 0.9);
    });
    if (fx.tenant && co.props && co.props.length) {
      if (fx.tenant === 'evict') {
        payCo(co, KC(12000, co.country), 'oth', 'Eviction costs');
        addMod(co, 'dem', 0.97, 6);
      } else if (fx.tenant === 'plan') {
        bk(co, 'loss', 4000);
      } else {
        bk(co, 'loss', 9000);
        payCo(co, 0, null);
      }
    }
  },
  checklist(co, bd, items) {
    items.push({
      k: 'prop',
      t: 'At least one property bought',
      ok: !!(co.props && co.props.length),
      sub: 'See Properties tab'
    });
  }
};


/* ---- src/company/family_project.js ---- */
/* ===== Project family: tenders, backlog, progress billing; real-estate development ===== */
FAM.project = {
  custom(co, bd, ctx) {
    if (bd.tw.dev) return FAM.dev.custom(co, bd, ctx);
    const tw = bd.tw, fm = co.fm;
    fm.jobs = fm.jobs || [];
    fm.done = fm.done || 0;
    fm.won = fm.won || 0;
    const dm = demand(co, bd), cp = capacity(co, bd);
    ctx.D = dm.D;
    ctx.cap = cp.cap;
    co.dbg = { D: dm.D, cap: cp.cap, dp: dm.parts, cp: cp.parts, bot: cp.bot ? cp.bot.label : '', owner: cp.owner, botObj: cp.bot ? { kind: cp.bot.kind, k: cp.bot.k } : null };
    const tick = bd.ticket * ticketMult(co, bd) * knobFx(co, 'tt'); // contract value scale
    const capV = cp.cap * bd.ticket * knobFx(co, 'k') / knobFx(co, 'k'); // value deliverable per week (cap in contracts/wk)
    const backlogV = sum(fm.jobs, j => j.v * (1 - j.p));
    const backlogWk = capV > 0 ? backlogV / capV : 99;
    // win new jobs
    const lam = ctx.D * Math.exp(-Math.max(0, backlogWk - 8) / 14);
    const n = pois(lam);
    for (let i = 0; i < n; i++) {
      const v = rnl(tick * Math.exp(gauss() * 0.4 - 0.08), 1000);
      const wks = Math.max(1, Math.round(tw.wks * rng(0.7, 1.4)));
      const base = (tw.mat + tw.sub) * modProd(co, 'price') * (S.econ.mat * 0.5 + 0.5) * (1 + gauss() * tw.over);
      fm.jobs.push({
        id: uid(),
        v,
        wks,
        p: 0,
        cf: Math.max(0.05, base),
        delay: 0,
        w0: S.week,
        client: pick([
          'Municipality',
          'Housing co-op',
          'Private client',
          'Developer',
          'Retail chain',
          'School board',
          'Hospital',
          'Office owner'
        ])
      });
      fm.won++;
    }
    // progress
    let avail = capV * (ctx.D > 0 ? 1 : 1);
    let prog = 0, cost = 0;
    fm.jobs.forEach(j => {
      if (j.delay > 0) {
        j.delay--;
        return;
      }
      if (avail <= 0) return;
      const rate = Math.min(j.v / j.wks * 1.25, avail, j.v * (1 - j.p));
      if (rate <= 0) return;
      avail -= rate;
      j.p += rate / j.v;
      prog += rate;
      cost += rate * j.cf;
    });
    const done = fm.jobs.filter(j => j.p >= 0.999);
    done.forEach(j => {
      fm.done++;
      co.rep = clamp(co.rep + (co.q > 55 ? 0.3 : -0.1), 0, 100);
    });
    fm.jobs = fm.jobs.filter(j => j.p < 0.999);
    ctx.units = prog / bd.ticket;
    ctx.util = capV > 0 ? prog / capV : 0;
    ctx.rev = prog;
    ctx.cogs = cost;
    ctx.price = bd.ticket;
    fm.backlog = Math.round(sum(fm.jobs, j => j.v * (1 - j.p)));
    fm.backlogWk = backlogWk;
  },
  fx(co, bd, fx) {
    const fm = co.fm;
    if (fx.ovr && fm.jobs && fm.jobs.length) {
      const j = pick(fm.jobs);
      j.cf += fx.ovr;
    }
    if (fx.defect && fm.done) payCo(co, Math.round(bd.ticket * 0.025 * fx.defect), 'loss', 'Defect rework');
    if (fx.delay != null && fm.jobs && fm.jobs.length) {
      pick(fm.jobs).delay += fx.delay;
    }
  },
  checklist(co, bd, items) { }
};
/* ===== real-estate development ===== */
FAM.dev = {
  custom(co, bd, ctx) {
    const tw = bd.tw, fm = co.fm;
    fm.proj = fm.proj || [];
    let rev = 0, cogs = 0, sold = 0;
    const H = S.econ.housing;
    // automatic baseline: with a manager and funds, projects start at a modest pace
    if (co.mgr && S.npcs[co.mgr] && co.st === 'open' && S.week - (fm.autoW || -99) >= 10 && fm.proj.filter(p => p.st !== 'done').length < 2 && chance(0.35)) {
      const city = cityOf(co.city), lev = (co.knob.fin || 0) === 0;
      for (const sz of [1, 0.5, 0.4]) {
        const land = tw.land * sz * city.rent * S.econ.housing, build = tw.build * sz * city.price * S.econ.mat, fee = DOCS.regplan[2] * Math.sqrt(sz);
        const need = lev ? land * 0.35 + fee + build * 0.15 : land + fee + build * 1.05;
        if (co.cash >= need * (fm.proj.filter(p => p.st !== 'done').length ? 3 : 1.1)) {
          const r = FAM.dev.start(co, bd, { size: sz, debt: lev });
          if (r === 'ok') {
            fm.autoW = S.week;
            note(S.npcs[co.mgr].name + ' started a new project.', 'good', co.id);
            break;
          }
          if (r === 'loan' && co.cash >= (land + fee + build * 1.05) * 1.1) {
            const r2 = FAM.dev.start(co, bd, { size: sz, debt: false });
            if (r2 === 'ok') {
              fm.autoW = S.week;
              break;
            }
          }
        }
      }
    }
    fm.proj.forEach(p => { if (p.wip == null) p.wip = Math.max(0, p.land + (p.spent || 0) - (p.cogsRec || 0)); }); /* older saves */
    ctx.D = 0;
    ctx.cap = 0;
    co.dbg = { D: 0, cap: 0, dp: {}, cp: [], bot: '', projects: fm.proj.length };
    fm.proj.forEach(p => {
      if (p.st === 'zoning') {
        p.wl--;
        if (p.wl <= 0) {
          if (chance(0.78 - (co.mgr ? 0 : 0.02))) {
            p.st = 'build';
            p.wl = tw.wks;
            p.spent = 0;
            note('Zoning approved for ' + p.name + '.', 'good', co.id);
          } else {
            p.wl = 10;
            note('Zoning for ' + p.name + ' delayed by objections.', 'bad', co.id);
          }
        }
      }
      else if (p.st === 'build') {
        const wk = p.build / tw.wks;
        const cost = (wk + (p.over || 0) / tw.wks) * S.econ.mat;
        payCo(co, cost, null, null);
        p.spent += cost;
        p.wip = (p.wip || 0) + Math.round(cost);
        p.wl--;
        if (p.delay > 0) {
          p.delay--;
          p.wl++;
        }
        if (p.wl <= 0) {
          p.st = 'sell';
          note(p.name + ' is complete and ready for sale.', 'good', co.id);
        }
        if (p.wl < tw.wks * 0.7 && p.sold < p.units) sellUnits(co, bd, p, 0.4);
      } else if (p.st === 'sell') {
        sellUnits(co, bd, p, 1);
        if (p.sold >= p.units) {
          p.st = 'done';
          note(p.name + ' sold out. Total sales ' + money(p.rev) + '.', 'good', co.id);
        }
      }
    });
    function sellUnits(co, bd, p, f) {
      const base = bd.Dc ? 1 : 1;
      const rate = p.units * 0.035 * f * Math.exp(-(1 - H) * 5) * (0.7 + co.aware / 150) * (0.8 + co.rep / 250) * Math.exp(-1.2 * (p.priceMult - 1)) * seasOf(bd);
      let n = Math.min(p.units - p.sold, pois(rate));
      if (n > 0) {
        const price = p.price * H * p.priceMult;
        const r = n * price;
        /* cost of sales: this share of everything spent on the project so far (work in progress) */
        const cs = (p.wip || 0) * n / (p.units - p.sold);
        p.wip -= cs;
        cogs += cs;
        p.sold += n;
        p.rev += r;
        rev += r;
        sold += n;
        if (p.loan) {
          const l = S.loans.find(x => x.id === p.loan);
          if (l) {
            const rep = Math.min(l.bal, r * 0.7);
            l.bal -= rep;
            moveCash(co, -(rep));
            if (l.bal < 1) {
              S.loans = S.loans.filter(x => x !== l);
              p.loan = 0;
            }
          }
        }
      }
    }
    fm.proj.forEach(p => { /* costs that came in after the last unit was sold */
      if (p.st === 'done' && p.wip > 0) {
        cogs += p.wip;
        p.wip = 0;
      }
    });
    fm.proj = fm.proj.filter(p => p.st !== 'done' || (p.cleared = 1) && false);
    ctx.rev = rev;
    ctx.cogs = cogs;
    ctx.units = sold;
    ctx.util = fm.proj.length ? 0.7 : 0;
    ctx.price = tw.land ? 4800000 : 0;
    ctx.devRevIsCash = 1;
    co.lastW = { units: sold, rev: Math.round(rev), cogs: Math.round(cogs), D: 0, cap: 0, util: ctx.util };
    fm.assets = sum(fm.proj, p => p.wip || 0);
  },
  start(co, bd, o) {
    const tw = bd.tw, fm = co.fm;
    fm.proj = fm.proj || [];
    const sz = o.size || 1;
    const city = cityOf(co.city);
    const land = rnl(tw.land * sz * city.rent * S.econ.housing, 1000), build = rnl(tw.build * sz * city.price * S.econ.mat, 1000);
    const units = Math.max(4, Math.round(tw.units * sz));
    const fee = DOCS.regplan[2] * Math.sqrt(sz);
    const down = o.debt ? land * 0.35 : land;
    if (co.cash < down + fee) return 'cash';
    let loan = 0, l = null;
    if (o.debt) {
      l = {
        id: uid(),
        kind: 'biz',
        name: 'Construction loan',
        bal: land - down + build * 0.7,
        margin: creditMargin() + 0.018,
        pay: 0,
        termM: 36,
        co: co.id,
        w0: S.week,
        guar: 1
      };
      const off = loanOffer('biz', l.bal, co);
      if (l.bal > off.max) return 'loan';
    }
    payCo(co, down, null, 'Land purchase');
    payCo(co, fee, 'oth', 'Zoning work');
    if (l) {
      l.pay = 0;
      S.loans.push(l);
      loan = l.id;
      moveCash(co, build * 0.7);
    }
    const priceUnit = rnl((land + build) * 1.38 / units * knobFx(co, 't'), 1000);
    fm.proj.push({
      id: uid(),
      name: 'Project ' + (fm.pn = (fm.pn || 0) + 1) + ' (' + units + ' units)',
      units,
      land,
      build,
      st: 'zoning',
      wl: 22 + rint(0, 8),
      sold: 0,
      rev: 0,
      price: priceUnit,
      priceMult: 1,
      spent: 0,
      wip: land,
      over: 0,
      loan,
      delay: 0
    });
    return 'ok';
  }
};
FAM.project.fx = function (co, bd, fx) {
  const fm = co.fm;
  if (bd.tw.dev) {
    const p = (fm.proj || []).find(x => x.st === 'build');
    if (p) {
      if (fx.ovr) p.over = (p.over || 0) + p.build * fx.ovr;
      if (fx.delay) p.delay = (p.delay || 0) + fx.delay;
    }
    return;
  }
  if (fx.ovr && fm.jobs && fm.jobs.length) {
    pick(fm.jobs).cf += fx.ovr;
  }
  if (fx.defect && fm.done) payCo(co, Math.round(bd.ticket * 0.025 * fx.defect), 'loss', 'Defect rework');
  if (fx.delay != null && fm.jobs && fm.jobs.length) {
    pick(fm.jobs).delay += fx.delay;
  }
};
FAM.project.checklist = (co, bd, items) => { };


/* ---- src/company/family_finance.js ---- */
/* ===== Finance: insurance company, bank, investment fund ===== */
function finStaffCover(co, bd) {
  let q = 0, n = 0;
  bd.std.forEach(s => {
    const have = staffFTE(co, s[0]);
    q += Math.min(1, have / Math.max(0.5, s[1] * co.size));
    n++;
  });
  return n ? q / n : 1;
}
FAM.fin = {
  custom(co, bd, ctx) {
    if (bd.tw.ins) return FAM.fin.ins(co, bd, ctx);
    if (bd.tw.bank) return FAM.fin.bank(co, bd, ctx);
    return FAM.fin.fund(co, bd, ctx);
  },
  ins(co, bd, ctx) {
    const tw = bd.tw, fm = co.fm;
    fm.pol = fm.pol || 0;
    const cover = finStaffCover(co, bd);
    const uw = staffFTE(co, 'underw') / Math.max(0.5, 3 * co.size);
    fm.prods = fm.prods || {};
    let W = 0, Wp = 0, Wl = 0;
    Object.keys(INS_PRODS).forEach(k => {
      if (!prodActive(co, k)) return;
      const P = INS_PRODS[k][1];
      const cv = clamp(verAgents(co, k) / Math.max(0.8, 1.2 * co.size), 0, 1);
      const w = P.vol * (0.15 + 0.85 * cv);
      W += w;
      Wp += w * P.prem;
      Wl += w * P.lr;
    });
    const pm = W ? Wp / W : 1, lmx = W ? Wl / W : 1, volF = W / 3;
    const price = tw.premium * pm * knobFx(co, 't') * (1 + 0.08 * co.price) * Math.pow(1 + S.econ.infl, S.week / 52);
    const rm = rivalMult(co, bd);
    let target = volF * tw.policies * co.size * mktMult(co) * repMult(co) * knobFx(co, 'd') * priceDem(co, bd) * rm * modProd(co, 'dem') * (1 + (S.econ.dem - 1) * 0.4);
    const sol0 = fm.sol == null ? 1.5 : fm.sol;
    if (sol0 < 1) target *= 0.5;
    const cap = tw.policies * co.size * 1.3 * Math.min(1, cover + 0.15);
    target = Math.min(target, cap);
    fm.pol += (target - fm.pol) * 0.025;
    fm.pol = clamp(fm.pol, 0, cap);
    const prem = fm.pol * price / 52;
    const lr = tw.lossR * lmx * knobFx(co, 'r') * (1.12 - 0.3 * clamp(uw, 0, 1.2)) * (1 + (1 - Math.min(1, staffFTE(co, 'claims') / Math.max(0.5, 5 * co.size))) * 0.12) * (1 + gauss() * 0.14 / Math.sqrt(Math.max(1, fm.pol / 1000))) * (co.flags.catW > 0 ? 1.5 : 1);
    const claims = prem * (lr + 0.12 * (0.8 + 0.2 * Math.min(1, cover)));
    /* claims plus agent commissions and claims handling */
    const invInc = Math.min(Math.max(0, co.cash), prem * 52 * 2.5) * Math.max(0, policy() - 0.008) / 52; /* only the float (reserves and solvency capital) earns investment income; idle owner cash does not */
    ctx.rev = prem + invInc;
    ctx.cogs = claims;
    ctx.units = fm.pol;
    ctx.D = target;
    ctx.cap = cap;
    ctx.util = cap ? fm.pol / cap : 0;
    ctx.price = price;
    fm.premW = prem;
    fm.lossR = lr;
    const annual = prem * 52 + 1;
    fm.sol = (co.cash - co.pay.other) / (annual * 0.4);
    fm.assets = 0;
    if (fm.sol < 0.8 && !co.flags.reg) {
      co.flags.reg = 1;
      note('{auth:fin} restricts ' + co.name + ': solvency too low. Add capital.', 'bad', co.id);
    }
    if (fm.sol > 1.0) co.flags.reg = 0;
    co.dbg = {
      D: target,
      cap,
      dp: {},
      cp: [],
      bot: !W ? 'No insurance products live' : cover < 0.8 ? 'Staff coverage' : '',
      pol: fm.pol,
      sol: fm.sol
    };
    co.lastW = { units: fm.pol, rev: Math.round(ctx.rev), cogs: Math.round(claims), D: target, cap, util: ctx.util };
    if (co.flags.catW > 0) co.flags.catW--;
  },
  bank(co, bd, ctx) {
    const tw = bd.tw, fm = co.fm;
    fm.dep = fm.dep || 0;
    fm.book = fm.book || 0;
    fm.gb = fm.gb || 0;
    const cover = finStaffCover(co, bd);
    const equity = co.cash + fm.book + fm.gb - fm.dep;
    const wholesale = co.knob.liq === 1;
    const depT = tw.capital * 5 * co.size * mktMult(co) * repMult(co) * (wholesale ? 0.7 : 1) * rivalMult(co, bd) * modProd(co, 'dem');
    /* a bank only pays for the deposits it can lend out (plus a liquidity reserve); beyond that it lowers its deposit rate and the money goes elsewhere */
    const depNeed = Math.max(0, equity) / tw.capitalReq * 0.85 / 0.9 + Math.max(0, equity) * 0.3;
    fm.dep += (Math.min(depT * (wholesale ? 1.3 : 1), depNeed, wholesale ? fm.book * 1.15 + Math.max(0, equity) * 0.25 + 1e7 : Infinity) - fm.dep) * (wholesale ? 0.05 : 0.02); /* wholesale money comes faster, but is only raised for loans actually made */
    const room = Math.min(equity / tw.capitalReq * 0.85 - fm.book - fm.gb, Math.max(0, fm.dep * 0.9 - fm.book - fm.gb + equity * 0.5), (co.cash > 0 ? co.cash : 0) * 0.9);
    const demand = Math.max(0, (depT / (wholesale ? 0.7 : 1) * 0.85 - fm.book) * (wholesale ? 0.06 : 0.04) * knobFx(co, 'd') * (S.econ.dem * 1.0) * Math.min(1, cover + 0.2));
    const add = Math.min(room, demand);
    fm.book += Math.max(0, add);
    moveCash(co, -(Math.max(0, add)));
    const loanM = (tw.nim + 0.012) * knobFx(co, 't');
    const rIn = fm.book * (policy() + loanM * 0.62) / 52 + fm.gb * 0;
    const dr = fm.dep * Math.max(0, policy() - 0.006 + (wholesale ? 0.012 : 0)) / 52;
    const baseLoss = 0.0035 * knobFx(co, 'r') * (1 + Math.max(0, 1 - S.econ.dem) * 8) * (1.1 - 0.4 * (staffFTE(co, 'credit') / Math.max(0.5, 3 * co.size) > 1 ? 1 : staffFTE(co, 'credit') / Math.max(0.5, 3 * co.size)));
    const loss = fm.book * baseLoss / 52 * (1 + gauss() * 0.3);
    fm.book = Math.max(0, fm.book - loss);
    const cashInt = Math.min(Math.max(0, co.cash), fm.dep * 0.35) * Math.max(0, policy() - 0.004) / 52; /* liquidity reserves earn interest; surplus owner cash does not */
    ctx.rev = rIn + cashInt;
    ctx.cogs = dr;
    bk(co, 'loss', loss);
    ctx.units = fm.book / 1e6;
    ctx.D = depT;
    ctx.cap = depT;
    ctx.util = depT ? fm.dep / depT : 0;
    ctx.price = 0;
    fm.cr = equity / Math.max(1, fm.book + fm.gb);
    fm.equity = equity;
    moveCash(co, dr * 0); // deposit interest is expense (paid via payables)
    moveCash(co, fm.dep ? 0 : 0);
    // deposits flow in as cash: delta of deposits
    const dd = fm.dep - (fm.depPrev || 0);
    moveCash(co, dd);
    fm.depPrev = fm.dep;
    if (fm.cr < tw.capitalReq * 0.5 && !co.flags.reg) {
      co.flags.reg = 1;
      note('{auth:fin} warns ' + co.name + ': capital ratio ' + pc(fm.cr, 1) + '. Add capital or shrink.', 'bad', co.id);
    }
    if (fm.cr > tw.capitalReq * 0.7) co.flags.reg = 0;
    fm.assets = fm.book + fm.gb;
    fm.liab = fm.dep;
    co.dbg = { D: depT, cap: depT, dp: {}, cp: [], bot: '', book: fm.book, dep: fm.dep, cr: fm.cr };
    co.lastW = {
      units: fm.book / 1e6,
      rev: Math.round(ctx.rev),
      cogs: Math.round(ctx.cogs),
      D: depT,
      cap: depT,
      util: ctx.util
    };
  },
  fund(co, bd, ctx) {
    const tw = bd.tw, fm = co.fm;
    fm.aum = fm.aum || 0;
    fm.hwm = fm.hwm || 1;
    fm.nav = fm.nav || 1;
    const an = staffFTE(co, 'analyst') / Math.max(0.5, 2 * co.size) + 0.0;
    const aq = clamp(0.4 + 0.6 * Math.min(1, an), 0.3, 1.2) * (co.mgr ? 0.8 + 0.4 * mgrQual(co) : 0.85 + co.oskill / 400);
    const strat = co.knob.strat || 0;
    const mret = S.idxRet || 0;
    const beta = [0.9, 1.0, 0.7][strat];
    const alpha = [0.0005, 0.0018, 0.0022][strat] * (aq - 0.6) * 4 + (strat === 2 ? gauss() * 0.01 : gauss() * 0.003);
    const r = mret * beta + alpha - tw.mgmt / 52;
    fm.nav *= (1 + r);
    fm.aum *= (1 + r);
    const target = 650e6 * co.size * (co.aware / 50 + 0.2) * (co.rep / 50) * knobFx(co, 'd') * Math.min(1.6, Math.max(0.4, fm.nav / (fm.nav52 || 1))) * (S.econ.dem);
    fm.aum += (target - fm.aum) * 0.055;
    fm.aum = Math.max(0, fm.aum);
    if (S.week % 52 === 0) fm.nav52 = fm.nav;
    const fee = fm.aum * tw.mgmt / 52 * knobFx(co, 't'); /* the fee level (the fees knob) */
    ctx.rev = fee;
    ctx.cogs = 0;
    ctx.units = fm.aum / 1e6;
    ctx.util = 0.7;
    ctx.D = target;
    ctx.cap = target;
    ctx.price = 0;
    if (isYearEnd(S.week) && fm.nav > fm.hwm * 1.04) {
      const gain = (fm.nav - fm.hwm * 1.04) / fm.hwm * fm.aum / (fm.nav / fm.hwm) ;
      const pf = Math.max(0, gain * tw.perf);
      coIn(co, pf, 'rev', 'Performance fee');
      fm.hwm = fm.nav;
      note('Performance fee earned at ' + co.name + ': ' + money(pf) + '.', 'good', co.id);
    } else if (isYearEnd(S.week)) {
      fm.hwm = Math.max(fm.hwm, fm.nav * 0.99);
    }
    co.dbg = { D: target, cap: target, dp: {}, cp: [], bot: '', aum: fm.aum, nav: fm.nav, aq };
    co.lastW = { units: fm.aum / 1e6, rev: Math.round(fee), cogs: 0, D: target, cap: target, util: 0.7 };
  },
  fx(co, bd, fx) {
    if (fx.aum && co.fm.aum) co.fm.aum *= fx.aum;
  },
  checklist(co, bd, items) {
    items.push({
      k: 'cap',
      t: 'Regulatory capital in the company (at least ' + money(bd.tw.capital * 0.4) + ')',
      ok: co.cash >= bd.tw.capital * 0.4 || bd.tw.fund,
      sub: 'Currently ' + money(co.cash)
    });
  }
};
FAM.fin.checklist = (co, bd, items) => {
  if (bd.tw.ins || bd.tw.bank) items.push({
    k: 'cap',
    t: 'Regulatory capital in the company (at least ' + money(bd.tw.capital * 0.5) + ')',
    ok: co.cash >= bd.tw.capital * 0.5,
    sub: 'Currently ' + money(co.cash)
  });
};


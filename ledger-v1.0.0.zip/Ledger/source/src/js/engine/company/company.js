/* ---- src/company/company.js ---- */
/* ===== Company: creation, calibration, documents, equipment, premises, marketing ===== */
const OC = () => 1 + CC().empNI + CC().otp + CC().injury;
const FIT = {
  shop: 2500,
  kitchen: 6000,
  hotel: 9000,
  industrial: 800,
  office: 1800,
  gym: 3000,
  clinic: 4000,
  warehouse: 300,
  yard: 100,
  home: 0,
  none: 0
};
function calib(bd) {
  if (bd._c) return bd;
  bd._c = 1;
  const f = bd.fam;
  if (f === 'rent' || f === 'fin' || f === 'energy' || f === 'club') {
    bd.Dc = 0;
    bd.capD = 0;
    return bd;
  }
  const w52 = 12 / 52, oc = 1.166; /* businesses are designed at the base country's cost level (employer costs 16.6%); countries then scale prices, wages and rents */
  let wages = 0;
  bd.std.forEach(s => {
    wages += s[1] * ROLES[s[0]][1] * w52 * oc * 1.2;
  });
  let rent = 0;
  if (bd.prem && PREM[bd.prem[0]]) rent = bd.prem[1] * PREM[bd.prem[0]][1] / 52;
  let dep = 0;
  bd.eq.forEach(e => {
    if (e.vo && VEH[e.vo[0]]) {
      const vc0 = VEH[e.vo[0]][1] * e.std;
      dep += vc0 * 0.15 / 52 + vc0 * 0.0143 / 52;
    } else {
      dep += e.cost * e.std / Math.max(1, e.life) / 52 + e.cost * e.std * 0.011 / 52;
    }
  });
  const acct = 3400 * 12 / 52 * (bd.needAS ? 1 : 0.3);
  const F = wages + rent + dep + bd.fixed + acct + (FIT[bd.prem ? bd.prem[0] : 'none'] || 0) * (bd.prem ? bd.prem[1] : 0) / 10 / 52;
  const tw = bd.tw;
  let vc = bd.cogs + (tw.perish || 0) * 0.6 + (tw.shrink || 0) * 0.3 + (tw.mat || 0) + (tw.fuel || 0) * 0 + (tw.ota || 0) * 0 + (tw.excise ? 0 : 0);
  if (tw.ota) vc += tw.ota * 0.5; // commissions on part
  bd.F = F;
  bd.vc = vc;
  const den = bd.ticket * Math.max(0.12, 1 - vc - 0.028 - bd.m - 0.07);
  bd.Dc = bd.D || F / den;
  bd.capD = bd.Dc / 0.85;
  if (f === 'project') {
    bd.Dc = F / den;
    bd.capD = bd.Dc / 0.85;
  }
  return bd;
}
/* stdStaff: the core below, then the steps features add: pipeSteps('stdStaff') */
function stdStaff(bd, size) {
  return runSteps('stdStaff', stdStaffCore(bd, size), bd, size);
}
function stdStaffCore(bd, size) {
  return bd.std.map(s => [s[0], Math.max(1, Math.round(s[1] * size))]);
}
function stdEq(bd, size) {
  const o = {};
  bd.eq.forEach(e => {
    if (e.std > 0) o[e.id] = Math.max(1, Math.round(e.std * size));
  });
  return o;
}
function recSize(cityId) {
  return clamp(Math.round(cityOf(cityId).dem * 20) / 20 + (0), 0.4, 2.2);
}
function mkBooks() {
  return { w: {}, m: {}, y: {}, ly: {} };
}
function newCompany(bdId, o) {
  const ctry = o.country || S.country;
  const bd = calib(BD[bdId]), city = cityOf(o.city || (ctry === S.country ? S.player.city : CO[ctry].cities[0].id));
  const co = {
    id: uid(),
    type: bdId,
    country: ctry,
    name: o.name || coName(bd.fam, city.id, bd.id),
    city: city.id,
    form: o.form || 'ENK',
    size: o.size || 1,
    st: 'setup',
    w0: S.week,
    wOpen: null,
    cash: 0,
    own: 100,
    holders: [],
    docs: {},
    eq: {},
    veh: [],
    lease: {},
    staff: [],
    mgr: null,
    mgrWage: 0,
    mgrBonus: 0,
    auth: { lvl: 0, buy: KC(25000, ctry), hire: KC(8000, ctry), ad: KC(3000, ctry) },
    region: 0,
    mkt: {},
    aware: 25,
    knob: {},
    price: 0,
    ohrs: 40,
    rep: 45,
    q: 45,
    oskill: 40,
    maint: 1,
    stockPol: 1,
    bid: 1,
    prem: null,
    recv: [],
    pay: { wages: 0, other: 0, tax: 0, rent: 0 },
    vatAcc: 0,
    inv: 0,
    bk: mkBooks(),
    law: null,
    insr: null,
    hist: [],
    mods: [],
    tx: [],
    payGap: 0,
    acc: null,
    ins: {},
    flags: {},
    fm: {},
    lossCarry: 0,
    dist: 0,
    capital: 0,
    inj: 0,
    ownerSalary: 0,
    unitsW: 0,
    lastW: null,
    mgrQ: 0,
    eqc: 1,
    books: 0.5,
    franchise: null,
    group: 0
  };
  bd.knobs.forEach(k => {
    co.knob[k.id] = knobDef(co, k);
  });
  co.price = 0;
  if (o.form === 'AS') {
    co.capital = CC().asCapital;
  }
  S.cos.push(co);
  return co;
}
/* knob helpers */
function knobOpt(co, k) {
  if (k.multi) return knobOpts(co, k)[0] || null;
  const o = k.opts[co.knob[k.id] || 0];
  return o;
}
/* every option that is on: one for a normal choice, any number for a group of add-ons (k.multi, a bitmask) */
function knobOpts(co, k) {
  if (k.multi) { const m = co.knob[k.id] || 0; return k.opts.filter((o, i) => m & (1 << i)); }
  const o = k.opts[co.knob[k.id] || 0];
  return o ? [o] : [];
}
/* knobFx: the core below, then the steps features add: pipeSteps('knobFx') */
function knobFx(co, key, mode) {
  return runSteps('knobFx', knobFxCore(co, key, mode), co, key, mode);
}
function knobFxCore(co, key, mode) { // multiply product ('m') or sum
  const bd = BD[co.type];
  let v = mode === 'sum' ? 0 : 1;
  bd.knobs.forEach(k => knobOpts(co, k).forEach(o => {
    if (o.fx.req && !o.fx.req.every(d => docOk(co, d))) return;
    const x = o.fx[key];
    if (x != null) v = mode === 'sum' ? v + x : v * x;
  }));
  return v;
}
function knobReqMissing(co, k, idx) {
  const o = k.opts[idx];
  return o.fx.req ? o.fx.req.filter(d => !docOk(co, d)) : [];
}
/* documents */
function docOk(co, id) {
  const d = co.docs[id];
  return !!d && d.st === 'ok';
}
/* real local fees where they are known (local currency). Everything else scales with the country's price level and is rounded. */
function docCost(co, id) {
  const dd = docDef(id, co.country), bd = BD[co.type];
  let c = dd[2] * (CO[co.country] ? CO[co.country].bur : 1) * costIdx(co.country) * (co.country !== S.country ? 1.8 : 1);
  if (bd.dq && bd.dq[id]) c = c * (bd.dq[id] === 'veh' ? Math.max(1, vehCountTotal(co) || stdEq(bd, co.size).car || 1) : bd.dq[id]);
  if (DOC_LOCAL[id] && DOC_LOCAL[id][co.country] != null && !(bd.dq && bd.dq[id])) c = DOC_LOCAL[id][co.country] * fxr(CO[co.country] || CC()) * (co.country !== S.country ? 1.8 : 1);
  if (id === 'acctr') c = 0;
  if (co.form === 'ENK' && (DOC_FREE_ENK[co.country] || []).indexOf(id) >= 0) c = 0;
  return Math.round(rlc(c, co.country));
}
function renewCost(co, id) {
  const dd = docDef(id, co.country);
  if (!dd[4]) return 0;
  return Math.round(rlc(dd[4] * (CO[co.country] ? CO[co.country].bur : 1) * costIdx(co.country) * (co.country !== S.country ? 1.4 : 1), co.country));
}
function docWeeks(co, id) {
  const dd = docDef(id, co.country);
  let wks = dd[3];
  if (co.country && co.country !== S.country) wks = Math.ceil(wks * CO[co.country].bur * (deskFor(co.country) ? 0.6 : 1.4));
  if (id === 'mva' || id === 'org' || id === 'mva_na') wks = Math.max(1, wks);
  return wks;
}
function docNeeds(co) {
  const bd = BD[co.type];
  const need = bd.docs.slice().filter(d => !(d === 'mva' && vatExempt(co)));
  bd.knobs.forEach(k => knobOpts(co, k).forEach(o => {
    if (o.fx.req) o.fx.req.forEach(d => {
      if (need.indexOf(d) < 0) need.push(d);
    });
  }));
  if (bd.tw && bd.tw.ins && co.fm && co.fm.prods) Object.keys(co.fm.prods).forEach(k => {
    if (co.fm.prods[k]) {
      const d = INS_PRODS[k][1].doc;
      if (need.indexOf(d) < 0) need.push(d);
    }
  });
  if (co.foreignOf && need.indexOf('forreg') < 0) need.push('forreg');
  if (co.form === 'AS' && need.indexOf('acctr') < 0) need.push('acctr');
  return need.filter(d => !docSkipped(d, co.country));
}
function applyDoc(co, id) {
  const dd = docDef(id, co.country);
  if (co.docs[id] && co.docs[id].st !== 'lapsed') return 'have';
  /* a document can wait for something first (a chain needs a track record, franchising a proven chain): those
     rules add 'applyDoc.check' steps that say no with a sentence the player reads */
  const ck = runChecks('applyDoc.check', {}, co, id);
  if (ck.no) return ck.no;
  if (id === 'acctr' && !co.acc) return 'pickacc';
  const cost = docCost(co, id);
  if (cost > 0 && co.cash < cost) return 'cash'; /* a free document can always be registered, even with the company in the red */
  if (cost) payCo(co, cost, 'oth', 'Application: ' + dd[0]);
  let wks = dd[3];
  if (co.country && co.country !== S.country) wks = Math.ceil(wks * CO[co.country].bur * (deskFor(co.country) ? 0.6 : 1.4));
  if (id === 'mva' || id === 'org' || id === 'mva_na') wks = Math.max(1, wks);
  const own = !!(co.law && co.law.own);
  if (own && wks > 3) wks = Math.ceil(wks * 0.75);
  co.docs[id] = { st: wks <= 0 ? 'ok' : 'applied', done: S.week + wks, w0: S.week };
  return 'ok';
}
function docsWeek(co) {
  for (const id in co.docs) {
    const d = co.docs[id], dd = docDef(id, co.country);
    if (d.st === 'applied' && S.week >= d.done) {
      d.st = 'ok';
      d.ok = S.week;
      note(dd[0] + ' approved for ' + co.name + '.', 'good', co.id);
    }
    else if (d.st === 'ok' && dd[4] > 0 && S.week - d.ok >= 52 && ((S.week - d.ok) % 52 === 0 || d.due)) {
      /* a renewal that cannot be paid on the day gets four weeks of grace before the licence lapses */
      const fee = renewCost(co, id);
      if (fee <= 0 || co.cash >= fee) {
        if (fee > 0) payCo(co, fee, 'oth', 'Renewal: ' + dd[0]);
        d.due = 0;
      } else if ((d.due = (d.due || 0) + 1) > 4) {
        d.st = 'lapsed';
        d.due = 0;
        note(dd[0] + ' lapsed for ' + co.name + ' - renewal not paid.', 'bad', co.id);
      } else if (d.due === 1) note(dd[0] + ' renewal is due at ' + co.name + ' (' + money(fee) + ') but the company is short of cash. It lapses in four weeks if unpaid.', 'bad', co.id);
    }
  }
}
function docsReady(co) {
  return docNeeds(co).every(d => docOk(co, d) || d === 'mva' && DOCS.mva_na && false);
}
function docsMissing(co) {
  return docNeeds(co).filter(d => !docOk(co, d));
}
/* equipment */
function eqCount(co, id) {
  const e = BD[co.type].eq.find(x => x.id === id);
  if (!e) return 0;
  if (e.vo) return co.veh.filter(v => v.eq === id).length + ((co.lease[id] || 0) && !co.veh.some(v => v.eq === id && v.mode === 'lease') ? 0 : 0);
  return (co.eq[id] ? co.eq[id].n : 0) + (co.lease[id] || 0);
}
function vehCountTotal(co) {
  return co.veh.length;
}
function eqPrice(co, e, mode, cat) {
  const infl = Math.pow(1 + S.econ.infl, S.week / 52) * S.econ.mat * 0.0 + Math.pow(1 + S.econ.infl, S.week / 52);
  const sm = e.id === 'turb' && typeof SRC !== 'undefined' ? SRC[['wind', 'hydro', 'solar'][co.knob.src || 0]].cost : 1;
  return rnl(e.cost * infl * sm * (cat ? cat.f : 1) * costIdx(co.country) * (co.franchise && co.franchise.brandId ? (1 + (fbBrandTier(co) - 1) * 0.07) : 1) * (1 - (cat && cat.vid ? vdisc('eq', cat.vid) : 0)), 100) === 0 ? 0 : rlc(Math.round(e.cost * infl * sm * (cat ? cat.f : 1) * costIdx(co.country) * (co.franchise && co.franchise.brandId ? (1 + (fbBrandTier(co) - 1) * 0.07) : 1) * (1 - (cat && cat.vid ? vdisc('eq', cat.vid) : 0))), co.country);
}
function usedOk(e) {
  return !e.vo && e.fl.indexOf('u') >= 0 || (!e.vo && e.cost < 5000000 && e.fl.indexOf('c') >= 0 && e.cost > 3000);
}
/* buyEq: features may change the order first: 'buyEq.order' steps get (co, eqId, o) with o = { qty, mode, cat }, and a
   step can settle the purchase itself by setting o.r. Otherwise the core buys. Then 'buyEq.after' steps see o.r. */
function buyEq(co, eqId, qty, mode, cat) {
  const o = { qty, mode, cat };
  runSteps('buyEq.order', o, co, eqId);
  if (o.r === undefined) o.r = buyEqCore(co, eqId, o.qty, o.mode, o.cat);
  runSteps('buyEq.after', o, co, eqId);
  return o.r;
}
function buyEqCore(co, eqId, qty, mode, cat) {
  const bd = BD[co.type], e = bd.eq.find(x => x.id === eqId);
  if (!e || e.vo) return 'bad';
  qty = qty || 1;
  mode = mode || 'new';
  cat = cat || mgrCat(co, eqId);
  const unit = eqPrice(co, e, mode, cat) * (mode === 'used' ? 0.55 : 1);
  const price = unit * qty;
  if (cat && cat.vid && (mode !== 'lease' ? co.cash >= price * (mode === 'finance' ? 0.2 : 1) : true)) vbuy(cat.vid, price, true);
  if (mode === 'lease') {
    co.lease[eqId] = (co.lease[eqId] || 0) + qty;
    co.eqL = co.eqL || {};
    co.eqL[eqId] = (co.eqL[eqId] || 0) + eqPrice(co, e, mode, cat) * qty * 0.0235;
    return 'ok';
  }
  if (mode === 'finance') {
    const down = price * 0.2;
    if (co.cash < down) return 'cash';
    payCo(co, down, null, 'Down payment: ' + e.n);
    const l = {
      id: uid(),
      kind: 'biz',
      name: 'Equipment loan: ' + e.n,
      bal: price - down,
      margin: creditMargin() + 0.02,
      pay: 0,
      termM: 48,
      co: co.id,
      w0: S.week,
      guar: co.form === 'ENK' ? 1 : 1
    };
    l.pay = annuity(l.bal, policy() + l.margin, 48);
    S.loans.push(l);
    setupEqRec(co, eqId, e, price, qty, mode === 'used', cat);
    return 'ok';
  }
  if (co.cash < price) return 'cash';
  payCo(co, price, null, (mode === 'used' ? 'Used ' : '') + e.n + ' x' + qty);
  setupEqRec(co, eqId, e, price, qty, mode === 'used', cat);
  return 'ok';
}
function setupEqRec(co, id, e, price, qty, used, cat) {
  const r = co.eq[id] || (co.eq[id] = { n: 0, cond: 1, bv: 0, cost: 0, used: 0, age: 0 });
  r.n_prev = r.n;
  const tot = r.n + qty;
  r.cond = (r.cond * r.n + (used ? rng(0.55, 0.8) : 1) * qty) / Math.max(1, tot);
  r.n = tot;
  r.bv += price;
  r.cost += price;
  r.used = used ? 1 : r.used;
  if (cat) {
    r.perf = ((r.perf || 1) * r.n_prev + cat.perf * qty) / Math.max(1, r.n_prev + qty);
    r.rel = ((r.rel || 1) * r.n_prev + cat.rel * qty) / Math.max(1, r.n_prev + qty);
    r.mods = r.mods || [];
    const nm = cat.brand + ' ' + cat.model;
    const ex = r.mods.find(x => x.nm === nm);
    if (ex) ex.n += qty; else r.mods.push({ nm, n: qty, rt: cat.rating });
  }
  if (e.fl.indexOf('c') >= 0 || true) r.life = e.life;
  const F = FAM[BD[co.type].fam];
  if (F && F.afterBuy) F.afterBuy(co, BD[co.type], id, qty);
}
function sellEq(co, id) {
  const r = co.eq[id];
  if (!r) return 0;
  const v = Math.round(r.bv * 0.7);
  delete co.eq[id];
  coIn(co, v, null, 'Sold equipment');
  return v;
}
/* eqWeek: steps before ('eqWeek.before') and after ('eqWeek.after'): pipeSteps('eqWeek.after') */
function eqWeek(co, util) {
  return runPhased('eqWeek', [co, util], () => eqWeekCore(co, util));
}
function eqWeekCore(co, util) {
  const bd = BD[co.type];
  let tot = 0, w = 0;
  const mm = [1.5, 1, 0.6][co.maint];
  const mc = [0.005, 0.011, 0.02][co.maint];
  let eqv = 0;
  for (const id in co.eq) {
    const r = co.eq[id], e = bd.eq.find(x => x.id === id);
    if (id === 'fit' && r && r.bv > 0) {
      const d = Math.min(r.bv, r.cost / ((r.life || 10) * 52));
      r.bv -= d;
      bk(co, 'dep', d);
      continue;
    }
    if (!e || r.n <= 0) continue;
    const perUnit = (r.cost / Math.max(1, r.n));
    const dep = r.cost / Math.max(1, (e.life * (r.used ? 0.6 : 1))) / 52;
    const d = Math.min(r.bv, dep);
    r.bv -= d;
    bk(co, 'dep', d);
    r.cond = clamp(r.cond - 0.0012 * mm * (r.rel || 1) * (0.4 + util), 0.05, 1);
    tot += r.cond * r.cost;
    w += r.cost;
    eqv += r.cost;
    const m = r.cost * mc / 52 * (1 - fixDisc(co));
    payCo(co, m, 'oth');
    if (co.maint === 2) r.cond = clamp(r.cond + 0.0009, 0, 1);
  }
  co.veh.forEach(v => {
    const m = VEH[v.model];
    const dep = v.cost * (window.R23 && R23.vehDep ? R23.vehDep(m) : 0.15) / 52;
    const d = Math.min(v.bv, dep);
    v.bv -= d;
    bk(co, 'dep', d);
    v.cond = clamp(v.cond - 0.0014 * mm * (v.rel || 1) * (0.4 + util), 0.05, 1);
    tot += v.cond * v.cost;
    w += v.cost;
    eqv += v.cost;
    v.km += (BD[co.type].tw.km || 500) / Math.max(1, co.veh.length) * util;
    payCo(co, v.cost * mc * 1.3 / 52, 'oth');
  });
  for (const id in (co.eqL || {})) {
    payCo(co, co.eqL[id] / 4.33, 'oth');
  }
  co.eqc = w ? tot / w : 1;
  co.eqv = eqv;
}
/* buyVeh: steps before ('buyVeh.before') and after ('buyVeh.after'): pipeSteps('buyVeh.after') */
function buyVeh(co, eqId, modelId, mode, cat) {
  return runPhased('buyVeh', [co, eqId, modelId, mode, cat], () => buyVehCore(co, eqId, modelId, mode, cat));
}
function buyVehCore(co, eqId, modelId, mode, cat) {
  const bd = BD[co.type], e = bd.eq.find(x => x.id === eqId);
  const m = VEH[modelId];
  if (!e || !m) return 'bad';
  mode = mode || 'new';
  const infl = Math.pow(1 + S.econ.infl, S.week / 52);
  cat = cat || vehCat(modelId)[0];
  const base = rnl(m[1] * infl * cat.f * (window.R23 && R23.vehCtry ? R23.vehCtry(co) : 1), 1000);
  const price = Math.round(base * (mode === 'used' ? 0.52 : 1));
  const v = {
    id: uid(),
    eq: eqId,
    model: modelId,
    cost: price,
    bv: price,
    cond: mode === 'used' ? rng(0.55, 0.8) : 1,
    km: mode === 'used' ? rint(60000, 160000) : 0,
    mode: mode === 'lease' ? 'lease' : mode === 'finance' ? 'fin' : 'own',
    loan: 0,
    name: cat.brand + ' ' + cat.model + (mode === 'used' ? ' (used)' : ''),
    rel: cat.rel,
    rating: cat.rating
  };
  if (mode === 'lease') {
    v.bv = 0;
    v.lease = Math.round(base * 0.0215);
    v.cost = base;
  }
  else if (mode === 'finance') {
    const down = price * 0.2;
    if (co.cash < down) return 'cash';
    payCo(co, down, null, 'Down payment: ' + m[0]);
    const l = {
      id: uid(),
      kind: 'biz',
      name: 'Vehicle loan: ' + m[0],
      bal: price - down,
      margin: creditMargin() + 0.015,
      pay: 0,
      termM: 60,
      co: co.id,
      w0: S.week,
      guar: co.form === 'AS' ? 0 : 1 /* secured on the asset: a limited company's owner does not sign for it */
    };
    l.pay = annuity(l.bal, policy() + l.margin, 60);
    S.loans.push(l);
    v.loan = l.id;
  }
  else {
    if (co.cash < price) return 'cash';
    payCo(co, price, null, m[0]);
  }
  co.veh.push(v);
  return 'ok';
}
function sellVeh(co, vid) {
  const i = co.veh.findIndex(v => v.id === vid);
  if (i < 0) return 0;
  const v = co.veh[i];
  const val = v.mode === 'lease' ? 0 : Math.round(v.bv * 0.78);
  co.veh.splice(i, 1);
  if (val) coIn(co, val, null, 'Sold ' + v.name);
  if (v.loan) {
    const l = S.loans.find(x => x.id === v.loan);
    if (l) {
      const rest = l.bal;
      payCo(co, rest, null, 'Loan settled');
      l.bal = 0;
      S.loans = S.loans.filter(x => x !== l);
    }
  }
  return val;
}
function leaseWeek(co) {
  co.veh.forEach(v => {
    if (v.mode === 'lease') payCo(co, v.lease * 12 / 52, 'oth');
  });
}
/* premises */
function setPrem(co, kind, m2, buy, lst) {
  if (window.R37 && R37.placeKind) kind = R37.placeKind(co, kind, m2); /* a home trade that signs for space gets its kind of place */
  if (co.prem && co.prem.dep && !co.prem.owned) {
    coIn(co, co.prem.dep, null, 'Lease deposit returned');
    co.prem.dep = 0;
  }
  const bd = BD[co.type];
  const city = cityOf(co.city);
  const P = PREM[kind];
  if (!P || kind === 'home' || kind === 'none') {
    co.prem = { kind, m2: 0, rent: 0, owned: false, val: 0, loan: 0 };
    return 'ok';
  }
  const rf = lst ? lst.rentF : 1;
  const rent0 = P[1] * rf * city.rent * Math.pow(1 + S.econ.infl, S.week / 52);
  const rent = m2 > 0 ? rl(rent0 * m2 / 12) * 12 / m2 : rl(rent0);
  const fit = window.R21 ? R21.fitOf(co, kind, m2) : (FIT[kind] || 0) * m2;
  if (buy) {
    const price = Math.round(P[2] * rf * Math.pow(city.rent, 0.9) * m2 * S.econ.housing);
    const down = price * 0.35;
    if (co.cash < down + fit) return 'cash';
    payCo(co, down, null, 'Premises purchase (equity)');
    const l = {
      id: uid(),
      kind: 'biz',
      name: 'Commercial mortgage',
      bal: price - down,
      margin: Math.max(0.012, creditMargin() * 0.45) + 0.004,
      pay: 0,
      termM: 180,
      co: co.id,
      w0: S.week,
      guar: co.form === 'AS' ? 0 : 1 /* secured on the asset: a limited company's owner does not sign for it */
    };
    l.pay = annuity(l.bal, policy() + l.margin, 180);
    S.loans.push(l);
    co.prem = { kind, m2, rent: 0, owned: true, val: price, loan: l.id, cost: price };
  }
  else {
    const bl = co.franchise && co.franchise.bld;
    const rent2 = bl ? rent * 0.85 : rent;
    const dep = bl ? 0 : rent * m2 / 12 * 3;
    if (co.cash < dep + fit) return 'cash';
    if (dep) payCo(co, dep, null, 'Lease deposit (3 months)');
    co.prem = { kind, m2, rent: rent2, owned: false, val: 0, loan: 0, dep };
    co.docs.stat = { st: 'ok', done: S.week, ok: S.week };
  }
  if (lst && co.prem) {
    co.prem.loc = lst.loc;
    co.prem.lname = lst.n;
    co.prem.landlord = lst.landlord;
  }
  if (fit > 0) {
    payCo(co, fit, null, 'Fit-out of premises');
    co.eq.fit = { n: 1, cond: 1, bv: fit, cost: fit, used: 0, age: 0, life: 10 };
  }
  return 'ok';
}
/* rentWeek: steps before ('rentWeek.before') and after ('rentWeek.after'): pipeSteps('rentWeek.after') */
function rentWeek(co) {
  return runPhased('rentWeek', [co], () => rentWeekCore(co));
}
function rentWeekCore(co) {
  if (!co.prem || co.prem.owned || !co.prem.m2) return 0;
  if (S.week > 0 && S.week % 52 === 0) co.prem.rent = rl(co.prem.rent * (1 + Math.max(0, S.econ.infl)));
  const r = co.prem.rent * co.prem.m2 / 52;
  if (co.landlord) {
    leaseNote(co);
    const L = getCo(co.landlord.co);
    if (L && L.st === 'open') coIn(L, r * 0.97, 'rev', 'Rent from ' + co.name);
  }
  co.pay.rent = (co.pay.rent || 0) + r;
  bk(co, 'rent', r);
  return r;
}
function premValueWeek(co) {
  if (co.prem && co.prem.owned && co.prem.val > 0) {
    const h0 = co.prem.hw || S.econ.housing;
    co.prem.val *= S.econ.housing / h0;
    co.prem.hw = S.econ.housing;
    payCo(co, co.prem.val * 0.01 / 52, 'oth');
  }
}
/* marketing */
function setMkt(co, ch, budget) {
  const c = CH[ch];
  if (!c || !chOk(co, ch)) return 'bad';
  const cur = co.mkt[ch];
  if (budget <= 0) {
    if (cur && cur.lock && S.week < cur.lock) return 'locked:' + (cur.lock - S.week);
    delete co.mkt[ch];
    return 'ok';
  }
  if (cur) {
    if (budget < cur.b && cur.lock && S.week < cur.lock) return 'locked:' + (cur.lock - S.week);
    cur.b = budget;
    return 'ok';
  }
  co.mkt[ch] = { b: budget, since: S.week, lock: S.week + c.mw };
  return 'ok';
}
function mktCost(co) {
  return sum(Object.keys(co.mkt), k => co.mkt[k].b);
}
/* The weekly marketing turn: the campaigns you pay for raise awareness (mktWeekCore). Steps before and after it
   end campaigns on their date, count new customers and cost per customer, add startup products, real customers
   from campaigns (with churn and SEO) and organic awareness: pipeSteps('mktWeek.before'), pipeSteps('mktWeek.after').
   Before-steps leave notes for after-steps in ctx. */
function mktWeek(co, bd) {
  runAround('mktWeek.around', co, () => {
    const ctx = {};
    runSteps('mktWeek.before', ctx, co, bd);
    mktWeekCore(co, bd);
    runSteps('mktWeek.after', ctx, co, bd);
  });
}
function mktWeekCore(co, bd) {
  const city = cityOf(co.city);
  const mkF = S.cos.find(c => c.type === 'mktg' && c.st === 'open' && c.id !== co.id);
  let gain = 0, spend = 0, premActive = 0;
  const scale = Math.max(0.5, bd.Dc * bd.ticket / 8000);
  for (const k in co.mkt) {
    const m = co.mkt[k], c = CH[k];
    const aud = bd.aud, fit = (1 - aud) * (c.loc || 0.5) + aud * (c.b2b || 0.5);
    const sc = c.sc * Math.max(0.4, Math.min(8, scale * 0.9));
    let eff = c.eff * (1 - Math.exp(-m.b / sc)) * (0.45 + fit);
    if (c.var) eff *= c.prem ? (chance(0.18) ? 1.7 : (chance(0.6) ? 0.55 : 0.9)) : (chance(0.12) ? 3.0 : (chance(0.55) ? 0.35 : 0.9));
    if (c.nat) eff *= natFit(co);
    eff *= chAff(bd, k);
    if (c.prem) premActive = 1;
    if (c.slow) eff *= clamp((S.week - m.since) / 26, 0.2, 1.4);
    if (c.loyal) eff *= 0.6 + co.aware / 100;
    gain += eff * (mkF ? 1.1 : 1);
    spend += m.b;
  }
  if (spend > 0) {
    const fee = spend;
    payCo(co, fee, 'mkt', null);
    if (mkF) {
      coIn(mkF, fee * 0.85, 'rev', 'Marketing for ' + co.name);
    }
  }
  if (co.wom > 0.4) {
    gain += co.wom * 0.2;
    co.wom *= 0.88;
  } else co.wom = 0;
  if (hasHQ('mkt')) gain *= 1.1;
  co.aware = clamp(co.aware * awareDecay(co) + gain, 0, 100);
  awareSpill(co, gain);
  viralRoll(co, premActive);
}
/* insurance */
function insPremium(co, k) {
  const p = INSP[k];
  const bd = BD[co.type];
  const base = k === 'prop' ? Math.max(100000, eqBook(co) + co.inv + (co.prem && co.prem.owned ? co.prem.val : 0) * 0.5) : Math.max(120000, (co.bk.y.rev || co.lastW && co.lastW.rev * 52 || 400000));
  return Math.round(base * p[3] / 52 * (1 + (co.flags['riskUp'] ? 0.4 : 0)) * insrMult(co));
}
function insWeek(co) {
  const own = co.insr && co.insr.own ? getCo(co.insr.own) : null;
  let t = 0;
  for (const k in co.ins) {
    if (!co.ins[k]) continue;
    const pr = insPremium(co, k);
    t += pr;
  }
  if (t > 0) {
    payCo(co, t, 'ins', null);
    if (own) {
      coIn(own, t * 0.85, 'rev', 'Premium from ' + co.name);
      own.fm.prem = (own.fm.prem || 0) + t * 0.85;
    }
  }
}
function hasIns(co, cat) {
  return !!co.ins[cat];
}
/* accountants and conversion */
function pickAccountant(co, accId) {
  if (co && co.acc && accId === co.acc.id) return true; /* already their accountant */
  if (typeof accId === 'string' && accId.indexOf('own') === 0) { const oc = getCo(+accId.slice(3)) || getCo(accId.slice(3)); if (oc && oc.st === 'open') { pickOwn(co, 'acc', oc); return true; } }
  const pa = poolFor(co.country).acc;
  const a = pa.find(x => x.id === accId) || pa[1];
  if (!a) return false;
  co.acc = { id: a.id, name: a.name, tier: a.tier, fee: a.fee, q: a.q, err: a.err, rating: a.rating, w0: S.week };
  if (co.docs.acctr) {
    co.docs.acctr = { st: 'ok', done: S.week, ok: S.week };
  } else co.docs.acctr = { st: 'applied', done: S.week + 1, w0: S.week };
  return true;
}
function accWeek(co) {
  lawWeek(co);
  const f = (co.acc ? co.acc.fee : (co.form === 'ENK' ? KC(480, co.country) : 0)) * (hasHQ('acc') ? 0.8 : 1);
  const sz = Math.max(1, Math.pow(((co.staff ? co.staff.length : 0) + (co.mgr ? 1 : 0)) / 8, 0.6));
  const amt = f * sz * Math.pow(1 + Math.max(0, S.econ.infl), S.week / 52) * 12 / 52;
  payCo(co, amt, 'oth', null);
  /* your own accountant office keeps the fee in the group */
  if (co.acc && co.acc.own && amt > 0) { const o = getCo(co.acc.own); if (o && o.st === 'open' && o.id !== co.id) coIn(o, amt, 'rev', 'Accounting for ' + co.name); }
}
function convertToAS(co, accId) {
  /* when your own cash is short, the share capital may come from the business's own cash */
  try {
    const c = CC(), need = c.asCapital + c.asConvFee;
    if (co.form !== 'AS' && S.cash < need && S.cash + Math.max(0, co.cash) >= need) {
      const x = need - Math.max(0, S.cash);
      moveCash(co, -x);
      moveCash(ME, x, 'From ' + co.name + ' for the share capital', co.id);
    }
  } catch (e) { console.error(e); }
  if (co.form === 'AS') return 'already';
  const c = CC();
  const need = c.asCapital + c.asConvFee;
  if (S.cash < need) return 'cash';
  if (!pickAccountant(co, accId)) return 'acc';
  payMe(c.asConvFee, 'Registration and conversion fee');
  payMe(c.asCapital, 'Share capital');
  moveCash(co, c.asCapital);
  ownerFlow(co, c.asCapital);
  co.capital = c.asCapital;
  co.inj += c.asCapital;
  S.tax.enkFrozen = (S.tax.enkFrozen || 0) + ((co.bk.y.rev || 0) - sumExp(co.bk.y));
  co.bk.y = {};
  co.form = 'AS';
  co.docs.acctr = { st: 'ok', done: S.week, ok: S.week };
  co.docs.org = { st: 'ok', done: S.week, ok: S.week };
  S.loans.forEach(l => {
    if (l.co === co.id) l.guar = 1;
  });
  note(co.name + ' is now a ' + CC().forms.AS.replace(/ \(.*\)/, '').toLowerCase() + ' (' + CC().forms.ASs + '). Accountant: ' + co.acc.name + '.', 'good', co.id);
  return 'ok';
}
/* injection and withdrawal */
function injectCash(co, amt) {
  if (liquid() < amt) return false;
  fromSavings(amt);
  moveCash(ME, -(amt), 'Invested in ' + co.name, co.id);
  moveCash(co, amt);
  ownerFlow(co, amt);
  if (co.form === 'AS') co.inj += amt;
  co.tx.unshift({ w: S.week, a: amt, l: 'Owner investment' });
  return true;
}
function withdrawCash(co, amt) {
  if (co.form === 'ENK') {
    if (co.cash < amt) return 'cash';
    moveCash(co, -(amt));
    ownerFlow(co, -amt);
    gainMe(amt, 'Drawing from ' + co.name);
    co.dist += amt;
    co.tx.unshift({ w: S.week, a: -amt, l: 'Owner drawing' });
    return 'ok';
  }
  return 'divonly';
}
/* most that can go out as a dividend now: profits kept (equity over share capital), leaving two weeks of costs in cash */
function divMax(co) {
  return Math.max(0, Math.floor(Math.min(companyAssets(co) - companyDebts(co) - co.capital, co.cash - coWeekCost(co) * 2)));
}
function payDividend(co, amt) {
  if (co.form !== 'AS') return 'notAS';
  const eq = companyAssets(co) - companyDebts(co) - co.capital;
  if (amt > eq) return 'noequity';
  if (co.cash - amt < coWeekCost(co) * 2) return 'cash';
  moveCash(co, -(amt));
  ownerFlow(co, -amt);
  co.tx.unshift({ w: S.week, a: -amt, l: 'Dividend' });
  const mine = amt * co.own / 100;
  const hh = co.hold && getCo(co.hold);
  if (hh && hh.st !== 'sold' && hh.st !== 'bust') {
    moveCash(hh, mine);
    hh.tx.unshift({ w: S.week, a: mine, l: 'Dividend from ' + co.name });
  } else {
    gainMe(mine, 'Dividend from ' + co.name);
    S.tax.ytdDiv = (S.tax.ytdDiv || 0) + mine;
    S.stats.dividends += mine;
  }
  {
    const sh = CC().shield || 0;
    S.tax.shield = Math.max(S.tax.shield || 0, sum(liveCos().filter(c => c.form === 'AS'), c => (c.inj || 0) * c.own / 100) * sh);
  }
  co.holders.forEach(h => { /* outside holders get their share */ });
  co.dist += amt;
  return 'ok';
}
function setOwnerSalary(co, m) {
  if (co.form !== 'AS') return false;
  co.ownerSalary = Math.max(0, rnl(m, 100));
  return true;
}
/* cost estimate for overdraft */
function coWeekCost(co) {
  const bd = BD[co.type];
  const staff = sum(co.staff, s => s.wage) * 12 / 52 * OC() + (co.mgrWage || 0) * 12 / 52 * OC();
  const rent = co.prem && !co.prem.owned && co.prem.m2 ? co.prem.rent * co.prem.m2 / 52 : 0;
  return staff + rent + bd.fixed * Math.pow(co.size, 0.6) + mktCost(co) + (co.lastW ? co.lastW.cogs || 0 : 0) * 0.5;
}


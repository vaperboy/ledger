/* ---- src/company/reviews.js ---- */
/* ===== Customer reviews (Trustpilot-style), tourists by country, local job titles ===== */
const TOUR_T = {
  hotel: 1,
  fun: 1,
  casino: 0.8,
  nightclub: 0.9,
  restaurant: 0.8,
  cafe: 0.7,
  foodtruck: 0.7,
  taxi: 0.6,
  airline: 0.8,
  boutique: 0.5,
  kiosk: 0.5,
  photo: 0.5,
  bakery: 0.3,
  gym: 0.1,
  carrental: 0.9, /* round 57 */
  vineyard: 0.4,
  pcbang: 0.1
};
const RV_POS = [
  'Friendly staff and good quality.',
  'Fast service, will come back.',
  'Fair price for what you get.',
  'Exactly what we hoped for.',
  'Clean, well run and professional.',
  'Staff really went the extra mile.',
  'Great value, easy to recommend.'
];
const RV_MID = [
  'Okay, nothing special.',
  'Decent, but nothing to write home about.',
  'Fine for the price.',
  'Good once, uneven the next time.',
  'Average. Could be better organised.'
];
const RV_NEG = [
  'Long wait and an unhelpful answer.',
  'Not what was promised.',
  'Quality has gone down.',
  'Rude staff and no apology.',
  'Would not use again.',
  'Messy and badly organised.'
];
const RV_PRICE = ['Good, but quite expensive.', 'Overpriced for what it is.', 'Too expensive for the quality.'];
const RV_CHEAP = ['Very cheap and still good.', 'Great prices.', 'Cheap, and you can tell.'];
const RV_WAIT = ['Always crowded and slow.', 'Too busy, long queues.'];
const RV_T = ['Excellent', 'Very good', 'Good', 'Solid', 'Reliable', 'Fair', 'Mixed', 'Poor', 'Disappointing', 'Avoid'];
function isoFlag(c) {
  return CO[c] && CO[c].flag || '';
}
function tourShare(co) {
  const bd = BD[co.type];
  return Math.min(0.5, (TOURISM[co.country] || 0.1) * (TOUR_T[co.type] || 0.05));
}
function rvRate(type) {
  const bd = BD[type];
  if (!bd) return 0;
  const f = bd.fam;
  if (['fin', 'energy', 'hold', 'rent'].indexOf(f) >= 0) return 0.0015;
  const b2b = {
    factory: 1,
    engcons: 1,
    construction: 1,
    shipping: 1,
    trucking: 1,
    courier: 1,
    salmon: 1,
    farm: 1,
    mktg: 1,
    webdev: 1,
    staffing: 1,
    acctfirm: 1,
    cons: 1,
    oilgas: 1,
    power: 1,
    fund: 1
  };
  /* big jobs get reviewed far more often than a coffee: a family that paid for a new kitchen writes about it */
  return Math.min(0.3, (b2b[type] ? 0.0015 : 0.006) * Math.max(1, Math.sqrt((bd.ticket || 100) / 40)));
}
function ratingOf(co) {
  return Math.round(clamp(1.8 + (co.q * 0.6 + co.rep * 0.4) / 100 * 3.1, 1.5, 4.9) * 10) / 10;
}
function rivalRating(r, bd) {
  const R = hrng(S.seed + ':rr:' + r.id);
  return Math.round(clamp(2.6 + R() * 1.9 + (r.size - 1) * 0.4, 1.8, 4.8) * 10) / 10;
}
/* weekly reviews: keeps the history of units sold; trades that work in hours and companies whose reviews already
   came in day by day this week get none here */
function rvWeek(co) {
    if (!co.lastW) return;
    co.uh = co.uh || [];
    co.uh.push(co.lastW.units || 0);
    if (co.uh.length > 40) co.uh.shift();
    if (R41.isHT(co) || co.rvD41 === S.week - 1) return;
    const u = co.lastW.units || 0;
    co.rvF = (co.rvF || 0) + Math.min(u * rvRate(co.type), 30 + 3 * Math.sqrt(u));
    const n = Math.floor(co.rvF);
    if (n > 0) { co.rvF -= n; R41.addReviews(co, Math.min(n, 60)); }
}
/* star distribution that matches the true rating */
function starDist(mu) {
  const w = [1, 2, 3, 4, 5].map(s => Math.exp(-Math.pow(s - mu, 2) / 1.5) + (s === 1 ? 0.05 : 0) + (s === 5 ? 0.06 : 0));
  const t = sum(w, x => x);
  return w.map(x => x / t);
}
function pickStar(R, mu) {
  const d = starDist(mu);
  let x = R();
  for (let i = 0; i < 5; i++) {
    if (x < d[i]) return i + 1;
    x -= d[i];
  }
  return 5;
}
function pickW(R, spec) {
  const a = spec.split(',').map(x => x.split(':'));
  const t = sum(a, x => +x[1]);
  let x = R() * t;
  for (const e of a) {
    if (x < +e[1]) return e[0];
    x -= +e[1];
  }
  return a[0][0];
}
/* the latest reviews of a business, deterministic from its id */
function reviewsOf(id, type, country, mu, count, price, n, perWeek) {
  const out = [];
  const bd = BD[type];
  const share = Math.min(0.5, (TOURISM[country] || 0.1) * (TOUR_T[type] || 0.05));
  for (let i = 0; i < Math.min(n, count); i++) {
    const R = hrng(S.seed + ':rv:' + id + ':' + (count - i));
    const stars = pickStar(R, mu);
    let origin = country, foreign = false;
    if (R() < share && ORIG[country]) {
      origin = pickW(R, ORIG[country]);
      foreign = true;
    }
    const C = CO[origin] || CO[country];
    const nm = C.first[Math.floor(R() * C.first.length)] + ' ' + C.last[Math.floor(R() * C.last.length)][0] + '.';
    let tx = stars >= 4 ? RV_POS[Math.floor(R() * RV_POS.length)] : stars === 3 ? RV_MID[Math.floor(R() * RV_MID.length)] : RV_NEG[Math.floor(R() * RV_NEG.length)];
    if (price > 0 && stars <= 4 && R() < 0.5) tx = RV_PRICE[Math.floor(R() * RV_PRICE.length)]; else if (price < 0 && stars >= 4 && R() < 0.5) tx = RV_CHEAP[Math.floor(R() * RV_CHEAP.length)];
    if (foreign) {
      const ad = liveCos().some(c => c.type === type && c.country === origin && c.mkt && c.mkt['prem_' + origin]);
      tx = ad ? 'Heard about them in ' + (AD_HEARD[origin] || 'a TV ad') + ' back home. ' + (stars >= 4 ? 'Very good.' : stars === 3 ? 'It was okay.' : 'Did not live up to it.') : (R() < 0.5 ? 'On holiday here. ' : 'Found it while travelling. ') + tx;
    }
    const AR = hrng(S.seed + ':ag:' + id + ':' + (count - i));
    let hh = 0; String(id + type).split('').forEach(ch => { hh = (hh * 31 + ch.charCodeAt(0)) % 1000; });
    const sweet = 24 + hh % 28 + (price > 0 ? 6 : price < 0 ? -4 : 0), gz = (AR() + AR() + AR() - 1.5) * 2;
    let age = stars >= 4 ? sweet + gz * 9 : stars <= 2 ? sweet + (AR() < 0.5 ? -1 : 1) * (10 + AR() * 10) + gz * 6 : sweet + gz * 14;
    age = Math.round(Math.max(18, Math.min(78, age)));
    const ov11 = window.R11NRV ? window.R11NRV(id, count - i) : null;
    out.push({
      a: age,
      g: AR() < 0.5 ? 'F' : 'M',
      n: nm,
      st: ov11 ? ov11.st : stars,
      tx: ov11 ? ov11.tx : tx,
      flag: foreign ? isoFlag(origin) : '',
      w: S.week - Math.floor(i / Math.max(0.3, perWeek))
    });
  }
  return out;
}
/* reviewList: the core below, then the steps features add: pipeSteps('reviewList') */
function reviewList(filter) {
  return runSteps('reviewList', reviewListCore(filter), filter);
}
function reviewListCore(filter) {
  const L = [];
  const mine = liveCos().filter(c => ['hold'].indexOf(c.type) < 0 && c.st !== 'sold');
  mine.forEach(c => {
    if (BD[c.type].fam === 'club' || true) L.push({
      key: 'c' + c.id,
      co: c,
      name: c.name,
      type: c.type,
      city: c.city,
      country: c.country,
      rt: ratingOf(c),
      n: c.rvN || 0,
      mine: 1,
      price: c.price,
      per: Math.max(0.3, (c.lastW ? c.lastW.units : 0) * rvRate(c.type))
    });
  });
  if (filter !== 'mine') {
    const seen = {};
    mine.forEach(c => {
      if (seen[mkKey(c)] || ['fin', 'energy', 'hold', 'club'].indexOf(BD[c.type].fam) >= 0) return;
      seen[mkKey(c)] = 1;
      let rl = [];
      try {
        rl = rivalsOf(c) || [];
      } catch (e) { }
      rl.forEach(r => {
        const bd = BD[c.type];
        const per = Math.min(((bd.Dc || 30) * 7) * r.size * 0.5, 600) * rvRate(c.type);
        L.push({
          key: 'r' + r.id,
          name: r.name,
          type: c.type,
          city: c.city,
          country: c.country,
          rt: rivalRating(r, bd),
          n: Math.floor((80 + S.week) * per * 0.6),
          mine: 0,
          price: 0,
          per: Math.max(0.3, per) ,
          rid: r.id
        });
      });
    });
  }
  return L;
}
function rvComment(r) {
  return r >= 4.6 ? 'Outstanding' : r >= 4.2 ? 'Very good' : r >= 3.8 ? 'Good' : r >= 3.4 ? 'Decent' : r >= 3 ? 'Mixed' : r >= 2.5 ? 'Poor' : 'Avoid';
}
/* vendors and brands get a rating and a short comment too */
function vendRating(v) {
  return Math.round(clamp(3.6 + v.q * 2.2, 2.6, 4.8) * 10) / 10;
}
function eqComment(rt) {
  return rt >= 4.5 ? 'Built to last' : rt >= 4.1 ? 'Reliable, good value' : rt >= 3.7 ? 'Solid choice' : rt >= 3.3 ? 'Does the job' : rt >= 2.9 ? 'Mixed reviews' : 'Breaks often';
}
/* job titles that fit the company and the country */
const TYPE_MGR = {
  cafe: 'Café manager',
  restaurant: 'Restaurant manager',
  foodtruck: 'Operations lead',
  nightclub: 'Venue manager',
  gym: 'Club manager',
  hotel: 'Hotel manager',
  casino: 'Casino manager',
  fun: 'Park manager',
  kiosk: 'Store manager',
  boutique: 'Store manager',
  grocery: 'Store manager',
  hardware: 'Store manager',
  cardealer: 'Dealership manager',
  webshop: 'Head of e-commerce',
  construction: 'Site manager',
  electrician: 'Operations manager',
  plumber: 'Operations manager',
  realdev: 'Project director',
  event: 'Production manager',
  engcons: 'Engineering manager',
  bakery: 'Bakery manager',
  brewery: 'Brewmaster',
  furniture: 'Workshop manager',
  salmon: 'Farm manager',
  farm: 'Farm manager',
  factory: 'Plant manager',
  taxi: 'Fleet manager',
  courier: 'Depot manager',
  trucking: 'Transport manager',
  shipping: 'Fleet manager',
  airline: 'Operations director',
  resrent: 'Property manager',
  comrent: 'Property manager',
  parking: 'Facility manager',
  insco: 'Managing director',
  bank: 'Branch director',
  fund: 'Managing partner',
  power: 'Plant manager',
  oilgas: 'Field manager',
  law: 'Managing partner',
  acctfirm: 'Managing partner',
  mktg: 'Agency director',
  webdev: 'Studio lead',
  staffing: 'Branch manager',
  cons: 'Principal',
  club: 'Club director'
};
function titleFor(co, kind) {
  const code = co && co.country || S.country, T = LOCAL_T[code] || LOCAL_T.UK;
  const g = TYPE_MGR[co && co.type] || 'General manager';
  if (kind === 'asst') return 'Assistant ' + g.toLowerCase();
  if (kind === 'lead') return T[2];
  if (kind === 'chainmgr') return 'Chain manager';
  if (kind === 'ceo56') return 'CEO';
  if (kind === 'md') return 'Managing director';
  if (kind === 'region') return co && co.chain ? 'Regional manager' : T[3];
  if (kind === 'ceo') return T[4];
  if (kind === 'mdir') return ({ US: 'CEO', CA: 'CEO', KR: 'CEO', JP: 'President' })[code] || 'Managing director';
  if (co && kind !== 'asst' && typeof chainOutlets === 'function' && chainOutlets(co) > 1 && /manager$/i.test(g)) return 'Area manager';
  const n = co && co.staff ? co.staff.length : 0;
  if (co && kind === 'mgr') {
    if (n >= 60) return T[0];
    if (n >= 25 && /manager$/i.test(g)) return 'Senior ' + g.charAt(0).toLowerCase() + g.slice(1);
  }
  return g;
}
/* a title inside a sentence: 'Store manager' -> 'store manager', but 'CEO' stays 'CEO' */
function titleLow(t) {
  t = String(t || '');
  return /^[A-Z]{2,}/.test(t) ? t : t.charAt(0).toLowerCase() + t.slice(1);
}
/* ladder: who can reach the owner */
function aboveMgr(co) {
  if (S.group.ceo && S.npcs[S.group.ceo.npc]) return { kind: 'ceo', npc: S.npcs[S.group.ceo.npc] };
  const rg = co.region ? S.group.regional.find(r => r.id === co.region) : null;
  if (rg && S.npcs[rg.npc]) return { kind: 'region', npc: S.npcs[rg.npc] };
  return null;
}
function virtName(co, kind) {
  const R = hrng(S.seed + ':vn:' + kind + ':' + co.id);
  const C = CO[co.country] || CC();
  return C.first[Math.floor(R() * C.first.length)] + ' ' + C.last[Math.floor(R() * C.last.length)];
}
function hasVirt(co, kind) {
  if (!co.mgr || aboveMgr(co)) return false;
  const n = co.staff ? co.staff.length : 0;
  return kind === 'asst' ? n >= 12 : n >= 6;
}
function sender(co, n) {
  const ls = !aboveMgr(co) && co.staff && co.staff.find(x => x.role === 'lead');
  if (ls && S.npcs[ls.id] && chance(0.5)) return { name: S.npcs[ls.id].name, role: titleFor(co, 'lead') };
  return { name: n.name, role: titleFor(co, 'mgr') };
}
function contactRoster() {
  const R = [], seen = {};
  const add = (name, role, co) => {
    const k = name + '|' + role;
    if (seen[k]) return;
    seen[k] = 1;
    R.push({ name, role, co: co ? co.name : '' });
  };
  liveCos().forEach(co => {
    if (!co.mgr || !S.npcs[co.mgr]) return;
    add(S.npcs[co.mgr].name, titleFor(co, 'mgr'), co);
    if (!aboveMgr(co)) {
      const ls = co.staff && co.staff.find(q => q.role === 'lead');
      if (ls && S.npcs[ls.id]) add(S.npcs[ls.id].name, titleFor(co, 'lead'), co);
    }
  });
  if (S.group.ceo && S.npcs[S.group.ceo.npc]) add(S.npcs[S.group.ceo.npc].name, titleFor(null, 'ceo'), null); else S.group.regional.forEach(r => {
    if (S.npcs[r.npc]) add(S.npcs[r.npc].name, titleFor({ country: S.country }, 'region'), null);
  });
  if (S.office && S.office.staff) S.office.staff.forEach(x => {
    const r = hqRole(x.role);
    if (r && x.name) add(x.name, r[0], null);
  });
  knownVendors().forEach(v => {
    if (vrel(v.id) >= 8) add(v.owner, 'Supplier · ' + v.name, null);
  });
  return R;
}

/* Messages are people you already know; Email is everyone else (authorities, invitations, unknown senders, rivals) */
function knownNames() {
  const k = {};
  contactRoster().forEach(c => {
    k[c.name] = 1;
  });
  if (S.office && S.office.staff) S.office.staff.forEach(x => {
    k[x.name] = 1;
  });
  return k;
}
function isKnownMsg(m, kn) {
  kn = kn || knownNames();
  if (m.kind === 'invite' || m.kind === 'offer') return false;
  return !!kn[m.from] || (m.kind === 'ask' && !!m.role);
}
function unreadSplit() {
  const kn = knownNames();
  let a = 0, b = 0;
  S.inbox.forEach(m => {
    if (m.status === 'open' || !m.read) {
      if ((m.ch || (isKnownMsg(m, kn) ? 'msg' : 'mail')) === 'msg') a++; else b++;
    }
  });
  return { msgs: a, mail: b };
}
/* feelings instead of numbers */
function awWord(x) {
  return x < 12 ? 'Hardly anyone knows you' : x < 28 ? 'A few locals know you' : x < 45 ? 'Known in your area' : x < 62 ? 'Well known in town' : x < 80 ? 'A familiar name' : 'Everyone knows you';
}
function repWord(x) {
  return x < 30 ? 'People avoid you' : x < 45 ? 'Mixed feelings' : x < 60 ? 'Seen as decent' : x < 75 ? 'Well liked' : x < 88 ? 'Highly regarded' : 'Loved';
}
function buzzWord(x) {
  return x > 40 ? 'Everyone is talking about you' : x > 15 ? 'A real buzz' : 'Some chatter';
}
/* the data analyst: how well can he read the market? */
function analystSkill() {
  const st = S.office && S.office.staff ? S.office.staff.find(x => x.role === 'ana') : null;
  const n = st ? S.npcs[st.id] : null;
  return n ? (n.skill || 50) : 0;
}
function analystAcc() {
  const k = analystSkill();
  return k ? clamp((k - 30) / 60, 0.1, 1) : 0;
}
function marketOutlook(co) {
  const a = analystAcc();
  if (!a) return null;
  const rc = reachOf(co);
  const R = hrng(S.seed + ':ol:' + co.id + ':' + Math.floor(S.week / 13));
  const sd = (1 - a) * 0.12;
  const est = (v, scale) => {
    const m = v + (R() - 0.5) * 2 * sd * scale;
    const w = (1 - a) * 0.5 * scale + 0.002;
    return [Math.max(0, m - w), m + w];
  };
  const h = (co.uh || []).slice(-12);
  let fc = [];
  if (h.length >= 4) {
    const n = h.length, mx = (n - 1) / 2, my = sum(h, x => x) / n;
    let num = 0, den = 0;
    h.forEach((y, i) => {
      num += (i - mx) * (y - my);
      den += (i - mx) * (i - mx);
    });
    const sl = den ? num / den : 0;
    for (let k = 1; k <= 8; k++) fc.push(Math.max(0, my + sl * (n - 1 - mx + k) * 0.8 * (1 + (R() - 0.5) * 2 * sd * 2)));
  }
  return { a, lift: est(rc.mult - 1, 0.2), save: est(rc.rebate, 0.06), hist: h, fc, top: a >= 0.9 };
}

const RV_MIN = 3;
function rvStars(rt, n) {
  return n < RV_MIN ? '<span class="stars" style="--w:0%"></span> <small>No reviews yet</small>' : stars(rt, n);
}
function rvWordN(rt, n) {
  return n < RV_MIN ? 'No rating yet' : rvComment(rt);
}


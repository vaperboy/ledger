/* ---- src/company/model.js ---- */
/* ===== Weekly company model (common part). Family models plug in via FAM. ===== */
const FAM = {};
const DK = 1.25;
const SENS = { svc: 0.7, venue: 1.0, retail: 0.9, project: 1.1, prod: 0.8, logi: 0.8, rent: 0.5, fin: 0.4, energy: 0.0 };
/* modProd: the core below, then the steps features add: pipeSteps('modProd') */
function modProd(co, k) {
  return runSteps('modProd', modProdCore(co, k), co, k);
}
function modProdCore(co, k) {
  let m = 1;
  co.mods.forEach(x => {
    if (x.k === k) m *= x.m;
  });
  return m;
}
function addMod(co, k, m, w) {
  co.mods.push({ k, m, w: Math.round(w) });
}
function mkKey(co) {
  return co.type + '|' + co.city;
}
/* mgrFTE: defined in features/people/managers_who_work.js (managers who work) */
/* shops, food, hotels, gyms and clinics live off passing trade; offices, halls and yards live off transport */
function isFoot(kind) {
  return ['shop', 'kitchen', 'hotel', 'gym', 'clinic'].indexOf(kind) >= 0;
}
const PRICE_PM = [0.7, 0.8, 0.9, 1, 1.15, 1.4, 1.9];
const PRICE_NAMES = ['Budget', 'Low-cost', 'Below average', 'Average', 'Above average', 'Premium', 'Luxury'];
function pLvl(co) {
  return clamp(Math.round(co.price || 0), -3, 3);
}
function priceMult(co) {
  return PRICE_PM[pLvl(co) + 3];
}
/* luxury needs a name: small unknown brands lose most customers, established ones keep them */
function brandPull(co) {
  return clamp(((co.rep || 0) + (co.aware || 0)) / 170, 0, 1);
}
/* priceDem: defined in features/sales/price_moves_and_lawsuits.js (prices in percent) */
/* ticketMult: the core below, then the steps features add: pipeSteps('ticketMult') */
function ticketMult(co, bd) {
  return runSteps('ticketMult', ticketMultCore(co, bd), co, bd);
}
function ticketMultCore(co, bd) {
  return knobFx(co, 't') * priceMult(co) * cityOf(co.city).price * Math.pow(1 + S.econ.infl, S.week / 52);
}
function repMult(co) {
  return 0.6 + 0.8 * co.rep / 100;
}
/* mktMult: the core below, then the steps features add: pipeSteps('mktMult') */
function mktMult(co) {
  return runSteps('mktMult', mktMultCore(co), co);
}
function mktMultCore(co) {
  return 0.75 + 0.7 * co.aware / 100;
}
/* rivalMult: defined in features/sales/price_moves_and_lawsuits.js, adjusted in features/world/rivals_run_businesses.js */
function seasOf(bd) {
  return SEAS[bd.seas][wMonth(S.week)];
}
/* Your own outlets of the same trade in the same city share its customers. How much two of them overlap depends on
   the city (in a small town they fish in the same pond, in a big city much less) and, for trades customers walk
   into, on where they are: two in the centre overlap more, a neighbourhood unit draws mostly its own street. */
const cityOverlap = city => clamp(0.25 * Math.sqrt(300 / (cityOf(city).pop || 100)), 0.12, 0.8);
function ownOverlap(a, b) {
  let ov = cityOverlap(a.city);
  const ti = c => c.prem && c.prem.lname ? PL_TIERS.findIndex(t => t[0] === c.prem.lname) : -1;
  if (a.prem && isFoot(a.prem.kind)) {
    const x = ti(a), y = ti(b);
    if (x >= 3 && y >= 3) ov *= 1.6;
    else if ((x >= 0 && x <= 1) || (y >= 0 && y <= 1)) ov *= 0.6;
  }
  return Math.min(0.9, ov);
}
function ownShare(co) {
  let t = 0;
  S.cos.forEach(c => { if (c !== co && c.st === 'open' && c.type === co.type && c.city === co.city && (c.country || S.country) === (co.country || S.country)) t += ownOverlap(co, c); });
  return 1 / (1 + t);
}
/* demand: how many customers want to buy this week (r.D) and why (r.parts). demandCore is the market model;
   the 'demand' steps add what features change: equipment and car classes, local price levels, startup products,
   campaigns, affordability, commodities, gifts to the city, goals, ways to sell, premises: pipeSteps('demand'). */
function demand(co, bd) {
  return runSteps('demand', demandCore(co, bd), co, bd);
}
function demandCore(co, bd) {
  const parts = { base: bd.Dc };
  let D = bd.Dc * DK * cityOf(co.city).dem;
  parts.city = cityOf(co.city).dem;
  const se = seasOf(bd);
  D *= se;
  parts.season = se;
  const mk = mktMult(co);
  D *= mk;
  parts.marketing = mk;
  const chm = reachOf(co).mult;
  D *= chm;
  parts.chain = chm;
  const hy = 1 + (co.hype || 0) * 0.006;
  D *= hy;
  parts.buzz = hy;
  const rp = repMult(co);
  D *= rp;
  parts.reputation = rp;
  const pe = priceDem(co, bd);
  D *= pe;
  if (co.prem && co.prem.loc && isFoot(co.prem.kind)) D *= co.prem.loc;
  parts.price = pe;
  const kd = knobFx(co, 'd');
  D *= kd;
  parts.choices = kd;
  const ec = 1 + (S.econ.dem - 1) * (SENS[bd.fam] || 0.8);
  D *= ec;
  parts.economy = ec;
  const rv = rivalMult(co, bd);
  D *= rv;
  parts.rivals = rv;
  const ow = ownShare(co);
  D *= ow;
  if (ow < 1) parts.own = ow;
  const md = modProd(co, 'dem');
  D *= md;
  parts.events = md;
  if (co.franchise && co.franchise.fran) {
    D *= 1.0 + (co.franchise.brand || 0) * 0.002;
  }
  return { D: Math.max(0, D), parts };
}
/* staff working a role, in full-time equivalents (an hourly worker counts their share of a 37.5 h week); someone
   off sick does not count, and new or tired people count for what they manage (rampF, tiredF in engine/people/people.js) */
function staffFTE(co, role) {
  let t = 0;
  co.staff.forEach(s => {
    if (s.role === role && !s.off && !sickNow(s)) t += rampF(s) * tiredF(s) * (s.pt || 1) * 0.92 * (0.75 + 0.5 * staffSkill(s) / 100) * (s.flag === 'lazy' ? 0.82 : 1) * (s.pay && SALES_ROLES[s.role] ? (s.pay.m === 'mix' ? 1.06 : s.pay.m === 'com' ? 1.12 : 1) : 1);
  });
  return t;
}
function avgCond(vs) {
  return vs.length ? sum(vs, v => v.cond) / vs.length : 1;
}
/* eqN: the core below, then the steps features add: pipeSteps('eqN') */
function eqN(co, e) {
  return runSteps('eqN', eqNCore(co, e), co, e);
}
function eqNCore(co, e) {
  return e.vo ? co.veh.filter(v => v.eq === e.id).length : (co.eq[e.id] ? co.eq[e.id].n : 0) + (co.lease[e.id] || 0);
}
function eqCondOf(co, e) {
  return e.vo ? avgCond(co.veh.filter(v => v.eq === e.id)) : (co.eq[e.id] ? Math.min(1.15, co.eq[e.id].cond * Math.pow(co.eq[e.id].perf || 1, 1.5)) : 1);
}
/* capacity: how much a company can serve in a week, and what limits it (res.parts, res.bot).
   capacityCore counts people, equipment and space. While it runs, your hours count for what you can really give
   (ownerFactor). Then the 'capacity.core' steps (equipment rules) and the 'capacity' steps (small-firm rules,
   startup products, group trade, seasons, service hours, premises) run in order: pipeSteps('capacity'). */
function capacity(co, bd) {
  const f = ownerFactor();
  let res;
  if (f === 1 || co.mgr || !co.ohrs) res = runSteps('capacity.core', capacityCore(co, bd), co, bd);
  else {
    const h0 = co.ohrs;
    co.ohrs = h0 * f;
    try { res = runSteps('capacity.core', capacityCore(co, bd), co, bd); } finally { co.ohrs = h0; }
  }
  return runSteps('capacity', res, co, bd);
}
function capacityCore(co, bd) {
  const parts = [];
  const capD = bd.capD;
  const ownerF = co.mgr ? mgrFTE(co, bd) : co.ohrs / 40;
  const over = Math.max(0, (co.ohrs - 40) / 40);
  const ownerEff = co.mgr && window.R24 && R24.mgrEff ? R24.mgrEff(co) : (0.75 + 0.5 * co.oskill / 100) * (co.mgr ? (S.npcs[co.mgr] ? 0.5 + S.npcs[co.mgr].stats.ops / 200 : 1) : 1);
  bd.std.forEach((s, i) => {
    const nRef = s[1] + (i === 0 ? bd.own : 0);
    const capPer = capD / nRef / 0.92;
    const fte = staffFTE(co, s[0]);
    parts.push({
      k: 'role:' + s[0],
      label: ROLES[s[0]][0],
      have: fte,
      need: s[1] * co.size,
      cap: fte * capPer,
      capPer,
      kind: 'staff'
    });
  });
  let of = ownerF * ownerEff + (window.R24 && R24.asstFTE ? R24.asstFTE(co, bd) : 0); /* the assistant manager works too */
  const owner = of;
  let guard = 0;
  while (of > 0.01 && parts.length && guard++ < 40) {
    const step = Math.min(0.25, of);
    let mi = 0;
    for (let i = 1; i < parts.length; i++) if (parts[i].cap < parts[mi].cap) mi = i;
    parts[mi].have += step;
    parts[mi].cap += step * parts[mi].capPer;
    parts[mi].owner = (parts[mi].owner || 0) + step;
    of -= step;
  }
  let avail = 1; /* a required machine in repair for part of the week: the business works the rest of the week */
  bd.eq.forEach(e => {
    const n = eqN(co, e), cond = eqCondOf(co, e);
    if (e.fl.indexOf('r') >= 0 && n < 1 && n > 0.01 && eqNCore(co, e) >= 1) avail = Math.min(avail, n);
    else if (e.fl.indexOf('r') >= 0 && n < 1) parts.push({ k: 'eq:' + e.id, label: e.n + ' (required)', have: 0, need: 1, cap: 0, kind: 'gate' });
    else if (e.fl.indexOf('c') >= 0 && e.std > 0) {
      const cp = capD / e.std;
      parts.push({
        k: 'eq:' + e.id,
        label: e.n,
        have: n,
        need: Math.max(1, Math.round(e.std * co.size)),
        cap: n * cp * (0.7 + 0.3 * cond),
        capPer: cp,
        kind: 'equip'
      });
    }
  });
  if (co.prem && co.prem.m2 && bd.prem && PREM[bd.prem[0]] && bd.prem[1] > 0) parts.push({
    k: 'prem',
    label: 'Space (' + co.prem.m2 + ' m2)',
    have: co.prem.m2,
    need: Math.round(bd.prem[1] * co.size),
    cap: capD * co.prem.m2 / bd.prem[1],
    kind: 'space'
  });
  let cap = Infinity, bot = null;
  parts.forEach(p => {
    if (p.cap < cap) {
      cap = p.cap;
      bot = p;
    }
  });
  if (!isFinite(cap)) cap = capD;
  const kk = knobFx(co, 'k');
  const mc = modProd(co, 'cap');
  cap *= kk * mc * (over > 0 ? 1 + over * 0.2 : 1) * avail;
  return { cap: Math.max(0, cap), parts, bot, owner };
}
function qualityTarget(co, bd, util) {
  if (bd.fam === 'club') return clamp(co.fm.s || 50, 5, 99);
  let ss = 0, ns = 0;
  co.staff.forEach(s => {
    ss += staffSkill(s);
    ns++;
  });
  const own = co.mgr ? 0 : 1;
  const sk = ns || own ? (ss + co.oskill * own * 1.2) / (ns + own * 1.2) : co.oskill;
  let tq = 0, hq = 0;
  bd.eq.forEach(e => {
    if (e.fl.indexOf('q') >= 0) {
      tq++;
      const n = eqN(co, e);
      if (n > 0) hq += eqCondOf(co, e) * 0.8 + 0.2;
    }
  });
  const eqQ = tq ? 16 * hq / tq : 8;
  let q = 28 + 0.3 * sk + eqQ + knobFx(co, 'q', 'sum') + (co.mgr ? 9 * mgrQual(co) : 0) + (co.ohrs > 46 && !co.mgr ? -(co.ohrs - 46) * 0.7 : 0) - Math.max(0, util - 0.97) * 40;
  q += [-3, 0, 2][co.maint];
  q += goodsEff(co).q;
  return clamp(q, 5, 99);
}
function ticketEff(co, bd) {
  return rlc(bd.ticket * (bd.rm || 1) * ticketMult(co, bd) * (1 + (co.rep - 50) / 500), co.country);
}
/* weekCo: steps before ('weekCo.before') and after ('weekCo.after') share ph (ph.r is the result): pipeSteps('weekCo.after') */
function weekCo(co) {
  return runPhased('weekCo', [co], () => weekCoCore(co));
}
function weekCoCore(co) {
  const bd = BD[co.type];
  co.bk.w = {};
  co.mods = co.mods.filter(m => {
    m.w--;
    return m.w > 0;
  });
  docsWeek(co);
  if (co.st === 'setup') {
    setupWeek(co, bd);
    return;
  }
  if (co.st === 'closed') {
    rentWeek(co);
    accWeek(co);
    payCo(co, bd.fixed * Math.pow(co.size, 0.6) * 0.5 * (window.R23 && R23.fixF ? R23.fixF(co) : 1), 'oth');
    wagesWeek(co, bd, ((co.closeTot || co.closeW) - co.closeW) < 2 ? 1 : 0.4);
    co.closeW--;
    if (co.closeW <= 0) {
      co.st = 'open';
      note(co.name + ' reopens.', 'good', co.id);
    }
    return;
  }
  if (co.st !== 'open') return;
  const F = FAM[bd.fam];
  const ctx = { D: 0, cap: 0, units: 0, rev: 0, cogs: 0, util: 0, price: 0, extra: {}, cr: 0 };
  if (F && F.custom) {
    F.custom(co, bd, ctx);
  }
  else {
    const dm = demand(co, bd), cp = capacity(co, bd);
    ctx.D = dm.D;
    ctx.cap = cp.cap;
    acctDemand(co, ctx);
    co.dbg = {
      D: dm.D,
      cap: cp.cap,
      dp: dm.parts,
      cp: cp.parts,
      bot: cp.bot ? cp.bot.label : '',
      botObj: cp.bot ? { kind: cp.bot.kind, k: cp.bot.k } : null,
      owner: cp.owner
    };
    ctx.price = ticketEff(co, bd);
    ctx.cogsMult = 1;
    ctx.gd = goodsEff(co);
    ctx.cogsMult = ctx.gd.m;
    if (F && F.pre) F.pre(co, bd, ctx);
    let units;
    if (window.R10U && window.R10U(co, bd, ctx)) units = ctx.units;
    else {
      units = Math.min(ctx.D, ctx.cap);
      units = Math.max(0, Math.min(ctx.cap, units * (1 + gauss() * 0.045)));
      if (F && F.units) units = F.units(co, bd, ctx, units);
      units = Math.round(Math.min(units, ctx.cap) * 10) / 10;
    }
    ctx.units = units;
    ctx.util = ctx.cap > 0 ? units / ctx.cap : 0;
    ctx.rev = units * ctx.price;
    const mq = co.mgr ? mgrQual(co) : 0.5;
    let cr = (bd.cogs + knobFx(co, 'c', 'sum')) * (co.mgr ? 1.04 - 0.08 * mq : 1) * ctx.cogsMult * modProd(co, 'price') * modProd(co, 'cogsup');
    if (bd.fam !== 'prod' && bd.fam !== 'project') cr *= (0.7 + 0.3 * S.econ.mat);
    if (bd.tw.fuel) cr += bd.tw.fuel * (S.econ.fuel - 1);
    ctx.cr = Math.max(0.01, cr);
    if (ctx.Da) {
      ctx.rev0 = ctx.rev;
      ctx.rev = acctRev(co, ctx);
    }
    ctx.cogs = (ctx.rev0 || ctx.rev) * ctx.cr;
    if (co.prem && co.prem.loc && co.prem.loc < 1 && !isFoot(co.prem.kind)) ctx.transportX = ctx.rev * (1 - co.prem.loc) * 0.6;
    if (ctx.Da) ctx.cogs *= (1 - 0.05 * ctx.Da / ctx.D);
    if (ctx.transportX) ctx.cogs += ctx.transportX;
    if (bd.tw.perish) ctx.cogs += ctx.rev * bd.tw.perish * (1 + Math.max(0, 0.85 - ctx.util) * 2.2) * (co.mgr ? 1.2 - 0.5 * mq : 1);
    if (bd.tw.shrink) ctx.cogs += ctx.rev * bd.tw.shrink * (co.flags.secure ? 0.5 : 1) * (1 + (co.flags.shrinkUp || 0));
    if (bd.tw.ota) ctx.cogs += ctx.rev * bd.tw.ota * knobFx(co, 'ota');
    if (bd.tw.excise) ctx.cogs += ctx.units * 8.5 * costIdx(co.country) * Math.pow(1 + S.econ.infl, S.week / 52);
    if (F && F.post) F.post(co, bd, ctx);
  }
  book(co, bd, ctx);
  weekEnd(co, bd, ctx);
}
function wagesWeek(co, bd, f) {
  f = f == null ? 1 : f;
  const oc = OC();
  let gross = 0;
  const hol = 1 + (CC().leaveWk || 0) / 52 * 0.3; /* cover for statutory paid leave and sick days: about a third of the leave weeks is covered by extra hours */
  co.staff.forEach(s => {
    if (!s.off) gross += s.wage * 12 / 52 * hol; /* a seasonal worker between seasons is not paid */
  });
  gross += co.st === 'closed' ? 0 : commissionWeek(co); /* extra share: statutory paid leave and sick cover, by country */
  if (co.mgr) gross += (co.mgrWage || 0) * 12 / 52;
  gross += runSteps('extraPay', 0, co) * 12 / 52; /* monthly pay of the company's management team (management_team.js) */
  gross *= f;
  const cost = gross * oc;
  co.pay.wages += cost;
  bk(co, 'wages', cost);
  S.stats.wagesPaid += cost;
  co.lastWages = cost;
  return cost;
}
function vatExempt(co) {
  const thr = (co.country && CO[co.country] ? CO[co.country] : CC()).vatThr || 0;
  if (thr <= 0 || docOk(co, 'mva')) return false;
  const t12 = sum((co.hist || []).slice(-12), x => x.rev || 0);
  return t12 < thr;
}
function vatRate(co) {
  const b = BD[co.type];
  if (vatExempt(co)) return 0;
  return CC().vat[b.vat] || 0;
}
function book(co, bd, ctx) {
  const rev = Math.round(ctx.rev), cogs = Math.round(ctx.cogs);
  const vr = vatRate(co);
  bk(co, 'rev', rev);
  bk(co, 'cogs', cogs);
  if (ctx.gd && ctx.gd.v) vbuy(ctx.gd.v.id, cogs);
  co.lastW = { units: ctx.units, rev, cogs, D: ctx.D, cap: ctx.cap, util: ctx.util };
  const cashShare = 1 - bd.b2b;
  const gross = rev * (1 + vr);
  /* US-style sales tax is charged to consumers only; business buyers pay without it */
  const grossB2B = CC().salesTax ? rev : gross;
  coIn(co, gross * cashShare - (ctx.paidD || 0), null, null);
  if (bd.b2b > 0 && rev > 0) {
    const t = bd.terms + (chance(0.18) ? rint(1, 4) : 0);
    co.recv.push({
      a: Math.round(grossB2B * bd.b2b),
      due: S.week + t,
      bad: chance(0.012 * (S.econ.dem < 0.97 ? 2 : 1) * (co.flags.ccheck ? 0.3 : 1))
    });
    if (co.flags.ccheck) payCo(co, grossB2B * bd.b2b * 0.004, 'oth', null);
  }
  const sTax = !!CC().salesTax, vBase = CC().vat[BD[co.type].vat] || 0, exm = vr === 0 && vBase > 0 && vatExempt(co);
  const vin = vr > 0 && !sTax ? Math.min(vr, 0.25) * 0.9 : 0;
  co.vatAcc += rev * vr * (sTax ? 1 - (BD[co.type].b2b || 0) : 1);
  if (ctx.devRevIsCash) { /* land and build costs were paid in cash as they fell due; cogs here is only the accounting cost of sales */ }
  else if (exm) {
    const ex = cogs * Math.min(vBase, 0.25) * 0.9;
    co.pay.other += cogs + ex;
    bk(co, 'oth', ex);
  } else {
    co.pay.other += cogs * (1 + vin);
    co.vatAcc -= vin * cogs;
  }
}
function weekEnd(co, bd, ctx) {
  co.recv = co.recv.filter(r => {
    if (S.week >= r.due) {
      if (!r.bad) coIn(co, r.a, null, null); else recvLoss(co, r.a);
      return false;
    }
    return true;
  });
  wagesWeek(co, bd);
  rentWeek(co);
  const size06 = Math.pow(co.size, 0.6) * Math.pow(cityOf(co.city).rent, 0.3);
  const fixed = (bd.fixed * size06 * (window.R23 && R23.fixF ? R23.fixF(co) : 1) + knobFx(co, 'w', 'sum')) * Math.pow(1 + S.econ.infl, S.week / 52);
  payCo(co, fixed, 'oth', null);
  if (fixed > 0 && vatRate(co) > 0 && !CC().salesTax) {
    const vf = vatRate(co) * fixed * 0.5;
    moveCash(co, -(Math.round(vf)));
    co.vatAcc -= vf;
  }
  else if (fixed > 0 && vatExempt(co)) {
    const vf = (CC().vat[BD[co.type].vat] || 0) * fixed * 0.5;
    moveCash(co, -(Math.round(vf)));
    bk(co, 'oth', vf);
  }
  accWeek(co);
  insWeek(co);
  leaseWeek(co);
  premValueWeek(co);
  mktWeek(co, bd);
  eqWeek(co, ctx.util || 0.6);
  const qt = qualityTarget(co, bd, ctx.util || 0.5);
  co.q += (qt - co.q) * 0.18;
  co.rep = clamp(co.rep + (co.q - co.rep) * 0.025 - (ctx.D > ctx.cap * 1.25 && ctx.cap > 0 ? 0.08 : 0), 0, 100);
  staffWeek(co).forEach(a => handleStaffEvent(co, a));
  if (!co.mgr && co.ohrs >= 20) co.oskill = clamp(co.oskill + 0.035 * (1 - co.oskill / 120), 0, 100);
  co.staff.forEach(s => {
    const n = S.npcs[s.id];
    if (!n) return;
    if (n.pot == null) n.pot = clamp(Math.round(n.skill + 16 + hrng(S.seed + ':pot:' + s.id)() * 30), n.skill + 8, 98);
    const cur = n.skill + s.skillGain;
    const age = n.age + Math.floor((S.week - (s.w0 || S.week)) / 52);
    const ageF = age < 25 ? 1.35 : age < 35 ? 1.1 : age < 50 ? 0.85 : age < 60 ? 0.6 : 0.35;
    s.skillGain = clamp(s.skillGain + Math.max(0, n.pot - cur) * 0.0065 * ageF, -10, Math.max(30, n.pot - n.skill));
  });
  spawnEvents(co, bd);
  managerWeek(co, bd, ctx);
  if (co.cash < 0) {
    co.negW = (co.negW || 0) + 1;
    const i = -co.cash * 0.14 / 52;
    moveCash(co, -(i));
    bk(co, 'int', i);
  } else co.negW = 0;
  co.unitsW = ctx.units;
}
function setupWeek(co, bd) {
  rentWeek(co);
  accWeek(co);
  const sc = initialStockCost(co, bd);
  if (sc > 0 && co.cash < sc && !openChecklist(co).some(x => !x.ok && x.k !== 'stockcash') && (S.week - (co.flags.stockAsk || -99)) >= 8) {
    co.flags.stockAsk = S.week;
    info(co.name, co.name + ' cannot open yet', 'Everything is ready, but the company has ' + money(Math.max(0, co.cash)) + ' and needs ' + money(sc) + ' for the first stock. Put money in under Finance and it opens by itself.', co.id, 'bad');
  }
}
function handleStaffEvent(co, a) {
  const k = a[0], s = a[1];
  const n = S.npcs[s.id];
  if (!n) return;
  if (k === 'quit') {
    if (!s.notice) {
      s.notice = s.w0 < S.week - 52 ? 8 : 4;
      note(n.name + ' (' + ROLES[s.role][0] + ') handed in notice at ' + co.name + ' and leaves in ' + s.notice + ' weeks.', 'bad', co.id);
    }
  }
  else if (k === 'sick') note(n.name + ' (' + ROLES[s.role][0] + ') is off sick this week at ' + co.name + (s.hw > 40 ? ': too many long weeks.' : '.'), 'bad', co.id);
  else if (k === 'leave') {
    note(n.name + ' (' + ROLES[s.role][0] + ') has left ' + co.name + '.', 'bad', co.id);
    co.staff = co.staff.filter(x => x !== s);
    n.hired = 0;
  }
  else if (k === 'payask' || k === 'fixask') {
    /* they ask, they do not threaten: a raise that feels like one, a token one, or not now */
    const lr = s.lr != null ? s.lr : s.w0 || 0, yrs = Math.floor((S.week - lr) / 52), need = raiseFelt(co, s);
    const big = Math.max(need, 0.06), small = 0.03;
    if (k === 'payask') addMsg({
      kind: 'ask', from: n.name, role: ROLES[s.role][0], co: co.id,
      title: n.name + ' asks about pay at ' + co.name,
      body: (S.week - lr >= 52 ? 'It has been ' + (yrs > 1 ? yrs + ' years' : 'a year') + ' since my last raise.' : 'I have looked around, and people doing my job earn more.') + ' I like it here and would like to stay. Could we look at my pay?',
      opts: [{ l: '+' + Math.round(big * 100) + '%', d: '+' + money(s.wage * big) + '/month', fx: {} }, { l: '+' + Math.round(small * 100) + '%', d: '+' + money(s.wage * small) + '/month', fx: {} }, { l: 'Not now', d: 'Disappointed', fx: {} }],
      act: 'staffx', data: { t: 'payask', sid: s.id, big, small }, exp: S.week + 3
    });
    else addMsg({
      kind: 'ask', from: n.name, role: ROLES[s.role][0], co: co.id,
      title: n.name + ' asks for a fixed salary at ' + co.name,
      body: 'I have been here ' + Math.round((S.week - (s.w0 || S.week)) / 4.35) + ' months and the work goes well. I would like a fixed monthly salary instead of being paid by the hour, so I know what comes in each month.',
      opts: [{ l: 'Fixed salary', d: money(rnl(s.wage, 100)) + '/month, a full week', fx: {} }, { l: 'Keep it hourly', d: 'Disappointed', fx: {} }],
      act: 'staffx', data: { t: 'fixask', sid: s.id }, exp: S.week + 3
    });
  }
  else if (k === 'problem') {
    const lbl = {
      late: 'is often late',
      lazy: 'is under-performing',
      conflict: 'is causing conflict in the team',
      sick: 'has high sick leave',
      theft: 'is suspected of stealing'
    }[s.flag];
    note('PROBLEM at ' + co.name + ': ' + n.name + ' ' + lbl + '. See Company > Workers.', 'bad', co.id);
    if (s.flag === 'theft') co.flags.shrinkUp = (co.flags.shrinkUp || 0) + 0.4;
  }
}
function openChecklist(co) {
  const bd = BD[co.type], items = [];
  docNeeds(co).forEach(d => {
    if (d === 'mva_na') return;
    items.push({
      k: 'doc:' + d,
      t: docDef(d, co.country)[0],
      ok: docOk(co, d),
      sub: co.docs[d] && co.docs[d].st === 'applied' ? 'In progress, ready ' + dateStr(co.docs[d].done) : docCost(co, d) > 0 ? 'Cost ' + money(docCost(co, d)) : 'Free'
    });
  });
  if (bd.fam !== 'rent' && bd.fam !== 'fin' && bd.fam !== 'energy') {
    if (bd.prem && bd.prem[0] !== 'none' && bd.prem[0] !== 'home') items.push({
      k: 'prem',
      t: 'Premises',
      ok: !!(co.prem && co.prem.m2),
      sub: co.prem && co.prem.m2 ? co.prem.m2 + ' m2' : 'Not chosen'
    });
    bd.eq.forEach(e => {
      if (e.fl.indexOf('r') >= 0) items.push({ k: 'eq:' + e.id, t: e.n, ok: eqN(co, e) >= 1, sub: '' });
    });
  }
  if (FAM[bd.fam] && FAM[bd.fam].checklist) FAM[bd.fam].checklist(co, bd, items);
  const sc = initialStockCost(co, bd);
  if (sc > 0) items.push({
    k: 'stockcash',
    t: 'Cash for opening stock',
    ok: co.cash >= sc,
    sub: co.cash >= sc ? 'Ready' : 'Needs ' + money(sc) + ' in the company. Put money in under Finance.'
  });
  return items;
}
function openCompany(co) {
  const bd = BD[co.type], it = openChecklist(co), miss = it.filter(x => !x.ok);
  if (miss.length) return 'missing';
  const F = FAM[bd.fam];
  if (F && F.open) {
    const r = F.open(co, bd);
    if (r !== 'ok') return r;
  }
  const sc = initialStockCost(co, bd);
  if (sc > 0) {
    if (co.cash < sc) return 'stock:' + sc;
    payCo(co, sc, null, 'Opening stock');
    co.inv += sc;
  }
  co.st = 'open';
  co.wOpen = S.week;
  note(co.name + ' is open for business!', 'good', co.id);
  return 'ok';
}
function initialStockCost(co, bd) {
  if (!bd.tw.stock) return 0;
  const wc = (bd.Dc || 1) * bd.ticket * Math.max(0.05, bd.cogs || 0.3) * Math.min(1, cityOf(co.city).dem + 0.1) * cityOf(co.city).price;
  return Math.round(wc * bd.tw.stock / 7 * Math.max(0.5, co.size) * 0.6);
}


/* ---- src/company/family_energy.js ---- */
/* ===== Energy: power producer and oil & gas ===== */
const SRC = {
  wind: { cf: 1, cost: 1, build: 52, seas: [1.3, 1.25, 1.1, 0.9, 0.75, 0.65, 0.6, 0.7, 0.9, 1.1, 1.25, 1.3] },
  hydro: { cf: 1.25, cost: 1.3, build: 78, seas: [0.8, 0.7, 0.9, 1.4, 1.7, 1.4, 1.0, 0.8, 0.9, 1.0, 0.9, 0.8] },
  solar: { cf: 0.31, cost: 0.55, build: 26, seas: [0.1, 0.35, 0.9, 1.6, 2.1, 2.4, 2.3, 1.8, 1.0, 0.45, 0.1, 0.05] }
};
function srcOf(co) {
  return ['wind', 'hydro', 'solar'][co.knob.src || 0];
}
FAM.energy = {
  afterBuy(co, bd, id, qty) {
    if (!bd.tw.power || id !== 'turb') return;
    const s = SRC[srcOf(co)];
    co.fm.build = co.fm.build || [];
    co.fm.build.push({ n: qty, ready: S.week + s.build });
  },
  custom(co, bd, ctx) {
    return bd.tw.power ? FAM.energy.power(co, bd, ctx) : FAM.energy.oil(co, bd, ctx);
  },
  power(co, bd, ctx) {
    const tw = bd.tw, fm = co.fm;
    fm.build = fm.build || [];
    const total = co.eq.turb ? co.eq.turb.n : 0;
    const inb = sum(fm.build.filter(b => b.ready > S.week), b => b.n);
    const mw = Math.max(0, total - inb);
    fm.build = fm.build.filter(b => b.ready > S.week);
    const s = SRC[srcOf(co)];
    const cond = co.eq.turb ? co.eq.turb.cond : 1;
    const stF = knobFx(co, 'k');
    const seas = s.seas[wMonth(S.week)];
    const crew = Math.min(1, staffFTE(co, 'windtech') / Math.max(0.5, 4 * Math.max(0.5, mw / 30)));
    const capW = mw * 168 * tw.cf * s.cf * seas;
    const mwh0 = mw * 168 * tw.cf * s.cf * seas * (0.75 + 0.25 * cond) * (0.8 + 0.2 * crew) * modProd(co, 'cap') * (1 + gauss() * 0.08);
    const mwh = Math.min(mwh0, capW);
    const hedge = co.knob.hedge || 0;
    const spot = 650 * S.econ.power * Math.pow(1 + S.econ.infl, S.week / 52);
    const fixed = 650 * 1.0 * Math.pow(1 + S.econ.infl, S.week / 52);
    const share = [0, 0.5, 0.9][hedge];
    const price = spot * (1 - share) + fixed * 0.95 * share;
    ctx.price = price;
    ctx.units = mwh;
    ctx.rev = mwh * price * modProd(co, 'dem');
    ctx.cogs = mw * 14e6 * tw.opex / 52 * (1 + (1 - cond) * 0.6);
    ctx.D = mwh;
    ctx.cap = capW;
    ctx.util = ctx.cap ? mwh / Math.max(1, ctx.cap) : 0;
    co.dbg = {
      D: mwh,
      cap: ctx.cap,
      dp: { season: seas, price: price },
      cp: [],
      bot: inb > 0 ? 'Under construction: ' + inb + ' MW ready in ' + Math.min.apply(null, fm.build.map(b => b.ready - S.week)) + ' wk' : '',
      mw,
      inb
    };
    co.lastW = {
      units: Math.round(mwh),
      rev: Math.round(ctx.rev),
      cogs: Math.round(ctx.cogs),
      D: mwh,
      cap: ctx.cap,
      util: ctx.util
    };
  },
  oil(co, bd, ctx) {
    const fm = co.fm;
    fm.fields = fm.fields || [];
    fm.prospects = fm.prospects || [];
    let bbl = 0, rev = 0, opex = 0, capexW = 0;
    // automatic baseline: a manager buys stakes in producing fields when funds allow; the strategy knob adds exploration
    if (co.mgr && S.npcs[co.mgr] && co.st === 'open' && S.week - (fm.autoW || -99) >= 26 && fm.fields.filter(f => f.st !== 'depleted').length < 2 + co.size) {
      const k = [10000, 5000, 2000, 1000].find(k => co.cash > k * 1000 * 190 * Math.sqrt(S.econ.oil) + 60e6 * Math.pow(1 + S.econ.infl, S.week / 52) + (co.lastWages || 0) * 26);
      if (k && oilAcquire(co, k) === 'ok') {
        fm.autoW = S.week;
        note(S.npcs[co.mgr].name + ' bought a stake in a producing field.', 'good', co.id);
      }
      else if ((co.knob.risk || 1) === 2 && co.cash > 2.5e9 * Math.pow(1 + S.econ.infl, S.week / 52) && chance(0.3)) {
        fm.autoW = S.week;
        oilExplore(co);
      }
    }
    /* How you sell (the sell knob): term contracts take 60% of the oil at 95% of the long-run price, so a swing in
       the market price hits less of it */
    const lr = 780 * Math.pow(1 + S.econ.infl, S.week / 52) ** 0.5, term = co.knob.sell === 1 ? 0.6 : 0;
    const price = lr * S.econ.oil * (1 - term) + lr * 0.95 * term;
    const crew = Math.min(1, staffFTE(co, 'offshore') / Math.max(1, 10 * co.size));
    fm.fields.forEach(f => {
      if (f.st === 'dev') {
        f.wl--;
        const c = f.capex / 156;
        if (window.R24 && R24.oilDevCash) R24.oilDevCash(co, f, c);
        payCo(co, c, null, null); /* development is an investment: it becomes part of the field's book value */
        f.bv = (f.bv || 0) + c;
        capexW += c;
        if (f.wl <= 0) {
          f.st = 'prod';
          f.age = 0;
          note('Field "' + f.name + '" starts production!', 'good', co.id);
        }
      }
      else if (f.st === 'prod') {
        f.age++;
        const q = f.q0 * Math.exp(-0.0028 * Math.max(0, f.age - (f.plat || 0))) * modProd(co, 'cap') * (0.8 + 0.2 * crew) * (1 + gauss() * 0.03);
        const b = Math.min(q, f.res);
        if (f.bv == null) f.bv = f.res * 1000 * 190; /* older saves */
        const dpl = f.res > 0 ? f.bv * b / f.res : 0; /* depletion: the share of the field used up this week */
        f.bv -= dpl;
        bk(co, 'dep', dpl);
        f.res -= b;
        bbl += b;
        opex += b * 190 * 1000 / 1000 * (1 + 0);
        if (f.res < 10) {
          bk(co, 'dep', f.bv || 0);
          f.bv = 0;
          f.st = 'depleted';
          note('Field "' + f.name + '" is depleted.', 'n', co.id);
        }
      }
    });
    ctx.units = bbl;
    ctx.rev = bbl * 1000 * price / 1000 * modProd(co, 'dem');
    ctx.cogs = bbl * 1000 * 300 / 1000 * (1 + (S.econ.mat - 1) * 0.5);
    ctx.D = bbl;
    ctx.cap = bbl;
    ctx.util = 0.8;
    ctx.price = price;
    // bbl are in thousand barrels; price per barrel NOK -> revenue = kbbl * 1000 * price
    ctx.rev = bbl * 1000 * price * modProd(co, 'dem');
    ctx.cogs = bbl * 1000 * (window.R24 && R24.oilLift ? R24.oilLift() : 300);
    fm.assets = sum(fm.fields.filter(f => f.st !== 'depleted'), f => f.bv || 0);
    co.dbg = { D: bbl, cap: bbl, dp: { price }, cp: [], bot: '', fields: fm.fields.length };
    co.lastW = { units: Math.round(bbl), rev: Math.round(ctx.rev), cogs: Math.round(ctx.cogs), D: bbl, cap: bbl, util: 0.8 };
  },
  fx(co, bd, fx) { },
  checklist(co, bd, items) {
    if (bd.tw.power) items.push({
      k: 'mw',
      t: 'Order at least 1 MW of generation capacity (Equipment)',
      ok: !!(co.eq.turb && co.eq.turb.n >= 1),
      sub: ''
    });
  }
};
const OIL_NEUT = ['Atlas', 'Beacon', 'Cormorant', 'Delta', 'Eagle', 'Falcon', 'Granite', 'Harrier', 'Ivory', 'Juniper'];
const OIL_NEUT2 = ['Aurora', 'Boreas', 'Cobalt', 'Drake', 'Ember', 'Fulmar', 'Gannet', 'Heron'];
function oilAcquire(co, kbbl) {
  const price = Math.round(kbbl * 1000 * 190 * S.econ.oil ** 0.5);
  if (co.cash < price) return 'cash';
  payCo(co, price, null, 'Stake in producing field');
  co.fm.fields = co.fm.fields || [];
  co.fm.fields.push({
    id: uid(),
    name: pick(flavour('oilFields', OIL_NEUT)) + ' ' + pick(['A', 'B', 'North', 'West', 'East']) + ' (stake)',
    st: 'prod',
    res: kbbl,
    q0: kbbl * 0.0034,
    age: 0,
    bv: price
  });
  return 'ok';
}
/* oilExplore: steps before ('oilExplore.before') and after ('oilExplore.after') share ph (ph.r is the result): pipeSteps('oilExplore.after') */
function oilExplore(co) {
  return runPhased('oilExplore', [co], () => oilExploreCore(co));
}
function oilExploreCore(co) {
  const c = Math.round(300e6 * Math.pow(1 + S.econ.infl, S.week / 52));
  if (co.cash < c) return 'cash';
  payCo(co, c, 'oth', 'Exploration well');
  const ok = chance([0.14, 0.2, 0.28][co.knob.risk || 1]);
  co.fm.fields = co.fm.fields || [];
  if (ok) {
    const vol = Math.round(Math.exp(gauss() * 0.9 + 4.4)) * 1000;
    co.fm.fields.push({
      id: uid(),
      name: pick(flavour('oilDiscoveries', OIL_NEUT2)) + ' ' + rint(1, 9),
      st: 'dev',
      res: vol,
      q0: vol * 0.0045,
      wl: 156,
      capex: vol * 1000 * 85,
      bv: 0
    });
    note('DISCOVERY! A well finds about ' + Math.round(vol / 1000) + ' million barrels. Development will take about 3 years.', 'good', co.id);
    news('A new oil discovery is announced.', 'good');
    return 'hit';
  }
  note('The exploration well is dry. ' + money(c) + ' lost.', 'bad', co.id);
  return 'dry';
}
/* tax rate by company type */
function coTaxRate(co) {
  const bd = BD[co.type];
  const c = CO[co.country] || CC();
  if (bd.tw.oil) return specialTax(co, 'oil', Math.min(0.5, c.corp + 0.2));
  if (bd.id === 'salmon') return specialTax(co, 'salmon', c.corp);
  if (bd.tw.power) return srcOf(co) === 'hydro' ? specialTax(co, 'hydro', c.corp) : c.corp;
  return c.corp;
}


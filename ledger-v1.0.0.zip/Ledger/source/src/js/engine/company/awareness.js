/* ---- src/company/awareness.js ---- */
/* ===== Awareness is local: it lives in one country. Each country has its own famous, very expensive media moment ===== */
function initPremCh() {
  CO_ORDER.forEach(k => {
    const c = CO[k], p = PREM_CH[k];
    if (!p) return;
    const f = costIdx(k) * Math.sqrt(Math.max(2, c.pop) / 5) * 0.9;
    const rd = x => rnl(x * f, 5000);
    CH['prem_' + k] = {
      n: p[0],
      eff: 34,
      sc: rd(500000),
      loc: 0.7,
      b2b: 0.2,
      mw: 4,
      only: k,
      nat: 1,
      prem: 1,
      var: 1,
      note: p[1] + ' Needs a national footprint, or most of it is wasted. Awareness fades quickly if the product disappoints.',
      opts: [0, rd(250000), rd(800000), rd(2500000)]
    };
  });
}
initPremCh();
const NATREACH = [
  'webshop',
  'shipping',
  'airline',
  'bank',
  'insco',
  'fund',
  'factory',
  'brewery',
  'furniture',
  'power',
  'mktg',
  'courier',
  'trucking',
  'casino',
  'hotel'
];
function natFit(co) {
  if (NATREACH.indexOf(co.type) >= 0) return 1;
  const n = reachOf(co).n;
  return clamp(0.12 + 0.88 * Math.min(1, Math.log2(n) / 4), 0.12, 1);
}
function chOk(co, k) {
  const c = CH[k];
  return !!c && (!c.only || c.only === co.country);
}
/* awareDecay: the core below, then the steps features add: pipeSteps('awareDecay') */
function awareDecay(co) {
  return runSteps('awareDecay', awareDecayCore(co), co);
}
function awareDecayCore(co) {
  return clamp(0.955 - Math.max(0, 55 - co.rep) * 0.0015 - Math.max(0, 55 - (co.q || 55)) * 0.001 + clamp((co.rep - 60) * 0.0004, 0, 0.012), 0.9, 0.968);
}
/* spill: the gain only leaks into other countries a little, unless it goes viral */
function awareSpill(co, gain) {
  if (gain <= 0) return;
  S.cos.forEach(s => {
    if (s === co || s.type !== co.type || s.st !== 'open' || s.country === co.country) return;
    s.aware = Math.min(100, s.aware + gain * 0.03);
  });
}
/* ---- going viral: every kind of business has its own hook. Buzz is short-lived and only sticks if you deliver ---- */
const VH_FAM = {
  svc: [['google', 'meta'], 'A customer’s glowing before-and-after story spreads fast'],
  venue: [['tiktok', 'meta'], 'A short video from {n} takes off'],
  retail: [['tiktok', 'meta'], 'A product from {n} gets picked up by influencers'],
  project: [['b2b', 'fair'], 'A showcase job by {n} wins an award and press'],
  prod: [['tiktok', 'fair'], 'A product from {n} wins a prize and goes around the web'],
  logi: [['b2b', 'google'], 'A rescue delivery by {n} becomes a feel-good news story'],
  rent: [['seo', 'google'], 'A tenant’s story about {n} gets national coverage'],
  fin: [['b2b', 'fair'], 'A founder interview about {n} goes around business media'],
  energy: [['b2b', 'fair'], 'A milestone at {n} becomes national news']
};
const VH_TYPE = {
  cafe: [['tiktok', 'meta'], 'A latte-art video from {n} takes off'],
  restaurant: [['tiktok', 'meta'], 'A dish at {n} goes viral on food channels'],
  barber: [['tiktok', 'meta'], 'A transformation video from {n} gets millions of views'],
  gym: [['tiktok', 'meta'], 'A member’s transformation at {n} is shared widely'],
  nightclub: [['tiktok', 'meta'], 'A night at {n} trends online'],
  tutor: [['google', 'meta'], 'A student’s result at {n} is shared by parents everywhere'],
  webdev: [['b2b', 'google'], 'A free tool from {n} is shared across developer forums'],
  webshop: [['tiktok', 'meta'], 'A product from {n} blows up on social media'],
  bakery: [['tiktok', 'meta'], 'A pastry from {n} trends online'],
  brewery: [['tiktok', 'fair'], 'A beer from {n} wins a medal and goes viral'],
  hotel: [['tiktok', 'meta'], 'A guest’s review video of {n} is everywhere'],
  fun: [['tiktok', 'meta'], 'A ride at {n} trends online'],
  cons: [['b2b', 'google'], 'A client’s case study of {n} is shared widely']
};
function viralHook(co) {
  return VH_TYPE[co.type] || VH_FAM[BD[co.type].fam] || [['meta'], 'Something about {n} takes off online'];
}
function viralRoll(co, premActive) {
  if (co.st !== 'open') return;
  const bd = BD[co.type];
  const h = viralHook(co);
  let fit = 0;
  h[0].forEach(k => {
    const m = co.mkt[k], c = CH[k];
    if (m && c) fit += Math.min(1, m.b / (c.sc * 0.7)) * (c.var ? 1.4 : 1);
  });
  if (premActive) fit += 1.2;
  const season = seasOf(bd) > 1.06 ? 1.5 : 1;
  let p = (0.0006 + 0.0035 * Math.min(2.5, fit)) * season;
  if (co.q >= 70 && co.rep >= 65) p += 0.0004;
  if (!chance(p)) return;
  const size = rng(28, 60);
  co.hype = Math.min(100, (co.hype || 0) + size);
  co.wom = (co.wom || 0) + size * 0.3;
  S.cos.forEach(s => {
    if (s !== co && s.type === co.type && s.st === 'open' && chance(0.5)) s.hype = Math.min(100, (s.hype || 0) + size * 0.25);
  });
  addMsg({
    kind: 'info',
    from: 'Market',
    title: h[1].replace('{n}', co.name) + '!',
    body: 'Everyone is talking about you. It fades within weeks unless you can serve the crowd well, so have stock, staff and quality ready.',
    co: co.id,
    tone: 'good',
    status: 'done'
  });
}
function deliverScore(co) {
  let d = clamp(((co.q || 50) - 45) / 40, 0, 1) * 0.6 + clamp((co.rep - 45) / 40, 0, 1) * 0.4;
  const u = co.lastW && co.lastW.util;
  if (u != null && u > 0.97 && (co.hype || 0) > 15) d *= 0.65;
  return d;
}
function hypeWeek(co) {
  if (!co.hype || co.hype < 0.5) {
    co.hype = 0;
    return;
  }
  const dv = deliverScore(co);
  const h = co.hype;
  if (dv >= 0.45) {
    co.aware = Math.min(100, co.aware + h * 0.1 * dv);
    co.rep = Math.min(100, co.rep + h * 0.012 * dv);
  }
  else {
    const hit = h * 0.012 * (0.45 - dv);
    co.rep = Math.max(0, co.rep - hit);
    if (h > 25 && !co.flags.hypeBad && chance(0.4)) {
      co.flags.hypeBad = S.week;
      note('Crowds came to ' + co.name + ' after the buzz, and left disappointed.', 'bad', co.id);
    }
  }
  co.hype = h * 0.86;
  if (co.hype < 1) co.hype = 0;
}
/* ---- marketing styles: each line of business responds to different channels ---- */
const CHAFF_FAM = {
  svc: { google: 1.3, seo: 1.2, mail: 1.1, tiktok: 0.8, bill: 0.6 },
  venue: { tiktok: 1.4, meta: 1.3, local: 1.2, google: 0.9, b2b: 0.3, seo: 0.8 },
  retail: { meta: 1.3, tiktok: 1.2, google: 1.1, bill: 1.1 },
  project: { b2b: 1.6, fair: 1.5, flyer: 0.3, tiktok: 0.3, meta: 0.4 },
  prod: { fair: 1.5, b2b: 1.4, flyer: 0.4 },
  logi: { b2b: 1.5, google: 1.2, fair: 1.1, tiktok: 0.3, flyer: 0.3 },
  rent: { seo: 1.4, google: 1.3, bill: 1.1, tiktok: 0.4 },
  fin: { b2b: 1.4, fair: 1.4, google: 1.1, tiktok: 0.3, flyer: 0.2 },
  energy: { b2b: 1.3, fair: 1.4, tiktok: 0.3, meta: 0.3, flyer: 0.2 }
};
const CHAFF_TYPE = {
  gym: { tiktok: 1.5, meta: 1.3 },
  barber: { tiktok: 1.5, meta: 1.3, flyer: 1.2 },
  nightclub: { tiktok: 1.6, flyer: 1.3, meta: 1.3 },
  tutor: { google: 1.4, mail: 1.3 },
  law: { google: 1.4, seo: 1.3, tiktok: 0.4 },
  boutique: { tiktok: 1.5, meta: 1.4 },
  hotel: { google: 1.2, tiktok: 1.2, local: 0.6 },
  cardealer: { bill: 1.3, google: 1.2, local: 1.2 },
  casino: { meta: 1.3, bill: 1.2 },
  fun: { meta: 1.4, tiktok: 1.4 },
  bakery: { tiktok: 1.3, local: 1.2 },
  brewery: { tiktok: 1.3, fair: 1.3 },
  grocery: { bill: 1.2, local: 1.3, mail: 1.3 },
  handy: { local: 1.3, flyer: 1.3 },
  cleaning: { local: 1.2, google: 1.3 }
};
function chAff(bd, k) {
  return ((CHAFF_FAM[bd.fam] || {})[k] || 1) * ((CHAFF_TYPE[bd.id] || {})[k] || 1);
}


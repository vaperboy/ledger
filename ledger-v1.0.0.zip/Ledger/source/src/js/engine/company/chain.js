/* ---- src/company/chain.js ---- */
/* ===== Chain reach: one shop is a local name; many outlets build a known brand ===== */
function chainOutlets(co) {
  let n = 0;
  S.cos.forEach(c => {
    if (c.type !== co.type || c.st === 'sold' || c.st === 'bust') return;
    n++;
    if (c.fr && c.fr.on) {
      n += c.fr.units.length;
      (c.fr.masters || []).forEach(m => {
        if (S.week >= m.ready) n += m.n;
      });
    }
  });
  if (co.franchise && co.franchise.brandId) {
    const b = fbBrand(co.franchise.brandId);
    if (b) n = Math.max(n, b.units + 1);
  }
  return Math.max(1, n);
}
function reachOf(co) {
  const n = chainOutlets(co);
  const cs = {};
  S.cos.forEach(c => {
    if (c.type === co.type && c.st !== 'sold' && c.st !== 'bust') cs[c.country || S.country] = 1;
    (c.fr && c.type === co.type ? c.fr.masters || [] : []).forEach(m => {
      cs[m.c] = 1;
    });
  });
  const k = Object.keys(cs).length;
  const label = n >= 60 && k >= 3 ? 'Worldwide' : n >= 25 && k >= 2 ? 'International' : n >= 10 ? 'National' : n >= 3 ? 'Regional' : 'Local';
  const cap = clamp(36 + 17 * Math.log2(n), 36, 100);
  const next = { Local: 3, Regional: 10, National: 25, International: 60, Worldwide: 0 }[label];
  return {
    n,
    k,
    label,
    cap,
    next,
    mult: 1 + 0.03 * Math.log2(n),
    rebate: n > 1 ? Math.min(0.035, 0.008 * Math.log2(n)) : 0
  };
}
function chainWeek(co) {
  hypeWeek(co);
  ownSupply(co);
  rivalSupply(co);
  const r = reachOf(co);
  co.aware = Math.min(co.aware, r.cap);
  if (r.rebate && co.lastW && co.lastW.rev && co.lastW.cogs > 0) rebate(co, Math.min(co.lastW.rev * r.rebate, co.lastW.cogs * 0.15));
}
function rebate(co, amt) {
  amt = Math.round(amt);
  if (amt <= 0) return;
  coIn(co, amt, null, null);
  bk(co, 'cogs', -amt);
}


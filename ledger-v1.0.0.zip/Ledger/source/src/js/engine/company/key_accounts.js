/* ---- src/company/key_accounts.js ---- */
/* ===== Business customers (key accounts): big orders, relationships, thin margins for best friends ===== */
const ACCT_FAM = ['svc', 'venue', 'retail', 'prod'];
const ACCT_PM = [1.0, 1.0, 0.98, 0.95, 0.9, 0.8, 0.65];
function acctOk(co) {
  const bd = BD[co.type];
  return !!bd && ACCT_FAM.indexOf(bd.fam) >= 0 && bd.b2b <= 0.8 && co.st === 'open';
}
function acctMax(co) {
  return 1 + Math.floor(Math.min(4, (co.rep - 25) / 18));
}
/* volume a key account buys; a discount you give them makes them buy more */
function acctVol(a, Dp) {
  return acctVolCore(a, Dp) * (1 + ((a.disc || 0) / 100) * 0.8);
}
function acctVolCore(a, Dp) {
  return Dp * a.f * (1 + a.rel / 150);
}
/* acctPm: defined in features/company/small_team_and_rewards.js (customers you choose to reward) */
/* demand side: called after private demand is known */
function acctDemand(co, ctx) {
  if (!co.accts || !co.accts.length || !acctOk(co)) {
    ctx.Da = 0;
    return;
  }
  ctx.Dp = ctx.D;
  ctx.Da = sum(co.accts, a => acctVol(a, ctx.Dp));
  ctx.D = ctx.Dp + ctx.Da;
}
/* acctRev: the core below, then the steps features add: pipeSteps('acctRev') */
function acctRev(co, ctx) {
  return runSteps('acctRev', acctRevCore(co, ctx), co, ctx);
}
function acctRevCore(co, ctx) {
  if (!ctx.Da || ctx.D <= 0) return ctx.rev;
  const f = ctx.units / ctx.D;
  let r = ctx.units * (ctx.Dp / ctx.D) * ctx.price;
  co.accts.forEach(a => {
    const u = f * acctVol(a, ctx.Dp);
    const pm = acctPm(a, ctx.cr);
    a.lastU = u;
    a.lastPm = pm;
    r += u * ctx.price * pm;
  });
  return r;
}
function acctWeek(co) {
  if (!acctOk(co)) return;
  co.accts = co.accts || [];
  const w = co.lastW;
  if (!w || !w.D) return;
  const fr = w.D > 0 ? w.units / w.D : 1;
  co.accts.slice().forEach(a => {
    if (fr >= 0.1) a.rel = Math.min(100, a.rel + 0.5 * clamp(fr / 0.6, 0.35, 1) * (1 - Math.pow(a.rel / 100, 1.6)) * (hasHQ('proc') ? 1.2 : 1)); else a.rel = Math.max(0, a.rel - 0.4);
    if ((fr < 0.1 && a.rel < 8 && chance(0.04)) || (co.q < 38 && a.rel < 25 && chance(0.015))) {
      co.accts = co.accts.filter(x => x !== a);
      note(a.name + ' took its business elsewhere from ' + co.name + '.', 'bad', co.id);
    }
  });
  if (S.week % 4 === 0 && co.accts.length < acctMax(co) && (co.aware >= 8 || co.rep >= 50) && chance(0.16 + co.aware / 400)) acctOffer(co);
}
function acctOffer(co) {
  const f = Math.round(rng(0.08, 0.28) * 100) / 100;
  const nm = coName('svc', co.city) ;
  const a = { id: uid(), name: nm, f, rel: 0, w0: S.week };
  if (co.mgr && S.npcs[co.mgr]) {
    co.accts.push(a);
    note(S.npcs[co.mgr].name + ' signed ' + nm + ' as a business customer for ' + co.name + '.', 'good', co.id);
    return;
  }
  addMsg({
    kind: 'ask',
    from: co.name,
    title: nm + ' wants to buy in bulk from ' + co.name,
    body: 'A larger business customer asks to place regular orders. They pay the normal price at first and expect better terms as you get to know each other.',
    co: co.id,
    opts: [{ l: 'Take them on', d: 'Extra orders every week', fx: {} }, { l: 'Decline', d: '', fx: {} }],
    act: 'acct',
    data: { a },
    exp: S.week + 3,
    by: 'ask',
    asker: 'mgr'
  });
}
ACTS.acct = (m, idx) => {
  const co = getCo(m.co);
  if (!co) return true;
  if (idx === 0) {
    co.accts = co.accts || [];
    if (co.accts.length < acctMax(co) + 1) co.accts.push(m.data.a);
  }
  return true;
};
function acctMeet(co, id) {
  const a = (co.accts || []).find(x => x.id === id);
  if (!a) return 'bad';
  if (a.meet != null && S.week - a.meet < 4) return 'wait';
  const c = KC(6000, co.country);
  if (S.cash < c) return 'cash';
  payMe(c, 'Dinner with ' + a.name);
  a.meet = S.week;
  a.rel = Math.min(100, a.rel + rint(4, 8) * (1 - Math.pow(a.rel / 100, 1.6)));
  return 'ok';
}
function acctDrop(co, id) {
  co.accts = (co.accts || []).filter(x => x.id !== id);
}


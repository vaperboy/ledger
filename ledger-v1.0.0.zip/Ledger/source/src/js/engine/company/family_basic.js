/* ---- src/company/family_basic.js ---- */
/* ===== Family models: svc, venue, retail, prod, logi (generic cap/demand with twists) ===== */
FAM.svc = {};
/* inventory handling shared by retail, prod, some venue */
function stockHandle(co, bd, ctx) {
  const tw = bd.tw;
  if (!tw.stock) return;
  const pol = co.stockPol, mult = [0.75, 1, 1.4][pol];
  const target = ctx.cogs * tw.stock / 7 * mult;
  const d = target - co.inv;
  const step = d * (0.25 + (co.mgr ? 0.15 * mgrQual(co) : 0));
  if (co.inv > target * 1.8 && target > 0) {
    const ob = (co.inv - target * 1.8) * 0.03;
    co.inv -= ob;
    bk(co, 'loss', ob);
  }
  if (step > 0) {
    moveCash(co, -(step));
    co.inv += step;
  } else {
    co.inv += step;
    moveCash(co, -(step));
  }
  const hold = co.inv * [0.0004, 0.0008, 0.0016][pol];
  bk(co, 'cogs', hold);
  co.pay.other += hold;
  if (tw.floor) {
    const i = co.inv * (policy() + 0.025) / 52;
    bk(co, 'int', i);
    moveCash(co, -(i));
  }
  if (tw.season && [2, 8].indexOf(wMonth(S.week)) >= 0 && S.week % 4 === 0) {
    const md = co.inv * 0.06 * (co.mgr ? 1.2 - mgrQual(co) * 0.7 : 0.9);
    co.inv -= md;
    bk(co, 'cogs', md);
    note('Season-end markdowns at ' + co.name + ': ' + money(md) + '.', 'n', co.id);
  }
}
function stockUnits(co, bd, ctx, u) {
  const pol = co.stockPol, tw = bd.tw;
  if (!tw.stock) return u;
  const hi = ctx.D > ctx.cap * 0.9 ? 1 : 0.4;
  const so = [0.05, 0.012, 0.002][pol] * hi * (co.mgr ? 1.2 - mgrQual(co) * 0.8 : 1);
  u = u * (1 - so * 0.5);
  /* real stock cover: when demand jumps above what the shelves hold, sales are lost until the next delivery */
  const lw = co.lastW;
  if (lw && lw.cogs > 0 && lw.units > 0) {
    const needNow = lw.cogs * (tw.stock / 7) * 0.5 * (u / lw.units);
    if (needNow > 0 && co.inv < needNow) {
      const f = clamp(co.inv / needNow, 0.25, 1);
      u *= f;
      if (f < 0.85 && (!co.flags.stockNote || S.week - co.flags.stockNote > 12)) {
        co.flags.stockNote = S.week;
        note('We ran short of stock at ' + co.name + ' and lost sales. Stock policy or ordering may need attention.', 'bad', co.id);
      }
    }
  }
  return u;
}
FAM.retail = {
  pre(co, bd, ctx) {
    if (bd.tw.ecom) { /* ads drive volume; returns handled in post */ }
  },
  units: stockUnits,
  post(co, bd, ctx) {
    const tw = bd.tw;
    if (tw.ecom) {
      const ret = tw.returns * knobFx(co, 'r') * (co.q < 50 ? 1.2 : 1);
      const lost = ctx.rev * ret * 0.7;
      ctx.rev -= lost;
      ctx.cogs += ctx.units * 52 * costIdx(co.country) * modProd(co, 'cogsup') + ctx.units * ret * 28 * costIdx(co.country);
    }
    stockHandle(co, bd, ctx);
  },
  checklist(co, bd, items) { }
};
FAM.prod = {
  pre(co, bd, ctx) {
    if (bd.tw.harvest) { /* farm */ }
  },
  units: stockUnits,
  post(co, bd, ctx) {
    stockHandle(co, bd, ctx);
    if (bd.tw.subsidy && ctx.rev > 0) {
      const sub = ctx.rev * bd.tw.subsidy;
      coIn(co, sub, 'rev', 'Agricultural support');
    }
  }
};
/* venue: members, casino variance */
FAM.venue = {
  open(co, bd) {
    if (bd.tw.sub) co.fm.memb = bd.Dc * 0.18 * cityOf(co.city).dem;
    return 'ok';
  },
  units(co, bd, ctx, u) {
    if (bd.tw.sub) {
      /* a week with no capacity (closed for repairs, owner sick in a one-person gym): members are not capped at 0,
         they stay on (a few more leave) and come back */
      if (!(ctx.cap > 0)) {
        const M0 = co.fm.memb == null ? 0 : co.fm.memb;
        const churn0 = bd.tw.churn * (1.5 - (co.q || 50) / 100) * (co.flags.churnUp || 1);
        co.fm.memb = Math.max(0, M0 * (1 - churn0 * 2));
        return 0;
      }
      const t = Math.min(ctx.D, ctx.cap);
      let M = co.fm.memb == null ? t * 0.2 : co.fm.memb;
      const churn = bd.tw.churn * (1.5 - co.q / 100) * (co.flags.churnUp || 1);
      M += (t - M) * 0.065 - M * churn;
      M = Math.max(0, Math.min(M, ctx.cap * 1.0));
      co.fm.memb = M;
      return M;
    }
    return u;
  },
  post(co, bd, ctx) {
    if (bd.tw.variance) {
      const risk = knobFx(co, 'risk');
      const sd = bd.tw.variance * (risk || 1) / Math.sqrt(Math.max(0.2, ctx.units / 100));
      const f = clamp(1 + gauss() * sd, 0.05, 3);
      co.fm.vol = risk || 1;
      ctx.rev *= f;
      co.fm.lastHold = f;
    }
  },
  fx(co, bd, fx) {
    if (fx.memb && co.fm.memb != null) co.fm.memb *= fx.memb;
  }
};
FAM.logi = {
  pre(co, bd, ctx) {
  if (bd.tw.rateIdx) ctx.price *= S.econ.freight;
},
  fx() { }
};
/* ===== salmon farm: cohort cycle ===== */
FAM.salmon = {
  custom(co, bd, ctx) {
    const tw = bd.tw, fm = co.fm;
    fm.coh = fm.coh || [];
    fm.price = fm.price || 84;
    ctx.D = 0;
    ctx.cap = 1;
    const feedK = knobFx(co, 'c', 'sum'), growQ = 1 + knobFx(co, 'q', 'sum') * 0.01, ill = knobFx(co, 'r');
    // stock a new cohort if none or when the first is >40 weeks old and fewer than 2 cohorts, and cash allows
    const auto = co.flags.autoStock !== 0;
    if (auto && fm.coh.length < 2 && (fm.coh.length === 0 || fm.coh[fm.coh.length - 1].age > 38)) {
      const n = Math.round(tw.tonnes / 4.6 * 1000 * 0.98 / knobFx(co, 'k'));
      const cost = n * 14.5 * Math.pow(1 + S.econ.infl, S.week / 52);
      if (co.cash > cost * 1.1) {
        payCo(co, cost, 'cogs', 'Smolt');
        fm.coh.push({ n, kg: 0.1, age: 0, dead: 0 });
        note('New salmon cohort stocked at ' + co.name + '.', 'n', co.id);
      }
    }
    let rev = 0, cogs = 0, biomass = 0;
    fm.coh.forEach(c => {
      c.age++;
      const g = (5.3 - 0.1) / tw.grow * growQ * (1 + 0.15 * Math.sin(c.age / 6)) * (0.8 + 0.4 * ([6, 7, 8, 9].indexOf(wMonth(S.week)) >= 0 ? 1 : 0.5));
      c.kg += g;
      const mort = 0.0016 * ill * (1 + (c.illx || 0) * 10) + (chance(0.002 * ill) ? 0.04 : 0);
      const dead = c.n * Math.min(0.5, mort);
      c.n -= dead;
      c.dead += dead;
      if (c.illx) c.illx *= 0.8;
      const feed = g * c.n * tw.feed * (1.25 / 1) * (1 + feedK) / 1000 * 1000 / 1000;
      cogs += g * c.n * 1.25 * 27 * (1 + feedK) / 1;
      biomass += c.n * c.kg / 1000;
    });
    fm.bio = biomass;
    const spot = 84 * S.econ.salmon;
    fm.price = spot;
    co.dbg = { D: 0, cap: 0, dp: {}, cp: [], bot: '', cohorts: fm.coh.length };
    // harvest when ready
    fm.coh = fm.coh.filter(c => {
      if (c.kg >= 5.1 && co.flags.harvest !== 0) {
        const t = c.n * c.kg * 0.88 / 1000;
        const r = t * 1000 * spot;
        rev += r;
        ctx.units += t;
        note('Harvest at ' + co.name + ': ' + Math.round(t) + ' tonnes sold at ' + Math.round(spot) + ' NOK/kg = ' + money(r) + '.', 'good', co.id);
        return false;
      }
      return true;
    });
    cogs += biomass * 1000 * 0.15 / 1; // health, site ops per kg of biomass per week (approx 0.15 NOK/kg/wk)
    ctx.rev = rev;
    ctx.cogs = cogs;
    ctx.util = 0.7;
    ctx.price = spot * 1000;
    co.lastW = { units: ctx.units, rev: Math.round(rev), cogs: Math.round(cogs), D: 0, cap: 0, util: 0.7 };
  },
  fx(co, bd, fx) {
    if (fx.ill) (co.fm.coh || []).forEach(c => {
      c.illx = (c.illx || 0) + fx.ill;
    });
  }
};
FAM.salmon.checklist = (co, bd, items) => { };
FAM.prod.fx = (co, bd, fx) => {
  if (bd.id === 'salmon' && FAM.salmon.fx) FAM.salmon.fx(co, bd, fx);
};
FAM.prod.custom = function (co, bd, ctx) {
  if (bd.id === 'salmon') return FAM.salmon.custom(co, bd, ctx);
  // generic prod path
  const dm = demand(co, bd), cp = capacity(co, bd);
  ctx.D = dm.D;
  ctx.cap = cp.cap;
  acctDemand(co, ctx);
  co.dbg = { D: dm.D, cap: cp.cap, dp: dm.parts, cp: cp.parts, bot: cp.bot ? cp.bot.label : '', owner: cp.owner, botObj: cp.bot ? { kind: cp.bot.kind, k: cp.bot.k } : null };
  ctx.price = ticketEff(co, bd);
  ctx.gd = goodsEff(co);
  ctx.cogsMult = ctx.gd.m;
  FAM.prod.pre(co, bd, ctx);
  let units;
  if (window.R10U && window.R10U(co, bd, ctx)) units = ctx.units;
  else {
    units = Math.min(ctx.D, ctx.cap);
    units = Math.max(0, Math.min(ctx.cap, units * (1 + gauss() * 0.045)));
    units = stockUnits(co, bd, ctx, units);
    units = Math.round(units * 10) / 10;
  }
  ctx.units = units;
  ctx.util = ctx.cap > 0 ? units / ctx.cap : 0;
  ctx.rev = units * ctx.price;
  const mq = co.mgr ? mgrQual(co) : 0.5;
  let cr = (bd.cogs + knobFx(co, 'c', 'sum')) * (co.mgr ? 1.04 - 0.08 * mq : 1) * modProd(co, 'price') * modProd(co, 'cogsup') * ctx.gd.m;
  ctx.cr = Math.max(0.01, cr);
  if (ctx.Da) {
    ctx.rev0 = ctx.rev;
    ctx.rev = acctRev(co, ctx);
  }
  ctx.cogs = (ctx.rev0 || ctx.rev) * ctx.cr;
  if (ctx.Da) ctx.cogs *= (1 - 0.05 * ctx.Da / ctx.D);
  if (ctx.gd.v) vbuy(ctx.gd.v.id, ctx.cogs);
  if (bd.tw.perish) ctx.cogs += ctx.rev * bd.tw.perish * (1 + Math.max(0, 0.85 - ctx.util) * 2.2) * (co.mgr ? 1.2 - 0.5 * mq : 1);
  if (bd.tw.shrink) ctx.cogs += ctx.rev * bd.tw.shrink * (co.flags.secure ? 0.5 : 1) * (1 + (co.flags.shrinkUp || 0));
  if (bd.tw.excise) ctx.cogs += ctx.units * 8.5 * Math.pow(1 + S.econ.infl, S.week / 52);
  FAM.prod.post(co, bd, ctx);
};
FAM.prod.checklist = (co, bd, items) => {
  if (bd.id === 'salmon') items.push({
    k: 'cash',
    t: 'Cash for first smolt stocking (about ' + money(Math.round(bd.tw.tonnes / 4.6 * 1000 * 14.5)) + ')',
    ok: co.cash > bd.tw.tonnes / 4.6 * 1000 * 14.5,
    sub: ''
  });
};
SEAS.harvest = [.2, .2, .2, .4, .6, .8, 1.2, 2.4, 2.4, 1.6, .5, .3];
BD.farm.seas = 'harvest';


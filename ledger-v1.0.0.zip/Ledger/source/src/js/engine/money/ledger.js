/* ---- src/money/ledger.js ---- */
/* ===== Ledger: the one place where cash balances change =====
   Every change to a cash balance goes through moveCash() or setCash():
   your private account (holder ME) or a company (holder = the company object).
   Each holder keeps a running total of everything booked in S.flow, so a test can
   prove that cash always equals what was booked: nothing appears or disappears.
   Never write  x.cash += ...  anywhere else.
   Your private account also keeps a statement (S.log, newest first): every movement is one line with its name, the
   company it concerns, the day it happened and the balance after it, so no money moves without a line. While the
   weekly simulation runs (ui/screens/mockup.js stageWeek) the lines wait in S.stage; each then lands whole on one day
   of the week (releaseDay), money and line together. */
const ME = 'me';
const STMT_MAX = 600;
function cashHolder(h) {
  return h === ME ? S : h;
}
function flowKey(h) {
  return h === ME ? 'me' : 'co' + h.id;
}
/* the balance moves; no statement line (only for the weekly staging, which writes the lines itself) */
function cashRaw(h, amt) {
  const o = cashHolder(h);
  o.cash += amt;
  const f = S.flow || (S.flow = {});
  const k = flowKey(h);
  f[k] = (f[k] || 0) + amt;
}
/* why: the line on your statement; coId: the company it concerns */
function moveCash(h, amt, why, coId) {
  cashRaw(h, amt);
  if (h !== ME || !amt) return;
  const x = { a: amt, l: why || 'Other', co: coId || 0 };
  if (S.stage) S.stage.push(x);
  else stmtLine(x);
}
function stmtLine(x) {
  S.log = S.log || [];
  S.log.unshift({ w: S.week, d: S.day || 0, a: Math.round(x.a), l: x.l, co: x.co || 0, bal: Math.round(S.cash) });
  if (S.log.length > STMT_MAX) S.log.length = STMT_MAX;
}
function setCash(h, v, why) {
  const o = cashHolder(h);
  const d = v - o.cash;
  o.cash = v;
  const f = S.flow || (S.flow = {});
  const k = flowKey(h);
  f[k] = (f[k] || 0) + d;
}
/* checks used by tests: difference between cash and what was booked, per holder */
function ledgerGaps() {
  const f = S.flow || {};
  const gaps = [];
  const me = S.cash - (S.cash0 || 0) - (f.me || 0);
  if (Math.abs(me) > 1) gaps.push(['me', me]);
  S.cos.forEach(c => {
    const g = c.cash - (f['co' + c.id] || 0);
    if (Math.abs(g) > 1) gaps.push([c.name, g]);
  });
  return gaps;
}


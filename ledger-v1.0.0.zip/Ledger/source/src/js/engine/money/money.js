/* ---- src/money/money.js ---- */
/* ===== Money: personal accounts, loans, credit, taxes, net worth ===== */
function bk(co, cat, amt) {
  if (!co.bk.t) co.bk.t = {};
  ['w', 'm', 'y', 't'].forEach(p => {
    co.bk[p][cat] = (co.bk[p][cat] || 0) + amt;
  });
}
/* an unpaid invoice (amount includes VAT): the net part is a loss, the VAT part is reclaimed */
function recvLoss(co, gross) {
  const vr = CC().salesTax ? 0 : vatRate(co); /* sales-tax countries: business invoices carry no tax */
  const net = gross / (1 + vr);
  bk(co, 'loss', net);
  co.vatAcc -= gross - net;
}
/* Selling unpaid invoices to the bank (factoring): the bank pays now, less a fee, and takes over collecting them,
   including the risk that a customer never pays. The fee grows with the weeks until they fall due and is higher
   in a weak economy, lower when you check customers before invoicing. */
function invoiceSale(co) {
  const L = (co.recv || []).filter(r => r.a > 0);
  const risk = 0.012 * (S.econ.dem < 0.97 ? 1.8 : 1) * (co.flags.ccheck ? 0.5 : 1);
  let a = 0, fee = 0;
  L.forEach(r => { a += r.a; fee += r.a * (0.01 + 0.004 * Math.max(0, r.due - S.week) + risk); });
  return { n: L.length, a: Math.round(a), fee: Math.round(fee), get: Math.round(a - fee) };
}
function sellInvoices(co) {
  const q = invoiceSale(co);
  if (!q.n || q.get <= 0) return 'none';
  co.recv = (co.recv || []).filter(r => !(r.a > 0));
  coIn(co, q.a, null, 'Unpaid invoices sold to the bank');
  payCo(co, q.fee, 'int', 'Fee for selling invoices');
  return q;
}
/* Group contribution: companies in a tax group (a holding company and the limited companies in the same country
   it owns 90% or more of) set this year's profits against this year's losses. The profit that covers a sister
   company's loss is not taxed, and the loss it covered is used up instead of carried forward. Worked out with the
   monthly tax accrual (monthEndCoCore in engine/core/week.js). */
function taxGroup(co) {
  if (!co || co.form !== 'AS') return null;
  const h = co.type === 'hold' ? co : co.hold ? getCo(co.hold) : null;
  if (!h || h.st === 'sold' || h.st === 'bust') return null;
  const cc = h.country || S.country;
  const L = [h].concat(S.cos.filter(c => c.hold === h.id && c.form === 'AS' && c.st !== 'sold' && c.st !== 'bust' && c.st !== 'setup' && (c.own == null ? 100 : c.own) >= 90 && (c.country || S.country) === cc));
  return L.length > 1 && L.indexOf(co) >= 0 ? L : null;
}
function groupContrib(co) {
  const L = taxGroup(co), z = { out: 0, in: 0 };
  if (!L) return z;
  const P = c => Math.max(0, (c.ytdP || 0) - (c.lc0 || 0)), Lo = c => Math.max(0, -(c.ytdP || 0));
  const tp = sum(L, P), tl = sum(L, Lo), used = Math.min(tp, tl);
  if (used <= 0) return z;
  return { out: P(co) / tp * used, in: Lo(co) / tl * used };
}
/* change in the market value of something the company owns (property, fields, stakes): not profit until sold */
function revalue(co, delta) {
  co.reval = (co.reval || 0) + delta;
}
/* money between owner and company (capital, investments, drawings, dividends): not profit or loss */
function ownerFlow(co, amt) {
  co.ownNet = (co.ownNet || 0) + amt;
}
/* payCo: a company pays. 'payCo.amount' steps can change the amount (a lawyer or legal team cuts fines), then
   'payCo.later' steps can take the payment to pay later (monthly bills build up during the week); otherwise payCoCore. */
function payCo(co, amt, cat, label) {
  amt = runSteps('payCo.amount', amt, co, cat, label);
  if (runSteps('payCo.later', false, co, amt, cat, label)) return true;
  return payCoCore(co, amt, cat, label);
}
function payCoCore(co, amt, cat, label) {
  if (cat === 'fine') {
    if (co.law) amt *= 1.1 - 0.45 * co.law.q;
    if (hasHQ('law')) amt *= 0.85;
  }
  amt = Math.round(amt);
  if (amt <= 0) return true;
  moveCash(co, -(amt));
  if (cat) bk(co, cat, amt);
  if (label) {
    co.tx.unshift({ w: S.week, a: -amt, l: label });
    if (co.tx.length > 40) co.tx.length = 40;
  }
  return co.cash >= 0;
}
function coIn(co, amt, cat, label) {
  amt = Math.round(amt);
  moveCash(co, amt);
  if (cat) bk(co, cat, amt);
  if (label) {
    co.tx.unshift({ w: S.week, a: amt, l: label });
    if (co.tx.length > 40) co.tx.length = 40;
  }
}
function closeLoan(l, repaid, keep) {
  repaid = Math.max(0, Math.min(l.bal, repaid || 0));
  if (l.bank) {
    const b = getCo(l.bank);
    if (b && b.st === 'open') {
      moveCash(b, repaid);
      b.fm.gb = Math.max(0, (b.fm.gb || 0) - l.bal);
      const loss = l.bal - repaid;
      if (loss > 1 && !keep) bk(b, 'loss', loss);
    }
    l.bank = 0;
  }
  if (keep) {
    l.bal -= repaid;
    l.co = 0;
    if (l.bal < 1) S.loans = S.loans.filter(x => x !== l);
  } else S.loans = S.loans.filter(x => x !== l);
}
function payHQ(amt, label) {
  amt = Math.round(amt);
  const h = (typeof liveCos === 'function' ? liveCos() : []).find(c => c.type === 'hold' && c.cash > amt * 3);
  if (h) {
    payCo(h, amt, 'wages', label);
    return;
  }
  payMe(amt, label);
  if (S.cos.some(c => c.form === 'ENK' && c.st !== 'sold' && c.st !== 'bust')) S.tax.hqDed = (S.tax.hqDed || 0) + amt;
}
function payMe(amt, label) {
  amt = Math.round(amt);
  moveCash(ME, -(amt), label);
}
function gainMe(amt, label) {
  amt = Math.round(amt);
  moveCash(ME, amt, label);
}
/* when the current account is short, the rest comes over from savings: one transfer on the statement */
function fromSavings(need) {
  const r = Math.min(Math.max(0, S.sav.bal), need - Math.max(0, S.cash));
  if (r > 0) {
    S.sav.bal -= r;
    moveCash(ME, r, 'From savings');
  }
}
function liquid() {
  return S.cash + S.sav.bal;
}
/* loans */
function policy() {
  return S.econ.rate;
}
function creditWord() {
  const c = S.credit;
  return c >= 80 ? 'Excellent' : c >= 65 ? 'Good' : c >= 50 ? 'Fair' : c >= 35 ? 'Weak' : 'Poor';
}
function qualWord(x) {
  return x >= 85 ? 'Exceptional' : x >= 70 ? 'High' : x >= 55 ? 'Good' : x >= 40 ? 'Moderate' : 'Basic';
}
function moodWord(x) {
  return x < 25 ? 'Close to quitting' : x < 40 ? 'Unhappy' : x < 60 ? 'Fine' : x < 80 ? 'Content' : 'Motivated';
}
function condWord(x) {
  return x >= 0.9 ? 'Like new' : x >= 0.7 ? 'Good condition' : x >= 0.5 ? 'Worn' : x >= 0.3 ? 'Poor condition' : 'Barely working';
}
function creditBand() {
  const c = S.credit;
  return c >= 80 ? 'A' : c >= 65 ? 'B' : c >= 50 ? 'C' : c >= 35 ? 'D' : 'E';
}
function creditMargin() {
  const c = S.credit;
  return c >= 80 ? 0.018 : c >= 65 ? 0.028 : c >= 50 ? 0.045 : c >= 35 ? 0.075 : 0.12;
}
/* loanRate: the core below, then the steps features add: pipeSteps('loanRate') */
function loanRate(l) {
  return runSteps('loanRate', loanRateCore(l), l);
}
function loanRateCore(l) {
  return Math.max(0.005, policy() + l.margin);
}
function totalDebt(personalOnly) {
  return sum(S.loans.filter(l => !personalOnly || !l.co), l => l.bal);
}
/* loanOffer: the core below, then the steps features add: pipeSteps('loanOffer') */
function loanOffer(kind, amt, co) {
  return runSteps('loanOffer', loanOfferCore(kind, amt, co), kind, amt, co);
}
function loanOfferCore(kind, amt, co) {
  const nw = netWorth();
  const band = creditBand();
  let margin = creditMargin() + (kind === 'biz' ? 0.01 : kind === 'mort' ? -0.012 : kind === 'cons' ? 0.03 : kind === 'lomb' ? -0.004 : 0);
  let max;
  if (kind === 'cons') max = Math.max(0, 80000 + Math.max(0, nw.total) * 0.15) * (band === 'A' ? 2 : band === 'B' ? 1.4 : band === 'C' ? 1 : band === 'D' ? 0.4 : 0);
  else if (kind === 'biz') {
    const base = co ? Math.max(0, coEbit12(co)) * 3 + coAssets(co) * 0.5 : 0;
    max = (base + Math.max(0, nw.total) * 0.25) * (band === 'E' ? 0 : band === 'D' ? 0.5 : 1);
  }
  else if (kind === 'mort') max = Math.max(0, nw.total) * 1.6 * (band === 'E' ? 0 : 1);
  /* lending against what you own (art, watches, homes, boats, estates): the collateral steps say how much the bank
     lends on each (features/player/lifestyle.js, estates.js); what is already borrowed on it counts */
  else if (kind === 'lomb') max = Math.max(0, runSteps('collateral', 0) - sum(S.loans.filter(l => !l.co && l.kind === 'lomb'), l => l.bal)) * (band === 'E' ? 0 : 1);
  else max = 0;
  /* real bank rules: what you already owe counts against you, and payments must fit your income */
  const owedP = sum(S.loans.filter(l => !l.co), l => l.bal), owedC = co ? sum(S.loans.filter(l => l.co === co.id), l => l.bal) : 0;
  const payP = sum(S.loans.filter(l => !l.co), l => l.pay) * 12, payC = co ? sum(S.loans.filter(l => l.co === co.id), l => l.pay) * 12 : 0;
  const incP = Math.max(sum(S.cos.filter(c => c.st === 'open' && c.form === 'AS'), c => (c.ownerSalary || 0) * 12) + 0.4 * sum(S.cos.filter(c => c.st === 'open'), c => Math.max(0, coEbit12(c)) * (c.own || 100) / 100), 380000 * (CC().wage0 || 1));
  const rate = policy() + margin;
  const perM = amt0 => annuity(amt0, rate, 60) * 12;
  const room = (inc, pay) => {
    const free = Math.max(0, inc * 0.4 - pay);
    const f = perM(100000) / 100000;
    return f > 0 ? free / f : 0;
  };
  if (kind === 'cons') max = Math.min(Math.max(0, max - owedP), room(incP, payP));
  else if (kind === 'mort') max = Math.min(Math.max(0, max - sum(S.loans.filter(l => !l.co && l.kind === 'mort'), l => l.bal)), room(incP * 1.6, payP));
  else if (kind === 'biz') {
    max = Math.max(0, max - owedC);
    if (co && co.hist && co.hist.length >= 3) max = Math.min(max, room(Math.max(0, coEbit12(co)) * 0.8, payC));
  }
  if ((owedP + owedC) > Math.max(1, nw.total) * 0.6) margin += 0.012;
  const bankCo = S.cos.find(c => c.type === 'bank' && c.st === 'open');
  if (bankCo) margin -= 0.006; // own bank: cheaper (it earns the spread)
  return { max: Math.floor(max / 1000) * 1000, margin, band, ownBank: bankCo ? bankCo.id : 0 };
}
function takeLoan(kind, amt, termM, co, guar) {
  const off = loanOffer(kind, amt, co);
  if (amt > off.max) return 'declined';
  if (amt < KC(5000, co ? co.country : S.country)) return 'small';
  const l = {
    id: uid(),
    kind,
    name: kind === 'biz' ? 'Business loan' : kind === 'cons' ? 'Consumer loan' : kind === 'lomb' ? 'Loan against your collection' : 'Mortgage',
    bal: amt,
    amt0: amt,
    margin: off.margin,
    pay: 0,
    termM,
    co: co ? co.id : 0,
    w0: S.week,
    guar: guar ? 1 : 0,
    bank: off.ownBank
  };
  if (l.bank) {
    const b = getCo(l.bank);
    if (b && b.st === 'open' && b.cash > amt * 1.2) {
      moveCash(b, -(amt));
      b.fm.gb = (b.fm.gb || 0) + amt;
    } else l.bank = 0;
  }
  l.pay = annuity(amt, policy() + off.margin, termM);
  S.loans.push(l);
  if (co) {
    coIn(co, amt, null, 'Loan drawn');
  } else gainMe(amt, 'Loan drawn');
  return 'ok';
}
function repayLoan(l, amt) {
  amt = Math.min(amt, l.bal);
  const co = l.co ? getCo(l.co) : null;
  if (co) {
    if (co.cash < amt) return false;
    payCo(co, amt, null, 'Loan repaid');
  } else {
    if (liquid() < amt) return false;
    payMe(amt, 'Loan repaid');
  }
  if (l.bank) {
    const b = getCo(l.bank);
    if (b && b.st === 'open') {
      moveCash(b, amt);
      b.fm.gb = Math.max(0, (b.fm.gb || 0) - amt);
    }
  }
  l.bal -= amt;
  if (l.bal < 1) S.loans = S.loans.filter(x => x !== l); else l.pay = Math.min(l.pay, annuity(l.bal, policy() + l.margin, 12));
  return true;
}
function loansDueMonth() {
  S.loans.slice().forEach(l => {
    const r = loanRate(l);
    if (l.pay > 0 && l.kind !== 'start') {
      const remM = Math.max(1, (l.termM || 120) - Math.floor((S.week - (l.w0 || 0)) / 4.33));
      l.pay = Math.max(annuity(l.bal, r, remM), l.bal * r / 12 * 1.02);
    }
    const int = l.bal * r / 12, prin = l.graceW && S.week < l.graceW ? 0 : Math.min(l.bal, Math.max(0, l.pay - int)), total = int + prin; /* interest only during a grace period */
    const co = l.co ? getCo(l.co) : null;
    if (co && (co.st === 'sold' || co.st === 'bust')) return;
    const ok = co ? payCoLoan(co, int, prin, l) : payPersonalLoan(int, prin, l);
    l.bal -= prin;
    if (l.bank) {
      const b = getCo(l.bank);
      if (b && b.st === 'open') {
        coIn(b, int, 'rev', 'Interest from group');
        moveCash(b, prin);
        b.fm.gb = Math.max(0, (b.fm.gb || 0) - prin);
      }
    }
    if (l.bal < 1) {
      S.loans = S.loans.filter(x => x !== l);
      note('Loan paid off: ' + l.name + '.', 'good', l.co);
    }
  });
}
function payPersonalLoan(int, prin, l) {
  const t = int + prin;
  moveCash(ME, -(Math.round(t)), 'Loan payment: ' + l.name);
  S.stats.interest = (S.stats.interest || 0) + int;
  if (S.cash < -S.overdraftLimit) {
    S.credit = clamp(S.credit - 4, 0, 100);
    note('You could not cover a loan payment in full.', 'bad');
    return false;
  }
  if (S.cash < 0) { /* overdraft */ }
  return true;
}
function payCoLoan(co, int, prin, l) {
  moveCash(co, -(Math.round(int + prin)));
  bk(co, 'int', int);
  co.tx.unshift({ w: S.week, a: -(int + prin), l: 'Loan payment: ' + l.name });
  return co.cash >= -coOverdraft(co);
}
function coOverdraft(co) {
  return Math.max(0, coWeekCost(co) * 3);
}
/* monthly personal processes */
function personalMonth() {
  const c = CC();
  if (S.cash < 0) {
    const i = -S.cash * 0.16 / 12;
    moveCash(ME, -(i), 'Overdraft interest');
    S.credit = clamp(S.credit - 0.4, 0, 100);
  }
  if (S.sav.bal > 0) {
    const i = S.sav.bal * Math.max(0.005, policy() - 0.012) / 12;
    S.sav.bal += i;
    S.tax.int = (S.tax.int || 0) + i;
  }
  loansDueMonth();
  if (S.cash >= 0 && totalDebt() > 0) S.credit = clamp(S.credit + 0.35, 0, 100);
  if (!S.loans.length) S.credit = clamp(S.credit + 0.1, 0, 100);
  const age = S.player.age + S.week / 52;
  if (age > 60) S.credit = clamp(S.credit - 0.02, 0, 100);
}
/* yearly tax and wealth */
function enkIncome() {
  let t = S.tax.enkFrozen || 0;
  S.cos.forEach(c => {
    if (c.form === 'ENK' && c.st !== 'sold') t += (c.bk.y.rev || 0) - sumExp(c.bk.y);
  });
  return t - (S.tax.hqDed || 0);
}
function sumExp(b) {
  return (b.cogs || 0) + (b.wages || 0) + (b.rent || 0) + (b.mkt || 0) + (b.ins || 0) + (b.oth || 0) + (b.dep || 0) + (b.int || 0) + (b.fine || 0) + (b.loss || 0) + (b.acc || 0);
}
function personalTaxEstimate() {
  const t = S.tax, c = CC();
  const enk = Math.max(0, enkIncome() - (S.enkLoss || 0)), wage = t.wage || 0;
  const tax1 = personalTax(enk + wage, wage > enk ? 'wage' : 'self');
  return Math.max(0, tax1 - (t.withheld || 0)) + Math.max(0, t.gain || 0) * c.divTax + dividendTax(t.ytdDiv || 0, t.shield || 0) + (t.int || 0) * c.divTax;
}
function yearEndPersonal() {
  const c = CC();
  const t = S.tax;
  const rawE = enkIncome(), lc0 = S.enkLoss || 0;
  const enk = Math.max(0, rawE - lc0);
  S.enkLoss = Math.max(0, lc0 - rawE);
  const wage = t.wage || 0;
  const inc = enk + wage;
  const tax1 = personalTax(inc, wage > enk ? 'wage' : 'self');
  const withheld = t.withheld || 0;
  const gain = Math.max(0, (t.gain || 0));
  const taxGain = gain * c.divTax;
  const divT = dividendTax(t.ytdDiv || 0, t.shield || 0);
  const intT = (t.int || 0) * c.divTax;
  const net = netWorth().total;
  const wtax = Math.max(0, (net - sum(S.cos, x => x.st === 'sold' ? 0 : companyValue(x) * x.own / 100) * (1 - c.wealthShare) - c.wealthThr)) * c.wealthRate;
  const due = Math.max(-(t.adv || 0), tax1 - withheld) + taxGain + divT + intT + wtax;
  payMe(due, 'Annual tax assessment (income, gains, wealth)');
  S.stats.taxPaid += due + withheld;
  note('Annual personal tax: ' + money(due) + (withheld ? ' (after ' + money(withheld) + ' withheld)' : '') + (wtax ? ', including wealth tax ' + money(wtax) : '') + '.', 'n');
  S.tax = { ytd: 0, paid: 0, enkIncome: 0, wage: 0, div: 0, ytdDiv: 0, withheld: 0, gain: 0, int: 0, shield: 0 };
  S.stats.years++;
}
/* net worth */
function companyAssets(co) {
  return co.cash + sum(co.recv, r => r.a) + Math.max(0, -co.vatAcc) + co.inv + ((co.prem && co.prem.dep) || 0) + eqBook(co) + (co.prem && co.prem.owned ? co.prem.val : 0) + sum(co.props || [], p => p.val) + (co.fm && co.fm.assets ? co.fm.assets : 0) + (co.luxBV || 0) + (co.fr && co.fr.units ? sum(co.fr.units, u => u.loan ? u.loan.bal : 0) : 0);
}
function coAssets(co) {
  return eqBook(co) + (co.prem && co.prem.owned ? co.prem.val : 0) + sum(co.props || [], p => p.val) + co.inv + (co.luxBV || 0);
}
function companyDebts(co) {
  return sum(S.loans.filter(l => l.co === co.id), l => l.bal) + co.pay.wages + co.pay.other + (co.pay.rent || 0) + Math.max(0, co.vatAcc) + co.pay.tax + (co.fm && co.fm.liab ? co.fm.liab : 0);
}
function coEbit12(co) {
  const h = co.hist.slice(-12);
  if (h.length < 3) return co.bk.y.rev ? (co.bk.y.rev - sumExp(co.bk.y)) * (52 / Math.max(4, S.week - co.w0 + 1)) : 0;
  return sum(h, x => x.profit) * (12 / h.length);
}
/* companyValue: the core below, then the steps features add: pipeSteps('companyValue') */
function companyValue(co) {
  return runSteps('companyValue', companyValueCore(co), co);
}
function companyValueCore(co) {
  if (co.st === 'sold' || co.st === 'bust') return 0;
  const bd = BD[co.type];
  if (bd.fam === 'club' && co.fm && co.fm.val) return Math.round(co.fm.val + co.cash);
  const net = companyAssets(co) - companyDebts(co);
  const mult = bd.fam === 'fin' ? 1.0 : bd.fam === 'rent' ? 0.0 : bd.fam === 'energy' ? 5 : (bd.m > 0.2 ? 5 : 4);
  const prof = Math.max(0, coEbit12(co));
  /* buyers pay for a track record: goodwill counts fully after two years of accounts, a quarter after six months
     (V.1.0.0: a young company with a good start no longer doubles your net worth overnight) */
  const trust = Math.min(1, (co.hist || []).length / 24);
  const gw = co.st === 'open' && (S.week - co.w0 > 12) ? prof * mult * (0.6 + co.rep / 200) * (co.mgr ? 0.85 : 1) * trust : 0;
  const adj = co.form === 'ENK' ? 0.85 : 1;
  return Math.round(net + gw * adj - Math.max(0, prof - 0) * 0.0);
}
function eqBook(co) {
  let t = 0;
  for (const id in co.eq) {
    const e = co.eq[id];
    t += e.bv;
  }
  for (const v of co.veh) t += v.bv;
  return t;
}
/* net worth: what you own minus what you owe. netWorthCore counts cash, savings, investments and companies;
   the 'netWorth' steps add your luxury collection, startups you founded and stakes in other groups. */
function netWorth() {
  return runSteps('netWorth', netWorthCore());
}
function netWorthCore() {
  let personal = S.cash + S.sav.bal, inv = 0, crypto = 0, funds = 0, cosV = 0, props = 0, taxEst = 0;
  for (const s in S.inv.stocks) inv += S.inv.stocks[s].q * (S.stocks[s] ? S.stocks[s].p : 0);
  for (const s in S.inv.crypto) crypto += S.inv.crypto[s].q * (S.crypto[s] ? S.crypto[s].p : 0);
  S.inv.deposits.forEach(d => {
    funds += d.bal;
  });
  for (const k in S.inv.funds) funds += S.inv.funds[k].q * fundPx(k);
  if (S.fm) funds += S.fm.bal;
  S.startups.forEach(s => {
    if (s.st === 'live') cosV += s.val * s.pct / 100;
  });
  S.cos.forEach(c => {
    if (c.st !== 'sold' && c.st !== 'bust' && !c.hold) cosV += companyValue(c) * c.own / 100;
  });
  const debt = sum(S.loans.filter(l => !l.co), l => l.bal) + (S.cash < 0 ? 0 : 0);
  const guar = sum(S.loans.filter(l => l.co && l.guar && getCo(l.co) && getCo(l.co).form === 'AS'), l => l.bal) * 0; // guarantees only matter on default
  const total = personal + inv + crypto + funds + cosV - debt - (S.tax.pending || 0);
  return { personal, inv, crypto, funds, cos: cosV, debt, total };
}

/* sole traders pay advance tax each quarter; it counts as withheld at the yearly assessment */
function advTaxMonth() {
  const mi = monthIdx(S.week) % 12;
  if (mi % 3 !== 2) return;
  const q = Math.floor(mi / 3);
  const enk = Math.max(0, enkIncome() - (S.enkLoss || 0));
  if (enk <= 0) return;
  const target = 0.9 * personalTax(enk * 4 / (q + 1), 'self') * (q + 1) / 4;
  const paid = S.tax.adv || 0;
  const pay = Math.round(target - paid);
  if (pay < 100) return;
  S.tax.adv = paid + pay;
  S.tax.withheld = (S.tax.withheld || 0) + pay;
  payMe(pay, 'Advance tax (sole trader)');
}


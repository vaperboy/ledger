Full-size pictures for Ledger. The game uses smaller copies in the pictures folder next to ledger.html:
make them with  python3 tools/pictures.py  after adding or changing a picture here.
cars/            the luxury cars, by their id in the game (c1 ... c15); the game also carries small copies inside
warehouses/      warehouses and industrial halls, wh1 (smallest) ... wh6 (largest)
offices/         offices, of1 (smallest) ... of6 (largest); also used for your own office
private-jets/    jets in the luxury shop, by id
luxury-houses/   homes in the luxury shop, by id
watches/         watches in the luxury shop, by id

(() => {
const out = [];
const plan = [[A1, 'meta', 4000], [A3, 'flyer', 1000], [A2, 'google', 3500]];
plan.forEach(([co, k, b]) => { co.mkt = {}; co.mk19 = { base: 0, nw: 0, seo: 0, ch: {} }; setMkt(co, k, b); co.mktEnd = co.mktEnd || {}; co.mktEnd[k] = S.week + 12; co.m30sp = (co.bk.y.mkt || 0); });
const wk = plan.map(() => []);
let lastW = S.week;
for (let d = 0; d < 7 * 13; d++) {
  window.auto29(1, []);
  if (S.week !== lastW) { lastW = S.week; plan.forEach(([co, k], i) => { const c = co.mk19.ch[k]; wk[i].push(c ? c.cust : 0); }); }
}
plan.forEach(([co, k, b], i) => {
  const c = co.mk19.ch[k] || {}; const cum = wk[i]; const per = cum.map((v, j) => v - (j ? cum[j - 1] : 0));
  out.push(co.name + ' ' + k + ' ' + b + '/wk: weeks=' + c.w + ' spent=' + Math.round(c.sp) + ' (budget×weeks=' + b * c.w + ') booked mkt in books=' + Math.round((co.bk.y.mkt || 0) - co.m30sp) + ' | new customers per week: ' + per.join(',') + ' | total ' + (c.cust || 0) + ' | still buying ' + Math.round(c.base || 0) + ' | still running: ' + !!co.mkt[k]);
});
return out.join('\n');
})()

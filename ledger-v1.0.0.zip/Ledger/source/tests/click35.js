(() => {
const out = [], errs = [];
window.onerror = (m) => errs.push(m);
const tryv = (l, f) => { try { UI.ui.sheet = null; f(); UI.render(true); const t = document.body.innerText; out.push((/undefined|NaN|\[object/.test(t) ? 'BAD ' : 'ok ') + l); } catch (e) { out.push('ERR ' + l + ': ' + e.message); } };
const cos = S.cos.filter(c => c.st !== 'sold' && c.st !== 'bust');
cos.forEach(c => ['ov', 'cli', 'mk', 'st', 'money', 'more', 'fin', 'deal', 'ops', 'mon', 'ana', 'eq', 'doc'].forEach(t => tryv(c.name + ' ' + t, () => UI.go('co', { id: c.id, t }))));
cos.forEach(c => ['books', 'value', 'loans', 'legal', 'tx', 'close', 'sell', 'owner'].forEach(s => tryv(c.name + ' fin/' + s, () => UI.go('co', { id: c.id, t: 'fin', s }))));
cos.forEach(c => ['supply', 'rivals', 'grow', 'reach', 'cust'].forEach(s => tryv(c.name + ' deal/' + s, () => UI.go('co', { id: c.id, t: 'deal', s }))));
cos.forEach(c => ['assets', 'docs', 'ins'].forEach(s => tryv(c.name + ' ops/' + s, () => UI.go('co', { id: c.id, t: 'ops', s }))));
cos.forEach(c => ['pay', 'bills', undefined].forEach(v => tryv(c.name + ' payroll29/' + v, () => UI.go('payroll29', { id: c.id, v }))));
cos.forEach(c => ['m', 'acc', 'tx', 'bills'].forEach(v => tryv(c.name + ' results/' + v, () => { UI.go('res36', { id: c.id }); UI.ACT.res36t({ v }); })));
['mkt36', 'found36', 'svc36', 'newbiz', 'franchises'].forEach(n => tryv('view ' + n, () => UI.go(n)));
['tax', 'acc', 'loans'].forEach(v => tryv('bank ' + v, () => { UI.ACT.tab('phone'); UI.ACT.phapp({ n: 'bank' }); UI.ACT.btab({ v }); }));
['su', 'stocks'].forEach(v => tryv('invest ' + v, () => { UI.ACT.tab('phone'); UI.ACT.phapp({ n: 'invest' }); UI.ACT.itab({ v }); }));
['ind', 'cc', 'world'].forEach(f => tryv('rankings ' + f, () => { UI.ui.rk27f = f; UI.ACT.tab('phone'); UI.ACT.phapp({ n: 'stats' }); UI.ACT.st27({ v: 'rk' }); }));
/* every row on the new tabs opens something */
let rows = 0;
cos.slice(0, 3).forEach(c => ['money', 'more', 'st', 'ov'].forEach(t => {
  UI.ui.sheet = null; UI.go('co', { id: c.id, t }); UI.render(true);
  [...document.querySelectorAll('main .lrow[data-a]')].map(b => [b.getAttribute('data-a'), b.getAttribute('data-p'), b.textContent.trim().slice(0, 30)]).forEach(x => {
    tryv(c.name + ' ' + t + ' › ' + x[2], () => { UI.go('co', { id: c.id, t }); UI.render(true); UI.ACT[x[0]](JSON.parse(x[1] || '{}')); }); rows++;
  });
}));
['you', 'grp', 'office', 'group', 'managers', 'suppliers', 'dealroom'].forEach(t => tryv('hq ' + t, () => { UI.ACT.tab('hq'); UI.ACT.hqtab(t); }));
['you', 'grp'].forEach(t => { UI.ACT.tab('hq'); UI.ACT.hqtab(t); UI.render(true); [...document.querySelectorAll('main .lrow[data-a="go"]')].map(b => [b.getAttribute('data-p'), b.textContent.trim().slice(0, 24)]).slice(0, 8).forEach(x => tryv('hq ' + t + ' › ' + x[1], () => { UI.ACT.tab('hq'); UI.ACT.go(JSON.parse(x[0])); })); });
tryv('phone', () => UI.ACT.tab('phone'));
['bank', 'invest', 'news', 'reviews', 'stats', 'lux', 'settings'].forEach(n => tryv('app ' + n, () => { UI.ACT.tab('phone'); UI.ACT.phapp({ n }); }));
['dec', 'msgs', 'meet'].forEach(t => tryv('inbox ' + t, () => { UI.ACT.tab('meet'); UI.ACT.mtab(t); }));
tryv('companies', () => UI.ACT.tab('cos'));
tryv('weekreport', () => UI.go('weekreport'));
['cos', 'ev'].forEach(k => tryv('weekreport sheet ' + k, () => { UI.go('weekreport'); UI.render(true); UI.ACT.wr35s({ k }); }));
['nw', 'cash', 'rev', 'profit', 'sh'].forEach(k => tryv('weekreport fin31 ' + k, () => { UI.go('weekreport'); UI.render(true); UI.ACT.fin31({ k }); }));
const bad = out.filter(x => !/^ok/.test(x));
return 'checked ' + out.length + ' (rows ' + rows + ') bad ' + bad.length + (bad.length ? '\n' + bad.slice(0, 20).join('\n') : '') + ' errors ' + errs.length + ' ' + errs.slice(0, 3).join(' | ');
})()

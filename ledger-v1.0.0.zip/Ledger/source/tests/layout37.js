return (function () {
  const ui = UI.ui, A = UI.ACT;
  const NAV = new Set(['go', 'cotab', 'cofin', 'cosub', 'codeal', 'hqtab', 'mtab', 'phapp', 'tab', 'go30', 'wr35s']);
  const isSub = (a) => /tab$|^rk27[fs]$|^st27$|^rvf$|^hdt$|^acct$|^books$|^ntab$|^btab$|^mtwho$|^acadco$|f$/.test(a) && !/^(setknob|pricestep|ownhrs|stockpol|pr29day|pr29mode)$/.test(a);
  const keysOf = () => ['tab', 'view', 'stack', 'ph', 'phStack', 'hqt', 'mtab', 'btab', 'nt', 'hdt', 'rk27f', 'rk27s', 'books', 'luxt', 'acct'];
  const snap = () => { const o = {}; Object.keys(ui).forEach(k => { const v = ui[k]; if (k === 'sheet' || typeof v === 'function') return; try { o[k] = JSON.parse(JSON.stringify(v)); } catch (e) { } }); return o; };
  const restore = s => { Object.keys(ui).forEach(k => { if (!(k in s) && k !== 'sheet') { /* keep */ } }); Object.assign(ui, JSON.parse(JSON.stringify(s))); ui.sheet = null; };
  const main = () => document.querySelector('main') || document.body;
  const onTabs = () => [...main().querySelectorAll('.ptabs button.on, .seg button.on')].map(b => b.textContent.trim()).join('/');
  const title = () => { const h = main().querySelector('h1, .phead h2'); return h ? h.textContent.trim().slice(0, 40) : ''; };
  const key = () => ui.tab + '|' + (ui.tab === 'phone' ? JSON.stringify(ui.ph || {}) : (ui.view ? ui.view.n + JSON.stringify(ui.view.p || {}) : '')) + '|' + onTabs();

  const W = document.documentElement.clientWidth;
  function audit(where) { try { R37.fitChips(); } catch (e) { }
    const root = document.querySelector('.scrim .sheet') || main();
    const bad = [];
    const lh = el => parseFloat(getComputedStyle(el).lineHeight) || 18;
    root.querySelectorAll('.chips:not(.col37)').forEach(c => { const k = [...c.children].filter(x => x.offsetParent); if (k.length > 1 && new Set(k.map(x => Math.round(x.getBoundingClientRect().top / 6))).size > 1) bad.push('CHIPS wrap: ' + k.map(x => x.textContent.trim()).join(' / ').slice(0, 90)); });
    root.querySelectorAll('button.btn, button.chip').forEach(b => { if (!b.offsetParent) return; const t = b.textContent.trim(); if (t && b.getBoundingClientRect().height > lh(b) * 1.75 + 20 && !b.querySelector('small,b,div')) bad.push('BUTTON 2 lines: ' + t.slice(0, 60)); });
    root.querySelectorAll('.kv').forEach(k => { if (!k.offsetParent) return; if (k.getBoundingClientRect().height > lh(k) * 1.8 + 6) bad.push('ROW 2 lines: ' + k.textContent.trim().replace(/\s+/g, ' ').slice(0, 80)); });
    root.querySelectorAll('.tri > div, .trio > div').forEach(d => { const b = d.querySelector('b'); if (b && b.getBoundingClientRect().height > lh(b) * 1.6) bad.push('TILE 2 lines: ' + d.textContent.trim().replace(/\s+/g, ' ').slice(0, 50)); });
    root.querySelectorAll('.ptabs, .subtabs, .seg').forEach(p => { if (p.scrollWidth > p.clientWidth + 2) bad.push('TABS overflow: ' + p.textContent.trim().replace(/\s+/g, ' ').slice(0, 70)); });
    root.querySelectorAll('*').forEach(e => { const r = e.getBoundingClientRect(); if (r.width && r.right > W + 1 && !e.closest('.ptabs,.subtabs,svg')) { bad.push('OVERFLOW x: ' + e.tagName + '.' + String(e.className).slice(0, 20) + ' ' + e.textContent.trim().slice(0, 40)); } });
    root.querySelectorAll('b, span, small, em, button').forEach(e => { if (!e.offsetParent || e.closest('p,.tipt,.note,.lead,.sense,.calm,svg,.wrap,h1,h2,h3,.news,.dcard .ctext,.sheet .ctext,.paper28,details > summary + *,.unli36,.tl31,.al30')) return; if (e.children.length) return; const t = e.textContent.trim(); if (!t || t.length > 70) return; const rg = document.createRange(); rg.selectNodeContents(e); const tops = new Set([...rg.getClientRects()].filter(r => r.width > 1).map(r => Math.round(r.top / 4))); if (tops.size > 1) bad.push('WRAP: ' + e.tagName + '.' + String(e.className).slice(0, 14) + ' ' + t.slice(0, 60)); });
    const u = [...new Set(bad)].slice(0, 12);
    if (u.length) AUD.push('## ' + where + '\n  ' + u.join('\n  '));
  }
  const AUD = [];
  const seen = new Set(), perView = {}, out = [];
  function measure() {
    const m = main();
    const btns = [...m.querySelectorAll('[data-a]')].filter(b => !b.closest('nav') && !/^(back|backto|phback|threadback|scrim|none|closepop)$/.test(b.getAttribute('data-a')));
    const nav = [], act = [], sub = [];
    btns.forEach(b => { const a = b.getAttribute('data-a'); (NAV.has(a) ? nav : isSub(a) && b.closest('.ptabs,.seg,.chips,.subtabs') ? sub : act).push(b); });
    const inputs = m.querySelectorAll('input, select, textarea').length;
    const txt = m.innerText.replace(/\s+/g, ' ').length;
    return { nav, act, sub, inputs, txt };
  }
  function visit(s, path, depth) {
    restore(s);
    try { UI.render(true); } catch (e) { out.push('ERR render ' + path + ' ' + e.message); return; }
    const k = key();
    if (seen.has(k)) return;
    seen.add(k);
    const vn = ui.tab === 'phone' ? 'ph:' + ((ui.ph || {}).n) : ui.view ? ui.view.n : '?';
    perView[vn] = (perView[vn] || 0) + 1;
    if (perView[vn] > 3 && !/^(co|hq|meetings|phone|ph:)/.test(vn)) return;
    if (vn === 'co' && perView[vn] > 80) return;
    const me = measure(); audit(path);
    out.push('  '.repeat(depth) + '- ' + path.split(' › ').pop() + '  [' + vn + (onTabs() ? ' · ' + onTabs() : '') + '] actions ' + me.act.length + ' inputs ' + me.inputs + ' links ' + me.nav.length + ' text ' + me.txt);
    if (depth >= 5) return;
    const here = snap();
    const targets = me.nav.concat(me.sub).concat(me.act.filter(b => /sheet$|^fin31$|^net31p$|^wr35s$/.test(b.getAttribute('data-a')))).map(b => [b.getAttribute('data-a'), b.getAttribute('data-p'), (b.querySelector('b') || b).textContent.trim().replace(/\s+/g, ' ').slice(0, 34)]);
    const done = new Set();
    targets.forEach(t => {
      if (done.has(t[0] + t[1])) return; done.add(t[0] + t[1]);
      restore(here); UI.render(true);
      let p; try { p = t[1] != null ? JSON.parse(t[1]) : undefined; } catch (e) { p = t[1]; }
      try { A[t[0]](p); } catch (e) { out.push('ERR ' + path + ' › ' + t[2] + ' ' + e.message); return; }
      if (ui.sheet) { UI.render(true); audit(path + ' › [sheet] ' + t[2]); ui.sheet = null; return; }
      visit(snap(), path + ' › ' + t[2], depth + 1);
    });
  }
  const start = t => { UI.ui.sheet = null; UI.ACT.tab(t); UI.ui.stack = []; UI.render(true); return snap(); };
  ['home', 'cos', 'hq', 'phone', 'meet'].forEach(t => { out.push('# ' + t); visit(start(t), t, 0); });
  return AUD.join('\n');
})()

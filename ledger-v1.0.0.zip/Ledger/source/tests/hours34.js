(() => {
UI.ui.inp.name = 'Erik Solheim'; UI.ui.sc = 'NO'; UI.ACT.startgame(); S.cash += 3e7;
const mk = (t, f) => { const co = startCompany(t, { form: f || 'AS', name: 'T ' + t }); injectCash(co, Math.round(setupEstimate(t, {}).total * 1.5)); setupAndOpen(co); co.staff.forEach(s => onbItems(s.role).forEach(it => { s.onb = s.onb || {}; s.onb[it[0]] = 1; })); topUpEq(co); return co; };
const c1 = mk('cons', 'ENK'); c1.ohrs = 60; c1.aware = 70;
const c2 = mk('cleaning'); c2.ohrs = 0;
const c3 = mk('cafe'); c3.ohrs = 0;
const out = [];
const capOf = co => { const r = capacity(co, BD[co.type]); return Math.round(r.cap * 10) / 10 + ' (' + (r.bot ? r.bot.label : '-') + ')'; };
out.push('capacity per week: consultant 60h=' + capOf(c1) + ' | cleaning staff ' + c2.staff.length + '=' + capOf(c2) + ' | cafe=' + capOf(c3));
const step = n => { for (let i = 0; i < n; i++) { window.dayStep(); S.inbox.forEach(m => { if (m.status === 'open' && (m.act === 'pay29all' || (m.act === 'pay29' && m.data && m.data.k === 'rem'))) resolveMsg(m.id, 0); }); } }; step(28);
[c1, c2].forEach(co => { const L = co.dl; out.push(co.name + ' this week by day: ' + Object.keys(L.days).map(d => L.days[d].u).join(',') + ' · week cap ' + Math.round(L.cap) + ' · D ' + Math.round(co.lastW.D) + ' · sold last week ' + Math.round(co.lastW.units)); });
const notes = []; for (let i = 0; i < 14; i++) { step(1); (UI.ui.day28 && UI.ui.day28.notes || []).forEach(n => notes.push(n[0] + ' ' + n[1])); }
out.push('day card notes over 14 days: ' + JSON.stringify(notes.slice(0, 6)));
c2.staff.forEach(s => { const wk = {}; (s.dd || []).forEach(x => { const w = Math.floor(x.k / 7); wk[w] = (wk[w] || 0) + x.h; }); out.push('staff weekly hours: ' + Object.values(wk).slice(-3).map(h => Math.round(h * 10) / 10).join(', ')); });
return out.join('\n');
})()

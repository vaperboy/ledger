(() => {
const out = [];
const types = ['cafe','restaurant','carclean','event','cons','webdev','plumber','boutique','gym','handy'];
const chans = ['flyer','google','meta','tiktok','local','bill','seo','b2b','fair','ref'];
const mk = types.map(t => { const c = startCompany(t, { form: 'AS', name: 'T ' + t }); c.st = 'open'; c.mk19 = { base: 60, nw: 0, seo: 160, ch: {} }; c.lastW = { units: 40, D: 40 }; return c; });
const ev2 = startCompany('event', { form: 'AS', name: 'T wedding' }); ev2.knob.seg = 2; ev2.st='open'; ev2.mk19 = { base: 60, nw: 0, seo: 160, ch: {} }; mk.push(ev2);
out.push('type'.padEnd(11) + chans.map(c => c.padStart(8)).join('') + '   (expected new customers/week at the middle budget; cost per customer in NOK below)');
mk.forEach(co => {
  const bd = BD[co.type]; const a = co.knob.seg === 2 ? [0.1] : null;
  const keep = bd.aud; if (co.type === 'event') bd.aud = co.knob.seg === 2 ? 0.1 : 0.85;
  const r = chans.map(k => { const o = CH[k].opts.filter(x => x); const b = o[Math.floor(o.length/2)]; const R = R19.chanCalc(co, bd, k, b); return R ? [R.cust, b / Math.max(1e-6, R.cust)] : [0, 0]; });
  bd.aud = keep;
  out.push((co.type + (co.knob.seg===2?'(wed)':'')).padEnd(11) + r.map(x => x[0].toFixed(2).padStart(8)).join(''));
  out.push(''.padEnd(11) + r.map(x => (x[1] > 99999 ? '>100k' : Math.round(x[1]/100)*100 + '').padStart(8)).join(''));
});
return out.join('\n');
})()

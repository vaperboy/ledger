(() => {
const out = [], errs = [];
window.onerror = m => errs.push(m);
/* 1: every trade's Clients tab renders its sales ways */
let bad = [];
Object.keys(R33.W).filter(t => t !== 'casino').forEach(t => { try { const co = startCompany(t, { form: 'AS', name: 'T33 ' + t }); co.st = 'open'; const h = R33.salesCard(co) || ''; if (!/Ways to sell/.test(h) || /undefined|NaN/.test(h.replace(/<[^>]+>/g, ''))) bad.push(t); S.cos = S.cos.filter(c => c !== co); } catch (e) { bad.push(t + ':' + e.message); } });
out.push('types with sales ways: ' + Object.keys(R33.W).length + ' · render problems: ' + JSON.stringify(bad));
/* 2: live run: switch some on, answer every question with the first option */
A1.sw33 = { on: { platform: 1, members: 1 }, ct: [], one: [], ref: 0, mem: 0, peak: {}, last: -99, log: [] };
A2.sw33 = { on: { platform: 1, upsell: 1 }, ct: [], one: [], ref: 0, mem: 0, peak: {}, last: -99, log: [], paidUp: 1 };
A3.sw33 = { on: { members: 1 }, ct: [], one: [], ref: 0, mem: 0, peak: {}, last: -99, log: [] };
const seen = new Set(S.inbox.map(m => m.id)), kinds = {};
for (let i = 0; i < 26 * 7; i++) { window.auto29(1, []); S.inbox.forEach(m => { if (!seen.has(m.id)) { seen.add(m.id); if (m.act === 'sw33') { kinds[m.data.k] = (kinds[m.data.k] || 0) + 1; if (m.status === 'open') resolveMsg(m.id, m.data.k === 'tender' ? 1 : 0); } } }); }
out.push('questions asked (26 weeks): ' + JSON.stringify(kinds));
[A1, A2, A3, A4, A5].forEach(co => { const s = co.sw33 || {}; out.push(co.name + ': ways=' + R33.ways(co).map(w => w[0]).join('/') + ' contracts=' + (s.ct || []).length + ' members=' + Math.round(s.mem || 0) + ' referrals/wk=' + (s.ref || 0).toFixed(2) + ' demand x' + ((co.dbg && co.dbg.dp && co.dbg.dp.sales33) || 1).toFixed(2) + ' | log: ' + (s.log || []).slice(0, 3).map(l => l.t).join(' / ')); });
out.push('errors ' + JSON.stringify(errs));
return out.join('\n');
})()

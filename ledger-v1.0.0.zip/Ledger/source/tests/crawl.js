const puppeteer = require('/opt/npm-tools/node_modules/puppeteer-core');
const fs = require('fs');
const [,, file, richFile, maxClicks, depthArg] = process.argv;
(async () => {
  const b = await puppeteer.launch({executablePath:'/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args:['--no-sandbox','--disable-gpu'], headless:'new'});
  const p = await b.newPage();
  await p.setViewport({width:390, height:844, deviceScaleFactor:1});
  const errs=[]; p.on('pageerror',e=>errs.push('PAGEERR '+e.message)); p.on('console',m=>{ if(m.type()==='error' && !/Failed to load resource|JSON input/.test(m.text())) errs.push('CONSOLE '+m.text().slice(0,200)); });
  p.on('dialog', d => d.dismiss());
  await p.goto('file://'+file, {waitUntil:'domcontentloaded'}); await new Promise(r=>setTimeout(r,500));
  console.log('rich:', await p.evaluate(fs.readFileSync(richFile,'utf8')));
  const res = await p.evaluate(async (maxClicks, maxDepth) => {
    window.__errs = []; const ce0 = console.error; console.error = function () { window.__errs.push([].map.call(arguments, x => x && x.stack ? x.stack.split('\n').slice(0, 2).join(' ') : String(x)).join(' ')); ce0.apply(console, arguments); }; window.addEventListener('error', e => window.__errs.push(e.message));
    const SKIP = { nextday:1, untilneeded:1, advance:1, startgame:1, newgame:1, newgame2:1, export:1, import:1, copysave:1, savefile:1, loadfile:1, reset:1, resetgame:1, wipe:1, quit:1 };
    const issues = [], seen = new Set(), noHandler = new Set();
    const snapState = () => ({ S: JSON.stringify(S), ui: JSON.stringify(UI.ui) });
    const restore = st => { S = JSON.parse(st.S); window.S = S; const u = JSON.parse(st.ui); Object.keys(UI.ui).forEach(k => { if (!(k in u)) delete UI.ui[k]; }); Object.assign(UI.ui, u); UI.render(true); };
    const sig = () => { const u = UI.ui; return u.tab + '|' + (u.tab === 'phone' ? JSON.stringify(u.ph) : JSON.stringify(u.view)) + '|' + (u.sheet ? 'sheet:' + (u.sheet.html || '').slice(0, 60) : '') + '|' + (u.mtab || '') + '|' + (u.hqt || ''); };
    const where = () => { const u = UI.ui; return u.tab + '/' + (u.tab === 'phone' ? u.ph && u.ph.n : u.view && u.view.n) + (u.view && u.view.p && u.view.p.t ? ':' + u.view.p.t : '') + (u.view && u.view.p && u.view.p.s ? ':' + u.view.p.s : '') + (u.sheet ? ' [sheet]' : ''); };
    const wait = ms => new Promise(r => setTimeout(r, ms));
    async function inspect(label) {
      await wait(40);
      try { document.getAnimations().forEach(a => { try { a.finish(); } catch (e) {} }); } catch (e) {} /* measure where things land, not mid slide-in */
      const out = [];
      if ([].some.call(document.querySelectorAll('.card h3'), x => x.textContent === 'Screen error')) out.push('screen error');
      const sc = document.querySelector('.screen'), sh = document.querySelector('#app .sheet');
      const txt = (sc ? sc.innerText : '') + ' ' + (sh ? sh.innerText : '');
      const m = txt.match(/\bundefined\b|\bNaN\b|\[object Object\]|Infinity/);
      if (m) out.push('text "' + m[0] + '": …' + txt.slice(Math.max(0, txt.indexOf(m[0]) - 50), txt.indexOf(m[0]) + 20).replace(/\s+/g, ' ') + '…');
      if (document.documentElement.scrollWidth > innerWidth + 1) out.push('page wider than screen ' + document.documentElement.scrollWidth);
      const wide = [].slice.call(document.querySelectorAll('.screen *, .sheet *')).filter(e => { if (!e.offsetParent) return false; const r = e.getBoundingClientRect(); return r.width > 0 && r.right > innerWidth + 2 && !e.closest('.pscroll,.hscroll'); });
      if (wide.length) out.push('sticks out right: ' + (wide[0].className || wide[0].tagName) + ' "' + (wide[0].innerText || '').slice(0, 30) + '"');
      if (sc && sc.classList.contains('root') && sc.scrollHeight > sc.clientHeight + 2) out.push('main tab scrolls');
      if (sh) {
        if (sh.scrollHeight > sh.clientHeight + 2 && getComputedStyle(sh).overflowY !== 'hidden') out.push('popup scrolls');
        const pg = sh.querySelector('.pager');
        if (pg) {
          const vis = [].slice.call(sh.children).filter(x => x.offsetParent && !x.classList.contains('pager') && x.tagName !== 'H2');
          const h = vis.reduce((t, x) => t + x.offsetHeight, 0);
          if (h < sh.clientHeight * 0.25) out.push('popup page nearly empty (' + pg.innerText.replace(/\n/g, ' ') + ')');
          const over = [].slice.call(sh.querySelectorAll('*')).some(e => e.offsetParent && e.getBoundingClientRect().bottom > sh.getBoundingClientRect().bottom + 2);
          if (over) out.push('popup content cut off');
        }
        if (!sh.innerText.trim()) out.push('empty popup');
      }
      document.querySelectorAll('[data-a]').forEach(e => { const a = e.getAttribute('data-a'); if (!UI.ACT[a] && ['scrim', 'back'].indexOf(a) < 0) noHandler.add(a + ' @ ' + label); });
      return out;
    }
    const queue = [];
    for (const tab of ['home', 'cos', 'hq', 'phone', 'meet']) {
      UI.ui.sheet = null; UI.tabTo(tab); UI.render(true);
      const st = snapState(); const s = sig(); if (!seen.has(s)) { seen.add(s); queue.push({ st, d: 0, w: where() }); }
    }
    let clicks = 0;
    while (queue.length && clicks < maxClicks) {
      const node = queue.shift();
      restore(node.st);
      const n = document.querySelectorAll('.screen [data-a], #app .sheet [data-a]').length;
      for (let i = 0; i < n && clicks < maxClicks; i++) {
        restore(node.st);
        const el = document.querySelectorAll('.screen [data-a], #app .sheet [data-a]')[i];
        if (!el) break;
        const a = el.getAttribute('data-a');
        if (SKIP[a] || el.disabled) continue;
        const lab = node.w + ' → ' + a + ' ' + (el.getAttribute('data-p') || '').slice(0, 50) + ' "' + (el.innerText || '').trim().slice(0, 30) + '"';
        const e0 = window.__errs.length;
        try { el.click(); } catch (e) { issues.push([lab, 'throws ' + e.message]); }
        clicks++;
        const found = await inspect(lab);
        if (window.__errs.length > e0) found.push(window.__errs.slice(e0).join(' / ').slice(0, 200));
        found.forEach(f => issues.push([lab, f]));
        const s = sig();
        if (!seen.has(s) && node.d + 1 <= maxDepth) { seen.add(s); queue.push({ st: snapState(), d: node.d + 1, w: where() }); }
      }
    }
    return { clicks, nodes: seen.size, issues, noHandler: Array.from(noHandler).slice(0, 60), left: queue.length };
  }, +maxClicks, +depthArg);
  res.errs = errs.slice(0, 50);
  fs.writeFileSync('/tmp/claude-0/qa/crawl_out.json', JSON.stringify(res, null, 1));
  console.log('clicks', res.clicks, 'screens', res.nodes, 'issues', res.issues.length, 'queue left', res.left, 'page errors', errs.length);
  await b.close();
})();

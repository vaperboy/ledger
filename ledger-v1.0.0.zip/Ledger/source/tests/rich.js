(function(){
 const log=[]; const T=(n,f)=>{ try{ f(); }catch(e){ log.push(n+': '+e.message); } };
 UI.ui.inp.name='Erik Solheim'; UI.ACT.startgame(); S.cash+=60e6;
 const mk=(t,nm,oh,o)=>{ const co=startCompany(t,Object.assign({name:nm},o||{})); if(typeof co==='string'){ log.push(t+': '+co); return null; } co.ohrs=oh; co.cash+=Math.round(setupEstimate(t,o||{}).total*1.5); setupAndOpen(co); co.staff.forEach(s=>onbItems(s.role).forEach(it=>{s.onb=s.onb||{};s.onb[it[0]]=1;})); topUpEq(co); co.aware=Math.max(co.aware,50); return co; };
 const cafe=mk('cafe','Fjord Kaffe',15,{form:'AS'});
 T('chain',()=>{ UI.ui.inp.ch12n='Fjord Kaffe'; UI.ACT.ch12make({id:cafe.id}); const ch=S.chains[0]; UI.ui.chainNew=ch.id; mk('cafe','x',0,{form:'AS', city:CC().cities[1].id}); UI.ui.chainNew=ch.id; mk('cafe','y',0,{form:'AS'}); });
 const est=mk('estate','Nord Eiendom',0,{form:'AS'});
 T('manager',()=>{ const n=genManager(est,BD.estate.mgr); S.npcs[n.id]=n; hireManager(est,n,n.ask*1.2); });
 const taxi=mk('taxi','Byens Taxi',10);
 const cons=mk('construction','Bygg AS',10,{form:'AS'});
 const rent=mk('resrent','Bolig Utleie',5,{form:'AS'});
 const shop=mk('kiosk','Hjørnet',10);
 T('loan',()=>{ log.push('loan '+takeLoan('biz', KC(500000), 60, taxi, false)); });
 T('stocks',()=>{ const k=Object.keys(S.stocks)[0]; log.push('stock '+buyAsset('stock',k,KC(200000))); });
 T('lux',()=>{ S.lux=[{id:'t1',k:'c2',price:1600000,val:1500000,w:S.week}]; });
 T('holding',()=>{ const r=createHolding('Solheim Holding AS', (S.pool.acc[0]||{}).id); log.push('holding '+(typeof r==='object'?'ok':r)); });
 for(let i=0;i<7*10;i++) dayStep();
 T('lh',()=>{ /* the right hand is the personal assistant at the main office */ if(!hasHQ('pa')){ const n=searchWorkers(null,'hq_pa','agency')[0]; n.hired=-3; S.office.staff.push({id:n.id,role:'pa',name:n.name,wage:n.ask,w0:S.week,onb:null}); } if(!R12.lhN()) throw new Error('no right hand'); });
 T('office',()=>{ S.office.tier=OFFICE_T.find(t=>t.desks>=4).id; });
 UI.tabTo('home'); UI.render(true);
 window.__rich=log; return log.join(' | ')||'ok';
})()

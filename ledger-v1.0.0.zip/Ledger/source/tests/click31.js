(() => {
const out = [], errs = [];
window.onerror = (m) => errs.push(m);
const tryv = (l, f) => { try { f(); UI.render(true); const t = document.querySelector('main') ? document.querySelector('main').innerText : document.body.innerText; out.push((/undefined|NaN|\[object/.test(document.body.innerText) ? 'TEXT ISSUE ' : 'ok ') + l); } catch (e) { out.push('ERR ' + l + ': ' + e.message + ' ' + (e.stack||'').split('\n')[1]); } };
window.auto29(120, []);
UI.ui.sheet = null;
out.push('paper: ' + R31.paperName() + ' | city ' + cityOf(S.player.city).name);
tryv('img31', () => UI.go('img31', {}));
out.push('image: ' + JSON.stringify(R31.image().lab[0]) + ' ' + JSON.stringify(Object.fromEntries(Object.entries(R31.image().g).map(([k,v])=>[k,Math.round(v)]))));
['people','web','fav'].forEach(t => tryv('net31 ' + t, () => UI.go('net31', { t })));
['own','where','circ'].forEach(t => tryv('map31 ' + t, () => UI.go('map31', { t })));
tryv('rivals', () => UI.go('rivals', {}));
const R = R31.rivalsAll(); out.push('rivals ' + R.length + ' mem: ' + R.slice(0,3).map(x => x.r.owner + '=' + (x.r.mem31||[]).length + '/' + Math.round(x.r.rel)).join(', '));
if (R[0]) tryv('riv31', () => UI.go('riv31', { id: R[0].r.id }));
if (R[0]) tryv('riv31 lunch', () => UI.ACT.riv31meet({ id: R[0].r.id }));
tryv('trophies', () => UI.go('trophies28', {}));
tryv('weekreport', () => UI.go('weekreport', {}));
out.push('wk31 snaps ' + (S.wk31||[]).length + ' last ' + JSON.stringify((S.wk31||[]).slice(-1)[0] && { cash: S.wk31.slice(-1)[0].cash, rev: S.wk31.slice(-1)[0].rev, profit: S.wk31.slice(-1)[0].profit, nw: S.wk31.slice(-1)[0].nw, sh: S.wk31.slice(-1)[0].sh }));
['nw','cash','rev','profit','sh'].forEach(k => tryv('fin31 ' + k, () => { UI.ui.sheet = null; UI.ACT.fin31({ k }); }));
UI.ui.sheet = null;
const fav = S.inbox.filter(m => m.act === 'fav31');
out.push('favour asks seen: ' + fav.length + ' ' + fav.slice(0,2).map(m => m.title).join(' | '));
const open = fav.find(m => m.status === 'open');
if (open) { resolveMsg(open.id, 0); out.push('helped: ' + JSON.stringify(S.net31.f[0])); tryv('call in', () => UI.ACT.fav31call({ id: S.net31.f[0].id })); }
const ros = R31.roster(); out.push('roster ' + ros.length + ': ' + ros.map(c => c.role + ':' + c.name + ':' + Math.round(c.rel)).join(', '));
if (ros[0]) tryv('person sheet', () => UI.ACT.net31p({ id: ros[0].id }));
UI.ui.sheet = null;
tryv('office', () => { UI.ui.tab = 'hq'; UI.go('office', {}); });
out.push('errors ' + JSON.stringify(errs));
return out.join('\n');
})()

/* manager A/B: node mgr.js FILE TYPES W_BEFORE W_AFTER SEEDS [MODE]
   Business runs W_BEFORE weeks owner-run with marketing; then branch A continues, branch B hires a manager (owner leaves). */
const puppeteer = require('/opt/npm-tools/node_modules/puppeteer-core');
const [,, file, types, wb, wa, seeds, mode] = process.argv;
(async () => {
  const b = await puppeteer.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--no-sandbox', '--disable-gpu'], headless: 'new', protocolTimeout: 3600000 });
  const p = await b.newPage();
  const errs = [];
  p.on('pageerror', e => errs.push('PAGEERR ' + e.message));
  await p.goto('file://' + file, { waitUntil: 'domcontentloaded' });
  await new Promise(r => setTimeout(r, 600));
  const res = await p.evaluate((types, wb, wa, seeds, mode) => {
    UI.render = function () { };
    const out = [];
    for (const t of types.split(',')) for (const seed of seeds.split(',').map(Number)) {
      UI.ui.inp.name = 'Audit Person'; UI.ui.sc = 'NO'; UI.ui.city = null; UI.ACT.startgame();
      S.seed = seed; S.rs = seed; S.cash += 1e9;
      const co = startCompany(t, { name: 'Audit ' + t });
      co.cash += Math.round(setupEstimate(t, {}).total * 1.15);
      setupAndOpen(co);
      co.staff.forEach(s => onbItems(s.role).forEach(it => { s.onb = s.onb || {}; s.onb[it[0]] = 1; }));
      topUpEq(co);
      const bd = BD[t];
      const b0 = Math.max(KC(600), bd.Dc * bd.ticket * (co.size || 1) * 0.03);
      const best = Object.keys(CH).filter(k => R19.CHX[k] && chOk(co, k) && !CH[k].prem && !CH[k].nat && !R19.CHX[k].loyal && !R19.CHX[k].seo).map(k => [k, R19.expect(co, k, b0)]).filter(x => x[1]).sort((a, b2) => b2[1].roi - a[1].roi)[0];
      if (best) co.mkt[best[0]] = { b: Math.round(b0), since: S.week };
      for (let w = 0; w < +wb; w++) nextWeek();
      const snap = serialize();
      const branch = (hire) => {
        deserialize(snap);
        UI.render = function () { };
        const c = S.cos.find(x => x.type === t && x.st === 'open');
        if (!c) return { dead: 1 };
        const bd = BD[t];
        let hired = '';
        if (hire) {
          const n = genManager(c, bd.mgr || 'gen');
          if (mode === 'good') n.skill = 80, Object.keys(n.stats || {}).forEach(k => n.stats[k] = 80);
          if (mode === 'bad') n.skill = 30, Object.keys(n.stats || {}).forEach(k => n.stats[k] = 30);
          S.npcs[n.id] = n;
          hired = hireManager(c, n, Math.round(n.ask * 1.05));
          c.ohrs = 0;
        }
        const W = [], notes = [];
        const n0 = (S.rep && S.rep.ev) ? 0 : 0;
        const st0 = c.staff.length, mk0 = mktCost(c), eq0 = Object.keys(c.eq || {}).length;
        const cash0 = c.cash;
        const cat = {};
        let bust = 0;
        for (let w = 0; w < +wa; w++) {
          const ev0 = S.rep ? S.rep.ev.length : 0;
          nextWeek();
          if (S.rep && S.rep.ev) S.rep.ev.slice(0).forEach(e => { if (e.co === c.id && /(hired|raised|lowered|bought|marketing|campaign|stock|upkeep|ordered|price|budget|fired|leased|invest|expan)/i.test(e.t) && notes.length < 40 && notes.indexOf(e.t) < 0) notes.push('w' + w + ' ' + e.t.slice(0, 110)); });
          if (c.st === 'bust') { bust = w + 1; break; }
          const bw = c.bk.w || {};
          Object.keys(bw).forEach(k => { cat[k] = (cat[k] || 0) + (bw[k] || 0); });
          W.push(Math.round(((bw.rev || 0) - sumExp(bw)) / 1000));
        }
        const h = c.hist.slice(-6);
        return {
          hired, bust, staff: st0 + '→' + c.staff.length, mkt: Math.round(mk0) + '→' + Math.round(mktCost(c)), eq: eq0 + '→' + Object.keys(c.eq || {}).length,
          price: (c.price || 0).toFixed(2), maint: c.maint, stockPol: c.stockPol, mgrWage: c.mgrWage || 0,
          prof6: Math.round(h.reduce((a, x) => a + x.profit, 0) / 1000), rev6: Math.round(h.reduce((a, x) => a + x.rev, 0) / 1000), dcash: Math.round((c.cash - cash0) / 1000),
          cat: Object.fromEntries(Object.entries(cat).map(([k, v]) => [k, Math.round(v / 1000)])), weekly: W.join(','), notes
        };
      };
      const pre = co.hist.slice(-3).map(h => Math.round(h.profit / 1000)).join(',');
      out.push({ t, seed, pre, A: branch(false), B: branch(true) });
    }
    return out;
  }, types, wb, wa, seeds, mode || '');
  console.log(JSON.stringify(res, null, 1));
  if (errs.length) console.log(errs.slice(0, 5));
  await b.close();
})();

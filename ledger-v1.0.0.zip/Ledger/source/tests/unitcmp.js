const puppeteer = require('/opt/npm-tools/node_modules/puppeteer-core');
const [,, file, mode, trials, weeks, typesArg] = process.argv;
(async () => {
  const b = await puppeteer.launch({executablePath:'/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args:['--no-sandbox','--disable-gpu'], headless:'new'});
  const p = await b.newPage(); p.on('pageerror',e=>console.error('PAGEERR '+e.message));
  await p.goto('file://'+file, {waitUntil:'domcontentloaded'}); await new Promise(r=>setTimeout(r,500));
  const res = await p.evaluate((mode, trials, weeks, typesArg) => {
    UI.render = function(){};
    const types = typesArg ? typesArg.split(',') : BD_ORDER.filter(t => ['svc','retail','venue','logi','prod'].indexOf(BD[t].fam) >= 0 && t !== 'salmon');
    const out = {};
    for (const t of types) {
      let U = 0, R = 0, n = 0, C = 0, M = 0;
      for (let i = 0; i < +trials; i++) {
        UI.ui.inp.name = 'Test Person'; UI.ACT.startgame();
        S.seed = 1000 + i * 7919 + t.length * 13; S.cash += 1e9;
        const co = startCompany(t, { name: 'Sim ' + t });
        if (typeof co === 'string') break;
        co.cash += Math.round(setupEstimate(t, {}).total * 1.15); setupAndOpen(co);
        co.staff.forEach(s => onbItems(s.role).forEach(it => { s.onb = s.onb || {}; s.onb[it[0]] = 1; })); topUpEq(co);
        if (co.st !== 'open') continue;
        const bd = BD[t];
        const fitc = k => { const c = CH[k]; return chAff(bd, k) * ((1 - bd.aud) * (c.loc || 0.5) + bd.aud * (c.b2b || 0.5)) * c.eff; };
        Object.keys(CH).filter(k => !CH[k].prem && !CH[k].nat && !CH[k].var).sort((a, b2) => fitc(b2) - fitc(a)).slice(0, 2).forEach(k => co.mkt[k] = { b: Math.max(300, bd.Dc * bd.ticket * (co.size || 1) * 0.015), since: S.week });
        for (let w = 0; w < +weeks; w++) {
          if (S.over || co.st === 'bust') break;
          if (mode === 'day') { for (let d = 0; d < 7; d++) window.dayStep(); } else nextWeek();
          if (w >= 8 && co.lastW && co.st === 'open') { U += co.lastW.units || 0; R += co.lastW.rev || 0; n++; C += co.lastWages || 0; }
        }
        M += co.cash;
      }
      out[t] = { u: n ? U / n : 0, r: n ? R / n : 0, wages: n ? C / n : 0, cash: M / +trials, n };
    }
    return out;
  }, mode, trials, weeks, typesArg || '');
  console.log(JSON.stringify(res));
  await b.close();
})();

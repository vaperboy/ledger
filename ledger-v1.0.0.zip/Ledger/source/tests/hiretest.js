/* hiring estimate check: node hiretest.js FILE TYPES SEEDS > out.json */
const puppeteer = require('/opt/npm-tools/node_modules/puppeteer-core');
const [,, file, types, seeds] = process.argv;
(async () => {
  const b = await puppeteer.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--no-sandbox', '--disable-gpu'], headless: 'new', protocolTimeout: 3600000 });
  const p = await b.newPage(); const errs = []; p.on('pageerror', e => errs.push('PAGEERR ' + e.message));
  await p.goto('file://' + file, { waitUntil: 'domcontentloaded' }); await new Promise(r => setTimeout(r, 600));
  const res = await p.evaluate((types, seeds) => {
    UI.render = function () { };
    const out = [];
    const W = 14, SKIP = 4;
    for (const t of types.split(',')) for (const seed of seeds.split(',').map(Number)) {
      UI.ui.inp.name = 'Hire Test'; UI.ui.sc = 'NO'; UI.ui.city = null; UI.ACT.startgame(); S.seed = seed; S.rs = seed; S.cash += 1e9;
      const co = startCompany(t, { name: 'H ' + t });
      if (typeof co === 'string') continue;
      injectCash(co, Math.round(setupEstimate(t, {}).total * 1.3)); setupAndOpen(co);
      co.staff.forEach(s => onbItems(s.role).forEach(it => { s.onb = s.onb || {}; s.onb[it[0]] = 1; })); topUpEq(co);
      const bd = BD[t];
      const b0 = Math.max(KC(600), bd.Dc * bd.ticket * (co.size || 1) * 0.03);
      const best = Object.keys(CH).filter(k => R19.CHX[k] && chOk(co, k) && !CH[k].prem && !CH[k].nat && !R19.CHX[k].loyal && !R19.CHX[k].seo).map(k => [k, R19.expect(co, k, b0)]).filter(x => x[1]).sort((a, b2) => b2[1].roi - a[1].roi)[0];
      if (best) co.mkt[best[0]] = { b: Math.round(b0), since: S.week };
      for (let w = 0; w < 20; w++) nextWeek();
      if (co.st !== 'open') continue;
      const snap = serialize();
      const meas = (role) => {
        deserialize(snap); UI.render = function () { };
        const c = S.cos.find(x => x.type === t);
        const rs0 = S.rs; let pred = null, hired = 0, ask = 0;
        if (role) {
          pred = R23.hireImpact(c, role);
          const cs = searchWorkers(c, role, 'network').filter(q => q.role === role).sort((a, b2) => a.ask - b2.ask);
          const cand = cs[Math.floor(cs.length / 2)];
          if (cand && hireWorker(c, cand, cand.ask) === 'ok') { hired = 1; ask = cand.ask * OC(); const s = c.staff[c.staff.length - 1]; onbItems(s.role).forEach(it => { s.onb = s.onb || {}; s.onb[it[0]] = 1; }); }
        }
        S.rs = rs0; /* same random draws as the branch without the hire */
        let wages = 0, rev = 0, prof = 0, n = 0;
        for (let w = 0; w < W; w++) { nextWeek(); if (w >= SKIP) { const bw = c.bk.w || {}; wages += bw.wages || 0; rev += bw.rev || 0; prof += (bw.rev || 0) - sumExp(bw); n++; } }
        const m = 52 / 12 / Math.max(1, n);
        return { pred, hired, ask, wages: wages * m, rev: rev * m, prof: prof * m };
      };
      const base = meas(null);
      for (const s of bd.std) {
        const role = s[0];
        const r = meas(role);
        if (!r.hired || !r.pred) continue;
        out.push({ t, seed, role, full: r.pred.full, bott: r.pred.bottleneck, predPay: Math.round(r.pred.pay), askPay: Math.round(r.ask), actPay: Math.round(r.wages - base.wages), predRev: Math.round(r.pred.rev), actRev: Math.round(r.rev - base.rev), predNet: Math.round(r.pred.net), actNet: Math.round(r.prof - base.prof) });
      }
    }
    return out;
  }, types, seeds);
  console.log(JSON.stringify(res));
  if (errs.length) console.error(errs.slice(0, 5).join('\n'));
  await b.close();
})();

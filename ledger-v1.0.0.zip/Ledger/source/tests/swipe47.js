/* swipe test: node tools/swipe47.js FILE  (touch phone viewport, synthetic touches) */
const puppeteer = require('/opt/npm-tools/node_modules/puppeteer-core');
const [,, file] = process.argv;
(async () => {
  const b = await puppeteer.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--no-sandbox', '--disable-gpu'], headless: 'new' });
  const p = await b.newPage();
  await p.setViewport({ width: 390, height: 844, deviceScaleFactor: 2, hasTouch: true, isMobile: true });
  const errs = []; p.on('pageerror', e => errs.push('PAGEERR ' + e.message));
  await p.goto('file://' + file, { waitUntil: 'domcontentloaded' }); await new Promise(r => setTimeout(r, 600));
  const out = [], P = (ok, n, i) => out.push((ok ? 'PASS ' : 'FAIL ') + n + (i ? ' · ' + i : ''));
  const swipe = async (x0, y, x1, steps = 8) => { await p.touchscreen.touchStart(x0, y); for (let i = 1; i <= steps; i++) { await p.touchscreen.touchMove(x0 + (x1 - x0) * i / steps, y + i); await new Promise(r => setTimeout(r, 16)); } await p.touchscreen.touchEnd(); await new Promise(r => setTimeout(r, 300)); };
  const st = () => p.evaluate(() => ({ v: UI.ui.view.n, t: UI.ui.view.p && UI.ui.view.p.t, on: (document.querySelector('main .ptabs .on') || {}).textContent }));
  await p.evaluate(() => { localStorage.setItem('ledger-v3:guide', '1'); /* the first-launch welcome stays away */ UI.ui.inp.name = 'Sw'; UI.ui.sc = 'NO'; UI.ACT.startgame(); S.cash += 5e6; const co = startCompany('plumber', { name: 'Swipe Rør', form: 'ENK' }); UI.go('co', { id: co.id }); UI.render(true); });
  const a = await st();
  /* halfway through a drag both pages are on screen, side by side */
  await p.touchscreen.touchStart(320, 500);
  for (let i = 1; i <= 6; i++) { await p.touchscreen.touchMove(320 - i * 25, 501); await new Promise(r => setTimeout(r, 16)); }
  const mid = await p.evaluate(() => { const s = document.querySelector('#app main.screen'), g = s.querySelector('.sw47g'), t = s.querySelector('.ptabs'); const n = [...s.children].filter(x => x !== g && x !== t && x.tagName !== 'HEADER')[0]; const pl = t.querySelector('.sw47pill'), bs = [...t.querySelectorAll('button')]; return { pill: pl ? Math.round(pl.getBoundingClientRect().left) : null, b0: Math.round(bs[0].getBoundingClientRect().left), b1: Math.round(bs[1].getBoundingClientRect().left), g: g ? Math.round(g.getBoundingClientRect().left) : null, n: n ? Math.round(n.getBoundingClientRect().left) : null, on: (t.querySelector('.on') || {}).textContent, mo: s.className }; });
  P(mid.g != null && mid.g < -100 && mid.n > 150 && mid.n < 300 && !/mo-/.test(mid.mo), 'mid-swipe: this tab slides out while the next one slides in with the finger', JSON.stringify(mid));
  P(mid.pill > mid.b0 + 5 && mid.pill < mid.b1 - 5, 'mid-swipe: the tab marker is on its way to the next tab', mid.b0 + ' < ' + mid.pill + ' < ' + mid.b1);
  await p.touchscreen.touchMove(300, 501); await p.touchscreen.touchEnd(); await new Promise(r => setTimeout(r, 400));
  const back0 = await st();
  P(back0.on === 'Overview' && !(await p.evaluate(() => !!document.querySelector('.sw47g'))), 'a drag that is let go early springs back to the same tab', back0.on);
  await swipe(300, 500, 120);
  const b1 = await st();
  P(a.on === 'Overview' && b1.on === 'Sales', 'swipe left: next tab', a.on + ' → ' + b1.on);
  await swipe(300, 500, 120);
  const b2 = await st();
  P(b2.on === 'Manage', 'swipe left again', b2.on);
  await swipe(100, 500, 300);
  const b3 = await st();
  P(b3.on === 'Sales', 'swipe right: previous tab', b3.on);
  await swipe(200, 500, 215);
  P((await st()).on === 'Sales', 'a short drag changes nothing');
  await swipe(150, 500, 160, 2); /* vertical-ish tap */
  /* the near-tap above can open a page inside the company (round 58 pages); the edge swipe goes back one level */
  const b3b = await p.evaluate(() => JSON.stringify(UI.ui.view));
  await swipe(6, 500, 260);
  const b4 = await st(), b4v = await p.evaluate(() => JSON.stringify(UI.ui.view));
  P(b4v !== b3b, 'swipe from the left edge goes back', b3b + ' → ' + b4v);
  /* back inside a phone app */
  await p.evaluate(() => { UI.ACT.tab('phone'); UI.go('lux'); UI.render(true); UI.ACT.lxgo({ c: 'cars' }); UI.render(true); });
  await swipe(6, 500, 280);
  const u = await p.evaluate(() => document.querySelector('.lxurl') && document.querySelector('.lxurl').textContent);
  P(u === 'aurum.no', 'edge swipe goes back a page in the web shop', u);
  await p.evaluate(() => { const co = S.cos[0]; UI.ACT.tab('cos'); UI.go('co', { id: co.id }); UI.render(true); });
  await p.evaluate(() => { document.querySelectorAll('main .ptabs button')[2].click(); });
  await new Promise(r => setTimeout(r, 90));
  const tp = await p.evaluate(() => { const t = document.querySelector('main .ptabs'), pl = t.querySelector('.sw47pill'), bs = [...t.querySelectorAll('button')]; return { pill: pl ? Math.round(pl.getBoundingClientRect().left) : null, b0: Math.round(bs[0].getBoundingClientRect().left), b2: Math.round(bs[2].getBoundingClientRect().left) }; });
  P(tp.pill != null && tp.pill > tp.b0 + 3 && tp.pill < tp.b2, 'tapping a tab: the marker slides over', JSON.stringify(tp));
  await new Promise(r => setTimeout(r, 400));
  P(!(await p.evaluate(() => !!document.querySelector('.sw47pill, .sw47t'))), 'the marker is a normal tab again afterwards');
  /* Inbox: a conversation, then back to the list */
  const th = await p.evaluate(() => { UI.ACT.tab('meet'); UI.ui.mtab = 'msgs'; UI.render(true); const b = document.querySelector('main [data-a="thread"]'); if (b) b.click(); else { UI.ui.thread = Object.keys(S.threads || {})[0] || 'Test'; UI.render(true); } return UI.ui.thread; });
  await swipe(6, 500, 280);
  P(th && !(await p.evaluate(() => UI.ui.thread)), 'Inbox: swipe from the edge closes a conversation', String(th));
  await swipe(100, 500, 300);
  const mt = await p.evaluate(() => UI.ui.mtab);
  P(mt && mt !== 'msgs', 'Inbox: swipe between its tabs', mt);
  /* a company sub-page goes back to its tab, not out of the company */
  const sub = await p.evaluate(() => { const co = S.cos[0]; UI.ACT.tab('cos'); UI.go('co', { id: co.id }); UI.render(true); const tb = [...document.querySelectorAll('main .ptabs button')]; tb[2].click(); /* Manage (V.1.0.0: the Company tab is part of it) */ const r = [...document.querySelectorAll('main [data-a="cosub"], main [data-a="cofin"], main [data-a="codeal"]')].find(b => { try { return JSON.parse(b.dataset.p || '{}').s; } catch (e) { return false; } }); if (!r) return null; r.click(); return !!document.querySelector('main .subhead'); });
  await swipe(6, 500, 280);
  const sub2 = await p.evaluate(() => ({ v: UI.ui.view.n, sh: !!document.querySelector('main .subhead') }));
  P(sub && sub2.v === 'co' && !sub2.sh, 'company sub-page: edge swipe goes back to the tab', JSON.stringify({ sub, sub2 }));
  /* phone apps with their own tab rows */
  const bk0 = await p.evaluate(() => { UI.ACT.tab('phone'); UI.go('bank'); UI.render(true); return (document.querySelector('main .subtabs .on') || {}).textContent; });
  await swipe(300, 500, 100);
  const bk1 = await p.evaluate(() => (document.querySelector('main .subtabs .on') || {}).textContent);
  P(bk0 && bk1 && bk0 !== bk1, 'Bank: swipe between its tabs', bk0 + ' → ' + bk1);
  await swipe(6, 500, 280);
  P(await p.evaluate(() => UI.ui.tab !== 'phone' || UI.ui.ph.n === 'home'), 'Bank: edge swipe leaves the app');
  const sty = await p.evaluate(() => [...document.querySelectorAll('main.screen, main.screen > *')].filter(e => e.style.transform).length);
  P(!sty, 'nothing is left shifted after swipes');
  if (errs.length) out.push('ERR ' + errs.slice(0, 4).join(' | '));
  console.log(out.join('\n'));
  await b.close();
})();

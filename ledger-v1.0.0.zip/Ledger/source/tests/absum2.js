const fs=require('fs');const R=[].concat(...process.argv.slice(2).map(f=>JSON.parse(fs.readFileSync(f,'utf8').replace(/\n\[[^\]]*\]\s*$/,''))));
let better=0,n=0,bA=0,bB=0,bad=[],rows=[];const byT={};
R.forEach(x=>{if(x.A.dead||x.B.dead)return;n++;const a=x.A.prof6,b=x.B.prof6,mc=Math.round(x.B.mgrWage*1.14*6/1000);
 if(x.A.bust)bA++;if(x.B.bust)bB++;if(b>a)better++;
 const excess=(a-b)-mc; // loss beyond the manager's own pay
 (byT[x.t]=byT[x.t]||[]).push(excess);
 if(excess>Math.max(400,mc*1.0)||(x.B.bust&&!x.A.bust)) bad.push(x.t+'/'+x.seed+' A '+a+' B '+b+' mgrcost6 '+mc+' excess '+excess+(x.B.bust?' BUST':'')+' staff '+x.B.staff);
});
console.log('runs',n,'manager better',better,'bust A',bA,'bust B',bB);
console.log('median excess loss beyond manager pay by type:');console.log(Object.entries(byT).map(([t,v])=>t+' '+v.sort((p,q)=>p-q)[Math.floor(v.length/2)]).join(', '));
console.log('flagged:\n'+bad.join('\n'));

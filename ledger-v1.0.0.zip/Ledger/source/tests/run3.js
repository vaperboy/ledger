const puppeteer = require('/opt/npm-tools/node_modules/puppeteer-core');
const [,, file, typesArg, trials, weeks, policy, kjson] = process.argv;
(async () => {
  const b = await puppeteer.launch({executablePath:'/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args:['--no-sandbox','--disable-gpu'], headless:'new'});
  const p = await b.newPage();
  p.on('pageerror',e=>console.log('PAGEERR '+e.message));
  await p.goto('file://'+file, {waitUntil:'domcontentloaded'});
  await new Promise(r=>setTimeout(r,500));
  const res = await p.evaluate((typesArg, trials, weeks, policy, kjson) => {
    UI.render = function(){};
    const kj = kjson ? JSON.parse(kjson) : {};
    if (kj.__PF) { R8.PF = kj.__PF; delete kj.__PF; } if (kj.__K) { R8.K = kj.__K; delete kj.__K; }
    Object.assign(R8.KT, kj);
    const types = typesArg === 'all' ? BD_ORDER.filter(t => ['rent','fin','energy','club','hold'].indexOf(BD[t].fam) < 0 && ['salmon','realdev'].indexOf(t) < 0) : typesArg.split(',');
    const out = [];
    for (const t of types) {
      const R = { t, m0: BD[t].m, n: 0, opened: 0, y1: 0, y2: 0, m: [], u: [], cash: [], bustW: [], err: '' };
      for (let i = 0; i < +trials; i++) {
        try {
          UI.ui.inp.name = 'Test Person'; UI.ACT.startgame();
          S.seed = 1000 + i * 7919 + t.length * 13; S.cash += 1e9;
          const co = startCompany(t, { name: 'Sim ' + t });
          if (typeof co === 'string') { R.err = co; break; }
          co.cash += Math.round(setupEstimate(t, {}).total * 1.15);
          setupAndOpen(co);
          co.staff.forEach(s => onbItems(s.role).forEach(it => { s.onb = s.onb || {}; s.onb[it[0]] = 1; }));
          topUpEq(co);
          R.n++;
          if (co.st !== 'open') continue;
          R.opened++;
          const bd = BD[t];
          if (policy === 'mkt') {
            const fitc = k => { const c = CH[k]; return chAff(bd, k) * ((1 - bd.aud) * (c.loc || 0.5) + bd.aud * (c.b2b || 0.5)) * c.eff; };
            const ks = Object.keys(CH).filter(k => !CH[k].prem && !CH[k].nat && !CH[k].var).sort((a, b2) => fitc(b2) - fitc(a)).slice(0, 2);
            ks.forEach(k => co.mkt[k] = { b: Math.max(300, bd.Dc * bd.ticket * (co.size || 1) * 0.03 / ks.length), since: S.week });
          }
          let ur = 0, un = 0, bw = 0;
          for (let w = 0; w < +weeks; w++) {
            if (S.over) break;
            nextWeek();
            if (co.st === 'bust') { bw = w; break; }
            if (w === 51) R.y1++;
            if (w >= +weeks - 13) { const d = demand(co, bd).D * (bd.fam === 'project' && !bd.tw.dev ? R8.jobScale(co) : 1), c = capacity(co, bd).cap; if (c > 0) { ur += d / c; un++; } }
          }
          if (bw) R.bustW.push(bw);
          if (co.st !== 'bust' && co.st !== 'sold' && !S.over) R.y2++;
          const h = co.hist.slice(-26); const rev = h.reduce((s, x) => s + (x.rev || 0), 0), pr = h.reduce((s, x) => s + (x.profit || 0), 0);
          const ow = co.mgr ? 0 : wageFor(bd.std[0] ? bd.std[0][0] : 'helper', co) * 12 / 52 * Math.min(1, (co.ohrs || 0) / 40) * 1.14 * h.length;
          if (rev > 0 && co.st !== 'bust') R.m.push(Math.round((pr - ow) / rev * 100));
          if (un) R.u.push(Math.round(ur / un * 100) / 100);
          R.cash.push(Math.round(co.cash / 1000));
        } catch (e) { R.err = e.message; }
      }
      out.push(R);
    }
    return out;
  }, typesArg, trials, weeks, policy, kjson);
  console.log(JSON.stringify(res));
  await b.close();
})();

(() => {
const out = [], errs = [];
window.onerror = (m) => errs.push(m);
const tryv = (l, f) => { try { f(); UI.render(true); const t = document.body.innerText; out.push('ok ' + l + (/undefined|NaN/.test(t) ? ' [TEXT HAS undefined/NaN]' : '')); } catch (e) { out.push('ERR ' + l + ': ' + e.message); } };
UI.ui.sheet = null;
['ov','cli','mk','st','more'].forEach(t => [A1,A2,A3,A4,A5].forEach(c => tryv(c.name + ' ' + t, () => UI.go('co', { id: c.id, t }))));
[A1,A4].forEach(c => tryv('month30 ' + c.name, () => UI.go('month30', { id: c.id })));
tryv('payroll29 A1', () => UI.go('payroll29', { id: A1.id }));
out.push('A4 ev30 ' + JSON.stringify(A4.fm.ev30 && { bm: A4.fm.ev30.bm, dm: A4.fm.ev30.dm, tot: A4.fm.ev30.tot, due: A4.fm.ev30.due.length }) + ' jobs ' + (A4.fm.jobs||[]).length);
out.push('event msgs: ' + S.inbox.filter(m => /New booking|Delivered:/.test(m.title)).slice(0,4).map(m => m.title + ' | ' + m.body).join(' || '));
out.push('f30 A2 ' + JSON.stringify(A2.f30) + ' tx ' + A2.tx.filter(x=>/Monthly bills|Rent|Payroll/.test(x.l)).slice(0,4).map(x=>x.l+' '+x.a).join(' | '));
out.push('hist bk ' + JSON.stringify((A2.hist[A2.hist.length-1]||{}).bk ? Object.keys(A2.hist[A2.hist.length-1].bk) : null));
out.push('errors ' + JSON.stringify(errs));
return out.join('\n');
})()

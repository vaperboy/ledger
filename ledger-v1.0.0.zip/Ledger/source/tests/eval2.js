const { execFileSync } = require('child_process'); const fs = require('fs');
const KT = JSON.parse(fs.readFileSync('/tmp/claude-0/kt3.json')), PF = JSON.parse(fs.readFileSync('/tmp/claude-0/pf3.json'));
const arg = JSON.stringify(Object.assign({ __PF: PF, __K: 1.3 }, KT));
const tr = process.argv[2] || '12';
for (const pol of ['none', 'mkt']) {
  const R = JSON.parse(execFileSync('node', [(process.env.RUN||'/tmp/claude-0/sim/run3.js'), (process.env.LF||'/home/claude/w3/ledger.html'), process.argv[3] || 'all', tr, '104', pol, arg], { encoding: 'utf8', maxBuffer: 1e8 }).trim().split('\n').pop());
  let n = 0, y1 = 0, y2 = 0, pr = 0, cnt = 0; const rows = [];
  R.forEach(r => { if (!r.opened) return; n += r.opened; y1 += r.y1; y2 += r.y2; const p = r.m.filter(x => x > 0).length; pr += p; cnt += r.opened; const s = r.m.slice().sort((a, b) => a - b); rows.push(r.t + ' ' + r.y1 + '/' + r.y2 + '/' + r.opened + ' med' + (s.length ? s[Math.floor(s.length / 2)] : '-') + ' prof' + p); });
  console.log(pol.toUpperCase(), 'Y1 survive', Math.round(y1 / n * 100) + '%', 'Y2', Math.round(y2 / n * 100) + '%', 'profitable after paying yourself', Math.round(pr / cnt * 100) + '%');
  console.log(rows.join(' | '));
}

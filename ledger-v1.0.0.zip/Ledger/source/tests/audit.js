/* Ledger audit harness: node audit.js FILE JOBS.json OUT.json
   JOBS: [{t, cc, s, seed, w}]  t=business type, cc=country, s=strategy, w=weeks */
const puppeteer = require('/opt/npm-tools/node_modules/puppeteer-core');
const fs = require('fs');
const [,, file, jobsF, outF] = process.argv;
(async () => {
  const jobs = JSON.parse(fs.readFileSync(jobsF, 'utf8'));
  const b = await puppeteer.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--no-sandbox', '--disable-gpu'], headless: 'new', protocolTimeout: 3600000 });
  const p = await b.newPage();
  const errs = [];
  p.on('pageerror', e => errs.push('PAGEERR ' + e.message));
  p.on('console', m => { if (m.type() === 'error') errs.push('CONSOLE ' + m.text().slice(0, 200)); });
  await p.goto('file://' + file, { waitUntil: 'domcontentloaded' });
  await new Promise(r => setTimeout(r, 600));
  const out = [];
  for (let i = 0; i < jobs.length; i += 20) {
    const part = await p.evaluate(js => {
      UI.render = function () { };
      const fin = v => typeof v === 'number' && isFinite(v);
      const R = [];
      for (const j of js) {
        const r = { t: j.t, cc: j.cc, s: j.s, seed: j.seed };
        try {
          UI.ui.inp.name = 'Audit Person'; UI.ui.sc = j.cc; UI.ui.city = null; UI.ACT.startgame();
          S.seed = j.seed; S.rs = j.seed; S.cash += 1e9; S.cash0 = S.cash; S.flow = {};
          if (j.kt) R8.KT[j.t] = j.kt; if (j.pf) R8.PF[j.t] = j.pf;
          const co = startCompany(j.t, { name: 'Audit ' + j.t });
          if (typeof co === 'string') { r.err = co; R.push(r); continue; }
          injectCash(co, Math.round(setupEstimate(j.t, {}).total * 1.15));
          setupAndOpen(co);
          co.staff.forEach(s => onbItems(s.role).forEach(it => { s.onb = s.onb || {}; s.onb[it[0]] = 1; }));
          topUpEq(co);
          if (co.st !== 'open') { r.err = 'notopen:' + co.st; R.push(r); continue; }
          const bd = BD[j.t];
          r.ohrs = co.ohrs; r.staff0 = co.staff.length; r.cap0 = Math.round(capacity(co, bd).cap * 10) / 10; r.D0 = Math.round(demand(co, bd).D * 10) / 10;
          /* strategies */
          const SS = j.s.split('&'), has = x => SS.indexOf(x) >= 0;
          if (has('mgr')) { const n = genManager(co, bd.mgr || 'gen'); S.npcs[n.id] = n; const x = hireManager(co, n, Math.round(n.ask * 1.05)); r.mgrHire = x; co.ohrs = 0; }
          if (has('mkt') || has('mktx')) {
            const b0 = Math.max(KC(600), bd.Dc * bd.ticket * (co.size || 1) * 0.03) * (has('mktx') ? 3 : 1);
            const best = Object.keys(CH).filter(k => R19.CHX[k] && chOk(co, k) && !CH[k].prem && !CH[k].nat && !R19.CHX[k].loyal && !R19.CHX[k].seo).map(k => [k, R19.expect(co, k, b0)]).filter(x => x[1]).sort((a, b2) => b2[1].roi - a[1].roi)[0];
            if (best) { co.mkt[best[0]] = { b: Math.round(b0), since: S.week }; r.ch = best[0]; r.mktB = Math.round(b0); }
          }
          if (has('p+10')) co.price = PX16.lvl(1.1);
          if (has('p-10')) co.price = PX16.lvl(0.9);
          if (has('p+30')) co.price = PX16.lvl(1.3);
          if (has('maint2')) co.maint = 2;
          if (has('maint0')) co.maint = 0;
          if (has('oh60')) co.ohrs = 60;
          if (has('oh0')) co.ohrs = 0;
          if (has('hire')) { const st = stdStaff(bd, co.size)[0]; if (st) { const cs = searchWorkers(co, st[0], 'network').sort((a, b2) => a.ask - b2.ask); const c = cs[Math.floor(cs.length / 2)]; if (c) r.hire = hireWorker(co, c, Math.round(c.ask * 1.05 / 100) * 100); } }
          if (has('fire')) { if (co.staff.length) { const x = co.staff[0]; co.staff = co.staff.slice(1); S.npcs[x.id].hired = 0; r.fired = 1; } }
          const acc = { rev: 0, exp: 0, cat: {}, units: 0, D: 0, cap: 0, n: 0 };
          const c0 = co.cash;
          let bustW = 0, nan = '';
          for (let w = 0; w < j.w; w++) {
            if (has('disc') && w % 8 === 0) { const mx = [10, 15].filter(x => x <= ({}[j.t] || 40)); co.camp16 = { pct: 15, end: S.week + 2, w0: S.week }; }
            if (S.over) { r.over = 1; break; }
            nextWeek();
            if (co.st === 'bust') { bustW = w + 1; break; }
            const bw = co.bk.w || {};
            acc.rev += bw.rev || 0; acc.exp += sumExp(bw);
            Object.keys(bw).forEach(k => { acc.cat[k] = (acc.cat[k] || 0) + (bw[k] || 0); });
            if (w >= j.w - 13) { const lw = co.lastW || {}; acc.units += lw.units || 0; acc.D += lw.D || 0; acc.cap += lw.cap || 0; acc.n++; }
            ['cash', 'aware', 'rep', 'q', 'price'].forEach(k => { if (co[k] != null && !fin(co[k])) nan = nan || k + '@' + w; });
          }
          r.bust = bustW; r.nan = nan;
          const h = co.hist.slice(-6);
          const rev = h.reduce((a, x) => a + (x.rev || 0), 0), pr = h.reduce((a, x) => a + (x.profit || 0), 0);
          const ow = co.mgr ? 0 : wageFor(bd.std[0] ? bd.std[0][0] : 'helper', co) * 12 / 52 * Math.min(1, (co.ohrs || 0) / 40) * 1.14 * h.length * 4.33;
          r.rev6 = Math.round(rev); r.pr6 = Math.round(pr); r.mg = rev > 0 ? Math.round(pr / rev * 1000) / 10 : null; r.mgOw = rev > 0 ? Math.round((pr - ow) / rev * 1000) / 10 : null;
          r.util = acc.cap > 0 ? Math.round(acc.units / acc.cap * 100) / 100 : null; r.dcap = acc.cap > 0 ? Math.round(acc.D / acc.cap * 100) / 100 : null;
          r.units13 = Math.round(acc.units); r.cash = Math.round(co.cash); r.dcash = Math.round(co.cash - c0);
          r.booksNet = Math.round(acc.rev - acc.exp);
          r.cat = Object.fromEntries(Object.entries(acc.cat).map(([k, v]) => [k, Math.round(v)]));
          r.staff = co.staff.length; r.q = Math.round(co.q || 0); r.rep = Math.round(co.rep || 0); r.aware = Math.round(co.aware || 0); r.rating = ratingOf(co);
          r.mk = co.mk19 ? Object.fromEntries(Object.entries(co.mk19.ch).map(([k, v]) => [k, { c: v.cust, sp: Math.round(v.sp), rev: Math.round(v.rev) }])) : null;
          r.val = Math.round(companyValue(co));
          r.st = co.st; try { r.gaps = ledgerGaps().filter(g => g[0] !== 'me').map(g => g[0] + ':' + Math.round(g[1])).slice(0, 3).join(','); } catch (e) { r.gaps = 'n/a'; }
        } catch (e) { r.err = 'EXC ' + e.message + ' ' + (e.stack || '').split('\n')[1]; }
        R.push(r);
      }
      return R;
    }, jobs.slice(i, i + 20));
    out.push(...part);
    process.stderr.write('.');
  }
  fs.writeFileSync(outF, JSON.stringify({ out, errs: errs.slice(0, 200) }));
  await b.close();
})();

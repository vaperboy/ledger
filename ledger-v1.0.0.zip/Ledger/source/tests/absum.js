const fs=require('fs');const R=[].concat(...process.argv.slice(2).map(f=>JSON.parse(fs.readFileSync(f,'utf8').replace(/\n\[[^\]]*\]\s*$/,''))));
let better=0,worse=0,bA=0,bB=0,n=0,ruin=[];
const rows=R.map(x=>{if(x.A.dead||x.B.dead)return x.t+' '+x.seed+' dead pre';n++;const a=x.A.prof6,b=x.B.prof6;if(x.A.bust)bA++;if(x.B.bust)bB++;if(b>a)better++;else worse++;
 if(x.B.bust&&!x.A.bust||(a>0&&b<-Math.abs(a)*0.5-50))ruin.push(x.t+'/'+x.seed);
 return (x.t+' '+x.seed).padEnd(16)+' pre '+String(x.pre).padEnd(14)+' A '+String(a).padStart(7)+(x.A.bust?' BUST':'     ')+' '+x.A.staff.padEnd(6)+' | B '+String(b).padStart(7)+(x.B.bust?' BUST'+x.B.bust:'     ')+' '+x.B.staff.padEnd(6)+' mgr '+Math.round(x.B.mgrWage/1000)+'k';});
console.log(rows.join('\n'));console.log('runs',n,'manager better',better,'worse',worse,'bust A',bA,'bust B',bB);console.log('manager ruined a business that was fine without:',ruin.join(' '));

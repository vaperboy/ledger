/* ---------- daily pacing ----------
   The economy is still calculated in weekly steps (the existing simulation, unchanged). Each week's result is then
   paid out in seven equal daily slices, and its messages and news land on random days of that week, so money and
   events arrive every day while the total over a week is exactly what the weekly simulation produced. */
  function stageWeek() {
    const meB = S.cash, coB = {};
    S.cos.forEach(c => {
      coB[c.id] = c.cash;
    });
    const inB = new Set(S.inbox.map(m => m.id)), newsB = new Set(S.news);
    advance('week');
    const rep = Object.assign({}, S.rep, { bw: {}, cos: [], meD: 0, w: S.week });
    S.cos.forEach(c => {
      if (c.st === 'sold' || c.st === 'bust') return;
      const b = c.bk.w || {};
      for (const k in b) rep.bw[k] = (rep.bw[k] || 0) + b[k];
      rep.cos.push({ id: c.id, name: c.name, rev: b.rev || 0, profit: (b.rev || 0) - sumExp(b), units: c.lastW ? c.lastW.units : 0, unit: BD[c.type].unit });
    });
    rep.meD = S.cash - meB;
    if (S.over) {
      S.pend = null;
      S.lastRep = rep;
      return;
    }
    const P = { me: S.cash - meB, co: [], msgs: [], news: [], rep };
    if (P.me) moveCash(ME, -P.me);
    S.cos.forEach(c => {
      if (coB[c.id] == null) return;
      const d = c.cash - coB[c.id];
      c.wkD = d;
      if (d) {
        P.co.push([c.id, d]);
        moveCash(c, -d);
      }
    });
    const R = hrng(S.seed + ':day:' + S.week);
    S.inbox = S.inbox.filter(m => {
      if (inB.has(m.id)) return true;
      P.msgs.push({ m, d: Math.floor(R() * 7) });
      return false;
    });
    S.news = S.news.filter(n => {
      if (newsB.has(n)) return true;
      P.news.push({ n, d: Math.floor(R() * 7) });
      return false;
    });
    S.pend = P;
  }
  function releaseDay(day) {
    const P = S.pend;
    if (!P) return [];
    const part = tot => Math.round(tot * (day + 1) / 7) - Math.round(tot * day / 7);
    const a = part(P.me);
    if (a) moveCash(ME, a);
    P.co.forEach(x => {
      const c = getCo(x[0]), v = part(x[1]);
      if (c && v) moveCash(c, v);
    });
    const got = [];
    P.msgs.filter(x => x.d === day).reverse().forEach(x => {
      S.inbox.unshift(x.m);
      got.push(x.m);
    });
    P.news.filter(x => x.d === day).reverse().forEach(x => S.news.unshift(x.n));
    return got;
  }
  /* one day forward; returns what arrived and, at the end of a week, the report of the week just finished */
  function dayStep() {
    if (S.day == null) S.day = 0;
    if (S.day < 6) {
      S.day++;
      return { got: releaseDay(S.day), done: null };
    }
    const done = S.pend ? S.pend.rep : null;
    S.pend = null;
    S.day = 0;
    stageWeek();
    const got = S.over ? [] : releaseDay(0);
    if (done) S.lastRep = done;
    return { got, done };
  }
  window.dayStep = dayStep;
  const needsYou = m => m.status === 'open' || !m.read;
  function afterDays(r) {
    save();
    if (S.over) {
      render(true);
      return;
    }
    if (r.done && r.done.ev && r.done.ev.length) {
      go('weekreport');
      return;
    }
    render();
    if (r.got.some(m => m.status === 'open') && window.showPop) window.showPop();
  }
  ACT.nextday = () => afterDays(dayStep());
  /* Until needed: skips days until something new needs you (always available) */
  ACT.untilneeded = () => {
    let r = { got: [], done: null }, last = null, hit = false;
    for (let i = 0; i < 26 * 7 && !S.over; i++) {
      r = dayStep();
      if (r.done) last = r.done;
      if (r.got.some(needsYou)) {
        hit = true;
        break;
      }
    }
    r.done = hit ? null : (r.done || last);
    afterDays(r);
  };
  ACT.weekrep = () => go('weekreport');


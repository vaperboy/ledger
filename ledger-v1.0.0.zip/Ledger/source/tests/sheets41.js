return (function () {
  /* opens every pop-up reachable from the main screens and reports the ones taller than the screen */
  const ui = UI.ui, A = UI.ACT;
  const NAV = new Set(['go', 'cotab', 'cofin', 'cosub', 'codeal', 'hqtab', 'mtab', 'phapp', 'tab', 'go30', 'wr35s']);
  const BAD = /quit|reset|newgame|delete|closedown|close36|sellco|bust|wipe|restart|startgame|untilneeded|nextday|nextweek|repdone|fire|leave|sheetclose|scrim|back|^none$/i;
  const snapU = () => { const o = {}; Object.keys(ui).forEach(k => { const v = ui[k]; if (k === 'sheet' || typeof v === 'function') return; try { o[k] = JSON.parse(JSON.stringify(v)); } catch (e) { } }); return o; };
  const restoreU = s => { Object.assign(ui, JSON.parse(JSON.stringify(s))); ui.sheet = null; };
  const S0 = JSON.stringify(S);
  const restoreS = () => { const o = JSON.parse(S0); Object.keys(S).forEach(k => { delete S[k]; }); Object.assign(S, o); };
  const main = () => document.querySelector('main') || document.body;
  const onTabs = () => [...main().querySelectorAll('.ptabs button.on, .seg button.on, .subtabs button.on')].map(b => b.textContent.trim()).join('/');
  const key = () => ui.tab + '|' + (ui.tab === 'phone' ? JSON.stringify(ui.ph || {}) : (ui.view ? ui.view.n + JSON.stringify(ui.view.p || {}) : '')) + '|' + onTabs();
  const seen = new Set(), seenSheet = new Set(), out = [], perView = {};
  let opened = 0;
  function measureSheet(where) {
    const sh = document.querySelector('.scrim .sheet');
    if (!sh) return;
    const t = (sh.querySelector('h2') || sh).textContent.trim().slice(0, 40);
    if (seenSheet.has(t)) return;
    seenSheet.add(t);
    opened++;
    const ov = sh.style.overflowY; sh.style.overflowY = 'hidden';
    const pg = sh.querySelector('.pager'); if (pg) pg.style.display = 'none';
    [...sh.querySelectorAll('*')].forEach(x => { if (x.style && x.style.display === 'none' && !x.classList.contains('pager')) x.dataset.h41 = 1, x.style.display = ''; });
    const over = sh.scrollHeight - sh.clientHeight;
    const form = !!sh.querySelector('input,textarea,select,.chips');
    if (over > 4) out.push((form ? 'FORM ' : 'TEXT ') + '+' + over + 'px  "' + t + '"  ← ' + where);
    sh.style.overflowY = ov;
  }
  function visit(path, depth) {
    try { UI.render(true); } catch (e) { out.push('ERR render ' + path + ' ' + e.message); return; }
    const k = key();
    if (seen.has(k)) return;
    seen.add(k);
    const vn = ui.tab === 'phone' ? 'ph:' + ((ui.ph || {}).n) : ui.view ? ui.view.n : '?';
    perView[vn] = (perView[vn] || 0) + 1;
    if (perView[vn] > 4 && !/^(co|hq|ph:)/.test(vn)) return;
    if (vn === 'co' && perView[vn] > 60) return;
    const here = snapU();
    const btns = [...main().querySelectorAll('[data-a]')].filter(b => !b.closest('nav')).map(b => [b.getAttribute('data-a'), b.getAttribute('data-p'), (b.querySelector('b') || b).textContent.trim().replace(/\s+/g, ' ').slice(0, 30)]);
    const done = new Set();
    btns.forEach(t => {
      if (done.has(t[0] + t[1]) || BAD.test(t[0]) || !A[t[0]]) return;
      done.add(t[0] + t[1]);
      restoreU(here); UI.render(true);
      let p; try { p = t[1] != null ? JSON.parse(t[1]) : undefined; } catch (e) { p = t[1]; }
      const nav = NAV.has(t[0]) || /tab$|^setcat$/.test(t[0]);
      try { A[t[0]](p); } catch (e) { restoreS(); return; }
      if (ui.sheet) { try { UI.render(true); measureSheet(path + ' › ' + t[2]); } catch (e) { } ui.sheet = null; if (!nav) restoreS(); return; }
      if (nav && depth < 4) visit(path + ' › ' + t[2], depth + 1);
      else if (!nav) restoreS();
    });
  }
  ['home', 'cos', 'hq', 'phone', 'meet'].forEach(t => { ui.sheet = null; try { A.tab(t); } catch (e) { } ui.stack = []; visit(t, 0); restoreS(); });
  return 'opened ' + opened + ' pop-ups, ' + out.length + ' too tall\n' + out.join('\n');
})()

const [a, b] = process.argv.slice(2);
const o = [...require('./' + a).out, ...require('./' + b).out];
const by = {}; o.forEach(r => { (by[r.t] = by[r.t] || {})[r.s] = (by[r.t][r.s] || []).concat([r]); });
const m = a => a.length ? Math.round(a.reduce((x, y) => x + y, 0) / a.length) : null;
const S = [...new Set(o.map(r => r.s))];
console.log('type | ' + S.map(s => s + ' prof6k/bust').join(' | ') + ' | issues');
for (const t in by) {
  const B = by[t];
  const cells = S.map(s => { const L = B[s] || []; return m(L.map(r => (r.pr6 || 0) / 1000)) + 'k/' + L.filter(r => r.bust).length; });
  const iss = o.filter(r => r.t === t && (r.err || r.nan || (r.gaps && r.gaps !== ''))).map(r => r.s + ':' + (r.err || r.nan || 'gap ' + r.gaps)).slice(0, 3).join(';');
  console.log(t + ' | ' + cells.join(' | ') + ' | ' + iss);
}
const pm = o.filter(r => r.s === 'mkt' && r.rev6 > 0);
console.log('mkt: profitable share (6mo profit>0): ' + Math.round(pm.filter(r => r.pr6 > 0).length / pm.length * 100) + '% of ' + pm.length);
const pmg = o.filter(r => r.s === 'mgr' && r.rev6 > 0);
console.log('mgr: bust ' + o.filter(r => r.s === 'mgr' && r.bust).length + '/' + o.filter(r => r.s === 'mgr').length + ', base bust ' + o.filter(r => r.s === 'base' && r.bust).length + '/' + o.filter(r => r.s === 'base').length);

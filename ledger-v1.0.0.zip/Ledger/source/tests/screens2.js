/* ---------- week report: full screen ---------- */
  V.titles.weekreport = 'Week report';
  V.heads = V.heads || {};
  V.heads.weekreport = function () {
    const r = S.lastRep;
    const d = r ? (r.nw1 != null ? r.nw1 : netWorth().total) - (r.nw0 || 0) : 0;
    return { t: 'Week report', sub: r ? 'Week ending ' + dateStr((r.w || S.week)) : '', right: r ? '<span class="pill ' + (d >= 0 ? 'grn' : 'amb') + '">' + (d >= 0 ? '+' : '−') + mshort(Math.abs(d)) + '</span>' : '' };
  };
  V.weekreport = function () {
    const r = S.lastRep;
    if (!r) return '<div class="calm">The first report arrives at the end of your first full week.</div>';
    const nw = netWorth().total, d = nw - (r.nw0 || 0);
    const b = r.bw || {};
    const lines = [
      ['Revenue, all companies', b.rev || 0, 1],
      ['Wages and charges', b.wages || 0, -1],
      ['Rent, power, materials', (b.rent || 0) + (b.cogs || 0) + (b.oth || 0), -1],
      ['Marketing', b.mkt || 0, -1],
      ['Insurance and accounting', (b.ins || 0) + (b.acc || 0), -1],
      ['Loan interest', b.int || 0, -1],
      ['Fines and losses', (b.fine || 0) + (b.loss || 0), -1]
    ].filter(x => x[1]);
    let h = '<div class="card ovhero"><span class="lab">Net worth</span><b class="huge">' + nok(nw) + '</b><span class="pills"><span class="pl ' + (d >= 0 ? 'g' : 'r') + '">' + (d >= 0 ? '+' : '−') + mshort(Math.abs(d)) + ' vs last week</span></span></div>';
    h += '<h2 class="sec">Money in and out</h2><div class="card">' + (lines.length ? lines.map(x => row(x[0], '<span class="' + (x[2] > 0 ? 'pos' : 'neg') + '">' + (x[2] > 0 ? '+' : '−') + npadL(x[1]) + '</span>')).join('') : '<span class="muted small">No company money moved this week.</span>') + (r.meD ? row('Your private account', '<span class="' + sgn(r.meD) + '">' + (r.meD > 0 ? '+' : '−') + npadL(Math.abs(r.meD)) + '</span>') : '') + '</div>';
    if (r.cos && r.cos.length) h += '<h2 class="sec">Per company</h2><div class="lrows">' + r.cos.map(c => '<button class="lrow" data-a="go" data-p="' + esc(JSON.stringify({ n: 'co', p: { id: c.id } })) + '"><span class="av">' + esc(String(c.name).split(/\s+/).slice(0, 2).map(x => x[0]).join('').toUpperCase()) + '</span><span class="ctext"><b>' + esc(c.name) + '</b><small>' + (Math.round((c.units || 0) * 10) / 10) + ' ' + esc(unitPl(c.unit, c.units || 0)) + ' · revenue ' + mshort(c.rev) + '</small></span><b class="num ' + sgn(c.profit) + '">' + (c.profit >= 0 ? '+' : '−') + mshort(Math.abs(c.profit)) + '</b></button>').join('') + '</div>';
    const ev = r.ev || [];
    if (ev.length) h += '<h2 class="sec">What happened</h2><div class="lrows">' + ev.slice(0, 40).map(e => {
      const co = e.co ? getCo(e.co) : null;
      const tg = e.tone === 'good' ? ['Good', 'green'] : e.tone === 'bad' ? ['Problem', 'red'] : ['Info', ''];
      return '<div class="lrow"><span class="ctext"><b class="wrap">' + esc(e.t) + '</b>' + (co ? '<small>' + esc(co.name) + '</small>' : '') + '</span><span class="badge ' + tg[1] + '">' + tg[0] + '</span></div>';
    }).join('') + '</div>';
    h += btn('Continue', 'back', undefined, 'primary wide go');
    return h;
  };

/* ---------- bank: mockup overview; loans and credit keep their existing screens ---------- */
  const bank0 = V.bank;
  V.bank = function () {
    const t = ui.btab || 'acc';
    if (t !== 'acc') return bank0();
    const cos = live().filter(c => c.st !== 'setup' || c.cash);
    const deps = sum(S.inv.deposits, d => d.bal);
    const total = S.cash + S.sav.bal + deps + sum(cos, c => c.cash);
    let h = U.tabsRow([['acc', 'Accounts'], ['loans', 'Loans'], ['credit', 'Credit']], t, 'btab');
    h += '<div class="card ovhero"><span class="lab">Total across all accounts</span><b class="huge">' + nok(total) + '</b><div class="three">' + btn('Transfer', 'trsheet', undefined, 'primary') + btn('Pay', 'btab', { v: 'loans' }) + btn('Invest', 'phapp', { n: 'invest' }) + '</div></div>';
    h += '<h2 class="sec">Accounts</h2><div class="lrows">' +
      '<div class="lrow"><span class="lic">' + svg('coin', 20) + '</span><span class="ctext"><b>Personal</b><small>' + esc(S.player && S.player.name ? S.player.name : 'Current account') + '</small></span><b class="num ' + (S.cash < 0 ? 'neg' : '') + '">' + mshort(S.cash) + '</b></div>' +
      '<button class="lrow" data-a="trsheet" data-p="' + esc(JSON.stringify({ from: 'me', to: 'sav' })) + '"><span class="lic">' + svg('bank', 20) + '</span><span class="ctext"><b>Savings</b><small>' + pc(Math.max(0.005, policy() - 0.012), 1) + ' interest</small></span><b class="num">' + mshort(S.sav.bal) + '</b></button>' +
      '<button class="lrow" data-a="depsheet"><span class="lic">' + svg('doc', 20) + '</span><span class="ctext"><b>Fixed deposits</b><small>' + (S.inv.deposits.length ? S.inv.deposits.length + ' open' : 'Lock money for a better rate') + '</small></span><b class="num">' + mshort(deps) + '</b></button>' +
      cos.map(c => '<button class="lrow" data-a="go" data-p="' + esc(JSON.stringify({ n: 'co', p: { id: c.id, t: 'more' } })) + '"><span class="lic">' + svg('biz', 20) + '</span><span class="ctext"><b>' + esc(c.name) + '</b><small>Business account</small></span><b class="num ' + (c.cash < 0 ? 'neg' : '') + '">' + mshort(c.cash) + '</b></button>').join('') + '</div>';
    const pl = S.loans.filter(l => !l.co);
    if (pl.length) h += '<h2 class="sec">Loan' + (pl.length > 1 ? 's' : '') + '</h2>' + pl.map(l => {
      const base = l.amt0 || (l.name === 'Start-up loan' ? (CO[S.country] || CC()).loan : 0) || l.bal;
      const paid = base > 0 ? Math.max(0, Math.min(1, 1 - l.bal / base)) : 0;
      return '<div class="card"><div class="bhead"><b>' + esc(l.name) + '</b><span class="badge amber">' + pc(loanRate(l), 1) + ' floating</span></div>' + row('Remaining', '<span class="neg">' + nok(l.bal) + '</span>') + row('Next payment', nok(l.pay) + ' · monthly') + bar(paid * 100, 'var(--amber)') + '<div class="two">' + btn('Pay extra', 'repaysheet', { id: l.id }, 'wide') + btn('Borrow more', 'btab', { v: 'loans' }, 'wide') + '</div></div>';
    }).join('');
    h += '<h2 class="sec">Recent</h2><div class="lrows">' + (S.log.length ? S.log.slice(0, 8).map(x => '<div class="lrow"><span class="ctext"><b>' + esc(x.l) + '</b><small>' + dateStr(x.w) + (x.co && getCo(x.co) ? ' · ' + esc(getCo(x.co).name) : '') + '</small></span><b class="num ' + sgn(x.a) + '">' + (x.a > 0 ? '+' : '−') + npadL(Math.abs(x.a)) + '</b></div>').join('') : '<div class="lrow"><small>Nothing yet.</small></div>') + '</div>';
    return h;
  };
  /* transfer between your accounts and into a company */
  function trSheet() {
    const tr = ui.tr = ui.tr || { from: 'me', to: 'sav' };
    const opts = [['me', 'Personal'], ['sav', 'Savings']].concat(live().map(c => ['co:' + c.id, c.name]));
    const pick = (k, lab) => '<div class="lab">' + lab + '</div><div class="chips">' + opts.filter(o => k === 'from' ? o[0] === 'me' || o[0] === 'sav' : o[0] !== tr.from).map(o => btn(esc(o[1]), 'trset', { k: k, v: o[0] }, 'chip' + (tr[k] === o[0] ? ' primary' : ''))).join('') + '</div>';
    const toCo = tr.to.indexOf('co:') === 0;
    openSheet('<h2>Transfer</h2>' + pick('from', 'From') + pick('to', 'To') + inp('tamt', 'Amount') + quick('tamt', [10000, 50000, 100000, 500000]) +
      (toCo ? '<p class="muted small">Money you put into a company is recorded as share capital from you.</p>' : '') +
      '<p class="muted small">To take money out of a company, open the company and use Move money.</p><div class="btnrow">' + btn('Cancel', 'sheetclose', undefined, 'ghost') + btn('Send', 'trgo', undefined, 'primary') + '</div>');
  }
  ACT.trsheet = p => {
    ui.tr = Object.assign({ from: 'me', to: 'sav' }, ui.tr || {}, p && typeof p === 'object' ? p : {});
    trSheet();
  };
  ACT.trset = p => {
    ui.tr[p.k] = p.v;
    if (ui.tr.from === ui.tr.to) ui.tr.to = ui.tr.from === 'me' ? 'sav' : 'me';
    if (ui.tr.from === 'sav' && ui.tr.to.indexOf('co:') === 0) ui.tr.to = 'me';
    trSheet();
  };
  ACT.trgo = () => {
    const tr = ui.tr || {}, a = Math.round(U.inum('tamt', 0));
    if (!(a > 0)) {
      toast('Enter an amount.', true);
      return;
    }
    let ok = false;
    if (tr.from === 'me' && tr.to === 'sav') ok = saveMove(a);
    else if (tr.from === 'sav' && tr.to === 'me') ok = saveMove(-a);
    else if (tr.from === 'me' && tr.to.indexOf('co:') === 0) {
      const co = getCo(isNaN(+tr.to.slice(3)) ? tr.to.slice(3) : +tr.to.slice(3)) || live().find(c => String(c.id) === tr.to.slice(3));
      ok = co ? injectCash(co, a) : false;
    }
    if (!ok) {
      toast('Not enough money for that transfer.', true);
      return;
    }
    ui.inp.tamt = '';
    ui.sheet = null;
    save();
    render();
    toast('Sent ' + money(a) + '.');
  };
  ACT.depsheet = () => {
    openSheet('<h2>Fixed deposits</h2><p class="muted small">Lock money for a better rate. You cannot touch it until it matures.</p>' + (S.inv.deposits.length ? '<div class="card">' + S.inv.deposits.map(d => row(money(d.bal) + ' at ' + pc(d.rate, 2), 'matures ' + dateStr(d.wEnd))).join('') + '</div>' : '') + inp('damt', 'Amount') + '<div class="chips">' + [13, 26, 52].map(w => '<button class="btn chip" data-a="depgo" data-p="' + w + '">' + w + ' weeks · ' + pc(Math.max(0.01, policy() - 0.002 + w / 52 * 0.004), 2) + '</button>').join('') + '</div>' + btn('Close', 'sheetclose', undefined, 'ghost wide'));
  };
  ACT.depgo = w => {
    ui.sheet = null;
    ACT.opendep(w);
  };

/* ---------- tax: mockup summary on top, existing details below ---------- */
  const tax0 = V.tax;
  V.tax = function () {
    const t = S.tax, est = personalTaxEstimate();
    let w = S.week;
    while (!isYearEnd(w)) w++;
    const left = w - S.week + 1;
    const body = tax0().replace(/^<div class="trio">[\s\S]*?<\/div><\/div><\/div>/, '');
    return '<div class="card ovhero"><span class="lab">Tax due this year</span><b class="huge">' + nok(est) + '</b><span class="pills"><span class="pl a">Assessment in ' + left + ' wk</span><span class="pl">Withheld ' + mshort(t.withheld || 0) + '</span></span></div>' + body;
  };

/* ---------- interviews: keep the salary talk as chat bubbles ---------- */
  const offer0 = ACT.offer;
  ACT.offer = p => {
    const n = S.npcs[p.n];
    if (!n) return offer0(p);
    const w = Math.round(U.inum('w' + n.id, n.ask) / 100) * 100;
    const L = ((ui.talk = ui.talk || {})[n.id] = (ui.talk || {})[n.id] || []);
    L.push({ me: 1, t: 'I can offer ' + money(w) + ' a month.' });
    offer0(p);
    if (n.hired) L.push({ me: 0, t: 'Deal. I can start right away.' });
    else {
      L.push({ me: 0, t: w < n.ask ? 'That is below what I asked. Could you come closer to ' + money(n.ask) + '?' : 'I need to think about the terms.' });
      render();
    }
  };


/* Round 59: the iPhone app's side of the game, with a stand-in for ios-app/native/app-bridge.js (window.LedgerApp):
   files on the phone, iCloud, the App Store. Run: node tests/round59_app.js $PWD/ledger.html */
const puppeteer = require('/opt/npm-tools/node_modules/puppeteer-core');
const [,, file] = process.argv;
const KEY = 'ledger-v3';
/* the stand-in: state lives in window.__m and is carried from one launch to the next by the test */
function mock(st) {
  const m = window.__m = st;
  const ok = v => Promise.resolve(v);
  window.LedgerApp = {
    platform: 'ios',
    open: u => { m.opened = u; return ok(); },
    disk: {
      load: () => ok({ local: JSON.parse(JSON.stringify(m.files)), cloud: m.icloud ? JSON.parse(JSON.stringify(m.cloud)) : null }),
      write: o => { if (o.value == null) delete m.files[o.key]; else m.files[o.key] = { v: o.value, t: o.t }; m.writes++; return ok({ ok: true }); },
      cloud: o => { if (o.value == null) delete m.cloud[o.key]; else m.cloud[o.key] = { v: o.value, t: o.t, a: o.about || null }; m.cwrites++; return ok({ ok: true }); },
      share: o => { m.shared = o.name; return ok(); },
      onCloud: cb => { m.cloudCb = cb; }
    },
    store: {
      load: () => ok({ items: { monthly: 'NOK 49', yearly: 'NOK 299', lifetime: 'NOK 799', world: 'NOK 59', tycoon: 'NOK 79', estates: 'NOK 59', time: 'NOK 49' }, own: m.own }),
      buy: id => m.cancel ? Promise.reject({ cancelled: true }) : ok(m.own = id === 'yearly' || id === 'monthly' || id === 'lifetime' ? { pro: id, packs: m.own.packs || {}, renews: Date.UTC(2027, 9, 17) } : { pro: m.own.pro || null, packs: Object.assign({}, m.own.packs, { [id]: true }) }),
      restore: () => ok(m.own),
      manage: () => { m.managed = 1; return ok(); },
      onChange: cb => { m.cb = cb; }
    }
  };
}
const fresh = () => ({ files: {}, cloud: {}, icloud: true, own: { pro: null, packs: {} }, writes: 0, cwrites: 0 });
(async () => {
  const b = await puppeteer.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--no-sandbox', '--disable-gpu'], headless: 'new' });
  const out = [], errs = [], P = (ok, n, i) => out.push((ok ? 'PASS ' : 'FAIL ') + n + (i != null && i !== '' ? ' · ' + i : ''));
  const wait = ms => new Promise(r => setTimeout(r, ms));
  /* one launch of the app: a phone (browser context) with its own web storage, the stand-in with state st */
  async function launch(ctx, st) {
    const p = await ctx.newPage();
    await p.setViewport({ width: 390, height: 844, deviceScaleFactor: 1, isMobile: true, hasTouch: true });
    p.on('pageerror', e => errs.push('PAGEERR ' + e.message));
    await p.evaluateOnNewDocument(mock, st);
    await p.goto('file://' + file, { waitUntil: 'domcontentloaded' }); await wait(700);
    return p;
  }
  const state = p => p.evaluate(() => { const m = Object.assign({}, window.__m); delete m.cb; delete m.cloudCb; return JSON.parse(JSON.stringify(m)); });
  const newGame = p => p.evaluate(() => { UI.ui.menu = 0; UI.ui.inp.name = 'Ada App'; UI.ui.sc = 'UK'; UI.ui.city = null; UI.ui.story = 'loan'; UI.ACT.startgame(); UI.render(true); return S.week; });

  /* 1. a new phone: the game is written to a file and, with iCloud on, to iCloud */
  const phoneA = await b.createBrowserContext();
  let p = await launch(phoneA, fresh());
  await newGame(p);
  await p.evaluate(() => { UI.save(); }); await wait(1800);
  let m = await state(p);
  P(!!m.files[KEY], 'the game is kept in a file a moment after a change');
  P(!m.cloud[KEY], 'iCloud waits half a minute, not every change');
  await p.evaluate(() => { UI.save(); UI.flushSave(); }); await wait(100);
  m = await state(p);
  P(!!m.cloud[KEY] && m.cloud[KEY].a && m.cloud[KEY].a.name === 'Ada App', 'leaving the app sends the game to iCloud, with a line about it', m.cloud[KEY] && JSON.stringify(m.cloud[KEY].a));
  const r1 = await p.evaluate(() => ({ s: UI.V.settings(), showAll: PRO.showAll }));
  P(/on this phone and in iCloud/.test(r1.s), 'Settings says where the game is kept');
  P(!/Play as a free player/.test(r1.s) && !r1.showAll, 'no test switches in the app, and screens appear as you play');
  /* save to a file uses the share sheet */
  await p.evaluate(() => UI.ACT.savefile()); m = await state(p);
  P(/^ledger-Ada-App-week\d+\.txt$/.test(m.shared || ''), 'Save to a file opens the share sheet', m.shared);
  const saved = m;
  await p.close();

  /* 2. web storage cleared on the same phone: the files bring the game back */
  const phoneA2 = await b.createBrowserContext();
  p = await launch(phoneA2, Object.assign(fresh(), { files: saved.files, cloud: saved.cloud }));
  let r = await p.evaluate(() => ({ s: !!S, name: S && S.player.name, menu: UI.ui.menu }));
  P(r.s && r.name === 'Ada App', 'cleared web storage: the game comes back from the file', JSON.stringify(r));
  r = await p.evaluate(() => UI.V.menu());
  P(!/From iCloud/.test(r), 'the game this phone sent to iCloud is not offered back to it');
  await p.close();

  /* 3. a new phone with only iCloud: the game carries on there */
  const phoneB = await b.createBrowserContext();
  p = await launch(phoneB, Object.assign(fresh(), { cloud: saved.cloud }));
  r = await p.evaluate(() => ({ s: !!S, name: S && S.player.name }));
  P(r.s && r.name === 'Ada App', 'a new phone picks the game up from iCloud', JSON.stringify(r));
  /* play on, so phone B's game is newer, and send it to iCloud */
  await p.evaluate(() => { for (let i = 0; i < 3; i++) nextWeek(); UI.save(); UI.flushSave(); }); await wait(100);
  const cloudB = (await state(p)).cloud;
  await p.close();

  /* 4. back on phone A: the newer iCloud game is offered in the menu, the game here stays */
  const tOld = Date.now() - 3600e3;
  const filesA = JSON.parse(JSON.stringify(saved.files)); filesA[KEY].t = tOld;
  const phoneA3 = await b.createBrowserContext();
  p = await launch(phoneA3, Object.assign(fresh(), { files: filesA, cloud: cloudB }));
  r = await p.evaluate(() => ({ week: S && S.week, menu: UI.V.menu() }));
  P(/From iCloud, another device/.test(r.menu), 'a game played later on another phone shows in the menu');
  const w0 = r.week;
  r = await p.evaluate(() => { UI.ACT.menuload({ s: 'cloud' }); return { week: S.week, prev: !!localStorage.getItem('ledger-v3:prev'), cloud: localStorage.getItem('ledger-v3:cloud'), meta: JSON.parse(localStorage.getItem('ledger-v3:meta') || '{}') }; });
  P(r.week === w0 + 3, 'loading it continues the other phone\'s game', w0 + ' → ' + r.week);
  P(r.prev && !r.cloud && !r.meta.cloud, 'the game that was here is kept as the previous game, the offer is gone');
  await p.close();

  /* 5. starting over deletes the game from the files and iCloud */
  const phoneA4 = await b.createBrowserContext();
  p = await launch(phoneA4, Object.assign(fresh(), { files: saved.files, cloud: saved.cloud }));
  await p.evaluate(() => { UI.ACT.newgame(); UI.flushSave(); }); await wait(100);
  m = await state(p);
  P(!m.files[KEY] && !m.cloud[KEY], 'a new game removes the old one from the file and iCloud, so it cannot come back');
  await p.close();

  /* 6. the App Store: prices, owned packs, buying, cancelling, restore, manage */
  const phoneC = await b.createBrowserContext();
  p = await launch(phoneC, Object.assign(fresh(), { own: { pro: null, packs: { world: true } } }));
  await newGame(p);
  r = await p.evaluate(() => ({ on: PRO.on, w: PRO.has('world'), t: PRO.has('tycoon'), it: PRO.ccOk('IT') }));
  P(!r.on && r.w && r.it && !r.t, 'an owned pack opens its part only', JSON.stringify(r));
  r = await p.evaluate(() => { PRO.store(); return UI.V.pro59(); });
  P(/NOK 299/.test(r) && /NOK 79/.test(r) && /Yours/.test(r), 'the store shows the App Store prices and what is yours');
  P(/renew by themselves until you cancel/.test(r) && /Terms of use/.test(r) && /Privacy/.test(r), 'with the renewal terms, terms of use and privacy');
  await p.evaluate(() => { window.__m.cancel = 1; UI.ACT.probuy({ id: 'yearly' }); }); await wait(100);
  r = await p.evaluate(() => ({ on: PRO.on, toast: (document.querySelector('.toast') || {}).textContent || '' }));
  P(!r.on && !/did not go through/.test(r.toast), 'cancelling the purchase changes nothing and shows no error');
  await p.evaluate(() => { window.__m.cancel = 0; UI.ACT.probuy({ id: 'yearly' }); }); await wait(100);
  r = await p.evaluate(() => ({ on: PRO.on, all: ['untl', 'slots', 'tycoon', 'clubs', 'estates', 'pe', 'trades'].every(k => PRO.has(k)), card: PRO.card(), kept: localStorage.getItem('ledger-v3:own') }));
  P(r.on && r.all, 'buying Pro opens everything');
  P(/renews/.test(r.card) && /"pro":"yearly"/.test(r.kept), 'Settings shows the plan and when it renews; it is kept on the phone, not in the save');
  r = await p.evaluate(() => { PRO.store(); return UI.V.pro59(); });
  P(/Manage subscription/.test(r) && !/Get Ledger Pro/.test(r), 'with Pro: manage the subscription, no plan picker');
  await p.evaluate(() => UI.ACT.promanage()); m = await state(p);
  P(m.managed === 1, 'Manage subscription opens the App Store page');
  /* the subscription ends: what was built keeps working, only new locked things ask */
  r = await p.evaluate(() => { S.cash += KC(5e8); const co = startCompany('bank', { form: 'AS', name: 'Test Bank' }); window.__m.cb({ pro: null, packs: { world: true } }); return { on: PRO.on, kept: typeof co !== 'string' && S.cos.some(c => c.id === co.id), lock: !PRO.typeOk('bank') }; });
  P(!r.on && r.kept && r.lock, 'when Pro ends, a bank already started stays, a new one asks', JSON.stringify(r));
  await p.close();

  /* 7b. a new phone where iCloud arrives a little after the start: the menu opens with the game */
  const phoneE = await b.createBrowserContext();
  p = await launch(phoneE, fresh());
  r = await p.evaluate(c => { const before = !!S; window.__m.cloudCb({ local: {}, cloud: c }); return { before, s: !!S, name: S && S.player.name, menu: UI.ui.menu, html: document.getElementById('app').textContent }; }, saved.cloud);
  P(!r.before && r.s && r.name === 'Ada App' && r.menu && /Continue/.test(r.html), 'iCloud arriving late on a new phone opens the menu with the game', JSON.stringify({ s: r.s, menu: r.menu }));
  await p.close();

  /* 7. iCloud off: the files still work, Settings says so */
  const phoneD = await b.createBrowserContext();
  p = await launch(phoneD, Object.assign(fresh(), { icloud: false }));
  await newGame(p);
  await p.evaluate(() => { UI.save(); UI.flushSave(); }); await wait(100);
  m = await state(p); r = await p.evaluate(() => UI.V.settings());
  P(!!m.files[KEY] && !Object.keys(m.cloud).length && /automatically on this phone\./.test(r), 'without iCloud the game is kept in a file only');
  await p.close();

  await b.close();
  console.log(out.join('\n') + (errs.length ? '\n' + errs.slice(0, 8).join('\n') : ''));
})();

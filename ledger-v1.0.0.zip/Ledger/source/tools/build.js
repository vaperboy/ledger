/* Ledger build: node tools/build.js [--dev]
   Concatenates the files listed in src/manifest.txt (in order) into ledger.dev.html, then minifies the scripts and
   styles into ledger.html and checks every script parses.
   Manifest lines: a path under src/; blank lines and "#" comments are ignored. Pictures are not built in: they live in
   the pictures folder next to ledger.html (tools/pictures.py makes them from src/assets/pictures). */
const fs = require('fs'), path = require('path');
const ROOT = path.join(__dirname, '..'), SRC = path.join(ROOT, 'src');
const man = fs.readFileSync(path.join(SRC, 'manifest.txt'), 'utf8').split('\n').map(s => s.trim()).filter(s => s && !s.startsWith('#'));
let out = '';
for (const m of man) {
  out += fs.readFileSync(path.join(SRC, m), 'utf8');
}
fs.writeFileSync(path.join(ROOT, 'ledger.dev.html'), out);
const esb = require('/opt/npm-tools/node_modules/esbuild');
let h = out;
const before = Buffer.byteLength(h);
h = h.replace(/<script>([\s\S]*?)<\/script>/g, (m, code) => '<script>' + esb.transformSync(code, { loader: 'js', minifyWhitespace: true, minifyIdentifiers: true, minifySyntax: true, legalComments: 'none', charset: 'utf8' }).code.trim().replace(/<\/script/gi, '<\\/script') + '</script>');
h = h.replace(/<style([^>]*)>([\s\S]*?)<\/style>/g, (m, at, css) => { try { return '<style' + at + '>' + esb.transformSync(css, { loader: 'css', minifyWhitespace: true, charset: 'utf8' }).code.trim() + '</style>'; } catch (e) { return m; } }); /* round 56: styles with an id are minified too */
let bad = 0;
const re = /<script>([\s\S]*?)<\/script>/g; let mm, i = 0;
while ((mm = re.exec(h))) { i++; try { new Function(mm[1]); } catch (e) { bad++; console.log('script', i, e.message); } }
fs.writeFileSync(path.join(ROOT, 'ledger.html'), h);
const after = Buffer.byteLength(h);
console.log('build: ' + man.length + ' files, ' + before + ' -> ' + after + ' bytes' + (bad ? ', ' + bad + ' scripts do not parse' : ''));
if (bad) process.exitCode = 1;

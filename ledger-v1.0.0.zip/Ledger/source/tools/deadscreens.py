# Cleanup helper (round 53): remove screens and actions that a later file replaces outright.
#   python3 tools/deadscreens.py [--dry]      (run from src/js)
# For each V.x / CT.x / ACT.x defined more than once (plain  X = ...  not pipeView), everything installed before the last
# outright replacement is never used: the earlier definitions, the pipelines put on them and those pipelines' steps.
import re, collections, sys
exec(open(__file__.replace('deadscreens.py', 'uistep.py'), encoding='utf8').read().split('def code(')[0].split('NOROUTE')[0])
DRY = '--dry' in sys.argv
order = [l.strip()[3:] for l in open('../manifest.txt') if l.strip().startswith('js/')]
T = {f: open(f, encoding='utf8').read() for f in order}
def endexpr(t, k):
    d = 0
    while k < len(t):
        c = t[k]
        if c in '\'"`':
            q = c; k += 1
            while t[k] != q:
                if t[k] == '\\': k += 1
                k += 1
        elif c in '([{': d += 1
        elif c in ')]}':
            d -= 1
            if d < 0: return k
        elif c == ';' and d == 0: return k
        elif c == '\n' and d == 0 and not re.match(r'\s*[.+\-*/?:|&]', t[k + 1:k + 20]) and not re.search(r'[+\-*/?:|&,(=]\s*$', t[k - 20:k]): return k - 1
        k += 1
    return k
ev = collections.defaultdict(list)
for f in order:
    t = T[f]
    for m in re.finditer(r'^([ \t]*)((?:window\.)?(?:V|CT|ACT|ACTS|U)\.\w+)\s*=(?![=>])\s*', t, re.M):
        X = m.group(2).replace('window.', '')
        if X.startswith(('V.titles', 'V.heads')): continue
        view = re.match(r"pipeView\('([^']+)'", t[m.end():])
        ev[X].append(dict(f=f, s=m.start(), e=m.end(), view=view.group(1) if view else None, ind=len(m.group(1))))
cut = collections.defaultdict(list)       # file -> [(start, end)]
deadnames = set()
for X, L in ev.items():
    defs = [e for e in L if not e['view']]
    if len(defs) < 2: continue
    pend = []
    for e in L:
        if not e['view'] and pend and e is not L[0]:
            for d in pend:
                t = T[d['f']]
                a = t.rindex('\n', 0, d['s']) + 1
                if d['view']:
                    z = t.index('\n', d['s']) + 1; deadnames.add(d['view'])
                else:
                    k = d['e']
                    if t.startswith('function', k) or re.match(r'(\([^)]*\)|\w+)\s*=>\s*\{', t[k:]):
                        z = match(t, t.index('{', k)) + 1
                    else:
                        z = endexpr(t, k) + 1
                    while z < len(t) and t[z] in ' ;': z += 1
                    if z < len(t) and t[z] == '\n': z += 1
                # a one-line comment right above goes with it
                pa = t.rindex('\n', 0, a - 1) + 1 if a > 0 else 0
                if re.match(r'\s*/\*.*\*/\s*$', t[pa:a]): a = pa
                cut[d['f']].append((a, z, X))
            pend = []
        pend.append(e)
# the steps of dead pipelines
for f in order:
    t = T[f]
    for m in re.finditer(r"^[ \t]*addStep\('([^']+?)(?:\.around|\.route)?', \d+,", t, re.M):
        if m.group(1) in deadnames:
            b = t.index('=>', m.end()); b2 = t.index('{', b) if t[b + 2:].lstrip().startswith('{') else None
            if b2 is not None:
                z = match(t, b2) + 1
            else:
                z = endexpr(t, b + 2)
            z = t.index(');', z) + 2
            if z < len(t) and t[z] == '\n': z += 1
            a = m.start()
            pa = t.rindex('\n', 0, a - 1) + 1 if a > 0 else 0
            if re.match(r'\s*/\*.*\*/\s*$', t[pa:a]): a = pa
            cut[f].append((a, z, 'step ' + m.group(1)))
n = 0
for f, L in cut.items():
    t = T[f]
    L = sorted(set(L), key=lambda x: -x[0])
    for a, z, X in L:
        print('%-26s %-16s %4d lines  %s' % (f.split('/')[-1], X, t[a:z].count('\n'), t[a:z].strip().split('\n')[0][:70]))
        n += t[a:z].count('\n')
        if not DRY: t = t[:a] + t[z:]
    if not DRY: open(f, 'w', encoding='utf8').write(t)
print(n, 'lines', 'would be removed' if DRY else 'removed')

# One-off (round 49): turn the base file + patch chain output into src/ files listed in src/manifest.txt.
# Concatenating the manifest reproduces the unminified build byte for byte.
import re, os, sys, json, subprocess
src = sys.argv[1]           # the unminified build (ledger.html before shrink)
root = sys.argv[2]          # w3/src
t = open(src, encoding='utf8').read()
lines = t.split('\n')
# offsets of each line start
off = [0]
for l in lines[:-1]: off.append(off[-1] + len(l) + 1)
def lpos(n): return off[n - 1]          # 1-based line -> char offset
def find_tag(tag, line):                 # char offset of a tag on a given line
    i = t.index(tag, lpos(line)); assert t.count('\n', 0, i) + 1 == line, (tag, line); return i
pieces = []                              # (relative path, text) or ('!carimg', None)
def add(path, text):
    if text: pieces.append((path, text))
# ---- fixed landmarks
s1 = find_tag('<style>', 8) + 7; e1 = find_tag('</style>', 326)
s2 = find_tag('<script>', 328) + 8; e2 = find_tag('</script>', 333)
s3 = find_tag('<script>', 334) + 8; e3 = find_tag('</script>', 16975)
s4 = find_tag('<script>', 16976) + 8; e4 = find_tag('</script>', 41431)
s5 = t.rindex('<style>') + 7; e5 = t.rindex('</style>')
add('shell/01-head.html', t[:s1])
add('styles/base.css', t[s1:e1])
add('shell/02.html', t[e1:s2])
add('js/nozoom.js', t[s2:e2])
add('shell/03.html', t[e2:s3])
def split_js(a, b, prefix, rx):
    body = t[a:b]
    cuts = [m.start() for m in re.finditer(rx, body, re.M)]
    if not cuts or cuts[0] != 0: cuts = [0] + cuts
    cuts.append(len(body))
    out = []
    for i in range(len(cuts) - 1):
        chunk = body[cuts[i]:cuts[i + 1]]
        m = re.match(r'/\* ---- (src|ui)/([\w/]+\.js) ---- \*/', chunk)
        r = re.match(r'/\* ===== (?:Round|round) (\w+)', chunk)
        if m: name = prefix + ('engine/' if m.group(1) == 'src' else 'ui/') + m.group(2)
        elif r:
            num = re.match(r'(\d+)(\w*)', r.group(1))
            name = prefix + 'rounds/round' + num.group(1).zfill(2) + num.group(2).lower() + '.js'
        else:
            k = re.match(r'/\* ===== ([^=.:(]+)', chunk)
            name = prefix + 'rounds/extra_' + (re.sub(r'[^a-z0-9]+', '_', k.group(1).lower()).strip('_')[:30] if k else 'start') + '.js'
        out.append([name, chunk])
    return out
eng = split_js(s3, e3, 'js/', r'^/\* ---- src/[\w/]+\.js ---- \*/$')
ui_ = split_js(s4, e4, 'js/', r'^/\* ---- ui/[\w/]+\.js ---- \*/$|^/\* ===== (?:Round|round) \w+|^/\* ===== (?:saves|Organic|Before hiring|Franchise lifecycle|Football clubs|Oil and gas|Bank liquidity|Pay spread)')
# a chunk that cannot be parsed on its own (it lives inside another file's closure) joins the one before it
def parses(code):
    p = subprocess.run(['node', '-e', 'new Function(require("fs").readFileSync(0,"utf8"))'], input=code.encode(), capture_output=True)
    return p.returncode == 0
def merge(chs):
    out = []   # [name, code, complete]
    for name, code in chs:
        if out and not out[-1][2]:
            out[-1][1] += code; out[-1][2] = parses(out[-1][1])
        else:
            out.append([name, code, parses(code)])
    for name, code, ok in out: assert ok, name
    return [[n, c] for n, c, ok in out]
# All round code sits inside the closure opened by ui/screens/mockup.js and closed after the no-zoom block:
# keep that closure as a head file and an end file, with the round files between them.
NZ = '/* ---------- no zooming: pinch, double tap, ctrl+wheel, ctrl +/- ---------- */'
for i, (name, code) in enumerate(ui_):
    if NZ in code:
        k = code.index(NZ)
        ui_[i:i + 1] = [[name, code[:k]], ['js/ui/screens/mockup_end.js', code[k:]]]
        break
hi = [i for i, c in enumerate(ui_) if c[0] == 'js/ui/screens/mockup.js'][0]
ei = [i for i, c in enumerate(ui_) if c[0] == 'js/ui/screens/mockup_end.js'][0]
assert parses(ui_[hi][1] + ui_[ei][1]), 'mockup head + end'
for name, code in ui_[hi + 1:ei]: assert parses(code), name
eng = merge(eng); ui_ = merge(ui_[:hi]) + ui_[hi:ei + 1] + merge(ui_[ei + 1:])
for name, code in eng: add(name, code)
add('shell/04.html', t[e3:s4])
for name, code in ui_:
    # the car photos are generated at build time from assets/cars
    m = re.search(r'^window\.CARIMG47 = .*;\n', code, re.M)
    if m:
        rest = code[m.end():]
        add(name.replace('.js', '_pre.js') if rest else name, code[:m.start()])
        pieces.append(('!carimg', None))
        add(name, rest)
    else: add(name, code)
add('shell/05-legacy-inline.html', t[e4:s5])
css = t[s5:e5]
cuts = [m.start() for m in re.finditer(r'^/\* ===== ', css, re.M)]
if not cuts or cuts[0] != 0: cuts = [0] + cuts
cuts.append(len(css))
for i in range(len(cuts) - 1):
    chunk = css[cuts[i]:cuts[i + 1]]
    k = re.match(r'/\* ===== ([^=.:(]+)', chunk)
    add('styles/' + str(i).zfill(2) + '_' + (re.sub(r'[^a-z0-9]+', '_', k.group(1).lower()).strip('_')[:28] if k else 'start') + '.css', chunk)
add('shell/06-end.html', t[e5:])
# write
seen = {}
man = []
for path, text in pieces:
    if path == '!carimg': man.append('!carimg'); continue
    if path in seen: seen[path] += 1; base, ext = os.path.splitext(path); path = base + '_' + str(seen[path]) + ext
    else: seen[path] = 1
    fp = os.path.join(root, path); os.makedirs(os.path.dirname(fp), exist_ok=True)
    open(fp, 'w', encoding='utf8').write(text)
    man.append(path)
open(os.path.join(root, 'manifest.txt'), 'w').write('\n'.join(man) + '\n')
print(len(man), 'pieces')

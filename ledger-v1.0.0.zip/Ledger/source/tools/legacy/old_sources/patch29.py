# round 45
path = '/home/claude/w3/ledger.html'
T = '/home/claude/w3/tools/'
t = open(path, encoding='utf8').read()
mark = '/* ---------- no zooming: pinch, double tap, ctrl+wheel, ctrl +/- ---------- */'
assert t.count(mark) == 1
t = t.replace(mark, open(T + 'round45.js', encoding='utf8').read() + '\n' + mark)
a = "rep + ' things happened</small>"
assert t.count(a) == 1, 'things happened'
t = t.replace(a, "rep + (rep === 1 ? ' thing' : ' things') + ' happened</small>")
a = "row('Premises (3 months deposit + fit-out)', nok(est.prem))"
assert t.count(a) == 1, 'premises row'
t = t.replace(a, "(est.prem ? row('Premises (3 months deposit + fit-out)', nok(est.prem)) : row('Premises', 'From home, free'))")
i = t.rindex('</style>')
t = t[:i] + open(T + 'round45.css', encoding='utf8').read() + '\n' + t[i:]
open(path, 'w', encoding='utf8').write(t)
print('patch29 ok')

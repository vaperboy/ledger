/* shrink ledger.html: remove whitespace and comments from scripts and styles only (names and logic untouched),
   so the file stays well under 2 MB; some phone viewers cut files at 2 MB, which leaves a black screen */
const fs = require('fs'), esb = require('/opt/npm-tools/node_modules/esbuild');
const f = process.argv[2] || 'ledger.html';
let h = fs.readFileSync(f, 'utf8');
const before = Buffer.byteLength(h);
h = h.replace(/<script>([\s\S]*?)<\/script>/g, (m, code) => '<script>' + esb.transformSync(code, { loader: 'js', minifyWhitespace: true, minifyIdentifiers: true, minifySyntax: true, legalComments: 'none', charset: 'utf8' }).code.trim().replace(/<\/script/gi, '<\\/script') + '</script>');
h = h.replace(/<style>([\s\S]*?)<\/style>/g, (m, css) => { try { return '<style>' + esb.transformSync(css, { loader: 'css', minifyWhitespace: true, charset: 'utf8' }).code.trim() + '</style>'; } catch (e) { return m; } });
fs.writeFileSync(f, h);
const after = Buffer.byteLength(h);
console.log('shrink: ' + before + ' -> ' + after + ' bytes');
if (after > 1900000) { console.log('SIZE WARNING: over 1.9 MB, phone viewers may cut the file'); process.exit(1); }

path='/home/claude/work/ledger.html'
t=open(path,encoding='utf8').read()
a=t.index("  const TABS = [['ov', 'Overview'], ['ops', 'Manage']")
b=t.index("  V.titles.co = 'Company';")
new = r"""  const TABS = [['ov', 'Overview'], ['cli', 'Clients'], ['mk', 'Marketing'], ['st', 'Staff'], ['more', 'More']];
  const TAB_MAP = {
    ppl: ['st', ''],
    eq: ['ops', 'assets'],
    mkt: ['mk', ''],
    doc: ['ops', 'docs'],
    ana: ['deal', 'insight'],
    set: ['ops', 'assets'],
    mon: ['fin', '']
  };
  const SUB_TAB = { people: 'st', marketing: 'mk', prices: 'cli' };
  function tabOrder(co, bd) {
    return bd.fam === 'club' ? ['ov', 'st', 'more'] : ['ov', 'cli', 'mk', 'st', 'more'];
  }
  function tabOf(t) {
    return t === 'ops' || t === 'fin' || t === 'deal' ? 'more' : t;
  }
  function icoTabs(cur, co, bd) {
    const c = tabOf(cur);
    return '<div class="ptabs">' + tabOrder(co, bd).map(k => {
      const it = TABS.find(x => x[0] === k);
      const lab = bd.fam === 'club' && k === 'st' ? 'Squad' : it[1];
      return '<button class="' + (k === c ? 'on' : '') + '" data-a="cotab" data-p="' + esc(JSON.stringify({ id: co.id, v: k })) + '">' + lab + '</button>';
    }).join('') + '</div>';
  }
  function lockWrap(co, bd, h, vp) {
    const locked = !!co.mgr && co.st === 'open' && bd.fam !== 'club' && !(vp && vp.f);
    if (!locked) return h;
    const n = S.npcs[co.mgr];
    const nm = n ? n.name : 'your manager';
    return '<div class="lockwrap"><div class="locked">' + h + '</div><div class="lockover"><div class="lockbox"><b>' + esc(titleFor(co, 'mgr')) + ' runs this</b><small>' + esc(nm) + ' handles the day-to-day. Ask for changes instead of doing it yourself.</small>' + btn('Contact ' + nm.split(' ')[0], 'askmgr', { id: co.id }, 'primary wide') + '</div></div></div>';
  }
  CT.cli = function (co, bd) {
    let h = opsPart(co, bd, 'prices');
    if (['svc', 'retail', 'prod'].indexOf(bd.fam) >= 0 && acctOk(co) && window.dealPart) h += '<h2 class="sec">Business customers</h2>' + window.dealPart(co, bd, 'cust');
    return h;
  };
  function rowsOf(keys, act, co, sumf, names) {
    return '<div class="lrows">' + keys.map(k => {
      const miss = k === 'docs' && docNeeds(co).some(d => d !== 'mva_na' && !docOk(co, d));
      return '<button class="lrow" data-a="' + act + '" data-p="' + esc(JSON.stringify({ id: co.id, s: k })) + '"><span class="lic">' + svg(names[k][1], 20) + '</span><span class="ctext"><b>' + names[k][0] + '</b><small>' + esc(sumf(k) || '') + '</small></span>' + (miss ? '<i class="rdot"></i>' : '<i>›</i>') + '</button>';
    }).join('') + '</div>';
  }
  CT.more = function (co, bd, vp) {
    const ops = opsKeys0(co, bd).filter(k => ['people', 'marketing', 'prices'].indexOf(k) < 0);
    let h = '';
    if (ops.length) h += '<h2 class="sec first">Run the business</h2>' + lockWrap(co, bd, rowsOf(ops, 'cosub', co, k => opsSummary(co, bd, k), OPS_SUB), vp);
    h += '<h2 class="sec">Money</h2>' + CT.fin(co, bd);
    h += '<h2 class="sec">Grow</h2>' + CT.deal(co, bd);
    return h;
  };
  V.co = function (p) {
    const co = getCo(p.id);
    if (!co) return card('This company no longer exists.');
    let t = p.t || 'ov';
    const bd = BD[co.type];
    if (TAB_MAP[t]) {
      const m = TAB_MAP[t];
      t = m[0];
      ui.view.p = p = Object.assign({}, p, { t: m[0], s: m[1], f: 1 });
    }
    if (t === 'ops' && SUB_TAB[p.s]) {
      t = SUB_TAB[p.s];
      ui.view.p = p = Object.assign({}, p, { t: t, s: '' });
    }
    if ((t === 'ops' || t === 'fin' || t === 'deal') && !p.s) t = 'more';
    if (bd.fam === 'club' && (t === 'cli' || t === 'mk')) t = 'ov';
    if (co.st === 'sold' || co.st === 'bust') return card('<h3>' + esc(co.name) + '</h3><p class="muted">' + (co.st === 'bust' ? 'This company went bankrupt.' : 'This company is sold or closed.') + '</p>');
    let body;
    if (t === 'cli') body = lockWrap(co, bd, CT.cli(co, bd), p);
    else if (t === 'mk') body = lockWrap(co, bd, opsPart(co, bd, 'marketing'), p);
    else if (t === 'st') body = lockWrap(co, bd, opsPart(co, bd, 'people'), p);
    else if (t === 'more') body = CT.more(co, bd, p);
    else body = (CT[t] || CT.ov)(co, bd);
    if (['ov', 'fin', 'deal'].indexOf(t) >= 0 && !p.s) body = '<div class="cols">' + body + '</div>';
    return icoTabs(t, co, bd) + body;
  };
  V.heads = V.heads || {};
  V.heads.co = function (p) {
    const co = getCo(p.id);
    if (!co) return {};
    const bd = BD[co.type];
    const m = co.mgr && S.npcs[co.mgr];
    return {
      t: co.name,
      sub: esc(bd.n) + ' · ' + CO[co.country].forms[co.form + 's'] + ' · ' + CO[co.country].flag + ' ' + esc(cityOf(co.city).name) + (co.franchise && co.franchise.fran ? ' · franchise' : '') + (m ? ' · run by ' + esc(m.name) : ''),
      right: '<span class="badge ' + (co.st === 'open' ? 'green' : co.st === 'closed' ? 'red' : 'amber') + '">' + ({ setup: 'Setting up', open: 'Open', closed: 'Closed' }[co.st] || '') + '</span>'
    };
  };
"""
t=t[:a]+new+t[b:]
# opsPart lives in the same closure; nothing else to export
open(path,'w',encoding='utf8').write(t)
print('co ok')

/* ===== Round 6c: mockup restyles. Pay yourself, Accounts, My office, Reports and timing, Academy,
   pictures in the Luxury app, and dated transactions. ===== */
{
  const P = o => esc(JSON.stringify(o));
  const pillp = (t, c) => '<span class="pill ' + (c || '') + '">' + t + '</span>';
  const neg = x => '<span class="neg">−' + npadL(Math.abs(x)) + '</span>';
  const sn = x => (x < 0 ? '−' : '') + npadL(Math.abs(x));
  const pcs = x => (x >= 0 ? '+' : '−') + Math.abs(Math.round(x * 100)) + '%';
  const R6FIN = window.R6FIN = window.R6FIN || {};

  /* ---------- Pay yourself ---------- */
  function availOut(co) {
    return co.form === 'AS' ? divMax(co) : Math.max(0, Math.floor(co.cash - coWeekCost(co) * 2));
  }
  V.titles.payself = 'Pay yourself';
  V.heads = V.heads || {};
  V.heads.payself = p => {
    const co = getCo(p.id);
    return { t: 'Pay yourself', sub: co ? esc(co.name) + ' · available ' + mshort(availOut(co)) : '' };
  };
  V.payself = function (p) {
    const co = getCo(p.id);
    if (!co) return '<div class="calm">Company not found.</div>';
    const c = CO[co.country] || CC(), AS = co.form === 'AS';
    const avail = availOut(co);
    const sal = AS ? (co.ownerSalary || 0) * 12 : 0;
    const out = Math.max(0, Math.min(avail, U.inum('amtOut', 0)));
    const leave = Math.max(0, avail - out);
    const tot = sal + out + leave || 1;
    const taxSal = sal ? personalTax(sal, 'wage') : 0;
    const taxOut = AS ? out * c.divTax : 0;
    const hand = sal - taxSal + out - taxOut;
    const after = co.cash - out;
    const buf = Math.round(coWeekCost(co) * 8.7);
    const salRate = sal ? taxSal / sal : 0;
    let h = '<div class="card ctr"><span class="lab">You take out</span><b class="huge">' + nok(sal + out) + '</b><span class="lab">' + (AS ? 'this year from this company: salary plus this payout' : 'from the company now') + '</span></div>';
    h += '<h2 class="sec">Split it</h2><div class="card split3">';
    if (AS) h += '<div class="bhead"><b>Salary</b><b>' + nok(sal) + '</b></div>' + bar(sal / tot * 100, 'var(--amber)') + '<span class="tipt">Taxed as income, about ' + Math.round(salRate * 100) + '% at this level. The company deducts it as a cost. Now ' + money(co.ownerSalary || 0) + ' a month.</span>' + chips([0, 20000, 40000, 60000, 80000].map(v => [v, v ? mshort(v) : 'None']), co.ownerSalary, 'cosal', { id: co.id });
    h += '<div class="bhead"><b>' + (AS ? 'Dividend' : 'Take out') + '</b><b>' + nok(out) + '</b></div>' + bar(out / tot * 100, 'var(--blue)') + '<span class="tipt">' + (AS ? 'The company pays ' + pc(c.corp, 0) + ' tax on profit first, then you pay ' + pc(c.divTax, 1) + ' dividend tax. Up to ' + nok(avail) + ' can be paid now, keeping two weeks of costs.' : 'As a sole proprietor the profit is your income whether you take it out or not. Taking it out adds no extra tax.') + '</span>' + U.inp('amtOut', 'Amount', null) + U.pctChips('amtOut', avail) + '<div class="chips">' + (AS ? btn('Pay dividend', 'cdiv', { id: co.id }, 'chip primary') : btn('Take out', 'cdraw', { id: co.id }, 'chip primary')) + '</div>';
    h += '<div class="bhead"><b>Leave in the company</b><b>' + nok(leave) + '</b></div>' + bar(leave / tot * 100, 'var(--green)') + '<span class="tipt">No extra tax now. Pays for equipment, a deposit, or a rainy day.</span></div>';
    h += '<h2 class="sec">What you end up with</h2><div class="tri"><div><span>Tax</span><b class="neg">' + (AS ? '−' + mshort(taxSal + taxOut) : 'On profit') + '</b></div><div><span>In your hand</span><b class="pos">' + mshort(AS ? hand : out) + '</b></div><div><span>Company cash after</span><b class="' + sgn(after) + '">' + mshort(after) + '</b></div></div>';
    h += '<div class="card sense"><b>Watch the buffer</b><span class="tipt">The company needs about two months of costs in cash (' + nok(buf) + '). ' + (after < buf ? 'Taking this much leaves it exposed. A late client could stop wages.' : 'You are keeping enough.') + '</span></div>';
    const loans = S.loans.filter(l => l.co === co.id);
    const hold = S.cos.some(x => x.type === 'hold' && x.st === 'open');
    h += '<h2 class="sec">Other ways to use profit</h2><div class="lrows">' +
      (loans.length ? '<button class="lrow" data-a="cofin" data-p="' + P({ id: co.id, s: 'loans' }) + '"><span class="ctext"><b>Pay down the loan</b><small>' + nok(loans.reduce((t, l) => t + l.bal, 0)) + ' left</small></span><b class="pos">Saves ' + pc(loanRate(loans[0]), 1) + '</b><i>›</i></button>' : '') +
      '<button class="lrow" data-a="go" data-p="' + P({ n: 'hq', p: { t: 'group' } }) + '"><span class="ctext"><b>Send to your holding</b><small>' + (hold ? 'Dividends between your companies' : 'Set up a holding company first') + '</small></span><b class="' + (hold ? 'pos' : 'muted') + '">' + (hold ? 'Almost tax-free' : 'Not set up') + '</b><i>›</i></button>' +
      '<button class="lrow" data-a="cosub" data-p="' + P({ id: co.id, s: 'assets' }) + '"><span class="ctext"><b>Buy equipment or a van</b><small>Shows as depreciation over the years</small></span><b>Lowers tax</b><i>›</i></button></div>';
    h += '<h2 class="sec">Put money in</h2><div class="card"><span class="tipt">From your own account (' + nok(Math.max(0, liquid())) + ' available).</span>' + U.inp('amtIn', 'Amount', null) + U.pctChips('amtIn', liquid()) + '<div class="chips">' + btn('Put money in', 'cinject', { id: co.id }, 'chip primary') + '</div></div>';
    return h;
  };
  document.addEventListener('change', e => {
    const k = e.target && e.target.getAttribute && e.target.getAttribute('data-k');
    if ((k === 'amtOut' || k === 'amtIn') && ui.view && ui.view.n === 'payself') render();
  });
  R6FIN.owner = (co, bd) => {
    const avail = availOut(co);
    return '<div class="lrows"><button class="lrow" data-a="go" data-p="' + P({ n: 'payself', p: { id: co.id } }) + '"><span class="lic">' + svg('coin', 20) + '</span><span class="ctext"><b>Pay yourself</b><small>' + (co.form === 'AS' ? 'Salary ' + mshort(co.ownerSalary || 0) + '/mo · dividend up to ' + mshort(avail) : 'Take out up to ' + mshort(avail)) + ' · put money in</small></span><i>›</i></button></div>';
  };

  /* ---------- Accounts ---------- */
  const PL = [['cogs', 'Materials and goods'], ['wages', 'Wages and charges'], ['rent', 'Rent and premises'], ['mkt', 'Marketing'], ['ins', 'Insurance'], ['acc', 'Accounting'], ['dep', 'Depreciation of equipment'], ['int', 'Interest'], ['oth', 'Other costs'], ['fine', 'Fines'], ['loss', 'Losses and write-offs']];
  function compare(co) {
    const y = co.bk.y || {}, ly = co.bk.ly || {};
    if ((ly.rev || 0) > 0) {
      let w0 = S.week;
      while (w0 > 0 && wYear(w0 - 1) === wYear(S.week)) w0--;
      const f = Math.max(1, S.week - w0 + 1) / 52;
      return { lab: 'Compared with last year', r: (y.rev || 0) / (ly.rev * f) - 1, c: sumExp(y) / Math.max(1, sumExp(ly) * f) - 1 };
    }
    const hst = co.hist || [];
    if (hst.length >= 8) {
      const n = Math.min(13, Math.floor(hst.length / 2)), a = hst.slice(-n), b = hst.slice(-2 * n, -n);
      const ra = a.reduce((t, x) => t + (x.rev || 0), 0), rb = b.reduce((t, x) => t + (x.rev || 0), 0);
      const ca = a.reduce((t, x) => t + (x.rev || 0) - (x.profit || 0), 0), cb = b.reduce((t, x) => t + (x.rev || 0) - (x.profit || 0), 0);
      return { lab: 'Compared with the ' + n + ' weeks before', r: rb > 0 ? ra / rb - 1 : 0, c: cb > 0 ? ca / cb - 1 : 0 };
    }
    return null;
  }
  function accSays(co) {
    const out = [];
    const cm = compare(co), y = co.bk.y || {}, ly = co.bk.ly || {};
    if (cm && cm.c > cm.r + 0.05) out.push('Costs grew faster than sales (' + pcs(cm.c) + ' against ' + pcs(cm.r) + ').');
    if ((y.wages || 0) > (y.rev || 0) * 0.6 && (y.rev || 0) > 0) out.push('Wages take ' + Math.round(y.wages / y.rev * 100) + '% of revenue, which is high.');
    let worn = 0;
    for (const id in co.eq) ((co.units || {})[id] || []).forEach(u => { if (window.R6 && R6.seen(u) < 0.5) worn++; });
    co.veh.forEach(v => { if (window.R6 && R6.seen(v) < 0.5) worn++; });
    if (worn) out.push('Equipment is aging: ' + worn + (worn > 1 ? ' items look' : ' item looks') + ' worn and will need replacing within 18 months.');
    const recv = co.recv.reduce((t, r) => t + r.a, 0);
    if (recv > (y.rev || 0) / Math.max(1, (S.week % 52) || 1) * 8 && recv > KC(20000, co.country)) out.push('Customers owe you ' + mshort(recv) + '. Chase the slow payers.');
    if (co.cash < coWeekCost(co) * 4) out.push('Cash is thin, under a month of costs.');
    if (co.form === 'AS' && !co.acc) out.push('A limited company must have its accounts prepared. Pick an accountant under Accountant and legal form.');
    if (!out.length) out.push('The books look healthy. Nothing unusual this period.');
    return out.join(' ');
  }
  function dueWeeks(co) {
    let w = S.week + 1;
    while (w < S.week + 60 && !(wMonth(w) === 6 && wDate(w).getUTCDate() >= 24)) w++;
    return w - S.week;
  }
  R6FIN.books = (co, bd) => {
    const t = ui.acct || 'pl', b = ui.books || 'y', bk = co.bk[b] || {};
    const AS = co.form === 'AS', corp = (CO[co.country] || CC()).corp;
    const st = co.acc || !AS ? ['Up to date', 'grn'] : ['No accountant', 'red'];
    let h = '<div class="card"><div class="cchd"><span class="lic">' + svg('book', 20) + '</span><span class="ctext"><b>Accounts</b><small>Prepared by ' + esc(co.acc ? co.acc.name : AS ? 'nobody yet' : 'you, with bookkeeping software') + '</small></span>' + pillp(st[0], st[1]) + '</div></div>';
    h += '<div class="ptabs">' + [['pl', 'P&amp;L'], ['bal', 'Balance'], ['cf', 'Cash flow'], ['tax', 'Tax']].map(x => '<button class="' + (t === x[0] ? 'on' : '') + '" data-a="acct" data-p="' + P(x[0]) + '">' + x[1] + '</button>').join('') + '</div>';
    const per = { w: 'This week', m: 'This month', y: 'This year so far', ly: 'Last year' };
    const perChips = chips([['w', 'Week'], ['m', 'Month'], ['y', 'Year'], ['ly', 'Last year']], b, 'books', { id: co.id });
    if (t === 'pl') {
      const rev = bk.rev || 0, prof = rev - sumExp(bk);
      h += perChips + '<h2 class="sec">Profit and loss · ' + per[b].toLowerCase() + '</h2><div class="card">' + row('Revenue', '<b>' + npadL(rev) + '</b>') + PL.filter(l => bk[l[0]]).map(l => row(l[1], neg(bk[l[0]]))).join('') + row('Profit before tax', '<span class="' + sgn(prof) + '">' + sn(prof) + '</span>', 'total') + (AS ? row('Corporate tax, ' + pc(corp, 0), bk.tax ? neg(bk.tax) : '–') + row('Profit after tax', '<span class="' + sgn(prof - (bk.tax || 0)) + '">' + sn(prof - (bk.tax || 0)) + '</span>', 'total') : '') + '</div>';
      const cm = compare(co);
      const y = co.bk.y || {};
      if (cm) h += '<h2 class="sec">' + cm.lab + '</h2><div class="tri"><div><span>Revenue</span><b class="' + (cm.r >= 0 ? 'pos' : 'neg') + '">' + pcs(cm.r) + '</b></div><div><span>Costs</span><b class="' + (cm.c > cm.r ? 'amb' : '') + '">' + pcs(cm.c) + '</b></div><div><span>Margin</span><b>' + ((y.rev || 0) > 0 ? Math.round(((y.rev || 0) - sumExp(y)) / y.rev * 100) + '%' : '–') + '</b></div></div>';
      h += '<div class="card sense"><b>' + (co.acc ? 'Your accountant says' : 'What the numbers say') + '</b><span class="tipt">' + esc(accSays(co)) + '</span></div>';
      const dw = dueWeeks(co);
      h += '<div class="card"><div class="bhead"><b>' + (AS ? 'Annual accounts' : 'Tax return') + '</b>' + pillp('Due in ' + dw + ' weeks', dw <= 8 ? 'amb' : '') + '</div><span class="tipt">Late filing triggers a fine. A better accountant also finds tax savings.</span></div>';
    } else if (t === 'bal') {
      const recv = co.recv.reduce((x, r) => x + r.a, 0), eq = companyAssets(co) - companyDebts(co);
      h += '<div class="card">' + row('Cash', nok(co.cash)) + row('Customers owe', nok(recv)) + row('Stock', nok(co.inv)) + row('Equipment and vehicles', nok(eqBook(co))) + (co.prem && co.prem.owned ? row('Property', nok(co.prem.val)) : '') + (co.props && co.props.length ? row('Rental properties', nok(co.props.reduce((x, p) => x + p.val, 0))) : '') + (co.fm && co.fm.assets ? row('Other assets', nok(co.fm.assets)) : '') + row('Debts and accruals', '<span class="neg">' + nok(companyDebts(co)) + '</span>') + row('Equity', '<span class="' + sgn(eq) + '">' + nok(eq) + '</span>', 'total') + '</div>';
      if (BD[co.type].b2b > 0) h += '<div class="card"><div class="bhead"><b>Credit checks on customers</b>' + pillp(co.flags.ccheck ? 'On' : 'Off', co.flags.ccheck ? 'grn' : '') + '</div><span class="tipt">Costs about 0.4% of invoices and cuts unpaid invoices a lot.</span><div class="chips">' + btn(co.flags.ccheck ? 'Stop credit checks' : 'Check customers before invoicing', 'ccheck', { id: co.id }, 'chip') + '</div></div>';
    } else if (t === 'cf') {
      const rev = bk.rev || 0, cost = sumExp(bk) - (bk.dep || 0);
      const recv = co.recv.reduce((x, r) => x + r.a, 0), pay = co.pay.wages + co.pay.other + co.pay.rent + co.pay.tax;
      h += perChips + '<h2 class="sec">Cash flow · ' + per[b].toLowerCase() + '</h2><div class="card">' + row('Sales', npadL(rev)) + row('Costs paid (not depreciation)', neg(cost)) + row('Net from running the business', '<span class="' + sgn(rev - cost) + '">' + sn(rev - cost) + '</span>', 'total') + '</div><div class="tri"><div><span>Owed to you</span><b>' + mshort(recv) + '</b></div><div><span>Bills to pay</span><b>' + mshort(pay + Math.max(0, co.vatAcc)) + '</b></div><div><span>Cash now</span><b class="' + sgn(co.cash) + '">' + mshort(co.cash) + '</b></div></div>';
    } else {
      h += '<div class="card">' + (AS ? row('Corporate tax rate', pc(corp, 0)) + row('Tax to pay (accrued)', nok(co.pay.tax)) + (co.lossCarry > 0 ? row('Tax loss carried forward', nok(co.lossCarry)) : '') : row('Taxed as', 'Your personal income')) + row('VAT to settle', nok(co.vatAcc)) + row('Payroll taxes', 'Included in wages') + '</div>' + btn('Open the Tax Office', 'phapp', { n: 'tax' }, 'wide');
    }
    return h;
  };
  ACT.acct = p => { ui.acct = p; render(); };
  R6FIN.tx = co => '<div class="lrows">' + (co.tx.length ? co.tx.slice(0, 20).map(t => '<div class="lrow"><span class="ctext"><b>' + esc(t.l) + '</b><small>' + dateStr(t.w) + '</small></span><b class="num ' + sgn(t.a) + '">' + (t.a > 0 ? '+' : '−') + npadL(Math.abs(t.a)) + '</b></div>').join('') : '<div class="lrow"><small>Nothing yet.</small></div>') + '</div>';

  /* ---------- My office ---------- */
  function topBlocks(h) {
    const out = [];
    let i = 0;
    while (i < h.length) {
      const m = /^<([a-z0-9]+)/i.exec(h.slice(i, i + 20));
      if (!m) {
        const j = h.indexOf('<', i + 1);
        out.push(h.slice(i, j < 0 ? h.length : j));
        i = j < 0 ? h.length : j;
        continue;
      }
      const re = new RegExp('<(/?)' + m[1] + '\\b[^>]*>', 'gi');
      re.lastIndex = i;
      let d = 0, j = -1, mm;
      while ((mm = re.exec(h))) {
        d += mm[1] ? -1 : 1;
        if (d === 0) { j = re.lastIndex; break; }
      }
      if (j < 0) { out.push(h.slice(i)); break; }
      out.push(h.slice(i, j));
      i = j;
    }
    return out;
  }
  const office0 = V.office;
  V.office = function () {
    const o = S.office, t = o ? officeTier() : null;
    const blocks = topBlocks(office0()).filter((b, i) => i > 0 && b.indexOf('Reports to you') < 0 && b.indexOf('<b>Move office</b>') < 0 && b.indexOf('<h3>Offices</h3>') < 0).map(b => b.replace('<h2 class="sec">HQ staff</h2>', '<h2 class="sec">Who sits here</h2>'));
    let h = '';
    if (o) {
      const idx = OFFICE_T.findIndex(x => x.id === t.id), nx = OFFICE_T[idx + 1];
      const used = deskUse(), desks = staffDesks(t);
      h += '<button class="card opt2" data-a="officepop"><div class="cchd">' + pic(t.id === 'home' ? 'house' : 'building', t.id + ':' + o.city) + '<span class="ctext"><b>' + esc(t.n) + ', ' + esc(cityOf(o.city || S.player.city).name) + '</b><small>' + esc(t.note) + '</small></span>' + pillp(t.rentM ? mshort(officeRent(t, o.city)) + '/mo' : 'Free') + '</div>' + (nx ? row('Next size up', esc(nx.n) + ' · ' + mshort(officeRent(nx, o.city || S.player.city)) + '/mo · ' + nx.desks + ' desks') : '') + '<span class="chg">Tap to change office ›</span></button>';
      h += '<h2 class="sec">Floor plan</h2><div class="fplan"><div><span>Desks</span><b>' + used + ' of ' + desks + ' used</b></div><div><span>Meeting rooms</span><b>' + (t.rooms || 'None') + '</b></div><div><span>Your office</span><b>' + (t.id === 'home' ? 'Kitchen table' : t.id === 'cow' ? 'Hot desk' : 'Corner office') + '</b></div><div><span>Free desks</span><b class="' + (desks - used > 0 ? 'pos' : 'amb') + '">' + Math.max(0, desks - used) + '</b></div></div>';
    } else h += '<button class="card opt2" data-a="officepop"><div class="cchd">' + pic('house', 'none') + '<span class="ctext"><b>No office</b><small>You work from your phone and kitchen table. An office gives desks for HQ staff and group managers, and meeting rooms.</small></span></div><span class="chg">Tap to choose an office ›</span></button>';
    const rs = repSettings();
    h += '<div class="lrows"><button class="lrow" data-a="go" data-p="' + P({ n: 'reports' }) + '"><span class="lic">' + svg('doc', 20) + '</span><span class="ctext"><b>Reports and timing</b><small>Board packs ' + ({ 4: 'monthly', 13: 'quarterly', 52: 'yearly' }[rs.freq] || 'monthly') + ' · ' + (rs.detail === 'full' ? 'full' : 'short') + '</small></span><i>›</i></button><button class="lrow" data-a="go" data-p="' + P({ n: 'academy' }) + '"><span class="lic">' + svg('grad', 20) + '</span><span class="ctext"><b>Academy</b><small>Courses for your people</small></span><i>›</i></button></div>';
    return h + blocks.join('');
  };

  /* ---------- Reports and timing ---------- */
  const pdd = (items, cur, act, p0, cls) => {
    const c = items.find(it => it[0] === cur) || items[0];
    return '<button class="pill ' + (cls || 'blue') + '" data-a="ddopen" data-p="' + P({ items, cur, act, p0 }) + '">' + c[1] + ' ▾</button>';
  };
  V.titles.reports = 'Reports and timing';
  V.heads.reports = () => ({ t: 'Reports and timing', sub: 'What reaches you, and when' });
  V.reports = function () {
    const rs = repSettings();
    const cos = S.cos.filter(c => c.st !== 'sold' && c.st !== 'bust');
    let h = '<div class="card sense"><span class="tipt">More reports mean you see problems sooner but spend more time reading them. Fewer reports are quieter, but you may notice trouble late.</span></div>';
    h += '<h2 class="sec">Reports</h2><div class="lrows">' +
      '<div class="lrow"><span class="ctext"><b>Week report</b><small>Cash and results, all companies</small></span>' + pillp('Weekly', 'blue') + '</div>' +
      '<div class="lrow"><span class="ctext"><b>Board pack</b><small>Profit and loss from companies with a manager</small></span>' + pdd([[4, 'Monthly'], [13, 'Quarterly'], [52, 'Yearly']], rs.freq, 'repset', { k: 'freq' }) + '</div>' +
      '<div class="lrow"><span class="ctext"><b>How much detail</b><small>Short summary or the full pack</small></span>' + pdd([['short', 'Short'], ['full', 'Full']], rs.detail, 'repset', { k: 'detail' }) + '</div>' +
      '<div class="lrow"><span class="ctext"><b>Which companies</b><small>Who sends a board pack</small></span>' + pdd([['all', 'All'], ['managed', 'Managed only'], ['big', 'Big ones only']], rs.only, 'repset', { k: 'only' }) + '</div>' +
      '<div class="lrow"><span class="ctext"><b>Risk and legal</b><small>Lawsuits, audits, licences</small></span>' + pillp('When it happens', 'amb') + '</div>' +
      (hasHQ('fin') ? '<div class="lrow"><span class="ctext"><b>Investments</b><small>From your finance manager</small></span>' + pillp('Monthly', 'blue') + '</div>' : '') +
      (hasHQ('ana') ? '<div class="lrow"><span class="ctext"><b>Analyst report</b><small>Forecasts on request</small></span>' + pillp('When asked') + '</div>' : '') + '</div>';
    h += '<h2 class="sec">How it reaches you</h2><div class="card">' + row('Board packs', 'In Meetings · Messages') + row('Urgent alerts', hasHQ('pa') ? 'Always, through your assistant' : 'Straight to Meetings') + row('Decisions', hasHQ('pa') ? 'Your assistant gives one extra week' : 'Due by the deadline') + '<span class="tipt">' + (hasHQ('pa') ? 'Your assistant filters small things so you see what matters.' : 'A personal assistant in your office can filter small things and buy you time on decisions.') + '</span></div>';
    h += '<h2 class="sec">Who prepares them</h2><div class="lrows">' + (cos.length ? cos.map(co => '<div class="lrow"><span class="ctext"><b>' + esc(co.name) + '</b><small>' + (co.mgr && S.npcs[co.mgr] ? 'Manager: ' + esc(S.npcs[co.mgr].name) : 'You') + '</small></span><b>' + esc(co.acc ? co.acc.name : co.form === 'AS' ? 'No accountant' : 'Bookkeeping app') + '</b></div>').join('') : '<div class="lrow"><small>No companies yet.</small></div>') + '</div>';
    return h;
  };

  /* ---------- Academy ---------- */
  V.titles.academy = 'Academy';
  V.heads.academy = () => ({ t: 'Academy', sub: 'Courses for the people in your companies' });
  const tenure = s => { const w = S.week - (s.w0 || S.week); return w >= 52 ? Math.floor(w / 52) + ' yr' : Math.max(1, Math.round(w / 4.3)) + ' mo'; };
  function fitTag(s, n) {
    const sk = staffSkill(s);
    if (sk >= 80) return ['Little to gain', 'red'];
    if (s.flag === 'lazy' || s.flag === 'conflict' || s.flag === 'late') return ['Might ignore it', 'amb'];
    if (sk < 60 || (n && n.age < 26)) return ['Good fit', 'grn'];
    return ['Some gain', ''];
  }
  V.academy = function () {
    const cos = S.cos.filter(c => c.st !== 'sold' && c.st !== 'bust' && BD[c.type] && BD[c.type].crs && BD[c.type].crs.length);
    if (!cos.length) return '<div class="calm">Courses open up when you run a company.</div>';
    const A = ui.acad = ui.acad || {};
    let co = cos.find(c => c.id === A.co) || cos[0];
    A.co = co.id;
    const bd = BD[co.type];
    let h = cos.length > 1 ? (cos.length > 3 ? U.ddown(cos.map(c => [c.id, esc(c.name)]), co.id, 'acadco') : '<div class="ptabs">' + cos.map(c => '<button class="' + (c.id === co.id ? 'on' : '') + '" data-a="acadco" data-p="' + P({ v: c.id }) + '">' + esc(c.name) + '</button>').join('') + '</div>') : '';
    h += '<p class="muted small">Each business has its own courses. A good one lifts a worker\'s skill. A bad fit can do nothing and the money is gone.</p>';
    const c = bd.crs.find(x => x[0] === A.c) || bd.crs[0];
    A.c = c[0];
    h += bd.crs.map(x => '<button class="card opt2' + (x[0] === c[0] ? ' on' : '') + '" data-a="acadc" data-p="' + P({ v: x[0] }) + '"><div class="cchd"><span class="lic">' + svg('grad', 20) + '</span><span class="ctext"><b>' + esc(x[1]) + '</b><small>' + x[3] + (x[3] > 1 ? ' days' : ' day') + ' · ' + money(x[2]) + ' per person</small></span></div><div class="kv"><span>Typical gain</span><b class="pos">+ up to ' + x[4] + ' skill</b></div><div class="kv"><span>Chance it sticks</span><b class="amb">About 65%</b></div></button>').join('');
    const people = co.staff.map(s => ({ id: s.id, s, n: S.npcs[s.id] })).filter(x => x.n);
    const ow = !co.mgr;
    h += '<h2 class="sec">Send who?</h2><div class="lrows">' + (ow ? '<button class="lrow" data-a="acads" data-p="' + P({ v: 'owner' }) + '"><span class="av">' + esc((S.player.name || 'You').split(' ').map(w => w[0]).join('').slice(0, 2)) + '</span><span class="ctext"><b>You</b><small>Owner · skill ' + Math.round(co.oskill) + '</small></span>' + pillp(co.oskill >= 80 ? 'Little to gain' : 'Good fit', co.oskill >= 80 ? 'red' : 'grn') + '<span class="radio' + (A.s === 'owner' ? ' on' : '') + '"></span></button>' : '') +
      people.map(x => { const tg = fitTag(x.s, x.n); return '<button class="lrow" data-a="acads" data-p="' + P({ v: x.id }) + '">' + faceAv(x.n) + '<span class="ctext"><b>' + esc(x.n.name) + '</b><small>' + tenure(x.s) + ' · ' + esc(ROLES[x.s.role] ? ROLES[x.s.role][0] : '') + '</small></span>' + pillp(tg[0], tg[1]) + '<span class="radio' + (String(A.s) === String(x.id) ? ' on' : '') + '"></span></button>'; }).join('') + (!ow && !people.length ? '<div class="lrow"><small>No staff yet.</small></div>' : '') + '</div>';
    const who = A.s === 'owner' ? { name: 'yourself' } : people.find(x => String(x.id) === String(A.s));
    h += '<div class="card sense"><div class="bhead"><span>Total</span><b>' + money(c[2]) + '</b></div><span class="tipt">' + (who ? (A.s === 'owner' ? 'You are' : esc(who.n.name.split(' ')[0]) + ' is') + ' away for ' + c[3] + (c[3] > 1 ? ' days' : ' day') + ', so about ' + Math.round(c[3] * 7.5) + ' working hours are lost.' : 'Pick who to send.') + '</span></div>';
    if (who) h += btn('Send ' + (A.s === 'owner' ? 'yourself' : esc(who.n.name.split(' ')[0])) + ' · ' + mshort(c[2]), 'docourse', { id: co.id, s: A.s === 'owner' ? 'owner' : who.id, c: c[0] }, 'primary wide go');
    return h;
  };
  ACT.acadco = p => { ui.acad = { co: p.v }; render(); };
  ACT.acadc = p => { ui.acad.c = p.v; render(); };
  ACT.acads = p => { ui.acad.s = p.v; render(); };
  APP.academy = ['grad', 'Academy', 'b', ['go', { n: 'academy' }]];
  FOLD.business.apps.push('academy');

  /* ---------- Luxury: pictures, and art you can look at ---------- */
  const LUXP = {
    c1: ['car', { lux: 1, ev: 1, c: '#c9cdd2' }], c2: ['car', { lux: 1, c: '#8e1f24' }], c3: ['car', { lux: 1, c: '#0f3b3a' }], c4: ['car', { lux: 1, c: '#d9a441' }], c5: ['car', { lux: 1, c: '#2b2f36' }],
    w1: ['watch'], w2: ['watch'], w3: ['jewel'], w4: ['watch'],
    a1: ['art', { style: 'land', frame: 'gold' }], a2: ['comic'], a3: ['wine'], a4: ['art', { style: 'geo', frame: 'black', mat: 7 }], a5: ['art', { style: 'fields', frame: 'gold' }],
    y1: ['yacht'], y2: ['yacht'], y3: ['yacht'], j1: ['jet'], j2: ['jet'], j3: ['jet']
  };
  const luxThumb = (k, id) => {
    const d = LUXP[k] || ['box'];
    if (d[0] === 'art') {
      const it = LUXI[k] || {};
      return id ? artThumb(k, d[1], 'artview', { seed: k, opt: d[1], t: it.n, sub: it.d, cap: 'Tap outside or Close to return.' }) : '<span class="pic art">' + artSvg(k, d[1]) + '</span>';
    }
    return pic(d[0], k, d[1] || {});
  };
  const unq = s => JSON.parse(s.replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&'));
  const lux0 = V.lux;
  V.lux = function () {
    let h = lux0();
    h = h.replace(/(<button class="lrow" data-a="luxbuy" data-p="([^"]+)">)/g, (m, a, p) => { try { return a + luxThumb(unq(p).k); } catch (e) { return a; } });
    h = h.replace(/<div class="lrow"><span class="lic">[\s\S]*?<\/svg><\/span>(<span class="ctext">[\s\S]*?data-a="luxsell" data-p="([^"]+)")/g, (m, rest, p) => {
      try { const x = (S.lux || []).find(y => y.id === unq(p).id); return '<div class="lrow">' + (x ? luxThumb(x.k, x.id) : '') + rest; } catch (e) { return m; }
    });
    return h;
  };
  const lb0 = ACT.luxbuy;
  ACT.luxbuy = p => {
    lb0(p);
    const d = LUXP[p.k];
    if (ui.sheet && d) {
      ui.sheet.html = ui.sheet.html.replace('</h2>', '</h2>' + (d[0] === 'art' ? '<div class="artbig">' + artSvg(p.k, d[1]) + '</div>' : '<span class="pic big">' + picSvg(d[0], p.k, d[1] || {}) + '</span>'));
      render();
    }
  };
}

# round 37: newcomer, premises, one-line choices
path = '/home/claude/w3/ledger.html'
T = '/home/claude/w3/tools/'
t = open(path, encoding='utf8').read()
mark = '/* ===== Round 32: PC and iPad.'
assert t.count(mark) == 1, 'r32 mark'
t = t.replace(mark, open(T + 'round37.js', encoding='utf8').read() + '\n' + mark)
i = t.rindex('</style>')
t = t[:i] + open(T + 'round37.css', encoding='utf8').read() + '\n' + t[i:]
a = "    if (items.length > 5 || items.reduce((n, it) => n + String(it[1]).replace(/<[^>]*>/g, '').length, 0) > 46) return ddown(items, cur, act, p0);"
assert t.count(a) == 1, 'chips'
t = t.replace(a, "    /* round 37: money labels without empty decimals, and a row of choices must fit on one line or it becomes a list */\n    items = items.map(it => [it[0], typeof it[1] === 'string' ? it[1].replace(/(\\d)\\.0+ (?=[kMB])/g, '$1 ') : it[1]]);\n    if (items.length > 5 || items.reduce((n, it) => n + String(it[1]).replace(/<[^>]*>/g, '').length * 7.4 + 26, 0) > 330) return ddown(items, cur, act, p0);")
open(path, 'w', encoding='utf8').write(t)
print('patch24 ok')

/* ===== Round 7a: your own hours, closing a company, the Clients tab, complaints, assistant managers,
   chat-style interviews, network limits, rounded money, executive hiring fix. ===== */
{
  const P = o => esc(JSON.stringify(o));
  const pillp = (t, c) => '<span class="pill ' + (c || '') + '">' + t + '</span>';
  const NOWORK = { rent: 1, fin: 1, energy: 1, club: 1, hold: 1 };
  const R7 = window.R7 = window.R7 || {};

  /* ---------- rounded money: amounts fit the local market and end on round numbers ---------- */
  window.niceAmt = function (v) {
    if (!v) return v;
    const f = fxr(CC());
    const loc = KC(v) / f;
    const p = Math.pow(10, Math.floor(Math.log10(loc)));
    const m = loc / p;
    const n = m < 1.5 ? 1 : m < 3.5 ? 2 : m < 7.5 ? 5 : 10;
    return Math.round(n * p * f);
  };
  const snap = (v, list) => list.reduce((b, x) => Math.abs(Math.log((x || 1) / (v || 1))) < Math.abs(Math.log((b || 1) / (v || 1))) ? x : b, list[0]);
  const grp0 = V.group;
  V.group = function () {
    const G = S.group;
    if (G) {
      G.big = snap(G.big, [1000000, 5000000, 20000000, 100000000].map(niceAmt));
      if (G.ceo) G.ceo.buy = snap(G.ceo.buy, [100000, 500000, 2000000, 10000000].map(niceAmt));
      (G.regional || []).forEach(r => { r.buy = snap(r.buy, [50000, 250000, 1000000].map(niceAmt)); });
    }
    return grp0.apply(this, arguments);
  };

  /* ---------- executive hiring: stay inside the Office tab ---------- */
  const exh0 = ACT.exechirego;
  ACT.exechirego = p => {
    exh0(p);
    if (ui.view && ui.view.n === 'group') {
      ui.stack = [];
      ui.tab = 'hq';
      ui.hqt = 'group';
      ui.view = { n: 'hq', p: { t: 'group' } };
      render(true);
    }
  };

  /* ---------- your hours: one person, 80 hours a week at most ---------- */
  const HCAP = 80;
  const devH = () => (S.founded || []).filter(f => f.st === 'live' && f.sw && f.sw.selfH).reduce((t, f) => t + f.sw.selfH, 0);
  function hoursUsed(except) {
    return S.cos.filter(c => c !== except && c.st !== 'sold' && c.st !== 'bust' && !c.mgr && c.type !== 'hold').reduce((t, c) => t + (c.ohrs || 0), 0) + devH();
  }
  window.hoursUsed = hoursUsed;
  R7.HCAP = HCAP;
  function ownerFactor() {
    if (!S) return 1;
    if (S.burnUntil && S.week < S.burnUntil) return 0.15;
    if (S.sickW === S.week) return 0;
    const t = hoursUsed();
    return t <= 55 ? 1 : Math.max(0.6, 1 - (t - 55) * 0.012);
  }
  R7.ownerFactor = ownerFactor;
  const capP = window.capacity;
  window.capacity = function (co, bd) {
    const f = ownerFactor();
    if (f === 1 || co.mgr || !co.ohrs) return capP.apply(this, arguments);
    const h0 = co.ohrs;
    co.ohrs = h0 * f;
    try { return capP.apply(this, arguments); } finally { co.ohrs = h0; }
  };
  const fatWord = () => { const f = S.fat || 0; return S.burnUntil && S.week < S.burnUntil ? ['Burned out', 'red'] : f >= 70 ? ['Exhausted', 'red'] : f >= 40 ? ['Tired', 'amb'] : ['Rested', 'grn']; };
  window.ownerHoursRow = function (co) {
    if (co.mgr) return '';
    const used = hoursUsed(co), left = HCAP - used, fw = fatWord();
    return '<div class="card"><div class="bhead"><b>Your hours here</b>' + pillp(fw[0], fw[1]) + '</div>' + '<div class="chips hrs">' + [0, 10, 20, 30, 40, 50, 60].map(v => '<button class="btn chip' + (co.ohrs === v ? ' primary' : '') + (v > left ? ' dim' : '') + '" data-a="ownhrs" data-p="' + P({ id: co.id, v }) + '">' + v + ' h</button>').join('') + '</div>' + '<span class="tipt">You work ' + (used + (co.ohrs || 0)) + ' of at most ' + HCAP + ' hours a week across everything you run. Above 55 hours you work less well, get tired and can get sick or burn out. At 0 hours with no staff, the company closes.</span></div>';
  };
  const own0 = ACT.ownhrs;
  ACT.ownhrs = p => {
    const co = getCo(p.id);
    if (!co) return;
    const left = HCAP - hoursUsed(co);
    if (p.v > left) {
      toast('You have ' + Math.max(0, left) + ' h left. You already work ' + hoursUsed(co) + ' h elsewhere, and ' + HCAP + ' h is the most one person can do.', true);
      if (left <= 0) return;
      p = Object.assign({}, p, { v: Math.max(0, Math.floor(left / 5) * 5) });
    }
    own0(p);
    wake(co);
  };
  function wake(co) {
    if (co && co.st === 'closed' && co.idle && (co.mgr || co.ohrs > 0 || co.staff.length)) {
      co.st = 'open';
      co.idle = 0;
      co.closeW = 0;
      note(co.name + ' is open again.', 'good', co.id);
      save();
      render();
    }
  }
  R7.wake = wake;
  const sc0 = window.startCompany;
  window.startCompany = function () {
    const r = sc0.apply(this, arguments);
    if (r && typeof r === 'object' && !r.mgr) {
      const used = hoursUsed(r);
      r.ohrs = Math.max(0, Math.floor(Math.min(r.ohrs || 0, HCAP - used, Math.max(10, 55 - used)) / 5) * 5);
    }
    return r;
  };

  /* ---------- weekly: tiredness, the hour cap, idle companies ---------- */
  const nw7 = window.nextWeek;
  window.nextWeek = function () {
    try { capHours(); } catch (e) { console.error(e); }
    const r = nw7.apply(this, arguments);
    try { fatigueWeek(); } catch (e) { console.error(e); }
    return r;
  };
  function capHours() {
    let over = hoursUsed() - HCAP;
    if (over <= 0) return;
    S.cos.filter(c => !c.mgr && c.ohrs > 0 && c.st !== 'sold' && c.st !== 'bust').sort((a, b) => b.w0 - a.w0).forEach(c => {
      if (over <= 0) return;
      const cut = Math.min(c.ohrs, over);
      c.ohrs -= cut;
      over -= cut;
      note('You cannot work more than ' + HCAP + ' hours a week. Your hours at ' + c.name + ' are down to ' + c.ohrs + '.', 'bad', c.id);
    });
  }
  function fatigueWeek() {
    const t = hoursUsed();
    S.fat = clamp((S.fat || 0) + (t > 55 ? (t - 55) * 1.2 : t < 45 ? -12 : -6), 0, 100);
    if (S.burnUntil && S.week < S.burnUntil) return;
    if (t > 65 && !S.fatWarn) {
      S.fatWarn = 1;
      info('Your doctor', 'You are working ' + t + ' hours a week', 'That pace wears anyone down. Above 55 hours you make more mistakes, and you risk getting sick or burning out.', 0, 'bad');
    }
    if (t <= 55) S.fatWarn = 0;
    if (S.fat >= 100) {
      S.burnUntil = S.week + 3;
      S.fat = 45;
      info('Your doctor', 'You burned out', 'You need three weeks of rest. You can barely work until then, so companies without staff or a manager will struggle.', 0, 'bad');
    } else if (S.fat > 50 && chance((S.fat - 50) / 220)) {
      S.sickW = S.week + 1;
      info('Your doctor', 'You are sick next week', 'Too many long weeks. You will not be able to work next week.', 0, 'bad');
    }
  }

  /* ---------- running costs and closing ---------- */
  function runCosts(co) {
    const bd = BD[co.type], Pm = co.prem;
    const rent = Pm && Pm.m2 && !Pm.owned ? Pm.rent * Pm.m2 / 52 : 0;
    const wages = co.staff.reduce((t, s) => t + (s.wage || 0), 0) * 12 / 52 * (1 + CC().empNI);
    let subs = 0;
    for (const id in co.eq) if (co.eq[id].sub) subs += co.eq[id].sub.fee * 12 / 52;
    const leases = co.veh.reduce((t, v) => t + (v.mode === 'lease' ? (v.lease || 0) : 0), 0) * 12 / 52 + Object.keys(co.eqL || {}).reduce((t, k) => t + co.eqL[k], 0) / 4.33;
    const acc = co.acc ? (co.acc.fee || 0) * 12 / 52 : 0;
    const fixed = bd.fixed * Math.pow(co.size || 1, 0.6) * 0.5;
    const asst = co.asst ? co.asst.wage * 12 / 52 : 0;
    const h = (co.hist || []).slice(-4);
    const lost = h.length ? Math.max(0, h.reduce((t, x) => t + (x.profit || 0), 0) / h.length) : 0;
    return { rent, wages, subs, leases, acc, fixed, asst, lost };
  }
  R7.runCosts = runCosts;
  const wc0 = window.weekCo;
  window.weekCo = function (co) {
    const bd = BD[co.type];
    try {
      if (bd && !NOWORK[bd.fam] && co.st === 'open' && !co.mgr && !(co.ohrs > 0) && !co.staff.some(s => !(s.notice > 0))) {
        co.st = 'closed';
        co.closeW = 9999;
        co.closeTot = 9999;
        co.idle = 1;
        note(co.name + ' is closed: nobody works there. Rent, software and other running costs continue.', 'bad', co.id);
      } else if (co.st === 'closed' && co.idle && (co.mgr || co.ohrs > 0 || co.staff.length)) {
        co.st = 'open';
        co.idle = 0;
        co.closeW = 0;
      }
    } catch (e) { console.error(e); }
    const st0 = co.st;
    const r = wc0.apply(this, arguments);
    try {
      if (st0 === 'closed') {
        if (!co.subPause) for (const id in co.eq) if (co.eq[id].sub) payCo(co, co.eq[id].sub.fee * 12 / 52, 'oth');
        leaseWeek(co);
        for (const id in (co.eqL || {})) payCo(co, co.eqL[id] / 4.33, 'oth');
      }
      asstWeek(co, bd);
      complaintsWeek(co, bd);
      if (R7.afterCoWeek) R7.afterCoWeek(co, bd);
    } catch (e) { console.error(e); }
    return r;
  };
  const hco0 = V.heads.co;
  V.heads.co = function (p) {
    const r = hco0(p), co = getCo(p.id);
    if (co && (co.st === 'open' || co.st === 'closed') && co.type !== 'hold' && BD[co.type].fam !== 'club') r.right = '<button class="badge ' + (co.st === 'open' ? 'green' : 'red') + ' bbtn" data-a="closepop" data-p="' + P({ id: co.id }) + '">' + (co.st === 'open' ? 'Open' : 'Closed') + ' ▾</button>';
    return r;
  };
  function costRows(co, rc, weeks) {
    const L = [['Rent', rc.rent], ['Staff wages', rc.wages], ['Software plans', co.subPause ? 0 : rc.subs], ['Leases', rc.leases], ['Accountant', rc.acc], ['Insurance and other fixed costs', rc.fixed], ['Assistant manager', rc.asst]].filter(x => x[1] > 0);
    return L.map(x => row(x[0], mshort(x[1]) + '/wk')).join('');
  }
  function closeSheet6(co) {
    const c = ui.cl = ui.cl && ui.cl.id === co.id ? ui.cl : { id: co.id, w: 4, rent: 0, pause: 0 };
    const rc = runCosts(co);
    const hasSub = Object.keys(co.eq).some(id => co.eq[id].sub);
    const rented = co.prem && co.prem.m2 && !co.prem.owned;
    const wk = c.w >= 9999 ? 4 : c.w;
    const keep = rc.rent * (c.rent ? 0 : 1) + rc.wages * (wk <= 2 ? 1 : (2 + (wk - 2) * 0.4) / wk) + (c.pause ? 0 : rc.subs) + rc.leases + rc.acc + rc.fixed + rc.asst;
    const notice = c.rent && rented ? co.prem.rent * co.prem.m2 / 12 * 3 : 0;
    openSheet('<h2>Close ' + esc(co.name) + '?</h2><div class="lab">For how long</div>' + chips([[1, '1 week'], [2, '2 weeks'], [4, '4 weeks'], [13, '3 months'], [9999, 'Until I reopen']], c.w, 'clset', { k: 'w' }) +
      '<div class="lrows">' + (hasSub ? '<button class="lrow" data-a="clset" data-p="' + P({ k: 'pause', v: c.pause ? 0 : 1 }) + '"><span class="ctext"><b>Pause software plans</b><small>Saves ' + mshort(rc.subs) + '/wk. Data is kept.</small></span><span class="radio' + (c.pause ? ' on' : '') + '"></span></button>' : '') +
      (rented ? '<button class="lrow" data-a="clset" data-p="' + P({ k: 'rent', v: c.rent ? 0 : 1 }) + '"><span class="ctext"><b>End the premises lease</b><small>Pay 3 months notice (' + mshort(co.prem.rent * co.prem.m2 / 4) + ') and lose the place. You need new premises to reopen.</small></span><span class="radio' + (c.rent ? ' on' : '') + '"></span></button>' : '') + '</div>' +
      '<div class="card sense"><b>Still running while closed</b><span class="tipt">Staff keep full pay for two weeks, then about 40% while laid off. Equipment stays.</span>' + costRows(co, rc) + row('About ' + (c.w >= 9999 ? 'a month' : wk + (wk > 1 ? ' weeks' : ' week')), '<span class="neg">' + mshort(keep * wk + notice) + '</span>') + (rc.lost ? row('Profit you give up', '<span class="neg">' + mshort(rc.lost) + '/wk</span>') : '') + '</div>' +
      '<div class="btnrow">' + btn('Cancel', 'sheetclose', undefined, 'ghost') + btn(c.w >= 9999 ? 'Close until I reopen' : 'Close for ' + (c.w === 13 ? '3 months' : c.w + (c.w > 1 ? ' weeks' : ' week')), 'clgo', { id: co.id }, 'primary danger') + '</div>');
  }
  ACT.closepop = p => {
    const co = getCo(p.id);
    if (!co) return;
    if (co.st === 'open') return closeSheet6(co);
    const rc = runCosts(co), bd = BD[co.type];
    const needPrem = bd.prem && bd.prem[0] !== 'home' && bd.prem[0] !== 'none' && !(co.prem && co.prem.m2);
    openSheet('<h2>' + esc(co.name) + ' is closed</h2><p class="muted small">' + (co.idle ? 'Nobody works there. Set your own hours or hire staff, and it opens again.' : co.closeW >= 9000 ? 'Closed until you reopen it.' : 'Opens again in ' + co.closeW + (co.closeW > 1 ? ' weeks.' : ' week.')) + '</p><div class="card sense"><b>Running costs</b>' + costRows(co, rc) + '</div>' + (needPrem ? '<div class="note bad">It has no premises. Find a place before it can reopen.</div>' + btn('Find premises', 'premsheet', { id: co.id }, 'wide') : '') + '<div class="btnrow">' + btn('Close', 'sheetclose', undefined, 'ghost') + (needPrem || co.idle ? '' : btn('Reopen now', 'reopen', { id: co.id }, 'primary')) + '</div>');
  };
  ACT.clset = p => {
    const co = getCo(ui.cl.id);
    ui.cl[p.k] = p.v;
    closeSheet6(co);
  };
  ACT.clgo = p => {
    const co = getCo(p.id), c = ui.cl;
    if (!co || !c) return;
    if (c.rent && co.prem && co.prem.m2 && !co.prem.owned) {
      payCo(co, co.prem.rent * co.prem.m2 / 12 * 3, 'rent', 'Notice period: ' + (co.prem.lname || 'premises'));
      if (co.prem.dep) coIn(co, co.prem.dep, null, 'Lease deposit returned');
      co.prem = null;
    }
    co.st = 'closed';
    co.closeW = c.w;
    co.closeTot = c.w;
    co.subPause = c.pause ? 1 : 0;
    co.idle = 0;
    ui.cl = null;
    closeSheet();
    save();
    render();
    toast(co.name + ' is closed.');
  };
  ACT.reopen = p => {
    const co = getCo(p.id);
    co.st = 'open';
    co.closeW = 0;
    co.subPause = 0;
    co.idle = 0;
    closeSheet();
    save();
    render();
    toast(co.name + ' is open.');
  };

  /* ---------- Clients tab: price moves first, how you sell, contracts, complaints ---------- */
  const fxTxt = fx => {
    const out = [];
    if (fx.d && fx.d !== 1) out.push([fx.d > 1.12 ? 'Draws more customers' : fx.d > 1 ? 'A few more customers' : fx.d < 0.88 ? 'Fewer customers' : 'Slightly fewer customers', fx.d > 1 ? 'grn' : 'red']);
    if (fx.t && fx.t !== 1) out.push([fx.t > 1.12 ? 'Pays much better' : fx.t > 1 ? 'Pays a bit better' : fx.t < 0.88 ? 'Much cheaper' : 'A bit cheaper', fx.t > 1 ? 'grn' : 'amb']);
    if (fx.k && fx.k !== 1) out.push([fx.k > 1 ? 'Serve more people' : 'Serve fewer people', fx.k > 1 ? 'grn' : 'red']);
    if (fx.c) out.push([fx.c > 0 ? 'Higher costs' : 'Lower costs', fx.c > 0 ? 'red' : 'grn']);
    if (fx.q) out.push([fx.q > 0 ? 'Better quality' : 'Lower quality', fx.q > 0 ? 'grn' : 'red']);
    if (fx.r && fx.r !== 1) out.push([fx.r > 1 ? 'More risk' : 'Less risk', fx.r > 1 ? 'amb' : 'grn']);
    if (fx.d && fx.d !== 1) out.push(['Varies with the season', '']);
    return out;
  };
  function howYouSell(co, bd) {
    if (!bd.knobs.length) return '';
    return '<h2 class="sec">How you sell</h2>' + bd.knobs.map(k => {
      const cur = co.knob[k.id] || 0;
      return '<div class="card"><div class="bhead"><b>' + esc(k.n) + '</b><small>' + esc(k.opts[cur] ? k.opts[cur].n : '') + '</small></div>' + (k.d ? '<span class="tipt">' + esc(k.d) + '</span>' : '') + k.opts.map((o, i) => {
        const miss = knobReqMissing(co, k, i), fx = fxTxt(o.fx || {});
        return '<button class="lrow knob" data-a="setknob" data-p="' + P({ id: co.id, k: k.id, i }) + '"><span class="ctext"><b class="wrap">' + esc(o.n) + '</b>' + (o.d ? '<small class="wrap">' + esc(o.d) + '</small>' : '') + (fx.length ? '<span class="pills">' + fx.map(x => '<span class="pl ' + (x[1] === 'grn' ? 'g' : x[1] === 'red' ? 'r' : '') + '">' + x[0] + '</span>').join('') + '</span>' : '') + (miss.length ? '<small class="neg">Needs: ' + miss.map(d => esc(docDef(d)[0])).join(', ') + '</small>' : '') + '</span><span class="radio' + (cur === i ? ' on' : '') + '"></span></button>';
      }).join('') + '</div>';
    }).join('');
  }
  function priceTop(co, bd) {
    const tk = ticketEff(co, bd), rs = co.st === 'open' && bd.fam !== 'fin' && bd.fam !== 'energy' ? rivalsOf(co) : [];
    const avg = rs.length ? rs.reduce((t, r) => t + rivPrice(co, r), 0) / rs.length : 0;
    const d = avg ? tk / avg - 1 : 0;
    const pw = co.flags.pw;
    return '<button class="card opt2" data-a="go" data-p="' + P({ n: 'pricemoves', p: { id: co.id } }) + '"><div class="bhead"><b>Prices and rivals</b><span class="pill blue">Price moves ›</span></div><div class="tri"><div><span>Your price</span><b>' + mshort(tk) + '</b></div><div><span>Rivals, average</span><b>' + (avg ? mshort(avg) : '–') + '</b></div><div><span>You are</span><b class="' + (Math.abs(d) < 0.03 ? '' : d > 0 ? 'amb' : 'pos') + '">' + (avg ? (Math.abs(d) < 0.03 ? 'Level' : (d > 0 ? '+' : '−') + Math.abs(Math.round(d * 100)) + '%') : '–') + '</b></div></div><span class="tipt">Per ' + esc(bd.unit) + ' · ' + esc(PRICE_NAMES[pLvl(co) + 3]) + ' prices' + (pw ? ' · price war running' : '') + '. Change prices, start a price war and watch rivals under Price moves.</span></button>';
  }
  CT.cli = function (co, bd) {
    let h = priceTop(co, bd) + howYouSell(co, bd);
    if (['svc', 'retail', 'prod'].indexOf(bd.fam) >= 0 && acctOk(co) && window.dealPart) h += '<h2 class="sec">Clients with agreements</h2>' + window.dealPart(co, bd, 'cust');
    h += complaintsPart(co, bd);
    return h;
  };

  /* complaints */
  const CTX = {
    svc: ['The job took far longer than promised.', 'Nobody called me back about my booking.', 'The invoice was higher than the quote.', 'The work was sloppy and had to be redone.'],
    venue: ['The food was cold and we waited forever.', 'We were charged for things we never ordered.', 'A member of staff was rude to us.', 'It was far too loud and crowded.'],
    retail: ['The product broke after a week.', 'The shop refused my return.', 'The price on the shelf was not what I paid.', 'Nobody could help me find anything.'],
    logi: ['My parcel arrived damaged.', 'The driver was two hours late.', 'The car was dirty and smelled of smoke.', 'I was charged twice for one trip.'],
    project: ['The site was left in a mess.', 'You are weeks behind schedule.', 'The finish is not what we agreed.', 'Your workers blocked my driveway all week.'],
    prod: ['A delivery came with faulty units.', 'The order was short.', 'It arrived a week late.']
  };
  const SEVN = ['', 'Minor', 'Upset', 'Serious'];
  function complaintsWeek(co, bd) {
    if (co.st !== 'open' || NOWORK[bd.fam]) return;
    const L = co.compl = co.compl || [];
    const q = co.q != null ? co.q : 60;
    const util = co.lastW && co.lastW.util || 0;
    if (chance(clamp(0.035 + (62 - q) * 0.004 + (util > 0.97 ? 0.03 : 0), 0.008, 0.22))) {
      const sev = q < 45 && chance(0.4) ? 3 : chance(0.35) ? 2 : 1;
      L.unshift({ id: uid(), w: S.week, who: personName(), t: pick(CTX[bd.fam] || CTX.svc), sev, st: 'open' });
    }
    const asst = co.asst && co.asst.duties.indexOf('comp') >= 0 ? S.npcs[co.asst.npc] : null;
    L.forEach(c => {
      if (c.st !== 'open') return;
      if (co.mgr || asst) {
        const sk = co.mgr ? (S.npcs[co.mgr] ? S.npcs[co.mgr].stats.ops / 100 : 0.6) : (asst.skill || 55) / 100;
        resolveC(co, bd, c, mgrRefund(co, bd, c) ? 'refund' : 'sorry', chance(0.55 + sk * 0.4));
        c.by = co.mgr ? 'mgr' : 'asst';
      } else if (S.week - c.w >= 2) {
        resolveC(co, bd, c, 'ignore');
        note('A complaint at ' + co.name + ' went unanswered. The customer left a bad review.', 'bad', co.id);
      }
    });
    if (L.length > 30) L.length = 30;
  }
  /* a refund is the price of the job for small tickets; for big-ticket sales (a car, a building job) it is
     goodwill compensation — a repair, a discount on the next service — never 1.5× the sale price */
  function refundOf(tk, sev) { return sev * Math.min(tk * 1.5, KC(1500) + tk * 0.06); }
  /* managers refund when it is cheap relative to the business and the complaint is serious; otherwise they apologise */
  function mgrRefund(co, bd, c) {
    const amt = refundOf(ticketEff(co, bd), c.sev);
    const H = (co.hist || []).slice(-4), wr = H.length ? H.reduce((a, x) => a + x.rev, 0) / H.length / 4.33 : ((co.lastW && co.lastW.rev) || 0);
    if (amt > Math.max(KC(500), wr * 0.15)) return c.sev >= 3 && amt < wr * 0.4 && chance(0.5);
    return c.sev >= 3 || (c.sev === 2 && chance(0.5));
  }
  window.R7refundOf = refundOf;
  function resolveC(co, bd, c, a, good) {
    const tk = ticketEff(co, bd);
    c.st = a;
    c.wd = S.week;
    if (a === 'refund') {
      payCo(co, Math.round(refundOf(tk, c.sev)), 'loss', c.sev >= 3 && tk > KC(4000) ? 'Goodwill compensation to a customer' : 'Refund to a customer');
      co.rep = clamp(co.rep + 0.3 * c.sev, 0, 100);
    } else if (a === 'sorry') {
      const ok = good != null ? good : chance(c.sev === 1 ? 0.8 : c.sev === 2 ? 0.55 : 0.25);
      c.ok = ok;
      co.rep = clamp(co.rep + (ok ? 0.2 : -0.6 * c.sev), 0, 100);
    } else {
      co.rep = clamp(co.rep - 0.9 * c.sev, 0, 100);
      if (c.sev >= 3) co.aware = clamp(co.aware - 1, 0, 100);
    }
  }
  function complaintsPart(co, bd) {
    if (NOWORK[bd.fam]) return '';
    const L = (co.compl || []);
    const open = L.filter(c => c.st === 'open');
    const recent = L.filter(c => c.st !== 'open' && S.week - c.wd < 8).slice(0, 4);
    const asst = co.asst && co.asst.duties.indexOf('comp') >= 0 && S.npcs[co.asst.npc];
    let h = '<h2 class="sec">Complaints</h2>';
    if (co.mgr || asst) h += '<div class="calm">' + esc(co.mgr ? (S.npcs[co.mgr] ? S.npcs[co.mgr].name : 'Your manager') : asst.name) + ' answers complaints for you' + (recent.length ? ': ' + recent.length + ' in the last two months.' : '. None lately.') + '</div>';
    else if (!open.length) h += '<div class="calm">No open complaints. Unhappy customers write when quality slips or you are too busy. Answer within two weeks or they post a bad review.</div>';
    h += open.map(c => '<div class="card"><div class="cchd">' + faceAv({ id: c.id, name: c.who, age: 40 }) + '<span class="ctext"><b>' + esc(c.who) + '</b><small>' + dateStr(c.w) + ' · answer within ' + Math.max(0, 2 - (S.week - c.w)) + ' wk</small></span>' + pillp(SEVN[c.sev], c.sev >= 3 ? 'red' : c.sev === 2 ? 'amb' : '') + '</div><div class="bub them">“' + esc(c.t) + '”</div><div class="dbtns three3">' + btn('Refund · ' + mshort(refundOf(ticketEff(co, bd), c.sev)), 'complres', { id: co.id, c: c.id, a: 'refund' }, 'primary') + btn('Apologise', 'complres', { id: co.id, c: c.id, a: 'sorry' }) + btn('Ignore', 'complres', { id: co.id, c: c.id, a: 'ignore' }) + '</div></div>').join('');
    if (recent.length && !co.mgr && !asst) h += '<div class="lrows">' + recent.map(c => '<div class="lrow"><span class="ctext"><b>' + esc(c.who) + '</b><small>' + esc(c.t) + '</small></span>' + pillp(c.st === 'refund' ? 'Refunded' : c.st === 'sorry' ? (c.ok ? 'Calmed down' : 'Still angry') : 'Ignored', c.st === 'ignore' || (c.st === 'sorry' && !c.ok) ? 'red' : 'grn') + '</div>').join('') + '</div>';
    return h;
  }
  ACT.complres = p => {
    const co = getCo(p.id), c = co && (co.compl || []).find(x => x.id === p.c);
    if (!c || c.st !== 'open') return;
    resolveC(co, BD[co.type], c, p.a);
    save();
    render();
    toast(p.a === 'refund' ? 'Refunded. The customer is satisfied.' : p.a === 'sorry' ? (c.ok ? 'They accepted the apology.' : 'They are still unhappy.') : 'Ignored. Expect a bad review.', p.a === 'ignore' || (p.a === 'sorry' && !c.ok));
  };

  /* ---------- assistant manager: a worker first, with a couple of management jobs on top; does not run the company ---------- */
  const DUTY = { comp: ['Customer complaints', 'Answers complaints before they become reviews'], paper: ['Paperwork and insurance', 'Staff papers, documents and basic insurance'], equip: ['Equipment and stock', 'Services worn equipment and keeps stock up'] };
  function asstWeek(co, bd) {
    const a = co.asst;
    if (!a) return;
    const n = S.npcs[a.npc];
    if (!n) { co.asst = null; return; }
    payCo(co, a.wage * 12 / 52 * (1 + CC().empNI), 'wages');
    if (co.st !== 'open') return;
    const sk = (n.skill || 55) / 100;
    if (a.duties.indexOf('paper') >= 0) {
      co.staff.forEach(s => { onbMissing(s).forEach(it => { if (chance(0.7 + sk * 0.3)) s.onb[it[0]] = 1; }); });
      if (co.insr && !Object.keys(co.ins || {}).some(k => co.ins[k])) { co.ins.liab = 1; if (co.prem && co.prem.m2) co.ins.prop = 1; note(n.name + ' took out basic liability' + (co.ins.prop ? ' and property' : '') + ' insurance for ' + co.name + '.', 'n', co.id); }
    }
    if (a.duties.indexOf('equip') >= 0) {
      for (const id in co.eq) {
        const r = co.eq[id];
        if (r.sub || r.soft || id === 'fit') continue;
        if (r.cond < 0.55 + sk * 0.1 && co.cash > r.cost * 0.1) {
          payCo(co, Math.round(r.cost * 0.04 * (1 - fixDisc(co))), 'oth', 'Equipment service');
          r.cond = Math.min(1, r.cond + 0.3);
        }
      }
      if ((bd.tw.stock || bd.fam === 'retail' || bd.fam === 'prod') && co.stockPol === 0 && co.lastW && co.lastW.util > 0.95) co.stockPol = 1;
    }
    if (S.week - (a.sug || a.w0) >= 4 && window.__r5 && window.__r5.mprops) {
      a.sug = S.week;
      try {
        const L = window.__r5.mprops(co) || [];
        const x = L[Math.floor(Z() * Math.min(3, L.length))];
        if (x) info(n.name, 'Suggestion for ' + co.name + ': ' + x.title, (x.why || '') + ' I can only advise. You decide.', co.id, 'n');
      } catch (e) { }
    }
  }
  window.asstRow = function (co) {
    const a = co.asst, n = a && S.npcs[a.npc];
    if (!n) return co.mgr ? '' : '<button class="lrow solo" data-a="go" data-p="' + P({ n: 'mgrhire', p: { id: co.id } }) + '"><span class="lic">' + svg('plus', 18) + '</span><span class="ctext"><b>Assistant manager</b><small>Works alongside the team and takes up to two jobs off your plate. Paid more than a worker, less than a manager</small></span><i>›</i></button>';
    return '<div class="lrow solo">' + faceAv(n) + '<span class="ctext"><b>' + esc(n.name) + '</b><small>Assistant manager · ' + money(a.wage) + '/mo</small></span>' + btn('Let go', 'asstfire', { id: co.id }, 'chip ghost danger') + '</div><div class="card"><div class="bhead"><b>Jobs for ' + esc(n.name.split(' ')[0]) + '</b><small>' + a.duties.length + ' of 2</small></div>' + Object.keys(DUTY).map(k => '<button class="lrow" data-a="asstduty" data-p="' + P({ id: co.id, k }) + '"><span class="ctext"><b>' + DUTY[k][0] + '</b><small>' + DUTY[k][1] + '</small></span><span class="radio' + (a.duties.indexOf(k) >= 0 ? ' on' : '') + '"></span></button>').join('') + '<span class="tipt">' + esc(n.name.split(' ')[0]) + ' works a full week in the business, a little less for each job you hand over, and sends you a suggestion about once a month. Decisions stay with you.</span></div>';
  };
  ACT.asstduty = p => {
    const co = getCo(p.id), a = co.asst;
    const i = a.duties.indexOf(p.k);
    if (i >= 0) a.duties.splice(i, 1);
    else if (a.duties.length >= 2) { toast('Two jobs at most. Untick one first.', true); return; }
    else a.duties.push(p.k);
    save();
    render();
  };
  ACT.asstfire = p => {
    const co = getCo(p.id), n = S.npcs[co.asst.npc];
    confirmThen('Let ' + esc(n.name) + ' go?', 'About one month of pay as notice.', 'Let go', () => {
      payCo(co, co.asst.wage * (1 + CC().empNI), 'wages', 'Notice pay');
      n.hired = 0;
      co.asst = null;
      save();
      render();
    }, true);
  };
  ACT.asstsearch = p => {
    const co = getCo(p.id);
    if (co.cash < KC(2500) && liquid() < KC(2500)) { toast('Not enough cash for the job ad.', true); return; }
    payCo(co, KC(2500), 'oth', 'Job ad: assistant manager');
    ui.asstC = ui.asstC || {};
    ui.asstC[co.id] = [0, 1, 2].map(() => {
      const n = genManager(co, 'gen');
      n.asst = 1;
      n.ask0 = n.ask;
      n.skill = Math.round(((n.stats.ops || 50) + (n.stats.people || 50)) / 2);
      n.ask = window.R24 && R24.asstAsk ? R24.asstAsk(co, n) : Math.round(n.ask * 0.5 / 500) * 500;
      n.exp = Math.max(0, Math.round(n.exp * 0.6));
      return n.id;
    });
    ui.acand = null;
    save();
    render();
  };
  function hireAsst(co, n, w) {
    if (n.hired) return 'bad';
    if (w < n.ask * 0.9 || (w < n.ask && chance(0.5))) return 'refuse';
    n.hired = 1;
    co.asst = { npc: n.id, wage: w, duties: [], w0: S.week };
    return 'ok';
  }
  ACT.asstgo = p => {
    const co = getCo(p.id), n = S.npcs[p.n];
    const w = Math.round(U.inum('m' + n.id, n.ask) / 500) * 500;
    const r = hireAsst(co, n, w);
    const L = talkOf(n.id);
    L.push({ me: 1, t: 'I can offer ' + money(w) + ' a month.' });
    if (r === 'ok') {
      L.push({ me: 0, t: 'Deal. Tell me which two things you want off your plate.' });
      ui.acand = null;
      ui.stack.length && ui.stack.pop();
      ui.view = { n: 'co', p: { id: co.id, t: 'st' } };
      save();
      render(true);
      toast(n.name + ' is your assistant manager. Pick the jobs under Staff.');
    } else if (r === 'refuse') {
      L.push({ me: 0, t: 'That is a bit low for me. Could you come closer to ' + money(n.ask) + '?' });
      render();
    }
  };

  /* ---------- network searches: your contacts run dry ---------- */
  const NETCD = 4;
  const cdLeft = k => Math.max(0, ((S.netCD || {})[k] || 0) - S.week);
  const hs0 = ACT.hsearch;
  ACT.hsearch = p => {
    if (ui.hmode === 'network') {
      const k = 'w:' + p.id + ':' + ui.hrole;
      if (cdLeft(k)) { toast('You already asked your contacts. Nobody new for ' + cdLeft(k) + (cdLeft(k) > 1 ? ' weeks' : ' week') + '. Try a job ad or an agency.', true); return; }
      (S.netCD = S.netCD || {})[k] = S.week + NETCD;
    }
    hs0(p);
  };
  const hq0 = ACT.hqsearch;
  ACT.hqsearch = p => {
    if (ui.hqmode === 'network') {
      const k = 'hq:' + p.r;
      if (cdLeft(k)) { toast('Your network has nobody new for ' + cdLeft(k) + (cdLeft(k) > 1 ? ' weeks' : ' week') + '. Try a job ad or an agency.', true); return; }
      (S.netCD = S.netCD || {})[k] = S.week + NETCD;
    }
    hq0(p);
  };

  /* ---------- interviews as a chat ---------- */
  const talkOf = id => ((ui.talk = ui.talk || {})[id] = (ui.talk || {})[id] || []);
  const bub = x => '<div class="bub ' + (x.sys ? 'sys' : x.me ? 'me' : 'them') + '">' + esc(x.t) + '</div>';
  const TIERN = { young: 'Young, early career', mid: 'Mid-career', senior: 'Senior' };
  const band = v => v >= 80 ? 'Outstanding' : v >= 65 ? 'Strong' : v >= 45 ? 'Capable' : v >= 28 ? 'Developing' : 'Entry level';
  function workerChat(co, n, orig) {
    const k = 'w' + n.id, L = talkOf(n.id);
    const msgs = [{ me: 0, t: '“' + n.resume + '” I am asking ' + money(n.ask) + ' a month.' }].concat(L);
    const pi = orig.indexOf('<h3 class="gap">Pay model</h3>');
    const sales = pi >= 0;
    const pm = ui.pay && ui.pay[n.id];
    const est = !!(window.carOffer && window.carOffer(co, n));
    const carc = (ui.carc || {})[n.id] || 'co';
    let h = '<div class="ichat"><div class="vh"><button class="bk" data-a="candback" aria-label="Back">‹</button>' + faceAv(n) + '<div class="vht"><h1>' + esc(n.name) + ', ' + n.age + '</h1><p>' + esc(ROLES[n.role] ? ROLES[n.role][0] : '') + ' · claims ' + n.claimExp + ' yr · asks ' + mshort(n.ask) + '</p></div>' + (window.patDots ? window.patDots(n) : '') + '</div>';
    h += '<div class="clog">' + msgs.map(bub).join('') + '</div>';
    h += '<div class="composer"><div class="chips qk">' + (n.checked ? '' : btn('Check references · {m:600}', 'refcheck', { id: co.id, n: n.id }, 'chip')) + (n.trial ? '' : btn('Trial week · ' + mshort(n.ask / 4), 'trial', { id: co.id, n: n.id }, 'chip')) + (sales ? btn('Pay: ' + (pm && pm.m === 'com' ? 'commission' : pm && pm.m === 'mix' ? 'mixed' : 'fixed') + ' ▾', 'payplan', { id: co.id, n: n.id }, 'chip') : '') + (est ? btn(carc === 'co' ? 'Car: company ▾' : 'Car: own + mileage ▾', 'carc', { n: n.id, v: carc === 'co' ? 'own' : 'co' }, 'chip') : '') + btn('Profile', 'candinfo', { id: co.id, n: n.id }, 'chip') + btn('Pass', 'candpass', { n: n.id }, 'chip ghost') + '</div>' +
      '<div class="chips qk">' + [0.9, 1, 1.05, 1.15].map(f => '<button class="btn chip" data-a="setinp" data-p="' + P({ k, v: Math.round(n.ask * f / 100) * 100 }) + '">' + Math.round(f * 100) + '% · ' + mshort(n.ask * f) + '</button>').join('') + '</div>' +
      '<div class="crow">' + U.inp(k, 'Your offer / month', n.ask) + btn('Send', 'offer', { id: co.id, n: n.id }, 'primary') + '</div></div></div>';
    return h;
  }
  ACT.candinfo = p => {
    const co = getCo(p.id), n = S.npcs[p.n], ref = n.checked ? refCheck(n) : null;
    openSheet('<h2>' + esc(n.name) + '</h2><div class="card">' + row('Claimed experience', n.claimExp + ' yr · ' + esc(claimLabel(n))) + row('Asks', money(n.ask) + ' / month') + row('Cost per year', mshort(U.inum('w' + n.id, n.ask) * 12 * (1 + CC().empNI))) + row('Real skill', ref ? esc(ref.skillBand) : '<span class="amb">Unknown</span>') + row('Type', esc(TIERN[n.tier] || '')) + '</div><div class="card sense"><b>What you can sense</b><span class="tipt">' + (ref ? 'References: real level ' + esc(ref.skillBand) + ', ' + ref.exp + ' yr experience' + (ref.skillBand !== claimLabel(n) ? '. The CV does not match.' : '.') : 'You only have the CV so far. Some people exaggerate.') + (n.trial ? ' Trial week: about ' + band(n.trialRes != null ? n.trialRes : n.skill) + '.' : '') + '</span></div>' + btn('Back to the chat', 'sheetclose', undefined, 'wide'));
  };
  ACT.payplan = p => {
    const co = getCo(p.id);
    const orig = R7._origHire ? R7._origHire() : '';
    const a = orig.indexOf('<h3 class="gap">Pay model</h3>');
    let b = orig.indexOf('<div class="card"><div class="kv"><span>Work car');
    if (b < 0) b = orig.indexOf('<div class="card"><div class="kv"><span>Your offer');
    openSheet('<h2>Pay plan</h2>' + (a >= 0 ? orig.slice(a, b > a ? b : undefined).replace('<h3 class="gap">Pay model</h3>', '') : '') + btn('Done', 'sheetclose', undefined, 'wide'), 'payplan');
  };
  ['paysel', 'payrate'].forEach(k => {
    const f0 = ACT[k];
    if (!f0) return;
    ACT[k] = p => {
      f0(p);
      if (ui.sheet && ui.sheet.cls === 'payplan') ACT.payplan({});
    };
  });
  ['refcheck', 'trial'].forEach(k => {
    const f0 = ACT[k];
    ACT[k] = p => {
      f0(p);
      const n = S.npcs[p.n];
      if (!n) return;
      const L = talkOf(n.id);
      if (k === 'refcheck' && n.checked) {
        const ref = refCheck(n);
        L.push({ sys: 1, t: 'References: real level ' + ref.skillBand + ', ' + ref.exp + ' yr experience' + (ref.skillBand !== claimLabel(n) ? '. The CV does not match.' : '. Matches the CV.') });
      }
      if (k === 'trial' && n.trial !== 0 && n.trialRes != null) L.push({ sys: 1, t: 'Trial week done: works at about ' + band(n.trialRes) + ' level.' });
      render();
    };
  });
  const hireP = V.hire;
  V.hire = function (p) {
    const co = p && p.id && getCo(p.id);
    if (co && ui.cand) {
      const cl = (ui.cands && ui.cands[co.id + ':' + ui.hrole]) || [];
      const n = cl.map(id => S.npcs[id]).find(x => x && x.id === ui.cand && !x.hired && !x.gone);
      if (n) {
        R7._origHire = () => hireP(p);
        return workerChat(co, n, hireP(p));
      }
    }
    let h = hireP(p);
    if (co && ui.hmode === 'network') {
      const left = cdLeft('w:' + co.id + ':' + ui.hrole);
      if (left) h = h.replace('Network · free', 'Network · again in ' + left + ' wk');
    }
    return h;
  };
  function mgrChat(co, bd, n, asst) {
    n.qLeft = n.qLeft == null ? 3 : n.qLeft;
    const k = 'm' + n.id;
    const asked = MQ.filter(x => n.q && n.q[x[0]] != null), left = MQ.filter(x => !(n.q && n.q[x[0]] != null));
    const st = mgrStyle(n);
    const msgs = [{ me: 0, t: 'Hi. ' + n.resume + ' I am asking ' + money(n.ask) + ' a month.' }];
    asked.forEach(x => { msgs.push({ me: 1, t: QTXT[x[0]][0].replace(/[“”]/g, '') }); msgs.push({ me: 0, t: answerText(x[0], n.q[x[0]]) }); });
    if (st) msgs.push({ sys: 1, t: 'What the answers suggest: ' + st.map(x => x[0] + ' ' + x[1].toLowerCase()).join(' · ') });
    if (n.ref) msgs.push({ sys: 1, t: 'References checked: the CV holds up.' });
    talkOf(n.id).forEach(x => msgs.push(x));
    let h = '<div class="ichat"><div class="vh"><button class="bk" data-a="' + (asst ? 'acandback' : 'mcandback') + '" aria-label="Back">‹</button>' + faceAv(n) + '<div class="vht"><h1>' + esc(n.name) + ', ' + n.age + '</h1><p>' + (asst ? 'Assistant manager' : esc(MGR_TYPES[n.mtype] || 'Manager')) + ' · ' + n.exp + ' yr · asks ' + mshort(n.ask) + (asst ? '' : ' · fit ' + Math.round(typeFit(co, n.mtype) * 100) + '%') + '</p></div></div>';
    h += '<div class="clog">' + msgs.map(bub).join('') + '</div><div class="composer">';
    h += '<div class="chips qk">' + (n.qLeft > 0 ? left.map(x => '<button class="btn chip" data-a="mgrask" data-p="' + P({ n: n.id, k: x[0] }) + '">' + esc(QTXT[x[0]][0].replace(/[“”]/g, '')) + '</button>').join('') : '<span class="pill">No questions left</span>') + (n.ref ? '' : btn('Check references · {m:2500}', 'mgrref', { id: co.id, n: n.id }, 'chip')) + btn('Pass', asst ? 'acandback' : 'mcandback', undefined, 'chip ghost') + '</div>';
    h += '<div class="chips qk">' + [0.95, 1, 1.1].map(f => '<button class="btn chip" data-a="setinp" data-p="' + P({ k, v: Math.round(n.ask * f / 500) * 500 }) + '">' + Math.round(f * 100) + '% · ' + mshort(n.ask * f) + '</button>').join('') + '</div>';
    h += '<div class="crow">' + U.inp(k, 'Salary offer / month', n.ask) + btn(asst ? 'Offer' : 'Hire', asst ? 'asstgo' : 'mgrhirego', { id: co.id, n: n.id }, 'primary') + '</div></div></div>';
    return h;
  }
  const mh0 = V.mgrhire;
  V.mgrhire = function (p) {
    const co = getCo(p.id), bd = co && BD[co.type];
    if (!co) return mh0(p);
    if (ui.mcand) {
      const n = (((ui.mgrC || {})[co.id]) || []).map(id => S.npcs[id]).find(x => x && x.id === ui.mcand && !x.hired);
      if (n) return mgrChat(co, bd, n, false);
    }
    if (ui.acand) {
      const n = (((ui.asstC || {})[co.id]) || []).map(id => S.npcs[id]).find(x => x && x.id === ui.acand && !x.hired);
      if (n) return mgrChat(co, bd, n, true);
      ui.acand = null;
    }
    const h = mh0(p);
    const a = co.asst && S.npcs[co.asst.npc];
    const list = (((ui.asstC || {})[co.id]) || []).map(id => S.npcs[id]).filter(n => n && !n.hired);
    const card7 = '<h2 class="sec">Or an assistant manager</h2><div class="card"><span class="tipt">' + (a ? esc(a.name) + ' already helps you here.' : 'Not ready to hand over the company? An assistant manager works in the business like your best worker and also takes up to two jobs off your plate: complaints, paperwork and insurance, or equipment and stock. Paid more than a typical worker, less than a manager. You stay in charge.') + '</span>' + (a || co.mgr ? '' : btn('Find an assistant · job ad ' + mshort(KC(2500)), 'asstsearch', { id: co.id }, 'chip primary')) + '</div>' + list.map(n => '<button class="ccard" data-a="acandopen" data-p="' + P({ n: n.id }) + '"><div class="cchd">' + faceAv(n) + '<span class="ctext"><b>' + esc(n.name) + ', ' + n.age + '</b><small>' + n.exp + ' yr experience · ' + esc(n.resume).slice(0, 60) + '</small></span><span class="badge blue">Asks ' + mshort(n.ask) + '</span></div></button>').join('');
    const i = h.indexOf('<div class="lrows"><button class="lrow" data-a="go" data-p="' + P({ n: 'hq', p: { t: 'office' } }));
    return i >= 0 ? h.slice(0, i) + card7 + h.slice(i) : h + card7;
  };
  ACT.acandopen = p => { ui.acand = p.n; render(true); };
  ACT.acandback = () => { ui.acand = null; render(true); };
  /* hiring reopens an idle company */
  const offR = ACT.offer;
  ACT.offer = p => { offR(p); const co = getCo(p.id); if (co) wake(co); };
  const mhg = ACT.mgrhirego;
  ACT.mgrhirego = p => { mhg(p); const co = getCo(p.id); if (co) wake(co); };
  /* keep the newest message in view */
  new MutationObserver(() => { document.querySelectorAll('.clog').forEach(el => { if (!el.dataset.sc || el.dataset.sc !== String(el.childElementCount)) { el.scrollTop = el.scrollHeight; el.dataset.sc = String(el.childElementCount); } }); }).observe(document.body, { childList: true, subtree: true });

  /* ---------- office: tap the office to change it ---------- */
  ACT.officepop = () => {
    const o = S.office;
    openSheet('<h2>Choose an office</h2><p class="muted small">' + (o ? 'Moving costs one month of rent as a deposit.' : 'An office gives desks for HQ staff and group managers.') + '</p>' + OFFICE_T.map(x => {
      const cur = o && o.tier === x.id;
      return '<div class="opt' + (cur ? ' on' : '') + '"><div class="bhead"><div><b>' + esc(x.n) + '</b><small>' + (x.id === 'home' ? 'Just you' : x.desks + ' desks · ' + x.rooms + (x.rooms === 1 ? ' room' : ' rooms')) + ' · ' + esc(x.note) + '</small></div><div class="rt"><b>' + (x.rentM ? mshort(officeRent(x, S.player.city)) + '/mo' : 'Free') + '</b>' + (cur ? '<small>Current</small>' : btn(o ? 'Move' : 'Rent', 'rentoffice', { t: x.id }, 'chip')) + '</div></div></div>';
    }).join('') + btn('Cancel', 'sheetclose', undefined, 'ghost wide'));
  };
}

/* ===== Round 11: what each worker actually does, reviews that name people, bought rivals as branches or
   franchise offices, promotions with an analyst report and a contract talk, and a board that advises and votes. ===== */
{
  const P11 = o => esc(JSON.stringify(o));
  const capF = s => String(s || '').replace(/^./, x => x.toUpperCase());
  const first = nm => String(nm || '').split(' ')[0];
  const R10 = window.R10;
  const r500 = v => Math.max(500, Math.round(v / 500) * 500);
  const R11 = window.R11 = {};

  /* ================= 1. work records: each worker, each day ================= */
  const DRIVE = { driver: 0.0004, truckd: 0.004, courier: 0.00005 };
  function offDays(s, sh) {
    const all = [0, 1, 2, 3, 4, 5, 6];
    const z = all.filter(i => sh[i] === 0);
    if (z.length >= 2) return z;
    const rest = all.filter(i => sh[i] > 0).sort((a, b) => sh[a] - sh[b]).slice(0, 4);
    const R = hrng('off11:' + s.id);
    const out = z.slice();
    while (out.length < 2 && rest.length) out.push(rest.splice(Math.floor(R() * rest.length), 1)[0]);
    return out;
  }
  /* round 10 asks this before it hands out today's sales: nobody sells on a day off */
  window.R11off = (co, s, wk, d) => {
    const bd = BD[co.type];
    if (!R10 || !R10.dailyOk(co, bd)) return false;
    const wd = (new Date(wDate(wk).getTime() + d * 86400000).getUTCDay() + 6) % 7;
    return offDays(s, R10.shapeOf(bd)).indexOf(wd) >= 0;
  };
  function alloc(n, ws) {
    const W = sum(ws, x => x);
    if (!W || n <= 0) return ws.map(() => 0);
    const raw = ws.map(w => n * w / W), out = raw.map(Math.floor);
    let left = n - sum(out, x => x);
    raw.map((x, i) => [x - out[i], i]).sort((a, b) => b[0] - a[0]).forEach(x => { if (left > 0) { out[x[1]]++; left--; } });
    return out;
  }
  function riskOf(s) {
    const n = S.npcs[s.id] || {};
    return (1.6 - staffSkill(s) / 100) * (n.pers === 'driven' ? 1.5 : n.pers === 'steady' ? 0.7 : 1) * (s.safe11 && S.week < s.safe11 ? 0.5 : 1) * (s.warn ? 0.85 : 1);
  }
  function workDay(co, d, pre) {
    const bd = BD[co.type];
    if (!R10.dailyOk(co, bd)) return;
    const L = co.dl;
    if (!L || L.w !== S.week || !L.days[d]) return;
    const sold = L.days[d].u, wd = L.days[d].wd, sh = R10.shapeOf(bd), sd = sh[wd] * 7;
    const key = S.week * 7 + d;
    const on = co.staff.filter(s => S.npcs[s.id] && !(s.sick > 0) && offDays(s, sh).indexOf(wd) < 0);
    const groups = {};
    on.forEach(s => (groups[s.role] = groups[s.role] || []).push(s));
    const got = {};
    Object.keys(groups).forEach(r => {
      const g = groups[r];
      if (SALES_ROLES[r]) g.forEach(s => { got[s.id] = Math.max(0, (s.ws && s.ws.w === S.week ? s.ws.u : 0) - (pre[s.id] || 0)); });
      else alloc(sold, g.map(s => staffSkill(s) + 10)).forEach((u, i) => { got[g[i].id] = u; });
    });
    co.staff.forEach(s => {
      const work = on.indexOf(s) >= 0;
      let h = 0, f = 0;
      const u = work ? got[s.id] || 0 : 0;
      if (work) {
        h = DRIVE[s.role] == null ? clamp(7.5 + (sd - 1) * 1.5 + gauss() * 0.5, 4, 10) : clamp(8 + (sd - 1) * 2.5 + gauss() * 1.2, 5, 12);
        if (DRIVE[s.role] != null && Z() < Math.min(0.5, u * DRIVE[s.role] * riskOf(s))) f = 1;
      }
      s.dd = s.dd || [];
      s.dd.push({ k: key, wd, h: Math.round(h * 10) / 10, u, f });
      if (s.dd.length > 28) s.dd.shift();
      if (f) fined(co, s);
    });
    if (!co.mgr && (co.ohrs || 0) > 0) {
      const ou = Math.max(0, (co.ows && co.ows.w === S.week ? co.ows.u : 0) - (pre['o' + co.id] || 0));
      co.odd = co.odd || [];
      co.odd.push({ k: key, wd, h: sh[wd] > 0 ? Math.round(co.ohrs / 5 * 10) / 10 : 0, u: ou, f: 0 });
      if (co.odd.length > 28) co.odd.shift();
    }
  }
  const day10 = window.R10DAY;
  window.R10DAY = function (d) {
    const pre = {};
    S.cos.forEach(co => {
      co.staff.forEach(s => { pre[s.id] = s.ws && s.ws.w === S.week ? s.ws.u : 0; });
      pre['o' + co.id] = co.ows && co.ows.w === S.week ? co.ows.u : 0;
    });
    day10(d);
    S.cos.forEach(co => { try { workDay(co, d, pre); } catch (e) { console.error(e); } });
  };
  /* sellers' money per week, for reports */
  const u10 = window.R10U;
  window.R10U = function (co) {
    const r = u10.apply(this, arguments);
    if (r) co.staff.forEach(s => { if (s.lw && s.lw.w === S.week) { s.rh = (s.rh || []).concat(Math.round(s.lw.r)).slice(-12); } });
    return r;
  };
  function fined(co, s) {
    const n = S.npcs[s.id];
    s.fines = (s.fines || []).concat(S.week).slice(-12);
    const recent = s.fines.filter(w => w > S.week - 5).length;
    if (recent < 2 || (s.fm11 && s.fm11 > S.week - 8)) return;
    s.fm11 = S.week;
    const what = s.role === 'truckd' ? 'the truck' : s.role === 'courier' ? 'the van' : 'the taxi';
    addMsg({ kind: 'ask', from: co.mgr && S.npcs[co.mgr] ? S.npcs[co.mgr].name : 'Traffic police', title: n.name + ' got another speeding fine', body: n.name + ' was caught driving ' + what + ' too fast, ' + recent + ' times in a month. The fine is theirs to pay, but customers notice, and the insurer counts it.', co: co.id, opts: [{ l: 'Give a warning', d: '', fx: {} }, { l: 'Safe-driving course · ' + money(KC(6000)), d: '', fx: {} }, { l: 'Let it go', d: '', fx: {} }], act: 'fine11', data: { sid: s.id }, exp: S.week + 2 });
  }
  ACTS.fine11 = (m, idx) => {
    const co = getCo(m.co), s = co && co.staff.find(x => x.id === m.data.sid);
    if (!s) return true;
    if (idx === 0) s.warn = (s.warn || 0) + 1;
    if (idx === 1) { payCo(co, KC(6000), 'oth', 'Safe-driving course'); s.safe11 = S.week + 26; }
    return true;
  };
  function agg(rec, n) {
    const L = (rec || []).slice(-(n || 28));
    const a = { days: 0, h: 0, u: 0, f: 0, span: L.length };
    L.forEach(x => { if (x.h > 0) a.days++; a.h += x.h; a.u += x.u; a.f += x.f || 0; });
    return a;
  }
  const perDay = (a, k) => a.days ? a.u * (k || 1) / a.days : 0;
  const perWeek = (a, k) => a.span ? a.u * (k || 1) / (a.span / 7) : 0;
  const hrsDay = a => a.days ? a.h / a.days : 0;
  const hrsWeek = a => a.span ? a.h / (a.span / 7) : 0;
  const num = x => String(Math.round(x));
  const wk = x => x >= 0.95 ? num(x) + ' a week' : x * 4.33 >= 0.95 ? num(x * 4.33) + ' a month' : x > 0.01 ? '1 every ' + Math.round(1 / x) + ' weeks' : 'none yet';
  const D = (l, k) => [l, a => num(perDay(a, k)), a => perDay(a, k)];
  const Wk = (l, k) => [l, a => wk(perWeek(a, k)), a => perWeek(a, k)];
  const H = ['Hours a day', a => (Math.round(hrsDay(a) * 10) / 10).toFixed(1), a => hrsDay(a)];
  const FI = ['Speeding fines, 4 weeks', a => String(a.f), a => -a.f];
  const UT = ['Share of hours billed', a => a.h ? Math.round(Math.min(1, perWeek(a) / Math.max(1, hrsWeek(a))) * 100) + '%' : '–', a => a.h ? perWeek(a) / Math.max(1, hrsWeek(a)) : 0];
  const PW = (l, k) => [l, a => num(hrsWeek(a) / k), a => hrsWeek(a) / k];
  const BILL = [Wk('Billable hours'), UT];
  const T11 = {
    driver: [D('Trips a day'), D('Passengers a day', 1.35), ['Hours on the road a day', H[1], H[2]], ['Km a day', a => num(perDay(a, 7.8) + hrsDay(a) * 6), a => perDay(a)], FI],
    truckd: [Wk('Trips'), ['Driving hours a day', a => (Math.round(Math.min(9, hrsDay(a) * 0.85) * 10) / 10).toFixed(1), a => hrsDay(a)], ['Km a day', a => num(Math.min(720, perDay(a, 240) + hrsDay(a) * 20)), a => perDay(a)], FI],
    courier: [D('Parcels a day'), D('Stops a day', 0.75), ['Km a day', a => num(perDay(a, 0.75) * 2.2 + (a.days ? 25 : 0)), a => perDay(a)], FI],
    estate: [Wk('Homes sold'), PW('Viewings a week', 3.2), PW('Valuations a week', 9), H],
    cardealer: [Wk('Cars sold'), PW('Test drives a week', 2.5), H],
    sales: [Wk('Deals closed'), PW('Client meetings a week', 4), H],
    agent: [Wk('Policies sold'), H], broker: [Wk('Trades'), H],
    barber: [D('Clients a day'), H], physio: [D('Treatments a day'), H], groom: [D('Animals cared for a day'), H], trainer: [D('Sessions a day'), H], instr: [D('Lessons a day'), H],
    tutor: [Wk('Lesson hours'), H], photog: [Wk('Shoots'), H], handy: [Wk('Jobs'), H], carwash: [D('Cars a day'), H],
    cleaner: [Wk('Cleaning hours billed'), UT], consult: BILL, lawyer: BILL, acct: BILL, dev: BILL, designer: BILL, marketer: BILL, hr: BILL, paralegal: BILL,
    barista: [D('Orders a day'), H], cook: [D('Meals cooked a day'), H], chef: [D('Meals cooked a day'), H], waiter: [D('Guests served a day'), D('Tables a day', 1 / 2.6), H],
    bartender: [D('Drinks served a day', 2.3), H], cashier: [D('Customers served a day'), H], baker: [D('Items baked a day'), H], dealer: [D('Hands dealt a day', 6), H],
    guard: [D('Guests checked a day'), H], recept: [D('Calls and bookings a day', 1.3), H], housek: [D('Rooms cleaned a day'), H], usher: [D('Guests a day'), H],
    mech: [Wk('Cars prepared'), H], dispatch: [D('Trips planned a day'), H], pilot: [Wk('Flights'), H], fo: [Wk('Flights'), H], cabin: [Wk('Flights'), H],
    shipm: [Wk('Voyages'), H], deckh: [Wk('Voyages'), H], seaman: [Wk('Voyages'), H], eng: [Wk('Voyages'), H],
    mktan: [PW('Rival checks a week', 2), H]
  };
  function tmpl(co, s) {
    const bd = BD[co.type];
    return T11[s.role] || [D(capF(unitPl(bd.unit, 2)) + ' handled a day'), H];
  }
  R11.agg = agg;
  /* rows for a worker card: their numbers next to the team's */
  window.workBlock = function (co, s) {
    const bd = BD[co.type];
    if (!R10 || !R10.dailyOk(co, bd)) return '';
    const a = agg(s.dd);
    if (!a.span) return '<p class="muted small">Numbers show after their first working day.</p>';
    const team = co.staff.filter(x => x.role === s.role && x !== s && x.dd && x.dd.length);
    const T = tmpl(co, s);
    let h = '<div class="wk11"><b>Last ' + (a.span >= 28 ? '4 weeks' : a.span + ' days') + '</b>' + T.map((t, i) => {
      let tv = '';
      if (i === 0 && team.length) {
        const avg = sum(team, x => t[2](agg(x.dd))) / team.length, me = t[2](a);
        tv = ' <small class="' + (me >= avg ? 'pos' : 'neg') + '">team ' + esc(t[1]({ days: 1, h: 0, u: avg, f: 0, span: 7 }).replace(/^NaN$/, '0')) + '</small>';
        if (t[1] === undefined) tv = '';
      }
      return row(esc(t[0]), esc(t[1](a)) + tv);
    }).join('') + (s.rv11 && s.rv11.n ? row('Named in reviews', s.rv11.n + ' · ' + (s.rv11.sum / s.rv11.n).toFixed(1) + ' ★') : '') + '</div>';
    return h;
  };
  window.workShort = function (co, s) {
    const bd = BD[co.type];
    if (!R10 || !R10.dailyOk(co, bd) || !s.dd || !s.dd.length) return null;
    const t = tmpl(co, s)[0], a = agg(s.dd);
    return t[0] + ' ' + t[1](a);
  };

  /* ================= 2. reviews that name the worker, or you ================= */
  const FACE = { driver: 1, barber: 1, physio: 1, groom: 1, trainer: 1, instr: 1, tutor: 1, photog: 1, handy: 1, carwash: 1, cleaner: 1, barista: 1, waiter: 1, bartender: 1, cashier: 1, recept: 1, housek: 1, dealer: 1, usher: 1, estate: 1, cardealer: 1, sales: 1, agent: 1, banker: 1, teller: 1, consult: 1, lawyer: 1, acct: 1, chef: 1, guard: 1, courier: 1, dev: 1, designer: 1, marketer: 1, event: 1, elec: 1, plumb: 1, carp: 1, mech: 1 };
  const POS = {
    driver: ['{n} drove safely and knew every shortcut.', 'Clean car and a good chat with {n}. On time, too.'],
    estate: ['{n} sold our flat fast and got more than we hoped.', 'Calm and honest. {n} handled every viewing.'],
    cardealer: ['{n} found the right car for us, no pushy sales talk.'],
    barber: ['{n} gave me the best haircut in years.'], physio: ['{n} fixed my back in three sessions.'], trainer: ['{n} pushed me just the right amount.'],
    instr: ['Passed first try thanks to {n}.'], tutor: ['Our son’s grades went up with {n}.'], photog: ['{n} took wonderful photos.'], groom: ['{n} was so gentle with our dog.'],
    handy: ['{n} fixed it quickly and cleaned up after.'], elec: ['{n} found the fault in minutes.'], plumb: ['{n} came the same day and fixed the leak.'], carp: ['Lovely work by {n}.'],
    cleaner: ['Spotless. {n} is very thorough.'], housek: ['Our room was spotless every day. Thanks, {n}.'],
    waiter: ['{n} looked after our table perfectly.'], barista: ['Best coffee in town, thanks to {n}.'], bartender: ['{n} mixes a great drink.'], chef: ['Compliments to {n} in the kitchen.'],
    lawyer: ['{n} explained everything clearly.'], acct: ['{n} sorted our books and saved us money.'], consult: ['{n} saw what we had missed.'], dev: ['{n} built exactly what we needed.'], designer: ['{n} has a great eye.'],
    recept: ['{n} at the front desk sorted everything out.'], courier: ['{n} always delivers on time and with a smile.'], cashier: ['{n} at the till is always friendly.']
  };
  const POSG = ['{n} was friendly and really helpful.', 'Ask for {n}. Made the whole thing easy.', 'Big thanks to {n} for great service.', '{n} went the extra mile for us.'];
  const MIDG = ['{n} was fine, nothing special.', 'Service from {n} was okay.'];
  const NEG = { driver: ['{n} drove far too fast. Felt unsafe.'], waiter: ['{n} forgot our order twice.'], estate: ['{n} never called us back.'], barber: ['{n} cut it far too short.'], courier: ['{n} left the parcel in the rain.'] };
  const NEGG = ['{n} was rude and seemed in a hurry.', 'Had to wait ages. {n} did not seem to care.'];
  const OWNP = ['The owner, {n}, served us personally. You can tell they care.', '{n}, who owns the place, took time to talk to us. Great service.'];
  const OWNN = ['The owner, {n}, was stressed and short with us.'];
  function faceCands(co) {
    const L = [];
    co.staff.forEach(s => {
      if (!FACE[s.role] || !S.npcs[s.id]) return;
      const a = agg(s.dd, 7);
      if (s.dd && s.dd.length && !a.days) return;
      L.push({ s, w: 1 + Math.sqrt(a.u || 1), q: staffSkill(s), name: first(S.npcs[s.id].name) });
    });
    if (!co.mgr && (co.ohrs || 0) > 0 && S.player) L.push({ s: null, w: Math.max(1, (co.ohrs / 40) * 3), q: co.oskill || 40, name: first(S.player.name) });
    return L;
  }
  function nrvWeek(co) {
    const bd = BD[co.type];
    if (!bd || ['fin', 'energy', 'hold', 'club', 'rent'].indexOf(bd.fam) >= 0) return;
    const to = co.rvN || 0;
    if (co.rv11c == null || co.st !== 'open') { co.rv11c = to; return; }
    const from = co.rv11c;
    co.rv11c = to;
    if (to <= from) return;
    const C = faceCands(co);
    if (!C.length) return;
    const share = bd.fam === 'retail' ? 0.12 : 0.25;
    co.nrv = co.nrv || [];
    for (let c = Math.max(from + 1, to - 25); c <= to; c++) {
      const R = hrng(S.seed + ':nrv:' + co.id + ':' + c);
      if (R() > share) continue;
      let x = R() * sum(C, y => y.w), pickd = C[0];
      for (const y of C) { if ((x -= y.w) <= 0) { pickd = y; break; } }
      const mu = clamp(ratingOf(co) + (pickd.q - 50) / 40, 1.2, 4.95);
      const st = pickStar(R, mu);
      const role = pickd.s ? pickd.s.role : null;
      const L = !pickd.s ? (st >= 4 ? OWNP : st <= 2 ? OWNN : MIDG) : st >= 4 ? (POS[role] && R() < 0.6 ? POS[role] : POSG) : st <= 2 ? (NEG[role] && R() < 0.6 ? NEG[role] : NEGG) : MIDG;
      const tx = L[Math.floor(R() * L.length)].replace('{n}', pickd.name);
      co.nrv.push({ c, st, tx, who: pickd.s ? S.npcs[pickd.s.id].name : S.player.name, sid: pickd.s ? pickd.s.id : 'you', w: S.week });
      if (pickd.s) {
        const o = pickd.s.rv11 = pickd.s.rv11 || { n: 0, sum: 0 };
        o.n++;
        o.sum += st;
        if (st >= 5) pickd.s.happy = Math.max(pickd.s.happy || 0, S.week + 4);
      }
    }
    if (co.nrv.length > 120) co.nrv = co.nrv.slice(-120);
  }
  window.R11NRV = function (key, c) {
    const co = S.cos.find(x => 'c' + x.id === key);
    if (!co || !co.nrv) return null;
    for (let i = co.nrv.length - 1; i >= 0; i--) if (co.nrv[i].c === c) return co.nrv[i];
    return null;
  };
  const rvd0 = V.rvdetail;
  V.rvdetail = function (p) {
    let h = rvd0.apply(this, arguments);
    const co = p && S.cos.find(x => 'c' + x.id === p.k);
    if (!co || !co.nrv || !co.nrv.length) return h;
    const by = {};
    co.nrv.forEach(r => { const o = by[r.who] = by[r.who] || { n: 0, s: 0, you: r.sid === 'you' }; o.n++; o.s += r.st; });
    const L = Object.keys(by).sort((a, b) => by[b].n - by[a].n).slice(0, 8);
    const c2 = '<div class="card"><h3>Named in reviews<small>Customers who mention someone by name</small></h3>' + L.map(k => row(esc(k) + (by[k].you ? ' <small>(you)</small>' : ''), by[k].n + ' · ' + (by[k].s / by[k].n).toFixed(1) + ' ★')).join('') + '</div>';
    const mm = /<div class="card[ "]/g;
    mm.lastIndex = 5;
    const f2 = mm.exec(h), i = f2 ? f2.index : -1;
    return i > 0 ? h.slice(0, i) + c2 + h.slice(i) : h + c2;
  };

  /* ================= 3. a bought rival: own company, your branch, or a franchise office ================= */
  const rc0 = ACT.rivclose;
  const optB = (t, d, a, p, off) => '<button class="opt2 card' + (off ? ' dim' : '') + '"' + (off ? ' disabled' : '') + ' data-a="' + a + '" data-p="' + P11(p) + '"><div class="bhead"><b>' + t + '</b><i>›</i></div><span class="tipt">' + d + '</span></button>';
  ACT.rivclose = p => {
    if (p.how === 'own') return rc0(p);
    const co = getCo(p.id), r = co && rivalsOf(co).find(x => x.id === p.r);
    if (!co || !r) return rc0(p);
    const fr = !!(co.fr && co.fr.on);
    const b = Object.assign({}, p);
    openSheet('<h2>Buy ' + esc(r.name) + '</h2><p class="muted small">' + money(p.price) + '. What should it become?</p>' +
      optB('Its own company', 'Keeps its name and customers. You own and staff it.', 'rivclose', Object.assign({}, b, { how: 'own' })) +
      optB('Your branch', 'Your name on the door from day one. Shares your brand, so more people know it.', 'rivhow', Object.assign({}, b, { how: 'branch' })) +
      optB('Franchise office, old owner stays', fr ? 'The owner keeps running it under your brand, pays half your sign-up fee and ' + pc(co.fr.roy, 0) + ' royalties.' : 'Start your franchise system first, in the company’s Grow tab.', 'rivhow', Object.assign({}, b, { how: 'frold' }), !fr) +
      optB('Franchise office, new franchisee', fr ? 'A new franchisee buys the shop from you for about half, pays the full fee and royalties.' : 'Start your franchise system first, in the company’s Grow tab.', 'rivhow', Object.assign({}, b, { how: 'frnew' }), !fr) +
      btn('Cancel', 'sheetclose', undefined, 'ghost wide'));
  };
  ACT.rivhow = p => {
    const co = getCo(p.id), r = co && rivalsOf(co).find(x => x.id === p.r);
    if (!co || !r) return;
    if (p.how === 'branch') {
      const n = acquireRival(co, r, p.price);
      if (typeof n === 'string') { U.res(n); return; }
      const k = S.cos.filter(c => c.branch && c.branch.of === co.id).length + 2;
      n.name = co.name + ' ' + k;
      n.branch = { of: co.id };
      n.aware = Math.max(n.aware, (co.aware || 0) * 0.9);
      n.rep = Math.max(n.rep, (co.rep || 50) * 0.95);
      closeSheet();
      save();
      ui.stack = [];
      ui.tab = 'cos';
      ui.view = { n: 'co', p: { id: n.id, t: 'ov' } };
      render(true);
      toast(r.name + ' is now ' + n.name + '.');
      return;
    }
    const f = co.fr;
    if (!f || !f.on) return;
    const old = p.how === 'frold';
    const back = old ? 0 : Math.round(p.price * rng(0.45, 0.6) / 1000) * 1000;
    if (S.cash < p.price - back) { U.res('cash'); return; }
    payMe(p.price, 'Bought ' + r.name);
    if (back) gainMe(back, 'Franchisee takes over ' + r.name);
    const m = ensureMk(co);
    m.riv = (m.riv || []).filter(x => x !== r);
    m.n = Math.max(1, (m.n || 1) - 1);
    const nm = old ? (r.owner || personName()) : personName();
    f.units.push({ id: uid(), name: nm, city: co.city, w0: S.week - 40, skill: old ? rint(60, 82) : rint(40, 80), rev: 0, prof: 0, neg: 0, setup: 0, from: r.name });
    coIn(co, Math.round(f.fee * (old ? 0.5 : 1)), 'rev', 'Franchise fee: ' + nm);
    f.brand = Math.min(100, f.brand + 2);
    co.aware = Math.min(100, (co.aware || 0) + 3);
    note(r.name + ' now runs as a ' + co.name + ' franchise office, led by ' + nm + '.', 'good', co.id);
    closeSheet();
    save();
    render(true);
    toast(r.name + ' is now one of your franchise offices.');
  };

  /* ================= 4. promotions ================= */
  const HQM = { hr: 'hr', acct: 'acc', lawyer: 'law', analyst2: 'ana', analyst: 'ana', marketer: 'mkt', buyer: 'proc', consult: 'strat', designer: 'mkt' };
  const MGR_HQ = ['perf', 'strat', 'proc', 'hr'];
  const AUTHN = ['Ask me first', 'Within limits', 'Full control'];
  const DUTY = {
    mgr: [['hire', 'Hiring staff'], ['buy', 'Buying equipment and space']],
    exec: [['quality', 'Quality checks'], ['coach', 'Coaching managers'], ['hire', 'Finding managers']]
  };
  const REPS = [['week', 'Weekly update'], ['month', 'Monthly report'], ['need', 'Only when needed']];
  function ensureStats(n, role) {
    if (n.stats) return n.stats;
    const b = n.skill || 50, R = hrng('st11:' + n.id), z = () => (R() - 0.5) * 20;
    const st = { ops: b + z(), people: b + z(), sales: b + z(), fin: b - 6 + z(), risk: b + z(), ethic: 55 + z() };
    if (SALES_ROLES[role]) st.sales += 12;
    if (role === 'acct') st.fin += 15;
    if (role === 'hr') st.people += 12;
    if (role === 'lead') { st.people += 6; st.ops += 6; }
    if (role === 'lawyer') st.risk += 12;
    if (role === 'consult') { st.ops += 8; st.fin += 6; }
    Object.keys(st).forEach(k => { st[k] = Math.round(clamp(st[k], 5, 98)); });
    n.stats = st;
    n.mtype = n.mtype || 'gen';
    return st;
  }
  const qOf = n => n && n.stats ? (n.stats.ops + n.stats.people + n.stats.sales + n.stats.fin + n.stats.risk) / 500 : 0.5;
  const mgrBase = c => wageFor(BD[c.type].std[0] ? BD[c.type].std[0][0] : 'helper', c) * 1.55;
  /* who is being promoted: a worker in a company, or that company's manager */
  function candOf(p) {
    const co = getCo(p.id);
    if (!co) return null;
    if (p.m) {
      const n = co.mgr && S.npcs[co.mgr];
      return n ? { co, n, m: 1, pay: co.mgrWage || 0, role: 'mgr', skill: Math.round(mgrQual(co) * 100) } : null;
    }
    const s = co.staff.find(x => x.id === p.s);
    const n = s && S.npcs[s.id];
    return n ? { co, n, s, m: 0, pay: s.wage, role: s.role, skill: staffSkill(s) } : null;
  }
  function postsFor(c) {
    const L = [], co = c.co, cos = liveCos().filter(x => x.st === 'open' || x.st === 'setup');
    const desk = execDesk();
    if (!c.m) ladderFor(co, c.s).forEach(r => L.push({ k: 'role:' + r, t: ROLES[r][0], where: co.name, base: wageFor(r, co) * (0.8 + c.skill / 200), kind: 'role' }));
    if (!c.m && !co.mgr) L.push({ k: 'mgr@' + co.id, t: titleFor(co, 'mgr'), where: co.name, base: mgrBase(co), kind: 'mgr' });
    cos.filter(x => x.id !== co.id && !x.mgr && BD[x.type].fam !== 'hold').slice(0, 4).forEach(x => L.push({ k: 'mgr@' + x.id, t: titleFor(x, 'mgr'), where: x.name, base: mgrBase(x), kind: 'mgr' }));
    if (window.R12chiefPosts) window.R12chiefPosts(c).forEach(x => L.push(Object.assign({ base: mgrBase(co) * 1.5, kind: 'exec' }, x)));
    const why = !S.office ? 'Needs an office (Office tab)' : !desk ? 'Needs a free desk in your office' : '';
    const regs = (S.group && S.group.regional) || [];
    if (cos.length >= 2 && !regs.some(r => r.scope === 'all')) L.push({ k: 'region:all', t: titleFor(null, 'region'), where: 'All your companies', base: mgrBase(co) * 1.7, kind: 'exec', off: why });
    const cats = {};
    cos.forEach(x => { const k = BD[x.type].cat; cats[k] = (cats[k] || 0) + 1; });
    Object.keys(cats).filter(k => cats[k] >= 2 && !regs.some(r => r.scope === k)).slice(0, 2).forEach(k => L.push({ k: 'region:' + k, t: titleFor(null, 'region'), where: k, base: mgrBase(co) * 1.5, kind: 'exec', off: why }));
    if (!(S.group && S.group.ceo)) L.push({ k: 'ceo', t: titleFor(null, 'ceo'), where: 'The whole group', base: mgrBase(co) * 2.8, kind: 'exec', off: cos.length < 3 ? 'Needs 3 or more companies' : why });
    const hk = c.m ? MGR_HQ : HQM[c.role] ? [HQM[c.role]] : [];
    hk.forEach(k => {
      if (!HQ_ROLES[k]) return;
      const r = hqRoom(k);
      const off = r === 'ok' ? '' : r === 'have' ? 'Already filled' : r === 'office' ? 'Needs an office' : r === 'homeoffice' ? 'Needs a real office, not home' : r === 'desks' ? 'No free desk' : r === 'locked' ? (typeof hqUnlockText === 'function' ? 'Opens when you run ' + hqUnlockText(k) : 'Not open yet') : 'Not possible';
      L.push({ k: 'hq:' + k, t: HQ_ROLES[k][0], where: 'Your office', base: KC(HQ_ROLES[k][1]), kind: 'exec', off });
    });
    return L;
  }
  const askFor = (c, post) => r500(Math.max(c.pay * 1.12, post.base * (0.85 + c.skill / 300)));
  const patMax = n => n.pers === 'driven' ? 5 : n.pers === 'loyal' || n.pers === 'steady' ? 8 : 7;
  const dots = (n, left) => '<span class="pdots">' + Array.from({ length: patMax(n) }, (x, i) => '<i class="' + (i < left ? 'on' : '') + '"></i>').join('') + '</span>';

  V.titles.pr11 = 'Promotion';
  V.pr11 = function (p) {
    const c = candOf(p);
    if (!c) return '<div class="calm">This person is no longer here.</div>';
    const { co, n } = c;
    let h = '<div class="card"><div class="cchd">' + faceAv(n) + '<span class="ctext"><b>' + esc(n.name) + '</b><small>' + esc(c.m ? titleFor(co, 'mgr') : ROLES[c.role][0]) + ' · ' + esc(co.name) + ' · ' + money(c.pay) + '/mo</small></span></div>' +
      (c.m ? row('Managing since', dateStr(co.mgrW0 || S.week)) + row('Last month', plus(lastProfit(co) || 0)) : (window.workBlock ? window.workBlock(co, c.s) : '')) + '</div>';
    h += btn((hasHQ('ana') ? 'Analyst report on ' : 'Your notes on ') + esc(first(n.name)) + ' ›', 'go', { n: 'anrep11', p: { id: co.id, s: c.s ? c.s.id : null, m: c.m } }, 'wide');
    const L = postsFor(c);
    h += '<h2 class="sec">Promote to</h2><div class="lrows">' + (L.length ? L.map(x => x.off ? '<div class="lrow dim"><span class="ctext"><b>' + esc(x.t) + '</b><small>' + esc(x.where) + ' · ' + esc(x.off) + '</small></span></div>' : '<button class="lrow" data-a="p11talk" data-p="' + P11({ id: co.id, s: c.s ? c.s.id : null, m: c.m, k: x.k }) + '"><span class="ctext"><b>' + esc(x.t) + '</b><small>' + esc(x.where) + ' · will ask about ' + mshort(askFor(c, x)) + '/mo</small></span><i>›</i></button>').join('') : '<div class="calm">No higher post fits right now.</div>') + '</div>';
    return h;
  };
  ACT.p11talk = p => {
    const c = candOf(p);
    if (!c) return;
    const post = postsFor(c).find(x => x.k === p.k);
    if (!post || post.off) return;
    const n = c.n;
    if (n.p11no && S.week < n.p11no) { toast(first(n.name) + ' does not want to talk about it again yet.', true); return; }
    const ask = askFor(c, post);
    const st = n.p11 && n.p11.k === p.k ? n.p11 : (n.p11 = { k: p.k, ask, pat: patMax(n), log: [], w: S.week });
    st.ask = ask;
    ui.p11 = { id: c.co.id, s: c.s ? c.s.id : null, m: c.m, k: p.k, wage: ui.p11 && ui.p11.k === p.k ? ui.p11.wage : ask, bonus: 0, auth: 1, duties: post.kind === 'role' ? [] : DUTY[post.kind === 'mgr' ? 'mgr' : 'exec'].map(x => x[0]).slice(0, post.kind === 'mgr' ? 2 : 2), rep: 'month' };
    ui.inp['p11w'] = String(Math.round(ask / fxr(CC())));
    go('p11talk', { id: c.co.id });
  };
  V.titles.p11talk = 'Promotion talk';
  V.p11talk = function () {
    const u = ui.p11, c = u && candOf(u);
    if (!c) return '<div class="calm">Nothing to discuss.</div>';
    const n = c.n, post = postsFor(c).find(x => x.k === u.k);
    const st = n.p11;
    if (!post || !st) return '<div class="calm">That post is no longer open.</div>';
    const done = st.done;
    const msgs = [{ sys: 1, t: 'Promotion talk · ' + post.t + ' · ' + post.where }, { me: 0, t: 'Thank you for thinking of me. For ' + (post.kind === 'role' ? 'that job' : 'a step like this') + ' I would expect about ' + money(st.ask) + ' a month.' }].concat(st.log);
    const bub = x => '<div class="bub ' + (x.sys ? 'sys' : x.me ? 'me' : 'them') + '">' + esc(x.t) + '</div>';
    let h = '<div class="ichat phone7"><div class="ph7top"><button class="bk" data-a="p11back" aria-label="Back">‹</button>' + faceAv(n) + '<div class="vht"><h1>' + esc(n.name) + '</h1><p>' + esc(post.t) + ' · now ' + mshort(c.pay) + '/mo</p></div>' + dots(n, st.pat) + '</div>';
    h += '<div class="clog"><div class="cfill"></div>' + msgs.map(bub).join('') + '</div><div class="composer">';
    if (done) return h + '<div class="crow">' + btn(done === 'yes' ? 'Done' : 'Close', 'p11back', {}, 'primary wide') + '</div></div></div>';
    const seg = (items, cur, k) => '<div class="seg7">' + items.map(x => '<button class="' + (x[0] === cur ? 'on' : '') + '" data-a="p11set" data-p="' + P11({ k, v: x[0] }) + '">' + x[1] + '</button>').join('') + '</div>';
    if (post.kind !== 'role') {
      h += '<div class="chips qk">' + DUTY[post.kind === 'mgr' ? 'mgr' : 'exec'].map(x => '<button class="btn chip' + (u.duties.indexOf(x[0]) >= 0 ? ' primary' : '') + '" data-a="p11duty" data-p="' + P11({ v: x[0] }) + '">' + x[1] + '</button>').join('') + '</div>';
      h += seg(AUTHN.map((x, i) => [i, x]), u.auth, 'auth');
      h += seg(REPS, u.rep, 'rep');
    }
    h += seg([[0, 'No bonus'], [0.05, '5% bonus'], [0.1, '10%'], [0.2, '20%']], u.bonus, 'bonus');
    if (c.co.form === 'AS' && c.co.own > 10) h += seg([[0, 'No shares'], [2, '2% shares'], [5, '5%'], [10, '10%']], u.eq || 0, 'eq');
    h += '<div class="chips qk">' + [0.9, 1, 1.1].map(f => { const v = r500(st.ask * f); return '<button class="btn chip' + (Math.round(U.inum('p11w', st.ask) / 500) * 500 === v ? ' primary' : '') + '" data-a="setinp" data-p="' + P11({ k: 'p11w', v }) + '">' + Math.round(f * 100) + '% · ' + mshort(v) + '</button>'; }).join('') + '</div>';
    h += '<div class="crow">' + U.inp('p11w', 'Monthly salary', st.ask) + btn('Send', 'p11offer', {}, 'primary') + '</div>';
    return h + '</div></div>';
  };
  ACT.p11set = p => { if (ui.p11) ui.p11[p.k] = p.v; render(); };
  ACT.p11duty = p => {
    const u = ui.p11;
    if (!u) return;
    const i = u.duties.indexOf(p.v);
    if (i >= 0) u.duties.splice(i, 1); else u.duties.push(p.v);
    render();
  };
  ACT.p11back = () => { ui.p11 = null; U.back(); };
  ACT.p11offer = () => {
    const u = ui.p11, c = u && candOf(u);
    if (!c) return;
    const n = c.n, st = n.p11, post = postsFor(c).find(x => x.k === u.k);
    if (!st || !post || st.done) return;
    const w = r500(U.inum('p11w', st.ask));
    const senior = post.kind === 'exec';
    const need = st.ask * (1 + Math.max(0, u.duties.length - 1) * 0.03 + (post.kind === 'role' ? 0 : u.auth === 2 ? -0.03 : u.auth === 0 && senior ? 0.03 : 0) + (senior && u.rep === 'week' ? 0.02 : 0));
    const eqV = (u.eq || 0) && c.co.form === 'AS' ? Math.max(0, companyValue(c.co)) * u.eq / 100 / 36 : 0;
    const eff = w + w * u.bonus * 0.6 + eqV;
    st.log.push({ me: 1, t: 'I can offer ' + money(w) + ' a month' + ((u.eq || 0) ? ' and ' + u.eq + '% of the shares' : '') + (u.bonus ? ' plus a ' + Math.round(u.bonus * 100) + '% yearly bonus' : '') + (post.kind !== 'role' ? ', ' + AUTHN[u.auth].toLowerCase() + (u.duties.length ? ', you handle ' + u.duties.map(d => DUTY[post.kind === 'mgr' ? 'mgr' : 'exec'].find(x => x[0] === d)[1].toLowerCase()).join(' and ') : '') + ', ' + REPS.find(x => x[0] === u.rep)[1].toLowerCase() : '') + '.' });
    if (eff >= need) {
      st.done = 'yes';
      st.log.push({ me: 0, t: pick(['Deal. Thank you, I will not let you down.', 'Then we have a deal. I start on Monday.', 'Yes. I have wanted this for a while.']) });
      const msg = applyPost(c, post, w, u) + ((u.eq || 0) && c.co.form === 'AS' && c.co.own > u.eq ? (window.R15give ? window.R15give(c.co, n, u.eq) : '') : '');
      st.log.push({ sys: 1, t: msg });
      save();
      render();
      return;
    }
    if (eff >= need * 0.9) {
      st.pat -= 1;
      st.log.push({ me: 0, t: 'Close. Make it ' + money(r500(need / (1 + u.bonus * 0.6))) + (u.duties.length > 2 ? ', or take one duty off me,' : '') + ' and we have a deal.' });
    } else {
      st.pat -= 2;
      st.log.push({ me: 0, t: post.kind === 'role' ? 'That is not much more than I earn now.' : 'That is too little for this much responsibility.' });
    }
    if (st.pat <= 0) {
      st.done = 'no';
      st.log.push({ me: 0, t: 'Let us leave it. I will keep my current job for now.' });
      n.p11no = S.week + 8;
      n.p11 = Object.assign({}, st);
      if (c.s) { c.s.happy = 0; if (chance(0.25)) c.s.notice = 4; }
      else if (c.co) c.co.mood = Math.max(0, (c.co.mood || 60) - 10);
    }
    save();
    render();
  };
  function leaveJob(c) {
    const { co, n } = c;
    if (c.m) {
      co.mgr = null;
      co.mgrWage = 0;
      co.mgrBonus = 0;
      if (co.auth) co.auth.lvl = 0;
    } else co.staff = co.staff.filter(x => x !== c.s);
    n.hired = 0;
  }
  function applyPost(c, post, w, u) {
    const { co, n } = c;
    const k = post.k;
    n.k11 = { post: k, t: post.t, wage: w, bonus: u.bonus, duties: u.duties.slice(), auth: u.auth, rep: u.rep, w0: S.week, from: { co: co.id, role: c.role } };
    n.p11 = null;
    if (k.indexOf('role:') === 0) {
      promoteStaff(co, c.s.id, k.slice(5));
      c.s.wage = w;
      return first(n.name) + ' is now ' + ROLES[k.slice(5)][0] + ' at ' + co.name + '.';
    }
    if (k.indexOf('mgr@') === 0) {
      const to = getCo(+k.slice(4)) || S.cos.find(x => String(x.id) === k.slice(4));
      ensureStats(n, c.role);
      leaveJob(c);
      to.mgr = n.id;
      to.mgrWage = w;
      to.mgrBonus = u.bonus;
      to.mgrW0 = S.week;
      to.ohrs = 0;
      to.mood = Math.max(to.mood || 0, 62);
      to.flags.fraud = 0;
      to.lastRev = null;
      if (to.auth) to.auth.lvl = u.auth;
      n.hired = to.id;
      return first(n.name) + ' now manages ' + to.name + '.';
    }
    ensureStats(n, c.role);
    let ok = false;
    const had = c.m ? co.name : null;
    leaveJob(c);
    if (k.indexOf('chain:') === 0) ok = !!(window.R12hireChief && window.R12hireChief(k.slice(6), n, w, u.auth));
    else if (k.indexOf('region:') === 0) ok = !!hireRegional(k.slice(7), n.id, w, u.auth, [0, 250000, 1e9][u.auth]);
    else if (k === 'ceo') ok = !!hireCEO(n.id, w, u.auth, [0, 500000, 1e9][u.auth]);
    else if (k.indexOf('hq:') === 0) {
      const role = k.slice(3);
      if (hqRoom(role) === 'ok') { n.hired = -3; S.office.staff.push({ id: n.id, role, name: n.name, wage: w, w0: S.week, onb: {} }); ok = true; }
    }
    if (!ok) {
      n.hired = 0;
      return 'Something blocked the move. Check that your office has a free desk.';
    }
    const seat = window.R12execSeat ? window.R12execSeat(n, post) : addSeat(n.id, 'exec', post.t);
    if (had) note(had + ' has no manager now. Find one, or run it yourself.', 'bad', co.id);
    return first(n.name) + ' is now ' + post.t + '.' + (seat === 'none' ? '' : seat ? ' ' + first(n.name) + ' joins the board.' : ' The board is full, so no seat.');
  }
  /* the manager's duties are real: without them, those decisions come to you */
  const mp0 = window.makeProposal;
  if (typeof mp0 === 'function') window.makeProposal = function (co, dp) {
    const n = co && co.mgr && S.npcs[co.mgr];
    const d = n && n.k11 && n.k11.post && n.k11.post.indexOf('mgr@') === 0 ? n.k11.duties : null;
    const need = dp && (dp.t === 'hire' ? 'hire' : dp.t === 'eq' || dp.t === 'veh' || dp.t === 'space' ? 'buy' : null);
    if (d && need && d.indexOf(need) < 0 && co.auth) {
      const l = co.auth.lvl;
      co.auth.lvl = 0;
      try { return mp0.apply(this, arguments); } finally { co.auth.lvl = l; }
    }
    return mp0.apply(this, arguments);
  };
  /* bosses above lift (or drag) every manager under them */
  const mq0 = window.mgrQual;
  window.mgrQual = function (co) {
    const q = mq0.apply(this, arguments);
    if (!co || !co.mgr) return q;
    let f = 1;
    const rg = co.region && S.group && S.group.regional.find(r => r.id === co.region);
    if (rg && S.npcs[rg.npc]) f *= 1 + 0.1 * (qOf(S.npcs[rg.npc]) - 0.5);
    if (S.group && S.group.ceo && S.npcs[S.group.ceo.npc]) f *= 1 + 0.06 * (qOf(S.npcs[S.group.ceo.npc]) - 0.5);
    return clamp(q * f, 0.05, 1);
  };
  /* report preference of a promoted manager */
  const sp0 = window.shouldPack;
  if (typeof sp0 === 'function') window.shouldPack = function (co, rs) {
    const n = co && co.mgr && S.npcs[co.mgr];
    if (n && n.k11 && n.k11.rep === 'need') { const h = co.hist && co.hist[co.hist.length - 1]; return !!(h && h.profit < 0); }
    if (n && n.k11 && (n.k11.rep === 'month' || n.k11.rep === 'week')) return true;
    return sp0.apply(this, arguments);
  };
  /* entry points: the old promote buttons open the new flow */
  ACT.promosheet = p => go('pr11', { id: p.id, s: p.s });
  ACT.promoteact = p => {
    const co = getCo(p.id), a = co && window.actingMgr && window.actingMgr(co);
    if (a) go('pr11', { id: co.id, s: a.id });
  };
  const xh0 = V.exechire;
  if (xh0) V.exechire = function () { if (!ui.exec) ui.exec = { k: 'region', scope: 'all', list: [] }; return xh0.apply(this, arguments); };

  /* ---------- analyst report on a person ---------- */
  V.titles.anrep11 = 'Report';
  V.anrep11 = function (p) {
    const c = candOf(p);
    if (!c) return '<div class="calm">This person is no longer here.</div>';
    const { co, n } = c, ana = hasHQ('ana'), acc = ana ? analystAcc() : 0;
    const rng2 = (v, i) => { const e = Math.round((1 - acc) * 22 + 4), R = hrng('ar11:' + n.id + ':' + i + ':' + Math.floor(S.week / 13)), c0 = v + (R() - 0.5) * e; return Math.round(clamp(c0 - e / 2, 0, 100)) + '–' + Math.round(clamp(c0 + e / 2, 0, 100)); };
    let h = '<div class="card"><div class="cchd">' + faceAv(n) + '<span class="ctext"><b>' + esc(n.name) + '</b><small>' + (ana ? 'Prepared by your data analyst' : 'Your own notes. A data analyst in your office writes a full report.') + '</small></span></div></div>';
    if (c.m) {
      const H = co.hist || [], w0 = co.mgrW0 || 0, m0 = monthIdx(w0);
      const bef = H.filter(x => x.m < m0).slice(-3), aft = H.filter(x => x.m >= m0).slice(-3);
      const av = (L, k) => L.length ? sum(L, x => x[k]) / L.length : null;
      const fmt = v => v == null ? '–' : plus(Math.round(v));
      const rb = av(bef, 'rev'), ra = av(aft, 'rev');
      h += '<div class="card"><h3>Results<small>Average month, before and since ' + esc(first(n.name)) + ' took over</small></h3>' + row('Revenue before', rb == null ? '–' : money(Math.round(rb))) + row('Revenue now', ra == null ? '–' : money(Math.round(ra)) + (rb ? ' <small class="' + (ra >= rb ? 'pos' : 'neg') + '">' + (ra >= rb ? '+' : '') + Math.round((ra / rb - 1) * 100) + '%</small>' : '')) + row('Profit before', fmt(av(bef, 'profit'))) + row('Profit now', fmt(av(aft, 'profit'))) +
        (ra ? row('Margin now', Math.round(av(aft, 'profit') / ra * 100) + '% <small>normal for the trade about ' + Math.round((BD[co.type].m || 0.08) * 100) + '%</small>') : '') + row('Customer rating', ratingOf(co).toFixed(1) + ' ★') + row('Staff mood', co.mood != null ? Math.round(co.mood) + ' / 100' : '–') + row('Staff', co.staff.length + ' people') + '</div>';
    } else {
      const s = c.s, a = agg(s.dd);
      h += '<div class="card"><h3>Work</h3>' + (window.workBlock ? window.workBlock(co, s) : '') + '</div>';
      const rh = s.rh || [];
      const share = co.lastW && co.lastW.units && a.span ? Math.min(1, perWeek(a) / co.lastW.units) : 0;
      h += '<div class="card"><h3>Money</h3>' + (rh.length ? row('Sales they made, last ' + rh.length + ' weeks', money(sum(rh, x => x))) : '') + (share ? row('Share of the company’s work', Math.round(share * 100) + '%') : '') + row('Costs you', money(s.wage) + '/mo') + '</div>';
      h += '<div class="card"><h3>Reliability</h3>' + row('Late this quarter', s.late || 0) + row('Client complaints', s.cmp || 0) + row('Warnings', s.warn || 0) + (DRIVE[s.role] != null ? row('Speeding fines, 4 weeks', a.f) : '') + (s.rv11 && s.rv11.n ? row('Named in reviews', s.rv11.n + ' · ' + (s.rv11.sum / s.rv11.n).toFixed(1) + ' ★') : row('Named in reviews', 'not yet')) + '</div>';
      h += '<div class="card"><h3>Growth</h3>' + row('Performance now', skillBand(staffSkill(s))) + row('Better since they started', ((s.skillGain || 0) >= 0 ? '+' : '') + Math.round(s.skillGain || 0) + ' points') + (ana && n.pot ? row('Could reach', rng2(n.pot, 'pot')) : '') + '</div>';
    }
    if (ana) {
      const stt = n.stats || ensureStats(Object.assign({}, n, { stats: null }), c.role);
      h += '<div class="card"><h3>Leadership estimate<small>' + (acc >= 0.8 ? 'Fairly sure' : acc >= 0.5 ? 'Rough' : 'Very rough') + '</small></h3>' + [['ops', 'Running things'], ['people', 'People'], ['sales', 'Sales'], ['fin', 'Money'], ['risk', 'Risk sense']].map((x, i) => row(x[1], rng2(stt[x[0]], i))).join('') + '</div>';
      const sc = c.m ? mgrQual(co) * 100 + ((co.hist || []).slice(-3).every(x => x.profit > 0) ? 8 : -8) : staffSkill(c.s) * 0.6 + qOf({ stats: stt }) * 40;
      const verdict = sc >= 72 ? 'Ready for a bigger job. Strong across the board.' : sc >= 58 ? 'Could grow into a bigger job with support.' : sc >= 45 ? 'Better kept where they are for now.' : 'Not ready. Results and skills point the other way.';
      h += '<div class="card"><h3>Verdict</h3><p>' + esc(verdict) + '</p></div>';
    } else h += btn('Hire a data analyst', 'tab', 'hq', 'wide');
    return h;
  };

  /* ================= 5. the board ================= */
  const MAXSEAT = 7;
  const B = () => (S.board = S.board || { seats: [], freq: 4, last: -99, mts: [], cands: [] });
  const ADV = { fin: ['Finance advisor', 'fin'], law: ['Legal advisor', 'risk'], ind: ['Industry expert', 'ops'], mkt: ['Marketing advisor', 'sales'], chair: ['Experienced chair', 'people'] };
  function addSeat(id, kind, t, fee, type) {
    const b = B();
    if (b.seats.some(x => x.id === id)) return true;
    if (b.seats.length >= MAXSEAT) return false;
    b.seats.push({ id, kind, t, w0: S.week, fee: fee || 0, type: type || null, ok: 0, no: 0, mood: 60 });
    return true;
  }
  R11.addSeat = addSeat;
  function seats() {
    const b = B();
    b.seats = b.seats.filter(x => { const n = S.npcs[x.id]; return n && (x.kind === 'adv' ? n.hired === -4 : n.hired === -1 || n.hired === -2 || n.hired === -3); });
    return b.seats;
  }
  const seatSkill = x => { const n = S.npcs[x.id]; if (!n) return 50; const st = n.stats || {}; return x.kind === 'adv' ? st[ADV[x.type] ? ADV[x.type][1] : 'ops'] || 50 : qOf(n) * 100; };
  V.titles.board11 = 'Board';
  V.board11 = function () {
    const b = B(), L = seats();
    let h = '<div class="card"><div class="bhead"><b>' + L.length + ' of ' + MAXSEAT + ' seats</b><span class="pill blue">' + (b.freq === 13 ? 'Meets every quarter' : 'Meets every month') + '</span></div><span class="tipt">Your board looks at the numbers, gives advice and votes on big moves: selling or closing a company, big loans. Where outside owners hold more than half, a no vote stops it.</span>' +
      '<div class="seg7">' + [[4, 'Monthly'], [13, 'Quarterly']].map(x => '<button class="' + (b.freq === x[0] ? 'on' : '') + '" data-a="b11freq" data-p="' + x[0] + '">' + x[1] + '</button>').join('') + '</div>' +
      (L.length >= 2 ? btn('Hold a meeting now', 'b11meet', {}, 'primary wide') : '<p class="muted small">Two or more members can hold a meeting.</p>') + '</div>';
    h += '<div class="lrows">' + L.map(x => { const n = S.npcs[x.id]; const agree = x.ok + x.no ? Math.round(x.ok / (x.ok + x.no) * 100) + '% of advice taken' : 'new'; return '<div class="lrow">' + faceAv(n) + '<span class="ctext"><b>' + esc(n.name) + '</b><small>' + esc(x.t) + (x.fee ? ' · ' + mshort(x.fee) + '/mo' : '') + ' · ' + agree + '</small></span>' + (x.kind === 'adv' ? btn('Remove', 'b11rm', { id: x.id }, 'chip ghost') : '') + '</div>'; }).join('') + '</div>';
    if (L.length < MAXSEAT) {
      h += '<h2 class="sec">Invite an advisor</h2><div class="chips">' + Object.keys(ADV).map(k => btn(ADV[k][0], 'b11find', { t: k }, 'chip')).join('') + '</div>';
      const C = (b.cands || []).map(id => S.npcs[id]).filter(n => n && !n.hired);
      if (C.length) h += '<div class="lrows">' + C.map(n => '<div class="card"><div class="cchd">' + faceAv(n) + '<span class="ctext"><b>' + esc(n.name) + '</b><small>' + esc(ADV[n.adv][0]) + (n.advCat ? ' · ' + esc(n.advCat) : '') + ' · ' + n.age + ' · ' + esc(n.advBg || '') + '</small></span></div><div class="chips">' + [0.9, 1, 1.15].map(f => btn('Offer ' + mshort(r500(n.fee11 * f)) + '/mo', 'b11inv', { n: n.id, f: r500(n.fee11 * f) }, 'chip' + (f === 1 ? ' primary' : ''))).join('') + '</div></div>').join('') + '</div>';
    }
    const M = (b.mts || []).slice(0, 4);
    if (M.length) h += '<h2 class="sec">Meetings</h2><div class="lrows">' + M.map(m => '<button class="lrow" data-a="go" data-p="' + P11({ n: 'bmeet11', p: { id: m.id } }) + '"><span class="ctext"><b>' + esc(dateStr(m.w)) + '</b><small>' + m.items.length + ' points · ' + m.items.filter(x => x.st === 'yes').length + ' taken</small></span><i>›</i></button>').join('') + '</div>';
    return h;
  };
  ACT.b11freq = p => { B().freq = +p; save(); render(); };
  ACT.b11find = p => {
    const cost = KC(10000);
    if (S.cash < cost) { U.res('cash'); return; }
    payMe(cost, 'Search for a board advisor');
    const cats = Array.from(new Set(liveCos().map(c => BD[c.type].cat)));
    B().cands = [0, 1, 2].map(() => {
      const n = genManager(null, 'gen');
      n.adv = p.t;
      n.advCat = p.t === 'ind' ? pick(cats.length ? cats : ['Services']) : '';
      n.advBg = pick(['former director', 'ex-banker', 'sits on two other boards', 'built and sold a company', 'twenty years in the trade', 'former partner at a big firm']);
      const sk = (n.stats || {})[ADV[p.t][1]] || 55;
      n.fee11 = r500(KC(9000 + sk * 260));
      S.npcs[n.id] = n;
      return n.id;
    });
    save();
    render();
  };
  ACT.b11inv = p => {
    const n = S.npcs[p.n];
    if (!n || n.hired) return;
    const ok = p.f >= n.fee11 || (p.f >= n.fee11 * 0.9 && chance(0.5));
    if (!ok) { toast(first(n.name) + ' says no at that fee.', true); B().cands = B().cands.filter(x => x !== n.id); save(); render(); return; }
    n.hired = -4;
    addSeat(n.id, 'adv', ADV[n.adv][0] + (n.advCat ? ' · ' + n.advCat : ''), p.f, n.adv);
    B().cands = [];
    toast(n.name + ' joins your board.');
    save();
    render();
  };
  ACT.b11rm = p => {
    const n = S.npcs[p.id];
    if (n) n.hired = 0;
    B().seats = B().seats.filter(x => x.id !== p.id);
    save();
    render();
  };
  /* numbers for the meeting */
  function nums() {
    const L = liveCos().filter(c => c.st === 'open' && BD[c.type].fam !== 'hold');
    const rows = L.map(c => {
      const H = c.hist || [], a = H[H.length - 1] || {}, b = H[H.length - 2] || {};
      return { id: c.id, name: c.name, rev: a.rev || 0, prof: a.profit || 0, prev: b.profit || 0, m: a.rev ? (a.profit || 0) / a.rev : null, cash: Math.round(c.cash), staff: c.staff.length, rt: ratingOf(c), own: c.own };
    });
    const nw = netWorth();
    return { rows, rev: sum(rows, x => x.rev), prof: sum(rows, x => x.prof), cash: Math.round(S.cash), debt: Math.round(sum(S.loans || [], l => l.bal || 0)), nw: Math.round(nw.total), staff: sum(rows, x => x.staff) };
  }
  function recsOf(seat, N) {
    const n = S.npcs[seat.id], out = [], cos = liveCos().filter(c => c.st === 'open' && BD[c.type].fam !== 'hold');
    const typ = seat.kind === 'adv' ? seat.type : (n.k11 && n.k11.post === 'ceo') || seat.t === titleFor(null, 'ceo') ? 'ceo' : (n.k11 && /^region/.test(n.k11.post)) ? 'region' : 'hq';
    const H3 = c => (c.hist || []).slice(-3);
    if (typ === 'fin' || typ === 'ceo') {
      const bad = cos.find(c => H3(c).length === 3 && H3(c).every(x => x.profit < 0) && !(S.sales || []).some(s => s.co === c.id));
      if (bad) out.push({ text: bad.name + ' lost money three months in a row (' + H3(bad).map(x => mshort(x.profit)).join(', ') + '). Put it up for sale?', act: 'go', p: { n: 'sale', p: { id: bad.id } } });
      if (N.debt > 0 && N.cash > N.debt * 0.5 && N.cash > KC(500000)) out.push({ text: 'You hold ' + mshort(N.cash) + ' in cash and owe ' + mshort(N.debt) + '. Pay down the most expensive loan.', act: 'go', p: { n: 'bank', p: {} }, ph: 1 });
    }
    if (typ === 'ind' || typ === 'ceo' || typ === 'region') {
      const cat = seat.kind === 'adv' ? n.advCat : null;
      const low = cos.filter(c => (!cat || BD[c.type].cat === cat) && H3(c).length && (c.price || 0) < 3).map(c => ({ c, m: H3(c)[H3(c).length - 1].rev ? H3(c)[H3(c).length - 1].profit / H3(c)[H3(c).length - 1].rev : 0 })).filter(x => x.m > -0.15 && x.m < (BD[x.c.type].m || 0.08) - 0.03).sort((a, b) => a.m - b.m)[0];
      if (low) out.push({ text: 'Margin at ' + low.c.name + ' is ' + Math.round(low.m * 100) + '%, normal for the trade is about ' + Math.round((BD[low.c.type].m || 0.08) * 100) + '%. Raise prices one step.', act: 'price', p: { id: low.c.id } });
    }
    if (typ === 'mkt' || typ === 'chair') {
      const quiet = cos.filter(c => (c.aware || 0) < 35).sort((a, b) => a.aware - b.aware)[0];
      if (quiet) out.push({ text: 'Only ' + Math.round(quiet.aware) + '% of the area knows ' + quiet.name + '. Spend more on marketing there.', act: 'go', p: { n: 'co', p: { id: quiet.id } } });
    }
    if (typ === 'law') {
      const miss = cos.find(c => (BD[c.type].docs || []).some(d => !docOk(c, d)));
      if (miss) out.push({ text: miss.name + ' is missing paperwork it needs. Fix it before an inspection finds it.', act: 'go', p: { n: 'co', p: { id: miss.id } } });
    }
    if (typ === 'region' || typ === 'ceo' || typ === 'chair' || typ === 'hq') {
      const nom = cos.find(c => !c.mgr && c.staff.length >= 3);
      if (nom) out.push({ text: nom.name + ' has ' + nom.staff.length + ' staff and no manager. You work ' + (nom.ohrs || 0) + ' h a week there. Hire a manager.', act: 'go', p: { n: 'mgrhire', p: { id: nom.id } } });
      const sad = cos.find(c => c.mgr && (c.mood || 60) < 40);
      if (sad) out.push({ text: 'Morale at ' + sad.name + ' is low (' + Math.round(sad.mood) + ' / 100). Talk to the manager about pay and workload.', act: 'go', p: { n: 'co', p: { id: sad.id } } });
    }
    if (typ === 'chair' && cos.length >= 3 && !S.cos.some(c => c.type === 'hold')) out.push({ text: 'With ' + cos.length + ' companies, a holding company would make dividends and selling cheaper on tax.', act: 'go', p: { n: 'newhold', p: {} } });
    if (!out.length) out.push({ text: pick(['Numbers look steady. No changes from me this time.', 'Nothing urgent. Keep an eye on cash before the next tax bill.', 'Good month. Keep doing what works.']), act: null });
    return out.slice(0, 2).map(x => Object.assign({ who: seat.id, st: null }, x));
  }
  function holdMeeting() {
    const L = seats();
    if (L.length < 2) return null;
    const N = nums();
    const items = [];
    L.forEach(x => recsOf(x, N).forEach(r => { if (!items.some(y => y.text === r.text)) items.push(r); }));
    const m = { id: uid(), w: S.week, N, items };
    const b = B();
    b.mts = [m].concat(b.mts || []).slice(0, 6);
    b.last = S.week;
    addMsg({ kind: 'info', from: 'Your board', title: 'Board meeting · ' + items.filter(x => x.act).length + ' points for you', body: 'Revenue last month ' + money(N.rev) + ', profit ' + plus(N.prof) + '. ' + L.length + ' members at the table.', tone: 'n', status: 'done', go: { l: 'Open the meeting', a: 'go', p: { n: 'bmeet11', p: { id: m.id } } } });
    return m;
  }
  ACT.b11meet = () => {
    const b = B();
    if (S.week - (b.last || -99) < 2) { toast('The board met less than two weeks ago.', true); return; }
    const m = holdMeeting();
    if (m) { save(); go('bmeet11', { id: m.id }); }
  };
  const kf = v => { const a = Math.abs(v), s = v < 0 ? '−' : ''; return s + (a >= 1e6 ? (a / 1e6).toFixed(1) + ' M' : a >= 1e4 ? Math.round(a / 1e3) + ' k' : String(Math.round(a))); };
  V.titles.bmeet11 = 'Board meeting';
  V.bmeet11 = function (p) {
    const m = (B().mts || []).find(x => x.id === p.id);
    if (!m) return '<div class="calm">This meeting is gone.</div>';
    const N = m.N;
    let h = '<div class="card"><div class="bhead"><b>' + esc(dateStr(m.w)) + '</b><span class="pill">' + seats().length + ' members</span></div>' + row('Revenue last month', money(N.rev)) + row('Profit last month', '<span class="' + (N.prof >= 0 ? 'pos' : 'neg') + '">' + plus(N.prof) + '</span>') + row('Your cash', money(N.cash)) + row('Debt', money(N.debt)) + row('Net worth', money(N.nw)) + row('Staff', N.staff) + '</div>';
    h += '<h2 class="sec">Companies, last month · ' + esc((CO[S.country] || CC()).cur || '') + '</h2><div class="card tbl11"><div class="t11 hd"><span>Company</span><span>Revenue</span><span>Profit</span><span>Margin</span></div>' + N.rows.map(r => '<div class="t11"><span>' + esc(r.name) + '</span><span>' + kf(r.rev) + '</span><span class="' + (r.prof >= 0 ? 'pos' : 'neg') + '">' + kf(r.prof) + '</span><span>' + (r.m == null ? '–' : Math.round(r.m * 100) + '%') + '</span></div>').join('') + '</div>';
    h += '<h2 class="sec">On the table</h2>' + m.items.map((x, i) => {
      const n = S.npcs[x.who];
      const st = x.st === 'yes' ? '<span class="pill green">Taken</span>' : x.st === 'no' ? '<span class="pill">Not now</span>' : x.act ? '<div class="two">' + btn('Do it', 'b11yes', { m: m.id, i }, 'primary') + btn('Not now', 'b11no', { m: m.id, i }, 'ghost') + '</div>' : '';
      return '<div class="card"><div class="cchd">' + faceAv(n) + '<span class="ctext"><b>' + esc(n ? n.name : 'Board') + '</b><small>' + esc((seats().find(s => s.id === x.who) || {}).t || '') + '</small></span></div><p>' + esc(x.text) + '</p>' + st + '</div>';
    }).join('');
    return h;
  };
  function seatOf(id) { return seats().find(x => x.id === id); }
  ACT.b11yes = p => {
    const m = (B().mts || []).find(x => x.id === p.m), it = m && m.items[p.i];
    if (!it || it.st) return;
    it.st = 'yes';
    const s = seatOf(it.who);
    if (s) { s.ok++; s.mood = Math.min(100, s.mood + 4); }
    save();
    if (it.act === 'price') {
      const co = getCo(it.p.id);
      if (co) { co.price = Math.min(3, (co.price || 0) + 1); toast('Prices at ' + co.name + ' up one step.'); }
      render();
    } else if (it.act === 'go') {
      if (it.ph) { ui.tab = 'phone'; ui.ph = { n: it.p.n, p: it.p.p || {} }; ui.phStack = []; render(true); }
      else go(it.p.n, it.p.p);
    } else render();
  };
  ACT.b11no = p => {
    const m = (B().mts || []).find(x => x.id === p.m), it = m && m.items[p.i];
    if (!it || it.st) return;
    it.st = 'no';
    const s = seatOf(it.who);
    if (s) {
      s.no++;
      s.mood = Math.max(0, s.mood - 6);
      const n = S.npcs[s.id];
      if (s.kind === 'adv' && s.mood < 25 && n) {
        n.hired = 0;
        B().seats = B().seats.filter(x => x !== s);
        info(n.name, 'Leaving the board', 'You rarely take my advice, so I am stepping down from the board.', null, 'bad');
      }
    }
    save();
    render();
  };
  /* ---------- votes on big moves ---------- */
  function votes(kind, co, amt) {
    const L = seats();
    const H = (co && co.hist || []).slice(-3), p3 = sum(H, x => x.profit || 0), r3 = sum(H, x => x.rev || 0);
    const N = nums();
    return L.map(x => {
      const n = S.npcs[x.id], sk = seatSkill(x);
      let yes, why;
      if (kind === 'sell') { yes = p3 < 0 || (r3 > 0 && p3 / r3 < 0.02); why = yes ? (p3 < 0 ? 'It lost ' + mshort(-p3) + ' in three months.' : 'It barely makes money.') : 'It made ' + mshort(p3) + ' in three months. Keep it.'; }
      else if (kind === 'close') { yes = p3 < 0; why = yes ? 'Losses of ' + mshort(-p3) + ' in three months.' : 'It is profitable. Sell it rather than close it.'; }
      else { const yp = Math.max(1, N.prof * 12), ratio = (N.debt + amt) / yp; yes = ratio < 3 || N.prof > 0 && amt < N.cash; why = yes ? 'Debt stays at ' + ratio.toFixed(1) + ' years of profit.' : 'Debt would be ' + (ratio > 50 ? 'far more than' : ratio.toFixed(0) + ' times') + ' a year of profit.'; }
      if (Z() < 0.12 * (1 - sk / 100)) { yes = !yes; why = yes ? 'I see it differently: the risk is worth taking.' : 'I see it differently: it is too early to decide.'; }
      const lead = x.kind === 'adv' ? { fin: 'From the numbers: ', law: 'Legally fine, but ', ind: 'In this trade, ', mkt: 'For the brand, ', chair: 'Overall, ' }[x.type] || '' : '';
      return { id: x.id, name: n.name, yes, why: lead ? lead + why.charAt(0).toLowerCase() + why.slice(1) : why };
    });
  }
  function voteSheet(kind, co, amt, go2, label) {
    if (window.R12boards) return go2();
    const L = seats();
    if (L.length < 3) return go2();
    const V2 = votes(kind, co, amt), y = V2.filter(x => x.yes).length, nn = V2.length - y;
    const outside = co && co.own < 50;
    const pass = y > nn;
    ui.b11cont = () => {
      if (!pass) V2.filter(x => !x.yes).forEach(x => { const s = seatOf(x.id); if (s) s.mood = Math.max(0, s.mood - 10); });
      closeSheet();
      go2();
    };
    openSheet('<h2>Board vote: ' + esc(label) + '</h2><p class="muted small">' + y + ' for, ' + nn + ' against.' + (outside && !pass ? ' Outside owners hold ' + Math.round(100 - co.own) + '% of ' + esc(co.name) + ', so the no vote stops it.' : '') + '</p><div class="lrows">' + V2.map(x => '<div class="lrow">' + faceAv(S.npcs[x.id]) + '<span class="ctext"><b>' + esc(x.name) + ' · ' + (x.yes ? 'for' : 'against') + '</b><small>' + esc(x.why) + '</small></span></div>').join('') + '</div>' +
      (outside && !pass ? btn('OK', 'sheetclose', undefined, 'wide') : '<div class="two">' + btn(pass ? 'Go ahead' : 'Go ahead anyway', 'b11go', {}, pass ? 'primary' : 'danger') + btn('Cancel', 'sheetclose', undefined, 'ghost') + '</div>'));
  }
  ACT.b11go = () => { const f = ui.b11cont; ui.b11cont = null; if (f) f(); };
  const sg0 = ACT.salego;
  ACT.salego = p => {
    const co = getCo(p.id);
    if (!co || p.bv) return sg0(p);
    voteSheet('sell', co, 0, () => sg0(Object.assign({}, p, { bv: 1 })), 'sell ' + (p.pct === 100 ? co.name : p.pct + '% of ' + co.name));
  };
  const wu0 = ACT.winduo;
  ACT.winduo = p => {
    const co = getCo(p.id);
    if (!co || p.bv) return wu0(p);
    voteSheet('close', co, 0, () => wu0(Object.assign({}, p, { bv: 1 })), 'close ' + co.name);
  };
  const lg0 = ACT.loango;
  ACT.loango = p => {
    const co = getCo(p.id), a = Math.round(U.inum('lamt', 0));
    const g = document.getElementById('guar'), gv = g ? g.checked : false;
    if (!co || p.bv || a < KC(1000000)) return lg0(p);
    voteSheet('loan', co, a, () => {
      const el = document.createElement('input');
      el.type = 'checkbox'; el.id = 'guar'; el.checked = gv; el.style.display = 'none';
      document.body.appendChild(el);
      try { lg0(Object.assign({}, p, { bv: 1 })); } finally { el.remove(); }
    }, 'borrow ' + mshort(a) + ' for ' + co.name);
  };
  /* ---------- the weekly rhythm: named reviews, exec duties and reports, board fees and meetings ---------- */
  function scopeCos(n) {
    const rg = S.group && S.group.regional.find(r => r.npc === n.id);
    if (rg) return liveCos().filter(c => c.region === rg.id || rg.scope === 'all' || BD[c.type].cat === rg.scope);
    if (S.group && S.group.ceo && S.group.ceo.npc === n.id) return liveCos();
    return [];
  }
  function execWeek() {
    const ex = [];
    if (S.group && S.group.ceo) ex.push(S.group.ceo.npc);
    ((S.group && S.group.regional) || []).forEach(r => ex.push(r.npc));
    ex.forEach(id => {
      const n = S.npcs[id];
      if (!n || !n.k11) return;
      const q = qOf(n), L = scopeCos(n).filter(c => c.st === 'open');
      const d = n.k11.duties || [];
      L.forEach(c => {
        if (d.indexOf('quality') >= 0) c.q = clamp((c.q || 50) + 0.4 * q, 0, 100);
        if (d.indexOf('coach') >= 0 && c.mgr) c.mood = Math.min(85, (c.mood || 60) + 0.5 * q);
      });
      if (d.indexOf('hire') >= 0) {
        const need = L.find(c => !c.mgr && c.staff.length >= 2 && !(c.flags.f11 > S.week - 8));
        if (need) {
          need.flags.f11 = S.week;
          const m = genManager(need, BD[need.type].mgr);
          S.npcs[m.id] = m;
          addMsg({ kind: 'ask', from: n.name, title: 'I found a manager for ' + need.name, body: m.name + ', ' + m.age + ', ' + (m.exp || 5) + ' years of experience. Asks ' + money(m.ask) + ' a month. I checked the references.', co: need.id, opts: [{ l: 'Hire at ' + mshort(m.ask), d: '', fx: {} }, { l: 'No thanks', d: '', fx: {} }], act: 'mfind11', data: { n: m.id }, exp: S.week + 3 });
        }
      }
      const rep = n.k11.rep;
      const me = isMonthEnd(S.week);
      const bad = L.filter(c => { const h = c.hist && c.hist[c.hist.length - 1]; return h && h.profit < 0; });
      if ((rep === 'week') || (rep === 'month' && me) || (rep === 'need' && me && bad.length)) {
        const lines = L.slice(0, 8).map(c => { const h = (c.hist || [])[c.hist.length - 1] || {}; return c.name + ': revenue ' + mshort(h.rev || 0) + ', profit ' + mshort(h.profit || 0) + (c.mgr ? '' : ' (no manager)'); });
        addMsg({ kind: 'info', from: n.name, title: (rep === 'week' ? 'Weekly update' : 'Monthly report') + ' from your ' + (n.k11.t || 'manager').toLowerCase(), body: lines.join('\n') || 'Nothing to report.', tone: bad.length ? 'bad' : 'n', status: 'done' });
      }
      if (isYearEnd(S.week) && n.k11.bonus) {
        const pr = sum(L, c => sum((c.hist || []).slice(-12), x => x.profit || 0));
        if (pr > 0) payHQ(Math.round(n.k11.wage * 12 * n.k11.bonus), 'Bonus: ' + n.name);
      }
    });
  }
  ACTS.mfind11 = (m, idx) => {
    const co = getCo(m.co), n = S.npcs[m.data.n];
    if (!co || !n || idx !== 0 || co.mgr) return true;
    n.ask = n.ask || KC(50000);
    const r = hireManager(co, n, n.ask);
    if (r !== 'ok') info(n.name, 'Changed my mind', 'Sorry, I took another job.', co.id, 'bad');
    return true;
  };
  R7.afterWeek = R7.afterWeek || [];
  R7.afterWeek.push(() => {
    try { S.cos.forEach(co => { try { nrvWeek(co); } catch (e) { console.error(e); } }); } catch (e) { console.error(e); }
    try { execWeek(); } catch (e) { console.error(e); }
    try {
      const b = S.board;
      if (b && isMonthEnd(S.week) && !window.R12boards) {
        const fee = sum(seats(), x => x.fee || 0);
        if (fee) payMe(fee, 'Board fees');
        const mi = monthIdx(S.week) % 12;
        if ((b.freq !== 13 || mi % 3 === 2) && S.week - (b.last || -99) >= 2 && seats().length >= 2) holdMeeting();
      }
    } catch (e) { console.error(e); }
  });
  /* a way to the board from the group screen */
  const grp0 = V.group;
  if (grp0) V.group = function () {
    const h = grp0.apply(this, arguments);
    const L = seats();
    if (window.R12boardsCard) return window.R12boardsCard() + h;
    return '<button class="card opt2" data-a="go" data-p="' + P11({ n: 'board11', p: {} }) + '"><div class="bhead"><b>Board</b><span class="pill blue">' + L.length + ' of ' + MAXSEAT + ' seats ›</span></div><span class="tipt">' + (L.length ? L.map(x => first(S.npcs[x.id].name)).join(', ') : 'Promote managers or invite advisors') + '</span></button>' + h;
  };
}

import sys
path='/home/claude/work/ledger.html'
t=open(path,encoding='utf8').read()
def rep(old,new,count=1):
    global t
    n=t.count(old)
    if n!=count: raise SystemExit('MATCH %d (want %d) for: %s'%(n,count,old[:90]))
    t=t.replace(old,new)

# ---------- base.js: sections ----------
rep("""  const SECS = [['cos', 'Companies', 'biz'], ['hq', 'HQ', 'office'], ['home', 'Home', 'home']];
  const ROOT = { home: 'home', cos: 'cos', hq: 'hq', settings: 'settings' };""",
"""  const SECS = [['home', 'Home', 'home'], ['cos', 'Companies', 'biz'], ['phone', 'Phone', 'phone'], ['meet', 'Meetings', 'chat']];
  const ROOT = { home: 'home', cos: 'cos', meet: 'meetings' };""")
rep("""    office: 'hq',
    group: 'hq',
    dealroom: 'hq',
    exechire: 'hq',
    settings: 'settings',
    hq: 'hq',
    cos: 'cos',
    home: 'home'
  };""","""    office: 'cos',
    group: 'cos',
    dealroom: 'cos',
    exechire: 'cos',
    hq: 'cos',
    cos: 'cos',
    home: 'home',
    meetings: 'meet'
  };""")
rep("""    'meet',
    'stats'
  ];""","""    'meet',
    'stats',
    'settings',
    'phfolder',
    'clubs'
  ];
  const MEET_APPS = { msgs: 'msgs', mail: 'mail', meet: 'meet' };""")
# phoneGo / phBack
rep("""  function phoneGo(n, p) {
    if (ui.ph.n !== 'home') ui.phStack.push(ui.ph);
    ui.ph = { n, p: p || {} };
    ui.phoneOn = true;
    ui.inp = {};
    render(true);
  }""","""  function phoneGo(n, p) {
    if (MEET_APPS[n]) {
      if (ui.tab !== 'meet') ui.stack = [];
      ui.tab = 'meet';
      ui.mtab = MEET_APPS[n];
      ui.view = { n: 'meetings', p: {} };
      ui.inp = {};
      render(true);
      return;
    }
    if (ui.tab !== 'phone') {
      ui.phFrom = { tab: ui.tab, view: ui.view, stack: ui.stack.slice() };
      ui.phStack = [];
      ui.tab = 'phone';
    } else if (ui.ph.n !== 'home') ui.phStack.push(ui.ph);
    ui.ph = { n, p: p || {} };
    ui.phoneOn = true;
    ui.inp = {};
    render(true);
  }""")
rep("""    ui.thread = null;
    ui.threadCo = null;
    ui.ph = ui.phStack.length ? ui.phStack.pop() : { n: 'home', p: {} };
    ui.inp = {};
    render(true);
  }""","""    ui.thread = null;
    ui.threadCo = null;
    if (!ui.phStack.length && ui.phFrom) {
      const f = ui.phFrom;
      ui.phFrom = null;
      ui.ph = { n: 'home', p: {} };
      ui.tab = f.tab;
      ui.view = f.view;
      ui.stack = f.stack;
      ui.inp = {};
      render();
      return;
    }
    ui.ph = ui.phStack.length ? ui.phStack.pop() : { n: 'home', p: {} };
    ui.inp = {};
    render(true);
  }""")
# go(): leaving the phone tab for a main view
rep("""    ui.stack.push(Object.assign({}, ui.view, { tab: ui.tab }));
    if (SEC_OF[n]) ui.tab = SEC_OF[n];
    ui.view = { n, p };""","""    if (ui.tab === 'phone') {
      ui.stack.push(Object.assign({}, ui.view, { tab: 'phone', ph: ui.ph, phStack: ui.phStack.slice(), phFrom: ui.phFrom }));
      ui.tab = SEC_OF[n] || 'cos';
    } else {
      ui.stack.push(Object.assign({}, ui.view, { tab: ui.tab }));
      if (SEC_OF[n]) ui.tab = SEC_OF[n];
    }
    ui.view = { n, p };""")
rep("""    if (ui.stack.length) {
      const v = ui.stack.pop();
      ui.tab = v.tab || ui.tab;
      ui.view = { n: v.n, p: v.p };
    } else ui.view = { n: ROOT[ui.tab] || 'home', p: {} };
    ui.inp = {};
    render();
  }""","""    if (ui.stack.length) {
      const v = ui.stack.pop();
      ui.tab = v.tab || ui.tab;
      ui.view = { n: v.n, p: v.p };
      if (v.ph) {
        ui.ph = v.ph;
        ui.phStack = v.phStack || [];
        ui.phFrom = v.phFrom || null;
      }
    } else ui.view = { n: ROOT[ui.tab] || 'home', p: {} };
    ui.inp = {};
    render();
  }""")
rep("""  function tabTo(t) {
    if (t === 'phone') {
      ui.phoneOn = !ui.phoneOn;
      render();
      return;
    }
    if (PHONE_APPS.indexOf(t) >= 0) {
      ui.phStack = [];
      ui.ph = { n: 'home', p: {} };
      phoneGo(t, {});
      return;
    }""","""  function tabTo(t) {
    if (t === 'phone') {
      ui.tab = 'phone';
      ui.ph = { n: 'home', p: {} };
      ui.phStack = [];
      ui.phFrom = null;
      ui.thread = null;
      ui.inp = {};
      render(true);
      return;
    }
    if (MEET_APPS[t]) {
      phoneGo(t, {});
      return;
    }
    if (PHONE_APPS.indexOf(t) >= 0) {
      ui.tab = 'phone';
      ui.phStack = [];
      ui.phFrom = null;
      ui.ph = { n: 'home', p: {} };
      phoneGo(t, {});
      return;
    }
    if (t === 'meet' && ui.tab === 'meet') ui.mtab = 'dec';
    if (t === 'meet') ui.thread = null;""")
# render scroll keys
rep("""    const sc = app.querySelector('.screen'), pb = app.querySelector('.pbody');
    if (sc && !top) ui.scroll[ui.view.n + JSON.stringify(ui.view.p)] = sc.scrollTop;
    if (pb) ui.scroll['ph:' + ui.ph.n] = pb.scrollTop;""","""    const sc = app.querySelector('.screen');
    if (sc && !top && ui._sk) ui.scroll[ui._sk] = sc.scrollTop;""")
rep("""    const s2 = app.querySelector('.screen');
    if (s2) s2.scrollTop = top ? 0 : (ui.scroll[ui.view.n + JSON.stringify(ui.view.p)] || 0);
    const p2 = app.querySelector('.pbody');
    if (p2) p2.scrollTop = top ? 0 : (ui.scroll['ph:' + ui.ph.n] || 0);""","""    ui._sk = ui.tab === 'phone' ? 'ph:' + ui.ph.n + JSON.stringify(ui.ph.p) : ui.tab + ':' + ui.view.n + JSON.stringify(ui.view.p) + (ui.view.n === 'meetings' ? ui.mtab : '');
    const s2 = app.querySelector('.screen');
    if (s2) s2.scrollTop = top ? 0 : (ui.scroll[ui._sk] || 0);""")
# new shell
rep("""  function shell() {
    return '<div class="os">' + rail() + '<div class="col">' + topbar() + '<div class="stage"><main class="screen">' + (setCtx(ctxFromView()), locText(safe(V[ui.view.n], ui.view.p))) + (setCtx(null), '') + '</main>' + phoneHtml() + '</div></div></div>';
  }""","""  function vhead(title, sub, right, act) {
    return '<header class="vh"><button class="bk" data-a="' + (act || 'back') + '" aria-label="Back">' + svg('back', 18) + '</button><div class="vht"><h1>' + esc(title) + '</h1>' + (sub ? '<p>' + sub + '</p>' : '') + '</div>' + (right || '') + '</header>';
  }
  function isRoot() {
    return ui.tab !== 'phone' && ROOT[ui.tab] === ui.view.n && !ui.stack.length;
  }
  function navbar() {
    const n = (typeof meetCount === 'function') ? meetCount() : unreadBadge();
    return '<nav class="nb" aria-label="Main">' + SECS.map(t => '<button class="' + (ui.tab === t[0] ? 'on' : '') + '" data-a="tab" data-p="' + t[0] + '">' + svg(t[2], 24) + '<span>' + t[1] + '</span>' + (t[0] === 'meet' && n ? '<b class="nbd">' + n + '</b>' : '') + '</button>').join('') + '</nav>';
  }
  function mainBody() {
    if (ui.tab === 'phone') {
      if (ui.ph.n === 'home') return safe(V.phonehome);
      const ht = V.phtitle ? V.phtitle(ui.ph) : null;
      return vhead((ht && ht.t) || V.titles[ui.ph.n] || '', ht && ht.sub, ht && ht.right, 'phback') + safe(V[ui.ph.n], ui.ph.p);
    }
    setCtx(ctxFromView());
    let h;
    try {
      const body = safe(V[ui.view.n], ui.view.p);
      if (isRoot()) h = body;
      else {
        const hd = V.heads && V.heads[ui.view.n] ? V.heads[ui.view.n](ui.view.p) : {};
        h = vhead(hd.t || V.title(ui.view), hd.sub, hd.right) + body;
      }
      h = locText(h);
    } finally {
      setCtx(null);
    }
    return h;
  }
  function shell() {
    const k = ui.tab === 'phone' ? 'ph-' + ui.ph.n : 'v-' + ui.view.n;
    return '<div class="os2"><main class="screen ' + k + '">' + mainBody() + '</main>' + navbar() + '</div>';
  }""")
rep("""    ui.inPhone = !!t.closest('.phone');""","""    ui.inPhone = ui.tab === 'phone' && !t.closest('.scrim');""")
rep("""  ACT.phone = () => {
    ui.phoneOn = !ui.phoneOn;
    render();
  };""","""  ACT.phone = () => tabTo('phone');""")
rep("""  ACT.phhome = () => {
    ui.thread = null;
    ui.ph = { n: 'home', p: {} };
    ui.phStack = [];
    render(true);
  };""","""  ACT.phhome = () => tabTo('phone');""")
rep("""    phoneGo,
    AGE0,""","""    phoneGo,
    vhead,
    AGE0,""")
open(path,'w',encoding='utf8').write(t)
print('base ok')

/* ===== Round 18: rivals run their businesses like you do. They follow inflation (or hold prices), change prices now
   and then, run discounts where the trade allows, push marketing, sell shares and open next to your stores (you are told).
   The market price index is built from what the rivals actually charge. Plus new event types. ===== */
{
  const NOPRICE = { rent: 1, fin: 1, energy: 1, club: 1, hold: 1 };
  const DMAX = { cons: 15, tutor: 30, carclean: 30, photo: 25, handy: 15, cleaning: 20, webdev: 15, mktg: 15, barber: 25, drivsk: 15, physio: 10, pets: 25, foodtruck: 30, cafe: 30, restaurant: 25, nightclub: 20, gym: 40, hotel: 40, fun: 30, kiosk: 25, boutique: 40, webshop: 40, grocery: 25, hardware: 30, cardealer: 10, event: 10, bakery: 30, brewery: 20, furniture: 30, factory: 10, taxi: 15, courier: 20, airline: 40, parking: 20 };
  const h0 = (r, k) => hrng(S.seed + ':' + k + ':' + r.id)();
  /* a rival's own price, relative to the market: starts where the old fixed number was, then lives its own life */
  function initR(r) {
    if (r.pm16 == null) r.pm16 = Math.round((0.82 + h0(r, 'rp') * 0.4) * 1000) / 1000;
    if (r.ig16 == null) r.ig16 = 1;
    if (r.nx16 == null) r.nx16 = S.week + 4 + Math.floor(h0(r, 'nx') * 14);
    if (r.cash16 == null) r.cash16 = Math.round(rivalValue0(r) * 0.08);
  }
  const rivalValue0 = r => 1e6 * (r.size || 1);
  const effP = r => r.pm16 / (r.ig16 || 1) * (r.camp16 && S.week < r.camp16.end ? 1 - r.camp16.pct / 100 : 1);
  window.R18 = { effP };

  function mine(m) { return S.cos.filter(c => c.st === 'open' && S.mk[mkKey(c)] === m); }
  function rivalWeek() {
    const newYear = wYear(S.week) !== wYear(S.week - 1);
    const infl = (S.econ && S.econ.infl) || 0.02;
    Object.keys(S.mk || {}).forEach(key => {
      const m = S.mk[key], cos = mine(m);
      if (!cos.length || !m.riv || !m.riv.length) return;
      const co = cos[0], bd = BD[co.type];
      if (!bd || NOPRICE[bd.fam]) return;
      const util = co.lastW ? co.lastW.util || 0.7 : 0.7;
      /* rivals that matched your cut (the old engine moved the index) carry it into their own prices */
      if (m.pil16 && m.pi < m.pil16 - 0.02) m.riv.forEach(r => { initR(r); r.pm16 = clamp(r.pm16 * m.pi / m.pil16, 0.7, 1.6); });
      m.riv.forEach(r => {
        initR(r);
        /* inflation: most follow it, a few hold to win customers */
        if (newYear) {
          r.hold16 = h0(r, 'hold' + wYear(S.week)) < 0.15;
          if (r.hold16) note(r.name + ' is holding last year\'s prices in ' + cityOf(co.city).name + '.', 'n', co.id);
        }
        if (r.hold16) r.ig16 = (r.ig16 || 1) * (1 + infl / 52);
        /* regular price reviews: small steps, up when they are busy, down when quiet or when you are much cheaper */
        if (S.week >= r.nx16) {
          r.nx16 = S.week + 8 + rint(0, 14);
          const myP = priceMult(co) / (co.ig || 1);
          let dir = rng(-0.4, 0.6) + (util > 0.9 ? 0.4 : 0) - (myP < effP(r) - 0.08 ? 0.5 : 0) - (r.size < 0.7 ? 0.2 : 0);
          const step = (Math.abs(dir) < 0.2 ? 0 : Math.sign(dir)) * rng(0.02, 0.06);
          if (step) {
            r.pm16 = clamp(Math.round(r.pm16 * (1 + step) * 1000) / 1000, 0.7, 1.6);
            if (Math.abs(step) >= 0.04) note(r.name + (step > 0 ? ' raised' : ' cut') + ' its prices about ' + Math.round(Math.abs(step) * 100) + '%.', step > 0 ? 'n' : 'bad', co.id);
          }
        }
        /* discounts, where the trade does them */
        if (r.camp16 && S.week >= r.camp16.end) delete r.camp16;
        const dm = DMAX[co.type] || 0;
        if (dm && !r.camp16 && chance(0.012 + (util < 0.6 ? 0.01 : 0))) {
          const pct = Math.min(dm, [10, 15, 20, 25, 30, 40][rint(0, 3)]);
          r.camp16 = { pct, end: S.week + rint(1, 3) };
          note(r.name + ' runs ' + pct + '% off for ' + (r.camp16.end - S.week) + ' week' + (r.camp16.end - S.week > 1 ? 's' : '') + '.', 'bad', co.id);
        }
        /* marketing pushes */
        if (r.mkt16 && S.week >= r.mkt16) { delete r.mkt16; r.size = Math.round(r.size * 1.01 * 100) / 100; }
        if (!r.mkt16 && chance(0.01)) { r.mkt16 = S.week + rint(4, 10); note(r.name + ' started a big marketing campaign.', 'n', co.id); }
        /* selling shares to grow */
        if (!r.listed && !r.sold16 && r.size > 1.1 && chance(0.0015)) {
          r.sold16 = 1;
          r.size = Math.round(r.size * 1.15 * 100) / 100;
          news(r.name + ' sells a stake to investors and plans to grow.', 'n');
          note(r.name + ' raised money by selling shares. Expect them to expand.', 'n', co.id);
        }
      });
      /* opening next to you */
      if (chance(0.0025 * (m.aggr || 1)) && cos.some(c => (c.lastW && c.lastW.util > 0.85) || ratingOf(c) > 4)) {
        const big = m.riv.slice().sort((a, b) => b.size - a.size)[0];
        const tgt = cos[rint(0, cos.length - 1)];
        big.size = Math.round(big.size * 1.12 * 100) / 100;
        m.n++;
        addMod(tgt, 'dem', 0.92, 26);
        addMsg({ kind: 'info', from: 'Market', title: big.name + ' opens next to ' + tgt.name, body: big.name + ' has opened a new site a few doors from ' + tgt.name + ' in ' + cityOf(tgt.city).name + '. Expect fewer walk-ins for a while. You can answer with prices, marketing or a discount under Price moves.', co: tgt.id, tone: 'bad', status: 'done', go: { l: 'Price moves', a: 'go', p: { n: 'pricemoves', p: { id: tgt.id } } } });
      }
      /* the market index is what the rivals charge, weighted by size; campaigns and marketing push it */
      const W = sum(m.riv, r => r.size * (r.mkt16 ? 1.1 : 1));
      if (W > 0) {
        const pi = sum(m.riv, r => effP(r) * r.size * (r.mkt16 ? 1.1 : 1)) / W;
        m.pi = clamp(m.pi + (pi - m.pi) * 0.5, 0.7, 1.4);
        m.pil16 = m.pi;
      }
      m.str16 = m.riv.some(r => r.mkt16) ? 0.15 : 0;
    });
  }
  /* rival marketing pushes take a little more of the market */
  const rm0 = window.rivalMult;
  window.rivalMult = function (co, bd) {
    const v = rm0.apply(this, arguments);
    const m = S.mk[mkKey(co)];
    return m && m.str16 ? clamp(v * (1 - m.str16 * 0.3), 0.2, 1.25) : v;
  };
  R7.afterWeek = R7.afterWeek || [];
  R7.afterWeek.push(() => { try { rivalWeek(); } catch (e) { console.error(e); } });

  /* ---------- new events: variations on what already exists ---------- */
  const WK = c => Math.max(3000, c.wk), PAY = c => Math.max(4000, c.pay);
  ev('g_poach', 0.008, 'A rival is trying to hire away your best worker at {n}.', [
    { l: 'Match their offer', d: 'A 6% raise for that person.', fx: { raise: 0.06, stay: 0.95 } },
    { l: 'Give a one-off bonus', d: 'Cheaper, may not be enough.', fx: { bonus: c => PAY(c) * 0.3, stay: 0.6, raise: 0 } },
    { l: 'Let them go', d: 'Lose a good worker.', fx: { quit: 1 } }
  ], { cat: 'none', exp: 2 });
  ev('g_viral', 0.006, 'A customer\'s post about {n} is spreading online.', [
    { l: 'Join in and post back', d: 'Could go either way.', fx: { gamble: { p: 0.7, ok: { aware: 10, dem: [1.15, 4] }, bad: { rep: -2 } } } },
    { l: 'Stay quiet', d: 'Some of the buzz lands anyway.', fx: { aware: 4 } }
  ], { cat: 'none', tone: 'good', exp: 2 });
  ev('g_supbust', 0.005, 'The main supplier of {n} has gone bankrupt.', [
    { l: 'Switch fast to a dearer supplier', d: 'Costs up for a while.', fx: { price: [1.12, 8] } },
    { l: 'Wait for a cheap one', d: 'Shortages for a few weeks.', fx: { cap: [0.75, 3] } }
  ], { cat: 'none', exp: 2 });
  ev('g_power', 0.007, 'A power cut hits the street around {n}.', [
    { l: 'Rent a generator', d: '', fx: { cash: c => -Math.max(4000, WK(c) * 0.04) } },
    { l: 'Close for the day', d: '', fx: { cap: [0.8, 1] } }
  ], { cat: 'prop', exp: 1 });
  ev('g_roadwork', 0.006, 'Roadworks outside {n} will block the street for weeks.', [
    { l: 'Pay for signs and a detour map', d: '', fx: { cash: c => -Math.max(5000, WK(c) * 0.05), dem: [0.94, 8] } },
    { l: 'Live with it', d: '', fx: { dem: [0.85, 8] } }
  ], { cat: 'none', exp: 2 });
  ev('g_fakerev', 0.005, 'Someone is posting fake bad reviews about {n}.', [
    { l: 'Hire a firm to get them removed', d: '', fx: { cash: c => -Math.max(8000, WK(c) * 0.06), gamble: { p: 0.75, ok: {}, bad: { rep: -1 } } } },
    { l: 'Answer each one politely', d: 'Takes time, often works.', fx: { gamble: { p: 0.5, ok: { rep: 1 }, bad: { rep: -2 } } } },
    { l: 'Ignore them', d: '', fx: { rep: -3 } }
  ], { cat: 'none', exp: 3 });
  ev('g_latepay', 0.006, 'A big customer of {n} is paying late.', [
    { l: 'Send it to debt collection', d: 'You get most of it, they leave.', fx: { cash: c => -WK(c) * 0.08, rep: -1 } },
    { l: 'Give them time', d: 'They might never pay.', fx: { gamble: { p: 0.65, ok: {}, bad: { loss: c => WK(c) * 0.5 } } } }
  ], { cat: 'none', exp: 3 });
  ev('g_idea', 0.007, 'A worker at {n} has an idea to do the work better.', [
    { l: 'Try it out', d: 'Small cost, may lift quality.', fx: { cash: c => -Math.max(3000, WK(c) * 0.03), gamble: { p: 0.6, ok: { q: 4 }, bad: {} } } },
    { l: 'Thank them, change nothing', d: '', fx: {} }
  ], { cat: 'none', tone: 'good', exp: 2 });
  ev('g_influencer', 0.005, 'An influencer wants free service from {n} in return for a post.', [
    { l: 'Say yes', d: '', fx: { cash: c => -Math.max(2000, WK(c) * 0.02), gamble: { p: 0.55, ok: { aware: 8 }, bad: { aware: 1 } } } },
    { l: 'No thanks', d: '', fx: {} }
  ], { cat: 'none', tone: 'good', exp: 2 });
  ev('g_theft', 0.005, 'Thieves broke into {n} during the night.', [
    { l: 'Repair and add an alarm', d: 'Insurance covers if you have it.', fx: { loss: c => Math.max(15000, c.eqv * 0.06), cash: c => -Math.max(5000, WK(c) * 0.03) } },
    { l: 'Just repair', d: 'It may happen again.', fx: { loss: c => Math.max(15000, c.eqv * 0.06) } }
  ], { cat: 'prop', exp: 2 });
  ev('g_heat', 0.006, 'A heatwave hits the city of {n}.', [
    { l: 'Extend hours and stock up', d: '', fx: { cash: c => -WK(c) * 0.03, dem: [1.12, 2] } },
    { l: 'Business as usual', d: '', fx: { dem: [1.04, 2] } }
  ], { cat: 'none', tone: 'good', exp: 1 });
  const ADD = {
    g_poach: ['svc', 'venue', 'retail', 'project', 'prod', 'logi'], g_viral: ['svc', 'venue', 'retail'], g_supbust: ['venue', 'retail', 'prod', 'project'],
    g_power: ['venue', 'retail', 'prod', 'svc'], g_roadwork: ['venue', 'retail'], g_fakerev: ['svc', 'venue', 'retail'], g_latepay: ['svc', 'project', 'prod', 'logi'],
    g_idea: ['svc', 'venue', 'retail', 'project', 'prod', 'logi'], g_influencer: ['venue', 'retail'], g_theft: ['retail', 'venue', 'prod', 'project'], g_heat: ['venue']
  };
  Object.keys(BD).forEach(id => { const bd = BD[id]; Object.keys(ADD).forEach(e => { if (ADD[e].indexOf(bd.fam) >= 0 && bd.ev.indexOf(e) < 0) bd.ev.push(e); }); });
}

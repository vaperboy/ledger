/* ===== Round 6a: picture library. Small flat drawings for every kind of thing you can buy, faces for people,
   and procedural framed art with a full view. Everything is drawn in code, so it is seeded and always the same
   for the same item. Replace any of these with real images later by mapping the same kind names to files. ===== */
{
  const hh = s => { s = String(s); let h = 2166136261; for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619); return h >>> 0; };
  const rr = seed => { let a = hh(seed) || 7; return () => { a ^= a << 13; a >>>= 0; a ^= a >> 17; a ^= a << 5; a >>>= 0; return a / 4294967296; }; };
  const pk = (R, a) => a[Math.floor(R() * a.length) % a.length];
  const PAINT = ['#c9cdd2', '#2b2f36', '#f2f2ef', '#8e1f24', '#1f4e8c', '#3d6b4f', '#b9884a', '#6b6f78', '#d9a441', '#5b3a6e', '#0f3b3a'];
  const GL = '#9fc3d8';
  const wheel = (x, y, r) => '<circle cx="' + x + '" cy="' + y + '" r="' + r + '" fill="#18191c"/><circle cx="' + x + '" cy="' + y + '" r="' + (r * 0.45) + '" fill="#9aa0a6"/>';
  const D = {};
  D.car = (R, o) => {
    const c = o.c || pk(R, PAINT);
    const low = o.lux ? 2 : 0;
    return '<path d="M5 ' + (28) + 'L7 ' + (21 + low) + 'Q9 ' + (17 + low) + ' 15 ' + (16 + low) + 'L23 ' + (12 + low) + 'Q28 ' + (10 + low) + ' 36 ' + (10 + low) + 'L44 ' + (11 + low) + 'Q49 ' + (12 + low) + ' 52 ' + (16 + low) + 'L58 ' + (19 + low) + 'Q61 ' + (21 + low) + ' 61 25L61 28Z" fill="' + c + '"/>' +
      '<path d="M22 ' + (15.5 + low) + 'L27 ' + (12.6 + low) + 'Q30 ' + (11.6 + low) + ' 35 ' + (11.6 + low) + 'L35 ' + (15.5 + low) + 'ZM37 ' + (11.6 + low) + 'L43 ' + (12.2 + low) + 'Q47 ' + (13 + low) + ' 49.5 ' + (15.5 + low) + 'L37 ' + (15.5 + low) + 'Z" fill="' + GL + '"/>' +
      '<rect x="57" y="21" width="3" height="2" rx="1" fill="#ffe7a8"/><rect x="5.5" y="22" width="2.5" height="2" rx="1" fill="#d9573e"/>' +
      (o.taxi ? '<rect x="31" y="' + (6 + low) + '" width="9" height="4" rx="1" fill="#f4c430"/>' : '') + (o.ev ? '<path d="M41 21l-2 3h2l-1 3 3-4h-2l1-2z" fill="#7fe3a5"/>' : '') + wheel(17, 28, 5) + wheel(50, 28, 5);
  };
  D.van = (R, o) => {
    const c = o.c || pk(R, ['#f2f2ef', '#f2f2ef', '#c9cdd2', '#1f4e8c', '#2b2f36', '#d9a441']);
    return '<path d="M4 29V11q0-3 3-3h31l9 2 8 8q4 2 4 6v5z" fill="' + c + '" stroke="rgba(0,0,0,.18)" stroke-width=".6"/><path d="M40 10.5l7 1.5 7 6.5H40z" fill="' + GL + '"/><path d="M26 10v18" stroke="rgba(0,0,0,.25)" stroke-width=".7"/>' +
      (o.stripe ? '<rect x="4" y="18" width="36" height="3" fill="' + o.stripe + '"/>' : '') + (o.ev ? '<path d="M15 14l-2 3h2l-1 3 3-4h-2l1-2z" fill="#3aa86b"/>' : '') + wheel(14, 29, 5) + wheel(48, 29, 5);
  };
  D.boxvan = (R, o) => {
    const c = o.c || pk(R, ['#e06a2c', '#1f4e8c', '#3d6b4f', '#8e1f24']);
    return '<rect x="2" y="4" width="40" height="24" rx="2" fill="#f1efe9" stroke="rgba(0,0,0,.18)" stroke-width=".6"/><rect x="2" y="16" width="40" height="4" fill="' + c + '"/><path d="M42 11h9l8 7q2 2 2 5v6H42z" fill="' + c + '"/><path d="M44 13h6l5 5H44z" fill="' + GL + '"/>' + wheel(12, 29, 5) + wheel(51, 29, 5);
  };
  D.truck = (R, o) => {
    const c = o.c || pk(R, PAINT);
    return '<rect x="1" y="6" width="41" height="20" rx="1" fill="#e8e6e0" stroke="rgba(0,0,0,.18)" stroke-width=".6"/><path d="M44 8h9q4 0 5 4l3 7v9H44z" fill="' + c + '"/><path d="M47 10h6q2 0 3 3l1 4H47z" fill="' + GL + '"/>' + wheel(8, 29, 4.2) + wheel(17, 29, 4.2) + wheel(48, 29, 4.2) + wheel(57, 29, 4.2);
  };
  D.bus = (R, o) => {
    const c = o.c || pk(R, ['#c33b2e', '#1f4e8c', '#3d6b4f', '#d9a441']);
    let w = '';
    for (let x = 8; x < 54; x += 9) w += '<rect x="' + x + '" y="11" width="7" height="7" rx="1" fill="' + GL + '"/>';
    return '<rect x="3" y="7" width="58" height="21" rx="4" fill="' + c + '"/>' + w + '<rect x="55" y="11" width="5" height="14" rx="1" fill="' + GL + '"/>' + wheel(15, 28, 4.5) + wheel(49, 28, 4.5);
  };
  D.bike = (R, o) => {
    const c = o.c || pk(R, ['#3aa86b', '#1f4e8c', '#e06a2c', '#2b2f36']);
    return '<g fill="none" stroke="#18191c" stroke-width="2"><circle cx="14" cy="28" r="7"/><circle cx="50" cy="28" r="7"/></g><path d="M14 28l12-12h14l10 12M26 16l-2-4h-4M40 16l3-6h4" fill="none" stroke="' + c + '" stroke-width="2.4" stroke-linecap="round"/><rect x="4" y="13" width="16" height="10" rx="1.5" fill="' + c + '" opacity=".85"/>';
  };
  D.scooter = (R, o) => {
    const c = o.c || pk(R, ['#c33b2e', '#f2f2ef', '#3aa86b']);
    return '<path d="M14 27h26q6 0 9-6l3-11h4" fill="none" stroke="#18191c" stroke-width="2"/><path d="M10 26q2-8 10-8h14l-3 9z" fill="' + c + '"/><rect x="5" y="13" width="12" height="9" rx="1.5" fill="#e8e6e0"/>' + wheel(14, 29, 4.5) + wheel(50, 29, 4.5);
  };
  D.plant = () => '<rect x="4" y="25" width="34" height="7" rx="3.5" fill="#2b2f36"/><rect x="8" y="14" width="22" height="11" rx="1" fill="#e0a526"/><rect x="11" y="9" width="11" height="9" rx="1" fill="#e0a526"/><rect x="13" y="10.5" width="7" height="5" fill="' + GL + '"/><path d="M28 16l14-10 12 10" fill="none" stroke="#e0a526" stroke-width="3.5" stroke-linejoin="round"/><path d="M52 15l6 8h-9z" fill="#5d5f63"/>';
  D.crane = () => '<rect x="4" y="22" width="40" height="7" rx="1" fill="#e0a526"/><path d="M20 22L58 4" stroke="#e0a526" stroke-width="3"/><path d="M58 4v16" stroke="#18191c" stroke-width=".8"/><rect x="55" y="20" width="6" height="4" fill="#5d5f63"/><rect x="36" y="14" width="9" height="8" fill="#d39a1f"/>' + wheel(10, 30, 3.5) + wheel(20, 30, 3.5) + wheel(36, 30, 3.5);
  D.ship = (R) => {
    const cs = ['#c33b2e', '#1f4e8c', '#3d6b4f', '#d9a441'];
    let b = '';
    for (let i = 0; i < 4; i++) b += '<rect x="' + (12 + i * 8) + '" y="13" width="7" height="7" fill="' + pk(R, cs) + '"/>';
    return '<path d="M2 21h60l-6 9H8z" fill="#2b2f36"/><rect x="50" y="9" width="8" height="12" fill="#f2f2ef"/><rect x="51.5" y="11" width="5" height="2" fill="' + GL + '"/>' + b + '<path d="M0 33q8-2 16 0t16 0 16 0 16 0" fill="none" stroke="#6aa6c9" stroke-width="1.5"/>';
  };
  D.boat = () => '<path d="M6 22h48l-5 8H12z" fill="#e8e6e0"/><rect x="30" y="13" width="14" height="9" fill="#d9a441"/><rect x="32" y="15" width="10" height="3" fill="' + GL + '"/><path d="M0 33q8-2 16 0t16 0 16 0 16 0" fill="none" stroke="#6aa6c9" stroke-width="1.5"/>';
  D.plane = () => '<path d="M4 20q0-3 6-3h40q8 0 11 3-3 3-11 3H10q-6 0-6-3z" fill="#f2f2ef" stroke="rgba(0,0,0,.2)" stroke-width=".6"/><path d="M22 20l8-14h4l-3 14zM22 21l8 12h4l-3-12z" fill="#c9cdd2"/><path d="M5 18l-1-9h4l5 9z" fill="#1f4e8c"/><circle cx="28" cy="10" r="2.6" fill="none" stroke="#5d5f63"/><circle cx="28" cy="31" r="2.6" fill="none" stroke="#5d5f63"/>';
  D.jet = (R) => {
    const c = pk(R, ['#1f4e8c', '#8e1f24', '#2b2f36', '#b9884a']);
    let w = '';
    for (let x = 20; x < 46; x += 5) w += '<circle cx="' + x + '" cy="19" r="1" fill="#5d5f63"/>';
    return '<path d="M3 20q0-3 8-3h36q10 0 14 3-4 3-14 3H11q-8 0-8-3z" fill="#f4f4f1" stroke="rgba(0,0,0,.2)" stroke-width=".6"/><path d="M26 21l12 11h4l-6-11z" fill="#d6d6d2"/><path d="M5 17l-2-8h4l7 8z" fill="' + c + '"/><path d="M3 21.5h50" stroke="' + c + '" stroke-width="1.4"/>' + w;
  };
  D.yacht = () => '<path d="M2 23h58l-8 7H10z" fill="#f4f4f1" stroke="rgba(0,0,0,.2)" stroke-width=".6"/><path d="M12 23l4-6h30l6 6z" fill="#f4f4f1" stroke="rgba(0,0,0,.2)" stroke-width=".6"/><path d="M18 17l3-4h18l4 4z" fill="#f4f4f1" stroke="rgba(0,0,0,.2)" stroke-width=".6"/><path d="M15 21h33M21 15.5h19" stroke="#2b2f36" stroke-width="1.6"/><path d="M0 33q8-2 16 0t16 0 16 0 16 0" fill="none" stroke="#6aa6c9" stroke-width="1.5"/>';
  D.watch = (R) => {
    const c = pk(R, ['#c8a24a', '#c9cdd2', '#2b2f36']);
    return '<rect x="25" y="2" width="14" height="36" rx="3" fill="#5a3b25"/><circle cx="32" cy="20" r="11" fill="' + c + '"/><circle cx="32" cy="20" r="8.6" fill="#f6f3ea"/><path d="M32 20V14M32 20l4 2" stroke="#18191c" stroke-width="1.3" stroke-linecap="round"/><rect x="43" y="18.6" width="2.4" height="2.8" rx=".6" fill="' + c + '"/>';
  };
  D.jewel = () => '<path d="M14 6q18 22 36 0" fill="none" stroke="#c8a24a" stroke-width="1.6"/><path d="M32 18l5 5-5 9-5-9z" fill="#bfe6f2" stroke="#7fb6c9" stroke-width=".8"/><circle cx="20" cy="12" r="1.4" fill="#e6f6fb"/><circle cx="44" cy="12" r="1.4" fill="#e6f6fb"/>';
  D.wine = () => '<path d="M18 4h6v7q4 3 4 8v15q0 2-2 2h-10q-2 0-2-2V19q0-5 4-8z" fill="#3a1620"/><rect x="15" y="20" width="11" height="8" fill="#e8e1cf"/><path d="M38 12h12q0 9-6 10v8h4v2h-10v-2h4v-8q-6-1-6-10z" fill="rgba(200,220,230,.35)" stroke="#9aa0a6" stroke-width=".8"/><path d="M39 15h10q-1 5-5 6-4-1-5-6z" fill="#8e1f24"/>';
  D.comic = (R) => '<rect x="20" y="3" width="25" height="34" rx="1" fill="' + pk(R, ['#d9573e', '#1f4e8c', '#d9a441']) + '"/><rect x="22" y="5" width="21" height="7" fill="#f4c430"/><circle cx="32" cy="24" r="7" fill="#f2f2ef"/><path d="M28 24l3 3 5-6" stroke="#18191c" stroke-width="1.5" fill="none"/>';
  D.laptop = (R, o) => '<rect x="12" y="6" width="40" height="24" rx="2" fill="#2b2f36"/><rect x="14.5" y="8.5" width="35" height="19" fill="' + (o.c || '#3e6e8e') + '"/><path d="M6 31h52l-3 4H9z" fill="#c9cdd2"/>' + (o.phone ? '<rect x="52" y="14" width="8" height="15" rx="1.5" fill="#18191c"/>' : '');
  D.phone = () => '<rect x="23" y="2" width="18" height="36" rx="3" fill="#18191c"/><rect x="25" y="5" width="14" height="28" fill="#3e6e8e"/>';
  D.soft = (R, o) => {
    const c = o.c || pk(R, ['#3e6e8e', '#3d6b4f', '#5b3a6e', '#b9884a']);
    return '<rect x="6" y="4" width="52" height="32" rx="3" fill="#f2f2ef"/><rect x="6" y="4" width="52" height="6" rx="3" fill="' + c + '"/><circle cx="10" cy="7" r="1" fill="#fff"/><circle cx="13.5" cy="7" r="1" fill="#fff"/><rect x="10" y="14" width="12" height="18" rx="1" fill="#dcdcd6"/><rect x="26" y="14" width="28" height="3" rx="1" fill="' + c + '" opacity=".7"/><rect x="26" y="20" width="22" height="2.4" rx="1" fill="#c9cdd2"/><rect x="26" y="25" width="25" height="2.4" rx="1" fill="#c9cdd2"/><path d="M28 32l5-4 4 2 6-6" fill="none" stroke="' + c + '" stroke-width="1.4"/>';
  };
  D.tool = (R) => {
    const c = pk(R, ['#e0a526', '#c33b2e', '#1f4e8c', '#3aa86b']);
    return '<path d="M10 10h28q4 0 4 4v4q0 4-4 4H22l-2 14h-8l2-14h-4q-2 0-2-2v-8q0-2 2-2z" fill="' + c + '"/><rect x="42" y="13" width="12" height="4" fill="#5d5f63"/><rect x="54" y="14.2" width="6" height="1.6" fill="#9aa0a6"/><rect x="11" y="28" width="10" height="9" rx="1.5" fill="#2b2f36"/>';
  };
  D.machine = (R) => {
    const c = pk(R, ['#3e6e8e', '#3d6b4f', '#c9cdd2', '#e0a526']);
    return '<rect x="8" y="6" width="48" height="28" rx="2" fill="' + c + '"/><rect x="12" y="10" width="20" height="14" rx="1" fill="#1b2a33"/><path d="M14 20l4-4 4 3 4-5 4 2" fill="none" stroke="#7fe3a5" stroke-width="1.2"/><circle cx="44" cy="15" r="5" fill="#f2f2ef"/><path d="M44 15l3-2" stroke="#c33b2e" stroke-width="1.2"/><rect x="38" y="25" width="14" height="4" rx="1" fill="#2b2f36"/><rect x="10" y="34" width="6" height="3" fill="#2b2f36"/><rect x="48" y="34" width="6" height="3" fill="#2b2f36"/>';
  };
  D.kitchen = () => '<rect x="10" y="10" width="44" height="26" rx="1.5" fill="#c9cdd2"/><rect x="10" y="6" width="44" height="5" rx="1" fill="#9aa0a6"/><circle cx="20" cy="8.5" r="1.2" fill="#c33b2e"/><circle cx="26" cy="8.5" r="1.2" fill="#2b2f36"/><rect x="15" y="15" width="34" height="16" rx="1.5" fill="#2b2f36"/><rect x="18" y="18" width="28" height="10" fill="#e07a3e" opacity=".55"/>';
  D.fridge = () => '<rect x="18" y="2" width="28" height="36" rx="2" fill="#e8e6e0" stroke="rgba(0,0,0,.2)" stroke-width=".6"/><path d="M18 14h28" stroke="#9aa0a6"/><rect x="20" y="16" width="24" height="20" fill="#bfe6f2" opacity=".5"/><rect x="41" y="5" width="1.6" height="6" fill="#9aa0a6"/>';
  D.furn = (R) => {
    const c = pk(R, ['#7a5230', '#3e6e8e', '#2b2f36', '#b9884a']);
    return '<rect x="8" y="14" width="30" height="3" fill="' + c + '"/><path d="M10 17v19M36 17v19" stroke="' + c + '" stroke-width="2.2"/><path d="M44 8h10v14H42z" fill="#5d5f63"/><rect x="41" y="21" width="14" height="4" rx="1" fill="#5d5f63"/><path d="M48 25v10M43 36h10" stroke="#2b2f36" stroke-width="2"/><rect x="12" y="8" width="14" height="6" rx="1" fill="#2b2f36"/>';
  };
  D.building = (R) => {
    let w = '';
    for (let y = 9; y < 34; y += 5) for (let x = 22; x < 42; x += 6) w += '<rect x="' + x + '" y="' + y + '" width="4" height="3" fill="' + (R() > 0.3 ? '#ffe7a8' : GL) + '"/>';
    return '<rect x="19" y="5" width="26" height="33" fill="#3a4250"/>' + w + '<rect x="6" y="18" width="12" height="20" fill="#5d6574"/><rect x="46" y="14" width="12" height="24" fill="#4b5361"/><rect x="29" y="31" width="6" height="7" fill="#1b1c1f"/>';
  };
  D.house = () => '<path d="M10 20L32 4l22 16" fill="#8e1f24"/><rect x="14" y="19" width="36" height="18" fill="#f2f2ef"/><rect x="29" y="26" width="7" height="11" fill="#7a5230"/><rect x="18" y="23" width="7" height="6" fill="' + GL + '"/><rect x="40" y="23" width="7" height="6" fill="' + GL + '"/>';
  D.camera = () => '<rect x="10" y="12" width="44" height="24" rx="3" fill="#2b2f36"/><rect x="18" y="8" width="12" height="5" rx="1" fill="#2b2f36"/><circle cx="34" cy="24" r="9" fill="#18191c"/><circle cx="34" cy="24" r="5.5" fill="#3e6e8e"/><circle cx="48" cy="16" r="1.5" fill="#d9573e"/>';
  D.pos = () => '<rect x="20" y="4" width="24" height="32" rx="3" fill="#2b2f36"/><rect x="23" y="7" width="18" height="10" fill="#3e6e8e"/><g fill="#9aa0a6"><rect x="23" y="20" width="4.6" height="3"/><rect x="29.7" y="20" width="4.6" height="3"/><rect x="36.4" y="20" width="4.6" height="3"/><rect x="23" y="25" width="4.6" height="3"/><rect x="29.7" y="25" width="4.6" height="3"/><rect x="36.4" y="25" width="4.6" height="3"/></g><rect x="26" y="1" width="12" height="4" fill="#f2f2ef"/>';
  D.av = () => '<rect x="12" y="4" width="18" height="32" rx="2" fill="#2b2f36"/><circle cx="21" cy="12" r="4" fill="#5d5f63"/><circle cx="21" cy="26" r="7" fill="#5d5f63"/><circle cx="21" cy="26" r="3" fill="#18191c"/><path d="M38 10h18v4H38zM42 14v20M52 14v20" stroke="#9aa0a6" stroke-width="1.6" fill="none"/><circle cx="42" cy="18" r="2.4" fill="#ffe7a8"/><circle cx="52" cy="18" r="2.4" fill="#ffe7a8"/>';
  D.box = (R) => '<path d="M14 12l18-7 18 7v18l-18 7-18-7z" fill="' + pk(R, ['#b9884a', '#c9a06a']) + '"/><path d="M14 12l18 7 18-7M32 19v18" fill="none" stroke="rgba(0,0,0,.25)"/>';
  D.doc = () => '<path d="M18 3h20l8 8v26H18z" fill="#f2f2ef"/><path d="M38 3v8h8" fill="#dcdcd6"/><path d="M22 18h20M22 23h20M22 28h14" stroke="#9aa0a6" stroke-width="1.6"/>';
  D.cards = () => '<rect x="10" y="10" width="40" height="24" rx="3" fill="#1f4e8c"/><rect x="14" y="6" width="40" height="24" rx="3" fill="#c8a24a"/><rect x="18" y="12" width="7" height="5" rx="1" fill="#e8e1cf"/>';

  function picSvg(kind, seed, o) {
    o = o || {};
    const R = rr(kind + ':' + seed);
    const f = D[kind] || D.box;
    return '<svg viewBox="0 0 64 40" aria-hidden="true">' + f(R, o) + '</svg>';
  }
  window.pic = function (kind, seed, o, cls) {
    return '<span class="pic ' + (cls || '') + '">' + picSvg(kind, seed, o) + '</span>';
  };
  window.picSvg = picSvg;

  /* ---------- faces ---------- */
  const SKIN = ['#f5d6c0', '#eac3a3', '#d9a77f', '#b9825b', '#8d5a3b', '#5e3b26'];
  const HAIR = ['#2a1d16', '#4a3020', '#7a5230', '#b08a50', '#d8c08a', '#1b1b1b', '#8a3b22'];
  const SHIRT = ['#3e6e8e', '#3d6b4f', '#8e1f24', '#2b2f36', '#b9884a', '#5b3a6e', '#c9cdd2'];
  const BGF = ['#2a3340', '#33302a', '#2b3a33', '#3a2d33', '#2d2f3a'];
  function faceSvg(seed, age) {
    const R = rr('face:' + seed);
    const sk = pk(R, SKIN), st = Math.floor(R() * 6), gl = R() < 0.22, beard = R() < 0.22;
    let hc = pk(R, HAIR);
    if (age >= 56) hc = R() < 0.5 ? '#bdbdbd' : '#dcdcdc'; else if (age >= 46 && R() < 0.4) hc = '#8d8d8d';
    const sh = pk(R, SHIRT);
    let hair = '';
    if (st === 0) hair = '<path d="M11 17q0-9 9-9t9 9q-2-5-9-5t-9 5z" fill="' + hc + '"/>';
    else if (st === 1) hair = '<path d="M10.6 18q-1-10 9.4-10.4 9-.2 9.6 9.4-4-5-11-4.6-5 .4-8 5.6z" fill="' + hc + '"/>';
    else if (st === 2) hair = '<path d="M10 30q-2-13 1-17 3-5 9-5t9 5q3 4 1 17h-3q1-8-1-13-3-3-6-3t-6 3q-2 5-1 13z" fill="' + hc + '"/>';
    else if (st === 3) hair = '<circle cx="20" cy="6.6" r="3.4" fill="' + hc + '"/><path d="M11 17q0-9 9-9t9 9q-3-6-9-6t-9 6z" fill="' + hc + '"/>';
    else if (st === 4) hair = '<path d="M10.4 17q-1-3 1-5 0-4 4-4 2-2 5-1 3-1 5 1 4 0 4 4 2 2 1 5-2-4-10-4t-10 4z" fill="' + hc + '"/>';
    else hair = '<path d="M12 14q2-5 8-5t8 5q-3-2-8-2t-8 2z" fill="' + hc + '" opacity=".7"/>';
    return '<svg viewBox="0 0 40 40" aria-hidden="true"><circle cx="20" cy="20" r="20" fill="' + pk(R, BGF) + '"/><path d="M6 40q1-9 14-9t14 9z" fill="' + sh + '"/><rect x="17" y="25" width="6" height="7" fill="' + sk + '"/>' +
      '<ellipse cx="20" cy="18.5" rx="8.4" ry="9.6" fill="' + sk + '"/><ellipse cx="11.6" cy="19" rx="1.4" ry="2" fill="' + sk + '"/><ellipse cx="28.4" cy="19" rx="1.4" ry="2" fill="' + sk + '"/>' + hair +
      '<circle cx="16.8" cy="18.6" r="1" fill="#1b1b1b"/><circle cx="23.2" cy="18.6" r="1" fill="#1b1b1b"/><path d="M15.2 16.2h3M21.8 16.2h3" stroke="' + (age >= 56 ? '#9a9a9a' : hc) + '" stroke-width=".9" stroke-linecap="round"/>' +
      (beard ? '<path d="M12.4 21q.6 8 7.6 8.4 7-.4 7.6-8.4-2 4-7.6 4.4-5.6-.4-7.6-4.4z" fill="' + hc + '"/>' : '') +
      '<path d="M17.4 23.6q2.6 1.6 5.2 0" fill="none" stroke="#7a3b2e" stroke-width=".9" stroke-linecap="round"/>' +
      (gl ? '<g fill="none" stroke="#18191c" stroke-width=".8"><circle cx="16.8" cy="18.6" r="2.6"/><circle cx="23.2" cy="18.6" r="2.6"/><path d="M19.4 18.6h1.2"/></g>' : '') + '</svg>';
  }
  window.faceSvg = faceSvg;
  /* a person avatar: takes an NPC (or anything with id/name/age) */
  window.faceAv = function (n, cls) {
    if (!n) return '<span class="av ' + (cls || '') + '">?</span>';
    return '<span class="av face ' + (cls || '') + '">' + faceSvg(n.id != null ? n.id + ':' + n.name : n.name, n.age || 35) + '</span>';
  };

  /* ---------- framed art ---------- */
  const FRAMES = { gold: ['#c8a24a', '#8a6a22', '#e6cf86'], black: ['#18191c', '#000', '#3a3b3f'], wood: ['#8a5a32', '#5e3b20', '#b07a4a'], white: ['#efeee8', '#c9c8c0', '#ffffff'] };
  function artSvg(seed, opt) {
    opt = opt || {};
    const R = rr('art:' + seed);
    const W = 120, H = 92;
    const style = opt.style || pk(R, ['fields', 'land', 'geo', 'portrait', 'grid']);
    const fr = FRAMES[opt.frame || pk(R, ['gold', 'black', 'wood', 'white'])];
    const mat = opt.mat != null ? opt.mat : style === 'geo' || style === 'grid' ? 7 : 0;
    const ft = opt.frame === 'white' ? 4 : 8;
    const x0 = ft + mat, y0 = ft + mat, w = W - 2 * x0, h = H - 2 * y0;
    const pal = pk(R, [['#1d3557', '#e63946', '#f1faee', '#a8dadc'], ['#2d1e2f', '#e0a526', '#c84b31', '#f2e9d8'], ['#0f3b3a', '#8fbf9f', '#f2c14e', '#f78154'], ['#3b2f2f', '#a05c3b', '#e7c59a', '#6b8f71'], ['#22223b', '#4a4e69', '#9a8c98', '#f2e9e4']]);
    let p = '';
    if (style === 'fields') {
      p = '<rect x="' + x0 + '" y="' + y0 + '" width="' + w + '" height="' + h + '" fill="' + pal[0] + '"/>';
      const n = 2 + Math.floor(R() * 2);
      for (let i = 0; i < n; i++) p += '<rect x="' + (x0 + 6) + '" y="' + (y0 + 6 + i * (h - 12) / n) + '" width="' + (w - 12) + '" height="' + ((h - 12) / n - 5) + '" rx="3" fill="' + pal[1 + i % 3] + '" opacity=".85"/>';
    } else if (style === 'land') {
      p = '<defs><linearGradient id="sk' + hh(seed) + '" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="' + pal[3] + '"/><stop offset="1" stop-color="' + pal[2] + '"/></linearGradient></defs><rect x="' + x0 + '" y="' + y0 + '" width="' + w + '" height="' + h + '" fill="url(#sk' + hh(seed) + ')"/>' +
        '<circle cx="' + (x0 + w * (0.2 + R() * 0.6)) + '" cy="' + (y0 + h * 0.3) + '" r="' + (6 + R() * 5) + '" fill="' + pal[1] + '" opacity=".9"/>' +
        '<path d="M' + x0 + ' ' + (y0 + h * 0.62) + 'Q' + (x0 + w * 0.3) + ' ' + (y0 + h * 0.4) + ' ' + (x0 + w * 0.55) + ' ' + (y0 + h * 0.6) + 'T' + (x0 + w) + ' ' + (y0 + h * 0.55) + 'V' + (y0 + h) + 'H' + x0 + 'z" fill="' + pal[0] + '" opacity=".75"/>' +
        '<path d="M' + x0 + ' ' + (y0 + h * 0.78) + 'Q' + (x0 + w * 0.5) + ' ' + (y0 + h * 0.66) + ' ' + (x0 + w) + ' ' + (y0 + h * 0.8) + 'V' + (y0 + h) + 'H' + x0 + 'z" fill="' + pal[0] + '"/>';
    } else if (style === 'geo') {
      p = '<rect x="' + x0 + '" y="' + y0 + '" width="' + w + '" height="' + h + '" fill="' + pal[2] + '"/>';
      for (let i = 0; i < 5; i++) {
        const cx = x0 + R() * w, cy = y0 + R() * h, r = 5 + R() * 14;
        p += R() < 0.5 ? '<circle cx="' + cx + '" cy="' + cy + '" r="' + r + '" fill="' + pal[i % 4 === 2 ? 0 : i % 4] + '" opacity=".85"/>' : '<path d="M' + cx + ' ' + (cy - r) + 'L' + (cx + r) + ' ' + (cy + r) + 'H' + (cx - r) + 'z" fill="' + pal[(i + 1) % 4 === 2 ? 3 : (i + 1) % 4] + '" opacity=".8"/>';
      }
    } else if (style === 'portrait') {
      p = '<rect x="' + x0 + '" y="' + y0 + '" width="' + w + '" height="' + h + '" fill="' + pal[0] + '"/><ellipse cx="' + (x0 + w / 2) + '" cy="' + (y0 + h * 0.4) + '" rx="' + (w * 0.13) + '" ry="' + (h * 0.2) + '" fill="' + pal[3] + '"/><path d="M' + (x0 + w * 0.22) + ' ' + (y0 + h) + 'Q' + (x0 + w / 2) + ' ' + (y0 + h * 0.5) + ' ' + (x0 + w * 0.78) + ' ' + (y0 + h) + 'z" fill="' + pal[1] + '"/>';
    } else {
      p = '<rect x="' + x0 + '" y="' + y0 + '" width="' + w + '" height="' + h + '" fill="#f4f1e8"/>';
      let x = x0;
      while (x < x0 + w - 4) {
        const ww = 8 + R() * 26;
        let y = y0;
        while (y < y0 + h - 4) {
          const hh2 = 8 + R() * 22;
          p += '<rect x="' + x + '" y="' + y + '" width="' + Math.min(ww, x0 + w - x) + '" height="' + Math.min(hh2, y0 + h - y) + '" fill="' + (R() < 0.3 ? pal[1 + Math.floor(R() * 3)] : '#f4f1e8') + '" stroke="#18191c" stroke-width="1.4"/>';
          y += hh2;
        }
        x += ww;
      }
    }
    const frame = '<rect x="0" y="0" width="' + W + '" height="' + H + '" fill="' + fr[0] + '"/><rect x="2" y="2" width="' + (W - 4) + '" height="' + (H - 4) + '" fill="none" stroke="' + fr[2] + '" stroke-width="1.2"/><rect x="' + (ft - 1.5) + '" y="' + (ft - 1.5) + '" width="' + (W - 2 * ft + 3) + '" height="' + (H - 2 * ft + 3) + '" fill="none" stroke="' + fr[1] + '" stroke-width="1.5"/>' + (mat ? '<rect x="' + ft + '" y="' + ft + '" width="' + (W - 2 * ft) + '" height="' + (H - 2 * ft) + '" fill="#f7f5ee"/>' : '');
    return '<svg viewBox="0 0 ' + W + ' ' + H + '" aria-hidden="true">' + frame + p + '<rect x="' + x0 + '" y="' + y0 + '" width="' + w + '" height="' + h + '" fill="none" stroke="rgba(0,0,0,.25)"/></svg>';
  }
  window.artSvg = artSvg;
  window.artThumb = (seed, opt, act, p) => '<button class="pic art" data-a="' + (act || 'artview') + '" data-p="' + esc(JSON.stringify(p || { seed, opt })) + '" aria-label="View">' + artSvg(seed, opt) + '</button>';
  ACT.artview = p => {
    openSheet('<h2>' + esc(p.t || 'Artwork') + '</h2>' + (p.sub ? '<p class="muted small">' + esc(p.sub) + '</p>' : '') + '<div class="artbig">' + artSvg(p.seed, p.opt) + '</div>' + (p.cap ? '<p class="small center">' + esc(p.cap) + '</p>' : '') + btn('Close', 'sheetclose', undefined, 'wide'), 'artsheet');
  };
}

/* ===== Round 13: chains need registration first, new stores open in real steps, the chain folder is one page,
   boards with real seats (chair, directors, CEO, CFO, secretary; specialists invited when relevant),
   owners vote by shares (more than half wins), and bankruptcy is told plainly. ===== */
{
  const R12 = window.R12, P13 = R12.P12, kf = R12.kf, first = R12.first, r500 = R12.r500, seg = R12.seg12;
  const liveCo = c => c && c.st !== 'sold' && c.st !== 'bust';
  DOCS.chain = ['Chain registration and operations manual', 'Business lawyer', 18000, 4, 0, 'Registers the brand for more stores and writes the manual every store follows.'];

  /* ================= 1. a chain is registered first, like a franchise ================= */
  R12.growX = function (co) {
    const ch = R12.chainOf(co);
    if (ch) { const n = R12.storesOf(ch).length; return '<div class="card"><div class="bhead"><b>Part of ' + esc(ch.name) + '</b><span class="pill blue">' + n + (n > 1 ? ' stores' : ' store') + '</span></div><span class="tipt">Registered chain. Open more stores under the same name, wherever you like.</span><div class="two">' + btn(n > 1 ? 'Open the chain' : 'Chain rules', 'go', { n: 'chain12', p: n > 1 ? { id: ch.id } : { id: ch.id, t: 'rules' } }, 'ghost') + btn('＋ New store', 'ch12new', { id: ch.id }, 'primary') + '</div></div>'; }
    if (co.st !== 'open' || ['fin', 'energy', 'club', 'hold', 'rent'].indexOf(BD[co.type].fam) >= 0) return '';
    const d = co.docs.chain, dd = docDef('chain', co.country);
    if (!d || d.st === 'lapsed') return '<div class="card"><div class="bhead"><b>Grow into a chain</b><span class="pill">Step 1 of 2</span></div><span class="tipt">Like a franchise: register the chain and have a lawyer write the operations manual every store will follow. Once approved, you can open stores under the same name anywhere.</span>' + row('Cost', money(docCost(co, 'chain'))) + row('Takes about', dd[3] + ' weeks') + btn('Apply for chain registration', 'applydoc', { id: co.id, d: 'chain' }, 'primary wide') + '</div>';
    if (d.st === 'applied') { const tot = Math.max(1, d.done - d.w0), left = Math.max(0, d.done - S.week); return '<div class="card"><div class="bhead"><b>Chain registration</b><span class="pill amb">In progress</span></div>' + bar(Math.min(100, (tot - left) / tot * 100)) + '<span class="tipt">Approved in about ' + left + (left === 1 ? ' week' : ' weeks') + '. The lawyer is writing the operations manual.</span></div>'; }
    return '<div class="card"><div class="bhead"><b>Chain approved</b><span class="pill green">Step 2 of 2</span></div><span class="tipt">Name the chain. Every store will carry this name.</span>' + U.inp('ch12n', 'Chain name', co.name, 'text') + btn('Make ' + esc(co.name) + ' a chain', 'ch12make', { id: co.id }, 'primary wide') + '</div>';
  };

  /* ================= 2. opening another store: lease, fit-out, people, opening day ================= */
  R12.newStoreX = function (p) {
    const ch = R12.chainById(p.id);
    if (!ch) return;
    const f = R12.storesOf(ch)[0];
    ui.ns13 = { id: ch.id, city: f ? f.city : CC().cities[0].id, size: 1 };
    go('store13', { id: ch.id });
  };
  V.titles.store13 = 'New store';
  function nsEst(ch) {
    const s = ui.ns13, f = R12.storesOf(ch)[0] || {};
    return setupEstimate(ch.type, { city: s.city, size: s.size, form: f.form || 'AS', country: f.country || S.country });
  }
  V.store13 = function (p) {
    const ch = R12.chainById(p.id);
    if (!ch) return '<div class="calm">This chain no longer exists.</div>';
    const s = ui.ns13 = ui.ns13 && String(ui.ns13.id) === String(ch.id) ? ui.ns13 : { id: ch.id, city: CC().cities[0].id, size: 1 };
    const L = R12.storesOf(ch), est = nsEst(ch), cost = Math.round(est.total * 1.15 / 1000) * 1000;
    const cnt = id => L.filter(c => c.city === id).length;
    let h = '<div class="card sense"><span class="tipt">Same name, same rules and the paperwork you already have. What this store needs is premises, equipment and people.</span></div>';
    h += '<h2 class="sec">Where</h2>' + U.ddown(CC().cities.map(c => [c.id, c.name + (cnt(c.id) ? ' · ' + cnt(c.id) + (cnt(c.id) > 1 ? ' stores' : ' store') : '')]), s.city, 'ns13city');
    h += '<h2 class="sec">Size</h2>' + seg([[0.7, 'Small'], [1, 'Standard'], [1.4, 'Large']], s.size, 'ns13size');
    h += '<h2 class="sec">From lease to opening day</h2><div class="card lrows">' + [['Week 1', 'Sign the lease', 'Premises in ' + cityOf(s.city).name], ['Week 2', 'Fit-out and equipment', 'Bought to the chain’s standard'], ['Week 3', 'Hire and train the team', 'Manager can be hired or promoted after'], ['Week 4', 'Opening day', 'Runs on the chain’s rules from day one']].map(x => '<div class="lrow"><span class="pill">' + x[0] + '</span><span class="ctext"><b>' + x[1] + '</b><small>' + esc(x[2]) + '</small></span></div>').join('') + '</div>';
    h += '<div class="tri"><div><span>Cost</span><b>' + mshort(cost) + '</b></div><div><span>Your cash</span><b class="' + (S.cash < cost ? 'neg' : '') + '">' + mshort(S.cash) + '</b></div><div><span>Opens in</span><b>3 wks</b></div></div>';
    h += btn('Open ' + esc(ch.name) + ' ' + esc(cityOf(s.city).name), 'ns13go', { id: ch.id }, 'primary wide');
    return h;
  };
  ACT.ns13city = p => { ui.ns13.city = p.v; render(); };
  ACT.ns13size = p => { ui.ns13.size = +p.v; render(); };
  ACT.ns13go = p => {
    const ch = R12.chainById(p.id), s = ui.ns13;
    if (!ch || !s) return;
    const L = R12.storesOf(ch), f = L[0];
    const cost = Math.round(nsEst(ch).total * 1.15 / 1000) * 1000;
    if (S.cash < cost) { U.res('cash'); return; }
    ui.chainNew = null;
    const n = startCompany(ch.type, { name: 'New store ' + uid(), city: s.city, size: s.size, form: f ? f.form : 'AS', country: f ? f.country : S.country });
    if (typeof n === 'string') { U.res(n); return; }
    payMe(cost, 'New store for ' + ch.name);
    n.cash += cost;
    n.inj = (n.inj || 0) + cost;
    if (f) for (const k in f.docs) if (f.docs[k] && f.docs[k].st === 'ok' && k !== 'chain') n.docs[k] = Object.assign({}, f.docs[k]);
    n.ohrs = 0;
    n.open13 = S.week + 3;
    R12.joinChain(ch, n, true);
    save();
    U.back();
    go('chain12', { id: ch.id });
    toast(n.name + ' opens in about 3 weeks.');
  };

  /* ================= 3. the chain folder: one page ================= */
  V.heads.chain12 = p => { const ch = R12.chainById(p.id); if (!ch) return {}; const n = R12.storesOf(ch).length; return { t: ch.name, sub: { rules: 'Chain rules', team: 'Chain team', board: 'Board', store: 'Store rules' }[p.t] || 'Chain · ' + BD[ch.type].n + ' · ' + n + (n > 1 ? ' stores' : ' store') }; };
  R12.chainX = function (p) {
    const ch = R12.chainById(p.id);
    if (!ch) return null;
    const t = p.t || 'all';
    if (t === 'rules') return R12.rulesTab(ch);
    if (t === 'team') return R12.teamTab(ch);
    if (t === 'board') return boardView('ch:' + ch.id);
    if (t === 'store') return R12.storeTab(ch, getCo(p.s));
    return allPage(ch);
  };
  function mo(c, i) { const H = c.hist || []; return H[H.length - 1 - (i || 0)] || {}; }
  function storeRow(ch, c) {
    const m = mo(c), mg = c.mgr && S.npcs[c.mgr], p = m.profit;
    const opening = c.st === 'setup' && c.open13;
    const sid = 's13' + c.id;
    const body = '<div class="st13b">' + (opening ? row('Opens in', Math.max(0, c.open13 - S.week) + ' weeks') : row('Revenue last month', money(Math.round(m.rev || 0))) + row('Costs last month', money(Math.round((m.rev || 0) - (m.profit || 0)))) + row('Profit', '<span class="' + sgn(p || 0) + '">' + plus(Math.round(p || 0)) + '</span>') + row('Margin', m.rev ? Math.round((m.profit || 0) / m.rev * 100) + '%' : '—')) +
      row('Cash', money(Math.round(c.cash))) + row('Staff', c.staff.length + (mg ? ' + manager' : '')) + row('Rating', ratingOf(c).toFixed(1) + ' ★') + (c.dlast && c.dlast.so ? row('Sold out last week', '<span class="neg">' + c.dlast.so + (c.dlast.so > 1 ? ' days' : ' day') + '</span>') : '') + (R12.offCount(c) ? row('Own rules', R12.offCount(c)) : '') +
      '<div class="btnrow end">' + btn('Own rules', 'go', { n: 'chain12', p: { id: ch.id, t: 'store', s: c.id } }, 'chip') + btn('Open store ›', 'go', { n: 'co', p: { id: c.id } }, 'chip primary') + '</div></div>';
    return '<details class="srow st13" data-sid="' + sid + '"' + (String(ui.openStaff) === sid ? ' open' : '') + '><summary class="lrow">' + av(ini(c.name)) + '<span class="ctext"><b>' + esc(c.name) + '</b><small>' + (opening ? '<em class="amb">Opening in ' + Math.max(0, c.open13 - S.week) + ' weeks</em>' : esc(mg ? mg.name : 'You run it · ' + (c.ohrs || 0) + ' h')) + ' · ' + esc(cityOf(c.city).name) + '</small></span><b class="num ' + (p == null ? '' : sgn(p)) + '">' + (p == null ? '—' : kf(p)) + '</b></summary>' + body + '</details>';
  }
  function allPage(ch) {
    const L = R12.storesOf(ch);
    const rev = sum(L, c => mo(c).rev || 0), pr = sum(L, c => mo(c).profit || 0);
    let h = '<div class="tri"><div><span>Revenue/mo</span><b>' + kf(rev) + '</b></div><div><span>Profit/mo</span><b class="' + sgn(pr) + '">' + kf(pr) + '</b></div><div><span>Staff</span><b>' + sum(L, c => c.staff.length + (c.mgr ? 1 : 0)) + '</b></div></div>';
    const cf = R12.chiefs(ch);
    if (!cf.length && L.length >= 3) h += '<div class="card dec1"><b>Hire a chain chief</b><span class="tipt">' + L.length + ' stores is a lot to run yourself. A chief keeps every store on the rules and coaches the managers.</span><div class="two">' + btn('Promote one of yours', 'go', { n: 'chain12', p: { id: ch.id, t: 'team' } }, 'primary') + btn('Search outside', 'go', { n: 'chief12', p: { id: ch.id } }, 'ghost') + '</div></div>';
    h += '<h2 class="sec">Stores</h2><div class="lrows">' + L.map(c => storeRow(ch, c)).join('') + '</div>';
    h += '<div class="lrows">' + [['rules', 'Chain rules', 'Prices, choices, opening hours, pay, marketing'], ['team', 'Team', cf.length ? cf.map(r => S.npcs[r.npc] ? S.npcs[r.npc].name : '').join(', ') : 'Chiefs, store managers, moving staff']].concat(active('ch:' + ch.id) ? [['board', 'Board', 'Meetings, members and votes']] : []).map(x => '<button class="lrow" data-a="go" data-p="' + P13({ n: 'chain12', p: { id: ch.id, t: x[0] } }) + '"><span class="ctext"><b>' + x[1] + '</b><small>' + esc(x[2]) + '</small></span><i>›</i></button>').join('') + '</div>';
    h += btn('＋ Open a new store', 'ch12new', { id: ch.id }, 'primary wide');
    return h;
  }

  /* ================= 4. boards with real seats ================= */
  const ROLE13 = {
    chair: ['Board chair', 'perm', 'people', 1, 14000, 'Runs the meetings and keeps the board on the numbers'],
    director: ['Director', 'perm', 'ops', 4, 9000, 'Independent view; weighs every big decision'],
    cfo: ['CFO', 'perm', 'fin', 1, 32000, 'Cash, debt and profit; first to speak on money'],
    sec: ['Board secretary', 'perm', 'ops', 1, 6000, 'Minutes, follow-ups and reminders'],
    mkt: ['Marketing manager', 'inv', 'sales', 1, 22000, 'Brand and campaigns; marketing works about 5% better'],
    hr: ['HR manager', 'inv', 'people', 1, 20000, 'Hiring and morale; fewer people quit'],
    legal: ['Legal adviser', 'inv', 'risk', 1, 16000, 'Contracts, permits and disputes; fines about 10% lower'],
    analyst: ['Data analyst', 'inv', 'fin', 1, 18000, 'Numbers behind prices, stock and demand'],
    consult: ['External consultant', 'inv', 'ops', 1, 26000, 'Outside eyes on what is not working']
  };
  const OLD = { fin: 'cfo', law: 'legal', ind: 'consult', mkt: 'mkt', chair: 'chair' };
  const roleOf = s => s.r || OLD[s.type] || null;
  const holdersOf = key => { const L = R12.brdCos(key); const H = []; L.forEach(c => (c.holders || []).forEach(h => H.push({ h, co: c }))); return H; };
  function active(key) {
    if (key.slice(0, 2) === 'ch') { const ch = R12.chainById(key.slice(3)); return !!ch && (R12.storesOf(ch).length >= 2 || holdersOf(key).length > 0); }
    return holdersOf(key).length > 0;
  }
  R12.active = active;
  const seatsR = (key, r) => R12.seatsOf(key).filter(s => roleOf(s) === r);
  function ceoOf(key) {
    const cos = R12.brdCos(key);
    if (S.group && S.group.ceo && S.npcs[S.group.ceo.npc]) return S.npcs[S.group.ceo.npc];
    const c = cos.find(x => x.mgr && S.npcs[x.mgr]);
    return c ? S.npcs[c.mgr] : null;
  }
  function chiefsOf(key) {
    const cos = R12.brdCos(key), ids = new Set();
    cos.forEach(c => { if (c.region) { const r = S.group.regional.find(x => x.id === c.region); if (r && S.npcs[r.npc]) ids.add(r.npc); } });
    return Array.from(ids).map(id => S.npcs[id]);
  }
  const has = (key, r) => seatsR(key, r).length > 0;
  R12.hasRole = (co, r) => { try { return has(R12.brdKeyOf(co), r); } catch (e) { return false; } };
  /* who is at the table: owners and the CEO vote, chiefs vote, advisers advise */
  R12.votersX = function (key) {
    const L = [];
    const lh = R12.lhN();
    if (lh) L.push({ id: lh.id, n: lh, t: 'Your left hand', type: 'lh', lh: 1 });
    R12.seatsOf(key).forEach(s => { const r = roleOf(s); if (r && S.npcs[s.id]) L.push({ id: s.id, n: S.npcs[s.id], t: ROLE13[r] ? ROLE13[r][0] : s.t, type: r, seat: s, vote: r === 'director' }); });
    const ceo = ceoOf(key);
    if (ceo) L.push({ id: ceo.id, n: ceo, t: 'CEO', type: 'ceo', vote: 1 });
    chiefsOf(key).forEach(n => L.push({ id: n.id, n, t: 'Regional manager', type: 'regional', vote: 1 }));
    holdersOf(key).forEach((x, i) => L.push({ id: 'h' + i, n: { id: 'h' + i, name: x.h.name, age: 50 }, t: 'Co-owner · ' + Math.round(x.h.pct) + '%', type: 'owner', owner: x.h, vote: 1 }));
    return L;
  };
  const MAPT = { cfo: 'fin', legal: 'law', mkt: 'mkt', analyst: 'lh', consult: 'ind', chair: 'chair', director: 'ind', hr: 'exec', lh: 'lh', ceo: 'exec', regional: 'exec' };
  R12.recsX = function (v, cos) {
    if (v.type === 'owner' || v.type === 'sec') return [];
    const out = R12.recs0(Object.assign({}, v, { type: MAPT[v.type] || v.type }), cos);
    out.forEach(x => { x.inv = invFor(x); });
    return out;
  };
  function invFor(x) {
    if (x.act === 'price') return ['mkt', 'analyst'];
    if (x.act === 'stock') return ['analyst'];
    const n = x.p && x.p.n;
    if (n === 'sale') return ['legal', 'cfo'];
    if (n === 'mgrhire') return ['hr'];
    if (n === 'newhold') return ['legal', 'cfo'];
    if (n === 'co' && x.p.p && x.p.p.t === 'mk') return ['mkt'];
    if (n === 'co') return ['legal'];
    return [];
  }
  R12.invText = function (x, key) {
    const inv = x.inv || invFor(x);
    if (!inv.length) return '';
    return '<span class="tipt inv13">The CEO invited: ' + inv.map(r => { const s = seatsR(key, r)[0]; const nm = s && S.npcs[s.id] ? first(S.npcs[s.id].name) : (r === 'cfo' && R12.brdCos(key)[0] && R12.brdCos(key)[0].acc ? 'your accountant' : null); return ROLE13[r][0] + (nm ? ' (' + esc(nm) + ')' : ' (not hired)'); }).join(', ') + '</span>';
  };
  function personRow(n, sub, right) { return '<div class="lrow">' + (n ? faceAv(n) : '<span class="av dim">–</span>') + '<span class="ctext"><b>' + esc(n ? n.name : 'Not filled') + '</b><small>' + sub + '</small></span>' + (right || '') + '</div>'; }
  function seatRow(key, r) {
    const L = seatsR(key, r), R = ROLE13[r];
    const rm = s => btn('Remove', 'bd12rm', { k: key, id: s.id }, 'chip ghost');
    if (L.length) return L.map(s => personRow(S.npcs[s.id], esc(R[0]) + ' · ' + mshort(s.fee || 0) + '/mo · ' + esc(R[5]), rm(s))).join('') + (L.length < R[3] ? '<div class="lrow"><span class="ctext"><small>Room for ' + (R[3] - L.length) + ' more</small></span>' + btn('Hire', 'bd13find', { k: key, r }, 'chip') + '</div>' : '');
    return '<div class="lrow"><span class="av dim">＋</span><span class="ctext"><b>' + esc(R[0]) + '</b><small>' + esc(R[5]) + '</small></span>' + btn('Hire', 'bd13find', { k: key, r }, 'chip') + '</div>';
  }
  function boardView(key) {
    const b = R12.brdOf(key);
    if (!b) return '<div class="calm">No board.</div>';
    const cos = R12.brdCos(key), co0 = cos[0], lh = R12.lhN();
    if (!active(key)) {
      let h = '<div class="card sense"><b>No board yet</b><span class="tipt">A board meets once a chain has two or more stores, or when someone else owns part of the company. Until then decisions come straight to you' + (lh ? ', and your left hand still advises' : '') + '.</span></div>';
      const E = (b.mts || []).filter(m => m.emg).slice(0, 4);
      if (E.length) h += '<h2 class="sec">Urgent decisions</h2><div class="lrows">' + E.map(m => '<button class="lrow" data-a="go" data-p="' + P13({ n: 'bmeet12', p: { k: key, id: m.id } }) + '"><span class="ctext"><b>' + esc(m.title) + '</b><small>' + esc(dateStr(m.w)) + '</small></span><span class="pill ' + (m.st ? '' : 'red') + '">' + (m.st === 'late' ? 'No answer' : m.st ? 'Decided' : 'Open') + '</span></button>').join('') + '</div>';
      return h;
    }
    let h = '<div class="card"><div class="bhead"><b>' + esc(R12.brdName(key)) + '</b><span class="pill blue">' + (b.mode === 'regular' ? (b.freq === 13 ? 'Every quarter' : 'Every month') : 'Only when needed') + '</span></div>' +
      seg([['regular', 'Regular meetings'], ['needed', 'Only when needed']], b.mode, 'bd12mode', { k: key }) + (b.mode === 'regular' ? seg([[4, 'Monthly'], [13, 'Quarterly']], b.freq, 'bd12freq', { k: key }) : '') +
      '<span class="tipt">Votes: you, co-owners by their shares, the CEO and regional managers. A decision needs more than half of the shares. Advisers advise.</span>' + btn('Hold a meeting now', 'bd12meet', { k: key }, 'wide') + '</div>';
    const ceo = ceoOf(key);
    const cfoS = seatsR(key, 'cfo')[0];
    h += '<h2 class="sec">Always at the table</h2><div class="card lrows">' +
      personRow({ id: 'you', name: S.player.name }, 'You · owner ' + Math.round(co0 ? co0.own : 100) + '% · votes') +
      (lh ? personRow(lh, 'Your left hand · advises') : '<button class="lrow" data-a="go" data-p="' + P13({ n: 'boards12', p: {} }) + '"><span class="av dim">＋</span><span class="ctext"><b>Your left hand</b><small>Hire a personal advisor ›</small></span></button>') +
      holdersOf(key).map(x => personRow({ id: 'h' + x.h.name, name: x.h.name, age: 50 }, 'Co-owner · ' + Math.round(x.h.pct) + '% · votes')).join('') +
      seatRow(key, 'chair') + seatRow(key, 'director') +
      personRow(ceo, 'CEO · ' + (ceo ? 'votes' : 'hire a manager or group CEO')) +
      (cfoS ? seatRow(key, 'cfo') : (co0 && co0.acc ? personRow({ id: 'acc', name: co0.acc.name }, 'Accountant, acting CFO · advises', btn('Hire CFO', 'bd13find', { k: key, r: 'cfo' }, 'chip')) : seatRow(key, 'cfo'))) +
      seatRow(key, 'sec') + '</div>';
    h += '<h2 class="sec">Invited when relevant</h2><div class="card lrows">' + (chiefsOf(key).length ? chiefsOf(key).map(n => personRow(n, 'Regional manager · votes')).join('') : '<div class="lrow"><span class="av dim">–</span><span class="ctext"><b>Regional manager</b><small>Hire a chain chief from the Team page</small></span></div>') + ['mkt', 'hr', 'legal', 'analyst', 'consult'].map(r => seatRow(key, r)).join('') + '</div>';
    const C = (b.cands || []).map(id => S.npcs[id]).filter(n => n && !n.hired);
    if (C.length) h += '<h2 class="sec">Candidates · ' + esc(ROLE13[b.candR] ? ROLE13[b.candR][0] : '') + '</h2>' + C.map(n => '<div class="card"><div class="cchd">' + faceAv(n) + '<span class="ctext"><b>' + esc(n.name) + '</b><small>' + n.age + ' · ' + esc(n.advBg || '') + ' · ' + skillBand(Math.round(R12.qOf(n) * 100)) + '</small></span></div><div class="chips">' + [0.9, 1, 1.15].map(f => btn(mshort(r500(n.fee13 * f)) + '/mo', 'bd13hire', { k: key, n: n.id, f: r500(n.fee13 * f) }, 'chip' + (f === 1 ? ' primary' : ''))).join('') + '</div></div>').join('');
    const M = (b.mts || []).slice(0, 5);
    if (M.length) h += '<h2 class="sec">Meetings</h2><div class="lrows">' + M.map(m => '<button class="lrow" data-a="go" data-p="' + P13({ n: 'bmeet12', p: { k: key, id: m.id } }) + '"><span class="ctext"><b>' + (m.emg ? 'Emergency · ' : '') + esc(dateStr(m.w)) + '</b><small>' + esc(m.emg ? m.title : m.items.length + ' points · ' + m.items.filter(x => x.st === 'yes').length + ' taken') + '</small></span>' + (m.emg ? '<span class="pill ' + (m.st ? '' : 'red') + '">' + (m.st === 'late' ? 'No answer' : m.st ? 'Decided' : 'Open') + '</span>' : '') + '<i>›</i></button>').join('') + '</div>';
    return h;
  }
  R12.boardViewX = boardView;
  ACT.bd13find = p => {
    const b = R12.brdOf(p.k), R = ROLE13[p.r], cost = KC(8000);
    if (!b || !R) return;
    if (S.cash < cost) { U.res('cash'); return; }
    payMe(cost, 'Search: ' + R[0]);
    b.candR = p.r;
    b.cands = [0, 1, 2].map(() => {
      const n = genManager(null, 'gen');
      n.adv13 = p.r;
      n.advBg = pick(['former director', 'ex-banker', 'sits on two other boards', 'built and sold a company', 'twenty years in the trade', 'former partner at a big firm']);
      n.fee13 = r500(KC(R[4] * (0.7 + ((n.stats || {})[R[2]] || 55) / 150)));
      S.npcs[n.id] = n;
      return n.id;
    });
    save();
    render();
  };
  ACT.bd13hire = p => {
    const b = R12.brdOf(p.k), n = S.npcs[p.n];
    if (!b || !n || n.hired) return;
    const r = n.adv13 || b.candR;
    if (seatsR(p.k, r).length >= ROLE13[r][3]) { toast('That seat is full.', true); return; }
    if (!(p.f >= n.fee13 || (p.f >= n.fee13 * 0.9 && chance(0.5)))) { toast(first(n.name) + ' says no at that pay.', true); b.cands = b.cands.filter(x => x !== n.id); save(); render(); return; }
    n.hired = -4;
    b.seats.push({ id: n.id, kind: 'adv', r, t: ROLE13[r][0], fee: p.f, w0: S.week, ok: 0, no: 0, mood: 60 });
    b.cands = [];
    toast(n.name + ' is now ' + ROLE13[r][0].toLowerCase() + ' of ' + R12.brdName(p.k) + '.');
    save();
    render();
  };
  /* what the seats do */
  const mm13 = window.mktMult;
  window.mktMult = function (co) { const r = mm13.apply(this, arguments); return co && R12.hasRole(co, 'mkt') ? r * 1.05 : r; };
  const pc13 = window.payCo;
  window.payCo = function (co, amt, cat) { if (cat === 'fine' && co && R12.hasRole(co, 'legal')) arguments[1] = amt * 0.9; return pc13.apply(this, arguments); };
  function seatsWeek() {
    S.cos.forEach(co => {
      if (!liveCo(co) || co.st !== 'open') return;
      if (R12.hasRole(co, 'hr')) co.staff.forEach(s => { if (s.notice > 0 && Z() < 0.15) { s.notice = 0; s.happy = S.week + 12; } });
    });
    /* the secretary chases what the board left open */
    const keys = (S.chains || []).map(ch => 'ch:' + ch.id).concat(S.cos.filter(liveCo).map(c => 'co:' + c.id));
    keys.forEach(k => {
      const b = (k[1] === 'h' ? (R12.chainById(k.slice(3)) || {}).brd : (getCo(+k.slice(3)) || {}).brd);
      if (!b || !has(k, 'sec')) return;
      (b.mts || []).forEach(m => {
        if (m.emg || m.rem13 || S.week - m.w < 1) return;
        const open = (m.items || []).filter(x => x.act && !x.st);
        if (!open.length) return;
        m.rem13 = 1;
        const s = seatsR(k, 'sec')[0];
        addMsg({ kind: 'info', from: S.npcs[s.id].name, role: 'Board secretary', title: open.length + ' board points still open at ' + R12.brdName(k), body: open.map(x => '• ' + x.text).join('\n'), tone: 'n', status: 'done', go: { l: 'Open the meeting', a: 'go', p: { n: 'bmeet12', p: { k, id: m.id } } } });
      });
    });
  }

  /* ================= 5. owners vote by shares ================= */
  function ownerVote(kind, co, h) {
    const H = (co.hist || []).slice(-3), p3 = sum(H, x => x.profit || 0);
    const R = hrng('ov13:' + h.name + ':' + kind + ':' + S.week)();
    const base = kind === 'sell' || kind === 'close' ? p3 < 0 : p3 > 0;
    return R < 0.85 ? base : !base;
  }
  R12.voteSheetX = function (kind, co, amt, go2, label) {
    const key = R12.brdKeyOf(co);
    if (!active(key)) return go2();
    const all = R12.voteOn(kind, co, amt);
    const vs = R12.votersX(key);
    const adv = all.filter(x => { const v = vs.find(y => y.id === x.id); return v && !v.vote; });
    const brd = all.filter(x => { const v = vs.find(y => y.id === x.id); return v && v.vote && v.type !== 'owner'; });
    const owners = [{ name: S.player.name + ' (you)', pct: co.own, yes: true, you: 1 }].concat((co.holders || []).map(h => ({ name: h.name, pct: h.pct, yes: ownerVote(kind, co, h), h })));
    const yesPct = sum(owners.filter(o => o.yes), o => o.pct);
    const big = owners.find(o => o.pct >= 51);
    const pass = big ? big.yes : yesPct > 50;
    const lonely = pass && owners.length > 1 && owners.filter(o => !o.you).every(o => !o.yes);
    ui.b13cont = () => {
      closeSheet();
      if (lonely) { (co.holders || []).forEach(h => { h.mood = Math.max(0, (h.mood != null ? h.mood : 60) - 8); }); R12.seatsOf(key).forEach(s => { s.mood = Math.max(0, (s.mood || 60) - 4); }); toast('Pushed through against the others. They are not happy.', true); }
      go2();
    };
    const line = x => '<div class="lrow">' + (x.id && S.npcs[x.id] ? faceAv(S.npcs[x.id]) : '<span class="av dim">' + esc(ini(x.name)) + '</span>') + '<span class="ctext"><b>' + esc(x.name) + (x.lh ? ' · your left hand' : '') + ' · ' + (x.yes ? 'for' : 'against') + '</b><small>' + esc(x.why || '') + '</small></span></div>';
    openSheet('<h2>Vote: ' + esc(label) + '</h2>' +
      (adv.length ? '<h3>Advice</h3><div class="lrows">' + adv.map(line).join('') + '</div>' : '') +
      (brd.length ? '<h3>Board</h3><div class="lrows">' + brd.map(line).join('') + '</div>' : '') +
      '<h3>Owners decide</h3><div class="lrows">' + owners.map(o => '<div class="lrow"><span class="av dim">' + esc(ini(o.name)) + '</span><span class="ctext"><b>' + esc(o.name) + '</b><small>' + Math.round(o.pct) + '% of the shares</small></span><span class="pill ' + (o.yes ? 'green' : 'red') + '">' + (o.yes ? 'Yes' : 'No') + '</span></div>').join('') + '</div>' +
      '<p class="muted small">' + (big ? esc(big.name) + ' owns ' + Math.round(big.pct) + '%, so that vote decides.' : Math.round(yesPct) + '% yes. It needs more than 50%.') + (lonely ? ' Everyone else voted no and will lose some morale.' : '') + '</p>' +
      (pass ? '<div class="two">' + btn('Go ahead', 'b13go', {}, 'primary') + btn('Cancel', 'sheetclose', undefined, 'ghost') + '</div>' : btn('The owners said no', 'sheetclose', undefined, 'wide')));
  };
  ACT.b13go = () => { const f = ui.b13cont; ui.b13cont = null; if (f) f(); };

  /* ================= 6. bankruptcy, told plainly ================= */
  const bk0 = window.bankrupt;
  window.bankrupt = function (co, why) {
    if (!co || co.st === 'bust' || co.st === 'sold') return bk0.apply(this, arguments);
    const cash0 = S.cash, staff = co.staff.length + (co.mgr ? 1 : 0);
    const loans = S.loans.filter(l => l.co === co.id).map(l => ({ b: l.bal, g: !!(l.guar || co.form === 'ENK') }));
    const info0 = { id: co.id, name: co.name, type: BD[co.type].n, why, w: S.week, staff, inj: co.inj || 0, form: co.form, cash: Math.round(co.cash), loans: Math.round(sum(loans, l => l.b)), guar: Math.round(sum(loans.filter(l => l.g), l => l.b)) };
    const r = bk0.apply(this, arguments);
    info0.hit = Math.max(0, cash0 - S.cash) + info0.guar;
    info0.credit = S.credit;
    (S.bkq = S.bkq || []).push(info0);
    return r;
  };
  function bkView() {
    const b = (S.bkq || [])[0];
    if (!b) return '';
    const why = b.why === 'unpaid' ? 'Bills went unpaid month after month. Suppliers, staff and the tax office stopped waiting and asked the court to close it.' : 'The company ran out of cash and nobody would lend it more.';
    return '<div class="bk13o"><div class="bk13c"><span class="pill red">BANKRUPT</span><h1>' + esc(b.name) + '</h1><p class="muted">' + esc(b.type) + ' · ' + esc(dateStr(b.w)) + '</p><p class="bk13why">' + esc(why) + '</p>' +
      '<div class="card">' + row('What you put in', '<span class="neg">' + money(b.inj) + ' · lost</span>') + row('Loans', money(b.loans) + (b.guar ? ' · ' + money(b.guar) + ' now yours to repay' : ' · closed by the bank')) + row('Lands on you personally', '<span class="' + (b.hit ? 'neg' : '') + '">' + money(Math.round(b.hit)) + '</span>') + row('People who lose their job', b.staff) + row('Your credit score', Math.round(b.credit) + ' / 100') + '</div>' +
      '<div class="card"><b>What happens now</b><span class="tipt">' + (b.form === 'ENK' ? 'As a sole proprietor you are liable for every unpaid bill yourself. ' : 'The limited company protects you, except for loans you guaranteed. ') + 'Everything the company owned is sold at a discount to pay what it owed. Banks will charge you more for a while.</span></div>' +
      btn('I understand', 'bk13ok', {}, 'primary wide') + '</div></div>';
  }
  ACT.bk13ok = () => { (S.bkq || []).shift(); save(); render(true); };
  ['home', 'cos', 'hq', 'meetings', 'phonehome'].forEach(k => {
    const f0 = V[k];
    if (!f0) return;
    V[k] = function () { const h = f0.apply(this, arguments); return S && S.bkq && S.bkq.length ? h + bkView() : h; };
  });

  R7.afterWeek = R7.afterWeek || [];
  R7.afterWeek.push(() => {
    try {
      S.cos.forEach(n => {
        if (n.open13 && S.week >= n.open13 && n.st === 'setup') {
          setupAndOpen(n);
          if (window.topUpEq) topUpEq(n);
          delete n.open13;
          if (n.st === 'open') note(n.name + ' opened its doors today.', 'good', n.id);
          else n.open13 = S.week + 1;
        }
      });
    } catch (e) { console.error(e); }
    try { seatsWeek(); } catch (e) { console.error(e); }
  });
}

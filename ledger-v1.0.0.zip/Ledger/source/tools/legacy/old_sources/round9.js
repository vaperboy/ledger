/* ===== Round 9: salary talks in a phone-style message screen, pay plans and car offers that work,
   and a back button when a button sends you to another main tab. ===== */
{
  const P = o => esc(JSON.stringify(o));
  const RATES = [0.01, 0.02, 0.03, 0.05, 0.08, 0.12];
  const talkOf = id => ((ui.talk = ui.talk || {})[id] = (ui.talk || {})[id] || []);
  const bub = x => '<div class="bub ' + (x.sys ? 'sys' : x.me ? 'me' : 'them') + '">' + esc(x.t) + '</div>';
  const seg = (items, cur, act, p0) => '<div class="seg7">' + items.map(x => '<button class="' + (x[0] === cur ? 'on' : '') + '" data-a="' + act + '" data-p="' + P(Object.assign({}, p0, { v: x[0] })) + '">' + x[1] + '</button>').join('') + '</div>';
  const payOf = n => (ui.pay && ui.pay[n.id]) || { m: 'fix', rate: 0.03 };

  /* ---------- the interview: a phone-style message screen over everything ---------- */
  function workerPhone(co, n) {
    const k = 'w' + n.id, sales = !!SALES_ROLES[n.role];
    const pm = payOf(n);
    const car = !!(window.carOffer && window.carOffer(co, n));
    const carc = (ui.carc || {})[n.id] || 'co';
    const msgs = [{ me: 0, t: '“' + n.resume + '” I am asking ' + money(n.ask) + ' a month.' }].concat(talkOf(n.id));
    const est = Math.round((pm.m === 'mix' ? n.ask * 0.6 : 0) + (pm.m === 'fix' ? 0 : commEstimate(co) * pm.rate));
    let h = '<div class="ichat phone7"><div class="ph7top"><button class="bk" data-a="candback" aria-label="Back">‹</button>' + faceAv(n) + '<div class="vht"><h1>' + esc(n.name) + '</h1><p>' + esc(ROLES[n.role] ? ROLES[n.role][0] : '') + ' · ' + n.age + ' · asks ' + mshort(n.ask) + '/mo</p></div>' + (window.patDots ? window.patDots(n) : '') + '</div>';
    h += '<div class="clog"><div class="cfill"></div>' + msgs.map(bub).join('') + '</div><div class="composer">';
    h += '<div class="chips qk">' + (n.checked ? '' : btn('Check references · {m:600}', 'refcheck', { id: co.id, n: n.id }, 'chip')) + (n.trial ? '' : btn('Trial week · ' + mshort(n.ask / 4), 'trial', { id: co.id, n: n.id }, 'chip')) + btn('Profile', 'candinfo', { id: co.id, n: n.id }, 'chip') + btn('Pass', 'candpass', { n: n.id }, 'chip ghost') + '</div>';
    if (sales) h += seg([['fix', 'Fixed'], ['mix', 'Base + bonus'], ['com', 'Commission']], pm.m, 'pay7', { n: n.id, k: 'm' });
    if (car) h += seg([['co', 'Company car'], ['own', 'Own car + mileage']], carc, 'car7', { n: n.id });
    if (pm.m === 'fix' || !sales) {
      h += '<div class="chips qk">' + [0.9, 1, 1.05, 1.15].map(f => { const v = Math.round(n.ask * f / 100) * 100; return '<button class="btn chip' + (Math.round(U.inum(k, n.ask) / 100) * 100 === v ? ' primary' : '') + '" data-a="setinp" data-p="' + P({ k, v }) + '">' + Math.round(f * 100) + '% · ' + mshort(n.ask * f) + '</button>'; }).join('') + '</div>';
      h += '<div class="crow">' + U.inp(k, 'Monthly salary', n.ask) + btn('Send', 'offer7', { id: co.id, n: n.id }, 'primary') + '</div>';
    } else {
      h += '<div class="chips qk">' + RATES.map(r => '<button class="btn chip' + (pm.rate === r ? ' primary' : '') + '" data-a="pay7" data-p="' + P({ n: n.id, k: 'rate', v: r }) + '">' + pc(r, 0) + '</button>').join('') + '</div>';
      h += '<div class="crow"><div class="crowtxt"><b>' + (pm.m === 'mix' ? mshort(n.ask * 0.6) + ' fixed + ' + pc(pm.rate, 0) + ' of sales' : pc(pm.rate, 0) + ' of sales, no fixed pay') + '</b><small>About ' + mshort(est) + ' a month at today\'s sales</small></div>' + btn('Send', 'offer7', { id: co.id, n: n.id }, 'primary') + '</div>';
    }
    return h + '</div></div>';
  }
  ACT.pay7 = p => {
    ui.pay = ui.pay || {};
    const o = ui.pay[p.n] || { m: 'fix', rate: 0.03 };
    if (p.k === 'm') { o.m = p.v; if (p.v === 'com') o.rate = Math.max(o.rate, 0.05); }
    else o.rate = p.v;
    ui.pay[p.n] = o;
    render();
  };
  ACT.car7 = p => { ui.carc = ui.carc || {}; ui.carc[p.n] = p.v; render(); };
  ACT.offer7 = p => {
    const co = getCo(p.id), n = S.npcs[p.n];
    if (!co || !n) return;
    const pm = payOf(n), sales = !!SALES_ROLES[n.role];
    const car = window.carOffer && window.carOffer(co, n) ? ((ui.carc || {})[n.id] || 'co') : null;
    const L = talkOf(n.id), before = L.length;
    if (sales && pm.m !== 'fix') ui.inp['w' + n.id] = String(Math.round(n.ask / fxr(CC())));
    const w = Math.round(U.inum('w' + n.id, n.ask) / 100) * 100;
    ACT.offer(p);
    let txt = !sales || pm.m === 'fix' ? 'I can offer ' + money(w) + ' a month.' : pm.m === 'mix' ? 'I can offer ' + money(Math.round(n.ask * 0.6 / 100) * 100) + ' fixed plus ' + pc(pm.rate, 0) + ' of what you sell.' : 'I can offer ' + pc(pm.rate, 0) + ' commission on everything you sell, no fixed pay.';
    if (car) txt += car === 'co' ? ' You get a company car.' : ' You use your own car and I pay mileage.';
    for (let i = L.length - 1; i >= before; i--) if (L[i].me) { L[i].t = txt; break; }
    if (L.length === before) L.push({ me: 1, t: txt });
    if (!n.hired && sales && pm.m !== 'fix') {
      const last = L[L.length - 1];
      const reply = pm.m === 'com' && (n.sec || 0) > 0.65 ? 'I need a fixed income. Commission only is not for me.' : 'Your sales are still small, so at that rate I would earn too little. Can you raise it, or add a base salary?';
      if (last && !last.me && !last.sys) last.t = reply; else L.push({ me: 0, t: reply });
    }
    render();
  };
  const hire9 = V.hire;
  V.hire = function (p) {
    const co = p && p.id && getCo(p.id);
    if (co && ui.cand) {
      const cl = (ui.cands && ui.cands[co.id + ':' + ui.hrole]) || [];
      const n = cl.map(id => S.npcs[id]).find(x => x && x.id === ui.cand && !x.hired && !x.gone);
      if (n) return workerPhone(co, n);
    }
    return hire9.apply(this, arguments);
  };
  /* manager and assistant talks and buyer talks get the same phone frame */
  const wrapPhone = h => h.replace('<div class="ichat">', '<div class="ichat phone7">').replace(/<div class="ichat phone7"><div class="vh">/, '<div class="ichat phone7"><div class="ph7top">').replace('<div class="clog">', '<div class="clog"><div class="cfill"></div>');
  ['mgrhire', 'saletalk'].forEach(k => {
    const f0 = V[k];
    V[k] = function () { return wrapPhone(f0.apply(this, arguments)); };
  });

  /* ---------- back to the tab you came from ---------- */
  let navClick = false;
  document.addEventListener('click', e => { navClick = !!(e.target && e.target.closest && e.target.closest('.nb')); }, true);
  const snap = () => ({ tab: ui.tab, view: ui.view ? { n: ui.view.n, p: ui.view.p } : null, stack: ui.stack.slice(), ph: ui.ph, phStack: (ui.phStack || []).slice(), hqt: ui.hqt });
  const ROOTS = { home: 1, cos: 1, hq: 1, meetings: 1 };
  const TABN = { home: 'Home', cos: 'Companies', hq: 'Office', phone: 'Phone', meet: 'Meetings' };
  function remember(b) {
    if (navClick) { ui.backTo = null; return; }
    if (ui.tab !== b.tab && !ui.stack.length && ui.view && ROOTS[ui.view.n]) ui.backTo = b;
  }
  const go9 = ACT.go;
  ACT.go = p => { const b = snap(); go9(p); remember(b); if (ui.backTo) render(true); };
  const tab9 = ACT.tab;
  ACT.tab = p => { const b = snap(); tab9(p); if (navClick) ui.backTo = null; else if (b.tab !== ui.tab) { ui.backTo = b; render(true); } };
  ACT.backto = () => {
    const b = ui.backTo;
    ui.backTo = null;
    if (!b) return;
    ui.tab = b.tab;
    ui.stack = b.stack;
    ui.view = b.view || { n: ROOT[b.tab] || 'home', p: {} };
    if (b.ph) { ui.ph = b.ph; ui.phStack = b.phStack; }
    if (b.hqt) ui.hqt = b.hqt;
    render(true);
  };
  Object.keys(ROOTS).forEach(k => {
    const f0 = V[k];
    if (!f0) return;
    V[k] = function () {
      const h = f0.apply(this, arguments);
      const b = ui.backTo;
      if (!b || b.tab === ui.tab || ui.stack.length) return h;
      return h.replace('<header class="hh">', '<header class="hh"><button class="bk backto" data-a="backto" aria-label="Back to ' + esc(TABN[b.tab] || 'where you were') + '">‹</button>');
    };
  });
}

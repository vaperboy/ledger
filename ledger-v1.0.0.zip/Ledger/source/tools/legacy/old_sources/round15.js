/* ===== Round 15: shareholders elect the board, the board appoints and oversees the CEO,
   ownership gives votes and jobs give operational power, and one person can be both. ===== */
{
  const R12 = window.R12, first = R12.first;
  const holdersAll = key => { const L = []; R12.brdCos(key).forEach(c => (c.holders || []).forEach(h => L.push({ h, co: c }))); return L; };
  const dirSeats = key => R12.seatsOf(key).filter(s => (s.r || '') === 'director');
  /* give an employee shares as part of their contract */
  window.R15give = function (co, n, pct) {
    pct = Math.min(pct, co.own - 1);
    if (pct <= 0) return '';
    co.own -= pct;
    co.holders = co.holders || [];
    const ex = co.holders.find(h => h.npc === n.id);
    if (ex) ex.pct += pct; else co.holders.push({ name: n.name, pct, in: 0, npc: n.id, mood: 70 });
    return ' ' + first(n.name) + ' now owns ' + pct + '% of ' + co.name + '.';
  };
  /* what someone does in the company, if anything */
  function jobOf(npcId, cos) {
    if (npcId == null) return null;
    if (S.group && S.group.ceo && S.group.ceo.npc === npcId) return 'Group CEO';
    const rg = ((S.group && S.group.regional) || []).find(r => r.npc === npcId);
    if (rg) return String(rg.scope).indexOf('chain:') === 0 ? 'Chain chief' : 'Regional manager';
    for (const c of cos) {
      if (c.mgr === npcId) return cos.length > 1 ? 'Store manager · ' + c.name : 'CEO';
      const s = c.staff.find(x => x.id === npcId);
      if (s) return ROLES[s.role][0] + ' · ' + c.name;
    }
    return null;
  }
  /* shareholders elect directors: a director needs more than half of the shares behind them */
  function election(key, n) {
    const L = holdersAll(key);
    if (!L.length) return { ok: true, pct: 100 };
    const co = R12.brdCos(key)[0];
    const q = R12.qOf(n);
    let yes = co.own;
    const votes = L.map(x => { const v = hrng('el15:' + x.h.name + ':' + n.id)() < 0.25 + q * 0.8; if (v) yes += x.h.pct; return { name: x.h.name, pct: x.h.pct, v }; });
    return { ok: yes > 50, pct: yes, votes };
  }
  const hire13 = ACT.bd13hire;
  ACT.bd13hire = p => {
    const b = R12.brdOf(p.k), n = S.npcs[p.n];
    if (!b || !n || n.hired || (n.adv13 || b.candR) !== 'director' || !holdersAll(p.k).length) return hire13(p);
    const e = election(p.k, n);
    if (!e.ok) {
      toast('Shareholders voted ' + first(n.name) + ' down: only ' + Math.round(e.pct) + '% of the shares were for.', true);
      b.cands = b.cands.filter(x => x !== n.id);
      save();
      render();
      return;
    }
    toast('Elected by ' + Math.round(e.pct) + '% of the shares.');
    hire13(p);
  };
  /* the board appoints the CEO: with directors on the board, hiring the man or woman at the top needs their majority */
  const hm15 = window.hireManager;
  window.hireManager = function (co, n, wage) {
    try {
      const key = R12.brdKeyOf(co);
      const D = dirSeats(key);
      if (co && n && !n.hired && R12.active && R12.active(key) && D.length) {
        const q = R12.qOf(n.stats ? n : Object.assign({ stats: { ops: n.skill || 50, people: n.skill || 50, sales: n.skill || 50, fin: n.skill || 50, risk: n.skill || 50 } }, n));
        const yes = 1 + D.filter(s => hrng('ceo15:' + s.id + ':' + n.id)() < clamp(0.25 + q * 0.9, 0.1, 0.95)).length;
        const total = 1 + D.length;
        if (yes * 2 <= total) {
          toast('The board voted against appointing ' + n.name + ': ' + yes + ' of ' + total + ' for.', true);
          return 'refuse';
        }
      }
    } catch (e) { console.error(e); }
    return hm15.apply(this, arguments);
  };
  /* the board oversees the CEO: three loss months and they want to talk about replacing them */
  const ex14 = R12.extraX;
  R12.extraX = function (key, cos, items) {
    if (ex14) ex14(key, cos, items);
    if (!dirSeats(key).length) return;
    cos.forEach(c => {
      const n = c.mgr && S.npcs[c.mgr];
      const H = (c.hist || []).slice(-3);
      if (!n || H.length < 3 || !H.every(x => x.profit < 0) || S.week - (c.mgrW0 || 0) < 13) return;
      const d = S.npcs[dirSeats(key)[0].id];
      items.push({ who: d.id, st: null, act: 'fireceo', p: { id: c.id }, inv: ['hr', 'legal'], text: 'The board questions ' + n.name + ' as ' + (cos.length > 1 ? 'manager of ' + c.name : 'CEO') + ': three months of losses in a row (' + H.map(x => R12.kf(x.profit)).join(', ') + '). Replace them?' });
    });
  };
  const yes15 = ACT.bd12yes;
  ACT.bd12yes = p => {
    const b = R12.brdOf(p.k), m = b && b.mts.find(x => x.id === p.m), it = m && m.items[p.i];
    if (!it || it.st || it.act !== 'fireceo') return yes15(p);
    const co = getCo(it.p.id);
    it.st = 'yes';
    if (co && co.mgr) { fireManager(co); co.mgr = null; }
    save();
    if (co) go('mgrhire', { id: co.id }); else render();
  };
  /* big owners take a board seat; the board shows who holds votes and who holds the jobs */
  function ownersWeek() {
    const keys = (S.chains || []).map(ch => 'ch:' + ch.id).concat(S.cos.filter(c => c.st === 'open' && !c.chain).map(c => 'co:' + c.id));
    keys.forEach(k => {
      if (!R12.active || !R12.active(k)) return;
      holdersAll(k).forEach(x => {
        if (x.h.pct < 20 || x.h.dir15 || dirSeats(k).length >= 4) return;
        let n = x.h.npc != null && S.npcs[x.h.npc];
        if (!n) { n = genManager(null, 'gen'); n.name = x.h.name; S.npcs[n.id] = n; x.h.npc = n.id; }
        x.h.dir15 = 1;
        const b = R12.brdOf(k);
        if (!b.seats.some(s => s.id === n.id)) {
          const wasHired = n.hired;
          if (!wasHired) n.hired = -4;
          b.seats.push({ id: n.id, kind: wasHired ? 'exec' : 'adv', r: 'director', t: 'Director', fee: 0, w0: S.week, ok: 0, no: 0, mood: 60, owner: 1 });
          info(x.h.name, 'Taking a board seat at ' + R12.brdName(k), 'With ' + Math.round(x.h.pct) + '% of the shares I want a say. I will sit on the board as a director.', x.co.id, 'n');
        }
      });
    });
  }
  const bv13 = R12.boardViewX;
  R12.boardViewX = function (key) {
    const h = bv13.apply(this, arguments);
    if (!R12.active || !R12.active(key)) return h;
    const cos = R12.brdCos(key), co0 = cos[0];
    const ppl = [{ name: S.player.name + ' (you)', pct: co0 ? co0.own : 100, job: cos.some(c => !c.mgr && c.ohrs > 0) ? 'Runs a store' : 'Owner' }];
    holdersAll(key).forEach(x => ppl.push({ name: x.h.name, pct: x.h.pct, job: jobOf(x.h.npc, cos) || (x.h.dir15 ? 'Director' : 'Shareholder only') }));
    const ceo = cos.find(c => c.mgr && S.npcs[c.mgr]);
    if (ceo && !holdersAll(key).some(x => x.h.npc === ceo.mgr)) ppl.push({ name: S.npcs[ceo.mgr].name, pct: 0, job: cos.length > 1 ? 'Store manager · ' + ceo.name : 'CEO' });
    const card = '<h2 class="sec">Who holds power</h2><div class="card"><div class="t11 hd t15"><span>Person</span><span>Votes</span><span>Job</span></div>' + ppl.map(x => '<div class="t11 t15"><span>' + esc(x.name) + '</span><span>' + (x.pct ? Math.round(x.pct) + '%' : '—') + '</span><span>' + esc(x.job) + '</span></div>').join('') + '<span class="tipt">Shares give votes. Jobs run the company day to day. Shareholders elect the board, the board appoints the CEO.</span></div>';
    const i = h.indexOf('<h2 class="sec">Always at the table</h2>');
    return i >= 0 ? h.slice(0, i) + card + h.slice(i) : h + card;
  };
  R7.afterWeek = R7.afterWeek || [];
  R7.afterWeek.push(() => { try { ownersWeek(); } catch (e) { console.error(e); } });
}

/* ===== Round 47: hiring needs a place, swipe between tabs and back, apps that open like apps,
   a luxury web shop, and share capital that is plainly the company's own money. ===== */
window.R47 = window.R47 || {};
(function () {
  'use strict';
  const R47 = window.R47;
  const U = window.UI;
  if (!U) return;
  const { ui, V, ACT, esc, btn, go, render, save, svg, toast } = U;
  const P = o => esc(JSON.stringify(o));
  const live = () => S.cos.filter(c => c.st !== 'sold' && c.st !== 'bust');

  /* ================= 1. nobody else works from your home ================= */
  const atHome = co => !!(co && window.R37 && R37.atHome && R37.atHome(co));
  const placeW = co => (window.R37 && R37.placeW ? R37.placeW(co) : 'place');
  R47.auto = 0;
  function rentSmall(co) {
    const L = premListings(co), l = L[1] || L[0];
    if (!l) return 'bad';
    co.off37 = Date.now();
    const r = setPrem(co, 'home', l.m2, false, l);
    delete co.off37;
    return r;
  }
  R47.rentSmall = rentSmall;
  if (U.ERR) U.ERR.noplace = 'Nobody else can work from your home. Rent a small place first.';
  if (typeof hireWorker === 'function') {
    const hw0 = hireWorker;
    hireWorker = function (co) {
      if (atHome(co)) {
        if (!co.mgr && !R47.auto) return 'noplace';
        if (rentSmall(co) !== 'ok') return 'noplace';
        const m = co.mgr && S.npcs[co.mgr];
        if (m) note(m.name + ' rented a small ' + placeW(co) + ' of ' + co.prem.m2 + ' m² for ' + co.name + ': staff need somewhere to work.', 'n', co.id);
      }
      return hw0.apply(this, arguments);
    };
  }
  if (typeof hireManager === 'function') {
    const hm0 = hireManager;
    hireManager = function (co) {
      if (atHome(co) && !R47.auto) return 'noplace';
      return hm0.apply(this, arguments);
    };
  }
  if (typeof autoSetup === 'function') {
    const as0 = autoSetup;
    autoSetup = function () { R47.auto++; try { return as0.apply(this, arguments); } finally { R47.auto--; } };
  }
  /* the hiring screens say what to do first */
  const placeCard = co => {
    const L = premListings(co), l = L[1] || L[0], W = placeW(co);
    const perk = window.R45 && R45.perks ? R45.perks(co) : '';
    return '<div class="card place47"><div class="bhead"><b>First, a place to work</b></div><span class="tipt">Staff cannot work from your home. A small ' + W + (l ? ' of about ' + l.m2 + ' m²' : '') + ' is enough to start' + (perk ? ': ' + esc(perk) : '.') + '</span>' + btn('Find a ' + W, 'premsheet', { id: co.id }, 'primary wide') + '</div>';
  };
  ['hire', 'mgrhire'].forEach(n => {
    const v0 = V[n];
    if (!v0) return;
    V[n] = function (p) {
      const h = v0.apply(this, arguments);
      try {
        const co = p && p.id && getCo(p.id);
        if (!atHome(co)) return h;
        const m = /^<div class="ptabs">[\s\S]*?<\/div>/.exec(h);
        return (m ? m[0] : '') + placeCard(co);
      } catch (e) { console.error(e); return h; }
    };
  });

  /* ================= 2. share capital is the company's own cash ================= */
  const nc47 = V.newco;
  if (nc47) V.newco = function () {
    let h = nc47.apply(this, arguments);
    try {
      const st = ui.nc || {};
      if (st.form !== 'AS') return h;
      const c = CC();
      h = h.replace('<h3>Money to put in</h3>', '<h3>Money to put in</h3>' + U.row('Share capital, already company cash', U.nok(c.asCapital)) + '<p class="cap47">Counts towards the start cost. Put in the rest below.</p>');
    } catch (e) { console.error(e); }
    return h;
  };

  /* ================= 3. swipe: left and right between tabs, from the left edge to go back ================= */
  /* Tabs: as soon as a sideways drag starts, the neighbouring tab is rendered and both pages follow the finger
     (the old page as a still copy); letting go finishes the move or springs back to where it was. */
  (function () {
    if (!('ontouchstart' in window) && !R47.touchTest) return;
    let sx = 0, sy = 0, t0 = 0, mode = null, edge = false, scr = null, moved = [], car = null;
    const reduce = () => window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
    const tabsOf = s => { const t = s && s.querySelector(':scope > .ptabs, :scope > .subtabs'); return t && t.offsetParent ? t : null; };
    /* the most specific way back on this screen: the last visible back button (a sub-page's own back comes after the header's) */
    const backOf = s => {
      if (!s) return null;
      const bs = [...s.querySelectorAll('[aria-label^="Back"], [data-a="back"], [data-a="phback"]')].filter(b => b.offsetParent && !b.disabled && !b.closest('.sheet, .scrim, .sw47g'));
      return bs[bs.length - 1] || null;
    };
    R47.backOf = backOf;
    R47.tabsOf = tabsOf;
    const after = (s, el) => { const k = [...s.children]; const i = el ? k.indexOf(el) : -1; return k.slice(i + 1).filter(x => !x.classList.contains('sw47g')); };
    const setX = (els, x, o) => els.forEach(e => { e.style.transform = x ? 'translateX(' + x + 'px)' : ''; e.style.opacity = o != null && o < 1 ? o : ''; });
    const settle = els => { els.forEach(e => { e.style.transition = 'transform .18s ease, opacity .18s ease'; }); setX(els, 0); setTimeout(() => els.forEach(e => { e.style.transition = ''; }), 200); };
    const live = () => document.querySelector('#app main.screen');
    const btnsOf = t => [...t.querySelectorAll('button')].filter(b => !b.disabled);

    /* the tab marker: a pill that slides between tabs (it copies the look of the chosen tab) */
    const rgb = s => (String(s).match(/[\d.]+/g) || [0, 0, 0]).slice(0, 3).map(Number);
    const mix = (a, b, k) => 'rgb(' + a.map((v, n) => Math.round(v + (b[n] - v) * k)).join(',') + ')';
    function pillMake(tabs, from) {
      const c = getComputedStyle(from), d = document.createElement('i');
      d.className = 'sw47pill';
      d.style.cssText = 'position:absolute;z-index:0;pointer-events:none;left:0;top:' + from.offsetTop + 'px;height:' + from.offsetHeight + 'px;width:' + from.offsetWidth + 'px;transform:translateX(' + from.offsetLeft + 'px);background:' + c.backgroundColor + ';box-shadow:' + c.boxShadow + ';border-radius:' + c.borderRadius + ';will-change:transform,width';
      tabs.classList.add('sw47t');
      tabs.insertBefore(d, tabs.firstChild);
      return d;
    }
    function pillAt(d, a, b, k) {
      d.style.transform = 'translateX(' + (a.offsetLeft + (b.offsetLeft - a.offsetLeft) * k) + 'px)';
      d.style.width = (a.offsetWidth + (b.offsetWidth - a.offsetWidth) * k) + 'px';
    }
    function pillDone(tabs, d) { if (d) d.remove(); if (tabs) { tabs.classList.remove('sw47t'); [...tabs.children].forEach(b => { b.style.color = ''; }); } }
    R47.pill = { pillMake, pillAt, pillDone };

    /* build the carousel: a still copy of this tab, and the neighbour tab rendered for real */
    function prepare(dir) {
      const tabs = tabsOf(scr);
      const bs = btnsOf(tabs), i = bs.findIndex(b => b.classList.contains('on')), j = i + (dir < 0 ? 1 : -1);
      if (i < 0 || j < 0 || j >= bs.length) return { edgeTab: 1, dir, nodes: after(scr, tabs) };
      const old = after(scr, tabs), sc0 = scr.scrollTop, cs = getComputedStyle(scr);
      const r0 = old[0] ? old[0].getBoundingClientRect().top : 0;
      const g = document.createElement('div');
      g.className = 'sw47g';
      g.style.cssText = 'position:absolute;left:0;right:0;top:0;pointer-events:none;padding-left:' + cs.paddingLeft + ';padding-right:' + cs.paddingRight + ';box-sizing:border-box;will-change:transform';
      old.forEach(n => g.appendChild(n.cloneNode(true)));
      R47.swiping = 1;
      bs[j].click();
      const s2 = live();
      if (!s2) { R47.swiping = 0; return null; }
      const t2 = tabsOf(s2);
      s2.scrollTop = Math.min(sc0, t2 ? t2.offsetTop : 0);
      if (getComputedStyle(s2).position === 'static') s2.style.position = 'relative';
      s2.appendChild(g);
      const gTop = g.firstChild ? g.firstChild.getBoundingClientRect().top : 0;
      const dy = r0 - gTop;
      const cut = t2 ? Math.max(0, t2.getBoundingClientRect().bottom - r0) : 0;
      if (cut > 0) g.style.clipPath = 'inset(' + cut + 'px 0 0 0)';
      const nodes = after(s2, t2);
      nodes.forEach(n => { n.style.willChange = 'transform'; });
      scr = s2;
      /* the tab marker stays on the tab you are on until the swipe is finished */
      const mark = k => { const b2 = t2 ? btnsOf(t2) : []; b2.forEach((b, n) => b.classList.toggle('on', n === k)); };
      mark(i);
      const b2 = t2 ? btnsOf(t2) : [], bi = b2[i], bj = b2[j];
      const pill = bi && bj ? pillMake(t2, bi) : null;
      const cOn = rgb(getComputedStyle(bi || t2).color), cOff = rgb(getComputedStyle(bj || t2).color);
      return { dir, i, j, g, dy, nodes, mark, t2, bi, bj, pill, cOn, cOff, W: s2.clientWidth || window.innerWidth, sc0 };
    }
    function place(c, dx) {
      const e = c.dir < 0 ? Math.min(0, dx) : Math.max(0, dx);
      if (c.edgeTab) { setX(c.nodes, e * 0.25); return; }
      c.g.style.transform = 'translate(' + e + 'px,' + c.dy + 'px)';
      const x = e + (c.dir < 0 ? c.W : -c.W);
      c.nodes.forEach(n => { n.style.transform = 'translateX(' + x + 'px)'; });
      c.e = e;
      if (c.pill) {
        const k = Math.min(1, Math.abs(e) / c.W);
        pillAt(c.pill, c.bi, c.bj, k);
        c.bi.style.color = mix(c.cOn, c.cOff, k);
        c.bj.style.color = mix(c.cOff, c.cOn, k);
      }
    }
    function finish(c, commit) {
      const T = reduce() ? 0 : 220, ease = 'cubic-bezier(.22,.7,.2,1)';
      if (c.edgeTab) { settle(c.nodes); return; }
      const gx = commit ? (c.dir < 0 ? -c.W : c.W) : 0, nx = commit ? 0 : (c.dir < 0 ? c.W : -c.W);
      const all = c.nodes.concat([c.g]);
      all.forEach(n => { n.style.transition = 'transform ' + T + 'ms ' + ease; });
      if (c.pill) {
        c.pill.style.transition = 'transform ' + T + 'ms ' + ease + ', width ' + T + 'ms ' + ease;
        [c.bi, c.bj].forEach(b => { b.style.transition = 'color ' + T + 'ms ' + ease; });
        pillAt(c.pill, c.bi, c.bj, commit ? 1 : 0);
        c.bi.style.color = commit ? mix(c.cOn, c.cOff, 1) : mix(c.cOn, c.cOff, 0);
        c.bj.style.color = commit ? mix(c.cOff, c.cOn, 1) : mix(c.cOff, c.cOn, 0);
      }
      c.g.style.transform = 'translate(' + gx + 'px,' + c.dy + 'px)';
      c.nodes.forEach(n => { n.style.transform = nx ? 'translateX(' + nx + 'px)' : 'translateX(0)'; });
      setTimeout(() => {
        if (commit) c.mark(c.j);
        if (c.pill) { [c.bi, c.bj].forEach(b => { b.style.transition = ''; }); pillDone(c.t2, c.pill); }
        c.g.remove();
        c.nodes.forEach(n => { n.style.transition = ''; n.style.transform = ''; n.style.willChange = ''; });
        if (!commit) {
          /* back to the tab you started on */
          const s = live(), t = tabsOf(s), bs = t ? btnsOf(t) : [];
          if (bs[c.i]) { bs[c.i].click(); const s2 = live(); if (s2) s2.scrollTop = c.sc0; }
        }
        requestAnimationFrame(() => { R47.swiping = 0; });
      }, T + 20);
    }

    /* tapping a tab: the marker slides from the old tab to the new one */
    document.addEventListener('click', e => {
      try {
        const b = e.target.closest && e.target.closest('main.screen > .ptabs > button, main.screen > .subtabs > button');
        if (!b || R47.swiping || b.classList.contains('on') || reduce()) return;
        const tabs = b.parentElement, old = tabs.querySelector(':scope > button.on');
        if (!old) return;
        const bs = btnsOf(tabs), io = bs.indexOf(old), inew = bs.indexOf(b);
        if (io < 0 || inew < 0) return;
        const from = { offsetLeft: old.offsetLeft, offsetWidth: old.offsetWidth };
        requestAnimationFrame(() => {
          const s = live(), t2 = tabsOf(s), b2 = t2 ? btnsOf(t2) : [];
          if (!b2[inew] || !b2[inew].classList.contains('on') || b2.length !== bs.length) return;
          const d = pillMake(t2, b2[inew]);
          pillAt(d, from, from, 0);
          void d.offsetWidth;
          d.style.transition = 'transform .22s cubic-bezier(.22,.7,.2,1), width .22s cubic-bezier(.22,.7,.2,1)';
          pillAt(d, from, b2[inew], 1);
          setTimeout(() => pillDone(t2, d), 260);
        });
      } catch (er) { }
    }, true);

    document.addEventListener('touchstart', e => {
      mode = null;
      if (car) return;
      R47.swiping = 0;
      if (e.touches.length !== 1) return;
      const tg = e.target;
      if (document.querySelector('.scrim') || document.querySelector('.spl47')) return;
      if (tg.closest && tg.closest('input, textarea, select, [contenteditable], .noswipe, .sheet, nav.nb')) return;
      scr = tg.closest && tg.closest('main.screen');
      if (!scr) return;
      const p = e.touches[0];
      sx = p.clientX; sy = p.clientY; t0 = Date.now();
      edge = sx <= 28;
      mode = 'wait';
      /* the touched element may be replaced when the next tab renders; touch events keep going to it, so listen there */
      const off = () => { tg.removeEventListener('touchmove', move); tg.removeEventListener('touchend', endT); tg.removeEventListener('touchcancel', cancelT); };
      const endT = ev => { off(); end(ev); }, cancelT = () => { off(); cancel(); };
      tg.addEventListener('touchmove', move, { passive: true });
      tg.addEventListener('touchend', endT, { passive: true });
      tg.addEventListener('touchcancel', cancelT, { passive: true });
    }, { passive: true });
    function move(e) {
      if (!mode || mode === 'no') return;
      const p = e.touches[0], dx = p.clientX - sx, dy = p.clientY - sy;
      if (mode === 'wait') {
        if (Math.abs(dx) < 10 && Math.abs(dy) < 10) return;
        if (Math.abs(dx) > Math.abs(dy) * 1.4) {
          if (edge && dx > 0 && backOf(scr)) { mode = 'back'; moved = [scr]; }
          else if (tabsOf(scr)) {
            mode = 'tab';
            car = prepare(dx < 0 ? -1 : 1);
            if (!car) { mode = 'no'; return; }
          }
          else { mode = 'no'; return; }
        } else { mode = 'no'; return; }
      }
      if (mode === 'back') { if (!reduce()) setX(moved, Math.max(0, dx), 1 - Math.min(0.35, Math.max(0, dx) / window.innerWidth * 0.5)); }
      else if (car) place(car, dx);
    }
    function end(e) {
      const m = mode;
      mode = null;
      if (m !== 'back' && m !== 'tab') return;
      const p = (e.changedTouches && e.changedTouches[0]) || { clientX: sx, clientY: sy };
      const dx = p.clientX - sx, dt = Math.max(1, Date.now() - t0), fast = Math.abs(dx) / dt > 0.45;
      if (m === 'back') {
        const b = backOf(scr);
        if (b && (dx > window.innerWidth * 0.3 || (fast && dx > 50))) { b.click(); setX(moved, 0); return; }
        settle(moved);
        return;
      }
      const c = car;
      car = null;
      if (!c) return;
      const ev = c.dir < 0 ? Math.min(0, dx) : Math.max(0, dx);
      finish(c, !c.edgeTab && (Math.abs(ev) > (c.W || 390) * 0.25 || (fast && Math.abs(ev) > 30)));
    }
    function cancel() { const c = car; car = null; if (mode === 'back') settle(moved); else if (c) finish(c, false); mode = null; }
  })();
  /* ================= 4. phone apps open like apps ================= */
  const SPL = {
    bank: ['bank', 'Bank', 'Signing in securely', '#10261f', '#7fc4a4', 1100],
    tax: ['tax', 'Tax', 'Signing in with your ID', '#16202c', '#8fb3d9', 1000],
    invest: ['invest', 'Investing', 'Fetching prices', '#251f15', '#d9b26f', 900],
    startups: ['rocket', 'Startups', 'Loading pitches', '#1d1a2a', '#b6a3e8', 800],
    news: ['news', 'News', 'Today’s edition', '#1c1d21', '#e8e4dc', 700],
    reviews: ['star', 'Reviews', 'Loading reviews', '#272112', '#f0c24b', 750],
    stats: ['chart', 'Stats', 'Crunching the numbers', '#181c24', '#8fb3d9', 800],
    rivals: ['chart', 'Rivals', 'Looking around', '#221a1a', '#e09a8a', 700],
    registry: ['gov', 'Registry', 'Connecting to the register', '#17201c', '#9fcab4', 900],
    clubs: ['shield', 'Football', 'Loading the league', '#11241a', '#7fd49a', 800],
    settings: ['cog', 'Settings', '', '#1a1b1e', '#c9ccd2', 380],
    lux: ['', 'AURUM', 'Private sales', '#0b0a08', '#c9a86a', 1000]
  };
  const warm = {};
  let lastK = null;
  function splash(k) {
    const c = SPL[k];
    if (!c) return;
    if ((navigator.webdriver && !R47.splashOn) || window.innerWidth > 960) return;
    document.querySelectorAll('.spl47').forEach(x => x.remove());
    const el = document.createElement('div');
    el.className = 'spl47' + (k === 'lux' ? ' lux' : '');
    el.style.setProperty('--bg', c[3]);
    el.style.setProperty('--fg', c[4]);
    el.style.setProperty('--d', c[5] + 'ms');
    el.innerHTML = (k === 'lux' ? '<b class="mark">AURUM</b>' : '<span class="ico">' + svg(c[0], 38) + '</span><b>' + esc(c[1]) + '</b>') + (c[2] ? '<small>' + esc(c[2]) + '</small>' : '') + '<i class="lb"><u></u></i>';
    document.body.appendChild(el);
    const out = () => { if (!el.isConnected || el.classList.contains('out')) return; el.classList.add('out'); setTimeout(() => el.remove(), 260); };
    el.addEventListener('click', out);
    el.addEventListener('touchstart', out, { passive: true });
    setTimeout(out, c[5]);
  }
  R47.splash = splash;
  new MutationObserver(() => {
    const k = ui.tab === 'phone' ? ((ui.ph && ui.ph.n) || 'home') : null;
    const prev = lastK;
    lastK = k;
    if (!k || k === 'home' || k === 'phfolder' || k === prev) return;
    const now = Date.now();
    const cold = prev === 'home' || prev === 'phfolder' || (prev === null && !(warm[k] && now - warm[k] < 180000));
    warm[k] = now;
    if (cold) splash(k);
  }).observe(document.getElementById('app'), { childList: true });

  /* ================= 5. Luxury: a web shop ================= */
  const LX = window.LUX47;
  if (LX && V.lux) {
    const { LUX, LUXI, SELL_FEE } = LX;
    /* the car range, with photographs (window.CARIMG47); ids c1-c5 are kept so collections in old saves still match */
    const CARS = [
      ['c15', 'Hyperion Zenith Tourer', 'Electric estate, seats five', 1300000, 0.02, -0.14, 0.04],
      ['c1', 'Aurelion S saloon', 'Chauffeur-grade comfort, loses value quickly', 1800000, 0.03, -0.12, 0.04],
      ['c11', 'Bavaria 8 Apex coupé', 'Four seats, 625 hp', 2700000, 0.03, -0.1, 0.04],
      ['c10', 'Apex V10 GT', 'One of the last naturally aspirated V10s', 3000000, 0.03, 0.01, 0.08],
      ['c7', 'Vanguard Artemis', 'Light hybrid supercar in papaya', 3300000, 0.035, -0.08, 0.06],
      ['c8', 'Vanguard Sovereign GT', 'Grand tourer in racing green', 3600000, 0.03, -0.07, 0.05],
      ['c9', 'Vanguard Sovereign GT Black Edition', 'Midnight blue, black chrome', 4100000, 0.03, -0.06, 0.05],
      ['c2', 'Brandt 912 GT RS', 'A track car with number plates', 4200000, 0.03, -0.02, 0.07],
      ['c4', 'Ravenna Tempesta', 'Mid-engine V6 hybrid', 4500000, 0.04, -0.05, 0.1],
      ['c3', 'Aurelion GT Noir', 'Matte black, built for the track', 4800000, 0.035, 0, 0.09],
      ['c14', 'Hyperion Zenith One', 'V12 hybrid flagship', 7500000, 0.035, -0.03, 0.09],
      ['c13', 'Apex Apexian SUV', 'The most expensive way to go off-road', 8000000, 0.03, -0.06, 0.05],
      ['c12', 'Monarch Regent limousine', 'Hand-built, starlight headliner', 9500000, 0.03, -0.05, 0.05],
      ['c5', 'Halvorsen Hyper 99', 'One of 99 built, 1,500 hp', 38000000, 0.03, 0.03, 0.18],
      ['c6', 'Ravenna Fulmine 63', 'One of 63, carbon and bronze', 42000000, 0.03, 0.04, 0.2]
    ];
    LUX.cars.items = CARS;
    CARS.forEach(x => { LUXI[x[0]] = { cat: 'cars', id: x[0], n: x[1], d: x[2], price: x[3], up: x[4], g: x[5], vol: x[6] }; });
    const CIMG = window.CARIMG47 || {};
    const LUXP = {
      c1: ['car', { lux: 1, ev: 1, c: '#c9cdd2' }], c2: ['car', { lux: 1, c: '#8e1f24' }], c3: ['car', { lux: 1, c: '#0f3b3a' }], c4: ['car', { lux: 1, c: '#d9a441' }], c5: ['car', { lux: 1, c: '#2b2f36' }],
      w1: ['watch'], w2: ['watch'], w3: ['jewel'], w4: ['watch'],
      a1: ['art', { style: 'land', frame: 'gold' }], a2: ['comic'], a3: ['wine'], a4: ['art', { style: 'geo', frame: 'black', mat: 7 }], a5: ['art', { style: 'fields', frame: 'gold' }],
      y1: ['yacht'], y2: ['yacht'], y3: ['yacht'], j1: ['jet'], j2: ['jet'], j3: ['jet']
    };
    const COVER = { cars: 'c2', watches: 'w4', art: 'a5', yachts: 'y2', jets: 'j2' };
    const CSLUG = { cars: 'cars', watches: 'watches-and-jewellery', art: 'art-and-collectibles', yachts: 'yachts', jets: 'private-jets' };
    const TLD = { NO: '.no', SE: '.se', PL: '.pl', LT: '.lt', DE: '.de', UK: '.co.uk', FR: '.fr', ES: '.es', NL: '.nl', US: '.com', CA: '.ca', AU: '.com.au', JP: '.jp', KR: '.kr', BR: '.com.br' };
    const dom = () => 'aurum' + (TLD[S.country] || '.com');
    const slug = s => String(s).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
    const trend = g => g >= 0.04 ? 'Usually rises' : g > 0 ? 'Holds its value' : g > -0.06 ? 'Loses some value' : 'Loses value fast';
    const img = (k, big) => {
      if (CIMG[k]) return '<span class="lximg photo' + (big ? ' big' : '') + '"><img src="' + CIMG[k] + '" alt="" loading="lazy" decoding="async"></span>';
      const d = LUXP[k] || ['box'];
      if (d[0] === 'art' && window.artSvg) return '<span class="lximg art' + (big ? ' big' : '') + '">' + artSvg(k, d[1]) + '</span>';
      return '<span class="lximg' + (big ? ' big' : '') + '">' + (window.picSvg ? picSvg(d[0], k, d[1] || {}) : '') + '</span>';
    };
    const price = v => esc(U.nok(v));
    const mine = () => (S.lux = S.lux || []);
    const bagN = () => mine().length;
    V.lux = function (p) {
      p = p || {};
      const it = p.k && LUXI[p.k];
      const cat = it ? it.cat : p.c && LUX[p.c] ? p.c : null;
      const pg = it ? 'item' : cat ? 'cat' : p.pg === 'mine' ? 'mine' : 'home';
      const url = dom() + (pg === 'item' ? '/' + CSLUG[cat] + '/' + slug(it.n) : pg === 'cat' ? '/' + CSLUG[cat] : pg === 'mine' ? '/account/collection' : '');
      const fresh = url !== R47.lxu;
      R47.lxu = url;
      let h = '<div class="lx47"><div class="lxbar"><button class="lxbk" data-a="phback" aria-label="Back">' + svg('back', 18) + '</button><span class="lxurl">' + svg('shield', 12) + '<span>' + esc(url) + '</span></span><button class="lxbag" data-a="lxgo" data-p="' + P({ pg: 'mine' }) + '" aria-label="Your collection">' + svg('bag', 18) + (bagN() ? '<i>' + bagN() + '</i>' : '') + '</button></div><i class="lxload' + (fresh ? ' go' : '') + '"></i>';
      if (pg === 'home') {
        const f = LUXI.c14;
        h += '<div class="lxhero"><b class="mark">AURUM</b><small>Private sales · ' + esc((CO[S.country] || {}).name || '') + '</small></div>';
        h += '<button class="lxfeat" data-a="lxgo" data-p="' + P({ k: f.id }) + '">' + img(f.id, 1) + '<span class="lxcap"><small>New in</small><b>' + esc(f.n) + '</b><em>' + price(f.price) + '</em></span></button>';
        h += '<h3 class="lxh">Collections</h3><div class="lxgrid">' + Object.keys(LUX).map(k => '<button class="lxcard" data-a="lxgo" data-p="' + P({ c: k }) + '">' + img(COVER[k]) + '<b>' + esc(LUX[k].n) + '</b><em>From ' + esc(mshort(Math.min.apply(null, LUX[k].items.map(x => x[3])))) + '</em></button>').join('') + '</div>';
        h += '<button class="lxacct" data-a="lxgo" data-p="' + P({ pg: 'mine' }) + '"><span><small>Your collection</small><b>' + (bagN() ? bagN() + (bagN() === 1 ? ' piece' : ' pieces') + ' · worth ' + esc(mshort(window.luxValue ? luxValue() : 0)) : 'Nothing yet') + '</b></span><i>›</i></button>';
      } else if (pg === 'cat') {
        const L = LUX[cat];
        h += '<div class="lxcrumb">Aurum / ' + esc(L.n) + '</div><h2 class="lxt">' + esc(L.n) + '</h2><p class="lxsub">' + L.items.length + ' pieces</p>';
        h += '<div class="lxgrid">' + L.items.map(x => '<button class="lxcard" data-a="lxgo" data-p="' + P({ k: x[0] }) + '">' + img(x[0]) + '<b>' + esc(x[1]) + '</b><em>' + price(x[3]) + '</em></button>').join('') + '</div>';
      } else if (pg === 'item') {
        const short = S.cash < it.price;
        h += '<div class="lxcrumb">Aurum / ' + esc(LUX[cat].n) + '</div>' + img(it.id, 1) + '<h2 class="lxt">' + esc(it.n) + '</h2><p class="lxsub">' + esc(it.d) + '</p><div class="lxprice">' + price(it.price) + '</div>';
        h += '<div class="lxspec">' + [['Upkeep, insurance and storage', price(it.up * it.price / 12) + ' a month'], ['Value over time', trend(it.g)], ['If you sell', Math.round(SELL_FEE * 100) + '% in selling costs']].map(r => '<div><span>' + r[0] + '</span><b>' + r[1] + '</b></div>').join('') + '</div>';
        h += '<button class="lxbuy" data-a="lxbuy" data-p="' + P({ k: it.id }) + '"' + (short ? ' disabled' : '') + '>' + (short ? 'Your personal cash is ' + esc(mshort(Math.max(0, S.cash))) : 'Purchase') + '</button><p class="lxfine">Paid from your personal cash. Delivered, insured and stored for you.</p>';
      } else {
        const L = mine();
        const up = L.reduce((t, x) => t + (LUXI[x.k] ? LUXI[x.k].up * x.price / 12 : 0), 0);
        h += '<div class="lxcrumb">Aurum / Account</div><h2 class="lxt">Your collection</h2><div class="lxspec">' + [['Worth today', esc(mshort(window.luxValue ? luxValue() : 0))], ['Upkeep', esc(mshort(up)) + ' a month'], ['Pieces', L.length]].map(r => '<div><span>' + r[0] + '</span><b>' + r[1] + '</b></div>').join('') + '</div>';
        if (!L.length) h += '<p class="lxsub">Nothing yet. What you buy is kept here.</p><button class="lxbuy ghost" data-a="lxgo" data-p="' + P({}) + '">Browse the shop</button>';
        else h += '<div class="lxlist">' + L.map(x => {
          const i = LUXI[x.k] || { n: x.k };
          const ch = x.price ? (x.val - x.price) / x.price : 0;
          return '<div class="lxrow">' + img(x.k) + '<span class="lxrt"><b>' + esc(i.n) + '</b><small>Bought ' + esc(dateStr(x.w)) + ' for ' + esc(mshort(x.price)) + '</small><small>Worth ' + esc(mshort(x.val)) + ' · ' + (Math.round(ch * 100) === 0 ? 'unchanged' : '<span class="' + (ch > 0 ? 'pos' : 'neg') + '">' + (ch > 0 ? 'up ' : 'down ') + Math.abs(Math.round(ch * 100)) + '%</span>') + '</small></span><button class="lxsell" data-a="luxsell" data-p="' + P({ id: x.id }) + '">Sell</button></div>';
        }).join('') + '</div>';
      }
      return h + '<div class="lxfoot">' + esc(dom()) + ' · Fictional shop</div></div>';
    };
    ACT.lxgo = p => go('lux', p || {});
    ACT.lxbuy = p => {
      const it = LUXI[p.k];
      if (!it) return;
      U.confirmThen('Buy ' + esc(it.n) + '?', 'You pay ' + U.nok(it.price) + ' from your personal cash. Upkeep is about ' + U.nok(it.up * it.price / 12) + ' a month.', 'Buy', () => {
        const n0 = mine().length;
        ACT.luxbuygo({ k: it.id });
        if (mine().length > n0) { ui.ph = { n: 'lux', p: { pg: 'mine' } }; render(true); }
      });
    };
  }
})();

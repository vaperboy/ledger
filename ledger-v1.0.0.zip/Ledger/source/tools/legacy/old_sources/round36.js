/* ===== Round 36: fewer places, each with a reason to exist.
   Pop-ups only close with their own buttons (a small × where there is nothing else).
   A menu that unlocks later (manager reviews, meetings, boards) announces itself once: Take a look or Not now.
   Money › Results holds months, accounts, transactions and bills. Group › Market is the market map and every rival.
   New company also offers: join a franchise, start a startup, your own service firm.
   Phone: Tax sits in the Bank, Startups in Investing, News is one page, Reports and timing in Settings.
   Inbox: Waiting · Messages (messages and email together) · Meetings (once you have a manager). ===== */
window.R36 = window.R36 || {};
(function () {
  'use strict';
  const R36 = window.R36;
  const U = window.UI;
  if (!U) return;
  const { ui, V, ACT, esc, row, btn, card, go, render, save, svg, openSheet, closeSheet } = U;
  const CT = window.CT;
  const P = o => esc(JSON.stringify(o));
  const live = () => S.cos.filter(c => c.st !== 'sold' && c.st !== 'bust');
  function blockEnd(h, i) {
    const tag = /^<(\w+)/.exec(h.slice(i))[1];
    const re = new RegExp('<' + tag + '[\\s>]|</' + tag + '>', 'g');
    re.lastIndex = i;
    let d = 0, m;
    while ((m = re.exec(h))) {
      if (m[0][1] === '/') { d--; if (d === 0) return m.index + m[0].length; } else d++;
    }
    return h.length;
  }
  const cutEl = (h, i) => i < 0 ? h : h.slice(0, i) + h.slice(blockEnd(h, i));
  function withView(p, f) {
    const old = ui.view;
    ui.view = { n: 'co', p: p };
    try { return f(); } finally { ui.view = old; }
  }
  const rowBtn = (a, p, ic, title, sub, right) => '<button class="lrow" data-a="' + a + '" data-p="' + P(p) + '"><span class="lic">' + svg(ic, 20) + '</span><span class="ctext"><b>' + title + '</b>' + (sub ? '<small>' + esc(sub) + '</small>' : '') + '</span>' + (right || '<i>›</i>') + '</button>';
  const busy = () => ui.dayBusy || ui.untl || ui.repLock;

  /* ================= pop-ups: no tapping away ================= */
  const CLOSERS = /data-a="(sheetclose|al30later|unl36no|repdone|cancelsheet|confno)"|>\s*(Close|Cancel|Not now|Do later|Continue|OK|Done|No thanks|Back|Later|Not yet|Skip)\s*</i;
  window.sheet36 = sh => {
    let h = sh.html || '';
    if (!CLOSERS.test(h)) h = '<button class="x36" data-a="sheetclose" aria-label="Close">×</button>' + h;
    return '<div class="scrim" data-a="scrim"><div class="sheet ' + (sh.cls || '') + '" role="dialog" aria-modal="true">' + h + '</div></div>';
  };

  /* ================= menus that unlock later ================= */
  const UNL = [
    {
      k: 'mgr', ok: () => R35.hasMgr && R35.hasMgr(),
      items: [['Manager reviews', 'Group › Group', 'A scorecard for every manager, and a review whenever you want one.'], ['Meetings', 'Inbox', 'Call a manager in. They bring proposals with costs and expected revenue; you decide.']],
      look: () => { ACT.tab('hq'); ACT.hqtab('grp'); go('managers'); }
    },
    {
      k: 'board', ok: () => R35.anyBoard && R35.anyBoard(),
      items: [['Boards', 'Group › Group, and Company in each company', 'Board members advise and vote on big decisions. Emergencies come to you.']],
      look: () => { ACT.tab('hq'); ACT.hqtab('grp'); go('boards12', {}); }
    }
  ];
  function unlState() {
    if (!S.unl36) { S.unl36 = {}; UNL.forEach(u => { try { if (u.ok()) S.unl36[u.k] = 1; } catch (e) { } }); }
    return S.unl36;
  }
  function unlCheck() {
    try {
      if (typeof S === 'undefined' || !S || !S.cos || S.over || ui.sheet || busy() || (ui.view && ui.view.n === 'weekreport')) return;
      const st = unlState(), L = UNL.filter(u => !st[u.k] && (() => { try { return u.ok(); } catch (e) { return false; } })());
      if (!L.length) return;
      L.forEach(u => { st[u.k] = 1; });
      save();
      const items = [].concat.apply([], L.map(u => u.items));
      openSheet('<div class="unl36"><small>Unlocked</small><h2>' + (items.length > 1 ? 'New in your game' : 'New: ' + esc(items[0][0])) + '</h2>' + items.map(x => '<div class="unli36"><b>' + esc(x[0]) + '</b><span class="where">' + esc(x[1]) + '</span><span>' + esc(x[2]) + '</span></div>').join('') + '<div class="btnrow col">' + btn('Take a look', 'unl36go', { k: L[0].k }, 'primary wide') + btn('Not now', 'unl36no', undefined, 'ghost wide') + '</div></div>', 'unl36s');
    } catch (e) { console.error(e); }
  }
  R36.unlCheck = unlCheck;
  ACT.unl36go = p => { closeSheet(); const u = UNL.find(x => x.k === p.k); if (u) u.look(); };
  ACT.unl36no = () => closeSheet();
  setInterval(unlCheck, 1500);

  /* ================= Money › Results ================= */
  const RT = [['m', 'Months'], ['acc', 'Accounts'], ['tx', 'Transactions'], ['bills', 'Bills']];
  V.titles.res36 = 'Results';
  V.heads.res36 = p => { const co = p && getCo(p.id); return { t: 'Results', sub: co ? esc(co.name) : '' }; };
  const stripSub = h => cutEl(h, h.indexOf('<div class="subhead">'));
  V.res36 = function (p) {
    const co = p && getCo(p.id);
    if (!co) return card('Company not found.');
    const bd = BD[co.type];
    let t = ui.res36 || 'm';
    if (t === 'bills' && !(window.R29 && R29.on && R29.on() && V.payroll29)) t = 'm';
    ui.res36 = t;
    const tabs = RT.filter(x => x[0] !== 'bills' || (window.R29 && R29.on && R29.on())).filter(x => x[0] !== 'm' || V.month30);
    let h = '<div class="ptabs">' + tabs.map(x => '<button class="' + (t === x[0] ? 'on' : '') + '" data-a="res36t" data-p="' + P({ v: x[0] }) + '">' + x[1] + '</button>').join('') + '</div>';
    try {
      if (t === 'm') h += V.month30({ id: co.id });
      else if (t === 'acc') h += stripSub(withView({ id: co.id, t: 'fin', s: 'books' }, () => CT.fin(co, bd)));
      else if (t === 'tx') h += stripSub(withView({ id: co.id, t: 'fin', s: 'tx' }, () => CT.fin(co, bd)));
      else h += V.payroll29({ id: co.id, v: 'bills' });
    } catch (e) { console.error(e); h += card('Nothing to show yet.'); }
    return h;
  };
  ACT.res36t = p => { ui.res36 = p.v; render(true); };

  /* ================= Group › Market: the market map and every rival in one place ================= */
  V.titles.mkt36 = 'Market';
  V.heads.mkt36 = () => { const o = V.heads.market ? V.heads.market() : {}; return Object.assign({}, o, { t: 'Market' }); };
  V.mkt36 = function () {
    let m = V.market ? V.market() : '';
    let rv = V.rivals ? V.rivals() : '';
    { const s = rv.indexOf('<div class="card sense">'); if (s >= 0 && m.indexOf('analyst') >= 0) rv = rv.slice(0, s) + rv.slice(blockEnd(rv, s)); }
    const i = m.indexOf('<h2 class="sec">Competitors</h2>');
    const ins = rv ? '<h2 class="sec">Your rivals</h2>' + rv : '';
    if (i >= 0) {
      const j = m.indexOf('<h2', i + 10);
      m = m.slice(0, i) + ins + (j >= 0 ? m.slice(j) : '');
    } else m += ins;
    return m;
  };

  /* ================= New company: other ways in ================= */
  V.titles.found36 = 'Your startups';
  V.found36 = function () {
    const old = ui.stab;
    ui.stab = 'found';
    let h = '';
    try { h = V.startups(); } finally { ui.stab = old; }
    return cutEl(h, h.indexOf('<div class="subtabs">'));
  };
  V.titles.svc36 = 'Your own service firm';
  V.svc36 = function () {
    const h = V.dealroom ? V.dealroom() : '';
    const i = h.indexOf('<h2 class="sec">Your own service firms</h2>');
    if (i < 0) return card('<p class="muted">Not available.</p>');
    const j = h.indexOf('<div', i);
    return h.slice(j, blockEnd(h, j));
  };
  const nb36 = V.newbiz;
  if (nb36) V.newbiz = function () {
    const h = nb36.apply(this, arguments);
    try {
      const b = [];
      if (V.franchises) b.push(rowBtn('go', { n: 'franchises' }, 'biz', 'Join a franchise', 'A known brand, their rules, a fee'));
      if (V.startups) b.push(rowBtn('go', { n: 'found36' }, 'rocket', 'Start a startup', 'Build a product, raise money'));
      if (!b.length) return h;
      /* the ready-made ways in come first */
      return '<h2 class="sec">Join or build</h2><div class="lrows">' + b.join('') + '</div><h2 class="sec">Start from scratch</h2>' + h;
    } catch (e) { return h; }
  };

  /* ================= Phone ================= */
  /* Investing: stocks, crypto, funds, startups */
  const inv36 = V.invest;
  if (inv36) V.invest = function (p) {
    const t = ui.itab || (p && p.tab) || 'stocks';
    const T4 = [['stocks', 'Stocks'], ['crypto', 'Crypto'], ['funds', 'Funds'], ['su', 'Startups']];
    if (t === 'su' && V.startups) {
      if (ui.stab === 'found') ui.stab = 'deals';
      let s = V.startups();
      s = s.replace(/<button class="[^"]*" data-a="stab" data-p="[^"]*found[^"]*">[^<]*<\/button>/, '');
      return U.tabsRow(T4, 'su', 'itab') + s;
    }
    const h = inv36.apply(this, arguments);
    return h.replace(U.tabsRow(T4.slice(0, 3), t, 'itab'), U.tabsRow(T4, t, 'itab'));
  };
  /* Bank: accounts, loans, credit, tax */
  const bank36 = V.bank;
  if (bank36 && V.tax) V.bank = function () {
    const T = [['acc', 'Accounts'], ['loans', 'Loans'], ['credit', 'Credit'], ['tax', 'Tax']];
    if (ui.btab === 'tax') return U.tabsRow(T, 'tax', 'btab') + V.tax();
    const h = bank36.apply(this, arguments), cur = ui.btab || 'acc';
    const old = U.tabsRow(T.slice(0, 3), cur, 'btab');
    return h.indexOf(old) >= 0 ? h.replace(old, U.tabsRow(T, cur, 'btab')) : h;
  };
  /* News: one page, the local paper first */
  const news36 = V.news;
  if (news36) V.news = function (p) {
    const old = ui.nt;
    const strip = h => cutEl(h, h.search(/<div class="(ptabs|subtabs)">/));
    try {
      /* round 40: all the news first; the local paper is one tap away */
      ui.nt = 'paper'; const a = strip(news36.call(this, { t: 'paper' }));
      ui.nt = 'news'; const b = strip(news36.call(this, { t: 'news' }));
      ui.nt = 'world'; const c = strip(news36.call(this, { t: 'world' }));
      let card0 = '';
      const ms = /<div class="card paper28">([\s\S]*?<h2>[\s\S]*?<\/h2>)/.exec(a);
      if (ms) card0 = '<button class="card opt2 paper40" data-a="phapp" data-p="' + P({ n: 'paper40' }) + '"><div class="bhead"><b>' + esc(window.R31 && R31.paperName ? R31.paperName() : 'The local paper') + '</b><span class="pill blue">Read ›</span></div><span class="tipt">' + (/<h2>([\s\S]*?)<\/h2>/.exec(ms[1]) || [])[1] + '</span></button>';
      return card0 + '<h2 class="sec">Headlines</h2>' + b + '<h2 class="sec">Economy</h2>' + c;
    } catch (e) { ui.nt = old; return news36.apply(this, arguments); } finally { ui.nt = old; }
  };
  V.titles.paper40 = 'The paper';
  V.paper40 = function () { const old = ui.nt; ui.nt = 'paper'; try { const h = news36.call(this, { t: 'paper' }); return h.replace(/^<div class="(ptabs|subtabs)">[\s\S]*?<\/div>/, ''); } finally { ui.nt = old; } };
  /* Settings: how reports reach you */
  const set36 = V.settings;
  if (set36 && V.reports) V.settings = function () {
    const h = set36.apply(this, arguments);
    return '<div class="lrows">' + rowBtn('phapp', { n: 'reports' }, 'doc', 'Reports and timing', 'What reaches you, and when') + '</div>' + h;
  };

  /* ================= Inbox ================= */
  const mt36 = V.meetings;
  if (mt36) V.meetings = function () {
    const mgr = R35.hasMgr && R35.hasMgr();
    if (ui.mtab === 'mail' && ui.thread == null) ui.mtab = 'msgs';
    if (ui.mtab === 'meet' && !mgr) ui.mtab = 'dec';
    let h = mt36.apply(this, arguments);
    try {
      if (ui.thread != null) return h;
      /* one Messages tab: email counts there too */
      const mb = /<button class="[^"]*" data-a="mtab" data-p="mail">Email(?: <b class="cnt">(\d+)<\/b>)?<\/button>/.exec(h);
      if (mb) {
        h = h.replace(mb[0], '');
        const n = +(mb[1] || 0);
        if (n) h = h.replace(/(data-a="mtab" data-p="msgs">Messages)(?: <b class="cnt">(\d+)<\/b>)?/, (all, a, m) => a + ' <b class="cnt">' + ((+m || 0) + n) + '</b>');
      }
      if (!mgr) h = h.replace(/<button class="[^"]*" data-a="mtab" data-p="meet">[^<]*<\/button>/, '');
      const t = ui.mtab || 'dec';
      if (t === 'msgs' && V.mail) {
        const mail = V.mail().replace(/data-a="thread"/g, 'data-a="thr36m"');
        const k = h.lastIndexOf('</div>');
        if (mail && !/class="calm"|No email|Nothing/.test(mail.slice(0, 120))) h = h.slice(0, k) + '<h2 class="sec">Email</h2>' + mail + h.slice(k);
      }
      if (t === 'dec' && V.bigmeet && S.bigOff) {
        const o = S.bigOff, f = h.indexOf('<div class="fill">');
        const r = '<div class="lrows">' + rowBtn('go', { n: 'bigmeet' }, 'deal', 'Big meeting', o.pct + '% of ' + o.tgt + ' · on the table until ' + dateStr(o.exp), '<span class="pill amb">Offer</span>') + '</div>';
        if (f >= 0) h = h.slice(0, f + 18) + r + h.slice(f + 18);
      }
    } catch (e) { console.error(e); }
    return h;
  };
  ACT.thr36m = p => { ui.mtab = 'mail'; ui.thread = p.k; render(true); };
})();

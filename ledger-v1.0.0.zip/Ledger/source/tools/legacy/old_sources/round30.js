/* ===== Round 30: tidier screens, monthly bills and results, event bookings, marketing that behaves like marketing.
   1  Clients: every "How you sell" choice (positioning, project model, focus...) is a collapsed menu showing the current pick.
   2  "Prices follow inflation" sits inside the Prices and rivals box.
   3  A complaint alert leads straight to the complaint, not the overview.
   4  Staff: "Find a manager" and "Find workers" swap places.
   5  Overview: monthly result at the top, weekly cost table and owner block folded into one short list.
   6  The "N things need you" bar is gone: each new problem pops up once; "Do later" brings it back when it matters again.
   7  The day card only shows special moments (best day, fully booked, reviews, payday, bills, big sales).
   8  In day mode every recurring cost (insurance, leasing, marketing, accounting, other fixed costs) is billed monthly.
   9  Monthly results: income against expenses and the profit, for every month.
   10 Event agency: bookings also come from referrals and repeat clients; bookings and deliveries are whole events.
   11 Marketing: real benchmarks, chance-based results per campaign, channel fit per business, ranges on screen. ===== */
window.R30 = window.R30 || {};
(function () {
  const R30 = window.R30;
  const U = window.UI, { ui, V, ACT, esc, row, btn, card, go, render, save, toast, svg, openSheet, closeSheet } = U;
  const CT = window.CT;
  const P = o => esc(JSON.stringify(o));
  const pillp = (t, c) => '<span class="pill ' + (c || '') + '">' + t + '</span>';
  const live = () => S.cos.filter(c => c.st !== 'sold' && c.st !== 'bust');
  const sgn = v => v > 0 ? 'pos' : v < 0 ? 'neg' : '';
  const plus = v => (v >= 0 ? '+' : '−') + mshort(Math.abs(v));
  const mLabel = m => MN[m % 12] + ' ' + Math.floor(m / 12);
  /* the end index of the element that opens at i (counts nested divs/buttons/details of the same tag) */
  function blockEnd(h, i) {
    const tag = /^<(\w+)/.exec(h.slice(i))[1];
    const re = new RegExp('<' + tag + '[\\s>]|</' + tag + '>', 'g');
    re.lastIndex = i;
    let d = 0, m;
    while ((m = re.exec(h))) {
      if (m[0][1] === '/') { d--; if (d === 0) return m.index + m[0].length; } else d++;
    }
    return h.length;
  }
  function cutAfter(h, marker) {
    const i = h.indexOf(marker);
    if (i < 0) return h;
    const j = h.indexOf('<', i + marker.length);
    if (j < 0) return h;
    return h.slice(0, i) + h.slice(blockEnd(h, j));
  }
  R30.blockEnd = blockEnd;

  /* ---------- 1, 2: Clients tab ---------- */
  ui.k30 = ui.k30 || {};
  document.addEventListener('toggle', e => {
    const d = e.target;
    if (d && d.tagName === 'DETAILS' && d.dataset && d.dataset.k30) { if (d.open) ui.k30[d.dataset.k30] = 1; else delete ui.k30[d.dataset.k30]; }
  }, true);
  const cli30 = CT.cli;
  CT.cli = function (co, bd) {
    let h = cli30.apply(this, arguments);
    try {
      /* inflation into the price box */
      let infl = '';
      const re = /<div class="card"><div class="bhead"><b>Prices follow inflation<\/b>([\s\S]*?)<\/div><\/div>(<span class="tipt">[\s\S]*?<\/span>)?<\/div>/;
      const m = h.match(re);
      if (m) {
        h = h.replace(m[0], '');
        infl = '<div class="bhead infl30"><span>Prices follow inflation</span>' + m[1] + '</div></div>' + (m[2] || '');
      }
      const pk = '<button class="card opt2" data-a="go" data-p="' + P({ n: 'pricemoves', p: { id: co.id } }) + '">';
      const i = h.indexOf(pk);
      if (i >= 0) {
        const j = h.indexOf('</button>', i);
        const inner = h.slice(i + pk.length, j).replace('<span class="pill blue">Price moves ›</span>', '<button class="pill blue" data-a="go" data-p="' + P({ n: 'pricemoves', p: { id: co.id } }) + '">Price moves ›</button>');
        h = h.slice(0, i) + '<div class="card opt2 price30">' + inner + infl + '</div>' + h.slice(j + 9);
      } else if (infl) h = '<div class="card">' + infl + '</div>' + h;
      /* every selling choice becomes a collapsed menu showing the current pick */
      const s = h.indexOf('<h2 class="sec">How you sell</h2>');
      if (s >= 0) {
        const e = h.indexOf('<h2', s + 10), end = e < 0 ? h.length : e;
        /* each choice card is cut out by counting its nested divs, so nothing inside can spill out of the box */
        let part = h.slice(s, end), out = '', pos = 0;
        const hd = /<div class="card"><div class="bhead"><b>([^<]*)<\/b><small>([^<]*)<\/small><\/div>/g;
        let m;
        while ((m = hd.exec(part))) {
          const e2 = blockEnd(part, m.index), n = m[1], cur = m[2];
          const body = part.slice(m.index + m[0].length, e2 - 6);
          const k = co.id + ':' + n;
          out += part.slice(pos, m.index) + '<details class="card knob30" data-k30="' + esc(k) + '"' + (ui.k30[k] ? ' open' : '') + '><summary><span class="ctext"><b>' + n + '</b><small>' + cur + '</small></span><i class="chev30">›</i></summary><div class="kb30">' + body + '</div></details>';
          pos = e2;
          hd.lastIndex = e2;
        }
        part = out + part.slice(pos);
        h = h.slice(0, s) + part + h.slice(end);
      }
      h = h.replace('<h2 class="sec">Complaints</h2>', '<h2 class="sec" id="compl30">Complaints</h2>');
    } catch (e) { console.error(e); }
    return h;
  };
  const knob0 = ACT.setknob;
  if (knob0) ACT.setknob = p => {
    Object.keys(ui.k30).forEach(k => { if (k.indexOf(p.id + ':') === 0) delete ui.k30[k]; });
    return knob0(p);
  };

  /* ---------- 3: go straight to the thing that needs you ---------- */
  function routeFor(co, text) {
    if (/complaint/i.test(text)) return { l: 'Answer the complaint', n: 'co', p: { id: co.id, t: 'cli' }, sc: 'compl30' };
    if (/document/i.test(text)) return { l: 'Open documents', n: 'co', p: { id: co.id, t: 'doc' } };
    if (/home office/i.test(text)) return { l: 'Find an office', n: 'co', p: { id: co.id, t: 'ops', s: 'assets', eqt: 'place' } };
    if (/staff problem/i.test(text)) return { l: 'See the staff', n: 'co', p: { id: co.id, t: 'st' } };
    if (/unpaid|negative cash|wages/i.test(text)) return { l: 'Payroll and bills', n: 'payroll29', p: { id: co.id } };
    return { l: 'Open ' + co.name, n: 'co', p: { id: co.id } };
  }
  R30.routeFor = routeFor;
  ACT.go30 = p => {
    go(p.n, p.p);
    if (p.sc) setTimeout(() => { const el = document.getElementById(p.sc); if (el) el.scrollIntoView({ block: 'start' }); }, 80);
  };

  /* ---------- 4: Find a manager on top, Find workers below (only while there is no manager) ---------- */
  const ppl30 = CT.ppl;
  CT.ppl = function (co, bd) {
    let h = ppl30.apply(this, arguments);
    try {
      if (co.mgr || bd.fam === 'club') return h;
      const top = btn('＋ Find workers', 'hirego', { id: co.id }, 'chip primary'), bot = btn('Find a manager', 'mgrgo', { id: co.id }, 'wide');
      if (h.indexOf(top) >= 0 && h.indexOf(bot) >= 0) h = h.replace(top, '\u0000T').replace(bot, btn('＋ Find workers', 'hirego', { id: co.id }, 'wide')).replace('\u0000T', btn('Find a manager', 'mgrgo', { id: co.id }, 'chip primary'));
    } catch (e) { console.error(e); }
    return h;
  };

  /* ---------- 9: monthly results ---------- */
  const COST30 = { cogs: 'Materials and goods', wages: 'Wages and payroll', rent: 'Rent and power', mkt: 'Marketing', ins: 'Insurance', acc: 'Accounting and payroll service', dep: 'Depreciation', int: 'Loan interest', oth: 'Leasing and other costs', fine: 'Fines', loss: 'Refunds and losses', tax: 'Company tax' };
  const me30 = monthEndCo;
  monthEndCo = function (co) {
    const snap = Object.assign({}, co.bk.m || {});
    const r = me30.apply(this, arguments);
    try { const h = co.hist[co.hist.length - 1]; if (h && h.m === monthIdx(S.week)) h.bk = snap; } catch (e) { }
    return r;
  };
  const monthOf = co => { const b = co.bk.m || {}, inc = b.rev || 0, ex = sumExp(b); return { inc, ex, p: inc - ex, b }; };
  R30.monthOf = monthOf;
  V.titles.month30 = 'Monthly results';
  V.heads.month30 = p => { const co = getCo(p.id); return { t: 'Monthly results', sub: co ? esc(co.name) + ' · income against expenses' : '' }; };
  V.month30 = function (p) {
    const co = getCo(p.id);
    if (!co) return card('Company not found.');
    const now = monthOf(co), H = (co.hist || []).slice(-12).reverse();
    const yr = sum(H.filter(x => Math.floor(x.m / 12) === Math.floor(monthIdx(S.week) / 12)), x => x.profit) + now.p;
    let h = '<div class="tri"><div><span>This month</span><b class="' + sgn(now.p) + '">' + plus(now.p) + '</b></div><div><span>Last month</span><b class="' + (H[0] ? sgn(H[0].profit) : '') + '">' + (H[0] ? plus(H[0].profit) : '–') + '</b></div><div><span>This year</span><b class="' + sgn(yr) + '">' + plus(yr) + '</b></div></div>';
    const one = (lab, inc, ex, b, open) => {
      const ks = b ? Object.keys(COST30).filter(k => b[k]) : [];
      return '<details class="card mon30d"' + (open ? ' open' : '') + '><summary><span class="ctext"><b>' + lab + '</b><small>Income ' + mshort(inc) + ' · expenses ' + mshort(ex) + '</small></span><b class="' + sgn(inc - ex) + '">' + plus(inc - ex) + '</b></summary>' + row('Income', mshort(inc)) + (ks.length ? ks.map(k => row(COST30[k], '−' + mshort(b[k]))).join('') : '<span class="tipt">No breakdown kept for this month.</span>') + row('Profit', '<span class="' + sgn(inc - ex) + '">' + plus(inc - ex) + '</span>', 'total') + '</details>';
    };
    h += one(mLabel(monthIdx(S.week)) + ' so far', now.inc, now.ex, now.b, true);
    h += H.map(x => one(mLabel(x.m), x.rev, x.rev - x.profit, x.bk, false)).join('');
    h += '<div class="note">Income is what customers bought; expenses include wages, rent, goods, insurance, marketing and wear on equipment. Bills are paid on payday and on the last day of the month.</div>';
    return h;
  };

  /* ---------- 5: a calmer overview ---------- */
  const ov30 = CT.ov;
  CT.ov = function (co, bd) {
    let h = ov30.apply(this, arguments);
    try {
      if (!co || co.st === 'setup' || co.type === 'hold' || bd.fam === 'club' || h.indexOf('class="card ovhero"') < 0) return h;
      h = h.replace(/<div class="tri"><div><span>Revenue\/wk<\/span>[\s\S]*?<\/b><\/div><\/div>/, '');
      h = h.replace(/<div class="kv [^"]*"><span>Unpaid invoices<\/span><b>[\s\S]*?<\/b><\/div>/, '');
      h = cutAfter(h, '<h2 class="sec">Costs per week</h2>').replace('<h2 class="sec">Costs per week</h2>', '');
      h = cutAfter(h, '<h2 class="sec">Owner view</h2>').replace('<h2 class="sec">Owner view</h2>', '');
      h = cutAfter(h, '<h2 class="sec">Monthly result</h2>').replace('<h2 class="sec">Monthly result</h2>', '');
      /* one short list instead of many one-line boxes */
      const rows = [];
      h = h.replace(/<div class="lrows">((?:<button class="lrow"[^>]*>[\s\S]*?<\/button>)+)<\/div>/g, (all, inner) => { rows.push(inner); return ''; });
      const own = '<button class="lrow" data-a="cofin" data-p="' + P({ id: co.id, s: 'value' }) + '"><span class="lic">' + svg('coin', 20) + '</span><span class="ctext"><b>Ownership and value</b><small>You own ' + (co.own % 1 ? co.own.toFixed(1) : co.own) + '% · worth about ' + mshort(companyValue(co)) + '</small></span><i>›</i></button>';
      h += '<h2 class="sec">More</h2><div class="lrows">' + rows.join('') + own + '</div>';
      /* the month at a glance, right under the cash */
      const m = monthOf(co), last = (co.hist || [])[co.hist.length - 1];
      const pr = (co.hist || []).slice(-8).map(x => x.profit);
      const mon = '<button class="card mon30" data-a="go" data-p="' + P({ n: 'month30', p: { id: co.id } }) + '"><div class="bhead"><b>' + mLabel(monthIdx(S.week)) + ' so far</b><small>' + (last ? 'Last month ' + plus(last.profit) : 'First month') + ' ›</small></div><div class="tri"><div><span>Income</span><b>' + mshort(m.inc) + '</b></div><div><span>Expenses</span><b>' + mshort(m.ex) + '</b></div><div><span>Profit</span><b class="' + sgn(m.p) + '">' + plus(m.p) + '</b></div></div>' + (pr.length > 1 ? '<div class="sp30">' + spark(pr, 300, 34) + '</div>' : '') + '</button>';
      const hi = h.indexOf('<div class="card ovhero"');
      const he = blockEnd(h, hi);
      h = h.slice(0, he) + mon + (bd.id === 'event' && !(window.R41 && R41.isHT && R41.isHT(co)) ? bookCard(co) : '') + h.slice(he);
    } catch (e) { console.error(e); }
    return h;
  };
  const spark = (a, w, hgt) => (U.spark ? U.spark(a, w, hgt) : '');

  /* ---------- 6: one popup per new problem instead of the "needs you" bar ---------- */
  const DAYN = () => S.week * 7 + (S.day || 0);
  const WHY = [
    [/complaint/i, 'A customer wrote in. Answer within two weeks, or they post a bad review.'],
    [/document/i, 'Something the authorities expect is missing. An inspection can bring a fine.'],
    [/staff problem/i, 'Someone on the team is causing trouble. Left alone, it spreads.'],
    [/wages/i, 'Staff have not been paid. Every day late hurts morale; people start to leave.'],
    [/unpaid bills/i, 'Suppliers and the landlord are waiting for money. Put money in or cut costs.'],
    [/negative cash/i, 'The company is in the red and running on its overdraft.'],
    [/home office/i, 'Four or more people round a kitchen table. Morale and quality slip every week until you get an office.'],
    [/closed/i, 'The company is closed and earns nothing until you reopen it.']
  ];
  const al0 = window.coAlerts;
  window.coAlerts = function (co) {
    const out = al0.apply(this, arguments);
    try {
      const c = co.pr29 && co.pr29.late;
      if (c && c.why !== 'slip' && co.st !== 'sold' && co.st !== 'bust') out.unshift([c.why === 'cash' ? 'Wages only partly paid' : 'Wages not paid', 'bad']);
    } catch (e) { }
    return out;
  };
  function sigOf(co, text) {
    if (/complaint/i.test(text)) { const due = (co.compl || []).some(c => c.st === 'open' && S.week - c.w >= 1); return text + (due ? ' · due' : ''); }
    return text;
  }
  function pending() {
    const out = [];
    S.al30 = S.al30 || {};
    const seen = {};
    live().forEach(co => (window.coAlerts(co) || []).filter(a => a[1] === 'bad').forEach(a => {
      const key = co.id + ':' + a[0].replace(/[0-9]+/g, '#'), sig = sigOf(co, a[0]);
      seen[key] = 1;
      const e = S.al30[key], now = DAYN();
      if (!e || e.sig !== sig || (e.later && now - e.t >= 7)) out.push({ co, text: a[0], key, sig });
    }));
    Object.keys(S.al30).forEach(k => { if (!seen[k]) delete S.al30[k]; }); /* solved: forget it, so it can pop up again if it returns */
    return out;
  }
  function maybeAlert() {
    try {
      if (!S || S.over || ui.sheet || ui.dayBusy || ui.untl || ui.repLock || ui.tab !== 'home' || (ui.view && ui.view.n && ui.view.n !== 'home')) return;
      const L = pending();
      if (!L.length) return;
      const a = L[0], r = routeFor(a.co, a.text), why = (WHY.find(w => w[0].test(a.text)) || [0, ''])[1];
      S.al30[a.key] = { sig: a.sig, t: DAYN(), later: 1 };
      openSheet('<div class="al30"><small>' + esc(a.co.name) + '</small><h2>' + esc(a.text) + '</h2>' + (why ? '<p class="lead">' + esc(why) + '</p>' : '') + (L.length > 1 ? '<span class="tipt">' + (L.length - 1) + ' more after this one.</span>' : '') + '<div class="btnrow col">' + btn(esc(r.l), 'al30go', { k: a.key, n: r.n, p: r.p, sc: r.sc }, 'primary wide') + btn('Do later', 'al30later', { k: a.key }, 'ghost wide') + '</div></div>', 'al30s');
    } catch (e) { console.error(e); }
  }
  R30.maybeAlert = maybeAlert;
  ACT.al30go = p => {
    if (S.al30[p.k]) S.al30[p.k].later = 0;
    ui.sheet = null;
    save();
    ACT.go30(p);
  };
  ACT.al30later = p => {
    if (S.al30[p.k]) { S.al30[p.k].later = 1; S.al30[p.k].t = DAYN(); }
    ui.sheet = null;
    save();
    render();
    setTimeout(maybeAlert, 60);
  };
  ['nextday', 'untilneeded'].forEach(k => {
    const f = ACT[k];
    if (f) ACT[k] = function () { const r = f.apply(this, arguments); const wait = () => (ui.dayBusy || ui.untl || ui.repLock ? setTimeout(wait, 150) : maybeAlert()); setTimeout(wait, 60); return r; };
  });
  const home30 = V.home;
  V.home = function () {
    let h = home30.apply(this, arguments);
    try {
      const i = h.indexOf('<button class="needbar"');
      if (i >= 0) h = h.slice(0, i) + h.slice(blockEnd(h, i));
      if (!ui.sheet && !ui.al30t) { ui.al30t = 1; setTimeout(() => { ui.al30t = 0; maybeAlert(); }, 120); }
    } catch (e) { console.error(e); }
    return h;
  };

  /* ---------- 7: the day card only for special moments ---------- */
  const special = x => /best day ever|fully booked/.test(x[1] || '') || /★/.test(x[0] || '') || ['Payday', 'Bills', 'Booked', 'Delivered'].indexOf(x[0]) >= 0 || Math.abs(x[2] || 0) >= KC(50000);
  const rd30 = window.R10DAY;
  window.R10DAY = function (d) {
    const r = rd30 ? rd30.apply(this, arguments) : undefined;
    try { if (ui.day28 && ui.day28.notes) ui.day28.notes = ui.day28.notes.filter(special); } catch (e) { }
    return r;
  };

  /* ---------- 8: recurring costs are billed monthly (day mode) ---------- */
  R30.sim = 0;
  const nw30 = nextWeek;
  nextWeek = function () { R30.sim++; try { return nw30.apply(this, arguments); } finally { R30.sim--; } };
  const MONTHLY = { oth: 1, mkt: 1, ins: 1, acc: 1, rent: 1 };
  const pay30 = payCo;
  payCo = function (co, amt, cat, label) {
    if (R30.sim && !label && MONTHLY[cat] && window.R29 && R29.on() && co && co.pay && co.st !== 'sold' && co.st !== 'bust') {
      amt = Math.round(amt);
      if (amt <= 0) return true;
      co.pay.other = (co.pay.other || 0) + amt;
      bk(co, cat, amt);
      co.f30 = co.f30 || {};
      co.f30[cat] = (co.f30[cat] || 0) + amt;
      return true;
    }
    return pay30.apply(this, arguments);
  };
  const ins30 = CT.insurance;
  if (ins30) CT.insurance = function () { return ins30.apply(this, arguments).replace('Premium is paid weekly.', window.R29 && R29.on() ? 'Premiums are billed with the other bills on the last day of the month.' : 'Premium is paid weekly.'); };

  /* ---------- 10: event bookings ---------- */
  const EVN = {
    0: ['summer party', 'Christmas party', 'conference', 'product launch', 'staff kick-off', 'anniversary dinner', 'customer seminar'],
    1: ['summer concert', 'club night', 'outdoor festival', 'charity concert', 'album release show'],
    2: ['wedding', 'wedding', 'wedding', 'silver wedding']
  };
  const focusOf = co => (co.knob && co.knob.seg) || 0;
  function dress(co, j, src, from) {
    const f = focusOf(co);
    j.src = src;
    j.from = from || '';
    if (src === 'rep' && from) j.client = from;
    else j.client = f === 2 ? personName() : brandCoName(CO[co.country] || CC(), f === 1 ? 'venue' : 'svc');
    j.due = S.week + j.wks;
    const mo = wDate(j.due).getUTCMonth();
    const ok = (EVN[f] || EVN[0]).filter(w => /Christmas/.test(w) ? mo >= 10 : /summer|outdoor/.test(w) ? mo >= 4 && mo <= 7 : true);
    j.what = pick(ok.length ? ok : EVN[0]);
  }
  function newJob(co, bd, d) {
    const tick = bd.ticket * ticketMult(co, bd) * knobFx(co, 'tt');
    const v = Math.round(tick * Math.exp(gauss() * 0.4 - 0.08) / 1000) * 1000, tw = bd.tw;
    const base = (tw.mat + tw.sub) * modProd(co, 'price') * (S.econ.mat * 0.5 + 0.5) * (1 + gauss() * tw.over);
    const j = { id: uid(), v, wks: Math.max(1, Math.round(tw.wks * rng(0.7, 1.4))), p: 0, cf: Math.max(0.05, base), delay: 0, w0: S.week };
    dress(co, j, d.src, d.from);
    return j;
  }
  const evName = j => (j.src === 'rep' ? j.client + '’s ' + j.what + ' again' : j.client + (/wedding/.test(j.what) ? '’s ' : ' ') + j.what);
  function booked(co, j) {
    const how = j.src === 'ref' ? 'Recommended by ' + j.from + '.' : j.src === 'rep' ? j.client + ' was happy last time and books again.' : 'Came from people who know your name.';
    addMsg({ kind: 'info', from: co.name, title: 'New booking: ' + evName(j), body: money(j.v) + ', to deliver around ' + dateStr(j.due) + '. ' + how + ' 30% deposit now, the rest after the event.', co: co.id, tone: 'good', status: 'done' });
  }
  function delivered(co, j, ev) {
    const q = co.q != null ? co.q : 55, happy = chance(clamp(0.45 + (q - 55) / 80, 0.15, 0.92));
    const f = focusOf(co);
    if (happy) {
      const r1 = f === 2 ? 0.6 : 0.45, r2 = f === 2 ? 0.25 : 0.15, rep = f === 0 ? 0.55 : f === 1 ? 0.45 : 0.03;
      if (chance(r1)) ev.due.push({ w: S.week + rint(3, 14), src: 'ref', from: j.client });
      if (chance(r2)) ev.due.push({ w: S.week + rint(6, 20), src: 'ref', from: j.client });
      if (chance(rep)) ev.due.push({ w: S.week + rint(44, 56), src: 'rep', from: j.client });
    }
    addMsg({ kind: 'info', from: co.name, title: 'Delivered: ' + (j.what ? evName(j) : 'an event'), body: (j.what ? '' : j.client + '. ') + (happy ? 'The client was delighted and will tell others about you.' : 'The client was not fully happy. Expect no recommendations from this one.') + ' Final invoice sent.', co: co.id, tone: happy ? 'good' : '', status: 'done' });
  }
  R30.ev = { dress, booked, delivered, evName };
  const pc30 = FAM.project.custom;
  FAM.project.custom = function (co, bd, ctx) {
    if (bd.id !== 'event' || bd.tw.dev) return pc30.apply(this, arguments);
    const fm = co.fm;
    fm.jobs = fm.jobs || [];
    const before = new Set(fm.jobs.map(j => j.id)), prev = fm.jobs.slice();
    const r = pc30.apply(this, arguments);
    try {
      const ev = fm.ev30 = fm.ev30 || { due: [], m: -1, bm: 0, dm: 0, tot: 0 };
      const mi = monthIdx(S.week);
      if (ev.m !== mi) { ev.m = mi; ev.bm = 0; ev.dm = 0; }
      fm.jobs.forEach(j => { if (!before.has(j.id)) { dress(co, j, 'mkt'); ev.bm++; booked(co, j); } });
      const ids = new Set(fm.jobs.map(j => j.id));
      let nd = 0;
      prev.forEach(j => { if (!ids.has(j.id)) { nd++; ev.dm++; ev.tot++; delivered(co, j, ev); } });
      const room = Math.exp(-Math.max(0, (fm.backlogWk || 0) - 8) / 14);
      ev.due = ev.due.filter(d => {
        if (S.week < d.w) return true;
        if (co.st === 'open' && chance(room)) { const j = newJob(co, bd, d); fm.jobs.push(j); fm.won++; ev.bm++; booked(co, j); }
        return false;
      });
      ctx.units = nd; /* whole events delivered this week, not fractions of work done */
    } catch (e) { console.error(e); }
    return r;
  };
  function bookCard(co) {
    const fm = co.fm || {}, ev = fm.ev30 || { due: [], bm: 0, dm: 0 }, J = (fm.jobs || []).slice().sort((a, b) => (a.due || 0) - (b.due || 0));
    const refs = ev.due.filter(d => d.src === 'ref').length, reps = ev.due.filter(d => d.src === 'rep').length;
    return '<div class="card"><div class="bhead"><b>Bookings this month</b><small>' + (refs + reps ? (refs ? refs + ' recommendation' + (refs > 1 ? 's' : '') + ' out there' : '') + (refs && reps ? ' · ' : '') + (reps ? reps + ' likely to book again' : '') : 'Happy clients bring the next ones') + '</small></div><div class="tri"><div><span>Booked</span><b>' + ev.bm + '</b></div><div><span>In progress</span><b>' + J.length + '</b></div><div><span>Delivered</span><b>' + ev.dm + '</b></div></div>' + J.slice(0, 3).map(j => row(esc(j.what ? evName(j) : j.client), Math.round(j.p * 100) + '% · ' + mshort(j.v))).join('') + '</div>';
  }

  /* ---------- 11: marketing ---------- */
  const X = window.R19 && R19.CHX;
  if (X) {
    /* real benchmarks (sources in the round notes), converted at about NOK 10.7 per USD */
    X.google.cpm = 50000; X.google.resp = 0.07;           /* WordStream 2024 search ads: CPC $4.66, conversion rate 6.96% */
    X.meta.cpm = 130;                                      /* Lebesgue: average Facebook CPM $12.15 in 2024 */
    X.flyer.cpm = 1200; X.flyer.resp = 0.005; X.flyer.conv = 0.25; /* JICMAIL 2024: door drops 0.6% response; NOK 1.20 a household is a game estimate */
    /* referral rewards: a new channel that only works once you have happy customers */
    CH.ref = { n: 'Referral rewards', eff: 3, sc: 2000, loc: 0.8, b2b: 1.2, mw: 0, note: 'Rewards customers who bring a friend or a client. Needs happy customers first.', opts: [0, 500, 1500, 4000] };
    X.ref = { cpm: 0, resp: 0.02, conv: 0.5, age: [1, 1, 1, 1], what: 'customers who could recommend you', loyal: 1 };
  }
  /* how well each channel suits each kind of business (game estimates), applied on top of the base table */
  const famAdj = { svc: { ref: 1.4 }, project: { ref: 1.8, flyer: 1, meta: 1, tiktok: 1 }, prod: { ref: 1.3 }, logi: { ref: 1.2 }, venue: { ref: 0.6, google: 2.2 }, retail: { ref: 0.5 }, fin: { ref: 1.4 }, rent: { ref: 0.8 } };
  Object.keys(famAdj).forEach(f => { CHAFF_FAM[f] = Object.assign(CHAFF_FAM[f] || {}, famAdj[f]); });
  const typeAdj = {
    photo: { meta: 1.5, tiktok: 1.5, ref: 1.5 },
    plumber: { google: 1.4, local: 1.3, flyer: 1.2, meta: 0.8 },
    webdev: { b2b: 1.2, google: 1.1, flyer: 0.4 },
    staffing: { b2b: 1.3, flyer: 0.4, tiktok: 0.6 },
    cons: { b2b: 1.3, ref: 1.5, flyer: 0.4, tiktok: 0.5 },
    carclean: { flyer: 1.3, local: 1.2, google: 1.2 }
  };
  Object.keys(typeAdj).forEach(t => { CHAFF_TYPE[t] = Object.assign(CHAFF_TYPE[t] || {}, typeAdj[t]); });
  /* an event agency's buyers depend on its focus: companies, concert-goers or couples */
  const AUD = { event: [0.85, 0.3, 0.1] };
  /* companies book through contacts, fairs and search; concert-goers through video and posters; couples through social, wedding fairs and friends */
  const EVFIT = [{ b2b: 1.4, fair: 1.3, google: 1.2, ref: 1.8, flyer: 0.6, meta: 0.8, tiktok: 0.5 }, { tiktok: 3.5, meta: 3, flyer: 2.5, bill: 1.5, b2b: 0.4, ref: 1.2 }, { meta: 2.8, tiktok: 2.2, flyer: 2, fair: 1.6, ref: 2, b2b: 0.2 }];
  CHAFF_TYPE.event = EVFIT[0];
  function withAud(co, fn) {
    const bd = co && BD[co.type], a = bd && AUD[bd.id];
    if (!a) return fn();
    const keep = bd.aud;
    const f = focusOf(co), tk = CHAFF_TYPE[bd.id];
    bd.aud = a[f] != null ? a[f] : keep;
    CHAFF_TYPE[bd.id] = EVFIT[f] || EVFIT[0];
    try { return fn(); } finally { bd.aud = keep; CHAFF_TYPE[bd.id] = tk; }
  }
  const mw30 = window.mktWeek;
  window.mktWeek = function (co, bd) { const a = arguments, t = this; return withAud(co, () => mw30.apply(t, a)); };
  const tune30 = window.tune;
  if (tune30) window.tune = function (co) { const a = arguments, t = this; return withAud(co, () => tune30.apply(t, a)); };
  /* how many people are actually shopping for this each week: few people buy a wedding or a car in any given week,
     so a big-ticket business runs out of interested buyers long before it runs out of people to show ads to (game estimate) */
  const UPP = { cons: 8, webdev: 40, cleaning: 3, hotel: 2, restaurant: 2 };
  R30.inMarket = (co, bd) => {
    const pop = ((cityOf(co.city) || {}).pop || 150) / 300;
    return Math.max(0.4, 3 * (bd.Dc || 1) / (UPP[bd.id] || 1) * Math.sqrt(Math.max(0.1, pop)));
  };
  /* what else decides a campaign's result: rivals and your price against theirs, and how long it has been running */
  window.R30M = function (co, bd, k) {
    let f = 1;
    try { f *= clamp(window.rivalMult ? window.rivalMult(co, bd) : 1, 0.3, 1.25); } catch (e) { }
    const m = co.mkt && co.mkt[k], wk = m ? S.week - (m.since != null ? m.since : S.week) : 0;
    f *= wk <= 0 ? 0.6 : wk === 1 ? 0.85 : wk > 26 ? 0.9 : 1; /* a new campaign starts slow; a long-running one gets tired */
    return f;
  };
  /* a likely range: campaign luck (creative, timing) and plain chance on top of the expected number */
  function range(mu, vol) {
    if (!(mu > 0)) return '0';
    const sl = vol ? 0.9 : 0.45, sh = vol ? 0.4 : 0.1;
    const lo = mu * Math.exp(-1.28 * sl - sh), hi = mu * Math.exp(1.28 * sl - sh);
    const L = Math.max(0, Math.floor(lo - 1.28 * Math.sqrt(lo))), H = Math.max(L + 1, Math.ceil(hi + 1.28 * Math.sqrt(hi)));
    return L + '–' + H;
  }
  R30.range = range;
  window.R30rng = (perWeek, k) => range(perWeek, X && X[k] && X[k].vol);
  if (window.R19) R19.planTxt = (co, PL) => {
    try {
      const bd = BD[co.type];
      if (!X || !X[PL.ch] || !bd.Dc) return '';
      return withAud(co, () => {
        const keep = co.mktT;
        co.mktT = { ag: PL.ag };
        const R = R19.chanCalc(co, bd, PL.ch, PL.b);
        co.mktT = keep;
        if (!R) return '';
        const w = PL.w || 13, ramp = w <= 1 ? 0.6 : (0.6 + 0.85 + Math.max(0, w - 2)) / w;
        let rv = 1;
        try { rv = clamp(window.rivalMult ? window.rivalMult(co, bd) : 1, 0.3, 1.25); } catch (e) { }
        const mu = R.cust * w * ramp * rv;
        return ' · reach ~' + Math.round(R.reach).toLocaleString('en-US').replace(/,/g, ' ') + '/wk · likely ' + range(mu, X[PL.ch].vol) + ' customers over ' + w + ' wk' + (PL.w ? '' : ' (13-wk view)');
      });
    } catch (e) { return ''; }
  };
  /* the marketing tab: one summary that keeps awareness, leads, new and repeat customers, revenue and profit apart */
  const mk30 = CT.marketing;
  CT.marketing = function (co, bd) {
    let h = mk30.apply(this, arguments);
    try {
      const s = co.mk19;
      if (!s || !s.ch || !Object.keys(s.ch).length) return h;
      const C = Object.keys(s.ch).map(k => s.ch[k]);
      const sp = sum(C, c => c.sp), le = sum(C, c => c.leads), nw = sum(C, c => c.cust), base = sum(C, c => c.base || 0), rev = sum(C, c => c.rev);
      const cm = Math.max(0.15, (bd.m || 0.1) + 0.25), prof = rev * cm - sp;
      h += '<h2 class="sec">All campaigns so far</h2><div class="card">' + row('Spent', money(sp)) + row('How well known', awWord(co.aware)) + row('Leads', le < 10 ? le.toFixed(1) : Math.round(le)) + row('New customers', Math.round(nw)) + row('Still buying from you', Math.round(base)) + row('Their purchases', money(rev)) + row('Profit after ad spend', '<span class="' + sgn(prof) + '">' + plus(prof) + '</span>', 'total') + '<span class="tipt">Profit is an estimate: their purchases times your usual margin, minus what the ads cost. Results vary: two identical campaigns can do very differently, and some weeks bring nobody.</span></div>';
    } catch (e) { console.error(e); }
    return h;
  };
  /* used by the planner to order channels: the real fit for this business, per krone */
  const FITB = { flyer: { svc: 1, venue: 1.1, retail: 1, project: 0.7, prod: 0.3, logi: 0.4 }, google: { svc: 1.2, venue: 0.8, retail: 0.9, project: 1.1, prod: 0.6, logi: 0.8 }, meta: { svc: 0.9, venue: 1.2, retail: 1.1, project: 0.5, prod: 0.5, logi: 0.5 }, tiktok: { svc: 0.6, venue: 1.2, retail: 1.1, project: 0.3, prod: 0.4, logi: 0.3 }, local: { svc: 1, venue: 1, retail: 1, project: 0.9, prod: 0.5, logi: 0.6 }, bill: { svc: 0.7, venue: 1, retail: 1.1, project: 0.6, prod: 0.5, logi: 0.6 }, seo: { svc: 1.1, venue: 0.8, retail: 1.1, project: 1, prod: 0.8, logi: 0.8 }, mail: { svc: 0.8, venue: 1.2, retail: 1.2, project: 0.4, prod: 0.6, logi: 0.5 }, b2b: { svc: 1, venue: 0.2, retail: 0.3, project: 1.1, prod: 1.2, logi: 1.1 }, fair: { svc: 0.6, venue: 0.3, retail: 0.4, project: 1, prod: 1.2, logi: 1 } };
  R30.chScore = (bd, k) => {
    const x = X && X[k];
    if (!x) return 0;
    const per = x.cpm ? 1000 / x.cpm * x.resp * x.conv * 1000 : x.resp * x.conv * 40;
    const aud = bd.aud || 0, aFit = x.b2b ? clamp(aud * 1.4, 0.08, 1.3) : clamp((1 - aud) + aud * ((CH[k] && CH[k].b2b) || 0.3), 0.15, 1);
    return ((FITB[k] || {})[bd.fam] || 0.5) * chAff(bd, k) * aFit * per;
  };
})();

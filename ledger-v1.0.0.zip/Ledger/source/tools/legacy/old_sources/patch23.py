# round 36: fewer places, rankings with every rival, pop-ups that stay until answered, unlock notes
path = '/home/claude/w3/ledger.html'
T = '/home/claude/w3/tools/'
t = open(path, encoding='utf8').read()
mark = '/* ===== Round 32: PC and iPad.'
assert t.count(mark) == 1, 'r32 mark'
t = t.replace(mark, open(T + 'round36.js', encoding='utf8').read() + '\n' + mark)
i = t.rindex('</style>')
t = t[:i] + open(T + 'round36.css', encoding='utf8').read() + '\n' + t[i:]
R = [
    ("    return ui.sheet ? '<div class=\"scrim\" data-a=\"scrim\"><div class=\"sheet ' + ui.sheet.cls + '\" role=\"dialog\" aria-modal=\"true\">' + ui.sheet.html + '</div></div>' : '';",
     "    return ui.sheet ? (window.sheet36 ? window.sheet36(ui.sheet) : '<div class=\"scrim\" data-a=\"scrim\"><div class=\"sheet ' + ui.sheet.cls + '\" role=\"dialog\" aria-modal=\"true\">' + ui.sheet.html + '</div></div>') : '';"),
    ("    if (a === 'scrim') {\n      if (e.target === t) closeSheet();\n      return;\n    }",
     "    if (a === 'scrim') return; /* round 36: a pop-up closes only with its own buttons */"),
    ("    if (e.key === 'Escape' && ui.sheet) closeSheet();",
     "    if (e.key === 'Escape' && ui.sheet && document.querySelector('.sheet > .x36')) closeSheet();"),
]
for a, b in R:
    assert t.count(a) == 1, (a[:60], t.count(a))
    t = t.replace(a, b)
open(path, 'w', encoding='utf8').write(t)
print('patch23 ok')

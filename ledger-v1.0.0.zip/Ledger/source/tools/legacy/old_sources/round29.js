/* ===== Round 29: payday.
   Before: wages, rent and supplier bills piled up all month, were settled inside the weekly simulation at month end,
   and that one lump was then spread over the next week's days, so cash rose for three weeks and fell for one with no
   explanation. Now, when the game is played day by day:
   - each company has a payday (company settings, default the 25th; a weekend payday moves to the Friday before),
     and payroll leaves company cash in one go on that real day, with a message and a line on the day card;
   - rent and supplier bills leave on the last day of the month, also on the real day;
   - Home shows costs so far this month and the next payday, every company has a "Payroll and bills" row;
   - an owner-run company's payroll is the owner's job: a reminder arrives seven days ahead, the owner approves it,
     and if payday passes without approval the staff are not paid (morale falls, people leave, a wage claim follows);
   - an accountant (per payslip) or a manager with payroll software (monthly fee) can run it automatically instead;
   - a sole trader's own withdrawals never go through payroll; a limited company owner's salary is a normal payslip
     in the company's payroll, paid on payday with tax withheld.
   Played week by week (test grids, old saves that never used days) everything stays as before. ===== */
window.R29 = window.R29 || {};
(function () {
  const R29 = window.R29;
  const U = window.UI, { ui, V, ACT, esc, row, btn, card, go, render, save, toast, svg } = U;
  const P = o => esc(JSON.stringify(o));
  const pillp = (t, c) => '<span class="pill ' + (c || '') + '">' + t + '</span>';
  const DN = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const INHOUSE = { fin: 1, club: 1, hold: 1, energy: 1 };
  const DAYS = [1, 5, 10, 12, 15, 20, 25, 28, 0]; /* 0 = last day of the month */

  R29.on = () => !!(S && S.dmode);

  /* ---------- dates ---------- */
  const today = () => new Date(wDate(S.week).getTime() + (S.day || 0) * DAY);
  const mIdx = d => d.getUTCFullYear() * 12 + d.getUTCMonth();
  const dnum = d => Math.round(d.getTime() / DAY);
  const lastDay = (y, m) => new Date(Date.UTC(y, m + 1, 0)).getUTCDate();
  const dstr = d => DN[d.getUTCDay()] + ' ' + d.getUTCDate() + ' ' + MN[d.getUTCMonth()];
  const sdate = d => d.getUTCDate() + ' ' + MN[d.getUTCMonth()];
  const dayLbl = v => v === 0 ? 'Last day' : v + (v === 1 || v === 21 ? 'st' : v === 2 || v === 22 ? 'nd' : v === 3 || v === 23 ? 'rd' : 'th');
  /* the real payment date in a month: a weekend payday moves to the Friday before (or the Monday after if that leaves the month) */
  function payDate(co, y, m) {
    const c = cfg(co), ld = lastDay(y, m);
    const dd = !c.day ? ld : Math.min(c.day, ld);
    let d = new Date(Date.UTC(y, m, dd));
    const wd = d.getUTCDay();
    if (wd === 6 || wd === 0) {
      const back = new Date(d.getTime() - (wd === 6 ? 1 : 2) * DAY);
      d = back.getUTCMonth() === m ? back : new Date(d.getTime() + (wd === 6 ? 2 : 1) * DAY);
    }
    return d;
  }
  function billDate(y, m) {
    return new Date(Date.UTC(y, m, lastDay(y, m)));
  }
  /* the next payday that is not yet paid (may be today or already passed if late) */
  function nextPay(co) {
    const c = cfg(co), t = today(), mi = mIdx(t);
    if (c.late && c.late.mi != null) return payDate(co, Math.floor(c.late.mi / 12), c.late.mi % 12); /* the payday that was missed */
    if (c.pm < mi) return payDate(co, t.getUTCFullYear(), t.getUTCMonth());
    const n = new Date(Date.UTC(t.getUTCFullYear(), t.getUTCMonth() + 1, 1));
    return payDate(co, n.getUTCFullYear(), n.getUTCMonth());
  }
  R29.nextPay = nextPay;

  /* ---------- per company settings ---------- */
  function cfg(co) {
    if (co.pr29) return co.pr29;
    const c = co.pr29 = { day: 25, mode: null, pm: -1, ok: -1, rem: -1, bm: -1, om: -1, late: null };
    if (S.dmode && S.week != null) {
      /* starting in the middle of a month: this month's payday counts as done if it has passed, bills from last month are done */
      const t = today(), mi = mIdx(t);
      c.pm = dnum(t) >= dnum(payDate(co, t.getUTCFullYear(), t.getUTCMonth())) ? mi : mi - 1;
      c.bm = mi - 1;
      c.om = c.pm;
    }
    return c;
  }
  R29.cfg = cfg;
  const inhouse = co => !!INHOUSE[BD[co.type].fam];
  function modeOf(co) {
    if (inhouse(co)) return 'inhouse';
    const c = cfg(co);
    let m = c.mode || (co.mgr ? 'mgr' : 'manual');
    if (m === 'mgr' && !co.mgr) m = 'manual';
    return m;
  }
  R29.modeOf = modeOf;
  const ownerOnPayroll = co => co.form === 'AS' && (co.ownerSalary || 0) > 0 && co.st === 'open';
  const payslips = co => (co.staff || []).length + (co.mgr ? 1 : 0) + (ownerOnPayroll(co) ? 1 : 0);
  const hasPayroll = co => payslips(co) > 0 || (co.pay && co.pay.wages > 1);
  const bureau = co => co.acc ? co.acc.name : ((poolFor(co.country || S.country).acc || [])[0] || { name: 'a local accountant' }).name;
  function feeOf(co, m) {
    const n = Math.max(1, payslips(co));
    if (m === 'acc') return Math.max(KC(900, co.country), KC(165, co.country) * n) * (hasHQ('acc') ? 0.5 : 1);
    if (m === 'mgr') return KC(450, co.country) + KC(40, co.country) * n;
    return 0;
  }
  R29.feeOf = feeOf;
  const MODE_TXT = {
    manual: ['You run it', 'You approve each payroll. Forget, and staff go unpaid.'],
    acc: ['Accountant runs it', 'Per payslip. On time, nothing to approve.'],
    mgr: ['Manager runs it', 'Payroll software. Careless managers sometimes pay late.'],
    inhouse: ['Finance team', 'Run by the company\'s own finance staff.']
  };
  const live = () => S.cos.filter(c => c.st !== 'sold' && c.st !== 'bust');
  /* careless with numbers = more slips: a manager with poor numbers sense misses about one payroll in ten */
  const mgrSlip = co => { const n = S.npcs[co.mgr], s = n && n.stats ? ((n.stats.fin || 60) + (n.stats.risk || 60)) / 2 : 60; return Math.max(0, (65 - s) / 300); };
  const weekWages = co => (sum(co.staff || [], s => s.wage) + (co.mgrWage || 0)) * 12 / 52 * OC();
  const ownCost = co => ownerOnPayroll(co) ? co.ownerSalary * OC() : 0;
  /* expected total on payday: wages owed now, the weeks that start before payday, and the owner's salary */
  function estimate(co, pd) {
    const n = Math.max(0, Math.floor((dnum(pd) - dnum(wDate(S.week))) / 7));
    return Math.round((co.pay.wages || 0) + weekWages(co) * n + (cfg(co).om >= mIdx(pd) ? 0 : ownCost(co)));
  }
  R29.estimate = estimate;
  const owedNow = co => (co.pay.wages || 0) + (co.pay.rent || 0) + (co.pay.other || 0);
  const spare = co => Math.max(0, co.cash + coOverdraft(co));

  /* ---------- paying ---------- */
  function payOwner(co, own) {
    S.tax.wage = (S.tax.wage || 0) + own.sal;
    S.tax.withheld = (S.tax.withheld || 0) + own.tax;
    gainMe(own.sal - own.tax, 'Salary from ' + co.name);
  }
  function applyNewDay(c) {
    if (c.nday != null) {
      c.day = c.nday;
      delete c.nday;
    }
  }
  /* runs one payroll now; how = the mode that runs it */
  function runPayroll(co, how) {
    const c = cfg(co), t = today(), mi = mIdx(t);
    const pmi = c.late && c.late.mi != null ? c.late.mi : mi;
    if (c.om !== pmi && ownerOnPayroll(co)) {
      c.om = pmi;
      const sal = co.ownerSalary, cost = sal * OC();
      co.pay.wages += cost;
      bk(co, 'wages', cost);
      c.ownPend = { sal, tax: personalTax(sal * 12, 'wage') / 12 };
    }
    const fee = feeOf(co, how);
    if (fee > 0) payCo(co, fee, 'acc', how === 'acc' ? 'Payroll service' : 'Payroll software');
    const due = co.pay.wages || 0, p = Math.min(due, spare(co));
    if (p > 0) {
      moveCash(co, -p);
      co.pay.wages = due - p;
      co.tx.unshift({ w: S.week, a: -Math.round(p), l: 'Payroll · ' + payslips(co) + (payslips(co) === 1 ? ' payslip' : ' payslips') });
      if (co.tx.length > 40) co.tx.length = 40;
    }
    const short = Math.max(0, due - p);
    c.pm = Math.max(c.pm, pmi);
    if (dnum(t) >= dnum(payDate(co, t.getUTCFullYear(), t.getUTCMonth()))) c.pm = Math.max(c.pm, mi); /* everything owed is paid: this month's payday is covered too */
    c.ok = -1;
    applyNewDay(c);
    co.wageShort = short;
    if (short > 1) {
      const d0 = c.late && c.late.d0 ? c.late.d0 : t.getTime();
      c.late = { d0, why: 'cash', mi: pmi, owe: short, n: c.late ? c.late.n || 0 : 0 };
      addMsg({ kind: 'ask', from: co.mgr && S.npcs[co.mgr] ? S.npcs[co.mgr].name : co.name, title: 'Payroll short at ' + co.name, body: 'Only ' + money(p) + ' of ' + money(due) + ' could be paid. ' + money(short) + ' is still owed to staff. Put money into the company: the rest goes out automatically as soon as there is cash. Every day late hurts morale.', co: co.id, tone: 'bad', opts: [{ l: 'Understood', d: '', fx: {} }], act: 'pay29', data: { k: 'info' }, exp: S.week + 2 });
    } else {
      c.late = null;
      if (c.ownPend) {
        payOwner(co, c.ownPend);
        c.ownPend = null;
      }
    }
    closeMsgs(co, ['rem', 'late']);
    return { paid: Math.round(p), short: Math.round(short), n: payslips(co), fee: Math.round(fee) };
  }
  R29.runPayroll = runPayroll;
  /* back pay after a short payroll, whenever cash allows */
  function backPay(co) {
    const c = cfg(co), L = c.late;
    if (!L || L.why !== 'cash') return 0;
    const p = Math.min(L.owe, co.pay.wages || 0, Math.max(0, co.cash));
    if (p < 1) return 0;
    moveCash(co, -p);
    co.pay.wages -= p;
    L.owe -= p;
    co.tx.unshift({ w: S.week, a: -Math.round(p), l: 'Back pay to staff' });
    if (L.owe < 1) {
      c.late = null;
      co.wageShort = 0;
      if (c.ownPend) {
        payOwner(co, c.ownPend);
        c.ownPend = null;
      }
      note('Back pay sent at ' + co.name + '. Everyone is paid in full.', 'good', co.id);
    }
    return p;
  }
  function payBills(co) {
    let left = spare(co), short = 0, paid = 0;
    ['rent', 'other'].forEach(k => {
      const due = co.pay[k] || 0;
      if (due <= 0) return;
      const p = Math.min(due, left);
      if (p > 0) {
        moveCash(co, -p);
        co.tx.unshift({ w: S.week, a: -Math.round(p), l: k === 'rent' ? 'Rent' : (co.f30 && Object.keys(co.f30).length ? 'Monthly bills: suppliers, insurance, leasing, fees' : 'Suppliers and costs') });
      }
      co.pay[k] = due - p;
      left -= p;
      short += due - p;
      paid += p;
    });
    if (co.tx.length > 40) co.tx.length = 40;
    if ((co.pay.other || 0) < 1) co.f30 = {};
    const c = cfg(co);
    if (short > 1500) {
      c.bs = (c.bs || 0) + 1;
      if (c.bs === 1) addMsg({ kind: 'info', from: co.name, title: 'Could not pay all bills at ' + co.name, body: 'Missing ' + money(short) + ' for rent and suppliers this month. Put money in or cut costs, or suppliers will stop delivering.', co: co.id, tone: 'bad', status: 'done' });
      if (c.bs >= 2) co.rep = clamp(co.rep - 1, 0, 100);
      if (c.bs >= 4) bankrupt(co, 'unpaid');
    } else c.bs = 0;
    return { paid: Math.round(paid), short: Math.round(short) };
  }
  function closeMsgs(co, kinds) {
    S.inbox.forEach(m => {
      if (m.status === 'open' && m.act === 'pay29' && m.co === co.id && m.data && kinds.indexOf(m.data.k) >= 0) {
        m.status = 'done';
        m.read = 1;
        m.pick = -1;
      }
    });
  }
  function quitOver(co, why) {
    co.staff.slice().forEach(s => {
      if (!chance(0.04)) return;
      const n = S.npcs[s.id];
      note((n ? n.name : 'A worker') + ' quit ' + co.name + ' over ' + why + '.', 'bad', co.id);
      if (n) n.hired = 0;
      co.staff = co.staff.filter(x => x !== s);
    });
  }
  /* one more day with wages owed */
  function lateDay(co, t) {
    const c = cfg(co), L = c.late;
    if (L.why === 'slip') {
      if (dnum(t) >= L.until) {
        c.late = null;
        const r = runPayroll(co, 'mgr');
        R29._day.push({ co, r });
      }
      return;
    }
    if (L.why === 'cash') backPay(co);
    /* the owner did not run it, but now an accountant or manager runs payroll: they pay it straight away */
    if (L.why === 'notrun' && modeOf(co) !== 'manual') {
      const r = runPayroll(co, modeOf(co));
      R29._day.push({ co, r });
    }
    if (!c.late) return;
    const n = dnum(t) - Math.round(L.d0 / DAY);
    if (n <= (L.n || 0)) return;
    L.n = n;
    co.mood = clamp((co.mood != null ? co.mood : 60) - 1.5, 0, 100);
    const owe = L.why === 'cash' ? L.owe : estimate(co, t);
    if (n === 3) {
      if (L.why === 'notrun') addMsg({ kind: 'ask', from: co.staff[0] && S.npcs[co.staff[0].id] ? S.npcs[co.staff[0].id].name : co.name, title: 'Staff at ' + co.name + ' still have not been paid', body: 'Payday was three days ago. People are asking when their wages come. Some are behind on their own rent.', co: co.id, tone: 'bad', opts: [{ l: 'Run payroll now · ' + money(owe), d: '', fx: {} }, { l: 'Not yet', d: '', fx: {} }], act: 'pay29', data: { k: 'late' }, exp: S.week + 2 });
      else note('Staff at ' + co.name + ' are three days without full pay.', 'bad', co.id);
    }
    if (n >= 3) quitOver(co, 'late wages');
    if (n === 7) {
      co.rep = clamp(co.rep - 2, 0, 100);
      note('Word is out that ' + co.name + ' pays late. Good people will think twice before joining.', 'bad', co.id);
    }
    if (n === 14) {
      const f = KC(5000, co.country) + owe * 0.02;
      payCo(co, f, 'fine', 'Wage claim and late interest');
      addMsg({ kind: 'info', from: 'Lawyer for the staff', title: 'Wage claim against ' + co.name, body: 'Staff took the unpaid wages to a lawyer. Legal costs and late interest: ' + money(f) + '. The wages are still owed.', co: co.id, tone: 'bad', status: 'done' });
    }
  }

  /* ---------- the day ---------- */
  R29._day = [];
  function dayCo(co, t, autoRem) {
    const c = cfg(co), mi = mIdx(t), y = t.getUTCFullYear(), m = t.getUTCMonth();
    const md = modeOf(co), pd = payDate(co, y, m);
    /* payday */
    if (c.pm < mi && dnum(t) >= dnum(pd) && !c.late) {
      if (!hasPayroll(co)) {
        c.pm = mi;
        applyNewDay(c);
      } else if (md === 'manual') {
        if (c.ok === mi) R29._day.push({ co, r: runPayroll(co, 'manual') });
        else {
          c.late = { d0: t.getTime(), why: 'notrun', mi, n: 0 };
          closeMsgs(co, ['rem']);
          addMsg({ kind: 'ask', from: 'Payroll', title: 'Payday at ' + co.name + ': wages not approved', body: 'Today is payday. ' + (payslips(co) ? payslips(co) + (payslips(co) === 1 ? ' person is' : ' people are') : 'Former staff are') + ' waiting for about ' + money(estimate(co, t)) + '. Nothing goes out until you run it. Every day late hurts morale, and after a few days people start to leave.', co: co.id, tone: 'bad', opts: [{ l: 'Run payroll now', d: '', fx: {} }, { l: 'Wait', d: '', fx: {} }], act: 'pay29', data: { k: 'late' }, exp: S.week + 2 });
        }
      } else if (md === 'mgr' && co.mgr && S.npcs[co.mgr] && chance(mgrSlip(co))) {
        const n = S.npcs[co.mgr], d = chance(0.5) ? 1 : 2;
        c.late = { d0: t.getTime(), why: 'slip', mi, until: dnum(t) + d, n: 0 };
        addMsg({ kind: 'info', from: n.name, title: 'Payroll late at ' + co.name, body: 'Sorry, I missed a step in the payroll software. Wages go out ' + (d === 1 ? 'tomorrow' : 'in two days') + '. The staff are not happy.', co: co.id, tone: 'bad', status: 'done' });
        co.mood = clamp((co.mood != null ? co.mood : 60) - 2, 0, 100);
      } else R29._day.push({ co, r: runPayroll(co, md === 'inhouse' ? 'inhouse' : md) });
    }
    if (c.late) lateDay(co, t);
    /* seven days ahead */
    const np = nextPay(co), left = dnum(np) - dnum(t), key = mIdx(np);
    if (left >= 1 && left <= 7 && c.rem !== key && c.pm < key && hasPayroll(co)) {
      c.rem = key;
      const est = estimate(co, np), cashOk = co.cash >= est;
      if (md === 'manual') {
        if (c.ok !== key) (R29._man = R29._man || []).push({ co, np, est, cashOk, key }); /* round 40: one approval for all companies */
      } else autoRem.push({ co, np, est, cashOk, md });
    }
    /* rent and supplier bills: last day of the month */
    const bd = billDate(y, m);
    if (c.bm < mi - 1) {
      c.bm = mi - 1;
      const r = payBills(co);
      if (r.paid) R29._day.push({ co, bills: r });
    }
    if (c.bm < mi && dnum(t) >= dnum(bd)) {
      c.bm = mi;
      const r = payBills(co);
      if (r.paid || r.short) R29._day.push({ co, bills: r });
    }
  }
  function onDay() {
    if (!R29.on() || S.over) return;
    const t = today(), autoRem = [];
    R29._day = [];
    live().forEach(co => {
      try {
        setCtx(co);
        dayCo(co, t, autoRem);
      } catch (e) { console.error(e); } finally { setCtx(null); }
    });
    const MR = R29._man || [];
    R29._man = [];
    if (MR.length) {
      const tot = sum(MR, x => x.est), short = MR.filter(x => !x.cashOk);
      addMsg({ kind: 'ask', from: 'Payroll', title: 'Approve payroll' + (MR.length > 1 ? ' for ' + MR.length + ' companies' : ' for ' + MR[0].co.name) + ': ' + mshort(tot), body: MR.map(x => x.co.name + ': about ' + money(x.est) + ' on ' + dstr(x.np) + (x.cashOk ? '' : ' (not enough cash yet)')).join('\n') + '\nApproved payroll goes out on payday by itself, as long as the cash is there.' + (short.length ? ' Put money into ' + short.map(x => x.co.name).join(', ') + ' before payday.' : ''), opts: [{ l: MR.length > 1 ? 'Approve all' : 'Approve', d: '', fx: {} }, { l: 'Later', d: 'A reminder comes on payday', fx: {} }], act: 'pay29all', data: { L: MR.map(x => ({ id: x.co.id, mi: x.key })) }, exp: S.week + 2 });
    }
    if (autoRem.length) {
      const bad = autoRem.filter(x => !x.cashOk);
      addMsg({ kind: bad.length ? 'ask' : 'info', from: 'Payroll', title: 'Payday in ' + (dnum(autoRem[0].np) - dnum(t)) + ' days: ' + money(sum(autoRem, x => x.est)), body: autoRem.map(x => x.co.name + ': about ' + money(x.est) + ' on ' + dstr(x.np) + ', run by ' + (x.md === 'acc' ? bureau(x.co) : x.md === 'mgr' ? (S.npcs[x.co.mgr] || { name: 'the manager' }).name : 'the finance team') + (x.cashOk ? '' : ' · not enough cash (' + money(x.co.cash) + ')')).join(' · '), co: autoRem[0].co.id, tone: bad.length ? 'bad' : '', status: bad.length ? 'open' : 'done', opts: bad.length ? [{ l: 'Understood', d: '', fx: {} }] : undefined, act: bad.length ? 'pay29' : undefined, data: { k: 'info' } });
    }
    const D = R29._day.filter(x => x.r && x.r.paid > 0), B = R29._day.filter(x => x.bills && x.bills.paid > 0);
    if (D.length) {
      const tot = sum(D, x => x.r.paid), ppl = sum(D, x => x.r.n);
      info('Payroll', 'Payday: ' + money(tot) + ' paid to ' + ppl + (ppl === 1 ? ' person' : ' people'), D.map(x => x.co.name + ': ' + money(x.r.paid) + (x.r.short ? ' (short by ' + money(x.r.short) + ')' : '') + (x.r.fee ? ', fee ' + money(x.r.fee) : '')).join(' · ') + '. These costs were already counted day by day, so your net worth does not drop today.', D[0].co.id, D.some(x => x.r.short) ? 'bad' : '');
    }
    /* the day card */
    if ((D.length || B.length) && !ui.untl) {
      const k = S.week * 7 + (S.day || 0);
      if (!ui.day28 || ui.day28.k !== k) ui.day28 = { k, tot: 0, notes: [], at: Date.now() };
      if (D.length) ui.day28.notes.unshift(['Payday', D.length === 1 ? D[0].co.name + ' · ' + D[0].r.n + ' paid' : D.length + ' companies · ' + sum(D, x => x.r.n) + ' paid', -sum(D, x => x.r.paid)]);
      if (B.length) ui.day28.notes.unshift(['Bills', 'Rent and suppliers' + (B.length > 1 ? ' · ' + B.length + ' companies' : ' · ' + B[0].co.name), -sum(B, x => x.bills.paid)]);
      ui.day28.at = Date.now();
    }
  }
  R29.onDay = onDay;
  const rdPrev = window.R10DAY;
  window.R10DAY = function (d) {
    const r = rdPrev ? rdPrev.apply(this, arguments) : undefined;
    try { onDay(); } catch (e) { console.error(e); }
    return r;
  };

  /* ---------- answers to payroll messages ---------- */
  ACTS.pay29all = (m, idx) => {
    if (idx !== 0) return true;
    ((m.data && m.data.L) || []).forEach(x => { const co = getCo(x.id); if (!co) return; const c = cfg(co); if (c.pm < x.mi && !c.late) c.ok = x.mi; });
    note('Payroll approved. It goes out on payday.', 'good');
    return true;
  };
  ACTS.pay29 = (m, idx) => {
    const co = getCo(m.co), d = m.data || {};
    if (!co || d.k === 'info') return true;
    const c = cfg(co);
    setCtx(co);
    try {
      if (d.k === 'rem' && idx === 0) {
        c.ok = d.mi;
        note('Payroll approved for ' + co.name + '. It goes out on payday.', 'good', co.id);
      }
      if (d.k === 'late' && idx === 0 && c.late) {
        const r = runPayroll(co, 'manual');
        note('Payroll run at ' + co.name + ': ' + money(r.paid) + ' paid' + (r.short ? ', short by ' + money(r.short) : '') + '.', r.short ? 'bad' : 'good', co.id);
      }
    } finally { setCtx(null); }
    return true;
  };

  /* ---------- screens ---------- */
  function statusOf(co) {
    const c = cfg(co), md = modeOf(co), np = nextPay(co), t = today();
    if (!hasPayroll(co)) return ['No payroll', ''];
    if (c.late) return c.late.why === 'cash' ? ['Short ' + mshort(c.late.owe), 'red'] : c.late.why === 'slip' ? ['Late', 'amb'] : ['Not paid', 'red'];
    if (md !== 'manual') return ['Automatic', 'grn'];
    if (c.ok === mIdx(np)) return ['Approved', 'grn'];
    return dnum(np) - dnum(t) <= 7 ? ['Approve', 'amb'] : ['Opens ' + dstr(new Date(np.getTime() - 7 * DAY)), ''];
  }
  R29.statusOf = statusOf;
  V.titles.payroll29 = 'Payroll and bills';
  V.heads.payroll29 = p => {
    const co = p && p.id && getCo(p.id);
    return co ? { t: p.v === 'pay' ? 'Payroll and payday' : p.v === 'bills' ? 'Monthly bills' : 'Payroll and bills', sub: esc(co.name) + ' · ' + (co.form === 'AS' ? 'limited company' : 'sole trader') } : { t: 'Payroll and bills', sub: 'All companies' };
  };
  V.payroll29 = function (p) {
    const co = p && p.id && getCo(p.id);
    if (!co) return groupView();
    setCtx(co);
    try { return coView(co, p.v); } finally { setCtx(null); }
  };
  function groupView() {
    const L = live().filter(c => hasPayroll(c) || owedNow(c) > 1);
    if (!L.length) return card('<span class="tipt">No payroll or bills yet. They start when a company has staff, rent or suppliers.</span>');
    const t = today();
    let h = '<div class="tri"><div><span>Costs so far</span><b>' + mshort(sum(L, owedNow)) + '</b></div><div><span>Next payday</span><b>' + (L.filter(hasPayroll).length ? sdate(L.filter(hasPayroll).map(nextPay).sort((a, b) => a - b)[0]) : '–') + '</b></div><div><span>Bills</span><b>' + sdate(billDate(t.getUTCFullYear(), t.getUTCMonth())) + '</b></div></div>';
    h += '<div class="lrows">' + L.map(co => {
      const st = statusOf(co);
      return '<button class="lrow" data-a="go" data-p="' + P({ n: 'payroll29', p: { id: co.id } }) + '"><span class="ctext"><b>' + esc(co.name) + '</b><small>' + (hasPayroll(co) ? 'Payday ' + dstr(nextPay(co)) + ' · ' + MODE_TXT[modeOf(co)][0] : 'No staff') + ' · ' + mshort(owedNow(co)) + ' so far</small></span>' + pillp(st[0], st[1]) + '<i>›</i></button>';
    }).join('') + '</div>';
    return h;
  }
  function coView(co, v) {
    const pay = v !== 'bills', bills = v !== 'pay';
    const c = cfg(co), md = modeOf(co), np = nextPay(co), t = today(), left = dnum(np) - dnum(t);
    const est = hasPayroll(co) ? estimate(co, np) : 0, st = statusOf(co);
    let h = '<div class="tri"><div><span>Wages so far</span><b>' + mshort(co.pay.wages || 0) + '</b></div><div><span>Rent and bills</span><b>' + mshort((co.pay.rent || 0) + (co.pay.other || 0)) + '</b></div><div><span>Cash</span><b class="' + (co.cash < est ? 'neg' : '') + '">' + mshort(co.cash) + '</b></div></div>';
    /* this payroll */
    if (pay && hasPayroll(co)) {
      let x = '<div class="bhead"><b>Next payroll</b>' + pillp(st[0], st[1]) + '</div>' + row('Payday', dstr(np) + (left > 0 ? ' · in ' + left + (left === 1 ? ' day' : ' days') : left === 0 ? ' · today' : ' · ' + (-left) + (left === -1 ? ' day' : ' days') + ' late')) + row(c.late ? 'Owed now' : 'Expected', money(c.late && c.late.why === 'cash' ? c.late.owe : est)) + row('Payslips', String(payslips(co)));
      if (c.late && c.late.why === 'cash') x += '<div class="note bad">Still owed to staff: ' + money(c.late.owe) + '. It goes out as soon as the company has cash.</div>';
      if (co.cash < est && !c.late) x += '<div class="note bad">Company cash is ' + money(est - co.cash) + ' short of this payroll. Put money in before payday.</div>';
      if (md === 'manual') {
        if (c.late && c.late.why === 'notrun') x += '<div class="note bad">Payday has passed and nothing was paid. Every day late hurts morale; after a few days people leave.</div>' + btn('Run payroll now · ' + money(estimate(co, t)), 'pr29run', { id: co.id }, 'primary wide');
        else if (c.ok === mIdx(np)) x += '<span class="tipt">Approved. It goes out on ' + dstr(np) + ' by itself, as long as the cash is there.</span>' + btn('Undo approval', 'pr29ok', { id: co.id, v: 0 }, 'wide');
        else if (left <= 7) x += btn('Approve payroll for ' + dstr(np), 'pr29ok', { id: co.id, v: 1 }, 'primary wide');
        else x += '<span class="tipt">You can approve it from ' + dstr(new Date(np.getTime() - 7 * DAY)) + '. A reminder comes then.</span>';
      } else x += '<span class="tipt">' + esc(md === 'acc' ? bureau(co) + ' runs it' : md === 'mgr' ? (S.npcs[co.mgr] || { name: 'Your manager' }).name + ' runs it' : 'The finance team runs it') + '. You get a heads-up seven days before.</span>';
      h += card(x);
    }
    /* who is paid */
    if (pay) {
      const nStaff = (co.staff || []).length;
      let x = '<h3>On the payroll</h3>' + row('Staff', nStaff + (nStaff === 1 ? ' person · ' : ' people · ') + money(sum(co.staff || [], s => s.wage)) + ' a month');
      if (co.mgr && S.npcs[co.mgr]) x += row(esc(titleFor(co, 'mgr')), esc(S.npcs[co.mgr].name) + ' · ' + money(co.mgrWage || 0));
      if (co.form === 'AS') x += row('You, the owner', co.ownerSalary > 0 ? money(co.ownerSalary) + ' · tax withheld' : 'No salary') + '<span class="tipt">Your salary is a normal payslip in this payroll: a cost for the company, paid on payday with tax withheld, and only once staff are paid in full.' + (co.ownerSalary > 0 ? '' : ' Set it under Pay yourself.') + '</span>';
      else x += '<span class="tipt">As a sole trader you are not on the payroll. What you take out under Pay yourself is a withdrawal, taxed as business profit, and never mixed with your staff\'s wages.</span>';
      x += row('Employer costs', '+' + Math.round((OC() - 1) * 100) + '% on top of pay') + btn('Pay yourself', 'go', { n: 'payself', p: { id: co.id } }, 'wide');
      h += card(x);
    }
    /* payday setting */
    if (pay && (hasPayroll(co) || co.staff.length)) {
      let x = '<h3>Payday<small>Company setting</small></h3>' + U.chips(DAYS.map(v => [v, dayLbl(v)]), c.nday != null ? c.nday : c.day, 'pr29day', { id: co.id });
      x += '<span class="tipt">' + (c.nday != null ? 'Changes to the ' + dayLbl(c.nday).toLowerCase() + ' after this month\'s payroll (staff need notice). ' : '') + 'A weekend payday is paid the Friday before.</span>';
      h += card(x);
      if (!inhouse(co)) {
        const opts = ['manual', 'acc', 'mgr'].map(k => {
          const can = k !== 'mgr' || !!co.mgr, fee = feeOf(co, k), on = md === k;
          return '<button class="lrow' + (can ? '' : ' dim') + '" data-a="pr29mode" data-p="' + P({ id: co.id, v: k }) + '"' + (can ? '' : ' disabled') + '><span class="ctext"><b>' + MODE_TXT[k][0] + '</b><small>' + (k === 'mgr' && !can ? 'Hire a manager first.' : k === 'acc' ? esc(bureau(co)) + ' · on time, nothing to approve' : k === 'mgr' ? esc((S.npcs[co.mgr] || { name: 'Your manager' }).name) + ' · payroll software' : esc(MODE_TXT[k][1])) + '</small></span><b>' + (fee ? mshort(fee) + '/mo' : 'Free') + '</b>' + (on ? pillp('On', 'grn') : '<i>›</i>') + '</button>';
        }).join('');
        h += '<div class="card"><h3>Who runs payroll</h3><div class="lrows">' + opts + '</div>' + (hasHQ('acc') ? '<span class="tipt">Your head office accounts team halves the accountant\'s fee.</span>' : '') + '</div>';
      } else h += card('<h3>Who runs payroll</h3><span class="tipt">' + MODE_TXT.inhouse[1] + '</span>');
    }
    /* bills */
    if (bills) {
      const bd = billDate(t.getUTCFullYear(), t.getUTCMonth());
      h += card('<h3>Monthly bills</h3>' + row('Rent so far', money(co.pay.rent || 0)) + row('Suppliers and goods so far', money(Math.max(0, (co.pay.other || 0) - sum(Object.keys(co.f30 || {}), k => co.f30[k])))) + Object.keys(co.f30 || {}).filter(k => co.f30[k] > 0).map(k => row({ ins: 'Insurance', mkt: 'Marketing', acc: 'Accounting', oth: 'Leasing and other costs', rent: 'Other rent' }[k] || k, money(co.f30[k]))).join('') + row('Paid on', dstr(bd) + ', the last day of the month') + '<span class="tipt">Everything recurring (rent, goods, insurance, leasing, marketing, fees) is billed here and paid automatically from company cash. VAT and company tax follow their own dates.</span>');
    }
    return h;
  }
  ACT.pr29day = p => {
    const co = getCo(p.id);
    if (!co) return;
    const c = cfg(co), mi = mIdx(today());
    if (c.pm >= mi && !c.late) {
      c.day = p.v;
      delete c.nday;
    } else if (p.v === c.day) delete c.nday;
    else c.nday = p.v;
    c.rem = -1;
    save();
    render();
  };
  ACT.pr29mode = p => {
    const co = getCo(p.id);
    if (!co || (p.v === 'mgr' && !co.mgr)) return;
    cfg(co).mode = p.v;
    if (p.v !== 'manual') closeMsgs(co, ['rem']);
    save();
    render();
    toast(MODE_TXT[p.v][0] + ' from now on.');
  };
  ACT.pr29ok = p => {
    const co = getCo(p.id);
    if (!co) return;
    const c = cfg(co);
    c.ok = p.v ? mIdx(nextPay(co)) : -1;
    if (p.v) closeMsgs(co, ['rem']);
    save();
    render();
    if (p.v) toast('Approved. Wages go out on ' + dstr(nextPay(co)) + '.');
  };
  ACT.pr29run = p => {
    const co = getCo(p.id);
    if (!co) return;
    setCtx(co);
    let r;
    try { r = runPayroll(co, 'manual'); } finally { setCtx(null); }
    save();
    render();
    toast('Payroll run: ' + money(r.paid) + ' paid' + (r.short ? ', short by ' + money(r.short) : '') + '.', !!r.short);
  };

  /* Home: costs so far and the next payday, next to the day card */
  const home0 = V.home;
  V.home = function () {
    const h = home0.apply(this, arguments);
    try {
      if (!R29.on()) return h;
      const L = live().filter(c => hasPayroll(c) || owedNow(c) > 1);
      if (!L.length) return h;
      const late = L.filter(c => cfg(c).late && cfg(c).late.why !== 'slip');
      const P0 = L.filter(hasPayroll).map(c => [c, nextPay(c)]).sort((a, b) => a[1] - b[1])[0];
      const t = today(), so = sum(L, owedNow);
      let txt;
      if (late.length) txt = '<b class="neg">Wages late at ' + esc(late[0].name) + (late.length > 1 ? ' +' + (late.length - 1) : '') + '</b>';
      else if (P0) {
        const dl = dnum(P0[1]) - dnum(t);
        txt = 'Payday <b>' + dstr(P0[1]) + '</b>' + (dl <= 0 ? ' · today' : dl <= 7 ? ' · in ' + dl + (dl === 1 ? ' day' : ' days') : '');
      } else txt = 'Bills <b>' + dstr(billDate(t.getUTCFullYear(), t.getUTCMonth())) + '</b>';
      const strip = '<button class="bill29" data-a="go" data-p="' + P({ n: 'payroll29', p: {} }) + '"><span>Costs so far <b>' + mshort(so) + '</b></span><span>' + txt + '</span><i>›</i></button>';
      const i = h.indexOf('<div class="advbar">');
      return i > 0 ? h.slice(0, i) + strip + h.slice(i) : h;
    } catch (e) { console.error(e); return h; }
  };

  /* every company: a Payroll and bills row on the overview and in Money */
  const rowHtml = co => {
    const st = statusOf(co);
    return '<div class="lrows"><button class="lrow" data-a="go" data-p="' + P({ n: 'payroll29', p: { id: co.id } }) + '"><span class="lic">' + svg('coin', 20) + '</span><span class="ctext"><b>Payroll and bills</b><small>' + (hasPayroll(co) ? 'Payday ' + dstr(nextPay(co)) + ' · ' : '') + mshort(owedNow(co)) + ' to pay so far</small></span>' + (st[1] ? pillp(st[0], st[1]) : '<i>›</i>') + '</button></div>';
  };
  R29.rowHtml = rowHtml;
  const CT = window.CT;
  const ov29 = CT.ov;
  CT.ov = function (co, bd) {
    const h = ov29.apply(this, arguments);
    try {
      if (!R29.on() || co.type === 'hold' || co.st === 'sold' || co.st === 'bust') return h;
      return h + rowHtml(co);
    } catch (e) { return h; }
  };
  const fin29 = CT.fin;
  CT.fin = function (co, bd) {
    const h = fin29.apply(this, arguments);
    try {
      if (!R29.on() || co.type === 'hold') return h;
      const i = h.indexOf('<div class="rowlist hub">');
      if (i < 0) return h;
      const j = i + '<div class="rowlist hub">'.length;
      const st = statusOf(co);
      return h.slice(0, j) + '<button class="contact" data-a="go" data-p="' + P({ n: 'payroll29', p: { id: co.id } }) + '"><span class="cic" style="background:var(--surface2)">' + svg('coin', 20) + '</span><span class="ctext"><b>Payroll and bills</b><small>' + (hasPayroll(co) ? 'Payday ' + dstr(nextPay(co)) + ' · ' + MODE_TXT[modeOf(co)][0] : 'No staff yet') + '</small></span>' + (st[1] === 'red' || st[1] === 'amb' ? pillp(st[0], st[1]) : '') + '<i>›</i></button>' + h.slice(j);
    } catch (e) { return h; }
  };

  /* Pay yourself: a sole trader's withdrawal is not payroll; warn when it would eat into wages owed */
  const ps29 = V.payself;
  V.payself = function (p) {
    let h = ps29.apply(this, arguments);
    try {
      const co = getCo(p.id);
      if (!co || !R29.on()) return h;
      const owe = owedNow(co);
      let n = '';
      if (co.form !== 'AS') n = '<div class="note">Withdrawals are yours, not payroll. ' + (owe > 1 ? 'But ' + money(owe) + ' of the company cash is already owed: wages ' + money(co.pay.wages || 0) + (hasPayroll(co) ? ' on ' + dstr(nextPay(co)) : '') + ', rent and bills ' + money((co.pay.rent || 0) + (co.pay.other || 0)) + '.' : 'Nothing is owed right now.') + '</div>';
      else if (co.ownerSalary > 0) n = '<div class="note">Your salary of ' + money(co.ownerSalary) + ' is paid with payroll on ' + dstr(nextPay(co)) + ', tax withheld.</div>';
      const i = h.indexOf('</div></div>');
      return n && i > 0 ? h.slice(0, i + 12) + n + h.slice(i + 12) : h + n;
    } catch (e) { return h; }
  };
  /* a sole trader cannot take more than the cash left after wages owed, in one go, without a warning */
  const draw0 = ACT.cdraw;
  if (draw0) ACT.cdraw = p => {
    const co = getCo(p && p.id);
    if (co && co.form !== 'AS' && R29.on()) {
      const a = U.inum('amtOut', 0), free = co.cash - owedNow(co);
      if (a > 0 && a > free && owedNow(co) > 1 && !ui.draw29ok) {
        ui.draw29ok = 1;
        toast('That takes money owed to staff and suppliers (' + mshort(owedNow(co)) + '). Tap Take out again to do it anyway.', true);
        setTimeout(() => { ui.draw29ok = 0; }, 8000);
        return;
      }
      ui.draw29ok = 0;
    }
    return draw0.apply(this, arguments);
  };
})();

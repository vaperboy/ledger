# round 41
path = '/home/claude/w3/ledger.html'
T = '/home/claude/w3/tools/'
t = open(path, encoding='utf8').read()
mark = '/* ---------- no zooming: pinch, double tap, ctrl+wheel, ctrl +/- ---------- */'
assert t.count(mark) == 1
t = t.replace(mark, open(T + 'round41.js', encoding='utf8').read() + '\n' + mark)
def rep(a, b):
    global t
    assert t.count(a) == 1, a[:60]
    t = t.replace(a, b)
# pop-ups: forms and long lists scroll; anything that still does not fit can be scrolled
rep("""      sh.style.overflowY = 'hidden';
      if (sh.scrollHeight <= sh.clientHeight + 2) return;
""", """      sh.style.overflowY = 'hidden';
      if (sh.scrollHeight <= sh.clientHeight + 2) return;
      /* round 41: forms are never split across pages, nor are long lists: they scroll instead */
      if (sh.querySelector('input,textarea,select,.chips,.knob,.ichat') || sh.scrollHeight > sh.clientHeight * 2.6) return;
""")
rep("""      if (foot) sh.insertBefore(nav, foot); else sh.appendChild(nav);
    } finally {
      fitting = false;""", """      if (foot) sh.insertBefore(nav, foot); else sh.appendChild(nav);
    } finally {
      if (sh.scrollHeight > sh.clientHeight + 2) sh.style.overflowY = 'auto';
      fitting = false;""")
# the week's one-off payments (loan instalments, VAT settlements, legal bills) leave on one day, not as a daily drip
rep("""    const meB = S.cash, coB = {};
    S.cos.forEach(c => {
      coB[c.id] = c.cash;
    });""", """    const meB = S.cash, coB = {}, txB = {};
    S.cos.forEach(c => {
      coB[c.id] = c.cash;
      txB[c.id] = c.tx && c.tx[0];
    });""")
rep("""      if (d) {
        P.co.push([c.id, d]);
        moveCash(c, -d);
      }""", """      if (d) {
        let one = 0;
        for (const x of (c.tx || [])) { if (x === txB[c.id]) break; if (x.a < 0) one += x.a; }
        P.co.push([c.id, d, Math.round(one)]);
        moveCash(c, -d);
      }""")
rep("""      const c = getCo(x[0]), v = part(x[1]);""", """      const one = (x[2] || 0) + Math.min(0, x[1] - (x[2] || 0)), c = getCo(x[0]), v = part(x[1] - one) + (day === 0 ? one : 0);""")
# ---- round 44 proofread: wording that was wrong, stale, real-brand or that only restated a design request ----
PR = [
    ("'Aquaculture licence (fictional price)'", "'Aquaculture licence'"),
    ("'Casino licence (fictional)'", "'Casino licence'"),
    ("'Gaming Authority (fictional)'", "'Gaming Authority'"),
    ("'Production licence (fictional)'", "'Production licence'"),
    ("'Ministry of Energy (fictional)'", "'Ministry of Energy'"),
    ("Fictional early-stage companies raising money.", "Early-stage companies raising money."),
    ("Ten fictional listed companies.", "Ten listed companies."),
    ("'Telenor-like Nett ASA'", "'Nordnett ASA'"),
    ("'Founders ex-' + pick(['Equinor', 'DNB', 'Schibsted', 'Telenor', 'Kahoot']) + '.'", "pick(['Founders from a big energy company.', 'Founders from a large bank.', 'Founders from a media group.', 'Founders from a telecom company.', 'Founders who built an app before.'])"),
    ("Create a holding company in Phone › Deal room first.", "Create a holding company under Expand first."),
    ("You can also borrow for the company in Phone › Banking.", "You can also borrow for the company in Phone › Bank."),
    ("'is investor-subsidised and burning cash'", "'is backed by investors and burning cash'"),
    ("None of your companies supply ' + esc(K.n.toLowerCase())", "None of your companies supply ' + esc(K.n.replace(/^./, c => c.toLowerCase()))"),
    ("'. A ' + esc(BD[K.sup[0]].n.toLowerCase()) + ' of your own could.</p>'", "'. You could start one: ' + esc(BD[K.sup[0]].n) + '.</p>'"),
    ("MO[ahead] + ': ' + pk[1].toLowerCase() + ' is coming'", "MO[ahead] + ': ' + pk[1].replace(/^(?!Christmas)./, c => c.toLowerCase()) + ' is coming'"),
    ("pickEqName(co, BD[co.type]).toLowerCase() : 'main machine'", "pickEqName(co, BD[co.type]) : 'main machine'"),
    ("feel(co, x, tx).toLowerCase()", "feel(co, x, tx)"),
    ("Helping now means they owe you; a promise must be kept within six weeks; saying no is remembered.", "Help now and they owe you one."),
    ("<p class=\"muted\">What customers say, like a public review site. Ratings follow how good each business really is.</p>", "<p class=\"muted\">What customers say about you and your rivals.</p>"),
    ("<p class=\"muted small\">What customers say about your businesses. Ratings follow how good each one really is.</p>", "<p class=\"muted small\">What customers say about your businesses.</p>"),
    ("These are feelings, not numbers. A data analyst gives you ranges and real odds.", "A data analyst gives you ranges and real odds."),
    (". Nothing is locked. If you cannot pay your debts, the game ends.</p>", ". If you cannot pay your debts, the game ends.</p>"),
    ("<p class=\"muted\">Nothing is locked. Choose anything. Large businesses need large money and strict documents.</p>", "<p class=\"muted\">Bigger businesses need more money and stricter documents.</p>"),
    ("Attention is pouring in. This is buzz, not loyalty: it fades within weeks. It only turns into lasting awareness if you can serve the crowd and the product is good. Be ready with stock, staff and quality.", "Everyone is talking about you. It fades within weeks unless you can serve the crowd well, so have stock, staff and quality ready."),
    ("A single shop stays a local name. Customers beyond your neighbourhood never hear of you, so profit stays modest and it is often best to run it yourself.", "One site stays a local name."),
    ("Famous national moments reach huge audiences but cost a fortune, and mean little for a shop with few outlets. They fade fast if the product disappoints. Now and then a campaign goes viral, but rarely.", "National TV moments reach everyone but cost a fortune; they pay off for brands with many outlets."),
    ("Awareness only exists where the ads run. Spending in another country does not move it here.", "Ads only work in the country they run in."),
    ("A known brand costs more to start: a high entry fee, their fit-out standards and royalties. You get customers from day one. You apply, they answer in a week or three, and then you meet them to agree terms. Nothing is guaranteed.", "A known brand costs more to start (entry fee, their fit-out, royalties) but brings customers from day one."),
    ("Choose what you want to build. Each path rewards a different way to play, gives a perk while you follow it, and adds to your legacy score. You can change later, but the perk takes half a year to start again.", "Each path has its own milestones and a perk. You can switch later; the new perk starts after half a year."),
    ("Not ready to hand over the company? An assistant manager works in the business like your best worker and also takes up to two jobs off your plate: complaints, paperwork and insurance, or equipment and stock. Paid more than a typical worker, less than a manager. You stay in charge.", "Works like your best worker and takes up to two jobs off your plate: complaints, paperwork and insurance, or equipment and stock. You stay in charge."),
    ("You know your own sales, but not what the others sell. This is a feeling from walking past their doors.", "Your guess from walking past their doors."),
]
PR += [
    ("Paid more than a worker, less than a manager", "Paid more than a worker, less than a manager."),
    (" · <span class=\"neg\">short: ' + short.map(", " · <span class=\"neg\">missing: ' + short.map("),
]
t = t.replace('left hand', 'right hand').replace('Left hand', 'Right hand')
for a, b in PR:
    n = t.count(a)
    if n == 0:
        print('proofread: not found:', a[:70])
    t = t.replace(a, b)
i = t.rindex('</style>')
t = t[:i] + open(T + 'round41.css', encoding='utf8').read() + '\n' + t[i:]
open(path, 'w', encoding='utf8').write(t)
print('patch28 ok')

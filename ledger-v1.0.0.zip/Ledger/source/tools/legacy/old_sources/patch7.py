path = '/home/claude/w3/ledger.html'
T = '/home/claude/w3/tools/'
t = open(path, encoding='utf8').read()
def rep(old, new, count=1):
    global t
    n = t.count(old)
    if n != count: raise SystemExit('MATCH %d (want %d): %s' % (n, count, old[:110]))
    t = t.replace(old, new)

# money screens can be replaced by round-6 screens
rep("""  function finPart(co, bd, k) {
    if (k === 'value')""", """  function finPart(co, bd, k) {
    if (window.R6FIN && window.R6FIN[k]) { const r6 = window.R6FIN[k](co, bd); if (r6 != null) return r6; }
    if (k === 'value')""")
# interview: work car choice
rep("""    h += payOffer(co, n) + '<div class="card">'""", """    h += payOffer(co, n) + (window.carOffer ? window.carOffer(co, n) : '') + '<div class="card">'""")
# faces for people
rep("""'<div class="lrow solo hl"><span class="av">' + esc(ini2(m.name)) + '</span>""", """'<div class="lrow solo hl">' + faceAv(m) + '""")
rep("""'<div class="lrow solo"><span class="av">' + esc(ini2(an.name)) + '</span>""", """'<div class="lrow solo">' + faceAv(an) + '""")
rep("""<summary class="lrow"><span class="av">' + esc(ini2(n.name)) + '</span>""", """<summary class="lrow">' + faceAv(n) + '""")
rep("""<div class="cchd"><span class="av">' + esc(n.name.split(' ').slice(0, 2).map(x => x[0]).join('')) + '</span>""", """<div class="cchd">' + faceAv(n) + '""")
rep("""data-a="mcandopen" data-p="' + P({ n: n.id }) + '"><div class="cchd">' + av(ini(n.name)) + '""", """data-a="mcandopen" data-p="' + P({ n: n.id }) + '"><div class="cchd">' + faceAv(n) + '""")
rep("""<button class="bk" data-a="candback" aria-label="Back">‹</button>""", """<button class="bk" data-a="candback" aria-label="Back">‹</button>' + faceAv(n) + '""")
rep("""<button class="bk" data-a="mcandback" aria-label="Back">‹</button>""", """<button class="bk" data-a="mcandback" aria-label="Back">‹</button>' + faceAv(n) + '""")

js = ''.join(open(T + f, encoding='utf8').read() + '\n' for f in ['round6a.js', 'round6b.js', 'round6c.js'])
mark = '/* ---------- no zooming: pinch, double tap, ctrl+wheel, ctrl +/- ---------- */'
rep(mark, js + mark)
css = open(T + 'round6.css', encoding='utf8').read()
i = t.rindex('</style>')
t = t[:i] + css + t[i:]
open(path, 'w', encoding='utf8').write(t)
print('patch7 ok')

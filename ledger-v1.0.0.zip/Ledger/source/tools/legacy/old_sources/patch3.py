path='/home/claude/work/ledger.html'
t=open(path,encoding='utf8').read()
def rep(old,new,count=1):
    global t
    n=t.count(old)
    if n!=count: raise SystemExit('MATCH %d (want %d): %s'%(n,count,old[:90]))
    t=t.replace(old,new)
# five bottom tabs, head office is its own tab again
rep("""  const SECS = [['home', 'Home', 'home'], ['cos', 'Companies', 'biz'], ['phone', 'Phone', 'phone'], ['meet', 'Meetings', 'chat']];
  const ROOT = { home: 'home', cos: 'cos', meet: 'meetings' };""",
"""  const SECS = [['home', 'Home', 'home'], ['cos', 'Companies', 'biz'], ['hq', 'Office', 'office'], ['phone', 'Phone', 'phone'], ['meet', 'Meetings', 'chat']];
  const ROOT = { home: 'home', cos: 'cos', hq: 'hq', meet: 'meetings' };""")
rep("""    office: 'cos',
    group: 'cos',
    dealroom: 'cos',
    exechire: 'cos',
    hq: 'cos',""","""    office: 'hq',
    group: 'hq',
    dealroom: 'hq',
    exechire: 'hq',
    hq: 'hq',
    hqhire: 'hq',
    hqmk: 'hq',
    managers: 'hq',
    suppliers: 'hq',""")
rep("""    registry: ['news', { t: 'registry' }],
""","")
rep("""    'settings',
    'phfolder',
    'clubs'
  ];""","""    'settings',
    'phfolder',
    'clubs',
    'registry',
    'lux'
  ];""")
rep("""      ui.tab = SEC_OF[n] || 'cos';""","""      ui.tab = SEC_OF[n] || 'cos';
      if (ui.tab === 'phone') ui.tab = 'cos';""")
rep("""    return '<div class="os2"><main class="screen ' + k + '">' + mainBody() + '</main>' + navbar() + '</div>';""",
"""    const root = ui.tab === 'phone' ? ui.ph.n === 'home' : isRoot();
    return '<div class="os2"><main class="screen ' + k + (root ? ' root' : '') + '">' + mainBody() + '</main>' + navbar() + '</div>';""")
# long option lists become a dropdown
rep("""    if (items.length > 7) return ddown(items, cur, act, p0);""","""    if (items.length > 5 || items.reduce((n, it) => n + String(it[1]).replace(/<[^>]*>/g, '').length, 0) > 46) return ddown(items, cur, act, p0);""")
# absolute week numbers become dates
rep("""'In progress, ready week ' + co.docs[d].done""","""'In progress, ready ' + dateStr(co.docs[d].done)""")
rep("""'<br><small>matures week ' + d.wEnd""","""'<br><small>matures ' + dateStr(d.wEnd)""")
rep("""' <small>(week ' + x.taxDueW + ')</small>'""","""' <small>(' + dateStr(x.taxDueW) + ')</small>'""")
rep("""'<p class="muted small">Reviewed week ' + r.w""","""'<p class="muted small">Reviewed ' + dateStr(r.w)""")
rep("""'<small>Week ' + r.w""","""'<small>' + dateStr(r.w)""")
# no zoom anywhere
rep("""<meta name=viewport content="width=device-width,initial-scale=1,viewport-fit=cover">""","""<meta name=viewport content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">""")
open(path,'w',encoding='utf8').write(t)
print('patch3 ok')

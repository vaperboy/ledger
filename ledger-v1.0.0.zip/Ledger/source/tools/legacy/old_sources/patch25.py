# round 38: currency signs on short amounts, round preset amounts, no empty decimals
import re
path = '/home/claude/w3/ledger.html'
t = open(path, encoding='utf8').read()
SYM = {'SEK': 'kr', 'PLN': 'zł', 'EUR': '€', 'GBP': '£', 'USD': '$', 'CAD': 'C$', 'AUD': 'A$', 'JPY': '¥', 'KRW': '₩', 'BRL': 'R$'}
for k, v in SYM.items():
    a = "  symbol: '" + k + "',"
    assert t.count(a) >= 1, k
    t = t.replace(a, "  symbol: '" + v + "',")
R = [
    ("  if (a >= 1e9) return s + (a / 1e9).toFixed(2) + ' bn';\n  if (a >= 1e6) return s + (a / 1e6).toFixed(a >= 1e7 ? 1 : 2) + ' M';",
     "  if (a >= 1e9) return s + (+(a / 1e9).toFixed(2)) + ' bn';\n  if (a >= 1e6) return s + (+(a / 1e6).toFixed(a >= 1e7 ? 1 : 2)) + ' M';"),
    ("function mshort(n) {\n  const c = CC().cur;\n  return mshort0(n) + ' ' + (CC().symbol || c);\n}",
     "function mshort(n) {\n  const c = CC().cur, sy = CC().symbol || c, v = mshort0(n);\n  /* kr and zł go after the number; $, €, £ and the others in front */\n  if (/^(kr|zł|[A-Z]{3})$/.test(sy)) return v + ' ' + sy;\n  return v.charAt(0) === '−' ? '−' + sy + v.slice(1) : sy + v;\n}"),
    ("      const v = NONMONEY[key] ? v0 : rl(v0);", "      const v = NONMONEY[key] ? v0 : (window.niceAmt ? window.niceAmt(v0) : rl(v0));"),
]
for a, b in R:
    assert t.count(a) == 1, a[:60]
    t = t.replace(a, b)
open(path, 'w', encoding='utf8').write(t)
print('patch25 ok')

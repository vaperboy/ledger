/* ===== Round 14: the marketing manager says who to target and how, only hired people are invited,
   a failing store can be closed or rescued by the chain (with the analyst's odds), and big decisions need two thirds. ===== */
{
  const R12 = window.R12, first = R12.first, kf = R12.kf;
  const liveCo = c => c && c.st !== 'sold' && c.st !== 'bust';
  const seatOfRole = (key, r) => R12.seatsOf(key).find(s => (s.r || { fin: 'cfo', law: 'legal', ind: 'consult', mkt: 'mkt', chair: 'chair' }[s.type]) === r);
  const nameOfRole = (key, r) => { const s = seatOfRole(key, r); return s && S.npcs[s.id] ? S.npcs[s.id] : null; };
  const AGL = ['18–24', '25–34', '35–49', '50+'];
  function fitCh(bd, k) { const c = CH[k]; return chAff(bd, k) * ((1 - bd.aud) * (c.loc || 0.5) + bd.aud * (c.b2b || 0.5)) * c.eff; }
  /* who to aim at and through what: best-rated age group from reviews, best-fitting channel not yet used enough */
  function mktPlan(co) {
    const bd = BD[co.type];
    let grp = null;
    try {
      const x = reviewList('mine').find(y => y.key === 'c' + co.id);
      if (x && x.n >= RV_MIN && window.AGX) { const g = window.AGX.ageStats(x).g; let bi = -1, bv = -1; g.forEach((a, i) => { const v = a.n ? a.avg * Math.sqrt(a.n) : 0; if (v > bv) { bv = v; bi = i; } }); if (bi >= 0 && g[bi].n) grp = { i: bi, avg: g[bi].avg }; }
    } catch (e) { }
    const ks = Object.keys(CH).filter(k => !CH[k].prem && !CH[k].nat && !CH[k].var).sort((a, b) => fitCh(bd, b) - fitCh(bd, a));
    const k = ks.find(x => !(co.mkt[x] && co.mkt[x].b > 0)) || ks[0];
    const rev = co.lastW ? co.lastW.rev || 0 : 0;
    const b = Math.round(Math.max(KC(3000), rev * 0.05) / 100) * 100;
    const aud = bd.aud >= 0.6 ? 'business buyers' : grp ? 'people aged ' + AGL[grp.i] : 'locals nearby';
    return { k, b, aud, why: grp ? 'they rate you ' + grp.avg.toFixed(1) + ' and come back most' : bd.aud >= 0.6 ? 'they order the most' : 'they find you fastest', ch: CH[k].n || k };
  }
  /* rescue odds: demand room, reviews, how known it is, the trend and the money behind it */
  function rescueOdds(c, ch) {
    const bd = BD[c.type], dm = demand(c, bd), cp = capacity(c, bd);
    const H = (c.hist || []).slice(-3), rev = sum(H, x => x.rev || 0) / Math.max(1, H.length), pr = sum(H, x => x.profit || 0) / Math.max(1, H.length);
    const trend = H.length >= 2 ? (H[H.length - 1].rev - H[0].rev) / Math.max(1, H[0].rev) : 0;
    const need = rev > 0 && pr < 0 ? -pr / Math.max(0.05, 1 - (bd.cogs || 0.3) - 0.35) : 0;
    const needPct = rev > 0 ? need / rev : 1;
    let o = 0.45 + (ratingOf(c) - 3.5) * 0.25 + clamp(trend, -0.3, 0.3) - clamp(needPct - 0.2, 0, 0.6) * 0.8 + ((c.aware || 0) < 40 ? 0.08 : 0) + (cp.cap > dm.D * 1.1 ? 0.05 : -0.05);
    o = clamp(o, 0.05, 0.9);
    const cash = Math.round(Math.max(KC(30000), -pr * 6) / 1000) * 1000;
    return { o, needPct, cash, perWeek: Math.round(need / 4.33 / Math.max(1, (c.lastW && c.lastW.units ? c.lastW.rev / c.lastW.units : bd.ticket))) };
  }
  R12.extraX = function (key, cos, items) {
    /* marketing manager: who and how */
    const mm = nameOfRole(key, 'mkt');
    if (mm) cos.filter(c => c.st === 'open').slice(0, 2).forEach(c => {
      const p = mktPlan(c);
      items.push({ who: mm.id, st: null, act: 'mktplan', p: { id: c.id, k: p.k, b: p.b }, inv: ['mkt'], text: c.name + ': aim at ' + p.aud + ' through ' + p.ch + ', ' + p.why + '. Put ' + money(p.b) + ' a week there.' });
    });
    /* a store on the brink while the others do well: close it, or lift it */
    if (key.slice(0, 2) !== 'ch' || cos.length < 2) return;
    const ok = cos.filter(c => (c.hist || []).slice(-2).every(x => x.profit > 0));
    cos.forEach(c => {
      if (c.st !== 'open' || !ok.length || ok.indexOf(c) >= 0) return;
      const brink = (c.negW || 0) >= 3 || c.cash < 0 || ((c.wkD || 0) < 0 && c.cash / -c.wkD < 6);
      if (!brink) return;
      const an = nameOfRole(key, 'analyst') || (hasHQ('perf') ? { name: (S.office.staff.find(x => x.role === 'perf') || {}).name || 'Your performance analyst', id: null } : null);
      const r = rescueOdds(c);
      const mp = mktPlan(c);
      const nums = an ? first(an.name) + ' (analyst): about ' + Math.round(r.o * 100) + '% chance it breaks even within six months. It needs about ' + Math.round(r.needPct * 100) + '% more sales, roughly ' + r.perWeek + ' more customers a week.' : 'No analyst on the board, so nobody has put numbers on its chances.';
      const mtxt = mm ? ' ' + first(mm.name) + ' (marketing): aim at ' + mp.aud + ' through ' + mp.ch + '.' : '';
      items.push({ who: an && an.id ? an.id : (R12.lhN() || {}).id, st: null, act: 'rescue', p: { id: c.id, cash: r.cash, k: mp.k, b: mp.b, mm: !!mm }, inv: ['analyst', 'mkt', 'cfo'], text: 'Rescue ' + c.name + ': the chain moves ' + money(r.cash) + ' from its profitable stores' + (mm ? ' and runs a marketing push' : '') + '. ' + nums + mtxt });
      items.push({ who: (nameOfRole(key, 'cfo') || R12.lhN() || {}).id, st: null, act: 'close', p: { id: c.id }, inv: ['cfo', 'legal'], text: 'Or close ' + c.name + ' and stop the losses (' + kf(sum((c.hist || []).slice(-3), x => x.profit || 0)) + ' in three months).' });
    });
  };
  const yes12 = ACT.bd12yes;
  ACT.bd12yes = p => {
    const b = R12.brdOf(p.k), m = b && b.mts.find(x => x.id === p.m), it = m && m.items[p.i];
    if (!it || it.st || ['mktplan', 'rescue', 'close'].indexOf(it.act) < 0) return yes12(p);
    const co = getCo(it.p.id);
    if (!co) return;
    if (it.act === 'mktplan') {
      co.mkt[it.p.k] = { b: it.p.b, since: (co.mkt[it.p.k] && co.mkt[it.p.k].since) || S.week };
      toast('Marketing plan set for ' + co.name + '.');
    } else if (it.act === 'rescue') {
      const donors = R12.brdCos(p.k).filter(c => c !== co && c.cash > 0).sort((a, b2) => b2.cash - a.cash);
      let need = it.p.cash;
      donors.forEach(d => { const x = Math.min(need, Math.max(0, d.cash - KC(20000))); if (x > 0) { moveCash(d, -x); moveCash(co, x); need -= x; } });
      if (it.p.mm) co.mkt[it.p.k] = { b: Math.round(it.p.b * 1.5), since: S.week };
      co.negW = 0;
      toast(co.name + ' gets ' + money(it.p.cash - need) + ' from the chain.');
    } else if (it.act === 'close') {
      it.st = 'yes';
      save();
      ACT.winduo({ id: co.id });
      return;
    }
    it.st = 'yes';
    m.items.forEach(x => { if (x !== it && x.p && x.p.id === co.id && (x.act === 'rescue' || x.act === 'close')) x.st = 'no'; });
    save();
    render();
  };
  /* only people you have hired are invited */
  R12.invText = function (x, key) {
    const inv = x.inv || [];
    const L = inv.map(r => { const n = nameOfRole(key, r); if (n) return [r, n.name]; if (r === 'cfo') { const c = R12.brdCos(key)[0]; if (c && c.acc) return [r, c.acc.name + ', accountant']; } if (r === 'analyst' && hasHQ('perf')) return [r, 'your performance analyst']; return null; }).filter(Boolean);
    if (!L.length) return '';
    const T = { mkt: 'Marketing manager', analyst: 'Data analyst', cfo: 'CFO', legal: 'Legal adviser', hr: 'HR manager', consult: 'External consultant' };
    return '<span class="tipt inv13">The CEO invited: ' + L.map(z => (T[z[0]] || z[0]) + ' (' + esc(first(z[1])) + ')').join(', ') + '</span>';
  };
  /* big decisions need two thirds of the shares */
  const BIG = { sell: 1, close: 1 };
  const vs13 = R12.voteSheetX;
  R12.voteSheetX = function (kind, co, amt, go2, label) {
    if (!BIG[kind] || !(co.holders || []).length) return vs13.apply(this, arguments);
    const owners = [{ name: S.player.name + ' (you)', pct: co.own, yes: true, you: 1 }].concat(co.holders.map(h => ({ name: h.name, pct: h.pct, yes: hrng('ov14:' + h.name + kind + S.week)() < (sum((co.hist || []).slice(-3), x => x.profit || 0) < 0 ? 0.8 : 0.2), h })));
    const yesPct = sum(owners.filter(o => o.yes), o => o.pct), pass = yesPct >= 200 / 3 - 0.01;
    const lonely = pass && owners.filter(o => !o.you).every(o => !o.yes);
    ui.b14cont = () => { closeSheet(); if (lonely) co.holders.forEach(h => { h.mood = Math.max(0, (h.mood != null ? h.mood : 60) - 8); }); go2(); };
    openSheet('<h2>Vote: ' + esc(label) + '</h2><p class="muted small">A big decision. It needs two thirds of the shares, so 51% is not enough.</p><div class="lrows">' + owners.map(o => '<div class="lrow"><span class="av dim">' + esc(ini(o.name)) + '</span><span class="ctext"><b>' + esc(o.name) + '</b><small>' + Math.round(o.pct) + '% of the shares</small></span><span class="pill ' + (o.yes ? 'green' : 'red') + '">' + (o.yes ? 'Yes' : 'No') + '</span></div>').join('') + '</div><p class="muted small">' + Math.round(yesPct) + '% yes of 67% needed.' + (lonely ? ' Everyone else voted no and will lose some morale.' : '') + '</p>' + (pass ? '<div class="two">' + btn('Go ahead', 'b14go', {}, 'primary') + btn('Cancel', 'sheetclose', undefined, 'ghost') + '</div>' : btn('Not enough votes', 'sheetclose', undefined, 'wide')));
  };
  ACT.b14go = () => { const f = ui.b14cont; ui.b14cont = null; if (f) f(); };
}

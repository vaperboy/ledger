# Round 13 spec (from user, 2026-10-08)

## Chains
- "Make it a chain" works like franchising: chain documents, application, waiting time, approval.
- After approval: open stores under the same name in any city you choose.
- Opening the second store follows real-life steps in mockup style (location, premises, staffing, opening); not a full new company registration flow.

## Chain folder
- 1 store: tapping the company opens the normal company page.
- 2+ stores: one "All stores" page. Each store is a row that expands (like workers in Staff tab): revenue, costs, key info, button bottom right "Open store".
- Remove the second tab row (Rules / Team / Board tabs) – put those inside the page.

## When there are board meetings
- Single store, only you as owner: no board meetings.
- 2+ stores: board meetings.
- Co-owners present: co-owners may want board meetings even for one store.

## Board composition
Permanent attendees:
- Board Chair, 2–4 Directors, CEO, CFO/Finance Manager or accountant, Board secretary
- Always: you, your personal advisor (left hand), co-owners
Invited when relevant (CEO invites by decision type):
- Regional Manager, Marketing Manager, HR Manager, Legal adviser, Data/Business Analyst, External consultant
- e.g. acquisition → legal + CFO; new store → regional + marketing; lawsuit → legal
- All these roles must be hirable per company and connected to real duties (check which exist: HQ_ROLES has hr, acc, law, ana, perf, mkt, proc, strat, fin; company roles: analyst2, hr, marketer, lawyer...). Add missing ones (Board secretary, Directors, Chair, CFO per company, External consultant).

## Voting
- Advisors advise only. Votes: you, co-owners, region chiefs, CEO (owners' votes weighted by shares).
- Shareholder resolution needs MORE than 50% (strict):
  A 40, B 30, C 20, D 10 → A alone NO; A+D 50 NO; A+C 60 YES; B+C 50 NO; B+D 40 NO; A+B 70 YES.
- One owner ≥51% decides alone.
- If the majority owner pushes a yes against everyone else, the others lose some morale.

## Bankruptcy
- Must be shown very clearly: full-screen notice with what happened, why, and what you lose.

/* ===== Round 23: second audit pass — fixes for systems found broken in testing (see report). ===== */
{
  /* property businesses: the setup estimate left out the property itself, so "Setup estimate" said ~100 000 for a
     rental company that needs millions. It now includes the down payment and fees on the smallest listing. */
  const se0 = window.setupEstimate;
  window.setupEstimate = function (bdId, o) {
    const r = se0.apply(this, arguments);
    try {
      o = o || {};
      const bd = BD[bdId], cc = o.country || S.country;
      if (bd.fam === 'rent' && bd.tw && bd.tw.price) {
        const C = CO[cc] || CC(), city = (o.city && C.cities.find(x => x.id === o.city)) || C.cities[0];
        const units = Math.max(2, Math.round((bd.tw.units || 10) * 0.35));
        const price = units * bd.tw.price * Math.pow(city.rent || 1, 0.8) * ((S.econ && S.econ.housing) || 1);
        const ltv = policy() > 0.09 ? 0.2 : 0.55;
        r.prop = rlc((price * (1 - ltv) + price * 0.06) * 1.3, cc); /* listings vary up to about 30% around the typical price */
        r.total = rlc(r.total + r.prop, cc);
      }
    } catch (e) { console.error(e); }
    return r;
  };
}
/* franchisees were paid a weekly "brand" amount booked as revenue with no customers behind it.
   The brand already works through awareness and reputation; the phantom revenue is removed. */
window.franchiseeWeek = function (co, rev) {
  const f = co.franchise;
  if (!f || !f.fran) return;
  payCo(co, rev * (f.roy + f.mkt), 'oth', null);
  f.brand = clamp(f.brand + (co.q - 55) * 0.004, 10, 90);
  if (f.brandId) co.aware = Math.max(co.aware, 15 + f.brand * 0.45);
  if (co.q < 45 && chance(0.01)) {
    note('The franchisor warns ' + co.name + ' about quality standards.', 'bad', co.id);
    co.rep -= 2;
  }
};
/* ===== Organic awareness: people find a business without advertising.
   A shop on a street is seen by passers-by, a local service turns up in maps and search, a business that serves
   people well is talked about. Awareness drifts toward this organic level a little each week; advertising pushes
   above it faster. Bad reviews pull the level down. ===== */
{
  const KIND = { venue: 1, retail: 1 };
  const ONLINE = { webshop: 1, webdev: 1, mktg: 1, tutor: 1 };
  function organic(co, bd) {
    if (!bd.Dc || ['fin', 'energy', 'hold', 'club', 'rent'].indexOf(bd.fam) >= 0) return 0;
    const pk = co.prem && co.prem.kind, foot = pk && isFoot(pk);
    let base = foot ? 20 : ONLINE[bd.id] ? 9 : bd.fam === 'project' || bd.fam === 'prod' ? 10 : bd.fam === 'logi' ? 11 : 12;
    if (foot && co.prem && co.prem.loc) base *= clamp(co.prem.loc, 0.8, 1.25);
    /* smaller towns: a bigger share of people notice you */
    const pop = (cityOf(co.city) || {}).pop || 150;
    base *= clamp(1.25 - Math.log10(Math.max(20, pop)) * 0.12, 0.85, 1.15);
    /* reviews and repeat customers: good service spreads, poor service sinks the name */
    const rt = ratingOf(co);
    base *= clamp(0.55 + (rt - 3) * 0.45, 0.35, 1.35);
    /* it takes time to become known: full level after about a year open */
    const age = S.week - (co.wOpen != null ? co.wOpen : co.w0 || S.week);
    base *= clamp(0.35 + age / 52 * 0.65, 0.35, 1);
    return base;
  }
  window.R23 = window.R23 || {};
  R23.organic = organic;
  const mw0 = window.mktWeek;
  window.mktWeek = function (co, bd) {
    const r = mw0.apply(this, arguments);
    try {
      if (co.st === 'open') {
        const A = organic(co, bd);
        co.aw23 = Math.round(A * 10) / 10;
        /* below the organic level, people who know you keep knowing you (no fading), and more find you each week */
        if (A > co.aware) co.aware = clamp(co.aware / Math.max(0.5, awareDecay(co)) + (A - co.aware) * 0.035, 0, A + 0.5);
      }
    } catch (e) { console.error(e); }
    return r;
  };
}
/* farms sell into a commodity market: what they grow is sold at the going price; awareness and advertising
   do not decide how much of the harvest finds a buyer. Production capacity sets the volume. */
{
  const COMMOD = { farm: 1 };
  const dem0 = window.demand;
  window.demand = function (co, bd) {
    const r = dem0.apply(this, arguments);
    try {
      if (COMMOD[bd.id]) {
        const cap = capacity(co, bd).cap || 0;
        const f = cap > 0 ? Math.max(r.D, cap * 0.97) / Math.max(1e-9, r.D) : 1;
        r.D = Math.max(r.D, cap * 0.97);
        r.parts.commodity = Math.round(f * 100) / 100;
      }
    } catch (e) { console.error(e); }
    return r;
  };
}
/* vehicles all lost 15% of their price a year, so a 180 million aircraft was written off in under 7 years
   (real: 20–25). Depreciation now follows the kind of vehicle. */
window.R23 = window.R23 || {};
R23.vehDep = m => ({ plane: 0.05, bus: 0.1, truck: 0.12, plant: 0.1, van: 0.15, car: 0.16, bike: 0.2 }[m && m[2]] || 0.15);
/* retuned price levels (R8.PF) and demand levels (R8.KT) for types that could not work under realistic running:
   see the audit report for the reasoning behind each number */
Object.assign(window.R8.PF, { farm: 1.0, airline: 1.2 });
(function () {
  const K = window.R8.KT, F = window.R8.PF;
  /* demand: trades, couriers and pet care run at 65–85% of their capacity when known in their area */
  const kt = { courier: 1.25, trucking: 1.15, electrician: 1.45, plumber: 1.2, pets: 1.3, taxi: 1.1 };
  Object.keys(kt).forEach(t => { if (K[t]) K[t] = Math.round(K[t] * kt[t] * 100) / 100; });
  /* fares: Norwegian taxi trips average about 340 NOK */
  F.taxi = 1.0;
  /* a bank with fifteen staff and a core system needs a balance sheet of a billion or more to cover its costs;
     at 16% capital that is about 180 million of equity (EU minimum licence capital is 5 million euro, but that does not pay the wages).
     The setup estimate includes it (see the setupEstimate wrapper below). */
})();
/* vehicles: traded across borders, so prices differ less than local prices do (Norway's taxes make them dearest).
   In low-cost countries small firms start with used vehicles, as they do in reality. */
R23.vehCtry = co => { const C = (co && CO[co.country]) || CC(); return 0.4 + 0.6 * Math.min(1.15, C.pl || 1); };
{
  const se1 = window.setupEstimate;
  window.setupEstimate = function (bdId, o) {
    const r = se1.apply(this, arguments);
    try {
      o = o || {};
      const C = CO[o.country || S.country] || CC(), f = 0.4 + 0.6 * Math.min(1.15, C.pl || 1);
      const used = (C.pl || 1) < 0.7 && bdId !== 'airline';
      if (r.veh) {
        const nv = r.veh * f * (used ? 0.52 / 0.2 : 1); /* used vehicles are bought outright at about half the new price */
        r.total = rlc(r.total - r.veh + nv, o.country || S.country);
        r.veh = rlc(nv, o.country || S.country);
      }
      if (r.vehFull) r.vehFull *= f;
      /* regulated finance needs capital before it can trade at a scale that pays its staff:
         a bank lends about five times its equity, an insurer's growth is capped by its solvency capital */
      const capReq = { bank: [180000000, 'Lending capital (regulator) and buffer'], insco: [45000000, 'Solvency capital (regulator) and buffer'] }[bdId];
      if (capReq) { const add = capReq[0] * (o.size || 1) - (r.buffer || 0); if (add > 0) { r.buffer = rlc((r.buffer || 0) + add, o.country || S.country); r.total = rlc(r.total + add, o.country || S.country); r.capLbl = capReq[1]; } }
    } catch (e) { console.error(e); }
    return r;
  };
}
/* running overheads (phone, accounting, insurance, small services) were charged at Norwegian prices in every
   country. They are mostly local services, so they follow the country's price level. */
/* accounting, insurance, phone and small services are mostly people's time, so they follow local wages as much as local prices */
R23.fixF = co => { const C = (co && CO[co.country]) || CC(); return 0.2 + 0.8 * (0.5 * (C.pl || 1) + 0.5 * Math.min(1.3, C.wage || 1)); };
/* ===== Before hiring: what the extra person costs, what they can earn, and whether demand is there ===== */
{
  function hireImpact(co, role) {
    const bd = BD[co.type];
    if (!bd || !ROLES[role] || !bd.Dc) return null;
    const cp = capacity(co, bd), w = co.lastW || {};
    /* last week's demand and capacity are what the business actually saw; the parts tell what one more person adds */
    const capNow = w.cap > 0 ? w.cap : (cp.cap || 0), D0 = w.D != null ? w.D : demand(co, bd).D;
    /* a customer-facing hire also brings customers of their own */
    const r0d = window.R8 && R8.demRef ? R8.demRef(co, bd, null) : 1, r1d = window.R8 && R8.demRef ? R8.demRef(co, bd, role) : 1;
    const D = D0 * (r0d > 0 ? r1d / r0d : 1), dD = D - D0;
    const parts = (cp.parts || []).filter(p => p.cap != null && isFinite(p.cap));
    const mine = parts.find(p => p.k === 'role:' + role);
    const others = parts.filter(p => p !== mine).reduce((m, p) => Math.min(m, p.cap), Infinity);
    /* ask the game's own capacity model: put a typical new person in the team for a moment and see what changes
       (this also catches the owner's or manager's hours moving to the job that limits output) */
    let ratio = 1;
    try {
      const tmp = { id: '_hire24', role, skillGain: 0 };
      S.npcs._hire24 = { skill: 55 };
      co.staff.push(tmp);
      const c1 = capacity(co, bd).cap;
      co.staff.pop();
      delete S.npcs._hire24;
      ratio = cp.cap > 0 && isFinite(c1) ? c1 / cp.cap : 1;
    } catch (e) { co.staff = co.staff.filter(x => x.id !== '_hire24'); delete S.npcs._hire24; }
    const capNew = capNow * ratio, per = capNew - capNow;
    const extraUnits = Math.max(0, Math.min(D, capNew) - Math.min(D0, capNow));
    const vr = w.rev > 0 ? clamp((w.cogs || 0) / w.rev, 0, 0.95) : (bd.cogs || 0.3);
    const tk = w.units > 0.01 && w.rev > 0 ? w.rev / w.units : ticketEff(co, bd);
    const pay = wageFor(role, co) * OC();
    const contrib = extraUnits * tk * (1 - vr) * 52 / 12;
    const be = tk * (1 - vr) > 0 ? pay / (tk * (1 - vr)) * 12 / 52 : Infinity;
    return { pay, rev: extraUnits * tk * 52 / 12, contrib, be, perWk: per, extraWk: extraUnits, net: contrib - pay, bottleneck: !!(mine && mine.cap <= others + 1e-9), full: D0 > capNow * 1.02, newCust: dD };
  }
  window.R23 = window.R23 || {};
  R23.hireImpact = hireImpact;
  function card(co, role) {
    const x = hireImpact(co, role), bd = BD[co.type];
    if (!x) return '';
    const unit = bd.unit;
    const bad = x.net < 0;
    const nc = x.newCust > 0.05 ? 'A ' + ROLES[role][0].toLowerCase() + ' also brings in customers: about ' + (x.newCust >= 10 ? Math.round(x.newCust) : x.newCust.toFixed(1)) + ' more ' + esc(unitPl(unit, 2)) + ' a week. ' : '';
    const why = nc + (!x.full ? (nc ? 'Beyond that, you are not turning customers away now.' : 'You are not turning customers away now, so another ' + ROLES[role][0].toLowerCase() + ' mostly adds cost.') : !x.bottleneck ? ROLES[role][0] + 's are not what limits you; ' + esc((co.dbg && co.dbg.bot) || 'something else') + ' is.' : 'You are turning customers away and this role is the bottleneck.');
    return '<div class="card' + (bad ? ' probcard' : '') + '"><div class="bhead"><b>' + (bad ? 'Demand does not pay for this hire yet' : 'This hire should pay for itself') + '</b></div>' +
      row('Extra payroll', money(x.pay) + ' a month') + row('Extra sales it allows', money(x.rev) + ' a month') + row('Break-even', Math.ceil(x.be) + ' more ' + esc(unitPl(unit, 2)) + ' a week') + row('Effect on monthly profit', '<span class="' + (bad ? 'neg' : 'pos') + '">' + (x.net >= 0 ? '+' : '−') + money(Math.abs(x.net)) + '</span>') + '<span class="tipt">' + why + ' Hiring ahead of growth is allowed; this is what it costs until demand catches up.</span></div>';
  }
  const h0 = V.hire;
  V.hire = function (p) {
    let h = h0.apply(this, arguments);
    try {
      const co = p && p.id && getCo(p.id);
      if (!co || co.st !== 'open' || !ui.hrole || ui.hrole === '_more') return h;
      const c = card(co, ui.hrole);
      if (!c) return h;
      const i = h.indexOf('<h3 class="gap">How to search</h3>');
      if (ui.cand) return h.replace('<div class="clog">', c + '<div class="clog">');
      const j = h.indexOf('</div>', i > 0 ? i : 0);
      return i > 0 && j > 0 ? h.slice(0, j + 6) + c + h.slice(j + 6) : c + h;
    } catch (e) { console.error(e); return h; }
  };
}
/* bank loan-loss events: a bad quarter writes off a fraction of a percent of the loan book, not two percent at a time
   (Norwegian banks lose roughly 0.1–0.5% of their loans in a normal year, on top of the running loss rate already modelled) */
if (typeof SPEC !== 'undefined') SPEC.f_default = (co, bd, e, c) => {
  if (!co.fm || !co.fm.book) return;
  const loss = co.fm.book * rng(0.0015, 0.006) * knobFx(co, 'r') * (1 + Math.max(0, 1 - S.econ.dem) * 4);
  co.fm.book -= loss;
  bk(co, 'loss', loss);
  note('Loan losses at ' + co.name + ': ' + money(loss) + ' written off.', 'bad', co.id);
};

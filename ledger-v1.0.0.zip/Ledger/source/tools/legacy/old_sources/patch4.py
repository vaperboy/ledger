path = '/home/claude/w3/ledger.html'
t = open(path, encoding='utf8').read()


def rep(old, new, count=1):
    global t
    n = t.count(old)
    if n != count:
        raise SystemExit('MATCH %d (want %d): %s' % (n, count, old[:100]))
    t = t.replace(old, new)


def between(start, end, new, keep_end=True):
    global t
    a = t.index(start)
    b = t.index(end, a)
    t = t[:a] + new + (t[b:] if keep_end else t[b + len(end):])


# ---------- A. realistic fictional company and rival names ----------
rep("""function coName(fam, city) {
  const c = CC();
  return pick(c.nameA) + ' ' + pick((c.nameB[fam] || c.nameB.svc));
}""", """/* Brand-style names: surnames, partner names and coined words built from local roots ("Fjordvik Bygg", "Haugen & Dahl Partners") */
const COIN_END = {
  nordic: ['vik', 'heim', 'dal', 'nes', 'lund', 'berg', 'strand', 'haug', 'sund', 'fjell'],
  germanic: ['feld', 'berg', 'hof', 'bach', 'stein', 'haus', 'werk', 'mark'],
  english: ['field', 'wood', 'ford', 'ley', 'ton', 'brook', 'gate', 'well', 'more', 'stone'],
  romance: ['val', 'mont', 'court', 'ville', 'ia', 'ora', 'ano', 'ard'],
  slavic: ['pol', 'ex', 'tex', 'mar', 'bud', 'ix', 'on'],
  baltic: ['ta', 'ra', 'lis', 'vis', 'nas'],
  asia: ['ra', 'ka', 'to', 'do', 'ya']
};
const COIN_LANG = { NO: 'nordic', SE: 'nordic', DE: 'germanic', NL: 'germanic', UK: 'english', US: 'english', CA: 'english', AU: 'english', FR: 'romance', ES: 'romance', BR: 'romance', PL: 'slavic', LT: 'baltic', JP: 'asia', KR: 'asia' };
function coinName(c) {
  let r = String(pick(c.nameA)).replace(/[^A-Za-zÀ-ÿ]/g, '');
  if (r.length > 6) r = r.slice(0, 5);
  let s = pick(COIN_END[COIN_LANG[c.code]] || COIN_END.english);
  if (r.slice(-1).toLowerCase() === s[0]) s = s.slice(1);
  return r + s;
}
function brandCoName(c, fam) {
  const end = pick(c.nameB[fam] || c.nameB.svc);
  const r = rng(0, 1);
  if (r < 0.3 && c.last && c.last.length) return pick(c.last) + ' ' + end;
  if (r < 0.42 && (fam === 'svc' || fam === 'fin') && c.last && c.last.length > 1) {
    const a = pick(c.last), b = pick(c.last.filter(x => x !== a));
    return a + ' & ' + b + ' ' + end;
  }
  if (r < 0.82) return coinName(c) + ' ' + end;
  return pick(c.nameA) + ' ' + end;
}
function coName(fam, city) {
  return brandCoName(CC(), fam);
}""")
rep("""function rivalName(bd, city, cc) {
  const C = CO[cc] || CC();
  return pick(C.nameA) + ' ' + pick(C.nameB[bd.fam] || C.nameB.svc);
}""", """function rivalName(bd, city, cc) {
  return brandCoName(CO[cc] || CC(), bd.fam);
}""")

# ---------- B. equipment gets a maker's brand ----------
rep("""const E = (id, n, cost, life, std, fl, vo) => ({ id, n, cost, life, std, fl: fl || '', vo: vo || null });""",
    """const EQ_BRANDS = [
  [/dental|medical|x-ray|treatment|massage|clinic|laser|ultrasound|patient/i, ['Medora', 'Clarion', 'Vitalis', 'Sanomed']],
  [/laptop|computer|\\bpc\\b|phone|tablet|software|server|printer|camera|monitor|screen|scanner|router|wifi|\\bpos\\b|till|terminal|headset|drone|projector|speaker|sound|webcam/i, ['Corvane', 'Lumetra', 'Arkline', 'Novix', 'Stratel', 'Brightwave', 'Helix']],
  [/\\bvan\\b|truck|\\bcar\\b|\\bbus\\b|boat|trailer|forklift|lorry|vessel|ship|\\btractor|excavator|crane|aircraft|plane|\\bjet\\b|helicopter|bike|scooter|ambulance|taxi/i, ['Valmont', 'Nordtrans', 'Kestrel', 'Ostrava', 'Hadeland Motor', 'Brenna']],
  [/oven|fridge|kitchen|coffee|espresso|grill|freezer|dishwasher|fryer|cooler|beer|ice machine|mixer|cold room|stove/i, ['Brenner', 'Kalvø', 'Gastrona', 'Rossi & Lund', 'Fornell']],
  [/machine|drill|press|\\bsaw|pump|compressor|polisher|washer|lathe|cnc|generator|turbine|welder|robot|loom|kiln|boiler|furnace|hoist|scaffold|vacuum/i, ['Hallberg', 'Ferrox', 'Stalheim', 'Durano', 'Torvik', 'Maxell & Strøm']],
  [/chair|table|furniture|shelving|shelves|counter|\\bbed|desk|sofa|rack|display|mirror/i, ['Formhaus', 'Linde', 'Oakridge', 'Sandmo']]
];
function brandEq(id, n) {
  const g = EQ_BRANDS.find(x => x[0].test(n));
  if (!g) return n;
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) | 0;
  const b = g[1][Math.abs(h) % g[1].length];
  return b + ' ' + (/^[A-Z]{2}/.test(n) ? n : n.charAt(0).toLowerCase() + n.slice(1));
}
const E = (id, n, cost, life, std, fl, vo) => ({ id, n: brandEq(id, n), cost, life, std, fl: fl || '', vo: vo || null });""")

# ---------- C. a company with no staff only gets customer and (if marketing runs) marketing events ----------
rep("""function spawnEvents(co, bd) {""", """const SOLO_CUST = { g_late: 1, g_review: 1, g_lawsuit: 1, g_offer: 1, c_scope: 1, c_clientloss: 1, c_damage: 1, c_wedding: 1, c_malprac: 1, c_patient: 1, c_contract: 1, v_critic: 1, v_poison: 1, v_overbook: 1, v_injury: 1, v_churn: 1, v_bigwin: 1, v_cheat: 1, v_addict: 1, r_return: 1, p_defect: 1, p_nopay: 1, p_leak: 1, rn_nopay: 1, rn_pet: 1, rn_vacant: 1, rn_anchor: 1, pr_cust: 1, pr_bigcontract: 1, f_fund: 1 };
const SOLO_MKT = { g_press: 1, g_award: 1, v_ota: 1 };
function soloCo(co) {
  return !co.staff.length && !co.mgr;
}
function soloOk(e, co) {
  if (SOLO_CUST[e.id]) return true;
  if (SOLO_MKT[e.id]) return Object.keys(co.mkt || {}).some(k => co.mkt[k] && co.mkt[k].b > 0);
  return false;
}
function spawnEvents(co, bd) {""")
rep("""    if (!co.staff.length && (/employee|staff|worker|colleague/i.test(e.t) || e.opts.some(o => o.fx && (o.fx.quit || o.fx.raise || o.fx.sick)))) return;""",
    """    if (!co.staff.length && (/employee|staff|worker|colleague/i.test(e.t) || e.opts.some(o => o.fx && (o.fx.quit || o.fx.raise || o.fx.sick)))) return;
    if (soloCo(co) && !soloOk(e, co)) return;""")

# ---------- D. loans remember what was borrowed (for the bank progress bar) ----------
rep("""    name: kind === 'biz' ? 'Business loan' : kind === 'cons' ? 'Consumer loan' : 'Mortgage',
    bal: amt,""", """    name: kind === 'biz' ? 'Business loan' : kind === 'cons' ? 'Consumer loan' : 'Mortgage',
    bal: amt,
    amt0: amt,""")

# ---------- E. company overview in the mockup's order ----------
between("  CT.ov = function (co, bd) {\n    let h = '';\n    if (co.st === 'setup') return CT.setupOv(co, bd);", "  CT.setupOv = function (co, bd) {", r"""  const COSTN = { cogs: 'Materials and goods', wages: 'Wages and holiday pay', rent: 'Rent and power', mkt: 'Marketing', ins: 'Insurance', acc: 'Accounting', dep: 'Depreciation', int: 'Interest', oth: 'Other costs', fine: 'Fines', loss: 'Losses and write-offs' };
  CT.ov = function (co, bd) {
    if (co.st === 'setup') return CT.setupOv(co, bd);
    const w = co.lastW || {};
    const util = w.util || 0;
    const al = coAlerts(co);
    const bw = co.bk.w || {};
    const rev = bw.rev != null ? bw.rev : (w.rev || 0);
    const cost = sumExp(bw);
    const margin = rev > 0 ? (rev - cost) / rev : null;
    const dW = co.wkD != null ? co.wkD : rev - cost;
    let h = '<div class="card ovhero"><span class="lab">Company cash</span><b class="huge ' + (co.cash < 0 ? 'neg' : '') + '">' + nok(co.cash) + '</b><span class="pills"><span class="pl ' + (dW >= 0 ? 'g' : 'r') + '">' + (dW >= 0 ? '+' : '−') + mshort(Math.abs(dW)) + ' this week</span>' + al.map(a => '<span class="pl ' + (a[1] === 'bad' ? 'r' : '') + '">' + esc(a[0]) + '</span>').join('') + '</span></div>';
    h += '<div class="tri"><div><span>Revenue/wk</span><b>' + mshort(rev) + '</b></div><div><span>Costs/wk</span><b>' + mshort(cost) + '</b></div><div><span>Margin</span><b class="' + (margin == null ? '' : sgn(margin)) + '">' + (margin == null ? '—' : Math.round(margin * 100) + '%') + '</b></div></div>';
    const unpaid = sum(co.recv || [], r => r.a);
    h += '<h2 class="sec">This week</h2><div class="card">' + (w.D != null && !w.cap && w.D > 0 ? '<div class="note bad"><b>Customers are looking, but you cannot serve them.</b> ' + (co.dbg && co.dbg.cp ? esc(co.dbg.cp.filter(c => c.have < c.need * 0.999 && c.kind !== 'equip' || c.cap <= 0).map(c => c.label).slice(0, 3).join(', ')) + ' missing. ' : '') + 'Check Staff and Equipment.</div>' : '') +
      (w.D != null && w.cap ? '<div class="kv"><span>Demand</span><b>' + demandLevel(w) + '</b></div>' + bar(Math.min(100, util * 100), util > 0.97 ? 'var(--amber)' : 'var(--blue)') : '') +
      row(esc(unitPl(bd.unit, 2).replace(/^./, x => x.toUpperCase())) + ' sold', Math.round((w.units || 0) * 10) / 10) + row('Average review', rvStars(ratingOf(co), co.rvN || 0)) + row('Unpaid invoices', '<span class="' + (unpaid > 0 ? 'amb' : '') + '">' + nok(unpaid) + '</span>') + row('Reputation', repWord(co.rep)) + row('How well known', awWord(co.aware)) + '</div>';
    const ks = Object.keys(COSTN).filter(k => bw[k]);
    h += '<h2 class="sec">Costs per week</h2><div class="card">' + (ks.length ? ks.map(k => row(COSTN[k], npadL(bw[k]))).join('') : '<span class="muted small">No costs booked this week.</span>') + '</div>';
    const m = co.mgr ? S.npcs[co.mgr] : null;
    h += '<h2 class="sec">Owner view</h2><div class="card">' + row('You own', (co.own % 1 ? co.own.toFixed(1) : co.own) + '%') + (m ? row('Manager salary', money(co.mgrWage) + ' / month') : row('Your hours', co.ohrs + ' h a week')) + row('Tax set aside', nok(co.pay.tax || 0)) + row('Value', nok(companyValue(co))) + '<div class="two">' + btn('Move money', 'cofin', { id: co.id, s: 'owner' }, 'wide') + btn('Sell shares', 'cofin', { id: co.id, s: 'sell' }, 'wide') + '</div></div>';
    if (bd.fam !== 'club' && m) {
      const rv = mgrReview(co);
      const sc = rv ? rv.score : 50;
      const wd = rv && !rv.hasHist ? 'Settling in' : sc >= 75 ? 'Doing very well' : sc >= 60 ? 'Doing well' : sc >= 45 ? 'Doing okay' : sc >= 30 ? 'Struggling' : 'Failing';
      const yrs = Math.floor((S.week - (co.mgrW0 || 0)) / 52);
      h += '<h2 class="sec">' + esc(titleFor(co, 'mgr')) + '</h2><div class="card"><div class="bhead"><div><b>' + esc(m.name) + '</b><small>' + (yrs ? yrs + (yrs > 1 ? ' years' : ' year') + ' in the role' : 'New in the role') + '</small></div></div>' + row('How it is going', wd) + row('Morale', moodWord(co.mood != null ? co.mood : 60)) + '<div class="two">' + btn('Message', 'askmgr', { id: co.id }, 'wide') + btn('Staff', 'cotab', { id: co.id, v: 'st' }, 'wide') + '</div></div>';
    }
    const fm = CT.famOv ? CT.famOv(co, bd) : '';
    if (fm) h += fm;
    const pr = co.hist.map(x => x.profit);
    h += '<h2 class="sec">Monthly result</h2>' + card((pr.length > 1 ? '<div style="display:flex;justify-content:center">' + spark(pr, 300, 54) + '</div>' : '') + row('This month so far', '<span class="' + sgn((co.bk.m.rev || 0) - sumExp(co.bk.m)) + '">' + nok((co.bk.m.rev || 0) - sumExp(co.bk.m)) + '</span>') + row('Year to date', '<span class="' + sgn((co.bk.y.rev || 0) - sumExp(co.bk.y)) + '">' + nok((co.bk.y.rev || 0) - sumExp(co.bk.y)) + '</span>'));
    const evs = S.inbox.filter(x => x.co === co.id && x.status === 'open');
    if (evs.length) h += btn('Open ' + evs.length + ' decision' + (evs.length > 1 ? 's' : ''), 'opendec', { id: co.id }, 'primary wide');
    return h;
  };
""")

# ---------- F. marketing: channel cards ----------
rep("""    const on = sorted.filter(k => co.mkt[k] && co.mkt[k].b), off = sorted.filter(k => !(co.mkt[k] && co.mkt[k].b));
    h += '<div class="card"><h3>Running now<small>Spend per week.</small></h3>' + (on.length ? on.map(chanRow).join('') : '<p class="muted small">No campaigns running.</p>') + '</div>';
    h += btn('Plan a campaign', 'plopen', { id: co.id }, 'primary wide');
    return h;
  };""", """    const on = sorted.filter(k => co.mkt[k] && co.mkt[k].b), off = sorted.filter(k => !(co.mkt[k] && co.mkt[k].b));
    const chanCard = k => {
      const c = CH[k], m = co.mkt[k], cur = m.b, since = m.since != null ? m.since : S.week, lock = m.lock && m.lock > S.week;
      const wks = Math.max(0, S.week - since);
      const meter = c.slow ? ['Build-up', Math.min(1, wks / 26), wks >= 26 ? 'Full effect' : Math.round(wks / 26 * 100) + '%'] : c.mw ? ['Minimum term', Math.min(1, wks / c.mw), lock ? (m.lock - S.week) + ' wk left' : 'Done'] : null;
      return '<div class="card chcard"><div class="bhead"><div class="cchd"><span class="lic">' + svg('mega', 18) + '</span><span class="ctext"><b>' + esc(c.n) + '</b><small>' + esc(c.note) + '</small></span></div><span class="badge ' + (lock ? 'amber' : 'green') + '">' + (lock ? 'Locked' : 'Running') + '</span></div>' + row('Weekly cost', money(cur)) + row('Running for', wks + (wks === 1 ? ' week' : ' weeks')) + (meter ? row(meter[0], meter[2]) + bar(meter[1] * 100, meter[1] >= 1 ? 'var(--green)' : 'var(--amber)') : '') + '<div class="chips">' + c.opts.map(o => '<button class="btn chip ' + (o === cur ? 'primary' : '') + '" data-a="setmkt" data-p="' + esc(JSON.stringify({ id: co.id, ch: k, b: o })) + '">' + (o ? mcur(o) : 'Off') + '</button>').join('') + '</div></div>';
    };
    h = h.replace('<div class="card"><h3>Brand awareness in ', '<div class="card"><div class="kv bigkv"><span>Weekly budget</span><b>' + money(mktCost(co)) + '</b></div><h3>Brand awareness in ');
    h += '<h2 class="sec">Active channels</h2>' + (on.length ? on.map(chanCard).join('') : '<div class="calm">No campaigns running.</div>');
    const adds = off.filter(k => !CH[k].prem).slice(0, 5);
    h += '<h2 class="sec">Add a channel</h2><div class="chips">' + adds.map(k => btn(esc(CH[k].n), 'plopen', { id: co.id, ch: k }, 'chip')) .join('') + btn('More…', 'addch', { id: co.id }, 'chip') + '</div>';
    h += btn('Plan a campaign', 'plopen', { id: co.id }, 'primary wide');
    return h;
  };""")

# ---------- G. staff: reporting chain, tagged list, problem card ----------
between("  CT.ppl = function (co, bd) {\n    const std = stdStaff(bd, co.size);", "  function staffCard(co, s) {", r"""  const AUTHN = ['Ask me first', 'Within limits', 'Full control'];
  function tenure(s) {
    const wk = Math.max(0, S.week - (s.w0 || S.week));
    return wk >= 52 ? Math.floor(wk / 52) + ' yr' + (wk >= 104 ? 's' : '') : wk >= 9 ? Math.round(wk / 4.35) + ' mo' : wk + ' wk';
  }
  function staffTag(s) {
    if (s.flag) return ['PROBLEM', 'red'];
    if (s.notice > 0) return ['Leaving', 'red'];
    if (s.nr > 0) return ['New', 'blue'];
    if ((s.skillGain || 0) >= 5) return ['Rising', 'blue'];
    return ['Fine', 'green'];
  }
  const ini2 = nm => String(nm || '?').split(/\s+/).slice(0, 2).map(x => x[0]).join('').toUpperCase();
  CT.ppl = function (co, bd) {
    const std = stdStaff(bd, co.size);
    const short = std.filter(s => co.staff.filter(x => x.role === s[0]).length < s[1]);
    const ac = actingMgr(co), an = ac ? S.npcs[ac.id] : null;
    const m = co.mgr ? S.npcs[co.mgr] : null;
    let h = '<div class="bhead"><b>' + (co.staff.length ? co.staff.length + ' staff' : 'No staff') + (short.length ? ' · <span class="neg">short: ' + short.map(s => esc(ROLES[s[0]][0])).join(', ') + '</span>' : '') + '</b><div class="chips">' + btn('＋ Find workers', 'hirego', { id: co.id }, 'chip primary') + '</div></div>';
    h += '<h2 class="sec">Who reports to whom</h2><div class="chain">';
    h += '<div class="lrow solo"><span class="av">' + esc(ini2(S.player && S.player.name)) + '</span><span class="ctext"><b>You (owner)</b><small>' + (m ? 'Sees every number, decides big things' : 'Runs it day to day · ' + co.ohrs + ' h a week') + '</small></span></div>';
    if (m) h += '<div class="lrow solo hl"><span class="av">' + esc(ini2(m.name)) + '</span><span class="ctext"><b>' + esc(m.name) + '</b><small>' + esc(titleFor(co, 'mgr')) + ' · ' + money(co.mgrWage) + '/mo</small></span><span class="badge amber">' + AUTHN[co.auth ? co.auth.lvl : 0] + '</span></div>';
    if (ac && an) h += '<div class="lrow solo"><span class="av">' + esc(ini2(an.name)) + '</span><span class="ctext"><b>' + esc(an.name) + '</b><small>Acting manager · ' + skillBand(an.skill) + '</small></span>' + btn('Promote', 'promoteact', { id: co.id }, 'chip primary') + '</div>';
    h += '</div>';
    if (co.staff.length) h += '<div class="lrows">' + co.staff.map(s => {
      const n = S.npcs[s.id];
      if (!n) return '';
      const tg = staffTag(s);
      return '<details class="srow"><summary class="lrow"><span class="av">' + esc(ini2(n.name)) + '</span><span class="ctext"><b>' + esc(n.name) + '</b><small>' + esc(ROLES[s.role][0]) + ' · ' + tenure(s) + ' · ' + money(s.wage) + '/mo</small></span><span class="badge ' + tg[1] + '">' + tg[0] + '</span></summary>' + staffCard(co, s) + '</details>';
    }).join('') + '</div>';
    co.staff.filter(s => s.flag && S.npcs[s.id]).slice(0, 2).forEach(s => {
      const n = S.npcs[s.id];
      h += '<div class="card probcard"><b>Problem: ' + esc(n.name) + '</b><p>' + esc(n.name.split(' ')[0]) + ' ' + FLAGN[s.flag] + '. Talk to them, let them go, or leave it to ' + (m ? esc(m.name.split(' ')[0]) : 'later') + '.</p><div class="two">' + btn('Talk to them', 'talkstaff', { id: co.id, s: s.id }, 'wide') + btn('Let go', 'firestaff', { id: co.id, s: s.id }, 'wide') + '</div></div>';
    });
    const ob = co.staff.filter(x => onbMissing(x).length).length;
    if (ob) h += '<div class="note bad">Paperwork open: ' + ob + '</div>';
    if (m) h += '<h2 class="sec">How much does ' + esc(m.name.split(' ')[0]) + ' decide?</h2>' + mgrBlock(co, bd);
    else h += btn('Find a manager', 'mgrgo', { id: co.id }, 'wide');
    return h;
  };
""")

# ---------- H. worker finder: candidate cards with tags, interview with chat bubbles ----------
rep("""    cl.forEach(id => {
      const n = S.npcs[id];
      if (n && !n.hired) h += candCard(co, n);
    });
    if (!cl.length) h += '<p class="muted small center">No candidates yet. Search to see applicants.</p>';
    return h;
  };""", """    const open = cl.map(id => S.npcs[id]).filter(n => n && !n.hired && !(ui.passed && ui.passed[n.id]));
    const sel = open.find(n => n.id === ui.cand);
    if (sel) return candDetail(co, sel);
    ui.cand = null;
    h += open.map(n => candList(co, n)).join('');
    if (!open.length) h += '<div class="calm">No candidates yet. Search to see applicants.</div>';
    return h;
  };
  function candTags(co, n) {
    const t = [];
    const ref = n.checked ? refCheck(n) : null;
    if (ref) t.push(ref.skillBand !== claimLabel(n) ? ['CV does not match', 'red'] : ['References checked', 'green']);
    else t.push(['Claim unverified', 'amber']);
    if (n.trial) t.push(['Trial: ' + band(n.trialRes != null ? n.trialRes : n.skill), 'blue']);
    if (n.age < 25) t.push(['Young', 'amber']);
    const norm = wageFor(n.role, co);
    if (norm && n.ask < norm * 0.9) t.push(['Cheap', '']);
    if (norm && n.ask > norm * 1.2) t.push(['Expensive', 'red']);
    if (n.tier != null && TIERN[n.tier]) t.push([TIERN[n.tier], '']);
    return t;
  }
  function candList(co, n) {
    const norm = wageFor(n.role, co);
    const askC = norm && n.ask > norm * 1.2 ? 'red' : norm && n.ask < norm * 0.9 ? 'green' : 'blue';
    return '<button class="ccard" data-a="candopen" data-p="' + esc(JSON.stringify({ n: n.id })) + '"><div class="cchd"><span class="av">' + esc(n.name.split(' ').slice(0, 2).map(x => x[0]).join('')) + '</span><span class="ctext"><b>' + esc(n.name) + ', ' + n.age + '</b><small>Claims ' + n.claimExp + ' yr · ' + esc(claimLabel(n)) + '</small></span><span class="badge ' + askC + '">Asks ' + mshort(n.ask) + '</span></div><div class="chips">' + candTags(co, n).map(x => '<span class="badge ' + x[1] + '">' + esc(x[0]) + '</span>').join('') + '</div></button>';
  }
  function candDetail(co, n) {
    const ref = n.checked ? refCheck(n) : null;
    const k = 'w' + n.id;
    const talk = (ui.talk && ui.talk[n.id]) || [];
    let h = '<div class="vh"><button class="bk" data-a="candback" aria-label="Back">‹</button><div class="vht"><h1>' + esc(n.name) + ', ' + n.age + '</h1><p>' + esc(ROLES[n.role] ? ROLES[n.role][0] : '') + ' · ' + esc(TIERN[n.tier] || '') + '</p></div></div>';
    h += '<div class="card">' + row('Claimed experience', n.claimExp + ' yr · ' + esc(claimLabel(n))) + row('Asks', money(n.ask) + ' / month') + '</div>';
    h += '<h2 class="sec">Salary discussion</h2><div class="chat"><div class="bub them">“' + esc(n.resume) + '” I am asking ' + money(n.ask) + ' a month.</div>' + talk.map(x => '<div class="bub ' + (x.me ? 'me' : 'them') + '">' + esc(x.t) + '</div>').join('') + '</div>';
    h += '<div class="card sense"><b>What you can sense</b><p>' + (ref ? 'References: real level ' + esc(ref.skillBand) + ', ' + ref.exp + ' yr experience' + (ref.trait ? '. Notes: ' + esc(TRAITS[ref.trait]) : '. No concerns') + (n.super ? '. Exceptional track record.' : '') + (ref.skillBand !== claimLabel(n) ? ' The CV does not match.' : '') : 'You only have the CV so far. Some people exaggerate.') + (n.trial ? ' Trial week result: about ' + band(n.trialRes != null ? n.trialRes : n.skill) + '.' : '') + '</p><div class="chips">' + (n.checked ? '' : btn('Check references · {m:600}', 'refcheck', { id: co.id, n: n.id }, 'chip')) + (n.trial ? '' : btn('Trial week · ' + mshort(n.ask / 4), 'trial', { id: co.id, n: n.id }, 'chip')) + '</div></div>';
    h += payOffer(co, n) + '<div class="card">' + '<div class="kv"><span>Your offer / month</span>' + inp(k, '', n.ask) + '</div><div class="chips">' + [0.9, 1, 1.05, 1.15].map(f => '<button class="btn chip" data-a="setinp" data-p="' + esc(JSON.stringify({ k: k, v: Math.round(n.ask * f / 100) * 100 })) + '">' + Math.round(f * 100) + '%</button>').join('') + '</div></div>';
    h += '<div class="tri two2"><div><span>Cost per year</span><b>' + mshort(inum(k, n.ask) * 12) + '</b></div><div><span>Real skill</span><b class="' + (ref ? '' : 'amb') + '">' + (ref ? esc(ref.skillBand) : 'Unknown') + '</b></div></div>';
    h += '<div class="two">' + btn('Pass', 'candpass', { n: n.id }, 'wide') + btn('Make offer', 'offer', { id: co.id, n: n.id }, 'primary wide') + '</div>';
    return h;
  }
  ACT.candopen = p => {
    ui.cand = p.n;
    render(true);
  };
  ACT.candback = () => {
    ui.cand = null;
    render(true);
  };
  ACT.candpass = p => {
    ui.passed = ui.passed || {};
    ui.passed[p.n] = 1;
    ui.cand = null;
    render(true);
  };""")

# ---------- I. decision cards: stat boxes and a big button row ----------
between("  function msgCard(m) {", "/* decisions you must take yourself", r"""  function msgCard(m) {
    const co = m.co ? getCo(m.co) : null;
    const left = m.exp ? Math.max(0, m.exp - S.week) : 0;
    const from = m.from || (co ? co.name : '');
    const ini = String(from || '?').replace(/[^A-Za-zÀ-ÿ0-9 ]/g, ' ').trim().split(/\s+/).slice(0, 2).map(x => x[0]).join('').toUpperCase() || '?';
    let h = '<div class="card dc"><div class="cchd"><span class="av">' + esc(ini) + '</span><span class="ctext"><b>' + esc(m.title) + '</b><small>' + esc(from) + (co && co.name !== from ? ' · ' + esc(co.name) : '') + '</small></span>' + (m.exp ? '<span class="badge ' + (left <= 1 ? 'red' : 'amber') + '">' + (left <= 0 ? 'Now' : left + ' wk') + '</span>' : (m.status === 'open' ? '<span class="badge amber">New</span>' : '')) + '</div>' + (m.pa && m.exp ? '<small>One week extra from your assistant</small>' : '') + (m.body ? '<div class="bub them">' + esc(m.body) + '</div>' : '');
    if (m.ask && m.mgrName) h += noteBox(esc(m.mgrName) + ' recommends: <b>' + esc(m.opts[m.rec].l) + '</b>');
    const opts = m.opts || [];
    const money2 = opts.filter(o => o.fx && (o.fx.cash || o.fx.loss || o.fx.fine)).slice(0, 2);
    if (money2.length) h += '<div class="duo">' + money2.map(o => {
      const v = (o.fx.cash || 0) - Math.abs(o.fx.loss || 0) - (o.fx.fine || 0);
      return '<div><span>' + esc(o.l) + '</span><b class="' + (v >= 0 ? 'pos' : 'neg') + '">' + (v >= 0 ? '+' : '−') + mshort(Math.abs(v)) + '</b></div>';
    }).join('') + '</div>';
    h += '<div class="dbtns">' + opts.map((o, i) => '<button class="btn' + (m.rec === i || (m.rec == null && i === 0 && opts.length > 1) ? ' primary' : '') + (optBlock(m, i) ? ' off' : '') + '" data-a="msgpick" data-p="' + esc(JSON.stringify({ id: m.id, i: i })) + '"><b>' + esc(o.l) + '</b>' + (o.d || (o.fx && fxText(o.fx)) ? '<small>' + esc(o.d || fxText(o.fx)) + '</small>' : '') + (optBlock(m, i) ? '<small class="neg">' + esc(optBlock(m, i)) + '</small>' : '') + '</button>').join('') + '</div>';
    if (m.go) h += btn(esc(m.go.l || 'Open'), m.go.a, m.go.p, 'primary wide');
    if (m.exp) h += '<small class="muted">If you do nothing, the cheapest option is chosen when time runs out.</small>';
    return h + '</div>';
  }

""", keep_end=True)

# ---------- J. accountant / law / insurer offers as mockup cards ----------
between("function provRow(a, kind, cur, data) {", "  function provSheet(co, kind) {", r"""function provRow(a, kind, cur, data) {
    const ini = String(a.name).replace(/[^A-Za-zÀ-ÿ ]/g, ' ').trim().split(/\s+/).slice(0, 2).map(x => x[0]).join('').toUpperCase();
    const acc = kind === 'acc' ? (a.err < 0.05 ? ['High', 'pos'] : a.err < 0.09 ? ['Medium', 'amb'] : ['Low', 'neg']) : null;
    const rows = kind === 'acc' ? row('Accuracy', '<span class="' + acc[1] + '">' + acc[0] + '</span>') + row('Error rate', Math.round(a.err * 100) + '%') : kind === 'law' ? row('Record', a.q > 0.8 ? '<span class="pos">Wins most cases</span>' : a.q > 0.6 ? 'Solid record' : '<span class="amb">Mixed record</span>') : row('Premiums', a.premM < 0.97 ? '<span class="pos">Below market</span>' : a.premM > 1.03 ? '<span class="neg">Above market</span>' : 'Around market') + row('Pays out', a.payM > 0.93 ? '<span class="pos">Reliably</span>' : a.payM > 0.82 ? 'Usually' : '<span class="neg">Reluctantly</span>');
    return '<div class="card offer' + (cur === a.id ? ' on' : '') + '"><div class="cchd"><span class="av">' + esc(ini) + '</span><span class="ctext"><b>' + esc(a.name) + '</b><small>' + stars(a.rating, a.reviews) + '</small></span>' + (a.fee ? '<span class="badge' + (cur === a.id ? ' amber' : '') + '">' + mshort(a.fee) + '/mo</span>' : '') + '</div>' + rows + '<button class="btn wide' + (cur === a.id ? '' : ' primary') + '" data-a="' + data.a + '" data-p="' + esc(JSON.stringify(data.p)) + '">' + (cur === a.id ? 'Current choice' : 'Hire') + '</button></div>';
  }
""", keep_end=True)
rep("""    openSheet('<h2>Convert to ' + CC().forms.AS + '</h2><p class="lead">Cost: ' + money(c.asConvFee) + ' fee plus ' + money(c.asCapital) + ' share capital, paid by you. You get limited liability, an accountant and company tax of ' + pc(c.corp, 0) + '. Past profit this year is taxed as your income.</p>' + poolFor(co.country).acc.map(a => provRow(a, 'acc', null, { a: 'convgo', p: { id: co.id, a: a.id } })).join('') + btn('Cancel', 'sheetclose', undefined, 'ghost wide'));""",
    """    openSheet('<h2>Convert to ' + CC().forms.AS + '</h2><div class="card sense"><b>' + esc(co.name) + ' (' + esc(CC().forms.ENK) + ') becomes ' + esc(co.name) + ' ' + esc(CC().forms.AS) + '</b><p>You get limited liability and an accountant. Past profit this year is taxed as your income.</p></div>' +
      '<h3 class="gap">Step 1 of 2 · Share capital</h3><div class="card ctr"><span class="lab">You put into the company</span><b class="huge">' + nok(c.asCapital) + '</b>' + row('Paid from', 'Personal · ' + mshort(S.cash)) + '</div>' +
      '<h3 class="gap">What happens</h3><div class="card">' + row('Existing clients and equipment', '<span class="pos">Move over</span>') + row('Registration fee', nok(c.asConvFee)) + row('Accounting duty', '<span class="amb">Required</span>') + row('Tax', pc(c.corp, 0) + ' company tax, then dividend tax') + row('Your liability', '<span class="pos">Limited to share capital</span>') + '</div>' +
      '<h3 class="gap">Step 2 of 2 · Pick an accountant</h3><p class="muted small">Picking one pays ' + nok(c.asConvFee + c.asCapital) + ' and converts the company.</p>' + poolFor(co.country).acc.map(a => provRow(a, 'acc', null, { a: 'convgo', p: { id: co.id, a: a.id } })).join('') + btn('Cancel', 'sheetclose', undefined, 'ghost wide'));""")

open(path, 'w', encoding='utf8').write(t)
print('patch4 ok')

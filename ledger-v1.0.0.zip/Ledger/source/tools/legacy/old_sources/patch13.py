path = '/home/claude/w3/ledger.html'
T = '/home/claude/w3/tools/'
t = open(path, encoding='utf8').read()
def rep(old, new, count=1):
    global t
    n = t.count(old)
    if n != count: raise SystemExit('MATCH %d (want %d): %s' % (n, count, old[:110]))
    t = t.replace(old, new)
# pager: a list taller than a page is split by its rows, and a short note is never left alone on a page
rep("""      const pages = [[]];
      let used = 0;
      body.forEach(x => {
        const hgt = x.offsetHeight + gap;
        if (pages[pages.length - 1].length && used + hgt > room) {
          pages.push([]);
          used = 0;
        }
        pages[pages.length - 1].push(x);
        used += hgt;
      });
      if (pages.length < 2) return;""", """      const items = [];
      body.forEach(x => {
        if (x.offsetHeight > room * 0.6 && x.children.length > 1) Array.prototype.forEach.call(x.children, y => { y.style.display = ''; items.push({ el: y, box: x, h: y.offsetHeight + (parseFloat(getComputedStyle(x).rowGap || getComputedStyle(x).gap) || 6) }); });
        else items.push({ el: x, box: null, h: x.offsetHeight + gap });
      });
      const pages = [[]];
      let used = 0;
      items.forEach(it => {
        const cur = pages[pages.length - 1];
        const onlySmall = cur.length && cur.every(z => z.h < 60);
        if (cur.length && used + it.h > room && !onlySmall) {
          pages.push([]);
          used = 0;
        }
        pages[pages.length - 1].push(it);
        used += it.h;
      });
      if (pages.length < 2) return;""")
rep("""      pages.forEach((p, i) => p.forEach(x => {
        x.style.display = i === pg ? '' : 'none';
      }));""", """      const boxes = new Set();
      pages.forEach((p, i) => p.forEach(it => {
        it.el.style.display = i === pg ? '' : 'none';
        if (it.box) boxes.add(it.box);
      }));
      boxes.forEach(bx => { bx.style.display = pages[pg].some(it => it.box === bx) ? '' : 'none'; });""")
rep("""      kids.forEach(x => {
        x.style.display = '';
      });""", """      kids.forEach(x => {
        x.style.display = '';
        Array.prototype.forEach.call(x.children, y => { if (y.style && y.style.display === 'none') y.style.display = ''; });
      });""")
open(path, 'w', encoding='utf8').write(t)
print('patch13 ok')

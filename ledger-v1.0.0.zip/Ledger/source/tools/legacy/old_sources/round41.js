/* ===== Round 41: trades work in hours, the overview is live, reviews are real, and the week report says where money went.
   - Plumbers, electricians, builders and engineering offices sell whole jobs measured in hours. Requests come in through
     the week, you take them on while you are booked less than three weeks ahead, and your hours go to the oldest job
     first. A job is paid when it is finished; big jobs pay 30% at the start, 40% halfway and 30% at the end.
   - The overview's "This week" box says what its numbers mean and updates every day.
   - Reviews arrive the day customers are served; the average shown is the average of the real reviews.
   - Customers who used you tell others: awareness grows with the work you actually do.
   - The week report separates money that moved from the result earned, and explains the difference. ===== */
window.R41 = window.R41 || {};
(function () {
  'use strict';
  const R41 = window.R41;
  const U = window.UI;
  if (!U) return;
  const { ui, V, ACT, esc, row, btn, card, go, render, save, svg, openSheet, closeSheet, toast, bar } = U;
  const CT = window.CT;
  const P = o => esc(JSON.stringify(o));
  const live = () => S.cos.filter(c => c.st !== 'sold' && c.st !== 'bust');
  const plus = v => (v >= 0 ? '+' : '−') + mshort(Math.abs(v));
  const sgnC = v => (v > 0 ? 'pos' : v < 0 ? 'neg' : '');
  const capF = s => String(s || '').replace(/^./, x => x.toUpperCase());
  const blockEnd = (h, s) => R30.blockEnd(h, s);
  const wdOf = (w, d) => (new Date(wDate(w).getTime() + d * 86400000).getUTCDay() + 6) % 7;

  /* ================= 1. trades that sell whole jobs in hours ================= */
  /* HV: what one working hour brings in (labour and materials), NOK before local prices.
     Job sizes in hours: small, medium, big. Mix by the Focus choice: small-heavy, mixed, big-heavy. */
  const HT = {
    plumber: {
      HV: 1500,
      cls: [[4, 10], [10, 18], [30, 45]],
      what: [['Leaking tap', 'Blocked drain', 'New toilet', 'Water heater swap', 'Pipe repair', 'Radiator fix'], ['Kitchen plumbing', 'Heat pump connection', 'Underfloor heating', 'New water pipes'], ['Bathroom renovation']],
      mix: { em: [0.9, 0.1, 0], mix: [0.55, 0.3, 0.15], bath: [0.1, 0.2, 0.7] },
      prem: { em: 1.3 }
    },
    electrician: {
      HV: 1650,
      cls: [[3, 8], [8, 16], [28, 45]],
      what: [['Fuse box check', 'New sockets', 'Light fittings', 'Fault finding', 'EV charger install'], ['Kitchen rewiring', 'Solar panels', 'Smart home setup'], ['Full house rewiring', 'Commercial installation']],
      mix: { home: [0.85, 0.15, 0], mix: [0.55, 0.3, 0.15], ind: [0.1, 0.3, 0.6] },
      prem: {}
    },
    construction: {
      HV: 1500,
      cls: [[40, 120], [300, 700], [2000, 5000]],
      what: [['Terrace', 'Garage', 'Small extension', 'Facade repair'], ['House extension', 'Loft conversion', 'Detached house'], ['Apartment block', 'Office building', 'School building']],
      mix: { house: [0.55, 0.4, 0.05], comm: [0.25, 0.5, 0.25], pub: [0.05, 0.35, 0.6] },
      prem: {}
    },
    engcons: {
      HV: 1700,
      cls: [[12, 40], [60, 160], [400, 1000]],
      what: [['Structural check', 'Survey report', 'Permit drawings', 'Energy assessment'], ['House design', 'Renovation project', 'Extension drawings'], ['Office building design', 'Bridge study', 'Housing project design']],
      mix: { res: [0.85, 0.15, 0], bld: [0.6, 0.35, 0.05], inf: [0.2, 0.5, 0.3] },
      prem: {}
    }
  };
  /* the event agency: hours of preparation before a fixed event day */
  HT.event = {
    HV: 2000, ev: 1,
    cls: [[12, 30], [40, 90], [150, 300]],
    what: [['party'], ['conference'], ['festival']],
    mix: { corp: [0.5, 0.4, 0.1], conc: [0.1, 0.4, 0.5], wed: [0.75, 0.25, 0] },
    prem: {}
  };
  const SIZEN = ['Small', 'Medium', 'Big'];
  const isHT = co => !!(co && HT[co.type] && BD[co.type] && !BD[co.type].tw.dev);
  R41.isHT = isHT;
  R41.HT = HT;
  function segOf(co) {
    const bd = BD[co.type], k = (bd.knobs || []).find(x => x.id === 'seg');
    const o = k ? knobOpt(co, k) : null;
    return o ? o.id : 'mix';
  }
  /* clients with very big projects rarely ask a firm that would need half a year for them: a small firm gets more small jobs */
  function mixOf(co) {
    const t = HT[co.type], s = segOf(co);
    const m0 = t.mix[s] || t.mix.mix || Object.values(t.mix)[1];
    const Hw = co.fm && co.fm.hw41 ? co.fm.hw41 : 0;
    if (!(Hw > 0)) return m0;
    const m = m0.map((p, i) => { const a = (t.cls[i][0] + t.cls[i][1]) / 2; return a <= 3 * Hw ? p : p * Math.pow(3 * Hw / a, 1.5); });
    const tot = m.reduce((x, y) => x + y, 0);
    return tot > 0 ? m.map(x => x / tot) : m0;
  }
  const avgOf = (t, m) => m.reduce((a, p, i) => a + p * (t.cls[i][0] + t.cls[i][1]) / 2, 0);
  /* local value of one hour: prices where you work, your own price level and reputation; emergency work pays extra */
  function hvLocal(co, bd) {
    const t = HT[co.type];
    let pl = 1;
    try { pl = ticketMult(co, bd) / Math.max(0.01, (window.R8 && R8.jobScale ? R8.jobScale(co) : 1) * knobFx(co, 't')); } catch (e) { }
    return t.HV * pl * (1 + ((co.rep || 50) - 50) / 500) * (t.prem[segOf(co)] || 1);
  }
  /* hours you can bill in a week: what your people and kit can deliver, in hours */
  function hoursWeek(co, bd, cp) {
    return Math.max(0, (cp.cap || 0) * bd.ticket / HT[co.type].HV);
  }
  function clientName(co, cls) {
    const C = CO[co.country] || CC();
    if (cls === 0 || (cls === 1 && Z() < 0.6)) return 'the ' + C.last[Math.floor(Z() * C.last.length)] + ' family';
    return pick(['a housing co-op', 'the municipality', 'a developer', 'a retail chain', 'the school board', 'an office owner', 'a hotel', 'a landlord']);
  }
  function newJob(co, bd, hvl) {
    const t = HT[co.type], m = mixOf(co);
    let x = Z(), c = 0;
    while (c < 2 && (x -= m[c]) > 0) c++;
    const r = t.cls[c], hq = Math.round(r[0] + Z() * (r[1] - r[0]));
    const tw = bd.tw;
    const over = (tw.over || 0.07) * (c === 2 ? 2.5 : 1.6);
    const h = Math.max(1, Math.round(hq * Math.max(0.7, 1 + gauss() * over + 0.02)));
    const base = ((tw.mat || 0) + (tw.sub || 0)) * modProd(co, 'price') * (S.econ.mat * 0.5 + 0.5) * (1 + gauss() * (tw.over || 0.07));
    const step = hq * hvl >= 20000 ? 1000 : 100;
    return { id: uid(), h41: 1, cls: c, what: pick(t.what[c]), client: clientName(co, c), hq, h, done: 0, v: Math.max(step, Math.round(hq * hvl / step) * step), paid: 0, cf: Math.max(0.05, base), delay: 0, w0: S.week, p: 0, wks: Math.max(1, Math.round(h / 37.5)) };
  }
  /* jobs from older saves and tenders won elsewhere are turned into hours */
  function norm(co, bd, j, hvl) {
    if (j.h41) return j;
    const t = HT[co.type];
    const h = Math.max(1, Math.round((j.v || 0) / Math.max(1, hvl)));
    const c = h > t.cls[1][1] ? 2 : h > t.cls[0][1] ? 1 : 0;
    j.h41 = 1; j.cls = c; j.h = h; j.hq = h; j.done = Math.round(h * (j.p || 0)); j.paid = Math.round((j.v || 0) * (j.p || 0));
    j.what = j.what || pick(t.what[c]);
    j.client = j.client || 'a client';
    if (t.ev && j.dueD == null) j.dueD = Math.max(S.week + 1, j.due || S.week + 2) * 7 + 3;
    return j;
  }
  const remH = j => Math.max(0, j.h - j.done);
  const backH = fm => (fm.jobs || []).reduce((a, j) => a + (j.h41 ? remH(j) : 0), 0);
  function newLog(w) { return { w, days: {}, req: 0, took: 0, lost: 0, big: 0, tooBig: 0, used: 0, H: 0, Hw: 0, Dh: 0, rev: 0, cogs: 0, paid: 0, units: 0, fin: [0, 0, 0], names: [] }; }
  function payJob(co, bd, L, j, amt, why) {
    amt = Math.round(Math.min(amt, j.v - j.paid));
    if (amt <= 0) return 0;
    j.paid += amt;
    L.rev += amt;
    L.cogs += amt * j.cf;
    const vr = vatRate(co);
    const cash = Math.round(amt * (1 + vr) * (1 - (bd.b2b || 0)));
    if (cash) coIn(co, cash, null, null);
    L.paid += cash;
    return amt;
  }
  /* one day of work: requests come in, hours go to the oldest job first, finished jobs are paid */
  function projDay(co, bd, L, wk, d) {
    if (L.days[d]) return;
    const fm = co.fm = co.fm || {};
    fm.jobs = fm.jobs || [];
    fm.won = fm.won || 0;
    fm.done = fm.done || 0;
    setCtx(co);
    try {
      const dm = demand(co, bd), cp = capacity(co, bd);
      const t = HT[co.type], m = mixOf(co), avgH = avgOf(t, m);
      const hvl = hvLocal(co, bd);
      const Hw = hoursWeek(co, bd, cp);
      const wd = wdOf(wk, d);
      const workShare = wd < 5 ? 0.2 : 0;
      const reqShare = wd < 5 ? 0.18 : wd === 5 ? 0.07 : 0.03;
      const js = window.R8 && R8.jobScale ? R8.jobScale(co) : 1;
      const Dh = (dm.D || 0) * js * bd.ticket * knobFx(co, 't') * knobFx(co, 'tt') / t.HV;
      L.Dh += Dh * reqShare;
      L.Hw += Hw / 7;
      L.H += Hw * workShare;
      co.dbg = { D: dm.D, cap: cp.cap, dp: dm.parts, cp: cp.parts, bot: cp.bot ? cp.bot.label : '', owner: cp.owner, botObj: cp.bot ? { kind: cp.bot.kind, k: cp.bot.k } : null };
      fm.jobs.forEach(j => norm(co, bd, j, hvl));
      /* new requests */
      const EV = t.ev && window.R30 && R30.ev ? R30.ev : null;
      const nowD = wk * 7 + d;
      let ev30 = null;
      if (EV) {
        ev30 = fm.ev30 = fm.ev30 || { due: [], m: -1, bm: 0, dm: 0, tot: 0 };
        const mi = monthIdx(wk);
        if (ev30.m !== mi) { ev30.m = mi; ev30.bm = 0; ev30.dm = 0; }
      }
      const take = (j, src, from) => {
        L.req++;
        if (EV) {
          /* an event has a date: take it only if the team can prepare it, and everything due before it, in time */
          j.wks = j.cls === 2 ? rint(6, 14) : j.cls === 1 ? rint(3, 8) : rint(1, 4);
          EV.dress(co, j, src || 'mkt', from);
          if (j.cls === 2 && src !== 'rep') j.what = pick([['conference', 'product launch', 'customer seminar'], ['outdoor festival', 'summer concert'], ['wedding']][(co.knob && co.knob.seg) || 0] || ['conference']);
          j.due = wk + j.wks;
          j.dueD = j.due * 7 + Math.floor(Z() * 7);
          const before = fm.jobs.filter(x => x.dueD <= j.dueD).reduce((a, x) => a + remH(x), 0);
          if (Hw <= 0 || before + j.h > (j.dueD - nowD) / 7 * Hw * 0.9) { L.lost++; return false; }
        } else {
          const wait = Hw > 0 ? backH(fm) / Hw : 99;
          if (Hw <= 0 || wait > 3) { L.lost++; return false; }
          if (j.h > Hw * 12) { L.lost++; L.tooBig++; return false; }
        }
        fm.jobs.push(j);
        fm.won++;
        L.took++;
        if (j.cls === 2) L.big++;
        if (EV) { ev30.bm++; payJob(co, bd, L, j, j.v * 0.3); EV.booked(co, j); }
        return true;
      };
      const n = pois(Dh * reqShare / Math.max(1, avgH));
      for (let i = 0; i < n; i++) take(newJob(co, bd, hvl));
      /* happy clients recommend you and book again */
      if (EV) ev30.due = ev30.due.filter(x => { if (wk < x.w) return true; if (co.st === 'open') take(newJob(co, bd, hvl), x.src, x.from); return false; });
      /* the day's work: the oldest job first; for events the nearest date first */
      let left = Hw * workShare;
      const order = EV ? fm.jobs.slice().sort((a, b) => a.dueD - b.dueD) : fm.jobs;
      for (const j of order) {
        if (left <= 1e-6) break;
        if (j.delay > 0) { if (workShare > 0) j.delay = Math.max(0, j.delay - 0.2); continue; }
        const use = Math.min(left, remH(j));
        if (use <= 0) continue;
        if (j.st41 == null) j.st41 = !EV && (j.cls === 2 || j.h > 2 * Hw) ? 1 : 0;
        if (!j.done && j.st41) {
          const dep = payJob(co, bd, L, j, j.v * 0.3);
          if (dep && j.cls === 2) note('Started: ' + j.what.toLowerCase() + ' for ' + j.client + '. Deposit paid: ' + mshort(dep) + '.', 'n', co.id);
        }
        j.done += use;
        left -= use;
        L.used += use;
        j.p = Math.min(1, j.done / j.h);
        if (j.st41 && j.p >= 0.5 && j.paid < j.v * 0.69) payJob(co, bd, L, j, j.v * 0.7 - j.paid);
      }
      /* finished jobs; events happen on their day, ready or not */
      const fin = EV ? fm.jobs.filter(j => nowD >= j.dueD) : fm.jobs.filter(j => j.done >= j.h - 1e-6);
      fin.forEach(j => {
        const prep = Math.min(1, j.done / j.h);
        const last = payJob(co, bd, L, j, j.v - j.paid);
        fm.done++;
        L.units++;
        L.fin[j.cls]++;
        fm.fin41 = fm.fin41 || [0, 0, 0];
        fm.fin41[j.cls]++;
        if (j.cls > 0) L.names.push(EV ? j.what : j.what);
        const q = co.q != null ? co.q : 55;
        const dr = [0.08, 0.15, 0.35][j.cls];
        if (EV && prep < 0.9) co.rep = clamp((co.rep || 50) - 1.5 * (1 - prep) * 3, 0, 100);
        else co.rep = clamp((co.rep || 50) + (q > 55 ? dr : q < 45 ? -dr * 0.6 : 0), 0, 100);
        if (EV) {
          ev30.dm++; ev30.tot++;
          if (prep >= 0.9) EV.delivered(co, j, ev30);
          else addMsg({ kind: 'info', from: co.name, title: 'Delivered in a rush: ' + EV.evName(j), body: 'Only ' + Math.round(prep * 100) + '% of the preparation was done in time. The client noticed; no recommendations from this one. Final invoice sent.', co: co.id, tone: 'bad', status: 'done' });
          if (j.cls > 0) dayNote(['Delivered', co.name + ' · ' + EV.evName(j), j.v]);
        } else if (j.cls === 2) {
          note(capF(j.what) + ' for ' + j.client + ' finished. Final payment ' + mshort(last) + ' (the whole job ' + mshort(j.v) + ').', 'good', co.id);
          dayNote(['Finished', co.name + ' · ' + j.what.toLowerCase() + ' done', last]);
        }
        /* a finished job may get a review */
        const pr = Math.min(0.7, rvRate(co.type) * [1, 1.4, 2][j.cls]);
        if (Z() < pr) addReviews(co, 1, (j.h > j.hq * 1.25 ? -0.4 : 0) + (prep < 0.9 ? -1 : 0));
      });
      fm.jobs = fm.jobs.filter(j => fin.indexOf(j) < 0);
      fm.backlog = Math.round(fm.jobs.reduce((a, j) => a + (j.v - j.paid), 0));
      fm.backlogH = Math.round(backH(fm));
      fm.backlogWk = Hw > 0 ? fm.backlogH / Hw : 99;
      fm.hw41 = Hw;
      fm.avgH41 = avgH;
      fm.hvl41 = hvl;
      L.days[d] = 1;
    } finally { setCtx(null); }
  }
  R41.projDay = projDay;
  /* the week's books take what happened on its days; a week played without days runs all seven now */
  const pcPrev = FAM.project.custom;
  FAM.project.custom = function (co, bd, ctx) {
    if (!isHT(co)) return pcPrev.apply(this, arguments);
    const fm = co.fm = co.fm || {};
    const wk = S.week - 1;
    let L = fm.d41 && fm.d41.w === wk ? fm.d41 : (fm.d41 = newLog(wk));
    for (let d = 0; d < 7; d++) if (!L.days[d]) projDay(co, bd, L, wk, d);
    const avgH = fm.avgH41 || avgOf(HT[co.type], mixOf(co));
    ctx.D = L.Dh / avgH;
    ctx.cap = L.Hw / avgH;
    ctx.units = L.units;
    ctx.util = L.Hw > 0 ? Math.min(1, L.used / L.Hw) : 0;
    ctx.rev = L.rev;
    ctx.cogs = L.cogs;
    ctx.price = avgH * (fm.hvl41 || 0);
    ctx.paidD = L.paid;
    if (co.dbg) { co.dbg.D = ctx.D; co.dbg.cap = ctx.cap; }
    fm.wk41 = { w: wk, req: L.req, took: L.took, lost: L.lost, tooBig: L.tooBig, big: L.big, used: Math.round(L.used), H: Math.round(L.Hw), fin: L.fin.slice(), names: L.names.slice(0, 4), rev: Math.round(L.rev) };
    fm.lost41 = (fm.lost41 || []).concat(L.lost).slice(-4);
    fm.d41 = null;
  };
  /* a delay from an event holds a job up for days, not weeks */
  const pfx = FAM.project.fx;
  FAM.project.fx = function (co, bd, fx) {
    if (!isHT(co)) return pfx.apply(this, arguments);
    const fm = co.fm || {}, J = (fm.jobs || []).filter(j => j.h41);
    if (fx.ovr && J.length) { const j = pick(J); j.h = Math.round(j.h * (1 + Math.min(0.5, fx.ovr * 2))); }
    if (fx.defect && fm.done) payCo(co, Math.round((fm.hvl41 || 1000) * 6 * fx.defect), 'loss', 'Fixing a finished job');
    if (fx.delay != null && J.length) pick(J).delay += fx.delay;
  };

  /* ================= 2. real reviews, the day they are written ================= */
  function avgRv(co) {
    if (!co) return 0;
    if (co.rvS == null) co.rvS = ratingOf(co) * (co.rvN || 0);
    return co.rvN ? Math.round(co.rvS / co.rvN * 10) / 10 : ratingOf(co);
  }
  R41.avg = avgRv;
  function addReviews(co, k, bias) {
    if (co.rvS == null) co.rvS = ratingOf(co) * (co.rvN || 0);
    co.rv41 = co.rv41 || [];
    for (let i = 0; i < k; i++) {
      const c = (co.rvN || 0) + 1;
      const mu = clamp(ratingOf(co) + (bias || 0), 1.2, 4.95);
      let r = null;
      try { r = reviewsOf('c' + co.id, co.type, co.country, mu, c, co.price, 1, 1)[0]; } catch (e) { }
      const st = r ? r.st : Math.round(mu);
      co.rvN = c;
      co.rvS += st;
      co.rv41.push({ c, st, tx: r ? r.tx : '' });
      if (co.rv41.length > 200) co.rv41.shift();
      co.rvD41 = S.week;
      if (st >= 5 || st <= 2) dayNote([st >= 5 ? '★★★★★' : '★★', (st >= 5 ? 'A 5-star review for ' : 'An unhappy review for ') + co.name, null]);
    }
  }
  R41.addReviews = addReviews;
  /* stored reviews keep the stars they were given */
  const nrv0 = window.R11NRV;
  window.R11NRV = function (key, c) {
    const o = nrv0 ? nrv0.apply(this, arguments) : null;
    if (o) return o;
    const co = S.cos.find(x => 'c' + x.id === key);
    if (!co || !co.rv41) return null;
    for (let i = co.rv41.length - 1; i >= 0; i--) if (co.rv41[i].c === c) return co.rv41[i].tx ? co.rv41[i] : { st: co.rv41[i].st, tx: (reviewsOf(key, co.type, co.country, co.rv41[i].st, c, co.price, 1, 1)[0] || {}).tx || '' };
    return null;
  };
  /* reviews for a week played without days */
  if (typeof rvWeek === 'function') {
    const rv0 = rvWeek;
    rvWeek = function (co) {
      if (!co.lastW) return;
      co.uh = co.uh || [];
      co.uh.push(co.lastW.units || 0);
      if (co.uh.length > 40) co.uh.shift();
      if (isHT(co) || co.rvD41 === S.week - 1) return;
      const u = co.lastW.units || 0;
      co.rvF = (co.rvF || 0) + Math.min(u * rvRate(co.type), 30 + 3 * Math.sqrt(u));
      const n = Math.floor(co.rvF);
      if (n > 0) { co.rvF -= n; addReviews(co, Math.min(n, 60)); }
    };
  }
  if (typeof reviewList === 'function') {
    const rlx = reviewList;
    reviewList = function () {
      const L = rlx.apply(this, arguments);
      try { L.forEach(x => { if (x.mine && x.co) x.rt = avgRv(x.co); }); } catch (e) { }
      return L;
    };
  }
  /* staff named in a review changes its stars: keep the average honest */
  R7.afterWeek = R7.afterWeek || [];
  R7.afterWeek.push(() => {
    try {
      live().forEach(co => {
        if (!co.nrv || !co.rv41) return;
        const from = co.nrv41 || 0;
        co.nrv.forEach(r => {
          if (r.c <= from) return;
          const s = co.rv41.find(x => x.c === r.c);
          if (s && s.st !== r.st) { co.rvS += r.st - s.st; s.st = r.st; s.tx = r.tx; }
        });
        co.nrv41 = co.nrv.length ? co.nrv[co.nrv.length - 1].c : from;
      });
    } catch (e) { console.error(e); }
  });

  /* ================= 3. the day card ================= */
  function dayNote(x) {
    if (ui.untl) return;
    const k = S.week * 7 + (S.day || 0);
    if (!ui.day28 || ui.day28.k !== k) ui.day28 = { k, tot: 0, notes: [], at: Date.now() };
    if (ui.day28.notes.length < 6) ui.day28.notes.push(x);
    ui.day28.at = Date.now();
  }

  /* ================= 4. each day: trades work, reviews arrive, company cash is measured ================= */
  const rdPrev = window.R10DAY;
  window.R10DAY = function (d) {
    /* the week just ended: how much company cash actually moved */
    if (d === 0) {
      try {
        const c = S.cc41 = S.cc41 || { w: -1, start: {} };
        const per = {}, tot = { now: 0, d: 0 };
        live().forEach(co => { const s = c.start[co.id]; per[co.id] = s != null ? co.cash - s : null; tot.now += co.cash; if (s != null) tot.d += co.cash - s; });
        c.last = { w: S.week - 1, per, tot: Math.round(tot.now), d: Math.round(tot.d), ok: c.w === S.week - 1 };
        c.w = S.week;
        c.start = {};
        live().forEach(co => { c.start[co.id] = co.cash; });
      } catch (e) { console.error(e); }
    }
    const r = rdPrev ? rdPrev.apply(this, arguments) : undefined;
    try {
      if (d === 0 && S.cc41 && S.cc41.last && S.wk31 && S.wk31.length) {
        const a = S.wk31[S.wk31.length - 1];
        if (a && !a.cc && a.w === S.cc41.last.w) a.cc = S.cc41.last;
      }
    } catch (e) { }
    S.cos.forEach(co => {
      try {
        if (co.st !== 'open') return;
        const bd = BD[co.type];
        if (isHT(co)) {
          const fm = co.fm = co.fm || {};
          const L = fm.d41 && fm.d41.w === S.week ? fm.d41 : (fm.d41 = newLog(S.week));
          projDay(co, bd, L, S.week, d);
          return;
        }
        /* reviews from today's customers */
        if (window.R10 && R10.dailyOk(co, bd) && co.dl && co.dl.w === S.week && co.dl.days[d]) {
          const u = co.dl.days[d].u || 0;
          if (u <= 0) return;
          co.rvF = (co.rvF || 0) + Math.min(u * rvRate(co.type), (30 + 3 * Math.sqrt(u * 7)) / 7);
          const n = Math.floor(co.rvF);
          if (n > 0) { co.rvF -= n; addReviews(co, Math.min(n, 12)); }
          co.rvD41 = S.week;
        }
      } catch (e) { console.error(e); }
    });
    return r;
  };

  /* ================= 5. people who used you tell others ================= */
  R7.afterWeek.push(() => {
    try {
      live().forEach(co => {
        const bd = BD[co.type];
        co.awP41 = co.aw41 != null ? co.aw41 : co.aware;
        if (co.st !== 'open' || !bd || ['fin', 'energy', 'hold', 'club', 'rent'].indexOf(bd.fam) >= 0) { co.aw41 = co.aware; return; }
        const w = co.lastW || {};
        let x = 0;
        if (isHT(co)) x = ((co.fm && co.fm.wk41 ? co.fm.wk41.used : 0) || 0) / 30;
        else if (bd.capD > 0) x = (w.units || 0) / (bd.capD * 0.6);
        co.cu41 = (co.cu41 || []).concat(Math.min(4, x)).slice(-26);
        const ratio = co.cu41.reduce((a, v) => a + v, 0) / 26;
        /* being known is not the same as being liked: good work spreads a bit faster, poor work a bit slower */
        let qf = clamp(0.75 + ((co.q != null ? co.q : 55) - 45) / 80, 0.6, 1.2);
        if ((co.rvN || 0) >= 5) { const a = avgRv(co); qf *= a >= 4.2 ? 1.1 : a >= 3 ? 1 : 0.9; }
        /* round 45: cheap and good spreads fastest */
        try { qf *= clamp(1 + (1 - priceMult(co)) * 0.8, 0.75, 1.3); } catch (e) { }
        const floor = Math.min(70, 40 * Math.sqrt(Math.min(4, ratio)) * qf);
        if (co.aware < floor) co.aware = clamp(co.aware + (floor - co.aware) * 0.5, 0, 100);
        co.aw41 = co.aware;
      });
    } catch (e) { console.error(e); }
  });

  /* ================= 6. the overview: live, and every number says what it means ================= */
  const pct = x => Math.round(Math.max(0, x) * 100) + '%';
  function busyWord(r) { return r > 1.05 ? 'More than you can take' : r > 0.85 ? 'About what you can take' : r > 0.5 ? 'Room for more' : 'Plenty of room for more'; }
  function trend(co) {
    const a = co.aware || 0, b = co.awP41 != null ? co.awP41 : a;
    return a - b >= 0.3 ? ' <small class="pos">↑</small>' : b - a >= 0.3 ? ' <small class="neg">↓</small>' : '';
  }
  function tail(co) {
    const unpaid = (co.recv || []).reduce((a, r) => a + r.a, 0);
    return row('Average review', rvStars(avgRv(co), co.rvN || 0)) +
      row('Reputation', repWord(co.rep)) + row('How well known', awWord(co.aware) + trend(co)) +
      (unpaid > 0 ? row('Invoices not paid yet', '<span class="amb">' + mshort(unpaid) + '</span>') : '');
  }
  function weekCardHT(co, bd) {
    const EVt = !!HT[co.type].ev;
    const fm = co.fm || {}, L = fm.d41 && fm.d41.w === S.week ? fm.d41 : null, lw = fm.wk41 || null;
    const Hw = fm.hw41 || 0;
    const used = L ? L.used : 0, Hso = L ? L.H : 0;
    let h = '<h2 class="sec">This week so far</h2><div class="card wk41">';
    if (!Hw) h += '<div class="note bad"><b>You cannot take work right now.</b> ' + esc((co.dbg && co.dbg.bot) || 'Something') + ' is missing. Check Staff and Equipment.</div>';
    h += row('Requests', L && L.req ? L.req + ' · you took ' + L.took : 'None yet');
    if (L && L.lost) h += row('Turned away', '<span class="neg">' + L.lost + (L.tooBig ? ' · ' + L.tooBig + ' too big for you' : ' · booked too far ahead') + '</span>');
    h += '<div class="kv"><span>Your hours worked</span><b>' + Math.round(used) + ' of ' + Math.round(Hw) + ' h</b></div>' + bar(Hw ? Math.min(100, used / Hw * 100) : 0, 'var(--blue)');
    const fin = L ? L.fin : [0, 0, 0], nF = fin[0] + fin[1] + fin[2];
    h += row(EVt ? 'Events delivered' : 'Jobs finished', nF ? nF + (fin[2] ? ' · ' + fin[2] + ' big' : '') + (fin[1] ? ' · ' + fin[1] + ' medium' : '') : 'None yet');
    h += row('Paid to you', L && L.rev ? mshort(L.rev) : '–');
    if (lw) { const nf = lw.fin[0] + lw.fin[1] + lw.fin[2]; h += '<small class="jl41">Last week: ' + nf + (EVt ? (nf === 1 ? ' event' : ' events') + ' delivered' : (nf === 1 ? ' job' : ' jobs') + ' finished') + (lw.names.length ? ' (' + esc(lw.names.join(', ').toLowerCase()) + ')' : '') + ' · ' + lw.used + ' of ' + lw.H + ' h worked · ' + mshort(lw.rev) + ' paid' + (lw.lost ? ' · ' + lw.lost + ' turned away' : '') + '</small>'; }
    return h + tail(co) + '</div>';
  }
  function weekCardAll(co, bd) {
    const w = co.lastW || {};
    const dl = co.dl && co.dl.w === S.week ? co.dl : null;
    let h = '<h2 class="sec">This week</h2><div class="card wk41">';
    if (w.D != null && !w.cap && w.D > 0) h += '<div class="note bad"><b>Customers are looking, but you cannot serve them.</b> ' + esc((co.dbg && co.dbg.bot) || 'Something') + ' is missing. Check Staff and Equipment.</div>';
    h += window.unitsRows ? window.unitsRows(co, bd, w) : row(capF(unitPl(bd.unit, 2)) + ' sold', Math.round(w.units || 0));
    if (w.cap && bd.fam === 'rent') h += '<div class="kv"><span>Let out last week</span><b>' + pct(Math.min(1, w.util || 0)) + ' of your space</b></div>' + bar(Math.min(100, (w.util || 0) * 100), 'var(--blue)');
    else if (w.cap && bd.fam !== 'fin' && bd.fam !== 'energy') {
      let u = w.util || 0, lab = 'Last week you used', ask = null;
      if (dl && dl.cap > 0) {
        let sh = ((S.day || 0) + 1) / 7;
        try { const SH = R10.shapeOf(bd); sh = 0; for (let i = 0; i <= (S.day || 0); i++) sh += SH[wdOf(S.week, i)]; } catch (e) { }
        const sofar = dl.cap * sh;
        if (sofar > 0) { u = dl.u / sofar; lab = 'So far you use'; ask = (dl.u + (dl.q || 0)) / sofar; }
      }
      h += '<div class="kv"><span>' + lab + '</span><b>' + (u > 1.02 ? 'All of your capacity' + (u > 1.08 ? ' and more' : '') : pct(u) + ' of your capacity') + '</b></div>' + bar(Math.min(100, u * 100), u > 0.97 ? 'var(--amber)' : 'var(--blue)');
      h += row('Customers asking', busyWord(ask != null ? Math.max(ask, u) : w.D / w.cap));
    }
    return h + tail(co) + '</div>';
  }
  const dayDate = D => { const x = new Date(wDate(Math.floor(D / 7)).getTime() + (D % 7) * 86400000); return x.getUTCDate() + ' ' + MN[x.getUTCMonth()]; };
  /* the event agency: bookings with a date, preparation done so far */
  function eventsCard(co, bd) {
    const fm = co.fm || {}, J = (fm.jobs || []).filter(j => j.h41 && j.dueD != null).sort((a, b) => a.dueD - b.dueD), EV = window.R30 && R30.ev;
    const nameOf = j => esc(EV ? EV.evName(j) : capF(j.what));
    const rest = J.reduce((a, j) => a + (j.v - j.paid), 0), ev = fm.ev30 || { due: [] };
    let h = '<h2 class="sec">Bookings</h2><div class="card jobs41">' + row('Booked events', J.length ? J.length + ' · next on ' + dayDate(J[0].dueD) : 'None yet') + (J.length ? row('Still to be paid after the events', mshort(rest)) : '');
    h += J.slice(0, 4).map(j => { const pr = Math.min(1, j.done / j.h), late = (j.dueD - (S.week * 7 + (S.day || 0))) / 7 * (fm.hw41 || 0) < j.h - j.done; return '<div class="kv"><span>' + nameOf(j) + ' <small>' + dayDate(j.dueD) + '</small></span><b>' + mshort(j.v) + '</b></div>' + bar(pr * 100, late ? 'var(--amber)' : 'var(--green)') + '<small class="jl41">Prepared ' + Math.round(j.done) + ' of ' + j.h + ' h' + (pr >= 1 ? ' · ready' : late ? ' · will be rushed' : '') + '</small>'; }).join('');
    if (J.length > 4) h += '<small class="jl41">+' + (J.length - 4) + ' more booked</small>';
    const refs = (ev.due || []).filter(d => d.src === 'ref').length, reps = (ev.due || []).filter(d => d.src === 'rep').length;
    h += row('Delivered since opening', (fm.done || 0) + ((fm.done || 0) === 1 ? ' event' : ' events')) + (refs + reps ? row('Coming from happy clients', (refs ? refs + ' recommended' : '') + (refs && reps ? ' · ' : '') + (reps ? reps + ' booking again' : '')) : '');
    h += '<small class="jl41 nt41">Clients pay 30% when they book and the rest after the event. Preparation goes to the nearest date first. A booking is turned away when the team cannot prepare it in time.</small></div>';
    return h;
  }
  function jobsCard(co, bd) {
    if (HT[co.type].ev) return eventsCard(co, bd);
    const fm = co.fm || {}, J = (fm.jobs || []).filter(j => j.h41), Hw = fm.hw41 || 0;
    const bh = backH(fm), days = Hw > 0 ? bh / (Hw / 5) : 0;
    const rest = J.reduce((a, j) => a + (j.v - j.paid), 0);
    const ahead = !J.length ? 'Nothing yet' : days < 1 ? 'Less than a day' : 'About ' + Math.round(days) + (Math.round(days) === 1 ? ' day' : ' days') + ' <small>(' + Math.round(bh) + ' h)</small>';
    let h = '<h2 class="sec">Jobs on the go</h2><div class="card jobs41">' + row('Work booked ahead', ahead) + (J.length ? row('Still to be paid for them', mshort(rest)) : '');
    /* jobs being worked on get a bar; jobs waiting their turn get one line each */
    const act = J.filter(j => j.done > 0), wait = J.filter(j => !(j.done > 0));
    const nm = j => esc(capF(j.what)) + ' <small>' + esc(j.client) + '</small>';
    h += act.slice(0, 3).map(j => '<div class="kv"><span>' + nm(j) + '</span><b>' + mshort(j.v) + '</b></div>' + bar(Math.min(100, j.done / j.h * 100), j.delay > 0 ? 'var(--amber)' : 'var(--green)') + '<small class="jl41">' + Math.round(j.done) + ' of ' + j.h + ' h done' + (j.delay > 0 ? ' · held up' : '') + (j.st41 ? ' · paid so far ' + mshort(j.paid) : ' · paid when finished') + '</small>').join('');
    if (wait.length) h += '<small class="jl41 wt41">Waiting their turn</small>' + wait.slice(0, 3).map(j => '<div class="kv"><span>' + nm(j) + ' <small>· ' + j.hq + ' h</small></span><b>' + mshort(j.v) + '</b></div>').join('') + (wait.length > 3 ? '<small class="jl41">+' + (wait.length - 3) + ' more · ' + Math.round(wait.slice(3).reduce((a, j) => a + j.h, 0)) + ' h</small>' : '');
    const F = fm.fin41 || [0, 0, 0];
    h += row('Finished since opening', (fm.done || 0) + ((fm.done || 0) === 1 ? ' job' : ' jobs') + (F[2] ? ' · ' + F[2] + ' big' : ''));
    h += '<small class="jl41 nt41">Short jobs are paid when finished. Big or long jobs pay 30% at the start, 40% halfway and the rest at the end. Business clients pay their invoices within ' + (bd.terms || 4) + ' weeks. You turn requests away when you are booked more than three weeks ahead.</small></div>';
    return h;
  }
  const ov41 = CT.ov;
  CT.ov = function (co, bd) {
    let h = ov41.apply(this, arguments);
    try {
      if (!co || co.st !== 'open' || co.type === 'hold') return h;
      const i = h.indexOf('<h2 class="sec">This week</h2>');
      if (i >= 0) {
        const s = h.indexOf('<div class="card', i), e = blockEnd(h, s);
        h = h.slice(0, i) + (isHT(co) ? weekCardHT(co, bd) : weekCardAll(co, bd)) + h.slice(e);
      }
      /* the money pill: what actually moved this week, so far */
      const c = S.cc41;
      if (c && c.w === S.week && c.start[co.id] != null) {
        const dd = co.cash - c.start[co.id];
        h = h.replace(/<span class="pl [gr]">[+−][^<]*this week<\/span>/, '<span class="pl ' + (dd >= 0 ? 'g' : 'r') + '">' + plus(dd) + ' so far this week</span>');
      }
    } catch (e) { console.error(e); }
    return h;
  };
  const fo41 = CT.famOv;
  if (fo41) CT.famOv = function (co, bd) {
    let h = fo41.apply(this, arguments);
    try {
      /* plain words for the order book of the firms that still use it */
      if (!isHT(co) && h.indexOf('<h3>Order book</h3>') >= 0) {
        const fm = co.fm || {}, wk = fm.backlogWk || 0;
        h = h.replace('<h3>Order book</h3>', '<h3>Jobs on the go</h3>')
          .replace(/<div class="kv[^"]*"><span>Backlog<\/span><b>[^<]*<\/b><\/div>/, row('Booked work not yet paid', mshort(fm.backlog || 0)))
          .replace(/<div class="kv[^"]*"><span>Weeks of work<\/span><b>[^<]*<\/b><\/div>/, row('Booked ahead', !(fm.jobs || []).length || wk >= 50 ? 'Nothing yet' : wk < 0.2 ? 'Less than a day' : 'About ' + (wk < 1.5 ? Math.max(1, Math.round(wk * 5)) + ' days' : Math.round(wk) + ' weeks')))
          .replace(/<div class="kv[^"]*"><span>Jobs won \/ finished<\/span><b>([^<]*) \/ ([^<]*)<\/b><\/div>/, (m, a1, b1) => row('Taken on / delivered', a1 + ' / ' + b1))
          .replace('Too big a backlog turns away new work.', 'Booked too far ahead, new clients go elsewhere.');
      }
      h = h.replace(/(<span>Solvency<\/span><b>)(\d{3,})(\.\d+)? \(needs 1\.0\)/, '$1Very strong (needs 1.0)');
      if (!isHT(co)) return h;
      const i = h.indexOf('<h3>Order book</h3>');
      if (i >= 0) { const s = h.lastIndexOf('<div class="card', i); h = h.slice(0, s) + h.slice(blockEnd(h, s)); }
      if (co.st === 'open') h = jobsCard(co, bd) + h;
    } catch (e) { console.error(e); }
    return h;
  };

  /* turning work away is what actually happened, not a guess from demand */
  const al41 = window.coAlerts;
  window.coAlerts = function (co) {
    let out = al41.apply(this, arguments);
    try {
      if (isHT(co)) {
        out = out.filter(a => a[0] !== 'Turning customers away');
        const w = co.fm && co.fm.wk41;
        if (w && w.lost > 0 && co.st === 'open') out.push(['Turning work away', 'n']);
      }
    } catch (e) { }
    return out;
  };

  /* ================= 7. the week report: money that moved, and money earned ================= */
  const COSTN = { cogs: 'Materials and goods', wages: 'Wages and payroll', rent: 'Rent and power', mkt: 'Marketing', ins: 'Insurance', acc: 'Accounting', dep: 'Depreciation', int: 'Interest', oth: 'Leasing and other costs', fine: 'Fines', loss: 'Refunds and losses' };
  const wr0 = V.weekreport;
  V.weekreport = function () {
    let h = wr0.apply(this, arguments);
    try {
      const L = S.wk31 || [], a = L[L.length - 1], b = L[L.length - 2] || null;
      const i = h.indexOf('<div class="wtiles35');
      if (!a || i < 0) return h;
      const e = blockEnd(h, i);
      const anim = h.indexOf('repanim') >= 0;
      const val = (v, cls) => anim ? '<b class="cnt28 ' + (cls || '') + '" data-to="' + Math.round(v || 0) + '">' + mshort(0) + '</b>' : '<b class="' + (cls || '') + '">' + mshort(v || 0) + '</b>';
      const tile = (k, lab, v, d, cls) => '<button class="card wt35" data-a="fin31" data-p="' + P({ k }) + '"><span>' + lab + '</span>' + val(v, cls) + '<em class="' + (d == null ? '' : sgnC(d)) + '">' + (d == null ? '–' : plus(d)) + '</em></button>';
      const cc = a.cc;
      const tiles = '<div class="wtiles35 n4">' + tile('cash', 'Your cash', a.cash, b ? a.cash - b.cash : null) + (cc ? tile('cc', 'Company cash', cc.tot, cc.ok ? cc.d : null) : tile('sh', 'Shares', a.sh, b ? a.sh - b.sh : null)) + tile('rev', 'Sales', a.rev, b ? a.rev - b.rev : null) + tile('profit', 'Result', a.profit, b ? a.profit - b.profit : null, sgnC(a.profit)) + '</div>' +
        '<button class="wexp41" data-a="fin31" data-p="' + P({ k: 'cc' }) + '">Why company cash and result differ ›</button>';
      h = h.slice(0, i) + tiles + h.slice(e);
    } catch (e) { console.error(e); }
    return h;
  };
  const fin0 = ACT.fin31;
  ACT.fin31 = p => {
    if (!p || p.k !== 'cc') return fin0(p);
    const L = S.wk31 || [], a = L[L.length - 1];
    const cc = a && a.cc;
    let h = '<h2>Company cash</h2>';
    const cos = live().filter(c => c.type !== 'hold' && c.st !== 'setup');
    if (cc && cc.ok) h += cos.map(c => row(esc(c.name), '<b>' + mshort(c.cash) + '</b>' + (cc.per[c.id] != null ? ' <small class="' + sgnC(cc.per[c.id]) + '">' + plus(cc.per[c.id]) + '</small>' : ''))).join('') + row('All companies, change this week', '<span class="' + sgnC(cc.d) + '">' + plus(cc.d) + '</span>', 'total');
    else h += '<span class="tipt">The change shows from your next full week.</span>';
    const wOwed = cos.reduce((s, c) => s + ((c.pay && c.pay.wages) || 0), 0), oOwed = cos.reduce((s, c) => s + ((c.pay && c.pay.other) || 0), 0);
    h += '<h3>Built up, paid later</h3>' + row('Wages and payroll', mshort(wOwed) + ' <small>on payday</small>') + row('Bills: rent, materials, insurance and more', mshort(oOwed) + ' <small>last day of the month</small>');
    if (a) h += row('This week’s result', '<span class="' + sgnC(a.profit) + '">' + plus(a.profit) + '</span>');
    h += '<span class="tipt">Sales are paid in as you work. Costs are counted in the week they belong to, but leave the account on payday and on the last day of the month.</span>';
    openSheet(h + btn('Close', 'sheetclose', undefined, 'ghost wide'));
  };
})();
/* a salmon farm sells nothing for over a year: the start-up money says so */
if (typeof window.setupEstimate === 'function') {
  const se41 = window.setupEstimate;
  window.setupEstimate = function (bdId, o) {
    const r = se41.apply(this, arguments);
    try {
      if (bdId === 'salmon' && !r.grow41) {
        o = o || {};
        const cc = o.country || S.country, add = KC(2300000, cc) * Math.pow(o.size || 1, 0.9) * 0.85 * ((BD.salmon.tw && BD.salmon.tw.grow) || 78);
        r.grow41 = 1;
        r.buffer = rlc((r.buffer || 0) + add, cc);
        r.total = rlc(r.total + add, cc);
        r.capLbl = 'Feed and running costs until the first harvest (about 15 months)';
      }
    } catch (e) { console.error(e); }
    return r;
  };
}
/* plurals that read right: MWh, m²-weeks */
if (typeof unitPl === 'function') {
  const up41 = unitPl;
  unitPl = function (u, n) { if (u === 'MWh') return 'MWh'; if (u === 'm2-week') return Math.abs((n || 0) - 1) < 0.05 ? 'm²-week' : 'm²-weeks'; return up41.apply(this, arguments); };
}
/* insurance premiums read per month, like the bill they end up on */
(function () {
  const CT = window.CT;
  const ins41 = CT && CT.insurance;
  if (!ins41 || typeof INSP === 'undefined') return;
  CT.insurance = function (co, bd) {
    let h = ins41.apply(this, arguments);
    try {
      Object.keys(INSP).forEach(k => {
        const w = insPremium(co, k), a = money(w) + '/wk';
        if (h.indexOf(a) >= 0) h = h.replace(a, money(Math.round(w * 52 / 12)) + '/mo');
      });
    } catch (e) { }
    return h;
  };
})();
/* cash warnings only when they matter: a dip into the overdraft that money already on its way covers is shown,
   not pushed in your face; the pop-up says how deep, what is coming in and what is due, and "leave it" means four weeks */
(function () {
  const U = window.UI;
  if (!U) return;
  const { ui, ACT, esc, row, btn, render, save, toast } = U;
  const DAYN = () => S.week * 7 + (S.day || 0);
  const soon = co => (co.recv || []).filter(r => !r.bad && r.due <= S.week + 2).reduce((a, r) => a + r.a, 0);
  const odOf = co => { try { return Math.max(1, coOverdraft(co)); } catch (e) { return 1; } };
  function cashBad(co) {
    const sn = S.sn41 && S.sn41[co.id];
    if (sn && DAYN() < sn.until && co.cash >= Math.min(sn.cash * 1.5, sn.cash - odOf(co) * 0.25)) return false;
    if (co.cash < -0.5 * odOf(co)) return true;
    const days = co.neg41 != null ? DAYN() - co.neg41 : 0;
    return co.cash < 0 && days >= 7 && co.cash + soon(co) < 0;
  }
  window.R41.cashBad = cashBad;
  const al = window.coAlerts;
  window.coAlerts = function (co) {
    const out = al.apply(this, arguments);
    try {
      out.forEach(a => {
        if (a[0] === 'Negative cash') a[1] = cashBad(co) ? 'bad' : 'warn';
        else if (a[0] === 'Low cash') a[1] = 'warn';
      });
    } catch (e) { }
    return out;
  };
  /* how long a company has been in the red */
  const rd = window.R10DAY;
  window.R10DAY = function (d) {
    const r = rd ? rd.apply(this, arguments) : undefined;
    try { S.cos.forEach(co => { if (co.st !== 'open') return; if (co.cash < 0) { if (co.neg41 == null) co.neg41 = DAYN(); } else co.neg41 = null; }); } catch (e) { }
    return r;
  };
  /* the pop-up itself */
  const sh0 = window.sheet36;
  if (sh0) window.sheet36 = function (sh) {
    try {
      if (sh && sh.cls === 'al30s' && /<h2>Negative cash<\/h2>/.test(sh.html || '')) {
        const m = /data-a="al30later" data-p="([^"]*)"/.exec(sh.html), go = /data-a="al30go" data-p="([^"]*)"/.exec(sh.html);
        const k = m ? JSON.parse(m[1].replace(/&quot;/g, '"')).k : '', co = getCo(+String(k).split(':')[0]) || getCo(String(k).split(':')[0]);
        if (co) {
          const need = Math.max(0, -co.cash) + coWeekCost(co) * 2;
          const mag = Math.pow(10, Math.floor(Math.log10(Math.max(1, need)))), st = [1, 1.5, 2, 2.5, 3, 4, 5, 6, 8, 10].find(x => x * mag >= need) || 10;
          const amt = st * mag;
          let pay = '';
          try { const d = window.R29 && R29.nextPay ? R29.nextPay(co) : null; if (d) pay = d.getUTCDate() + ' ' + MN[d.getUTCMonth()]; } catch (e) { }
          const html = '<div class="al30"><small>' + esc(co.name) + '</small><h2>Negative cash</h2><p class="lead">' + esc(co.name) + ' is ' + mshort(-co.cash) + ' in the red and runs on its overdraft (limit ' + mshort(odOf(co)) + ').</p>' +
            '<div class="card">' + row('Invoices paid to you within two weeks', mshort(soon(co))) + row('Wages building up' + (pay ? ', paid ' + pay : ''), mshort((co.pay && co.pay.wages) || 0)) + row('Bills due on the last day of the month', mshort((co.pay && co.pay.other) || 0)) + '</div>' +
            '<div class="btnrow col">' + btn('Put in ' + mshort(amt) + ' from your cash', 'cash41in', { id: co.id, a: amt, k }, 'wide') + (go ? '<button class="btn wide" data-a="al30go" data-p="' + go[1] + '">See payroll and bills</button>' : '') + btn('Leave it on the overdraft for now', 'al30later', { k }, 'ghost wide') + '</div><span class="tipt">Left alone, it comes back only if it gets clearly worse, or in four weeks.</span></div>';
          sh = Object.assign({}, sh, { html });
        }
      }
    } catch (e) { console.error(e); }
    return sh0.call(this, sh);
  };
  ACT.cash41in = p => {
    const co = getCo(p.id);
    if (!co) return;
    if (!injectCash(co, p.a)) { toast('You do not have ' + mshort(p.a) + ' to put in.', true); return; }
    if (S.al30 && S.al30[p.k]) S.al30[p.k].later = 0;
    ui.sheet = null;
    toast('Put ' + mshort(p.a) + ' into ' + co.name + '.');
    save();
    render();
  };
  /* "leave it" lasts four weeks unless it gets clearly worse */
  const later0 = ACT.al30later;
  ACT.al30later = p => {
    S.al30 = S.al30 || {};
    try {
      if (p && /:Negative cash$/.test(p.k || '')) {
        const id = String(p.k).split(':')[0], co = getCo(+id) || getCo(id);
        if (co) { S.sn41 = S.sn41 || {}; S.sn41[co.id] = { until: DAYN() + 28, cash: co.cash }; }
      }
    } catch (e) { }
    return later0(p);
  };
})();
/* a holding pays its own small costs with dividends from its companies instead of quietly going bankrupt;
   if a holding fails anyway, its companies come back to you instead of disappearing from your net worth */
(function () {
  R7.afterWeek = R7.afterWeek || [];
  R7.afterWeek.push(() => {
    try {
      S.cos.filter(h => h.type === 'hold' && h.st === 'open').forEach(h => {
        const wc = Math.max(KC(1500), coWeekCost(h));
        if (h.cash >= wc * 4) return;
        const need = wc * 13 - h.cash;
        const subs = S.cos.filter(c => c.hold === h.id && c.st === 'open' && c.form === 'AS').sort((a, b) => b.cash - a.cash);
        for (const s of subs) {
          const spare = s.cash - coWeekCost(s) * 6;
          if (spare <= 0) continue;
          const g = need / Math.max(0.01, (s.own || 100) / 100);
          const mag = Math.pow(10, Math.floor(Math.log10(Math.max(1, g)))), amt = Math.min(spare, ([1, 1.5, 2, 2.5, 3, 4, 5, 6, 8, 10].find(x => x * mag >= g) || 10) * mag);
          if (payDividend(s, Math.round(amt)) === 'ok') { note(h.name + ' took a dividend of ' + mshort(amt) + ' from ' + s.name + ' to pay its own costs.', 'n', h.id); break; }
        }
      });
    } catch (e) { console.error(e); }
  });
  if (typeof bankrupt === 'function') {
    const bk41 = bankrupt;
    bankrupt = function (co) {
      const r = bk41.apply(this, arguments);
      try { if (co && co.type === 'hold' && co.st === 'bust') S.cos.forEach(c => { if (c.hold === co.id) { c.hold = null; note(c.name + ' is owned by you directly now.', 'n', c.id); } }); } catch (e) { }
      return r;
    };
  }
})();
/* brand-style names for rivals and franchise brands: "Fjord Building Supplies", not "Fjord Building-supplie" */
if (typeof fbNoun === 'function') {
  const NOUN41 = { cons: 'Consulting', tutor: 'Tutoring', carclean: 'Car Care', photo: 'Photo', handy: 'Handyman', cleaning: 'Cleaning', webdev: 'Digital', mktg: 'Marketing', law: 'Law', acctfirm: 'Accounting', staffing: 'Staffing', barber: 'Hair', drivsk: 'Driving School', physio: 'Physio', estate: 'Estate', pets: 'Pet Care', foodtruck: 'Street Food', cafe: 'Café', restaurant: 'Restaurant', nightclub: 'Club', gym: 'Gym', hotel: 'Hotel', casino: 'Casino', fun: 'Entertainment', kiosk: 'Convenience', boutique: 'Clothing', webshop: 'Online', grocery: 'Supermarket', hardware: 'Building Supplies', cardealer: 'Motors', construction: 'Construction', electrician: 'Electric', plumber: 'Plumbing', realdev: 'Property', event: 'Events', engcons: 'Engineering', bakery: 'Bakery', brewery: 'Brewing', furniture: 'Furniture', salmon: 'Seafood', factory: 'Industries', farm: 'Farms', taxi: 'Taxi', courier: 'Courier', trucking: 'Haulage', shipping: 'Shipping', airline: 'Air', resrent: 'Homes', comrent: 'Properties', parking: 'Parking', insco: 'Insurance', bank: 'Bank', fund: 'Capital', power: 'Power', oilgas: 'Energy' };
  const fbn41 = fbNoun;
  fbNoun = function (id) { return NOUN41[id] || fbn41.apply(this, arguments); };
}

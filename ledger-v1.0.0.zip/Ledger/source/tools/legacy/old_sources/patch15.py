path = '/home/claude/w3/ledger.html'
T = '/home/claude/w3/tools/'
t = open(path, encoding='utf8').read()
mark = '/* ---------- no zooming: pinch, double tap, ctrl+wheel, ctrl +/- ---------- */'
assert t.count(mark) == 1
t = t.replace(mark, open(T + 'round16.js', encoding='utf8').read() + '\n' + open(T + 'round17.js', encoding='utf8').read() + '\n' + open(T + 'round18.js', encoding='utf8').read() + '\n' + open(T + 'round19.js', encoding='utf8').read() + '\n' + open(T + 'round20.js', encoding='utf8').read() + '\n' + open(T + 'round21.js', encoding='utf8').read() + '\n' + open(T + 'round22.js', encoding='utf8').read() + '\n' + open(T + 'round23.js', encoding='utf8').read() + '\n' + open(T + 'round24.js', encoding='utf8').read() + '\n' + open(T + 'round25.js', encoding='utf8').read() + '\n' + open(T + 'round26.js', encoding='utf8').read() + '\n' + ''.join(open(T + f, encoding='utf8').read() + '\n' for f in ['round27a.js', 'round27b.js', 'round27c.js', 'round27d.js', 'round27e.js', 'round28a.js', 'round28b.js', 'round28c.js'] if __import__('os').path.exists(T + f)) + mark)
old = "(0.82 + hrng(S.seed + ':rp:' + r.id)() * 0.4)"
t = t.replace('/ priceMult(co) * ' + old, '/ priceMult(co) * (window.R18 && r.pm16 ? R18.effP(r) : ' + old + ')')
a = "' · reach ~' + planEst(co, bd).toLocaleString('en-US').replace(/,/g, ' ') + (PL.w ? '' : ' per quarter')"
assert t.count(a) == 1
t = t.replace(a, "(window.R19 && R19.planTxt ? R19.planTxt(co, PL) : ' · reach ~' + planEst(co, bd).toLocaleString('en-US').replace(/,/g, ' ') + (PL.w ? '' : ' per quarter'))")

# exchange rates from the USD table: base units (NOK) per local unit = 10.7 / local per USD
t = t.replace('fx: 1.05, /* game base units per 1 SEK */', 'fx: 1.0190476, /* game base units per 1 SEK */')
t = t.replace('fx: 2.6, /* game base units per 1 PLN */', 'fx: 2.675, /* game base units per 1 PLN */')
t = t.replace('fx: 11.7, /* game base units per 1 EUR */', 'fx: 11.6304348, /* game base units per 1 EUR */')
t = t.replace('fx: 13.5, /* game base units per 1 GBP */', 'fx: 13.5443038, /* game base units per 1 GBP */')
t = t.replace('fx: 10.5, /* game base units per 1 USD */', 'fx: 10.7, /* game base units per 1 USD */')
t = t.replace('fx: 7.6, /* game base units per 1 CAD */', 'fx: 7.6428571, /* game base units per 1 CAD */')
t = t.replace('fx: 6.9, /* game base units per 1 AUD */', 'fx: 7.1333333, /* game base units per 1 AUD */')
t = t.replace('fx: 0.072, /* game base units per 1 JPY */', 'fx: 0.0713333, /* game base units per 1 JPY */')
t = t.replace('fx: 0.0078, /* game base units per 1 KRW */', 'fx: 0.0076429, /* game base units per 1 KRW */')
t = t.replace('fx: 1.9, /* game base units per 1 BRL */', 'fx: 1.8448276, /* game base units per 1 BRL */')
a = '  const fit = (FIT[kind] || 0) * m2;\n'
assert t.count(a) == 1
t = t.replace(a, '  const fit = window.R21 ? R21.fitOf(co, kind, m2) : (FIT[kind] || 0) * m2;\n')
a = "let r = buyVeh(co, e.id, e.vo[0], o.vehMode || 'new');"
assert t.count(a) == 1
t = t.replace(a, "let r = buyVeh(co, e.id, e.vo[0], o.vehMode || (window.R22 && R22.vehMode ? R22.vehMode(co, e) : 'new'));")
a = "for (let i = 3; i >= 1 && r !== 'ok'; i--) r = buyProp("
assert t.count(a) == 1
t = t.replace(a, "for (let i = 3; i >= 0 && r !== 'ok'; i--) r = buyProp(")
a = "const dep = v.cost / Math.max(1, (m[3] / 1 / (v.kmY || 60000))) * 0 + v.cost * 0.15 / 52;"
assert t.count(a) == 1
t = t.replace(a, "const dep = v.cost * (window.R23 && R23.vehDep ? R23.vehDep(m) : 0.15) / 52;")
a = "  const base = Math.round(m[1] * infl * cat.f / 1000) * 1000;"
assert t.count(a) == 1, 'vehbase'
t = t.replace(a, "  const base = Math.round(m[1] * infl * cat.f * (window.R23 && R23.vehCtry ? R23.vehCtry(co) : 1) / 1000) * 1000;")
a = "  const fixed = (bd.fixed * size06 + knobFx(co, 'w', 'sum')) * Math.pow(1 + S.econ.infl, S.week / 52);"
assert t.count(a) == 1, 'fixed'
t = t.replace(a, "  const fixed = (bd.fixed * size06 * (window.R23 && R23.fixF ? R23.fixF(co) : 1) + knobFx(co, 'w', 'sum')) * Math.pow(1 + S.econ.infl, S.week / 52);")
a = "    payCo(co, bd.fixed * Math.pow(co.size, 0.6) * 0.5, 'oth');"
assert t.count(a) == 1, 'fixed2'
t = t.replace(a, "    payCo(co, bd.fixed * Math.pow(co.size, 0.6) * 0.5 * (window.R23 && R23.fixF ? R23.fixF(co) : 1), 'oth');")
a = "bot: cp.bot ? cp.bot.label : '', owner: cp.owner };"
assert t.count(a) == 2, 'botobj'
t = t.replace(a, "bot: cp.bot ? cp.bot.label : '', owner: cp.owner, botObj: cp.bot ? { kind: cp.bot.kind, k: cp.bot.k } : null };")
a = "const room = Math.min(equity / tw.capitalReq * 0.45 - fm.book - fm.gb,"
assert t.count(a) == 1, 'bankroom'
t = t.replace(a, "const room = Math.min(equity / tw.capitalReq * 0.85 - fm.book - fm.gb,")
a = "    fm.dep += (depT - fm.dep) * 0.02 + (wholesale ? Math.max(0, fm.book * 0.02) : 0);"
assert t.count(a) == 1, 'bankdep'
t = t.replace(a, "    /* a bank only pays for the deposits it can lend out (plus a liquidity reserve); beyond that it lowers its deposit rate and the money goes elsewhere */\n    const depNeed = Math.max(0, equity) / tw.capitalReq * 0.85 / 0.9 + Math.max(0, equity) * 0.3;\n    fm.dep += (Math.min(depT * (wholesale ? 1.3 : 1), depNeed, wholesale ? fm.book * 1.15 + Math.max(0, equity) * 0.25 + 1e7 : Infinity) - fm.dep) * (wholesale ? 0.05 : 0.02); /* wholesale money comes faster, but is only raised for loans actually made */")
a = "row('Cash buffer (recommended)', nok(est.buffer))"
assert t.count(a) == 1, 'caplbl'
t = t.replace(a, "row(est.capLbl || 'Cash buffer (recommended)', nok(est.buffer))")
a = """  let personalHit = 0;
  S.loans.slice().forEach(l => {
    if (l.co !== co.id) return;
    if (l.guar || co.form === 'ENK') {
      l.co = 0;"""
assert t.count(a) == 1, 'bust1'
t = t.replace(a, """  let personalHit = 0;
  /* secured lenders are paid first from the sale of what the company owns (vehicles, property, equipment);
     only what is left of a guaranteed loan after that lands on the owner */
  let pool = assets;
  S.loans.slice().forEach(l => {
    if (l.co !== co.id) return;
    if (l.guar || co.form === 'ENK') {
      const cut = Math.min(pool, l.bal);
      l.bal -= cut;
      pool -= cut;
      l.co = 0;""")
b = """  let shortfall = Math.max(0, debts - loanBal - assets - cashPart);
  if (co.form === 'ENK') {
    shortfall = Math.max(0, debts - loanBal - assets - cashPart);"""
assert t.count(b) == 1, 'bust2'
t = t.replace(b, """  let shortfall = Math.max(0, debts - loanBal - pool - cashPart);
  if (co.form === 'ENK') {
    shortfall = Math.max(0, debts - loanBal - pool - cashPart);""")
b = """  else if (assets + cashPart > debts - loanBal) {
    const rest = (assets + cashPart) - (debts - loanBal);"""
assert t.count(b) == 1, 'bust3'
t = t.replace(b, """  else if (pool + cashPart > debts - loanBal) {
    const rest = (pool + cashPart) - (debts - loanBal);""")
a = """    else if (d.st === 'ok' && dd[4] > 0 && S.week - d.ok >= 52 && (S.week - d.ok) % 52 === 0) {
      const fee = renewCost(co, id);
      if (co.cash >= fee) {
        payCo(co, fee, 'oth', 'Renewal: ' + dd[0]);
      } else {
        d.st = 'lapsed';
        note(dd[0] + ' lapsed for ' + co.name + ' - renewal not paid.', 'bad', co.id);
      }
    }"""
assert t.count(a) == 1, 'renew'
t = t.replace(a, """    else if (d.st === 'ok' && dd[4] > 0 && S.week - d.ok >= 52 && ((S.week - d.ok) % 52 === 0 || d.due)) {
      /* a renewal that cannot be paid on the day gets four weeks of grace before the licence lapses */
      const fee = renewCost(co, id);
      if (co.cash >= fee) {
        payCo(co, fee, 'oth', 'Renewal: ' + dd[0]);
        d.due = 0;
      } else if ((d.due = (d.due || 0) + 1) > 4) {
        d.st = 'lapsed';
        d.due = 0;
        note(dd[0] + ' lapsed for ' + co.name + ' - renewal not paid.', 'bad', co.id);
      } else if (d.due === 1) note(dd[0] + ' renewal is due at ' + co.name + ' (' + money(fee) + ') but the company is short of cash. It lapses in four weeks if unpaid.', 'bad', co.id);
    }""")
a = "    if (co.st === 'closed') out.push(['Closed for ' + co.closeW + ' wk', 'bad']);"
assert t.count(a) == 1, 'closedfor'
t = t.replace(a, "    if (co.st === 'closed') out.push([co.closeW >= 9000 ? 'Closed until you reopen it' : 'Closed for ' + co.closeW + ' wk', 'bad']);")
import re as _re
for nm in ["name: 'Vehicle loan: ' + m[0],", "name: 'Commercial mortgage',"]:
    k = t.index(nm); e = t.index('guar: 1', k)
    assert e - k < 400, 'guar ' + nm
    t = t[:e] + "guar: co.form === 'AS' ? 0 : 1 /* secured on the asset: a limited company's owner does not sign for it */" + t[e + len('guar: 1'):]
a = "        if (r === 'cash' && !o.vehMode) r = buyVeh(co, e.id, e.vo[0], 'finance');\n        if (r === 'cash' && !o.vehMode) r = buyVeh(co, e.id, e.vo[0], 'lease');"
assert t.count(a) == 1, 'vehfallback'
t = t.replace(a, "        /* a firm that meant to buy used and cannot afford it leases before it takes on a loan for a new vehicle */\n        if (r === 'cash' && !o.vehMode && window.R22 && R22.vehMode && R22.vehMode(co, e) === 'used') r = buyVeh(co, e.id, e.vo[0], 'lease');\n        if (r === 'cash' && !o.vehMode) r = buyVeh(co, e.id, e.vo[0], 'finance');\n        if (r === 'cash' && !o.vehMode) r = buyVeh(co, e.id, e.vo[0], 'lease');")
a = "  const ownerEff = (0.75 + 0.5 * co.oskill / 100) * (co.mgr ? (S.npcs[co.mgr] ? 0.5 + S.npcs[co.mgr].stats.ops / 200 : 1) : 1);"
assert t.count(a) == 1, 'ownerEff'
t = t.replace(a, "  const ownerEff = co.mgr && window.R24 && R24.mgrEff ? R24.mgrEff(co) : (0.75 + 0.5 * co.oskill / 100) * (co.mgr ? (S.npcs[co.mgr] ? 0.5 + S.npcs[co.mgr].stats.ops / 200 : 1) : 1);")
a = "  let of = ownerF * ownerEff;"
assert t.count(a) == 1, 'of'
t = t.replace(a, "  let of = ownerF * ownerEff + (window.R24 && R24.asstFTE ? R24.asstFTE(co, bd) : 0); /* the assistant manager works too */")
a = "row('Brand', brandWord(co.franchise.brand)) + '<p class=\"muted small\">Poor quality can get you a warning"
assert t.count(a) == 1, 'fbcard'
t = t.replace(a, "row('Brand', brandWord(co.franchise.brand)) + (window.R24 && R24.fbCard ? R24.fbCard(co) : '') + '<p class=\"muted small\">Poor quality can get you a warning")
a = "        h += '<div class=\"kv\"><span>' + esc(u.name) + ' · ' + esc(cityOf(u.city).name) + '</span><b class=\"' + sgn(u.prof) + '\">' + mshort(u.rev || 0) + ' /wk</b></div>';"
assert t.count(a) == 1, 'frunit'
t = t.replace(a, "        h += '<div class=\"kv\"><span>' + esc(u.name) + ' · ' + esc(cityOf(u.city).name) + (window.R24 && R24.frUnitRow ? R24.frUnitRow(u) : '') + '</span><b class=\"' + sgn(u.prof) + '\">' + mshort(u.rev || 0) + ' /wk</b>' + btn('End', 'fr24term', { id: co.id, u: u.id }, 'chip ghost danger') + '</div>';")
for a, b in [("  const ops = R * 0.15 / 52;", "  const ops = R * 0.3 / 52; /* stadium, travel, academy, staff: about 30% of revenue in a top-flight club */"),
             ("  const tr = ((fm.coach ? fm.coach.skill : 35) - 55) * R * 0.00025 + gauss() * R * 0.0012;", "  const tr = 0; /* transfers now happen in the transfer windows (round 24) */"),
             ("(fm.asst ? 0 : 3) + (fm.form || 0);", "(fm.asst ? 0 : 3) + (fm.form || 0) + (fm.sq || 0);")]:
    assert t.count(a) == 1, a
    t = t.replace(a, b)
for a, b in [("    ctx.cogs = bbl * 1000 * 300;", "    ctx.cogs = bbl * 1000 * (window.R24 && R24.oilLift ? R24.oilLift() : 300);"),
             ("        const q = f.q0 * Math.exp(-0.0028 * f.age) * modProd(co, 'cap') * (0.8 + 0.2 * crew) * (1 + gauss() * 0.03);", "        const q = f.q0 * Math.exp(-0.0028 * Math.max(0, f.age - (f.plat || 0))) * modProd(co, 'cap') * (0.8 + 0.2 * crew) * (1 + gauss() * 0.03);"),
             ("        const c = f.capex / 156;", "        const c = f.capex / 156;\n        if (window.R24 && R24.oilDevCash) R24.oilDevCash(co, f, c);")]:
    assert t.count(a) == 1, a
    t = t.replace(a, b)
a = "    const int = l.bal * r / 12, prin = Math.min(l.bal, Math.max(0, l.pay - int)), total = int + prin;"
assert t.count(a) == 1, 'grace'
t = t.replace(a, "    const int = l.bal * r / 12, prin = l.graceW && S.week < l.graceW ? 0 : Math.min(l.bal, Math.max(0, l.pay - int)), total = int + prin; /* interest only during a grace period */")
a = "    const demand = Math.max(0, (depT * 0.85 - fm.book) * 0.04 * knobFx(co, 'd')"
assert t.count(a) == 1, 'bankdemand'
t = t.replace(a, "    const demand = Math.max(0, (depT / (wholesale ? 0.7 : 1) * 0.85 - fm.book) * (wholesale ? 0.06 : 0.04) * knobFx(co, 'd')")
a = "  const ask = rnd(base * city * T.ask * (0.55 + skill / 110 + (lie ? 0.05 : 0)) * Math.pow(1 + S.econ.infl, S.week / 52), 100);"
assert t.count(a) == 1, 'candask'
t = t.replace(a, "  const ask = rnd(base * city * T.ask * (0.55 + skill / 110 + (lie ? 0.05 : 0)) * Math.pow(1 + S.econ.infl, S.week / 52) * (window.R24 && R24.paySpread && ROLES[role] ? R24.paySpread(role, (co && co.country) || S.country) : 1), 100);")
for a, b, n in [("coName(bd.fam, city.id)", "coName(bd.fam, city.id, bd.id)", 1), ("coName(bd.fam, st.city)", "coName(bd.fam, st.city, bd.id)", 2)]:
    assert t.count(a) == n, a
    t = t.replace(a, b)
for a, b in [("    'handy'\n  ];\n  function moreRoles", "    'handy',\n    'mktan'\n  ];\n  function moreRoles"),
             ("    cook: 'Better and faster food',\n", "    cook: 'Better and faster food',\n    mktan: 'Measures this company’s market share and reports every month',\n"),
             ("Roles that make sense for this business. HR, analysts and accountants belong at head office.", "Roles that make sense for this business. HR, data analysts and accountants belong at head office; a market analyst works for one company.")]:
    assert t.count(a) == 1, a
    t = t.replace(a, b)
i = t.rindex('</style>')
t = t[:i] + open(T + 'round16.css', encoding='utf8').read() + '\n' + open(T + 'round17.css', encoding='utf8').read() + '\n' + open(T + 'round26.css', encoding='utf8').read() + '\n' + open(T + 'round27.css', encoding='utf8').read() + '\n' + open(T + 'round28.css', encoding='utf8').read() + '\n' + t[i:]
open(path, 'w', encoding='utf8').write(t)
print('patch15 ok')

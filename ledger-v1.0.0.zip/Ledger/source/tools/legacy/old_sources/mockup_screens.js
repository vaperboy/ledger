/* ---- ui/screens/mockup.js ---- */
/* Mockup layout: Home, Companies, Office, Phone, Meetings, Luxury, Start, Game over.
   Main tabs are locked to the screen; only their list area scrolls. Game numbers and actions come from the existing code. */
(function () {
  'use strict';
  const U = window.UI, { ui, V, ACT, esc, nok, sgn, svg, bar, row, btn, card, noteBox, badge, chips, inp, go, tabTo, render, save, openSheet, closeSheet, confirmThen, toast } = U;

  const ini = n => String(n || '?').replace(/[^A-Za-zÀ-ÿ0-9 ]/g, ' ').trim().split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase() || '?';
  const av = (t, cls) => '<span class="av ' + (cls || '') + '">' + esc(t) + '</span>';
  const P = o => esc(JSON.stringify(o));
  const live = () => S.cos.filter(c => c.st !== 'sold' && c.st !== 'bust');
  const plus = n => (n >= 0 ? '+' : '−') + mshort(Math.abs(n));
  const lastProfit = co => co.hist.length ? co.hist[co.hist.length - 1].profit : null;
  const badAlerts = co => coAlerts(co).filter(a => a[1] === 'bad');
  window.meetCount = function () {
    return S ? unreadBadge() : 0;
  };

/* ---------- calendar: days on top of the weekly simulation ---------- */
  const DN = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  function today() {
    return new Date(wDate(S.week).getTime() + (S.day || 0) * 86400000);
  }
  function weekOfYear(d) {
    return Math.floor((d.getTime() - Date.UTC(d.getUTCFullYear(), 0, 1)) / 86400000 / 7) + 1;
  }
  function dayStr(d) {
    return DN[(d.getUTCDay() + 6) % 7] + ' ' + d.getUTCDate() + ' ' + MN[d.getUTCMonth()] + ' ' + d.getUTCFullYear();
  }
  window.todayLabel = function () {
    const d = today();
    return 'Week ' + weekOfYear(d) + ' · ' + dayStr(d);
  };
/* ---------- daily pacing ----------
   The economy is still calculated in weekly steps (the existing simulation, unchanged). Each week's result is then
   paid out in seven equal daily slices, and its messages and news land on random days of that week, so money and
   events arrive every day while the total over a week is exactly what the weekly simulation produced. */
  function stageWeek() {
    const meB = S.cash, coB = {};
    S.cos.forEach(c => {
      coB[c.id] = c.cash;
    });
    const inB = new Set(S.inbox.map(m => m.id)), newsB = new Set(S.news);
    advance('week');
    const rep = Object.assign({}, S.rep, { bw: {}, cos: [], meD: 0, w: S.week });
    S.cos.forEach(c => {
      if (c.st === 'sold' || c.st === 'bust') return;
      const b = c.bk.w || {};
      for (const k in b) rep.bw[k] = (rep.bw[k] || 0) + b[k];
      rep.cos.push({ id: c.id, name: c.name, rev: b.rev || 0, profit: (b.rev || 0) - sumExp(b), units: c.lastW ? c.lastW.units : 0, unit: BD[c.type].unit });
    });
    rep.meD = S.cash - meB;
    if (S.over) {
      S.pend = null;
      S.lastRep = rep;
      return;
    }
    const P = { me: S.cash - meB, co: [], msgs: [], news: [], rep };
    if (P.me) moveCash(ME, -P.me);
    S.cos.forEach(c => {
      if (coB[c.id] == null) return;
      const d = c.cash - coB[c.id];
      c.wkD = d;
      if (d) {
        P.co.push([c.id, d]);
        moveCash(c, -d);
      }
    });
    const R = hrng(S.seed + ':day:' + S.week);
    S.inbox = S.inbox.filter(m => {
      if (inB.has(m.id)) return true;
      P.msgs.push({ m, d: Math.floor(R() * 7) });
      return false;
    });
    S.news = S.news.filter(n => {
      if (newsB.has(n)) return true;
      P.news.push({ n, d: Math.floor(R() * 7) });
      return false;
    });
    S.pend = P;
  }
  function releaseDay(day) {
    const P = S.pend;
    if (!P) return [];
    const part = tot => Math.round(tot * (day + 1) / 7) - Math.round(tot * day / 7);
    const a = part(P.me);
    if (a) moveCash(ME, a);
    P.co.forEach(x => {
      const c = getCo(x[0]), v = part(x[1]);
      if (c && v) moveCash(c, v);
    });
    const got = [];
    P.msgs.filter(x => x.d === day).reverse().forEach(x => {
      S.inbox.unshift(x.m);
      got.push(x.m);
    });
    P.news.filter(x => x.d === day).reverse().forEach(x => S.news.unshift(x.n));
    return got;
  }
  /* one day forward; returns what arrived and, at the end of a week, the report of the week just finished */
  function dayStep() {
    if (S.day == null) S.day = 0;
    if (S.day < 6) {
      S.day++;
      return { got: releaseDay(S.day), done: null };
    }
    const done = S.pend ? S.pend.rep : null;
    S.pend = null;
    S.day = 0;
    stageWeek();
    const got = S.over ? [] : releaseDay(0);
    if (done) S.lastRep = done;
    return { got, done };
  }
  window.dayStep = dayStep;
  const needsYou = m => m.status === 'open' || !m.read;
  function afterDays(r) {
    save();
    if (S.over) {
      render(true);
      return;
    }
    if (r.done && r.done.ev && r.done.ev.length) {
      go('weekreport');
      return;
    }
    render();
    if (r.got.some(m => m.status === 'open') && window.showPop) window.showPop();
  }
  ACT.nextday = () => afterDays(dayStep());
  /* Until needed: skips days until something new needs you (always available) */
  ACT.untilneeded = () => {
    let r = { got: [], done: null }, last = null, hit = false;
    for (let i = 0; i < 26 * 7 && !S.over; i++) {
      r = dayStep();
      if (r.done) last = r.done;
      if (r.got.some(needsYou)) {
        hit = true;
        break;
      }
    }
    r.done = hit ? null : (r.done || last);
    afterDays(r);
  };
  ACT.weekrep = () => go('weekreport');

/* ---------- home ---------- */
  V.home = function () {
    const nw = netWorth(), hist = S.hist.nw;
    const prev = hist.length > 5 ? hist[hist.length - 5] : hist[0];
    const d = nw.total - (prev || 0);
    const cos = live();
    const open = S.inbox.filter(m => m.status === 'open');
    const alertCos = cos.filter(c => badAlerts(c).length);
    const nNeed = open.length + alertCos.length;
    const c0 = CO[S.country] || CC();
    let h = '<header class="hh"><div><small>' + todayLabel() + '</small><h1>' + esc(S.player && S.player.name ? S.player.name : 'Home') + '</h1></div><span class="pill">' + c0.flag + ' ' + esc(c0.name) + '</span></header>';
    if (nNeed) {
      const first = open[0] ? esc(open[0].title) : esc(badAlerts(alertCos[0])[0][0]) + ' · ' + esc(alertCos[0].name);
      const act = nNeed === 1 && open.length === 1 ? ['openmsg', { id: open[0].id }] : nNeed === 1 ? ['go', { n: 'co', p: { id: alertCos[0].id } }] : ['tab', 'meet'];
      h += '<button class="needbar" data-a="' + act[0] + '" data-p="' + P(act[1]) + '"><span><b>' + nNeed + (nNeed > 1 ? ' things need you' : ' thing needs you') + '</b><small>' + first + '</small></span><i>›</i></button>';
    }
    h += '<button class="nwc" data-a="phapp" data-p="' + P({ n: 'stats' }) + '"><span class="lab">Net worth</span><b class="huge">' + nok(nw.total) + '</b><span class="pills"><span class="pl ' + (d >= 0 ? 'g' : 'r') + '">' + (d >= 0 ? '▲ ' : '▼ ') + mshort(Math.abs(d)) + ' last 4 weeks</span>' + (nw.debt > 0 ? '<span class="pl">Debt ' + mshort(nw.debt) + '</span>' : '') + '</span></button>';
    h += '<div class="tri"><button data-a="phapp" data-p="' + P({ n: 'bank' }) + '"><span>Cash</span><b class="' + (S.cash < 0 ? 'neg' : '') + '">' + mshort(S.cash) + '</b></button><button data-a="phapp" data-p="' + P({ n: 'invest' }) + '"><span>Invested</span><b>' + mshort(nw.personal - S.cash + nw.inv + nw.crypto + nw.funds) + '</b></button><button data-a="tab" data-p="cos"><span>Companies</span><b>' + mshort(nw.cos) + '</b></button></div>';
    if (S.cash < 0) h += noteBox('Overdrawn by ' + money(-S.cash) + '. Move money in or sell something.', true);
    if (!cos.length) h += '<button class="banner blue" data-a="go" data-p="' + P({ n: 'newbiz' }) + '"><div><b>Start your first business</b><span>Pick any of ' + BD_ORDER.length + ' business types</span></div><i>＋</i></button><div class="fill"></div>';
    else {
      h += '<div class="sh"><h2 class="sec">Companies</h2><button data-a="tab" data-p="cos">See all</button></div><div class="lrows fill">' + cos.map(co => {
        const lp = lastProfit(co);
        const al = badAlerts(co);
        return '<button class="lrow" data-a="go" data-p="' + P({ n: 'co', p: { id: co.id } }) + '">' + av(ini(co.name)) + '<span class="ctext"><b>' + esc(co.name) + '</b><small>' + (al.length ? '<em class="neg">' + esc(al[0][0]) + '</em>' : (co.mgr && S.npcs[co.mgr] ? esc(S.npcs[co.mgr].name) + ' manages' : co.st === 'setup' ? 'Setting up' : 'You run it')) + '</small></span>' + (co.st === 'setup' ? '<b class="amb">Set up</b>' : lp != null ? '<b class="num ' + sgn(lp) + '">' + plus(lp) + '<small>/mo</small></b>' : '<b class="num">' + mshort(co.cash) + '</b>') + '</button>';
      }).join('') + '</div>';
    }
    if (S.news[0]) h += '<button class="newsline" data-a="phapp" data-p="' + P({ n: 'news' }) + '"><span class="lab">News</span><span>' + esc(S.news[0].t) + '</span></button>';
    h += '<div class="advbar">' + '<button class="btn untl" data-a="untilneeded">Until needed</button><button class="btn primary go" data-a="nextday">Next day ›</button></div>';
    return h;
  };

/* ---------- companies ---------- */
  function coCard2(co) {
    const lp = lastProfit(co);
    const al = coAlerts(co);
    const m = co.mgr && S.npcs[co.mgr];
    const bd = BD[co.type];
    const tag = co.st === 'setup' ? '<span class="badge">Setting up</span>' : co.st === 'closed' ? '<span class="badge red">Closed</span>' : m ? '<span class="badge green">' + esc(m.name.split(' ')[0]) + ' manages</span>' : '<span class="badge blue">You run it</span>';
    let mid = '';
    if (co.st === 'setup') {
      const cl = openChecklist(co), ok = cl.filter(x => x.ok).length;
      mid = bar(cl.length ? ok / cl.length * 100 : 0);
    } else mid = '<div class="duo"><div><span>Last month</span><b class="' + (lp != null ? sgn(lp) : '') + '">' + (lp != null ? plus(lp) : '—') + '</b></div><div><span>' + (m ? 'Cash' : 'Your hours') + '</span><b>' + (m ? mshort(co.cash) : co.ohrs + ' h') + '</b></div></div>';
    const a0 = al.find(a => a[1] !== 'good');
    return '<button class="ccard" data-a="go" data-p="' + P({ n: 'co', p: { id: co.id } }) + '"><div class="cchd">' + av(ini(co.name)) + '<span class="ctext"><b>' + ((co.country && co.country !== S.country && CO[co.country]) ? CO[co.country].flag + ' ' : '') + esc(co.name) + '</b><small>' + esc(bd.n) + ' · ' + esc(cityOf(co.city).name) + '</small></span>' + tag + '</div>' + mid + (a0 ? '<span class="apill ' + (a0[1] === 'bad' ? 'r' : 'a') + '">' + esc(a0[0]) + '</span>' : '') + '</button>';
  }
  V.cos = function () {
    const lv = live(), old = S.cos.filter(c => c.st === 'sold' || c.st === 'bust');
    const f = ui.cof || 'all';
    const mine = c => !c.mgr;
    const attn = c => badAlerts(c).length > 0;
    const list = lv.filter(c => f === 'all' || (f === 'me' && mine(c)) || (f === 'mgr' && c.mgr) || (f === 'attn' && attn(c)));
    const na = lv.filter(attn).length;
    let h = '<header class="hh"><h1>Companies</h1>' + (na ? '<button class="pill amb" data-a="cofilter" data-p="' + P({ v: 'attn' }) + '">' + na + ' need' + (na > 1 ? '' : 's') + ' you</button>' : '') + '</header>';
    if (lv.length) {
      h += '<div class="tri"><div><span>Companies</span><b>' + lv.length + '</b></div><div><span>Total cash</span><b>' + mshort(sum(lv, c => c.cash)) + '</b></div><div><span>Staff</span><b>' + sum(lv, c => c.staff.length + (c.mgr ? 1 : 0)) + '</b></div></div>';
      h += U.ddown([['all', 'All companies · ' + lv.length], ['me', 'Run by me · ' + lv.filter(mine).length], ['mgr', 'Run by manager · ' + lv.filter(c => c.mgr).length], ['attn', 'Needs attention · ' + na]], f, 'cofilter');
      h += '<div class="fill stack2">' + (list.map(coCard2).join('') || '<div class="calm">None in this filter.</div>') + (old.length ? '<h2 class="sec">Closed and failed</h2><div class="lrows">' + old.map(c => '<div class="lrow">' + av(ini(c.name), 'dim') + '<span class="ctext"><b>' + esc(c.name) + '</b><small>' + BD[c.type].n + '</small></span>' + badge(c.st === 'bust' ? 'Bankrupt' : 'Sold or closed', c.st === 'bust' ? 'red' : '') + '</div>').join('') + '</div>' : '') + '</div>';
    } else h += '<div class="fill"><div class="card empty"><h3>No companies yet</h3><p class="lead">Start a business of any kind. You only need the money and the paperwork.</p></div></div>';
    h += '<div class="advbar">' + btn('＋ New company', 'go', { n: 'newbiz' }, 'wide') + '</div>';
    return h;
  };

/* ---------- office (head office tab) ---------- */
  V.titles.hq = 'Office';
  const HQT = [['office', 'Office'], ['group', 'Structure'], ['managers', 'Reviews'], ['suppliers', 'Suppliers'], ['dealroom', 'Deal room']];
  V.hq = function (p) {
    const t = (p && p.t) || ui.hqt || 'office';
    ui.hqt = t;
    const root = ui.tab === 'hq' && !ui.stack.length;
    return (root ? '<header class="hh"><h1>Office</h1>' + (window.crisisCount && window.crisisCount() ? '<button class="pill red" data-a="go" data-p="' + P({ n: 'crisis' }) + '">Crisis · ' + window.crisisCount() + '</button>' : '') + (fbAny() ? '<button class="pill" data-a="go" data-p="' + P({ n: 'franchises' }) + '">Franchises</button>' : '') + '</header>' : '') + '<div class="ptabs">' + HQT.map(x => '<button class="' + (t === x[0] ? 'on' : '') + '" data-a="hqtab" data-p="' + x[0] + '">' + x[1] + '</button>').join('') + '</div><div class="fill">' + (V[t] ? V[t]() : '') + '</div>';
  };
  ACT.hqtab = p => {
    ui.hqt = p;
    ui.view = { n: 'hq', p: { t: p } };
    render(true);
  };

/* ---------- find workers: worker and manager search in one place ---------- */
  const hireV = V.hire, mgrV = V.mgrhire;
  function hireTabs(p, cur) {
    return '<div class="ptabs">' + [['hire', 'Workers'], ['mgrhire', 'Manager']].map(x => '<button class="' + (cur === x[0] ? 'on' : '') + '" data-a="hiretab" data-p="' + P({ v: x[0], id: p.id }) + '">' + x[1] + '</button>').join('') + '</div>';
  }
  V.hire = p => hireTabs(p || {}, 'hire') + hireV(p);
  V.mgrhire = p => hireTabs(p || {}, 'mgrhire') + mgrV(p);
  ACT.hiretab = p => {
    ui.view = { n: p.v, p: { id: p.id } };
    ui.inp = {};
    render(true);
  };
  V.heads = V.heads || {};
  V.heads.hire = V.heads.mgrhire = p => {
    const co = p && p.id && getCo(p.id);
    return { t: 'Find workers', sub: co ? esc(co.name) : '' };
  };

/* ---------- news: headlines and economy only ---------- */
  V.news = function (p) {
    const t = (p && p.t) === 'world' || ui.nt === 'world' ? 'world' : 'news';
    ui.nt = t;
    const head = '<div class="ptabs">' + [['news', 'Headlines'], ['world', 'Economy']].map(x => '<button class="' + (t === x[0] ? 'on' : '') + '" data-a="ntab" data-p="' + x[0] + '">' + x[1] + '</button>').join('') + '</div>';
    if (t === 'world') return head + V.world();
    return head + '<div class="lrows">' + (S.news.slice(0, 40).map(n => '<div class="lrow"><span class="ctext"><b class="wrap">' + esc(n.t) + '</b><small>' + dateStr(n.w) + '</small></span></div>').join('') || '<div class="lrow"><small>Quiet.</small></div>') + '</div>';
  };

/* ---------- phone: every app appears once ---------- */
  const TINT = { g: 'tg', a: 'ta', b: 'tb', r: 'tr', n: 'tn' };
  const APP = {
    bank: ['bank', 'Bank', 'g', ['phapp', { n: 'bank' }]],
    invest: ['invest', 'Investing', 'b', ['phapp', { n: 'invest' }]],
    lux: ['star', 'Luxury', 'a', ['phapp', { n: 'lux' }]],
    news: ['news', 'News', 'n', ['phapp', { n: 'news' }]],
    stats: ['chart', 'Stats', 'n', ['phapp', { n: 'stats' }]],
    settings: ['cog', 'Settings', 'n', ['phapp', { n: 'settings' }]],
    startups: ['rocket', 'Startups', 'a', ['phapp', { n: 'startups' }]],
    tax: ['tax', 'Tax Office', 'a', ['phapp', { n: 'tax' }]],
    newbiz: ['plus', 'New business', 'a', ['go', { n: 'newbiz' }]],
    hire: ['people', 'Find workers', 'b', ['go', { n: 'pickco', p: { to: 'hire', t: 'Find workers' } }]],
    registry: ['doc', 'Registry', 'a', ['phapp', { n: 'registry' }]],
    reviews: ['star', 'Reviews', 'a', ['phapp', { n: 'reviews' }]],
    rivals: ['fire', 'Rivals', 'r', ['phapp', { n: 'rivals' }]],
    clubs: ['fire', 'Football clubs', 'g', ['go', { n: 'clubs' }]]
  };
  const FOLD = {
    business: { n: 'Business', apps: ['newbiz', 'hire', 'registry', 'reviews', 'rivals', 'clubs'] },
    money: { n: 'Finance', apps: ['startups', 'tax'] }
  };
  function appOk(k) {
    if (k === 'clubs') return typeof V.clubs === 'function' && S.cos.some(c => BD[c.type] && BD[c.type].fam === 'club');
    return true;
  }
  function appTile(k) {
    const a = APP[k];
    return '<button class="app2" data-a="' + a[3][0] + '" data-p="' + P(a[3][1]) + '"><span class="tile ' + TINT[a[2]] + '">' + svg(a[0], 24) + '</span><span>' + a[1] + '</span></button>';
  }
  function folderTile(k) {
    const f = FOLD[k];
    return '<button class="app2" data-a="go" data-p="' + P({ n: 'phfolder', p: { f: k } }) + '"><span class="tile fold">' + f.apps.filter(appOk).slice(0, 4).map(x => '<i class="' + TINT[APP[x][2]] + '"></i>').join('') + '</span><span>' + f.n + '</span></button>';
  }
  V.phonehome = function () {
    let h = '<header class="hh"><h1>Phone</h1><small>' + todayLabel().split(' · ')[1] + '</small></header>';
    h += '<div class="pgrid">' + ['bank', 'invest', 'lux', 'news'].map(appTile).join('') + folderTile('business') + folderTile('money') + appTile('stats') + appTile('settings') + '</div>';
    return h;
  };
  V.titles.phfolder = 'Folder';
  V.phfolder = function (p) {
    const f = FOLD[p.f] || FOLD.business;
    return '<div class="pgrid">' + f.apps.filter(appOk).map(appTile).join('') + '</div>';
  };
  V.phtitle = function (ph) {
    if (ph.n === 'phfolder') return { t: (FOLD[ph.p.f] || FOLD.business).n };
    return null;
  };

/* ---------- meetings ---------- */
  V.titles.meetings = 'Meetings';
  V.meetings = function () {
    const t = ui.mtab || 'dec';
    const us = unreadSplit();
    const open = S.inbox.filter(m => m.status === 'open');
    const alertCos = live().filter(c => badAlerts(c).length);
    const nW = open.length + alertCos.length;
    if ((t === 'msgs' || t === 'mail') && ui.thread != null) {
      return U.vhead(ui.thread, '', '', 'threadback') + '<div class="fill thr">' + (t === 'mail' ? V.mail() : V.msgs()) + '</div>';
    }
    let h = '<header class="hh"><h1>Meetings</h1>' + (nW ? '<span class="pill amb">' + nW + ' waiting</span>' : '') + '</header>';
    h += '<div class="ptabs">' + [['dec', 'Waiting', nW], ['msgs', 'Messages', us.msgs], ['mail', 'Email', us.mail], ['meet', 'Meet', 0]].map(x => '<button class="' + (t === x[0] ? 'on' : '') + '" data-a="mtab" data-p="' + x[0] + '">' + x[1] + (x[2] ? ' <b class="cnt">' + x[2] + '</b>' : '') + '</button>').join('') + '</div>';
    if (t === 'msgs') return h + '<div class="fill">' + V.msgs() + '</div>';
    if (t === 'mail') return h + '<div class="fill">' + V.mail() + '</div>';
    if (t === 'meet') return h + '<div class="fill">' + V.meet(ui.mtp || {}) + '</div>';
    h += '<div class="fill">';
    if (alertCos.length) h += '<div class="lrows">' + alertCos.map(co => '<button class="lrow" data-a="go" data-p="' + P({ n: 'co', p: { id: co.id } }) + '">' + av(ini(co.name)) + '<span class="ctext"><b>' + esc(co.name) + '</b><small class="neg">' + badAlerts(co).map(a => esc(a[0])).join(' · ') + '</small></span><i>›</i></button>').join('') + '</div>';
    h += open.map(m => '<div class="dcard">' + window.msgCard(m) + '</div>').join('');
    if (!nW) h += '<div class="calm">Nothing is waiting.</div>';
    const done = S.inbox.filter(m => m.status !== 'open').sort((a, b) => b.w - a.w).slice(0, 6);
    const rep = S.lastRep ? (S.lastRep.ev || []).length || 1 : 0;
    if (done.length || rep) h += '<h2 class="sec">Earlier</h2><div class="lrows">' + (rep ? '<button class="lrow" data-a="weekrep"><span class="ctext"><b>Week report</b><small>' + rep + ' things happened</small></span><i>›</i></button>' : '') + done.map(m => '<button class="lrow" data-a="openmsg" data-p="' + P({ id: m.id }) + '"><span class="ctext"><b>' + esc(m.title) + '</b><small>' + esc(m.from || '') + ' · ' + dateStr(m.w) + '</small></span><b class="pos small">Done</b></button>').join('') + '</div>';
    return h + '</div>';
  };
  ACT.mtab = p => {
    ui.mtab = p;
    ui.thread = null;
    ui.threadCo = null;
    render(true);
  };

/* ---------- luxury: private collection ---------- */
  /* [id, name, detail, price (NOK), upkeep per year (share of price), expected value change per year, swing per year] */
  const LUX = {
    cars: { n: 'Cars', ic: 'truck', items: [
      ['c1', 'Aurelion ES electric saloon', 'Quiet, fast, loses value quickly', 1100000, 0.03, -0.14, 0.04],
      ['c2', 'Brandt 912 GT coupé', 'Everyday supercar', 1600000, 0.03, -0.09, 0.05],
      ['c3', 'Castellan 1963 Spyder roadster', 'Restored, rare, needs a garage', 2200000, 0.025, 0.04, 0.12],
      ['c4', 'Ravenna Tempesta V12', 'Limited run supercar', 4500000, 0.04, -0.05, 0.1],
      ['c5', 'Halvorsen Hyper 99', 'One of 99 built', 28000000, 0.03, 0.03, 0.18]
    ] },
    watches: { n: 'Watches and jewellery', ic: 'star', items: [
      ['w1', 'Montclair Classique dress watch', 'Gold case, leather strap', 180000, 0.01, -0.03, 0.04],
      ['w2', 'Aldrin Marine steel watch', 'Waiting-list model', 260000, 0.01, 0.05, 0.1],
      ['w3', 'Vescovi Rivière diamond necklace', 'Certified stones', 900000, 0.015, 0.01, 0.05],
      ['w4', 'Lemaire Tourbillon No. 7', 'Hand-finished, numbered', 2400000, 0.01, 0.04, 0.12]
    ] },
    art: { n: 'Art and collectibles', ic: 'grad', items: [
      ['a1', 'Oil painting by Mira Halden', 'Emerging artist. Could rise a lot, or not at all', 120000, 0.01, 0.06, 0.3],
      ['a2', 'Captain Polar #1, first issue', 'Graded, sealed comic', 250000, 0.005, 0.06, 0.2],
      ['a3', 'Château Ormel cellar, 120 bottles', 'Fine vintages, stored properly', 600000, 0.02, 0.04, 0.08],
      ['a4', 'Jules Arnaud print set', 'Signed modernist edition', 400000, 0.01, 0.03, 0.1],
      ['a5', 'Canvas by Otto Brehm', 'Blue-chip, museum-grade, insured', 18000000, 0.015, 0.05, 0.14]
    ] },
    yachts: { n: 'Yachts', ic: 'globe', items: [
      ['y1', 'Sundqvist 40 day cruiser', 'Weekends on the water', 5000000, 0.08, -0.08, 0.05],
      ['y2', 'Marenco 80 motor yacht', 'Needs a captain', 38000000, 0.1, -0.07, 0.06],
      ['y3', 'Halcyon 50 m superyacht', 'Full crew all year', 320000000, 0.1, -0.05, 0.08]
    ] },
    jets: { n: 'Private jets', ic: 'rocket', items: [
      ['j1', 'Corvane Light 4 jet', 'Four seats, short trips', 60000000, 0.09, -0.08, 0.05],
      ['j2', 'Aerion Midsize 7 jet', 'Coast to coast', 160000000, 0.09, -0.07, 0.05],
      ['j3', 'Stratos Global 8000 jet', 'Any continent, non-stop', 520000000, 0.08, -0.06, 0.06]
    ] }
  };
  const LUXI = {};
  Object.keys(LUX).forEach(c => LUX[c].items.forEach(x => {
    LUXI[x[0]] = { cat: c, id: x[0], n: x[1], d: x[2], price: x[3], up: x[4], g: x[5], vol: x[6] };
  }));
  const SELL_FEE = 0.08;
  const luxList = () => (S.lux = S.lux || []);
  const luxValue = () => sum(luxList(), x => x.val);
  const luxUpkeep = () => sum(luxList(), x => (LUXI[x.k] ? LUXI[x.k].up : 0) * x.price / 12);
  window.luxValue = luxValue;
  const nw0 = window.netWorth;
  window.netWorth = function () {
    const r = nw0();
    const v = S && S.lux ? luxValue() : 0;
    if (v) {
      r.lux = v;
      r.personal += v;
      r.total += v;
    }
    return r;
  };
  const nextWeek0 = window.nextWeek;
  window.nextWeek = function () {
    const r = nextWeek0.apply(this, arguments);
    try {
      if (S && !S.over && S.lux && S.lux.length) {
        let cost = 0;
        S.lux.forEach(x => {
          const it = LUXI[x.k];
          if (!it) return;
          const z = (hrng(S.seed + ':lux:' + x.id + ':' + S.week)() - 0.5) * 3.4;
          x.val = Math.max(it.price * 0.05, Math.round(x.val * (1 + it.g / 52 + z * it.vol / Math.sqrt(52))));
          cost += it.up * x.price / 52;
        });
        cost = Math.round(cost);
        if (cost > 0) {
          moveCash(ME, -cost);
          logTx(0, -cost, 'Upkeep: private collection');
        }
      }
    } catch (e) { console.error(e); }
    return r;
  };
  V.titles.lux = 'Luxury';
  V.lux = function () {
    const cat = ui.luxc || 'cars';
    const t = ui.luxt || 'shop';
    const mine = luxList();
    let h = '<div class="tri"><div><span>Collection</span><b>' + mshort(luxValue()) + '</b></div><div><span>Upkeep / mo</span><b>' + mshort(luxUpkeep()) + '</b></div><div><span>Items</span><b>' + mine.length + '</b></div></div>';
    h += '<div class="ptabs">' + [['shop', 'Buy'], ['mine', 'My collection']].map(x => '<button class="' + (t === x[0] ? 'on' : '') + '" data-a="luxtab" data-p="' + x[0] + '">' + x[1] + '</button>').join('') + '</div>';
    if (t === 'mine') {
      if (!mine.length) return h + '<div class="calm">Nothing yet. Things you buy show up here.</div>';
      return h + '<div class="lrows">' + mine.map(x => {
        const it = LUXI[x.k] || { n: x.k };
        const ch = x.price ? (x.val - x.price) / x.price : 0;
        return '<div class="lrow"><span class="lic">' + svg(LUX[it.cat] ? LUX[it.cat].ic : 'star', 20) + '</span><span class="ctext"><b>' + esc(it.n) + '</b><small>Bought ' + dateStr(x.w) + ' for ' + mshort(x.price) + '</small></span><span class="rt"><b>' + mshort(x.val) + '</b><small class="' + sgn(ch) + '">' + (ch >= 0 ? '+' : '') + Math.round(ch * 100) + '%</small></span>' + btn('Sell', 'luxsell', { id: x.id }, 'chip') + '</div>';
      }).join('') + '</div>';
    }
    h += U.ddown(Object.keys(LUX).map(k => [k, LUX[k].n]), cat, 'luxcat');
    return h + '<div class="lrows">' + LUX[cat].items.map(x => '<button class="lrow" data-a="luxbuy" data-p="' + P({ k: x[0] }) + '"><span class="ctext"><b>' + esc(x[1]) + '</b><small>' + esc(x[2]) + '</small></span><b class="num">' + mshort(x[3]) + '</b><i>›</i></button>').join('') + '</div>';
  };
  ACT.luxtab = p => {
    ui.luxt = p;
    render(true);
  };
  ACT.luxcat = p => {
    ui.luxc = p.v;
    render(true);
  };
  const trend = g => g >= 0.04 ? 'Usually rises' : g > 0 ? 'Holds its value' : g > -0.06 ? 'Loses some value' : 'Loses value fast';
  ACT.luxbuy = p => {
    const it = LUXI[p.k];
    if (!it) return;
    openSheet('<h2>' + esc(it.n) + '</h2><p class="lead">' + esc(it.d) + '</p>' + row('Price', nok(it.price)) + row('Upkeep, insurance and storage', nok(it.up * it.price / 12) + ' / mo') + row('Value over time', trend(it.g)) + row('Selling costs', Math.round(SELL_FEE * 100) + '% of the value') + '<div class="btnrow">' + btn('Cancel', 'sheetclose', undefined, 'ghost') + btn('Buy for ' + mshort(it.price), 'luxbuygo', { k: it.id }, 'primary') + '</div>');
  };
  ACT.luxbuygo = p => {
    const it = LUXI[p.k];
    if (!it) return;
    if (S.cash < it.price) {
      toast('Not enough cash.', true);
      return;
    }
    moveCash(ME, -it.price);
    logTx(0, -it.price, 'Bought: ' + it.n);
    luxList().push({ id: uid(), k: it.id, price: it.price, val: it.price, w: S.week });
    ui.sheet = null;
    ui.luxt = 'mine';
    save();
    render(true);
    toast('Bought: ' + it.n);
  };
  ACT.luxsell = p => {
    const x = luxList().find(y => y.id === p.id);
    if (!x) return;
    const it = LUXI[x.k] || { n: x.k };
    const get = Math.round(x.val * (1 - SELL_FEE));
    confirmThen('Sell ' + esc(it.n) + '?', 'You receive ' + money(get) + ' after selling costs.', 'Sell', () => {
      S.lux = luxList().filter(y => y.id !== p.id);
      moveCash(ME, get);
      logTx(0, get, 'Sold: ' + it.n);
      save();
      render();
    });
  };

/* ---------- start ---------- */
  function guessCountry() {
    try {
      const ls = (navigator.languages || [navigator.language || '']).join(',');
      const m = ls.match(/-([A-Za-z]{2})\b/g) || [];
      for (let i = 0; i < m.length; i++) {
        let c = m[i].slice(1).toUpperCase();
        if (c === 'GB') c = 'UK';
        if (CO[c]) return c;
      }
      const L = { nb: 'NO', nn: 'NO', no: 'NO', sv: 'SE', pl: 'PL', lt: 'LT', de: 'DE', fr: 'FR', es: 'ES', nl: 'NL', ja: 'JP', ko: 'KR', pt: 'BR' };
      const l = (navigator.language || '').slice(0, 2).toLowerCase();
      if (L[l] && CO[L[l]]) return L[l];
    } catch (e) { }
    return CO.US ? 'US' : CO.UK ? 'UK' : CO_ORDER[0];
  }
  V.start = function () {
    ui.sc = ui.sc || guessCountry();
    const c = CO[ui.sc];
    setCtx({ country: ui.sc });
    ui.inp.name = ui.inp.name == null ? '' : ui.inp.name;
    ui.city = (c.cities.some(x => x.id === ui.city) ? ui.city : c.cities[0].id);
    ui.age = ui.age || U.AGE0;
    const h = '<div class="splash st2"><div>' +
      '<div class="eyebrow">Ledger</div><h1 class="hero">Build companies, hire people, invest.</h1>' +
      '<div class="card">' + inp('name', 'Your name', null, 'text') +
      '<div class="agerow"><span class="lab">Age</span><div class="stp2"><button class="bk" data-a="agestep" data-p="-1" aria-label="Younger">−</button><b>' + ui.age + '</b><button class="bk" data-a="agestep" data-p="1" aria-label="Older">+</button></div></div></div>' +
      '<div class="sh"><span class="lab">Country</span><small>' + CO_ORDER.length + ' to choose from</small></div>' +
      '<div class="cscroll">' + CO_ORDER.map(k => '<button class="cchip' + (k === ui.sc ? ' on' : '') + '" data-a="setcountry" data-p="' + P({ v: k }) + '"><span>' + CO[k].flag + '</span>' + esc(CO[k].name) + '</button>').join('') + '</div>' +
      '<div class="ctry"><span class="ch"><b>' + c.flag + ' ' + esc(c.name) + '</b><span class="pill amb">' + esc(c.cur) + '</span></span><small>Start-up loan ' + nok(c.loan) + ' over ' + c.loanTermM / 12 + ' years.</small>' + U.ddown(c.cities.map(x => [x.id, x.name]), ui.city, 'setcity') + '</div>' +
      '<div class="stbtns">' + btn('Start playing', 'startgame', undefined, 'primary wide go') + btn('Load a saved game', 'loadsheet', undefined, 'ghost wide') + '</div></div></div>';
    setCtx(null);
    return h;
  };
  ACT.agestep = p => {
    ui.age = Math.max(U.AGE0, Math.min(U.AGE1, (ui.age || U.AGE0) + (+p || 0)));
    render();
  };

/* ---------- game over ---------- */
  V.over = function () {
    const o = S.over, nw = netWorth();
    return '<div class="splash st2"><div><div class="eyebrow red">Game over · ' + todayLabel() + '</div><h1 class="hero">' + (o.reason === 'insolvent' ? 'You could not pay your debts and the creditors took everything.' : 'You ran out of money and have no business left to build on.') + '</h1>' +
      '<div class="card"><span class="lab">Final net worth</span><b class="huge ' + sgn(nw.total) + '">' + mshort(nw.total) + '</b></div>' +
      '<div class="tri"><div><span>Weeks played</span><b>' + S.week + '</b></div><div><span>Peak net worth</span><b>' + mshort(S.stats.peak) + '</b></div><div><span>Businesses failed</span><b>' + S.stats.bankrupt + '</b></div></div>' +
      '<div class="stbtns">' + btn('Start a new game', 'newgame', undefined, 'primary wide go') + '</div></div></div>';
  };

/* ---------- week report: full screen ---------- */
  V.titles.weekreport = 'Week report';
  V.heads = V.heads || {};
  V.heads.weekreport = function () {
    const r = S.lastRep;
    const d = r ? (r.nw1 != null ? r.nw1 : netWorth().total) - (r.nw0 || 0) : 0;
    return { t: 'Week report', sub: r ? 'Week of ' + dateStr((r.w || S.week)) : '', right: r ? '<span class="pill ' + (d >= 0 ? 'grn' : 'amb') + '">' + (d >= 0 ? '+' : '−') + mshort(Math.abs(d)) + '</span>' : '' };
  };
  V.weekreport = function () {
    const r = S.lastRep;
    if (!r) return '<div class="calm">The first report arrives at the end of your first full week.</div>';
    const nw = netWorth().total, d = nw - (r.nw0 || 0);
    const b = r.bw || {};
    const lines = [
      ['Revenue, all companies', b.rev || 0, 1],
      ['Wages and charges', b.wages || 0, -1],
      ['Rent, power, materials', (b.rent || 0) + (b.cogs || 0) + (b.oth || 0), -1],
      ['Marketing', b.mkt || 0, -1],
      ['Insurance and accounting', (b.ins || 0) + (b.acc || 0), -1],
      ['Loan interest', b.int || 0, -1],
      ['Fines and losses', (b.fine || 0) + (b.loss || 0), -1]
    ].filter(x => x[1]);
    let h = '<div class="card ovhero"><span class="lab">Net worth</span><b class="huge">' + nok(nw) + '</b><span class="pills"><span class="pl ' + (d >= 0 ? 'g' : 'r') + '">' + (d >= 0 ? '+' : '−') + mshort(Math.abs(d)) + ' vs last week</span></span></div>';
    h += '<h2 class="sec">Money in and out</h2><div class="card">' + (lines.length ? lines.map(x => row(x[0], '<span class="' + (x[2] > 0 ? 'pos' : 'neg') + '">' + (x[2] > 0 ? '+' : '−') + npadL(x[1]) + '</span>')).join('') : '<span class="muted small">No company money moved this week.</span>') + (r.meD ? row('Your private account', '<span class="' + sgn(r.meD) + '">' + (r.meD > 0 ? '+' : '−') + npadL(Math.abs(r.meD)) + '</span>') : '') + '</div>';
    if (r.cos && r.cos.length) h += '<h2 class="sec">Per company</h2><div class="lrows">' + r.cos.map(c => '<button class="lrow" data-a="go" data-p="' + esc(JSON.stringify({ n: 'co', p: { id: c.id } })) + '"><span class="av">' + esc(String(c.name).split(/\s+/).slice(0, 2).map(x => x[0]).join('').toUpperCase()) + '</span><span class="ctext"><b>' + esc(c.name) + '</b><small>' + (Math.round((c.units || 0) * 10) / 10) + ' ' + esc(unitPl(c.unit, c.units || 0)) + ' · revenue ' + mshort(c.rev) + '</small></span><b class="num ' + sgn(c.profit) + '">' + (c.profit >= 0 ? '+' : '−') + mshort(Math.abs(c.profit)) + '</b></button>').join('') + '</div>';
    const ev = r.ev || [];
    if (ev.length) h += '<h2 class="sec">What happened</h2><div class="lrows">' + ev.slice(0, 40).map(e => {
      const co = e.co ? getCo(e.co) : null;
      const tg = e.tone === 'good' ? ['Good', 'green'] : e.tone === 'bad' ? ['Problem', 'red'] : ['Info', ''];
      return '<div class="lrow"><span class="ctext"><b class="wrap">' + esc(e.t) + '</b>' + (co ? '<small>' + esc(co.name) + '</small>' : '') + '</span><span class="badge ' + tg[1] + '">' + tg[0] + '</span></div>';
    }).join('') + '</div>';
    h += '<button class="btn primary wide go repgo' + (ui.repLock ? ' wait' : '') + '" data-a="repdone"' + (ui.repLock ? ' disabled' : '') + '>Continue</button>';
    return ui.repAnim ? '<div class="repanim">' + h + '</div>' : h;
  };

/* ---------- bank: mockup overview; loans and credit keep their existing screens ---------- */
  const bank0 = V.bank;
  V.bank = function () {
    const t = ui.btab || 'acc';
    if (t !== 'acc') return bank0();
    const cos = live().filter(c => c.st !== 'setup' || c.cash);
    const deps = sum(S.inv.deposits, d => d.bal);
    const total = S.cash + S.sav.bal + deps + sum(cos, c => c.cash);
    let h = U.tabsRow([['acc', 'Accounts'], ['loans', 'Loans'], ['credit', 'Credit']], t, 'btab');
    h += '<div class="card ovhero"><span class="lab">Total across all accounts</span><b class="huge">' + nok(total) + '</b><div class="three">' + btn('Transfer', 'trsheet', undefined, 'primary') + btn('Pay', 'btab', { v: 'loans' }) + btn('Invest', 'phapp', { n: 'invest' }) + '</div></div>';
    h += '<h2 class="sec">Accounts</h2><div class="lrows">' +
      '<div class="lrow"><span class="lic">' + svg('coin', 20) + '</span><span class="ctext"><b>Personal</b><small>' + esc(S.player && S.player.name ? S.player.name : 'Current account') + '</small></span><b class="num ' + (S.cash < 0 ? 'neg' : '') + '">' + mshort(S.cash) + '</b></div>' +
      '<button class="lrow" data-a="trsheet" data-p="' + esc(JSON.stringify({ from: 'me', to: 'sav' })) + '"><span class="lic">' + svg('bank', 20) + '</span><span class="ctext"><b>Savings</b><small>' + pc(Math.max(0.005, policy() - 0.012), 1) + ' interest</small></span><b class="num">' + mshort(S.sav.bal) + '</b></button>' +
      '<button class="lrow" data-a="depsheet"><span class="lic">' + svg('doc', 20) + '</span><span class="ctext"><b>Fixed deposits</b><small>' + (S.inv.deposits.length ? S.inv.deposits.length + ' open' : 'Lock money for a better rate') + '</small></span><b class="num">' + mshort(deps) + '</b></button>' +
      cos.map(c => '<button class="lrow" data-a="go" data-p="' + esc(JSON.stringify({ n: 'co', p: { id: c.id, t: 'more' } })) + '"><span class="lic">' + svg('biz', 20) + '</span><span class="ctext"><b>' + esc(c.name) + '</b><small>Business account</small></span><b class="num ' + (c.cash < 0 ? 'neg' : '') + '">' + mshort(c.cash) + '</b></button>').join('') + '</div>';
    const pl = S.loans.filter(l => !l.co);
    if (pl.length) h += '<h2 class="sec">Loan' + (pl.length > 1 ? 's' : '') + '</h2>' + pl.map(l => {
      const base = l.amt0 || (l.name === 'Start-up loan' ? (CO[S.country] || CC()).loan : 0) || l.bal;
      const paid = base > 0 ? Math.max(0, Math.min(1, 1 - l.bal / base)) : 0;
      return '<div class="card"><div class="bhead"><b>' + esc(l.name) + '</b><span class="badge amber">' + pc(loanRate(l), 1) + ' floating</span></div>' + row('Remaining', '<span class="neg">' + nok(l.bal) + '</span>') + row('Next payment', nok(l.pay) + ' · monthly') + bar(paid * 100, 'var(--amber)') + '<div class="two">' + btn('Pay extra', 'repaysheet', { id: l.id }, 'wide') + btn('Borrow more', 'btab', { v: 'loans' }, 'wide') + '</div></div>';
    }).join('');
    h += '<h2 class="sec">Recent</h2><div class="lrows">' + (S.log.length ? S.log.slice(0, 8).map(x => '<div class="lrow"><span class="ctext"><b>' + esc(x.l) + '</b><small>' + dateStr(x.w) + (x.co && getCo(x.co) ? ' · ' + esc(getCo(x.co).name) : '') + '</small></span><b class="num ' + sgn(x.a) + '">' + (x.a > 0 ? '+' : '−') + npadL(Math.abs(x.a)) + '</b></div>').join('') : '<div class="lrow"><small>Nothing yet.</small></div>') + '</div>';
    return h;
  };
  /* transfer between your accounts and into a company */
  function trSheet() {
    const tr = ui.tr = ui.tr || { from: 'me', to: 'sav' };
    const opts = [['me', 'Personal'], ['sav', 'Savings']].concat(live().map(c => ['co:' + c.id, c.name]));
    const pick = (k, lab) => '<div class="lab">' + lab + '</div><div class="chips">' + opts.filter(o => k === 'from' ? o[0] === 'me' || o[0] === 'sav' : o[0] !== tr.from).map(o => btn(esc(o[1]), 'trset', { k: k, v: o[0] }, 'chip' + (tr[k] === o[0] ? ' primary' : ''))).join('') + '</div>';
    const toCo = tr.to.indexOf('co:') === 0;
    openSheet('<h2>Transfer</h2>' + pick('from', 'From') + pick('to', 'To') + inp('tamt', 'Amount') + U.quick('tamt', [10000, 50000, 100000, 500000]) +
      (toCo ? '<p class="muted small">Money you put into a company is recorded as share capital from you.</p>' : '') +
      '<p class="muted small">To take money out of a company, open the company and use Move money.</p><div class="btnrow">' + btn('Cancel', 'sheetclose', undefined, 'ghost') + btn('Send', 'trgo', undefined, 'primary') + '</div>');
  }
  ACT.trsheet = p => {
    ui.tr = Object.assign({ from: 'me', to: 'sav' }, ui.tr || {}, p && typeof p === 'object' ? p : {});
    trSheet();
  };
  ACT.trset = p => {
    ui.tr[p.k] = p.v;
    if (ui.tr.from === ui.tr.to) ui.tr.to = ui.tr.from === 'me' ? 'sav' : 'me';
    if (ui.tr.from === 'sav' && ui.tr.to.indexOf('co:') === 0) ui.tr.to = 'me';
    trSheet();
  };
  ACT.trgo = () => {
    const tr = ui.tr || {}, a = Math.round(U.inum('tamt', 0));
    if (!(a > 0)) {
      toast('Enter an amount.', true);
      return;
    }
    let ok = false;
    if (tr.from === 'me' && tr.to === 'sav') ok = saveMove(a);
    else if (tr.from === 'sav' && tr.to === 'me') ok = saveMove(-a);
    else if (tr.from === 'me' && tr.to.indexOf('co:') === 0) {
      const co = getCo(isNaN(+tr.to.slice(3)) ? tr.to.slice(3) : +tr.to.slice(3)) || live().find(c => String(c.id) === tr.to.slice(3));
      ok = co ? injectCash(co, a) : false;
    }
    if (!ok) {
      toast('Not enough money for that transfer.', true);
      return;
    }
    ui.inp.tamt = '';
    ui.sheet = null;
    save();
    render();
    toast('Sent ' + money(a) + '.');
  };
  ACT.depsheet = () => {
    openSheet('<h2>Fixed deposits</h2><p class="muted small">Lock money for a better rate. You cannot touch it until it matures.</p>' + (S.inv.deposits.length ? '<div class="card">' + S.inv.deposits.map(d => row(money(d.bal) + ' at ' + pc(d.rate, 2), 'matures ' + dateStr(d.wEnd))).join('') + '</div>' : '') + inp('damt', 'Amount') + '<div class="chips">' + [13, 26, 52].map(w => '<button class="btn chip" data-a="depgo" data-p="' + w + '">' + w + ' weeks · ' + pc(Math.max(0.01, policy() - 0.002 + w / 52 * 0.004), 2) + '</button>').join('') + '</div>' + btn('Close', 'sheetclose', undefined, 'ghost wide'));
  };
  ACT.depgo = w => {
    ui.sheet = null;
    ACT.opendep(w);
  };

/* ---------- tax: mockup summary on top, existing details below ---------- */
  const tax0 = V.tax;
  V.tax = function () {
    const t = S.tax, est = personalTaxEstimate();
    let w = S.week;
    while (!isYearEnd(w)) w++;
    const left = w - S.week + 1;
    const body = tax0().replace(/^<div class="trio">[\s\S]*?<\/div><\/div><\/div>/, '');
    return '<div class="card ovhero"><span class="lab">Tax due this year</span><b class="huge">' + nok(est) + '</b><span class="pills"><span class="pl a">Assessment in ' + left + ' wk</span><span class="pl">Withheld ' + mshort(t.withheld || 0) + '</span></span></div>' + body;
  };

/* ---------- interviews: keep the salary talk as chat bubbles ---------- */
  const offer0 = ACT.offer;
  ACT.offer = p => {
    const n = S.npcs[p.n];
    if (!n) return offer0(p);
    const w = Math.round(U.inum('w' + n.id, n.ask) / 100) * 100;
    const L = ((ui.talk = ui.talk || {})[n.id] = (ui.talk || {})[n.id] || []);
    L.push({ me: 1, t: 'I can offer ' + money(w) + ' a month.' });
    offer0(p);
    if (n.hired) L.push({ me: 0, t: 'Deal. I can start right away.' });
    else {
      L.push({ me: 0, t: w < n.ask ? 'That is below what I asked. Could you come closer to ' + money(n.ask) + '?' : 'I need to think about the terms.' });
      render();
    }
  };

/* ---------- 1B: salary talk has a patience meter ---------- */
  const offer1 = ACT.offer;
  ACT.offer = p => {
    const n = S.npcs[p.n];
    if (!n) return offer1(p);
    if (n.pat == null) n.pat = n.pers === 'driven' ? 2 : n.pers === 'loyal' || n.pers === 'steady' ? 4 : 3;
    if (n.gone) {
      toast(n.name + ' has taken another job.', true);
      return;
    }
    const w = Math.round(U.inum('w' + n.id, n.ask) / 100) * 100;
    offer1(p);
    if (n.hired) return;
    n.pat -= w < n.ask * 0.9 ? 2 : 1;
    const L = ui.talk && ui.talk[n.id];
    if (n.pat <= 0) {
      n.gone = 1;
      if (L) L.push({ me: 0, t: 'I have accepted another offer. Good luck.' });
      ui.cand = null;
      toast(n.name + ' is no longer interested.', true);
    }
    render();
  };
  window.patDots = n => {
    const max = n.pers === 'driven' ? 2 : n.pers === 'loyal' || n.pers === 'steady' ? 4 : 3;
    const left = n.pat == null ? max : Math.max(0, n.pat);
    return '<span class="pdots">' + Array.from({ length: max }, (x, i) => '<i class="' + (i < left ? 'on' : '') + '"></i>').join('') + '</span>';
  };

/* ---------- 6B: the manager follows a focus and explains the plan by text ---------- */
  const FOCUS_ACT = window.FOCUS_ACT = {
    price_up: 'raise prices a little',
    price_down: 'lower prices a little',
    hire: 'hire one more person',
    cut: 'trim staff costs',
    mkt_more: 'spend more on marketing',
    mkt_less: 'cut weak marketing',
    quality: 'step up maintenance and quality',
    save: 'reduce running costs'
  };
  const FOCUS_N = { profit: 'Profit', growth: 'Growth', quality: 'Quality' };
  function planFor(co, focus, skip) {
    const w = co.lastW || {}, util = w.util || 0;
    const mk = Object.keys(co.mkt || {}).filter(k => co.mkt[k] && co.mkt[k].b).length;
    const std = stdStaff(BD[co.type], co.size || 1);
    const short = std.some(x => co.staff.filter(s => s.role === x[0] && !s.notice).length < x[1]);
    const c = [];
    const add = (k, why, ok) => {
      if (ok && c.every(x => x[0] !== k)) c.push([k, why]);
    };
    if (focus === 'profit') {
      add('price_up', 'we are busy most days, so a small price rise costs few customers', util > 0.85 && co.price < 2);
      add('mkt_less', 'some of the ad money is not bringing customers back', mk > 0 && co.aware > 55);
      add('save', 'upkeep is higher than the business needs right now', co.maint > 1);
      add('cut', 'we have more people than work', util < 0.5 && co.staff.length > 1);
      add('price_up', 'our prices are below what the market pays', co.price < 0);
      add('save', 'every small saving goes straight to profit', co.maint > 0);
    } else if (focus === 'growth') {
      add('hire', 'we turn customers away for lack of hands', util > 0.9 || short);
      add('mkt_more', 'more people need to know about us', co.aware < 60);
      add('price_down', 'demand is soft and a lower price wins customers', util < 0.6 && co.price > -2);
      add('mkt_more', 'growth comes from new customers', true);
    } else {
      add('quality', 'better upkeep means fewer breakdowns and happier customers', co.maint < 2);
      add('hire', 'the team is stretched and quality slips when we rush', util > 0.95 || short);
      add('price_up', 'better quality lets us charge a little more', co.maint >= 2 && co.price < 1);
    }
    const q = mgrQual(co);
    let list = c.filter(x => !skip || skip.indexOf(x[0]) < 0);
    if (q < 0.45 && list.length > 1 && chance(0.35)) list = list.slice(1).concat(list.slice(0, 1));
    return list.slice(0, 2);
  }
  function planText(co, plan) {
    return plan.length ? 'For ' + co.name + ' I would ' + plan.map((x, i) => (i ? 'then ' : '') + FOCUS_ACT[x[0]] + ', because ' + x[1]).join('; ') + '.' : 'Honestly, I would not change anything at ' + co.name + ' right now.';
  }
  function sendPlan(co, focus, plan, alt) {
    const n = S.npcs[co.mgr];
    addMsg({
      kind: 'ask',
      from: n.name,
      role: titleFor(co, 'mgr'),
      title: (alt ? 'Another idea' : 'My plan') + ': ' + FOCUS_N[focus],
      body: planText(co, plan),
      co: co.id,
      opts: [{ l: 'Sounds smart', d: 'Go ahead', fx: {} }, { l: alt ? 'Keep the first plan' : 'Let us discuss', d: '', fx: {} }],
      act: 'focusplan',
      data: { id: co.id, focus, plan: plan.map(x => x[0]), alt: alt ? 1 : 0, first: co.focusDraft || null },
      exp: S.week + 2
    });
  }
  ACT.setfocus = p => {
    const co = getCo(p.id);
    if (!co || !co.mgr || !S.npcs[co.mgr]) return;
    co.focus = p.v;
    const plan = planFor(co, p.v);
    co.focusDraft = plan.map(x => x[0]);
    sendPlan(co, p.v, plan, false);
    save();
    render();
  };
  function runStep(co, k) {
    const ids = new Set(S.inbox.map(m => m.id));
    co.askW = null;
    askManager(co, k);
    const said = S.inbox.filter(m => !ids.has(m.id));
    S.inbox = S.inbox.filter(m => ids.has(m.id));
    return said.length ? said[0].body : '';
  }
  ACTS.focusplan = (m, idx) => {
    const co = getCo(m.data.id);
    if (!co || !co.mgr || !S.npcs[co.mgr]) return true;
    const n = S.npcs[co.mgr];
    if (idx === 0 || m.data.alt) {
      const plan = idx === 0 ? m.data.plan : (m.data.first || []);
      co.focusPlan = plan.slice();
      co.focusW = S.week;
      const said = plan.length ? runStep(co, plan[0]) : '';
      if (plan.length) co.focusPlan.shift();
      addMsg({ kind: 'info', from: n.name, role: titleFor(co, 'mgr'), title: 'Re: ' + FOCUS_N[m.data.focus], body: (plan.length ? 'Good. ' + said + (co.focusPlan.length ? ' Next I will ' + FOCUS_ACT[co.focusPlan[0]] + '.' : '') : 'Then we keep things as they are.'), co: co.id, tone: 'n', status: 'done' });
      return true;
    }
    const alt = planFor(co, m.data.focus, m.data.plan);
    sendPlan(co, m.data.focus, alt, true);
    return true;
  };
  /* every four weeks the manager carries out the next step, and re-plans when a step is done */
  function focusWeek() {
    S.cos.forEach(co => {
      if (!co.focus || !co.mgr || !S.npcs[co.mgr] || co.st !== 'open') return;
      if (S.week - (co.focusW || 0) < 4) return;
      co.focusW = S.week;
      if (!co.focusPlan || !co.focusPlan.length) co.focusPlan = planFor(co, co.focus).map(x => x[0]);
      const k = co.focusPlan.shift();
      if (!k) return;
      const said = runStep(co, k);
      if (said) note(S.npcs[co.mgr].name + ' (' + FOCUS_N[co.focus] + '): ' + said, 'n', co.id);
    });
  }

/* ---------- 13A: long, strong service earns better titles ---------- */
  function titleWeek() {
    if (S.week % 4 !== 1) return;
    S.cos.forEach(co => {
      if (co.st !== 'open') return;
      co.staff.forEach(s => {
        const n = S.npcs[s.id];
        if (!n || s.flag || s.notice) return;
        const ten = S.week - (s.w0 || S.week);
        if (ten < 156 || staffSkill(s) < 72) return;
        if (s.titleW && S.week - s.titleW < 52) return;
        const lad = ladderFor(co, s);
        if (!lad || !lad.length) return;
        const to = lad[0];
        s.titleW = S.week;
        const mn = co.mgr && S.npcs[co.mgr];
        addMsg({
          kind: 'ask',
          from: mn ? mn.name : n.name,
          role: mn ? titleFor(co, 'mgr') : ROLES[s.role][0],
          title: 'Promotion: ' + n.name + ' at ' + co.name,
          body: (mn ? n.name + ' has ' + Math.floor(ten / 52) + ' years here with strong results and deserves a step up to ' : 'After ' + Math.floor(ten / 52) + ' years of good work I would like a step up to ') + esc(ROLES[to] ? ROLES[to][0] : to) + '.',
          co: co.id,
          opts: [{ l: 'Promote', d: 'Better title and pay', fx: {} }, { l: 'Not now', d: 'May lower motivation', fx: {} }],
          act: 'titleask',
          data: { id: co.id, sid: s.id, role: to },
          exp: S.week + 3
        });
      });
    });
  }
  ACTS.titleask = (m, idx) => {
    const co = getCo(m.data.id);
    if (!co) return true;
    if (idx === 0) {
      const r = promoteStaff(co, m.data.sid, m.data.role);
      if (r && r !== 'ok' && r !== true) note('The promotion could not go through: ' + r, 'n', co.id);
    } else {
      const s = co.staff.find(x => x.id === m.data.sid);
      if (s) s.happy = 0;
    }
    return true;
  };
  const nextWeek1 = window.nextWeek;
  window.nextWeek = function () {
    const r = nextWeek1.apply(this, arguments);
    try {
      if (S && !S.over) {
        focusWeek();
        titleWeek();
      }
    } catch (e) {
      console.error(e);
    }
    return r;
  };

/* ---------- staff card stays open while you work on it ---------- */
  document.addEventListener('toggle', e => {
    const d = e.target;
    if (!d || !d.classList || !d.classList.contains('srow')) return;
    const sid = d.getAttribute('data-sid');
    if (d.open) ui.openStaff = sid;
    else if (String(ui.openStaff) === sid) ui.openStaff = null;
  }, true);

/* ---------- 14B: the week report opens every week, Until needed sums the skipped weeks ---------- */
  function mergeReps(list) {
    if (list.length === 1) return list[0];
    const o = { ev: [], bw: {}, cos: [], meD: 0, nw0: list[0].nw0, w: list[list.length - 1].w, weeks: list.length };
    const byCo = {};
    list.forEach(r => {
      o.ev = o.ev.concat(r.ev || []);
      o.meD += r.meD || 0;
      for (const k in r.bw || {}) o.bw[k] = (o.bw[k] || 0) + r.bw[k];
      (r.cos || []).forEach(c => {
        const x = byCo[c.id] || (byCo[c.id] = { id: c.id, name: c.name, rev: 0, profit: 0, units: 0, unit: c.unit });
        x.rev += c.rev;
        x.profit += c.profit;
        x.units += c.units || 0;
      });
    });
    o.cos = Object.keys(byCo).map(k => byCo[k]);
    return o;
  }
  function showWeekReport() {
    ui.repLock = Date.now();
    ui.repAnim = 1;
    go('weekreport');
    setTimeout(() => {
      ui.repLock = 0;
      const b = document.querySelector('.repgo');
      if (b) {
        b.disabled = false;
        b.classList.remove('wait');
      }
    }, 1400);
  }
  ACT.nextday = () => {
    if (ui.repLock) return;
    const r = dayStep();
    save();
    if (S.over) return render(true);
    if (r.done) {
      showWeekReport();
      return;
    }
    render();
    if (r.got.some(m => m.status === 'open') && window.showPop) window.showPop();
  };
  ACT.untilneeded = () => {
    if (ui.repLock) return;
    const reps = [];
    let hit = false;
    for (let i = 0; i < 26 * 7 && !S.over; i++) {
      const r = dayStep();
      if (r.done) reps.push(r.done);
      if (r.got.some(m => m.status === 'open' || !m.read)) {
        hit = true;
        break;
      }
    }
    if (reps.length) S.lastRep = mergeReps(reps);
    ui.popAfterRep = hit;
    save();
    if (S.over) return render(true);
    if (reps.length) {
      showWeekReport();
      return;
    }
    render();
    if (hit && window.showPop) window.showPop();
  };
  ACT.repdone = () => {
    if (ui.repLock) return;
    ui.repAnim = 0;
    U.back();
    if (window.showPop) window.showPop(true);
  };

/* ---------- pop-ups never scroll: overflowing content is split into pages ---------- */
  let fitting = false;
  function fitSheet() {
    const sh = document.querySelector('#app .sheet');
    if (!sh || fitting) return;
    fitting = true;
    try {
      const kids = Array.prototype.slice.call(sh.children).filter(x => !x.classList.contains('pager'));
      kids.forEach(x => {
        x.style.display = '';
      });
      const old = sh.querySelector('.pager');
      if (old) old.remove();
      sh.style.overflowY = 'hidden';
      if (sh.scrollHeight <= sh.clientHeight + 2) return;
      const head = kids[0] && kids[0].tagName === 'H2' ? kids[0] : null;
      const lastBtn = kids[kids.length - 1];
      const foot = lastBtn && lastBtn !== head && (lastBtn.classList.contains('btnrow') || lastBtn.classList.contains('btn') || (lastBtn.classList.contains('chips') && lastBtn.querySelector('.btn.primary'))) ? lastBtn : null;
      const body = kids.filter(x => x !== head && x !== foot);
      const cs = getComputedStyle(sh);
      const gap = parseFloat(cs.rowGap || cs.gap) || 8;
      const room = sh.clientHeight - parseFloat(cs.paddingTop) - parseFloat(cs.paddingBottom) - (head ? head.offsetHeight + gap : 0) - (foot ? foot.offsetHeight + gap : 0) - 52;
      const pages = [[]];
      let used = 0;
      body.forEach(x => {
        const hgt = x.offsetHeight + gap;
        if (pages[pages.length - 1].length && used + hgt > room) {
          pages.push([]);
          used = 0;
        }
        pages[pages.length - 1].push(x);
        used += hgt;
      });
      if (pages.length < 2) return;
      const key = (ui.sheet && ui.sheet.html || '').length;
      if (ui.pgKey !== key) {
        ui.pgKey = key;
        ui.pg = 0;
      }
      const pg = Math.min(ui.pg || 0, pages.length - 1);
      pages.forEach((p, i) => p.forEach(x => {
        x.style.display = i === pg ? '' : 'none';
      }));
      const nav = document.createElement('div');
      nav.className = 'pager';
      nav.innerHTML = '<button type="button" class="btn chip" ' + (pg ? '' : 'disabled') + '>‹ Back</button><span>' + (pg + 1) + ' / ' + pages.length + '</span><button type="button" class="btn chip primary" ' + (pg < pages.length - 1 ? '' : 'disabled') + '>Next ›</button>';
      const b = nav.querySelectorAll('button');
      b[0].onclick = ev => {
        ev.stopPropagation();
        ui.pg = Math.max(0, pg - 1);
        fitting = false;
        fitSheet();
      };
      b[1].onclick = ev => {
        ev.stopPropagation();
        ui.pg = Math.min(pages.length - 1, pg + 1);
        fitting = false;
        fitSheet();
      };
      if (foot) sh.insertBefore(nav, foot); else sh.appendChild(nav);
    } finally {
      fitting = false;
    }
  }
  new MutationObserver(() => {
    if (!fitting) requestAnimationFrame(fitSheet);
  }).observe(document.getElementById('app') || document.body, { childList: true });

/* ===== Round 5a: manager search by type, interviews, moving managers, meetings with real proposals ===== */
  const fmtPct = x => (x % 1 ? x.toFixed(1) : String(x));
  const pctTxt = x => (x >= 0 ? '+' : '−') + Math.abs(Math.round(x * 100)) + '%';
  const capF = s => String(s || '').replace(/^./, c => c.toUpperCase());
  const MT_TIER = { young: 'Early career', mid: 'Mid-career', senior: 'Senior' };
  function typeFit(co, t) {
    const bd = BD[co.type];
    return t === bd.mgr ? 1 : t === 'gen' ? 0.85 : (MGR_FIT[t] || 0.6) * 0.9;
  }
  ACT.mtypeset = p => {
    ui.mtype = ui.mtype || {};
    ui.mtype[p.id] = p.v;
    render();
  };
  ACT.mgrsearch = p => {
    const co = getCo(p.id), bd = BD[co.type];
    const t = (ui.mtype && ui.mtype[co.id]) || bd.mgr;
    if (co.cash < KC(15000) && liquid() < KC(15000)) {
      toast('Not enough cash for the search.', true);
      return;
    }
    payCo(co, KC(15000), 'oth', 'Executive search');
    ui.mgrC = ui.mgrC || {};
    ui.mgrC[co.id] = [genManager(co, t).id, genManager(co, t).id, genManager(co, t).id, genManager(co, t === bd.mgr ? 'gen' : bd.mgr).id];
    ui.mcand = null;
    save();
    render();
  };
  function mgrStyle(n) {
    const q = n.q || {};
    if (Object.keys(q).length < 2) return null;
    const v = k => (q[k] != null ? q[k] : 55);
    return [
      ['Hiring', v('people') >= 70 && v('sales') >= 60 ? 'Quick' : v('ops') >= 65 ? 'Measured' : 'Slow'],
      ['Spending', v('fin') >= 68 ? 'Careful' : v('fin') < 45 ? 'Loose' : 'Balanced'],
      ['Pricing', v('sales') >= 72 ? 'Pushes prices up' : v('fin') >= 65 ? 'Holds prices' : 'Discounts to win'],
      ['Rules', v('risk') >= 65 ? 'By the book' : v('risk') < 45 ? 'Cuts corners' : 'Pragmatic']
    ];
  }
  function mgrRow(co, n) {
    const fit = Math.round(typeFit(co, n.mtype) * 100);
    const tags = [[MGR_TYPES[n.mtype] || 'Manager', ''], ['Fit ' + fit + '%', fit >= 90 ? 'green' : fit >= 70 ? 'amber' : 'red']];
    if (n.exp < 3) tags.push(['Inexperienced', 'amber']);
    if (n.ref) tags.push(['References checked', 'green']);
    else tags.push(['Claims unverified', 'amber']);
    return '<button class="ccard" data-a="mcandopen" data-p="' + P({ n: n.id }) + '"><div class="cchd">' + av(ini(n.name)) + '<span class="ctext"><b>' + esc(n.name) + ', ' + n.age + '</b><small>' + esc(MT_TIER[n.tier] || '') + ' · ' + n.exp + ' yr experience</small></span><span class="badge blue">Asks ' + mshort(n.ask) + '</span></div><div class="chips">' + tags.map(x => '<span class="badge ' + x[1] + '">' + esc(x[0]) + '</span>').join('') + '</div></button>';
  }
  function mgrDetail(co, bd, n) {
    n.qLeft = n.qLeft == null ? 3 : n.qLeft;
    const k = 'm' + n.id;
    const st = mgrStyle(n);
    let h = '<div class="vh"><button class="bk" data-a="mcandback" aria-label="Back">‹</button><div class="vht"><h1>' + esc(n.name) + ', ' + n.age + '</h1><p>' + esc(MGR_TYPES[n.mtype] || 'Manager') + ' candidate · ' + n.exp + ' years</p></div></div>';
    h += '<div class="card">' + row('Last job', esc(n.resume)) + row('Asks', money(n.ask) + ' / month') + row('Style', st ? esc(st[0][1] + ' hiring, ' + st[1][1].toLowerCase() + ' spending') : '<span class="amb">Unknown until you ask</span>') + row('Fit for ' + esc(bd.n), Math.round(typeFit(co, n.mtype) * 100) + '%') + '</div>';
    const asked = MQ.filter(x => n.q && n.q[x[0]] != null);
    const left = MQ.filter(x => !(n.q && n.q[x[0]] != null));
    h += '<div class="sh"><h2 class="sec">Ask a question</h2><small>' + n.qLeft + ' left</small></div>';
    if (n.qLeft > 0) h += '<div class="chips">' + left.map(x => '<button class="btn chip" data-a="mgrask" data-p="' + P({ n: n.id, k: x[0] }) + '">' + esc(QTXT[x[0]][0].replace(/[“”]/g, '')) + '</button>').join('') + '</div>';
    if (asked.length) h += '<div class="chat">' + asked.slice(-2).map(x => '<div class="bub me">' + esc(QTXT[x[0]][0].replace(/[“”]/g, '')) + '</div><div class="bub them">' + esc(answerText(x[0], n.q[x[0]])) + '</div>').join('') + '</div>';
    if (st) h += '<div class="card sense"><b>What the answers suggest</b>' + st.map(x => row(x[0], x[1])).join('') + '</div>';
    h += '<div class="card"><div class="kv"><span>Salary offer / month</span>' + inp(k, '', n.ask) + '</div><div class="chips">' + [0.95, 1, 1.1].map(f => '<button class="btn chip" data-a="setinp" data-p="' + P({ k: k, v: Math.round(n.ask * f / 500) * 500 }) + '">' + Math.round(f * 100) + '%</button>').join('') + (n.ref ? '' : btn('References · ' + mshort(KC(2500)), 'mgrref', { id: co.id, n: n.id }, 'chip')) + '</div></div>';
    h += '<div class="two">' + btn('Pass', 'mcandback', undefined, 'wide') + btn('Hire', 'mgrhirego', { id: co.id, n: n.id }, 'primary wide') + '</div>';
    return h;
  }
  V.mgrhire = function (p) {
    const co = getCo(p.id), bd = BD[co.type];
    ui.mtype = ui.mtype || {};
    const t = ui.mtype[co.id] || bd.mgr;
    const list = ((ui.mgrC || {})[co.id] || []).map(id => S.npcs[id]).filter(n => n && n.stats && !n.hired);
    const sel = list.find(n => n.id === ui.mcand);
    let h = hireTabs(p, 'mgrhire');
    if (sel) return h + mgrDetail(co, bd, sel);
    ui.mcand = null;
    const types = Object.keys(MGR_TYPES).sort((a, b) => typeFit(co, b) - typeFit(co, a));
    h += '<div class="card"><span class="lab">Looking for</span>' + U.ddown(types.map(x => [x, MGR_TYPES[x] + ' · fit ' + Math.round(typeFit(co, x) * 100) + '%']), t, 'mtypeset', { id: co.id }) + '<small>Best fit for ' + esc(bd.n) + ': ' + esc(MGR_TYPES[bd.mgr] || 'General manager') + '</small>' + btn('Search · ' + mshort(KC(15000)), 'mgrsearch', { id: co.id }, 'primary wide') + '</div>';
    h += list.map(n => mgrRow(co, n)).join('') || '<div class="calm">No candidates yet.</div>';
    h += '<div class="lrows"><button class="lrow" data-a="go" data-p="' + P({ n: 'hq', p: { t: 'office' } }) + '"><span class="lic">' + svg('office', 20) + '</span><span class="ctext"><b>Head office staff</b><small>Analysts, HR, accountants and assistants</small></span><i>›</i></button><button class="lrow" data-a="go" data-p="' + P({ n: 'exechire' }) + '"><span class="lic">' + svg('tie', 20) + '</span><span class="ctext"><b>Group CEO and regional managers</b><small>Leaders above your company managers</small></span><i>›</i></button></div>';
    return h;
  };
  ACT.mcandopen = p => {
    ui.mcand = p.n;
    render(true);
  };
  ACT.mcandback = () => {
    ui.mcand = null;
    render(true);
  };

  /* moving a manager: the same kind of business keeps all experience, the same field costs a little, another field more */
  function moveLoss(a, b) {
    if (a.type === b.type) return { f: 1, t: 'Keeps experience', cls: 'green' };
    if (BD[a.type].fam === BD[b.type].fam) return { f: 0.9, t: '−10% experience', cls: 'amber' };
    return { f: 0.7, t: '−30% experience', cls: 'red' };
  }
  ACT.mgrmove = p => {
    const co = getCo(p.id), n = co && S.npcs[co.mgr];
    if (!n) return;
    const tg = live().filter(c => c.id !== co.id && !c.mgr && BD[c.type].fam !== 'club');
    openSheet('<h2>Move ' + esc(n.name) + '</h2><p class="muted small">Same kind of business keeps all experience. Another business in the same field costs a little; a different field costs more.</p><div class="lrows">' + (tg.map(c => {
      const l = moveLoss(co, c);
      return '<button class="lrow" data-a="mgrmovego" data-p="' + P({ id: co.id, to: c.id }) + '"><span class="ctext"><b>' + esc(c.name) + '</b><small>' + esc(BD[c.type].n) + '</small></span><span class="badge ' + l.cls + '">' + l.t + '</span></button>';
    }).join('') || '<div class="lrow"><small>Every other company already has a manager.</small></div>') + '</div>' + btn('Cancel', 'sheetclose', undefined, 'ghost wide'));
  };
  ACT.mgrmovego = p => {
    const a = getCo(p.id), b = getCo(p.to), n = a && S.npcs[a.mgr];
    if (!a || !b || !n || b.mgr) return;
    const l = moveLoss(a, b);
    n.exp = Math.round(n.exp * l.f * 2) / 2;
    b.mgr = n.id;
    b.mgrWage = a.mgrWage;
    b.mgrBonus = a.mgrBonus || 0;
    b.mgrW0 = S.week;
    b.ohrs = 0;
    b.mood = a.mood != null ? a.mood : 60;
    b.flags.fraud = 0;
    b.lastRev = null;
    n.hired = b.id;
    a.mgr = null;
    a.mgrWage = 0;
    a.ohrs = 40;
    ui.sheet = null;
    save();
    toast(n.name + ' now manages ' + b.name + '.');
    go('co', { id: b.id, t: 'st' });
  };

  /* ---------- meetings: the manager brings 2-3 proposals with numbers ---------- */
  const fmtW = (v, once) => once ? mshort(once) + ' once' : (v < 0 ? '−' : '') + mshort(Math.abs(v)) + '/wk';
  function mprops(co) {
    const bd = BD[co.type], w = co.lastW || {}, d = co.dbg || {};
    const q = mgrQual(co);
    const units = w.units || 0, rev = w.rev || 0, tk = units > 0 ? rev / units : ticketEff(co, bd);
    const util = w.util || 0, D = d.D != null ? d.D : (w.D || 0), cap = d.cap || w.cap || 0;
    const out = [];
    const std = stdStaff(bd, co.size || 1);
    let role = null;
    std.forEach(x => {
      if (!role && co.staff.filter(s => s.role === x[0] && !s.notice).length < x[1] && ROLES[x[0]]) role = x[0];
    });
    if (!role && util > 0.85 && std[0] && ROLES[std[0][0]]) role = std[0][0];
    if (role && (util > 0.75 || D > cap)) {
      const per = cap > 0 ? cap / Math.max(1, co.staff.length || 1) : D;
      const extra = Math.min(per, Math.max(0, D - cap * 0.9)) || per * 0.3;
      if (extra * tk > 0) out.push({ t: 'hire', role, cost: wageFor(role, co) * 12 * OC(), cw: wageFor(role, co) * 12 * OC() / 52, rw: extra * tk * 0.9, title: 'Hire one more ' + ROLES[role][0].toLowerCase(), why: 'Utilisation is ' + Math.round(util * 100) + '%' + (D > cap ? ' and we turn customers away' : '') + '. I would like to hire one more. Salary around ' + money(wageFor(role, co)) + ' a month.' });
    }
    const L = pLvl(co);
    if (util > 0.85 && L < 3) out.push({ t: 'price_up', cw: 0, rw: rev * (PRICE_PM[L + 4] / PRICE_PM[L + 3] * 0.9 - 1), title: 'Raise prices one step', why: 'We are nearly fully booked, so a higher price costs us few customers.' });
    if (util < 0.6 && L > -3 && units > 0) out.push({ t: 'price_down', cw: 0, rw: rev * (PRICE_PM[L + 2] / PRICE_PM[L + 3] * 1.22 - 1), title: 'Lower prices one step', why: 'We have free capacity. A lower price fills it.' });
    if (co.aware < 70) {
      const c = bd.aud > 0.5 ? 'google' : 'meta';
      const cur = co.mkt[c] ? co.mkt[c].b : 0;
      const nx = CH[c] && CH[c].opts.find(o => o > cur);
      if (nx) out.push({ t: 'mkt_more', cw: nx - cur, rw: (nx - cur) * (1.1 + (70 - co.aware) / 60) * (util < 0.9 ? 1 : 0.4), title: 'Spend more on ' + CH[c].n, why: 'We are ' + awWord(co.aware).toLowerCase() + ' locally. More people need to hear about us.' });
    }
    if ((co.eqc != null ? co.eqc : 1) < 0.7 && co.maint < 2) out.push({ t: 'quality', cw: Math.max(KC(200), rev * 0.02), rw: rev * 0.05, title: 'Step up maintenance', why: 'Equipment is at ' + Math.round((co.eqc || 0) * 100) + '% and breakdowns cost us jobs.' });
    if (util < 0.5 && co.staff.length > 1) {
      const s = co.staff.slice().sort((a, b) => staffSkill(a) - staffSkill(b))[0];
      out.push({ t: 'cut', cost: 0, cw: -s.wage * OC() * 12 / 52, rw: -rev * 0.04, title: 'Let one person go', why: 'We have more people than work right now.' });
    }
    const bo = d.botObj;
    if (bo && bo.kind === 'equip' && util > 0.9) {
      const e = bd.eq.find(x => 'eq:' + x.id === bo.k);
      if (e && !e.vo) out.push({ t: 'eq', id: e.id, cost: eqPrice(co, e), cw: 0, once: eqPrice(co, e), rw: tk * Math.max(1, D - cap) * 0.8, title: 'Buy ' + e.n, why: 'It is our bottleneck right now.' });
    }
    if (co.maint > 0 && rev > 0 && out.length < 3) out.push({ t: 'save', cw: -Math.max(KC(100), rev * 0.015), rw: -rev * 0.01, title: 'Trim upkeep', why: 'A little less maintenance saves money with small risk.' });
    out.forEach(x => {
      x.score = x.rw - x.cw - (x.once || 0) / 26 + gauss() * Math.abs(x.rw - x.cw + 1) * 0.6 * (1 - q);
    });
    return out.sort((a, b) => b.score - a.score).slice(0, 3);
  }
  V.meet = function () {
    const cos = live().filter(c => c.mgr && S.npcs[c.mgr]);
    if (!cos.length) return '<div class="card empty"><h3>No managers yet</h3><p class="lead">Hire a manager for a company and you can call meetings here.</p></div>';
    ui.mtw = cos.some(c => c.id === ui.mtw) ? ui.mtw : cos[0].id;
    const co = getCo(ui.mtw), n = S.npcs[co.mgr];
    const wait = co.meetW != null && S.week - co.meetW < 3;
    let h = '<div class="card"><span class="lab">Meet with</span>' + U.ddown(cos.map(c => [c.id, S.npcs[c.mgr].name + ' · ' + c.name]), ui.mtw, 'mtwho') + '<small>' + esc(n.name.split(' ')[0]) + ' brings 2–3 proposals with costs and expected revenue. You decide on each.</small>' + (wait ? '<div class="note">You met recently. Next meeting possible in ' + (3 - (S.week - co.meetW)) + ' week(s).</div>' : btn('Call the meeting', 'mtgo2', undefined, 'primary wide')) + '</div>';
    const open = S.inbox.filter(m => m.status === 'open' && m.act === 'mprop');
    if (open.length) h += '<h2 class="sec">On the table</h2>' + open.map(m => '<div class="dcard">' + window.msgCard(m) + '</div>').join('');
    return h;
  };
  ACT.mtwho = p => {
    ui.mtw = p.v;
    render();
  };
  ACT.mtgo2 = () => {
    const co = getCo(ui.mtw);
    if (!co || !co.mgr || !S.npcs[co.mgr]) return;
    const n = S.npcs[co.mgr], first = n.name.split(' ')[0];
    const ps = mprops(co);
    co.meetW = S.week;
    co.mood = Math.min(100, (co.mood != null ? co.mood : 60) + 3);
    if (!ps.length) addMsg({ kind: 'info', from: n.name, role: titleFor(co, 'mgr'), title: 'Meeting: ' + co.name, body: 'Things run well. I do not see anything worth changing right now.', co: co.id, tone: 'n', status: 'done' });
    ps.forEach(x => addMsg({
      kind: 'ask',
      from: n.name,
      role: titleFor(co, 'mgr'),
      title: x.title,
      body: x.why,
      co: co.id,
      stats: [['Added cost', fmtW(x.cw, x.once)], ['Added revenue', (x.rw < 0 ? '' : '~') + fmtW(x.rw)]],
      opts: [{ l: x.t === 'hire' ? 'Approve, I pick' : 'Approve', d: '', fx: {} }, { l: 'Let ' + first + ' decide', d: '', fx: {} }, { l: 'Not now', d: '', fx: {} }],
      act: 'mprop',
      data: x,
      exp: S.week + 2
    }));
    save();
    toast(ps.length ? first + ' put ' + ps.length + ' proposal' + (ps.length === 1 ? '' : 's') + ' on the table.' : first + ' has nothing to change.');
    render(true);
  };
  function doProp(co, x, n, q, mine) {
    if (x.t === 'hire' && mine) {
      ui.hrole = x.role;
      go('hire', { id: co.id });
      return;
    }
    if (x.t === 'hire' || x.t === 'eq' || x.t === 'cut') {
      if (x.t === 'hire') {
        const need = hireShort(co, x.cost || 0);
        if (need > 0) {
          if (liquid() < need) {
            note('Not enough money to hire at ' + co.name + ': needs ' + money(need) + ' first.', 'bad', co.id);
            return;
          }
          injectCash(co, need);
        }
      }
      execProposal(co, x, n, q);
      return;
    }
    const said = runStep(co, x.t);
    if (said) note(n.name + ': ' + said, 'n', co.id);
  }
  ACTS.mprop = (m, idx) => {
    const co = getCo(m.co);
    if (!co || !co.mgr || !S.npcs[co.mgr] || idx === 2) return true;
    const x = m.data, n = S.npcs[co.mgr], q = mgrQual(co);
    if (idx === 1 && !(x.rw - x.cw > 0 && chance(0.55 + q * 0.4))) {
      note(n.name + ' decided against: ' + x.title + '.', 'n', co.id);
      return true;
    }
    doProp(co, x, n, q, idx === 0);
    return true;
  };

/* ===== Round 5b: selling and raising money, own startups, the big meeting, worker discipline,
   price moves, crisis centre, marketing client stats ===== */
  const SALES = () => (S.sales = S.sales || []);
  const FOUNDER = () => (S.founder = S.founder || { exits: 0, fails: 0, raised: 0 });
  const FD = () => (S.founded = S.founded || []);
  const STK = () => (S.stakes = S.stakes || []);
  window.founderRec = FOUNDER;
  function capK(co) {
    return { energy: 5, fin: 4, club: 4, rent: 3, prod: 3, logi: 3, project: 2, venue: 2, retail: 2, svc: 1 }[BD[co.type].fam] || 2;
  }
  function traction(co) {
    const e = coEbit12(co);
    const rev = (co.bk.y && co.bk.y.rev) || (co.lastW ? co.lastW.rev * 52 : 0);
    const mg = rev > 0 ? e / rev : -0.2;
    const h = co.hist.slice(-6).map(x => x.rev || 0);
    const g = h.length >= 2 && h[0] > 0 ? h[h.length - 1] / h[0] - 1 : 0;
    return clamp(0.25 + mg * 1.5 + clamp(g, -0.5, 1) * 0.6 + ((co.rep || 50) - 50) / 150 + Math.min(0.2, (S.week - co.w0) / 260), 0, 1);
  }
  /* investors look at your record as a founder, how much capital the business eats, and how it is doing */
  function interest(ck, tr) {
    const f = FOUNDER();
    const track = Math.min(0.36, f.exits * 0.12) - Math.min(0.3, f.fails * 0.06);
    const pen = (ck - 1) * 0.13 * (f.exits ? 0.4 : 1);
    return clamp(0.3 + track + tr * 0.45 - pen + (((S.econ && S.econ.dem) || 1) - 1), 0.02, 0.97);
  }
  const intWord = x => x >= 0.7 ? ['Strong', 'pos'] : x >= 0.45 ? ['Some interest', 'amb'] : x >= 0.25 ? ['Weak', 'amb'] : ['Almost none', 'neg'];
  function consequences(co, pct, kind) {
    const after = kind === 'fund' ? co.own * (1 - pct / 100) : co.own - pct * co.own / 100;
    return '<h2 class="sec">What happens</h2><div class="card">' + row('You get cash', kind === 'fund' ? '<span class="pos">Into the company</span>' : '<span class="pos">Into your pocket</span>') + row('Your ownership', '<span class="amb">' + fmtPct(Math.round(co.own * 10) / 10) + '% → ' + fmtPct(Math.round(Math.max(0, after) * 10) / 10) + '%</span>') + (after > 0 ? row('Future dividends', 'Shared ' + fmtPct(Math.round((co.own - after) * 10) / 10) + '%') + row('Big decisions', after < 50 ? '<span class="neg">You lose control</span>' : after < 67 ? '<span class="amb">May need their vote</span>' : 'Still yours') : row('The company', 'No longer yours')) + '</div>';
  }

  /* ---------- sell a company or part of it ---------- */
  V.titles.sale = 'Sell or raise money';
  V.heads.sale = p => {
    const co = getCo(p.id);
    return { t: 'Sell or raise money', sub: co ? esc(co.name) : '' };
  };
  V.sale = function (p) {
    const co = getCo(p.id);
    if (!co || co.st === 'sold' || co.st === 'bust') return '<div class="calm">This company is no longer yours.</div>';
    const t = ui.salet || 'whole';
    const V0 = Math.max(0, companyValue(co));
    const net = companyAssets(co) - companyDebts(co);
    let h = '<div class="ptabs">' + [['whole', 'Whole company'], ['part', 'Part of it'], ['fund', 'Raise funding']].map(x => '<button class="' + (t === x[0] ? 'on' : '') + '" data-a="saletab" data-p="' + P(x[0]) + '">' + x[1] + '</button>').join('') + '</div>';
    h += '<div class="card"><span class="lab">Estimated value</span><b class="huge">' + nok(V0) + '</b>' + row('Profit last 12 months', nok(Math.max(0, coEbit12(co)))) + row('Assets minus debts', nok(net)) + row('Brand, clients, contracts', nok(Math.max(0, V0 - net))) + '</div>';
    if (t === 'fund') return h + fundPart(co, V0);
    const Lst = SALES().find(x => x.co === co.id);
    if (Lst) return h + listingPart(co, Lst);
    if (t === 'part' && co.form !== 'AS') return h + '<div class="card sense"><b>Only a limited company can sell shares</b><span class="tipt">Convert to ' + esc(CC().forms.AS) + ' first, then sell part of it.</span>' + btn('Convert to ' + esc(CC().forms.AS), 'tcAS', { id: co.id }, 'wide') + '</div>';
    const pct = t === 'whole' ? 100 : (ui.salep || 25);
    if (t === 'part') h += '<div class="card"><div class="kv"><span>Share of your stake to sell</span><b>' + pct + '%</b></div>' + chips([[10, '10%'], [25, '25%'], [34, '34%'], [49, '49%']], pct, 'salepct') + '</div>';
    const m = ui.salem || 'private';
    h += '<h2 class="sec">How to sell</h2><div class="lrows">' + [['private', 'Quiet private sale', 'Fewer buyers and slower. Staff and rivals do not hear.'], ['broker', 'Use a broker', 'More buyers, fee 4%. Rivals and staff hear about it.']].map(x => '<button class="lrow" data-a="salemode" data-p="' + P(x[0]) + '"><span class="ctext"><b>' + x[1] + '</b><small>' + x[2] + '</small></span><span class="radio' + (m === x[0] ? ' on' : '') + '"></span></button>').join('') + '</div>';
    h += consequences(co, pct, 'sell');
    h += btn('Put ' + (pct === 100 ? 'the company' : pct + '% of your shares') + ' up for sale', 'salego', { id: co.id, pct, m }, 'primary wide go');
    return h;
  };
  ACT.saletab = p => {
    ui.salet = p;
    render(true);
  };
  ACT.salepct = p => {
    ui.salep = p.v;
    render();
  };
  ACT.salemode = p => {
    ui.salem = p;
    render();
  };
  ACT.salego = p => {
    const co = getCo(p.id);
    if (!co || SALES().some(x => x.co === co.id)) return;
    SALES().push({ id: uid(), co: co.id, pct: p.pct, m: p.m, w0: S.week, offers: [] });
    save();
    toast(p.m === 'broker' ? 'The broker starts calling buyers.' : 'You quietly let it be known you would sell.');
    render(true);
  };
  const KIND_N = { rival: 'Rival · wants the clients', fund: 'Investment fund', mbo: 'Management buyout', private: 'Private buyer', angel: 'Private investor' };
  function listingPart(co, Lst) {
    const best = Lst.offers.reduce((a, o) => (o.price > (a ? a.price : 0) ? o : a), null);
    let h = '<div class="card sense"><b>On the market since ' + dateStr(Lst.w0) + '</b><span class="tipt">' + (Lst.pct === 100 ? 'The whole company' : Lst.pct + '% of your shares') + ' · ' + (Lst.m === 'broker' ? 'through a broker' : 'quiet private sale') + ' · ' + Lst.offers.length + ' offer' + (Lst.offers.length === 1 ? '' : 's') + ' so far.</span>' + btn('Take it off the market', 'salewd', { id: co.id }, 'wide') + '</div>';
    if (!Lst.offers.length) return h + '<div class="calm">No offers yet. Buyers show up over the coming weeks.</div>';
    return h + '<h2 class="sec">Buyers</h2>' + Lst.offers.map(o => '<div class="card' + (o === best ? ' offer on' : ' offer') + '"><div class="cchd">' + av(ini(o.name)) + '<span class="ctext"><b>' + esc(o.name) + '</b><small>' + esc(KIND_N[o.k] || '') + ' · until ' + dateStr(o.exp) + '</small></span><span class="badge ' + (o === best ? 'amber' : '') + '">' + mshort(o.price) + '</span></div><span class="tipt">' + esc(o.note) + '</span><div class="dbtns">' + btn('Accept', 'saleacc', { id: co.id, o: o.id }, 'primary') + (o.ctr ? btn('Decline', 'saledec', { id: co.id, o: o.id }) : btn('Counter +8%', 'salectr', { id: co.id, o: o.id })) + '</div></div>').join('');
  }
  function sellPart(co, pct, amt, buyer) {
    const pts = Math.min(pct * co.own / 100, co.own - 1);
    moveCash(ME, amt);
    logTx(0, amt, 'Sold ' + pct + '% of ' + co.name);
    S.tax.gain = (S.tax.gain || 0) + Math.max(0, amt - (co.inj || 0) * pts / 100);
    co.holders.push({ name: buyer, pct: pts, in: amt });
    co.own = Math.round((co.own - pts) * 100) / 100;
    if (pts >= 20) co.flags.boardSeat = (co.flags.boardSeat || 0) + 1;
    note('Sold ' + pct + '% of your shares in ' + co.name + ' to ' + buyer + ' for ' + money(amt) + '.', 'good', co.id);
  }
  ACT.saleacc = p => {
    const co = getCo(p.id), Lst = SALES().find(x => x.co === p.id), o = Lst && Lst.offers.find(x => x.id === p.o);
    if (!co || !o) return;
    const fee = Lst.m === 'broker' ? Math.round(o.price * 0.04) : 0;
    const get = Lst.pct === 100 ? o.price * co.own / 100 - fee : o.price - fee;
    confirmThen('Sell ' + (Lst.pct === 100 ? esc(co.name) : Lst.pct + '% of your shares') + '?', 'You receive ' + money(get) + (fee ? ' after the broker fee' : '') + (o.k === 'mbo' ? '. A third is a seller loan paid back over two years.' : '.') + ' This cannot be undone.', 'Sell', () => {
      if (Lst.pct === 100) {
        const r = acceptSale(co, { buyer: o.name, price: o.price, V: o.price });
        if (r !== 'ok') return U.res(r);
        if (fee) {
          moveCash(ME, -fee);
          logTx(0, -fee, 'Broker fee');
        }
        if (o.k === 'mbo') {
          const later = Math.round(o.price * co.own / 100 / 3);
          moveCash(ME, -later);
          S.deferred = (S.deferred || []).concat([{ w: S.week + 104, amt: later, co: co.id, name: co.name, hurdle: 0 }]);
        }
        if (o.price > (co.inj || 0) * 1.3) FOUNDER().exits++;
      } else sellPart(co, Lst.pct, o.price - fee, o.name);
      S.sales = SALES().filter(x => x !== Lst);
      save();
      if (co.st === 'sold') {
        ui.stack = [];
        tabTo('cos');
      } else render(true);
      toast('Deal done.');
    }, true);
  };
  ACT.salectr = p => {
    const Lst = SALES().find(x => x.co === p.id), o = Lst && Lst.offers.find(x => x.id === p.o);
    if (!o || o.ctr) return;
    o.ctr = 1;
    if (chance(o.k === 'rival' || o.k === 'fund' ? 0.55 : 0.4)) {
      o.price = Math.round(o.price * 1.08 / 1000) * 1000;
      o.note = 'Accepted your counter-offer.';
      toast(o.name + ' accepts +8%.');
    } else {
      Lst.offers = Lst.offers.filter(x => x !== o);
      toast(o.name + ' walked away.', true);
    }
    save();
    render();
  };
  ACT.saledec = p => {
    const Lst = SALES().find(x => x.co === p.id);
    if (Lst) Lst.offers = Lst.offers.filter(x => x.id !== p.o);
    save();
    render();
  };
  ACT.salewd = p => {
    S.sales = SALES().filter(x => x.co !== p.id);
    save();
    render();
    toast('Taken off the market.');
  };
  function salesWeek() {
    SALES().slice().forEach(Lst => {
      const co = getCo(Lst.co);
      if (!co || co.st === 'sold' || co.st === 'bust') {
        S.sales = SALES().filter(x => x !== Lst);
        return;
      }
      Lst.offers = (Lst.offers || []).filter(o => S.week < o.exp);
      if (Lst.offers.length >= 4) return;
      const V0 = Math.max(KC(20000), companyValue(co));
      const tr = traction(co);
      if (!chance((Lst.m === 'broker' ? 0.42 : 0.16) * (0.35 + tr) * (coEbit12(co) > 0 ? 1 : 0.45))) return;
      const kinds = Lst.pct === 100 ? ['private', 'fund', 'rival'] : ['private', 'fund', 'angel'];
      if (co.mgr && S.npcs[co.mgr] && Lst.pct === 100) kinds.push('mbo');
      const k = pick(kinds);
      const f = { rival: rng(0.95, 1.18), fund: rng(0.82, 1.02), mbo: rng(0.62, 0.8), private: rng(0.8, 1), angel: rng(0.78, 0.98) }[k] * (Lst.m === 'broker' ? 1.05 : 1) * (0.85 + tr * 0.3);
      const riv = rivalsOf(co)[0];
      const name = k === 'rival' && riv ? riv.name : k === 'mbo' ? S.npcs[co.mgr].name + ', your manager' : k === 'fund' ? brandCoName(CC(), 'fin') : personName();
      const nt = { rival: 'Strategic buyer. Pays well but may close it and keep only the customers.', fund: 'Wants to grow it and sell again. Keeps staff and the brand.', mbo: 'Management buyout. A third is paid as a seller loan over two years. Safe, loyal, slower to pay.', private: 'A private buyer who wants to run it themselves.', angel: 'A private investor who wants a say in big decisions.' }[k];
      const base = Lst.pct === 100 ? V0 : V0 * Lst.pct / 100 * co.own / 100;
      const o = { id: uid(), k, name, price: Math.round(base * f / 1000) * 1000, note: nt, w: S.week, exp: S.week + 6 };
      Lst.offers.push(o);
      addMsg({ kind: 'info', from: name, title: 'Offer for ' + (Lst.pct === 100 ? co.name : Lst.pct + '% of ' + co.name), body: name + ' offers ' + money(o.price) + '.', co: co.id, tone: 'good', status: 'done', go: { l: 'See offer', a: 'go', p: { n: 'sale', p: { id: co.id } } } });
      if (Lst.m === 'broker' && !Lst.heard) {
        Lst.heard = 1;
        co.mood = Math.max(0, (co.mood != null ? co.mood : 60) - 8);
        rivalsOf(co).forEach(r => {
          r.rel = Math.max(0, r.rel - 5);
        });
        note('Word is out that ' + co.name + ' is for sale. Staff are uneasy and rivals are watching.', 'n', co.id);
      }
    });
  }

  /* ---------- raise funding: new shares, the money goes into the company ---------- */
  function fundPart(co, V0) {
    if (co.form !== 'AS') return '<div class="card sense"><b>Investors buy shares</b><span class="tipt">Only a limited company can issue new shares. Convert first.</span>' + btn('Convert to ' + esc(CC().forms.AS), 'tcAS', { id: co.id }, 'wide') + '</div>';
    const it = interest(capK(co), traction(co)), iw = intWord(it), f = FOUNDER();
    const k = 'fneed' + co.id;
    let h = '<div class="card">' + row('You own', fmtPct(Math.round(co.own * 10) / 10) + '%') + row('Investor interest', '<span class="' + iw[1] + '">' + iw[0] + '</span>') + row('Your record as founder', f.exits + ' exit' + (f.exits === 1 ? '' : 's') + ' · ' + f.fails + ' failure' + (f.fails === 1 ? '' : 's')) + '<div class="kv"><span>You need</span>' + inp(k, '', Math.round(Math.max(KC(100000), V0 * 0.2) / 10000) * 10000) + '</div>' + btn('Pitch to investors', 'pitch', { id: co.id }, 'primary wide') + '</div>';
    const offs = (S.fundOffers || {})[co.id] || [];
    if (offs.length) h += '<h2 class="sec">Offers</h2>' + offs.map((o, i) => '<div class="card offer' + (i === 0 ? ' on' : '') + '"><div class="cchd">' + av(ini(o.name)) + '<span class="ctext"><b>' + esc(o.name) + '</b><small>Wants ' + o.pct.toFixed(0) + '% for ' + mshort(o.amt) + ' · values you at ' + mshort(o.pre + o.amt) + '</small></span>' + (i === 0 ? '<span class="badge amber">Best</span>' : '') + '</div>' + row(o.k === 'fund' ? 'Brings' : 'Says', esc(o.says)) + '<div class="dbtns">' + btn('Accept', 'fundacc', { id: co.id, i }, 'primary') + (o.ctr ? btn('Decline', 'funddec', { id: co.id, i }) : btn('Counter', 'fundctr', { id: co.id, i })) + '</div></div>').join('');
    else if (S.fundTried && S.fundTried[co.id] != null && S.week - S.fundTried[co.id] < 4) h += '<div class="calm">No investor bit this time. More profit, growth or a founder record makes them keener.</div>';
    h += consequences(co, offs[0] ? offs[0].pct : 20, 'fund');
    return h;
  }
  function makeOffers(ck, tr, amt, pre0) {
    const it = interest(ck, tr);
    const k = it > 0.72 ? 3 : it > 0.48 ? 2 : it > 0.26 ? 1 : (chance(it * 2) ? 1 : 0);
    const kinds = ['angel', 'fund', 'ff'];
    return Array.from({ length: k }, (x, i) => {
      const kd = kinds[i];
      const a = Math.round((kd === 'ff' ? amt * 0.5 : amt * rng(0.8, 1.15)) / 1000) * 1000;
      const pre = pre0 * rng(0.7, 1.25) * (0.7 + it * 0.6) * (kd === 'ff' ? 1.1 : 1);
      return { k: kd, name: kd === 'fund' ? brandCoName(CC(), 'fin') : kd === 'ff' ? 'Friends and family' : personName() + ', angel investor', amt: a, pre, pct: a / (pre + a) * 100, says: kd === 'fund' ? 'Contacts, advice, strict targets and a board seat' : kd === 'ff' ? 'Friendly, but it can get awkward if things go badly' : pick(['Will stay quiet', 'Interferes with managers', 'Wants monthly numbers']) };
    }).sort((a, b) => a.pct - b.pct);
  }
  ACT.pitch = p => {
    const co = getCo(p.id);
    S.fundTried = S.fundTried || {};
    if (S.fundTried[co.id] != null && S.week - S.fundTried[co.id] < 4) {
      toast('Investors need time. Try again in ' + (4 - (S.week - S.fundTried[co.id])) + ' week(s).', true);
      return;
    }
    S.fundTried[co.id] = S.week;
    const amt = Math.max(KC(50000), Math.round(U.inum('fneed' + co.id, KC(100000))));
    S.fundOffers = S.fundOffers || {};
    S.fundOffers[co.id] = makeOffers(capK(co), traction(co), amt, Math.max(amt, companyValue(co)));
    save();
    render();
    if (!S.fundOffers[co.id].length) toast('No investor bit.', true);
  };
  ACT.fundacc = p => {
    const co = getCo(p.id), o = ((S.fundOffers || {})[co.id] || [])[p.i];
    if (!o) return;
    moveCash(co, o.amt);
    co.tx.unshift({ w: S.week, a: o.amt, l: 'New shares sold to ' + o.name });
    co.holders.push({ name: o.name, pct: o.pct * co.own / 100, in: o.amt });
    co.own = Math.round(co.own * (1 - o.pct / 100) * 100) / 100;
    if (o.k === 'fund') co.flags.boardSeat = (co.flags.boardSeat || 0) + 1;
    FOUNDER().raised += o.amt;
    S.fundOffers[co.id] = [];
    note(co.name + ' raised ' + money(o.amt) + ' from ' + o.name + ' for ' + o.pct.toFixed(0) + '% in new shares.', 'good', co.id);
    save();
    render();
  };
  ACT.fundctr = p => {
    const co = getCo(p.id), L = (S.fundOffers || {})[co.id] || [], o = L[p.i];
    if (!o || o.ctr) return;
    o.ctr = 1;
    if (chance(0.25 + interest(capK(co), traction(co)) * 0.5)) {
      o.pre *= 1.2;
      o.pct = o.amt / (o.pre + o.amt) * 100;
      toast(o.name + ' accepts a higher valuation.');
    } else {
      S.fundOffers[co.id] = L.filter(x => x !== o);
      toast(o.name + ' walked away.', true);
    }
    save();
    render();
  };
  ACT.funddec = p => {
    const co = getCo(p.id), L = (S.fundOffers || {})[co.id] || [];
    S.fundOffers[co.id] = L.filter((x, i) => i !== p.i);
    save();
    render();
  };

  /* ---------- your own startups ---------- */
  const FSECT = [['app', 'Software and apps', 1, 250000], ['brand', 'Consumer brand', 2, 800000], ['fintech', 'Fintech', 2, 1500000], ['food', 'Food tech', 2, 1000000], ['health', 'Health tech', 3, 3000000], ['clean', 'Clean energy', 4, 15000000], ['bio', 'Biotech', 4, 20000000], ['air', 'Airline', 5, 120000000], ['oil', 'Oil and gas rig', 5, 300000000]];
  const ROUNDS = ['Pre-seed', 'Seed', 'Series A', 'Series B', 'Growth'];
  const CAPN = ['', 'Low', 'Medium', 'High', 'Very high', 'Huge'];
  function foundSheet() {
    const s = ui.fs = ui.fs || { sec: 'app', m: 1 };
    const d = FSECT.find(x => x[0] === s.sec), min = KC(d[3]);
    return '<h2>Found a startup</h2>' + inp('fname', 'Startup name', null, 'text') + '<div class="lab">Sector</div>' + U.ddown(FSECT.map(x => [x[0], x[1]]), s.sec, 'fsec') + row('Capital it needs', CAPN[d[2]]) + row('Investor interest at start', intWord(interest(d[2], 0.05))[0]) + '<div class="lab">Your seed money</div>' + chips([[1, mshort(min)], [2, mshort(min * 2)], [4, mshort(min * 4)]], s.m, 'fseed') + row('Runway', Math.round(26 * s.m) + ' weeks') + '<div class="btnrow">' + btn('Cancel', 'sheetclose', undefined, 'ghost') + btn('Found it', 'foundgo', undefined, 'primary') + '</div>';
  }
  ACT.found = () => openSheet(foundSheet());
  ACT.fsec = p => {
    ui.fs.sec = p.v;
    openSheet(foundSheet());
  };
  ACT.fseed = p => {
    ui.fs.m = p.v;
    openSheet(foundSheet());
  };
  ACT.foundgo = () => {
    const s = ui.fs, d = FSECT.find(x => x[0] === s.sec), seed = KC(d[3]) * s.m;
    if (liquid() < seed) {
      toast('You need ' + money(seed) + '.', true);
      return;
    }
    if (S.cash < seed) {
      const r = seed - Math.max(0, S.cash);
      S.sav.bal -= r;
      moveCash(ME, r);
    }
    moveCash(ME, -seed);
    logTx(0, -seed, 'Founded a startup');
    const f = FOUNDER();
    const nm = (ui.inp.fname || '').trim() || coinName(CC()) + pick(['ly', ' Labs', 'io', ' Tech']);
    FD().push({ id: uid(), name: nm, sec: d[0], secn: d[1], ck: d[2], stage: 0, pct: 100, val: seed * 1.2, cash: seed, burn: seed / (26 * s.m), in: seed, q: clamp(rng(0.25, 0.7) + f.exits * 0.05 - f.fails * 0.02, 0.1, 0.92), tr: 0.05, w0: S.week, wNext: S.week + rint(20, 34), st: 'live', offers: [] });
    ui.sheet = null;
    ui.inp.fname = '';
    ui.stab = 'found';
    save();
    render(true);
    toast(nm + ' is founded.');
  };
  function foundCard(f) {
    const run = f.burn > 0 ? Math.max(0, Math.floor(f.cash / f.burn)) : 0;
    let h = '<div class="card"><div class="cchd">' + av(ini(f.name)) + '<span class="ctext"><b>' + esc(f.name) + '</b><small>' + esc(f.secn) + ' · ' + (f.st === 'live' ? ROUNDS[f.stage] : f.st === 'exit' ? 'Acquired' : 'Shut down') + '</small></span><span class="badge ' + (f.st === 'live' ? (run < 8 ? 'red' : 'amber') : f.st === 'exit' ? 'green' : 'red') + '">' + (f.st === 'live' ? run + ' wk runway' : f.st === 'exit' ? 'Exit' : 'Closed') + '</span></div>';
    if (f.st !== 'live') return h + row('You put in', nok(f.in)) + (f.exitV ? row('Sold for', nok(f.exitV)) : '') + '</div>';
    h += row('You own', f.pct.toFixed(0) + '%') + row('Valuation', nok(f.val)) + row('Cash in the company', nok(f.cash)) + row('Investor interest', intWord(interest(f.ck, clamp(f.tr + f.stage * 0.15, 0, 1)))[0]);
    (f.offers || []).forEach((o, i) => {
      h += '<div class="card offer on"><div class="cchd">' + av(ini(o.name)) + '<span class="ctext"><b>' + esc(o.name) + '</b><small>' + mshort(o.amt) + ' for ' + o.pct.toFixed(0) + '%</small></span></div><div class="dbtns">' + btn('Accept', 'facc', { id: f.id, i }, 'primary') + btn('Decline', 'fdec', { id: f.id, i }) + '</div></div>';
    });
    return h + '<div class="three">' + btn('Raise a round', 'fpitch', { id: f.id }, 'primary') + btn('Put in money', 'ftop', { id: f.id }) + btn('Shut down', 'fshut', { id: f.id }) + '</div></div>';
  }
  ACT.fpitch = p => {
    const f = FD().find(x => x.id === p.id);
    if (!f) return;
    if (f.pitchW != null && S.week - f.pitchW < 4) {
      toast('Investors need time. Try again in ' + (4 - (S.week - f.pitchW)) + ' week(s).', true);
      return;
    }
    f.pitchW = S.week;
    f.offers = makeOffers(f.ck, clamp(f.tr + f.stage * 0.15, 0, 1), Math.max(f.burn * 26, f.val * 0.3), Math.max(f.val, f.in * 1.5));
    save();
    render();
    if (!f.offers.length) toast('No investor bit. Show more traction first.', true);
  };
  ACT.facc = p => {
    const f = FD().find(x => x.id === p.id), o = f && f.offers[p.i];
    if (!o) return;
    f.cash += o.amt;
    f.val = o.pre + o.amt;
    f.pct = f.pct * (1 - o.pct / 100);
    f.burn *= 1.35;
    f.warn = 0;
    FOUNDER().raised += o.amt;
    f.offers = [];
    note(f.name + ' raised ' + money(o.amt) + ' from ' + o.name + '.', 'good');
    save();
    render();
  };
  ACT.fdec = p => {
    const f = FD().find(x => x.id === p.id);
    if (f) f.offers.splice(p.i, 1);
    save();
    render();
  };
  ACT.ftop = p => openSheet('<h2>Put in money</h2>' + inp('ftopa', 'Amount') + U.quick('ftopa', [100000, 500000, 1000000, 5000000]) + '<div class="btnrow">' + btn('Cancel', 'sheetclose', undefined, 'ghost') + btn('Put in', 'ftopgo', { id: p.id }, 'primary') + '</div>');
  ACT.ftopgo = p => {
    const f = FD().find(x => x.id === p.id), a = Math.round(U.inum('ftopa', 0));
    if (!f || !(a > 0) || liquid() < a) {
      toast('Not enough money.', true);
      return;
    }
    if (S.cash < a) {
      const r = a - Math.max(0, S.cash);
      S.sav.bal -= r;
      moveCash(ME, r);
    }
    moveCash(ME, -a);
    logTx(0, -a, 'Put money into ' + f.name);
    f.cash += a;
    f.in += a;
    f.warn = 0;
    ui.sheet = null;
    ui.inp.ftopa = '';
    save();
    render();
  };
  ACT.fshut = p => {
    const f = FD().find(x => x.id === p.id);
    if (!f) return;
    confirmThen('Shut down ' + esc(f.name) + '?', 'Your share of the cash that is left comes back to you. It counts as a failed startup.', 'Shut down', () => {
      const back = Math.max(0, f.cash) * f.pct / 100;
      if (back) {
        moveCash(ME, back);
        logTx(0, back, 'Closed ' + f.name);
      }
      f.st = 'failed';
      f.val = 0;
      FOUNDER().fails++;
      save();
      render();
    }, true);
  };
  function foundedWeek() {
    FD().forEach(f => {
      if (f.st !== 'live') return;
      f.cash -= f.burn;
      f.tr = clamp(f.tr + (f.q - 0.3) * 0.012 + gauss() * 0.004, 0, 1);
      if (f.cash < 0) {
        f.st = 'failed';
        f.val = 0;
        FOUNDER().fails++;
        note(f.name + ' ran out of money and shut down.', 'bad');
        news('Startup ' + f.name + ' shuts down.', 'n');
        return;
      }
      if (f.cash < f.burn * 6 && !f.warn) {
        f.warn = 1;
        addMsg({ kind: 'info', from: f.name, title: f.name + ' has about ' + Math.floor(f.cash / f.burn) + ' weeks of money left', body: 'Raise a round or put in more money, or it shuts down.', tone: 'bad', status: 'done', go: { l: 'Open', a: 'phapp', p: { n: 'startups' } } });
      }
      if (S.week < f.wNext) return;
      f.wNext = S.week + rint(20, 34);
      if (chance(clamp(f.q * 0.9 + f.tr * 0.3 - f.stage * 0.05, 0.1, 0.9))) {
        f.stage = Math.min(4, f.stage + 1);
        f.val *= rng(1.8, 3.2);
        note(f.name + ' hit its milestone and is now at ' + ROUNDS[f.stage] + ' stage.', 'good');
        if (f.stage >= 4 && chance(0.5 + f.q * 0.3)) {
          const ex = f.val * rng(1.2, 2.8), pr = ex * f.pct / 100;
          moveCash(ME, pr);
          logTx(0, pr, 'Exit: ' + f.name);
          S.tax.gain = (S.tax.gain || 0) + Math.max(0, pr - f.in);
          f.st = 'exit';
          f.exitV = ex;
          f.val = 0;
          FOUNDER().exits++;
          note('EXIT! ' + f.name + ' was acquired. Your ' + f.pct.toFixed(0) + '% pays ' + money(pr) + '.', 'good');
          news(f.name + ' is acquired for ' + mshort(ex) + '.', 'good');
        }
      } else {
        f.val *= rng(0.6, 0.95);
        note(f.name + ' missed its milestone. The valuation fell.', 'bad');
      }
    });
  }
  const su0 = V.startups;
  V.startups = function () {
    const t = ui.stab || 'deals';
    const tabs = U.tabsRow([['deals', 'Invest'], ['mine', 'My stakes'], ['found', 'My startups']], t, 'stab');
    if (t !== 'found') return tabs + su0().replace(/^<div class="subtabs">[\s\S]*?<\/div>/, '');
    const f = FOUNDER(), L = FD();
    return tabs + '<div class="card">' + row('Your record as founder', f.exits + ' exit' + (f.exits === 1 ? '' : 's') + ' · ' + f.fails + ' failure' + (f.fails === 1 ? '' : 's')) + row('Raised from investors', nok(f.raised || 0)) + '<span class="tipt">Investors back founders with a record. A first-timer asking for a capital-heavy venture finds few takers.</span>' + btn('＋ Found a startup', 'found', undefined, 'primary wide') + '</div>' + L.slice().reverse().map(foundCard).join('');
  };

  /* ---------- the big meeting (late game) ---------- */
  function bigWeek() {
    if (S.bigOff && S.week >= S.bigOff.exp) S.bigOff = null;
    if (S.bigOff || S.week % 13 !== 7 || netWorth().total < KC(40e6) || !chance(0.35)) return;
    const nw = netWorth().total;
    const o = { id: uid(), tgt: brandCoName(CC(), pick(['venue', 'prod', 'logi', 'rent'])).split(' ')[0] + ' Group', seller: personName(), sellerCo: brandCoName(CC(), 'fin'), pct: pick([25, 30, 40, 49]), price: Math.round(nw * rng(0.5, 1.1) / 1e5) * 1e5, yld: rng(0.06, 0.1), w: S.week, exp: S.week + 3, ctr: 0 };
    S.bigOff = o;
    addMsg({ kind: 'info', from: o.seller, title: 'Big meeting: ' + o.pct + '% of ' + o.tgt, body: 'An offer is on the table for 3 weeks.', tone: 'good', status: 'done', go: { l: 'Go to the meeting', a: 'go', p: { n: 'bigmeet' } } });
  }
  V.titles.bigmeet = 'Big meeting';
  V.heads.bigmeet = () => ({ t: 'Big meeting', sub: 'Year ' + (Math.floor(S.week / 52) + 1), right: '<span class="badge blue">Only you attend</span>' });
  const prow = (nm, sub, right) => '<div class="lrow">' + av(ini(nm)) + '<span class="ctext"><b>' + esc(nm) + '</b><small>' + sub + '</small></span>' + (right ? '<span class="badge">' + right + '</span>' : '') + '</div>';
  V.bigmeet = function () {
    const o = S.bigOff;
    const stakes = STK();
    if (!o) return '<div class="calm">No big offer on the table right now. They come when your net worth is large enough.</div>' + (stakes.length ? '<h2 class="sec">Your stakes</h2><div class="lrows">' + stakes.map(x => prow(x.name, x.pct + '% · profit share ' + mshort(x.val * x.yld) + ' a year', mshort(x.val))).join('') + '</div>' : '');
    const nw = netWorth();
    const bankMax = Math.round(o.price * 0.6);
    const bank = (S.cos.find(c => c.type === 'bank' && c.st === 'open') || {}).name || brandCoName(CC(), 'fin').split(' ')[0] + ' Bank';
    const g = S.group || {};
    const lead = g.ceo && S.npcs[g.ceo.npc] ? [S.npcs[g.ceo.npc].name, 'Group CEO · reports on your behalf'] : g.regional && g.regional[0] && S.npcs[g.regional[0].npc] ? [S.npcs[g.regional[0].npc].name, 'Regional manager · reports on your behalf'] : null;
    let h = '<div class="card sense"><b>Offer to buy ' + o.pct + '% of ' + esc(o.tgt) + '</b><span class="tipt">Seller: ' + esc(o.sellerCo) + '. Offer is open for ' + Math.max(0, o.exp - S.week) + ' more week(s).</span><div class="duo"><div><span>Price</span><b>' + mshort(o.price) + '</b></div><div><span>Yearly profit share</span><b class="pos">' + mshort(o.price * o.yld) + '</b></div></div></div>';
    h += '<h2 class="sec">At the table</h2><div class="lrows">' + prow(o.seller, esc(o.sellerCo) + ' · seller') + prow(bank, 'Would finance up to 60%', mshort(bankMax)) + (lead ? prow(lead[0], lead[1]) : '') + '</div>';
    h += '<h2 class="sec">Your numbers</h2><div class="tri"><div><span>Net worth</span><b>' + mshort(nw.total) + '</b></div><div><span>Cash</span><b>' + mshort(S.cash) + '</b></div><div><span>Debt</span><b class="neg">' + mshort(nw.debt) + '</b></div></div>';
    h += '<h2 class="sec">Decide</h2><div class="dbtns three3">' + btn('Accept and borrow', 'bigacc', undefined, 'primary') + (o.ctr ? '' : btn('Counter ' + mshort(o.price * 0.9), 'bigctr')) + btn('Walk away', 'bigwalk') + '</div>';
    if ((policy() + 0.045) * bankMax > o.price * o.yld) h += '<div class="card probcard"><p>If rates rise 2 points, your interest cost would be higher than the profit share.</p></div>';
    return h;
  };
  ACT.bigacc = () => {
    const o = S.bigOff;
    if (!o) return;
    const borrow = Math.min(Math.round(o.price * 0.6), Math.max(0, Math.round(o.price - Math.max(0, liquid() - KC(100000)))));
    const own = o.price - borrow;
    if (liquid() < own) {
      toast('You need ' + money(own) + ' of your own money.', true);
      return;
    }
    confirmThen('Buy ' + o.pct + '% of ' + esc(o.tgt) + '?', 'You pay ' + money(own) + ' yourself and borrow ' + money(borrow) + ' over 10 years.', 'Buy', () => {
      if (borrow > 0) {
        const r = policy() + 0.02;
        S.loans.push({ id: uid(), kind: 'mort', name: 'Acquisition loan: ' + o.tgt, bal: borrow, amt0: borrow, margin: 0.02, pay: annuity(borrow, r, 120), termM: 120, co: 0, w0: S.week, guar: 0, bank: 0 });
        gainMe(borrow, 'Acquisition loan');
      }
      payMe(o.price, 'Bought ' + o.pct + '% of ' + o.tgt);
      STK().push({ id: uid(), name: o.tgt, pct: o.pct, val: o.price, yld: o.yld, w0: S.week });
      S.bigOff = null;
      note('You bought ' + o.pct + '% of ' + o.tgt + '.', 'good');
      save();
      render();
    }, true);
  };
  ACT.bigctr = () => {
    const o = S.bigOff;
    if (!o || o.ctr) return;
    o.ctr = 1;
    if (chance(0.45)) {
      o.price = Math.round(o.price * 0.9 / 1e5) * 1e5;
      toast(o.seller + ' accepts your counter.');
    } else {
      S.bigOff = null;
      toast(o.seller + ' walked away from the deal.', true);
    }
    save();
    render();
  };
  ACT.bigwalk = () => {
    S.bigOff = null;
    save();
    U.back();
  };
  function stakesWeek() {
    STK().forEach(x => {
      x.val = Math.max(0, x.val * (1 + 0.003 + gauss() * 0.015));
      if (isMonthEnd(S.week)) {
        const a = Math.round(x.val * x.yld / 12);
        moveCash(ME, a);
        logTx(0, a, 'Profit share: ' + x.name);
      }
    });
  }

  /* ---------- worker discipline: raise, warn, lay off ---------- */
  const justified = s => (s.warn || 0) >= 2 || s.flag === 'theft';
  const compRange = s => [s.wage * 2, s.wage * 4];
  function tenure2(s) {
    const wk = Math.max(0, S.week - (s.w0 || S.week));
    return wk >= 52 ? Math.floor(wk / 52) + ' yr' : wk >= 9 ? Math.round(wk / 4.35) + ' months' : wk + ' weeks';
  }
  V.titles.staffman = 'Worker';
  V.heads.staffman = p => {
    const co = getCo(p.id), s = co && co.staff.find(x => x.id === p.s), n = s && S.npcs[s.id];
    return n ? { t: n.name, sub: esc(ROLES[s.role][0]) + ' · ' + tenure2(s) + ' · ' + money(s.wage), right: s.flag ? '<span class="badge red">PROBLEM</span>' : '' } : {};
  };
  V.staffman = function (p) {
    const co = getCo(p.id), s = co && co.staff.find(x => x.id === p.s);
    if (!s) return '<div class="calm">This person no longer works here.</div>';
    const bd = BD[co.type];
    const team = co.staff.filter(x => x.role === s.role);
    const avg = sum(team, x => staffSkill(x)) / Math.max(1, team.length);
    const per = co.lastW && co.lastW.units ? co.lastW.units / Math.max(1, co.staff.length) : 0;
    const mine = per * staffSkill(s) / Math.max(1, avg);
    let h = '<div class="card">' + row('Late this quarter', '<span class="' + (s.late ? 'neg' : '') + '">' + (s.late || 0) + (s.late === 1 ? ' time' : ' times') + '</span>') + row('Client complaints', '<span class="' + (s.cmp ? 'neg' : '') + '">' + (s.cmp || 0) + '</span>') + row(esc(capF(unitPl(bd.unit, 2))) + ' per week', (Math.round(mine * 10) / 10) + ' · team average ' + (Math.round(per * 10) / 10)) + row('Warnings on file', s.warn || 0) + row('Notice period', s.w0 < S.week - 52 ? '2 months' : '1 month') + '</div>';
    h += '<h2 class="sec">What you can do</h2>';
    const f = ui.rf || 0.06;
    h += '<div class="card"><div class="bhead"><b>Give a raise</b><span class="badge blue">Keeps good workers</span></div>' + chips([[0.03, '+3%'], [0.06, '+6%'], [0.1, '+10%']], f, 'rfset') + '<span class="tipt">Cost +' + money(s.wage * f) + ' a month plus charges.' + (s.flag === 'late' ? ' Does not fix lateness.' : '') + '</span>' + btn('Give +' + Math.round(f * 100) + '%', 'doraise', { id: co.id, s: s.id, f }, 'wide') + '</div>';
    h += '<div class="card"><div class="bhead"><b>Written warning</b><span class="badge amber">' + (s.warn ? s.warn + ' on file' : 'First step') + '</span></div><span class="tipt">Creates a record. A second warning later makes a firing easier to defend.</span>' + btn('Issue warning', 'warnstaff', { id: co.id, s: s.id }, 'wide') + '</div>';
    if (bd.crs && bd.crs.length) h += '<div class="card"><div class="bhead"><b>Send on a course</b><span class="badge">from ' + mshort(Math.min.apply(null, bd.crs.map(c => c[2]))) + '</span></div><span class="tipt">Might help, might do nothing.</span>' + btn('Choose a course', 'coursesheet', { id: co.id, s: s.id }, 'wide') + '</div>';
    const just = justified(s), cr = compRange(s);
    h += '<div class="card' + (just ? '' : ' probcard') + '"><div class="bhead"><b>Let them go</b><span class="badge ' + (just ? 'green' : 'red') + '">' + (just ? 'Documented' : 'Legal rules') + '</span></div><span class="tipt">' + (just ? 'Two warnings are on file, so dismissal for cause is easy to defend. No severance.' : 'Without documented warnings they can claim unfair dismissal. Cost: notice pay plus possible compensation of ' + mshort(cr[0]) + ' to ' + mshort(cr[1]) + '.') + '</span>' + btn('Start process', 'firestaff', { id: co.id, s: s.id }, 'wide') + '</div>';
    h += '<h2 class="sec">Layoffs for the whole company</h2>' + layoffCard(co);
    return h;
  };
  ACT.rfset = p => {
    ui.rf = p.v;
    render();
  };
  ACT.warnstaff = p => {
    const co = getCo(p.id), s = co && co.staff.find(x => x.id === p.s);
    if (!s) return;
    s.warn = (s.warn || 0) + 1;
    s.warnW = S.week;
    if (s.flag && chance(0.35)) {
      s.flag = null;
      toast('The warning worked. ' + S.npcs[s.id].name.split(' ')[0] + ' has improved.');
    } else toast('Warning on file (' + s.warn + ').');
    save();
    render();
  };
  ACT.firestaff = p => {
    const co = getCo(p.id), s = co && co.staff.find(x => x.id === p.s);
    if (!s) return;
    const n = S.npcs[s.id], just = justified(s), mo = s.w0 < S.week - 52 ? 2 : s.w0 < S.week - 13 ? 1 : 0.5, sev = s.wage * mo * (1 + CC().empNI), cr = compRange(s);
    confirmThen('Let ' + esc(n.name) + ' go?', just ? 'Dismissal for cause with warnings on file. No severance.' : 'Notice pay is about ' + money(sev) + '. Without documented warnings ' + esc(n.name.split(' ')[0]) + ' may claim unfair dismissal (' + mshort(cr[0]) + '–' + mshort(cr[1]) + ').', 'Let go', () => {
      const unfair = !just && chance(s.flag ? 0.35 : 0.55);
      fireStaff(co, s.id, just ? 1 : 0);
      if (unfair) {
        const c = Math.round(rng(cr[0], cr[1]) / 100) * 100;
        payCo(co, c, 'fine', 'Unfair dismissal settlement');
        note(n.name + ' claimed unfair dismissal. ' + co.name + ' paid ' + money(c) + ' in compensation.', 'bad', co.id);
      }
      save();
      if (ui.view.n === 'staffman') U.back(); else render();
    }, true);
  };
  function layoffCard(co) {
    const v = ui.lo || '1';
    const n = v === '10' ? Math.max(1, Math.round(co.staff.length * 0.1)) : Math.min(co.staff.length, +v);
    const pickL = co.staff.slice().sort((a, b) => staffSkill(a) - staffSkill(b)).slice(0, n);
    const saves = sum(pickL, s => s.wage * (1 + CC().empNI));
    const sev = sum(pickL, s => s.wage * (s.w0 < S.week - 52 ? 2 : s.w0 < S.week - 13 ? 1 : 0.5) * (1 + CC().empNI));
    return '<div class="card"><div class="kv"><span>Cut staff to save costs</span><b>Choose how many</b></div>' + chips([['1', '1 person'], ['3', '3 people'], ['10', '10%']], v, 'loset') + row('Saves per month', '<span class="pos">' + nok(saves) + '</span>') + row('Severance now', '<span class="neg">' + nok(sev) + '</span>') + row('Who goes', esc(pickL.map(s => S.npcs[s.id] ? S.npcs[s.id].name.split(' ')[0] : '').join(', ') || 'Nobody')) + btn('Lay off ' + n, 'logo', { id: co.id, n }, 'wide') + '</div>';
  }
  ACT.loset = p => {
    ui.lo = p.v;
    render();
  };
  ACT.logo = p => {
    const co = getCo(p.id);
    if (!co || !co.staff.length) return;
    confirmThen('Lay off ' + p.n + '?', 'The weakest performers go and get severance. Morale drops for the rest.', 'Lay off', () => {
      co.staff.slice().sort((a, b) => staffSkill(a) - staffSkill(b)).slice(0, p.n).forEach(s => fireStaff(co, s.id, 0));
      co.mood = Math.max(0, (co.mood != null ? co.mood : 60) - 6);
      note(co.name + ' laid off ' + p.n + ' (' + (p.n === 1 ? 'person' : 'people') + ').', 'n', co.id);
      save();
      if (ui.view.n === 'staffman') U.back(); else render();
    }, true);
  };
  function staffTrack() {
    S.cos.forEach(co => {
      if (co.st !== 'open') return;
      const q4 = Math.floor(S.week / 13);
      co.staff.forEach(s => {
        if (s.qtr !== q4) {
          s.qtr = q4;
          s.late = 0;
          s.cmp = 0;
        }
        if (s.flag === 'late' ? chance(0.45) : chance(0.01)) s.late = (s.late || 0) + 1;
        if ((s.flag === 'conflict' || s.flag === 'lazy' || s.flag === 'theft') && chance(0.18)) s.cmp = (s.cmp || 0) + 1;
        if (s.flag && s.warnW && S.week - s.warnW <= 8 && chance(0.05)) {
          s.flag = null;
          if (S.npcs[s.id]) note(S.npcs[s.id].name + ' has improved after the warning.', 'good', co.id);
        }
      });
    });
  }

  /* ---------- price moves ---------- */
  const rivRun = r => Math.round(6 + r.size * 8 + hrng(String(r.id))() * 4);
  const rivPrice = (co, r) => ticketEff(co, BD[co.type]) / priceMult(co) * (0.82 + hrng(S.seed + ':rp:' + r.id)() * 0.4);
  const mktShare = (co, rs) => (co.size || 1) / ((co.size || 1) + sum(rs, r => r.size));
  V.titles.pricemoves = 'Price moves';
  V.heads.pricemoves = p => {
    const co = getCo(p.id);
    return { t: 'Price moves', sub: co ? esc(co.name) + ' · ' + esc(cityOf(co.city).name) : '' };
  };
  V.pricemoves = function (p) {
    const co = getCo(p.id), bd = BD[co.type];
    const rs = co.st === 'open' ? rivalsOf(co) : [];
    const tk = ticketEff(co, bd), w = co.lastW || {};
    const costPer = w.units > 0 ? sumExp(co.bk.w || {}) / w.units : 0;
    let h = '<div class="card"><div class="kv bigkv"><span>Your price per ' + esc(bd.unit) + '</span><b>' + nok(tk) + '</b></div>' + rs.map(r => row(esc(r.name), npadL(rivPrice(co, r)))).join('') + (costPer ? row('Your cost per ' + esc(bd.unit), npadL(costPer)) : '') + '</div>';
    const L = pLvl(co);
    const opts = [-2, -1, 1, 2].map(d => L + d).filter(l => l >= -3 && l <= 3);
    const sel = opts.indexOf(ui.pmv) >= 0 ? ui.pmv : (opts.indexOf(L - 1) >= 0 ? L - 1 : opts[0]);
    const dp = PRICE_PM[sel + 3] / PRICE_PM[L + 3] - 1;
    const dc = -dp * 1.25;
    const m0 = tk > 0 && costPer ? (tk - costPer) / tk : null, tk1 = tk * (1 + dp), m1 = costPer ? (tk1 - costPer) / tk1 : null;
    h += '<h2 class="sec">Move first</h2><div class="card"><div class="bhead"><b>Set a new price</b><span class="badge blue">Applies from next week</span></div><div class="seg" style="grid-template-columns:repeat(' + opts.length + ',1fr)">' + opts.map(l => '<button class="' + (l === sel ? 'on' : '') + '" data-a="pmvset" data-p="' + l + '">' + pctTxt(PRICE_PM[l + 3] / PRICE_PM[L + 3] - 1) + '</button>').join('') + '</div><div class="duo"><div><span>Clients</span><b class="' + (dc >= 0 ? 'pos' : 'neg') + '">' + pctTxt(dc) + '</b></div><div><span>Margin</span><b class="' + (m1 != null && m0 != null && m1 >= m0 ? 'pos' : 'amb') + '">' + (m1 != null && m0 != null ? (m1 >= m0 ? '+' : '−') + Math.abs(Math.round((m1 - m0) * 100)) + ' pts' : '—') + '</b></div></div><span class="tipt">Rivals may match you, ignore you, or go lower still.</span>' + btn('Set ' + PRICE_NAMES[sel + 3].toLowerCase() + ' prices', 'pmvgo', { id: co.id, l: sel }, 'primary wide') + '</div>';
    const pw = co.flags.pw;
    if (pw) {
      const r = rs.find(x => x.id === pw.rid);
      h += '<div class="card probcard"><b>Price war with ' + esc(r ? r.name : 'a rival') + '</b>' + row('Weeks left', Math.max(0, pw.end - S.week)) + row('Revenue given up so far', nok(pw.loss || 0)) + btn('End the price war', 'pwend', { id: co.id }, 'wide') + '</div>';
    } else if (rs.length) {
      const tgt = rs.slice().sort((a, b) => a.size - b.size)[0];
      const wks = rivRun(tgt), loss = Math.round((w.rev || 0) * 0.3 * wks), share = mktShare(co, rs);
      const odds = clamp(0.25 + (co.cash > loss * 1.3 ? 0.35 : co.cash > loss * 0.7 ? 0.15 : 0) + (1.2 - tgt.size) * 0.2, 0.1, 0.85);
      h += '<div class="card sense"><div class="bhead"><b>Undercut to push a rival out</b>' + (share >= 0.35 ? '<span class="badge red">Legal risk</span>' : '') + '</div><span class="tipt">Go rock-bottom on price until ' + esc(tgt.name) + ' runs out of cash. They have about ' + wks + ' weeks of money. You would give up about ' + money(loss) + ' first.</span>' + row('Chance they fold', odds >= 0.6 ? 'Good' : odds >= 0.4 ? 'Even' : 'Poor') + row('Your market share', Math.round(share * 100) + '%') + row('If you dominate and it looks deliberate', share >= 0.35 ? '<span class="neg">Authority can fine you</span>' : 'Low risk') + btn('Start price war', 'pwgo', { id: co.id, r: tgt.id, w: wks, odds, share }, 'primary wide') + '</div>';
    }
    if (rs.length) h += '<h2 class="sec">Move before they do</h2><div class="lrows"><button class="lrow" data-a="newsite" data-p="' + P({ bd: co.type }) + '"><span class="ctext"><b>Open a branch next to their best one</b><small>Takes their customers on their doorstep</small></span><i>›</i></button><button class="lrow" data-a="hirego" data-p="' + P({ id: co.id }) + '"><span class="ctext"><b>Poach their best worker</b><small>Costs more salary, weakens them</small></span><i>›</i></button><button class="lrow" data-a="codeal" data-p="' + P({ id: co.id, s: 'rivals' }) + '"><span class="ctext"><b>Talk to them or buy them</b><small>Relationships and offers</small></span><i>›</i></button></div>';
    return h;
  };
  ACT.pmvset = p => {
    ui.pmv = +p;
    render();
  };
  ACT.pmvgo = p => {
    const co = getCo(p.id);
    co.price = clamp(p.l, -3, 3);
    ui.pmv = null;
    save();
    render();
    toast('Prices set to ' + PRICE_NAMES[co.price + 3].toLowerCase() + '.');
  };
  ACT.pwgo = p => {
    const co = getCo(p.id);
    confirmThen('Start a price war?', 'Your prices go to the bottom for ' + p.w + ' weeks. It costs you revenue, and it may draw the competition authority.', 'Start', () => {
      co.flags.pw = { rid: p.r, end: S.week + p.w, prev: co.price, odds: p.odds, share: p.share, loss: 0 };
      co.price = -3;
      save();
      render();
    }, true);
  };
  ACT.pwend = p => {
    const co = getCo(p.id), pw = co.flags.pw;
    if (!pw) return;
    co.price = pw.prev;
    delete co.flags.pw;
    save();
    render();
  };
  function pwWeek() {
    S.cos.forEach(co => {
      const pw = co.flags && co.flags.pw;
      if (!pw) return;
      if (co.st !== 'open') {
        delete co.flags.pw;
        return;
      }
      co.price = -3;
      pw.loss = (pw.loss || 0) + Math.round(((co.lastW && co.lastW.rev) || 0) * 0.3);
      if (S.week < pw.end) return;
      const rs = rivalsOf(co), r = rs.find(x => x.id === pw.rid);
      co.price = pw.prev;
      delete co.flags.pw;
      if (r && chance(pw.odds)) {
        const m = ensureMk(co);
        m.riv = (m.riv || []).filter(x => x !== r);
        m.n = Math.max(1, m.n - 1);
        co.aware = Math.min(100, co.aware + 6);
        note(r.name + ' could not survive the price war and closed. Its customers are up for grabs.', 'good', co.id);
        news(r.name + ' closes after a price war.', 'n');
      } else note((r ? r.name : 'The rival') + ' survived the price war.', 'bad', co.id);
      if (pw.share >= 0.35 && chance(0.3)) {
        const f = Math.round(Math.max(KC(50000), (co.bk.y.rev || 0) * 0.05));
        payCo(co, f, 'fine', 'Competition fine');
        co.rep = clamp(co.rep - 5, 0, 100);
        addMsg({ kind: 'info', from: '{auth:comp}', title: 'Abuse of a dominant position at ' + co.name, body: 'The competition authority fined ' + co.name + ' ' + money(f) + ' for pricing to push out a rival.', co: co.id, tone: 'bad', status: 'done' });
      }
    });
  }

  /* ---------- crisis centre ---------- */
  function crisisList() {
    return S.inbox.filter(m => m.status === 'open' && m.opts && m.opts.length && (m.tone === 'bad' || m.kind === 'decision') && m.act !== 'mprop').sort((a, b) => (a.exp || 999) - (b.exp || 999));
  }
  window.crisisCount = () => (S ? crisisList().length : 0);
  V.titles.crisis = 'Crisis centre';
  V.heads.crisis = () => {
    const n = crisisList().length;
    return { t: 'Crisis centre', right: n ? '<span class="badge red">' + n + ' open</span>' : '' };
  };
  V.crisis = function () {
    const Lc = crisisList();
    if (!Lc.length) return '<div class="calm">No crises right now.</div>';
    return Lc.map(m => {
      const co = getCo(m.co), left = m.exp ? m.exp - S.week : null;
      return '<div class="card' + (left != null && left <= 1 ? ' hot' : '') + '"><div class="bhead"><b>' + esc(m.title) + '</b>' + (left != null ? '<span class="badge ' + (left <= 1 ? 'red' : 'amber') + '">' + (left <= 0 ? 'Now' : 'In ' + left + ' wk') + '</span>' : '') + '</div>' + (m.body ? '<span class="tipt">' + esc(m.body) + '</span>' : '') + (co ? '<small>' + esc(co.name) + '</small>' : '') + '<div class="chips">' + m.opts.map((o, i) => '<button class="btn chip' + (m.rec === i ? ' primary' : '') + '" data-a="msgpick" data-p="' + P({ id: m.id, i }) + '">' + esc(o.l) + '</button>').join('') + '</div>' + (m.opts.some(o => o.fx && fxText(o.fx)) ? '<small>' + esc(m.opts.map(o => o.l + ': ' + (fxText(o.fx || {}) || 'no direct cost')).join(' · ')) + '</small>' : '') + '</div>';
    }).join('');
  };
  APP.crisis = ['alert', 'Crisis centre', 'r', ['go', { n: 'crisis' }]];
  APP.bigmeet = ['deal', 'Big meeting', 'b', ['go', { n: 'bigmeet' }]];
  FOLD.business.apps.unshift('crisis');
  FOLD.money.apps.push('bigmeet');

  /* ---------- marketing: new clients and cost per client ---------- */
  const mkw0 = window.mktWeek;
  window.mktWeek = function (co, bd) {
    const r = mkw0.apply(this, arguments);
    try {
      const mi = monthIdx(S.week);
      if (!co.mks || co.mks.m !== mi) co.mks = { m: mi, n: 0, c: 0, ch: {}, prev: co.mks ? { n: co.mks.n, c: co.mks.c } : null };
      const sp = mktCost(co);
      const dpm = co.dbg && co.dbg.dp && co.dbg.dp.marketing ? co.dbg.dp.marketing : 1 + co.aware / 200;
      const att = sp > 0 ? clamp(1 - 1 / Math.max(1, dpm), 0, 0.6) : 0;
      const nw = ((co.lastW && co.lastW.units) || 0) * att * 0.5;
      co.mks.n += nw;
      co.mks.c += sp;
      const tot = sum(Object.keys(co.mkt), k => co.mkt[k].b * (CH[k] ? CH[k].eff : 1)) || 1;
      Object.keys(co.mkt).forEach(k => {
        co.mks.ch[k] = (co.mks.ch[k] || 0) + nw * co.mkt[k].b * (CH[k] ? CH[k].eff : 1) / tot;
      });
    } catch (e) { console.error(e); }
    return r;
  };
  const mk1 = CT.marketing;
  CT.marketing = function (co, bd) {
    const h = mk1(co, bd);
    const st = co.mks && co.mks.m === monthIdx(S.week) ? co.mks : null;
    const n = st ? Math.round(st.n) : 0;
    const chs = st ? Object.keys(st.ch).filter(k => co.mkt[k] && co.mkt[k].b) : [];
    const top = '<div class="card"><div class="kv bigkv"><span>Monthly budget</span><b>' + money(mktCost(co) * 4.33) + '</b></div>' + row('New clients this month', (n ? '~' : '') + n) + row('Cost per client', n ? npadL(st.c / n) : '—') + (co.mks && co.mks.prev ? row('Last month', '~' + Math.round(co.mks.prev.n) + ' new clients') : '') + chs.map(k => row(esc(CH[k].n) + ' · clients won', '~' + Math.round(st.ch[k]))).join('') + (mktCost(co) > 0 ? '<div class="kv"><span>Charged to the company account</span><b><span class="badge green">Auto-renew on</span></b></div>' : '') + '</div>';
    return top + h.replace(/<div class="card"><div class="kv bigkv"><span>Weekly budget<\/span><b>[\s\S]*?<\/b><\/div>/, '<div class="card">');
  };

  /* ---------- weekly hooks and net worth ---------- */
  const nextWeek2 = window.nextWeek;
  window.nextWeek = function () {
    const r = nextWeek2.apply(this, arguments);
    try {
      if (S && !S.over) {
        salesWeek();
        foundedWeek();
        bigWeek();
        stakesWeek();
        staffTrack();
        pwWeek();
      }
    } catch (e) {
      console.error(e);
    }
    return r;
  };
  const nw3 = window.netWorth;
  window.netWorth = function () {
    const r = nw3();
    if (!S) return r;
    const f = sum(FD().filter(x => x.st === 'live'), x => x.val * x.pct / 100) + sum(STK(), x => x.val);
    if (f) {
      r.cos += f;
      r.total += f;
    }
    return r;
  };
  const cofin0 = ACT.cofin, codeal0 = ACT.codeal;
  ACT.cofin = p => (p && p.s === 'sell' ? go('sale', { id: p.id }) : cofin0(p));
  ACT.codeal = p => (p && p.s === 'sell' ? go('sale', { id: p.id }) : codeal0(p));
  window.__r5 = { salesWeek, bigWeek, foundedWeek, pwWeek, mprops };

/* ---------- no zooming: pinch, double tap, ctrl+wheel, ctrl +/- ---------- */
  ['gesturestart', 'gesturechange', 'gestureend'].forEach(ev => document.addEventListener(ev, e => e.preventDefault(), { passive: false }));
  document.addEventListener('touchmove', e => {
    if (e.touches && e.touches.length > 1) e.preventDefault();
  }, { passive: false });
  document.addEventListener('wheel', e => {
    if (e.ctrlKey) e.preventDefault();
  }, { passive: false });
  document.addEventListener('keydown', e => {
    if ((e.ctrlKey || e.metaKey) && ['+', '-', '=', '0'].indexOf(e.key) >= 0) e.preventDefault();
  });
})();


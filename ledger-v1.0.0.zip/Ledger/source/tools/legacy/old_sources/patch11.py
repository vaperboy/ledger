path = '/home/claude/w3/ledger.html'
T = '/home/claude/w3/tools/'
t = open(path, encoding='utf8').read()
def rep(old, new, count=1):
    global t
    n = t.count(old)
    if n != count: raise SystemExit('MATCH %d (want %d): %s' % (n, count, old[:110]))
    t = t.replace(old, new)

# reviews: a stored review that names a worker (or you) replaces the generated one at the same place
rep("""    out.push({
      a: age,
      g: AR() < 0.5 ? 'F' : 'M',
      n: nm,
      st: stars,
      tx,""", """    const ov11 = window.R11NRV ? window.R11NRV(id, count - i) : null;
    out.push({
      a: age,
      g: AR() < 0.5 ? 'F' : 'M',
      n: nm,
      st: ov11 ? ov11.st : stars,
      tx: ov11 ? ov11.tx : tx,""")
# worker card: real numbers under the performance bar; the row shows their main number
rep("""'<div class="kv"><span>Performance</span><b>' + band(sk) + '</b></div>' + bar(sk, sk > 65 ? 'var(--green)' : sk < 35 ? 'var(--red)' : 'var(--blue)') +""",
    """'<div class="kv"><span>Performance</span><b>' + band(sk) + '</b></div>' + bar(sk, sk > 65 ? 'var(--green)' : sk < 35 ? 'var(--red)' : 'var(--blue)') + (window.workBlock ? window.workBlock(co, s) : '') +""")
rep("""<small>' + esc(ROLES[s.role][0]) + ' · ' + tenure(s) + ' · ' + money(s.wage) + '/mo</small>""",
    """<small>' + esc(ROLES[s.role][0]) + ' · ' + esc((window.workShort && window.workShort(co, s)) || tenure(s)) + ' · ' + money(s.wage) + '/mo</small>""")
# the manager can be promoted too
rep("""<span class="badge amber">' + AUTHN[co.auth ? co.auth.lvl : 0] + '</span></div>';""",
    """<span class="badge amber">' + AUTHN[co.auth ? co.auth.lvl : 0] + '</span><button class="btn chip" data-a="go" data-p="' + esc(JSON.stringify({ n: 'pr11', p: { id: co.id, m: 1 } })) + '">Promote</button></div>';""")
rep("(ladderFor(co, s).length ? btn('Promote', 'promosheet', { id: co.id, s: s.id }, 'chip') : '')", "btn('Promote', 'promosheet', { id: co.id, s: s.id }, 'chip')")
js = open(T + 'round11.js', encoding='utf8').read() + '\n'
mark = '/* ---------- no zooming: pinch, double tap, ctrl+wheel, ctrl +/- ---------- */'
rep(mark, js + mark)
css = open(T + 'round11.css', encoding='utf8').read()
i = t.rindex('</style>')
t = t[:i] + css + t[i:]
open(path, 'w', encoding='utf8').write(t)
print('patch11 ok')

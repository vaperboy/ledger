path = '/home/claude/w3/ledger.html'
T = '/home/claude/w3/tools/'
t = open(path, encoding='utf8').read()
def rep(old, new, count=1):
    global t
    n = t.count(old)
    if n != count: raise SystemExit('MATCH %d (want %d): %s' % (n, count, old[:110]))
    t = t.replace(old, new)

# weekly close: sales come from the days that were traded (whole units)
rep("""    let units = Math.min(ctx.D, ctx.cap);
    units = Math.max(0, Math.min(ctx.cap, units * (1 + gauss() * 0.045)));
    if (F && F.units) units = F.units(co, bd, ctx, units);
    units = Math.round(Math.min(units, ctx.cap) * 10) / 10;
    ctx.units = units;""", """    let units;
    if (window.R10U && window.R10U(co, bd, ctx)) units = ctx.units;
    else {
      units = Math.min(ctx.D, ctx.cap);
      units = Math.max(0, Math.min(ctx.cap, units * (1 + gauss() * 0.045)));
      if (F && F.units) units = F.units(co, bd, ctx, units);
      units = Math.round(Math.min(units, ctx.cap) * 10) / 10;
    }
    ctx.units = units;""")
rep("""  let units = Math.min(ctx.D, ctx.cap);
  units = Math.max(0, Math.min(ctx.cap, units * (1 + gauss() * 0.045)));
  units = stockUnits(co, bd, ctx, units);
  units = Math.round(units * 10) / 10;
  ctx.units = units;""", """  let units;
  if (window.R10U && window.R10U(co, bd, ctx)) units = ctx.units;
  else {
    units = Math.min(ctx.D, ctx.cap);
    units = Math.max(0, Math.min(ctx.cap, units * (1 + gauss() * 0.045)));
    units = stockUnits(co, bd, ctx, units);
    units = Math.round(units * 10) / 10;
  }
  ctx.units = units;""")
# money from sales already paid on the day is not paid twice
rep("""  coIn(co, gross * cashShare, null, null);""", """  coIn(co, gross * cashShare - (ctx.paidD || 0), null, null);""")
# each day is traded as it starts
rep("""    if (S.day < 6) {
      S.day++;
      return { got: releaseDay(S.day), done: null };
    }""", """    if (S.day < 6) {
      S.day++;
      if (window.R10DAY) window.R10DAY(S.day);
      return { got: releaseDay(S.day), done: null };
    }""")
rep("""    S.day = 0;
    stageWeek();
    const got = S.over ? [] : releaseDay(0);""", """    S.day = 0;
    stageWeek();
    if (!S.over && window.R10DAY) window.R10DAY(0);
    const got = S.over ? [] : releaseDay(0);""")
# "homes sold", not "home solds"
rep("""function unitPl(unit, n) {
  unit = String(unit || '');""", """function unitPl(unit, n) {
  unit = String(unit || '');
  const sd = /^(.+) sold$/.exec(unit);
  if (sd) return unitPl(sd[1], n) + ' sold';""")
# whole things on screen
rep("""row(esc(unitPl(bd.unit, 2).replace(/^./, x => x.toUpperCase())) + ' sold', Math.round((w.units || 0) * 10) / 10)""",
    """(window.unitsRows ? window.unitsRows(co, bd, w) : row(esc(unitPl(bd.unit, 2).replace(/^./, x => x.toUpperCase())) + ' sold', Math.round((w.units || 0) * 10) / 10))""")
rep("""(Math.round((c.units || 0) * 10) / 10) + ' ' + esc(unitPl(c.unit, c.units || 0))""", """esc(window.fmtU ? window.fmtU(c.units || 0, c.unit) : Math.round(c.units || 0) + ' ' + unitPl(c.unit, c.units || 0))""")
rep("""row(esc(capF(unitPl(bd.unit, 2))) + ' per week', (Math.round(mine * 10) / 10) + ' · team average ' + (Math.round(per * 10) / 10))""",
    """(window.staffSalesRow ? window.staffSalesRow(co, s, bd, per, mine) : row(esc(capF(unitPl(bd.unit, 2))) + ' per week', (Math.round(mine * 10) / 10) + ' · team average ' + (Math.round(per * 10) / 10)))""")
rep("""(a.lastU ? ' · about ' + Math.round(a.lastU) + ' ' + esc(bd.unit) + ' a week' : '')""", """(a.lastU ? ' · about ' + esc(window.rateW ? window.rateW(a.lastU, bd.unit) : Math.round(a.lastU) + ' ' + bd.unit + ' a week') : '')""")
rep("""    ? 'Customers want about ' + f(d.D) + ' ' + u + 's a week, but we can only do ' + f(d.cap) + '. What holds us back: ' + (d.bot || 'staff') + '.'
    : 'We are almost fully booked (' + f(d.D) + ' of ' + f(d.cap) + ' ' + u + 's a week). Another '""",
    """    ? 'Customers want about ' + rateW(d.D, u) + ', but we can only do ' + rateW(d.cap, u) + '. What holds us back: ' + (d.bot || 'staff') + '.'
    : 'We are almost fully booked (' + rateW(d.D, u) + ' wanted, room for ' + rateW(d.cap, u) + '). Another '""")
js = open(T + 'round10.js', encoding='utf8').read() + '\n'
mark = '/* ---------- no zooming: pinch, double tap, ctrl+wheel, ctrl +/- ---------- */'
rep(mark, js + mark)
css = open(T + 'round10.css', encoding='utf8').read()
i = t.rindex('</style>')
t = t[:i] + css + t[i:]
open(path, 'w', encoding='utf8').write(t)
print('patch10 ok')

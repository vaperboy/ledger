/* ===== Round 39: a small team does every job, equipment like software, customers you choose to reward.
   - Owner hours: in a company of up to three people the owner (and the team) also cover the support jobs
     (designer, receptionist, sales...), at some loss of efficiency, instead of being capped by an empty role.
   - Equipment: one recommended model per item, Compare for the rest. A manager buys missing kit at once and replaces
     worn-out kit, within the purchase limit you set; above it, they ask.
   - Business customers: you set each customer's discount; their profile shows what they bought and what they do;
     a customer you know well enough can become your supplier.
   - Favours have an effect you can see, and the same person does not ask again and again. ===== */
window.R39 = window.R39 || {};
(function () {
  'use strict';
  const R39 = window.R39;
  const U = window.UI;
  if (!U) return;
  const { ui, V, ACT, esc, row, btn, card, go, render, save, svg, openSheet, closeSheet, toast } = U;
  const CT = window.CT;
  const P = o => esc(JSON.stringify(o));
  const pillp = (t, c) => '<span class="pill ' + (c || '') + '">' + t + '</span>';
  const live = () => S.cos.filter(c => c.st !== 'sold' && c.st !== 'bust');

  /* ================= 1. a small team covers the support jobs ================= */
  const cap39 = window.capacity;
  window.capacity = function (co, bd) {
    const r = cap39.apply(this, arguments);
    try {
      if (!r || !r.parts || !co || co.mgr || !isFinite(r.cap)) return r;
      const sp = r.parts.filter(p => p.kind === 'staff');
      if (sp.length < 2) return r;
      const ownFTE = sp.reduce((t, p) => t + (p.owner || 0), 0);
      const heads = (co.staff || []).length + ((co.ohrs || 0) > 0 ? 1 : 0);
      if (heads > 3 || heads < 1) return r;
      const minOld = Math.min.apply(null, r.parts.map(p => isFinite(p.cap) ? p.cap : Infinity));
      const mult = minOld > 0 ? r.cap / minOld : 1;
      const core = sp[0];
      const emp = p => Math.max(0, (p.have || 0) - (p.owner || 0));
      /* everything the owner does goes into the core work; empty support jobs cost some efficiency instead */
      const ownCore = Math.max(0, (core.cap || 0) - emp(core) * (core.capPer || 0));
      const coreCap = emp(core) * (core.capPer || 0) + (core.owner > 0 ? ownCore * ownFTE / core.owner : ownFTE * (core.capPer || 0));
      let uncovered = 0;
      sp.slice(1).forEach(p => { if (emp(p) < 0.5) { uncovered++; p.cap = Infinity; p.cover39 = 1; } else p.cap = emp(p) * (p.capPer || 0) * 1.15; });
      const pen = Math.max(0.65, 1 - 0.1 * uncovered);
      core.cap = coreCap * pen;
      let cap = Infinity, bot = null;
      r.parts.forEach(p => { if (p.cap < cap) { cap = p.cap; bot = p; } });
      r.parts.forEach(p => { if (p.cover39) p.cap = core.cap; });
      if (!isFinite(cap)) return r;
      r.cap = Math.max(0, cap * mult);
      r.bot = bot;
      r.small39 = uncovered;
    } catch (e) { console.error(e); }
    return r;
  };

  /* ================= 2. equipment: one recommendation, compare for the rest ================= */
  const CLS = ['Basic', 'Standard', 'Premium'];
  const isSoft = (bd, e) => { try { return R6.kindOf(bd, e) === 'soft' || R6.kindOf(bd, e) === 'svc'; } catch (x) { return false; } };
  function recOf(co, e) {
    const bd = BD[co.type];
    if (e.vo) { const m = e.vo[0], v = VEH[m] || []; return { veh: 1, m, nm: v[0] || e.n, price: v[1] || e.cost || 0 }; }
    let cat = [];
    try { cat = eqCat(co.type, e.id, brandN(co), co.country) || []; } catch (x) { }
    if (!cat.length) return null;
    const want = co.eqcls39 != null ? co.eqcls39 : 1;
    const pool = cat.filter(c => c.cls === want).length ? cat.filter(c => c.cls === want) : cat;
    const pr = c => { try { return eqPrice(co, e, null, c); } catch (x) { return e.cost || 0; } };
    const c = pool.slice().sort((a, b) => (b.rating || 3) * (b.perf || 1) / Math.pow(pr(b), 0.15) - (a.rating || 3) * (a.perf || 1) / Math.pow(pr(a), 0.15))[0];
    return { c, nm: c.brand + ' ' + c.model, cls: c.cls, rating: c.rating, perf: c.perf, price: pr(c) };
  }
  R39.recOf = recOf;
  const needN = (co, bd, e) => { try { return Math.max(0, R6.needOf(co, bd, e) - eqCount(co, e.id)); } catch (x) { return 0; } };
  function recCard(co, bd, e) {
    const n = needN(co, bd, e), have = eqCount(co, e.id), need = n + have, r = recOf(co, e);
    if (!r) return '';
    const req = e.fl && e.fl.indexOf('r') >= 0;
    let h = '<div class="card eq39"><div class="cchd">' + R6.picEq(bd, e) + '<span class="ctext"><b>' + esc(e.n) + '</b><small>' + have + ' of ' + need + (req ? ' · needed to work' : '') + '</small></span>' + pillp(n + ' short', req ? 'red' : 'amb') + '</div>';
    h += '<div class="rec39"><span class="lab">Recommended</span><b>' + esc(r.nm) + '</b><small>' + (r.veh ? 'On finance: a small payment now, the rest monthly' : CLS[r.cls] + ' · ' + (r.rating ? r.rating.toFixed(1) + ' ★ · ' : '') + mshort(r.price) + ' each') + '</small></div>';
    h += '<div class="two">' + btn(r.veh ? 'Get ' + n + (n > 1 ? ' vehicles' : ' vehicle') : 'Buy ' + n + ' · ' + mshort(r.price * n), 'eq39buy', { id: co.id, e: e.id, n }, 'primary wide') + btn('Compare', 'go', { n: 'shop', p: { id: co.id, e: e.id, t: 'new' } }, 'wide') + '</div></div>';
    return h;
  }
  ACT.eq39buy = p => {
    const co = getCo(p.id), bd = co && BD[co.type], e = bd && bd.eq.find(x => x.id === p.e);
    if (!e) return;
    const r = recOf(co, e);
    let res = 'bad';
    if (r && r.veh) { for (let i = 0; i < p.n; i++) { res = buyVeh(co, e.id, r.m, 'finance'); if (res === 'cash') res = buyVeh(co, e.id, r.m, 'lease'); if (res !== 'ok') break; } }
    else if (r) res = buyEq(co, e.id, p.n, 'new', r.c);
    if (res === 'ok') { save(); render(); toast('Bought: ' + (r ? r.nm : e.n) + '.'); }
    else toast(res === 'cash' ? 'Not enough cash in ' + co.name + '.' : 'Could not buy it.', true);
  };
  ACT.eq39cls = p => { const co = getCo(p.id); if (!co) return; co.eqcls39 = p.v; save(); render(); };
  const eq39 = CT.eq;
  if (eq39) CT.eq = function (co, bd) {
    const h = eq39.apply(this, arguments);
    try {
      if (!bd.eq.length || bd.fam === 'club' || (ui.eqt && ui.eqt !== 'need')) return h;
      const tabsEnd = h.indexOf('<div class="ptabs">') >= 0 ? R30.blockEnd(h, h.indexOf('<div class="ptabs">')) : 0;
      let tail = '';
      const ip = h.indexOf('<h2 class="sec">In place</h2>'), cp = h.indexOf('<h2 class="sec">Condition</h2>');
      tail = ip >= 0 ? h.slice(ip) : cp >= 0 ? h.slice(cp) : '';
      const short = bd.eq.filter(e => !isSoft(bd, e) && needN(co, bd, e) > 0);
      const softMiss = bd.eq.filter(e => isSoft(bd, e) && e.fl && e.fl.indexOf('r') >= 0 && eqCount(co, e.id) < 1 && !(co.eq[e.id] && co.eq[e.id].sub));
      const up = bd.eq.filter(e => !isSoft(bd, e) && (() => { try { return R6.needOf(co, bd, e) === 0; } catch (x) { return false; } })() && eqCount(co, e.id) === 0 && !(co.eq[e.id]));
      let mid = '';
      const m = co.mgr && S.npcs[co.mgr];
      if (short.length) mid += (m ? '<div class="card sense"><span class="tipt">' + esc(m.name) + ' buys missing equipment within the purchase limit you set (Staff › manager). Above it, they ask you.</span></div>' : '') + short.map(e => recCard(co, bd, e)).join('');
      if (softMiss.length) mid += '<div class="lrows">' + softMiss.map(e => '<button class="lrow" data-a="eqtab" data-p="' + P({ v: 'soft' }) + '">' + R6.picEq(bd, e) + '<span class="ctext"><b>' + esc(e.n) + '</b><small>Software · needed to work</small></span>' + pillp('Missing', 'red') + '</button>').join('') + '</div>';
      mid += '<div class="card"><div class="bhead"><b>When buying</b><small>' + CLS[co.eqcls39 != null ? co.eqcls39 : 1] + '</small></div>' + U.chips(CLS.map((n, i) => [i, n]), co.eqcls39 != null ? co.eqcls39 : 1, 'eq39cls', { id: co.id }) + '<span class="tipt">Basic is cheap and breaks more; Premium lasts and works a little better. Recommendations and your manager follow this.</span></div>';
      if (up.length) mid += '<h2 class="sec">Optional upgrades</h2><div class="lrows">' + up.map(e => { const r = recOf(co, e); return '<button class="lrow" data-a="go" data-p="' + P({ n: 'shop', p: { id: co.id, e: e.id, t: 'new' } }) + '">' + R6.picEq(bd, e) + '<span class="ctext"><b>' + esc(e.n) + '</b><small>' + (r ? 'from about ' + mshort(r.price) : 'Compare suppliers') + '</small></span><i>›</i></button>'; }).join('') + '</div>';
      return h.slice(0, tabsEnd) + mid + tail;
    } catch (e) { console.error(e); return h; }
  };

  /* ================= 3. a manager buys and replaces kit within the purchase limit ================= */
  function buyLimit(co) {
    const a = co.auth || {};
    if (a.lvl === 2) return { v: Infinity, by: 'mgr' };
    if (a.lvl !== 1) return { v: 0, by: 'mgr' };
    let v = a.buy || 0, by = 'mgr';
    try {
      const reg = (S.group.regional || []).find(r => r.scope === 'all' || r.scope === BD[co.type].cat);
      if (reg && (reg.buy || 0) > v) { v = reg.buy; by = 'reg'; }
      if (S.group.ceo && (S.group.ceo.lvl === 2 ? Infinity : S.group.ceo.lvl === 1 ? S.group.ceo.buy || 0 : 0) > v) { v = S.group.ceo.lvl === 2 ? Infinity : S.group.ceo.buy; by = 'ceo'; }
    } catch (x) { }
    return { v, by };
  }
  R39.buyLimit = buyLimit;
  function askBuy(co, m, e, n, cost, what) {
    co.ask39 = co.ask39 || {};
    if (co.ask39[e.id] && S.week - co.ask39[e.id] < 4) return;
    co.ask39[e.id] = S.week;
    addMsg({ kind: 'ask', from: m.name + ', ' + titleFor(co, 'mgr').toLowerCase(), title: what + ' for ' + co.name + '?', body: 'It costs ' + money(cost) + ', above the purchase limit you gave me. Without it ' + (e.fl && e.fl.indexOf('r') >= 0 ? 'someone cannot work.' : 'we work slower.'), co: co.id, opts: [{ l: 'Approve · ' + mshort(cost), d: '', fx: {} }, { l: 'Not now', d: '', fx: {} }], act: 'eq39ask', data: { e: e.id, n, rep: what.indexOf('Replace') === 0 ? 1 : 0 }, exp: S.week + 3 });
  }
  function replaceKit(co, e, n, r) {
    try { (R6.unitsOf(co, e.id) || []).slice().forEach(u => R6.sellUnit(co, e.id, u.u)); } catch (x) { }
    return buyEq(co, e.id, n, 'new', r.c);
  }
  ACTS.eq39ask = (m, idx) => {
    const co = getCo(m.co), bd = co && BD[co.type], e = bd && bd.eq.find(x => x.id === m.data.e);
    if (!e || idx !== 0) return true;
    const r = recOf(co, e);
    const res = !r ? 'bad' : r.veh ? buyVeh(co, e.id, r.m, 'finance') : m.data.rep ? replaceKit(co, e, m.data.n, r) : buyEq(co, e.id, m.data.n, 'new', r.c);
    if (res === 'ok') note('Bought ' + (r ? r.nm : e.n) + ' for ' + co.name + '.', 'good', co.id); else note('Could not buy ' + e.n + ' for ' + co.name + ': ' + (res === 'cash' ? 'not enough cash.' : 'not possible.'), 'bad', co.id);
    return true;
  };
  function mgrKit(co) {
    const m = co && co.mgr && S.npcs[co.mgr];
    if (!m || co.st !== 'open') return;
    const bd = BD[co.type], L = buyLimit(co);
    const by = L.by === 'reg' ? ' (approved by the regional manager)' : L.by === 'ceo' ? ' (approved by the group CEO)' : '';
    bd.eq.forEach(e => {
      if (isSoft(bd, e)) return;
      const n = needN(co, bd, e);
      const r = n > 0 ? recOf(co, e) : null;
      if (n > 0 && r) {
        const cost = r.veh ? r.price * 0.2 * n : r.price * n;
        if (cost > L.v) return askBuy(co, m, e, n, cost, 'Buy ' + n + ' × ' + e.n.toLowerCase());
        let res = 'ok';
        if (r.veh) { for (let i = 0; i < n && res === 'ok'; i++) res = buyVeh(co, e.id, r.m, 'finance'); }
        else res = buyEq(co, e.id, n, 'new', r.c);
        if (res === 'ok') note(m.name + ' bought ' + n + ' × ' + (r.nm || e.n) + ' for ' + co.name + ' (' + mshort(cost) + ')' + by + '.', 'n', co.id);
        else if (res === 'cash') askBuy(co, m, e, n, cost, 'Put in cash for ' + e.n.toLowerCase());
        return;
      }
      /* worn out: service it, or replace it when it is past its life */
      const q = co.eq[e.id];
      if (!q || !(q.n > 0) || q.cond == null || q.cond >= 0.35 || q.sub) return;
      const old = (q.age || 0) >= (q.life || e.life || 5);
      const rr = recOf(co, e);
      if (old && rr && !rr.veh) {
        const cost = rr.price * Math.round(q.n);
        if (cost > L.v) return askBuy(co, m, e, Math.round(q.n), cost, 'Replace ' + e.n.toLowerCase());
        if (replaceKit(co, e, Math.round(q.n), rr) === 'ok') note(m.name + ' replaced worn-out ' + e.n.toLowerCase() + ' at ' + co.name + ' (' + mshort(cost) + ')' + by + '.', 'n', co.id);
      } else {
        const c = Math.round((q.cost || 0) * 0.04);
        if (c <= Math.max(L.v, KC(5000))) { payCo(co, c, 'oth', 'Equipment service'); q.cond = Math.min(1, q.cond + 0.3); }
      }
    });
  }
  R39.mgrKit = mgrKit;
  if (typeof hireWorker === 'function') {
    const hw0 = hireWorker;
    hireWorker = function (co) { const r = hw0.apply(this, arguments); try { if (r === 'ok' && co && co.mgr) setTimeout(() => { try { mgrKit(co); } catch (e) { } }, 0); } catch (e) { } return r; };
  }
  const rd39 = window.R10DAY;
  window.R10DAY = function (d) {
    const r = rd39 ? rd39.apply(this, arguments) : undefined;
    try { if (!ui.untl || d === 0) live().filter(c => c.mgr && c.st === 'open').forEach(mgrKit); } catch (e) { console.error(e); }
    return r;
  };

  /* ================= 4. business customers: your discount, their profile, their services ================= */
  const DISC = [0, 5, 10, 15, 20, 30, 40];
  const SUPT = ['cleaning', 'hardware', 'trucking', 'courier', 'bakery', 'brewery', 'farm', 'furniture', 'webdev', 'mktg', 'staffing'];
  const OTHT = ['law', 'acctfirm', 'engcons', 'hotel', 'factory', 'construction', 'realdev', 'gym', 'insco', 'shipping'];
  function acc39(a) {
    if (!a.t) {
      const h = Math.abs(fbHash(String(a.id) + ':t'));
      const L = (h % 10) < 6 ? SUPT : OTHT;
      a.t = L.filter(x => BD[x])[h % L.filter(x => BD[x]).length] || 'cleaning';
    }
    if (a.disc == null) {
      /* the old automatic terms become the discount you start from */
      const old = [0, 0, 0, 5, 10, 20, 30, 40][Math.min(7, relIdx(a.rel || 0))];
      a.disc = old;
    }
    if (a.tu == null) { a.tu = (a.lastU || 0) * Math.max(0, S.week - (a.w0 || S.week)); a.tr = 0; }
    return a;
  }
  R39.acc = acc39;
  if (typeof acctPm === 'function') {
    acctPm = function (a, cr) { acc39(a); return Math.max(Math.max(0.2, cr * 1.015), 1 - (a.disc || 0) / 100); };
  }
  if (typeof acctVol === 'function') {
    const av0 = acctVol;
    acctVol = function (a, Dp) { return av0.apply(this, arguments) * (1 + ((a.disc || 0) / 100) * 0.8); };
  }
  if (typeof acctRev === 'function') {
    const ar0 = acctRev;
    acctRev = function (co, ctx) {
      const r = ar0.apply(this, arguments);
      try { (co.accts || []).forEach(a => { acc39(a); a.tu = (a.tu || 0) + (a.lastU || 0); a.tr = (a.tr || 0) + (a.lastU || 0) * (ctx.price || 0) * (a.lastPm != null ? a.lastPm : 1); }); } catch (e) { }
      return r;
    };
  }
  R7.afterWeek = R7.afterWeek || [];
  R7.afterWeek.push(() => {
    try {
      live().forEach(co => (co.accts || []).forEach(a => {
        acc39(a);
        /* a discount warms the relationship; full price for a long time cools it a little */
        if (a.disc > 0) a.rel = Math.min(100, a.rel + 0.05 * a.disc * (1 - Math.pow(a.rel / 100, 1.6)));
        else if (a.rel > 40 && S.week - (a.w0 || 0) > 26) a.rel = Math.max(36, a.rel - 0.15);
      }));
    } catch (e) { console.error(e); }
  });
  const KIND = () => (window.R27 && R27.KINDS) || {};
  const kindOfTrade = t => Object.keys(KIND()).find(k => KIND()[k].sup.indexOf(t) >= 0);
  function custList(co, bd) {
    const ac = (co.accts || []).map(acc39);
    if (!ac.length) return card('<p class="muted small">No business customers yet. Larger companies approach you once your name is known.</p>');
    return '<div class="lrows">' + ac.map(a => '<button class="lrow" data-a="acc39" data-p="' + P({ id: co.id, a: a.id }) + '"><span class="av">' + esc(String(a.name).split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase()) + '</span><span class="ctext"><b>' + esc(a.name) + '</b><small>' + esc(BD[a.t] ? BD[a.t].n : 'Business') + ' · ' + esc(relWord(a.rel)) + (a.lastU ? ' · ' + esc(window.rateW ? window.rateW(a.lastU, bd.unit) : Math.round(a.lastU) + ' a week') : '') + '</small></span>' + pillp(a.disc ? '−' + a.disc + '%' : 'Full price', a.disc ? 'amb' : '') + '</button>').join('') + '</div>';
  }
  if (window.dealPart) {
    const dp39 = window.dealPart;
    window.dealPart = function (co, bd, k) { if (k === 'cust') { try { return custList(co, bd); } catch (e) { console.error(e); } } return dp39.apply(this, arguments); };
  }
  /* venues have business customers too: show them in Sales */
  const cli39 = CT.cli;
  CT.cli = function (co, bd) {
    let h = cli39.apply(this, arguments);
    try { if (bd.fam === 'venue' && acctOk(co) && (co.accts || []).length && h.indexOf('Clients with agreements') < 0) h += '<h2 class="sec">Clients with agreements</h2>' + custList(co, bd); } catch (e) { }
    return h;
  };
  ACT.acc39 = p => {
    const co = getCo(p.id), a = co && (co.accts || []).find(x => x.id === p.a);
    if (!a) return;
    acc39(a);
    const bd = BD[co.type], k = kindOfTrade(a.t), K = k && KIND()[k], ok = relIdx(a.rel) >= 2;
    const unitN = n => (window.fmtU ? window.fmtU(n, bd.unit) : Math.round(n) + ' ' + unitPl(bd.unit, n));
    let h = '<h2>' + esc(a.name) + '</h2><p class="muted small">' + esc(BD[a.t] ? BD[a.t].n : 'Business') + ' · ' + esc(cityOf(co.city).name) + ' · customer since ' + dateStr(a.w0 || S.week) + '</p>';
    h += '<div class="tri"><div><span>Bought</span><b>' + esc(unitN(a.tu || 0)) + '</b></div><div><span>Paid you</span><b>' + mshort(a.tr || 0) + '</b></div><div><span>A week now</span><b>' + esc(unitN(a.lastU || 0)) + '</b></div></div>';
    h += row('Relationship', esc(relWord(a.rel))) + row('They pay', a.disc ? (100 - a.disc) + '% of your price' : 'Your full price');
    h += '<div class="kv"><span>Your discount to them</span><b></b></div><div class="d39">' + DISC.map(v => '<button class="btn chip' + (a.disc === v ? ' primary' : '') + '" data-a="acc39d" data-p="' + P({ id: co.id, a: a.id, v }) + '">' + v + '%</button>').join('') + '</div>';
    h += '<span class="tipt">A discount comes off every order. It brings more orders and warms the relationship faster. Nobody gets it for free just for staying.</span>';
    if (K) h += '<div class="note' + (ok ? '' : ' bad') + '">' + (ok ? 'They sell ' + esc(K.n.toLowerCase()) + '. You can buy from them in a company’s Supply chain and compare with what you have.' : 'They sell ' + esc(K.n.toLowerCase()) + '. Get to know them better (familiar or closer) and you can buy from them.') + '</div>';
    h += '<div class="two">' + btn('Dinner · ' + mshort(Math.round(6000 * costIdx(co.country))), 'acctmeet', { id: co.id, a: a.id }, 'wide') + btn('End contract', 'acctdrop', { id: co.id, a: a.id }, 'ghost wide') + '</div>' + btn('Close', 'sheetclose', undefined, 'ghost wide');
    openSheet(h, 'acc39s');
  };
  ACT.acc39d = p => {
    const co = getCo(p.id), a = co && (co.accts || []).find(x => x.id === p.a);
    if (!a) return;
    a.disc = p.v;
    save();
    ACT.acc39({ id: p.id, a: p.a });
  };
  /* their services in your supply chain */
  const L39 = () => (S.l39 = S.l39 || []);
  const accById = id => { for (const c of S.cos) { const a = (c.accts || []).find(x => x.id === id); if (a) return { a, c }; } return null; };
  const theirPf = a => 1 - Math.min(0.2, 0.02 + relDisc(a.rel) + (a.disc || 0) / 400);
  function custSuppliers(co, k) {
    const K = KIND()[k];
    if (!K) return [];
    const out = [];
    S.cos.filter(c => c.st === 'open' && c.country === co.country && (!K.local || c.city === co.city)).forEach(c => (c.accts || []).forEach(a => { acc39(a); if (K.sup.indexOf(a.t) >= 0) out.push({ a, c }); }));
    return out;
  }
  if (ACT.ch27k) {
    const ck0 = ACT.ch27k;
    ACT.ch27k = p => {
      ck0(p);
      try {
        const co = getCo(p.id), L = custSuppliers(co, p.k);
        if (!L.length || !ui.sheet) return;
        const cur = L39().find(l => l.b === co.id && l.k === p.k);
        const K = KIND()[p.k], spend = Math.max(0, (co.lastW ? co.lastW.rev || 0 : 0) * (K.b[co.type] || 0)) * 52;
        const sec = '<h3>Your business customers</h3>' + L.map(({ a, c }) => {
          const ok = relIdx(a.rel) >= 2, pf = theirPf(a);
          return '<div class="opt"><div class="bhead"><div><b>' + esc(a.name) + '</b><small>' + esc(relWord(a.rel)) + ' · buys from ' + esc(c.name) + '</small></div>' + (cur && cur.a === a.id ? pillp('Current', 'grn') : pillp(Math.round((1 - pf) * 100) + '% below', 'amb')) + '</div>' + (ok ? row('Saves against outside', mshort(spend * (1 - pf)) + ' a year') + (cur && cur.a === a.id ? '' : btn('Buy from ' + esc(a.name), 'ch39set', { id: co.id, k: p.k, a: a.id }, 'chip primary')) : '<span class="tipt">Get to know them better first (familiar or closer).</span>') + '</div>';
        }).join('') + (cur ? btn('Stop buying from them', 'ch39off', { id: co.id, k: p.k }, 'wide') : '');
        ui.sheet.html = ui.sheet.html.replace(/(<button[^>]*data-a="sheetclose")/, sec + '$1');
        render();
      } catch (e) { console.error(e); }
    };
  }
  ACT.ch39set = p => {
    const co = getCo(p.id), x = accById(p.a);
    if (!co || !x) return;
    S.l27 = (S.l27 || []).filter(l => !(l.b === co.id && l.k === p.k));
    S.l39 = L39().filter(l => !(l.b === co.id && l.k === p.k));
    L39().push({ id: uid(), k: p.k, b: co.id, a: p.a, w0: S.week });
    closeSheet(); save(); render(true);
    toast(x.a.name + ' now supplies ' + KIND()[p.k].n.toLowerCase() + ' to ' + co.name + '.');
  };
  ACT.ch39off = p => { S.l39 = L39().filter(l => !(l.b === p.id && l.k === p.k)); closeSheet(); save(); render(true); };
  if (ACT.ch27set) { const cs0 = ACT.ch27set; ACT.ch27set = p => { S.l39 = L39().filter(l => !(l.b === p.id && l.k === p.k)); return cs0(p); }; }
  R7.afterWeek.push(() => {
    try {
      L39().slice().forEach(l => {
        const b = getCo(l.b), x = accById(l.a), K = KIND()[l.k];
        if (!b || !K || b.st === 'sold' || b.st === 'bust') { S.l39 = L39().filter(y => y !== l); return; }
        if (!x) { S.l39 = L39().filter(y => y !== l); note('Your business customer stopped supplying ' + K.n.toLowerCase() + ' to ' + b.name + '. It buys outside again.', 'bad', b.id); return; }
        if (b.st !== 'open') return;
        const spend = Math.max(0, (b.lastW ? b.lastW.rev || 0 : 0) * (K.b[b.type] || 0)), pf = theirPf(x.a), sv = spend * (1 - pf);
        if (sv > 0) { coIn(b, sv, null, null); bk(b, K.cat, -sv); }
        l.save = (l.save || 0) + sv;
        x.a.rel = Math.min(100, x.a.rel + 0.3 * (1 - Math.pow(x.a.rel / 100, 1.6)));
      });
    } catch (e) { console.error(e); }
  });
  const sc39 = V.chain27;
  if (sc39) V.chain27 = function (p) {
    let h = sc39.apply(this, arguments);
    try {
      const L = L39().filter(l => l.b === p.id);
      if (L.length) h += '<h2 class="sec">From your business customers</h2><div class="lrows">' + L.map(l => { const x = accById(l.a); return '<button class="lrow" data-a="ch27k" data-p="' + P({ id: p.id, k: l.k }) + '"><span class="av">' + esc(x ? String(x.a.name).split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase() : '?') + '</span><span class="ctext"><b>' + esc(x ? x.a.name : 'Gone') + '</b><small>' + esc(KIND()[l.k].n) + ' · saved ' + mshort(l.save || 0) + ' so far</small></span>' + pillp('Partner', 'grn') + '</button>'; }).join('') + '</div>';
    } catch (e) { console.error(e); }
    return h;
  };

  /* a favour that lowers your loan costs shows in the bank */
  const bk39 = V.bank;
  if (bk39) V.bank = function () {
    let h = bk39.apply(this, arguments);
    try {
      const L = S.net31 && S.net31.loanCut;
      if (L && S.week < L.until) { const i = h.indexOf('</div>', h.indexOf('<div class="subtabs">')) + 6; h = h.slice(0, i) + '<div class="note">A favour from your banker: all your loans cost half a percentage point less until ' + dateStr(L.until) + '.</div>' + h.slice(i); }
    } catch (e) { }
    return h;
  };
  /* after a dinner the customer card shows the new relationship */
  if (ACT.acctmeet) { const am0 = ACT.acctmeet; ACT.acctmeet = p => { const open = ui.sheet && /acc39s/.test(ui.sheet.cls || ''); am0(p); if (open) ACT.acc39({ id: p.id, a: p.a }); }; }
})();

path = '/home/claude/w3/ledger.html'
T = '/home/claude/w3/tools/'
t = open(path, encoding='utf8').read()
mark = '/* ---------- no zooming: pinch, double tap, ctrl+wheel, ctrl +/- ---------- */'
assert t.count(mark) == 1
t = t.replace(mark, open(T + 'round13.js', encoding='utf8').read() + '\n' + open(T + 'round14.js', encoding='utf8').read() + '\n' + open(T + 'round15.js', encoding='utf8').read() + '\n' + mark)
i = t.rindex('</style>')
t = t[:i] + open(T + 'round13.css', encoding='utf8').read() + '\n.t15 { grid-template-columns: minmax(0, 1.3fr) minmax(0, .5fr) minmax(0, 1.4fr); }\n.t15 > span:not(:first-child) { text-align: left; }\n' + t[i:]
open(path, 'w', encoding='utf8').write(t)
print('patch14 ok')

/* ===== Round 31: the world around you.
   4A/B  Milestones: the full-screen moment shows where you stood; every milestone is also a clipping from the local paper on the trophy wall.
   5A    Rivals remember: each rival owner has a temperament, a memory of what you did to them, a mood towards you and a likely next move.
   6A    Public image: how the press, bankers, staff, rivals, the city and customers see you, in words, with what it opens and risks.
   7A/B/D People you know: contacts by role, a network web, and a ledger of favours owed and promises open. Favours are never guaranteed.
   8A/B/C Maps: ownership tree, presence by city, circles of influence. Static and vertical.
   9A    The business paper is a local paper named after your city.
   10    When a week ends, cash, shares, revenue, profit and net worth count up to their new values, with the change from last week,
         and each one opens the calculation behind it. ===== */
window.R31 = window.R31 || {};
(function () {
  const R31 = window.R31;
  const U = window.UI, { ui, V, ACT, esc, row, btn, card, go, render, save, toast, svg, openSheet } = U;
  const P = o => esc(JSON.stringify(o));
  const pillp = (t, c) => '<span class="pill ' + (c || '') + '">' + t + '</span>';
  const ini = n => String(n || '?').replace(/[^\p{L}0-9 ]/gu, ' ').trim().split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase() || '?';
  const live = () => S.cos.filter(c => c.st !== 'sold' && c.st !== 'bust');
  const sgn = v => v > 0 ? 'pos' : v < 0 ? 'neg' : '';
  const plus = v => (v >= 0 ? '+' : '−') + mshort(Math.abs(v));
  const hsh = s => { let h = 7; s = String(s); for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0; return Math.abs(h); };
  const C0 = () => CO[S.country] || CC();
  const city0 = () => cityOf((S.player && S.player.city) || (C0().cities[0] || {}).id) || C0().cities[0] || { name: 'the city' };

  /* ---------- 9A: a local paper ---------- */
  const NO_P = { Oslo: 'Osloposten', Bergen: 'Bergensposten', Trondheim: 'Trondheimsposten', Stavanger: 'Stavangerposten', Kristiansand: 'Kristiansandsposten', Tromsø: 'Tromsøposten', Drammen: 'Drammensposten', Fredrikstad: 'Fredrikstadposten', Bodø: 'Bodøposten', Ålesund: 'Ålesundsposten' };
  const LT_G = { Vilnius: 'Vilniaus', Kaunas: 'Kauno', Klaipėda: 'Klaipėdos', Šiauliai: 'Šiaulių', Panevėžys: 'Panevėžio', Alytus: 'Alytaus' };
  const PL_G = { Warszawa: 'Warszawy', Warsaw: 'Warszawy', Kraków: 'Krakowa', Wrocław: 'Wrocławia', Gdańsk: 'Gdańska', Poznań: 'Poznania', Łódź: 'Łodzi', Szczecin: 'Szczecina', Lublin: 'Lublina' };
  const DE_A = { Berlin: 'Berliner', München: 'Münchner', Munich: 'Münchner', Hamburg: 'Hamburger', Köln: 'Kölner', Cologne: 'Kölner', Frankfurt: 'Frankfurter', Stuttgart: 'Stuttgarter', Düsseldorf: 'Düsseldorfer', Leipzig: 'Leipziger', Dresden: 'Dresdner' };
  const ltGen = n => LT_G[n] || (/as$/.test(n) ? n.slice(0, -2) + 'o' : /us$/.test(n) ? n.slice(0, -2) + 'aus' : /ys$/.test(n) ? n.slice(0, -2) + 'io' : /a$/.test(n) ? n.slice(0, -1) + 'os' : /ė$/.test(n) ? n.slice(0, -1) + 'ės' : n);
  R31.paperName = () => {
    const n = city0().name || '', c = S.country;
    if (!n) return null;
    if (c === 'NO') return NO_P[n] || n + 'posten';
    if (c === 'SE') return n + (/s$/.test(n) ? '' : 's') + '-Kuriren';
    if (c === 'DK') return n + 's Dagblad';
    if (c === 'LT') return ltGen(n) + ' žinios';
    if (c === 'PL') return 'Kurier ' + (PL_G[n] || n);
    if (c === 'DE') return (DE_A[n] || n + 'er') + ' Tageblatt';
    if (c === 'FR') return 'Le Courrier de ' + n;
    if (c === 'ES') return 'El Diario de ' + n;
    if (c === 'NL') return 'Dagblad van ' + n;
    if (c === 'BR') return 'Diário de ' + n;
    if (c === 'KR') return n + ' Ilbo';
    if (c === 'JP') return 'The ' + n + ' Shimbun';
    if (c === 'UK') return 'The ' + n + ' Courier';
    if (c === 'AU') return 'The ' + n + ' Chronicle';
    return 'The ' + n + ' Ledger';
  };

  /* ---------- 4A/4B: milestones ---------- */
  function stamp() {
    const a = S.ach28 || {};
    Object.keys(a).forEach(k => {
      const r = a[k];
      if (r.ctx31 || r.old) return;
      let nw = 0;
      try { nw = netWorth().total; } catch (e) { }
      r.ctx31 = { nw, cos: live().length, ppl: sum(live(), c => (c.staff || []).length + (c.mgr ? 1 : 0)), paper: R31.paperName() };
    });
  }
  R31.celExtra = (id, r) => {
    try {
      stamp();
      const x = r.ctx31;
      if (!x) return '';
      return '<div class="tri cel31"><div><span>Net worth</span><b>' + mshort(x.nw) + '</b></div><div><span>Companies</span><b>' + x.cos + '</b></div><div><span>People</span><b>' + x.ppl + '</b></div></div><small class="clipsrc31">Front page of ' + esc(x.paper || 'the paper') + '</small>';
    } catch (e) { return ''; }
  };
  const tw0 = V.trophies28;
  if (tw0) V.trophies28 = function () {
    let h = tw0.apply(this, arguments);
    try {
      stamp();
      const a = S.ach28 || {}, ACH = (window.R28 && R28.ACH) || [];
      const L = ACH.filter(x => a[x[0]]).map(x => [x, a[x[0]]]).sort((p, q) => q[1].w - p[1].w);
      if (!L.length) return h;
      const sur = String((S.player && S.player.name) || '').split(' ').pop();
      h = '<h2 class="sec first">Clippings</h2><div class="clips31">' + L.map(([x, r]) => '<button class="clip31" data-a="tw28" data-p="' + P({ id: x[0] }) + '"><span class="ms31">' + esc((r.ctx31 && r.ctx31.paper) || R31.paperName() || 'The paper') + '</span><small>' + (r.old ? 'From the archive' : esc(dateStr(r.w))) + '</small><b>' + esc(sur + ': ' + x[1].charAt(0).toLowerCase() + x[1].slice(1)) + '</b><span>' + esc(r.t) + '</span></button>').join('') + '</div><h2 class="sec">All milestones</h2>' + h;
    } catch (e) { console.error(e); }
    return h;
  };

  /* ---------- 5A: rivals remember ---------- */
  const TEMP = [['Proud', 'takes things personally'], ['Calm', 'thinks before acting'], ['Hot-headed', 'hits back fast'], ['Calculating', 'waits for the right moment'], ['Old-school', 'values a handshake'], ['Ambitious', 'wants to be number one']];
  const GRUDGE = [['Forgives quickly', 0.92], ['Holds a grudge', 0.97], ['Never forgets', 1]];
  const tempOf = r => TEMP[hsh(r.id) % TEMP.length];
  const grudgeOf = r => GRUDGE[hsh(r.id + 'g') % GRUDGE.length];
  function remember(r, t, d) {
    r.mem31 = r.mem31 || [];
    r.mem31.unshift({ w: S.week, t, d });
    if (r.mem31.length > 20) r.mem31.length = 20;
    const hot = tempOf(r)[0] === 'Hot-headed' || tempOf(r)[0] === 'Proud' ? 1.3 : 1;
    r.rel = clamp((r.rel || 40) + d * (d < 0 ? hot : 1), 0, 100);
    if (!r.n31) r.n31 = S.week;
  }
  /* round 37: a rival only knows you once you cross paths or take a real share of their customers */
  const known = r => !!r.n31;
  R31.known = known;
  R31.remember = remember;
  const moodOf = r => { if (!known(r)) return ['Has not noticed you', '']; const x = r.rel || 40; return x < 22 ? ['Bitter', 'red'] : x < 36 ? ['Wary', 'amb'] : x < 50 ? ['Neutral', ''] : x < 64 ? ['Respectful', 'grn'] : ['Friendly', 'grn']; };
  function nextMove(r) {
    const m = moodOf(r)[0], t = tempOf(r)[0];
    if (!known(r)) return 'They do not know you yet. That changes when you take a real share of their customers, or cross them.';
    if (m === 'Bitter') return t === 'Calculating' ? 'Likely waiting for a weak moment: a bad review week or a staff crisis.' : 'Likely to hit back: a price cut, poaching your people, or a bid for your customers.';
    if (m === 'Wary') return t === 'Hot-headed' ? 'Could start a price war over a small thing.' : 'Watching you closely. One more push and it turns personal.';
    if (m === 'Respectful') return t === 'Old-school' || t === 'Calm' ? 'Might suggest working together, or selling to you one day.' : 'Competes hard but fair.';
    if (m === 'Friendly') return 'Open to deals: shared suppliers, referrals, maybe a sale.';
    return 'Getting to know you. What you do next decides how this goes.';
  }
  function rivalsAll() {
    const out = [];
    live().forEach(co => {
      if (co.st !== 'open') return;
      const k = mkKey(co), m = S.mk && S.mk[k];
      if (!m || !m.riv) return;
      m.riv.forEach(r => { if (!out.some(x => x.r === r)) out.push({ r, k, co }); });
    });
    return out;
  }
  R31.rivalsAll = rivalsAll;
  /* weekly: what they notice */
  function rivalWeek() {
    rivalsAll().forEach(({ r, k, co }) => {
      const g = grudgeOf(r)[1];
      /* old memories fade unless they never forget; mood drifts back slowly */
      if (r.mem31 && r.mem31.length && g < 1 && chance(1 - g)) r.mem31.pop();
      if (!r.m37) { r.m37 = 1; if (r.mem31) { const old = r.mem31.length; r.mem31 = r.mem31.filter(m => !/^You opened /.test(m.t)); if (r.mem31.length < old) r.rel = clamp((r.rel || 40) + 2, 0, 100); } if (!r.n31 && r.mem31 && r.mem31.length) r.n31 = r.mem31[r.mem31.length - 1].w; }
      if (!r.n31 && window.R27 && R27.noticed && R27.noticed(co)) { r.n31 = S.week; remember(r, co.name + ' is taking customers from them in ' + cityOf(co.city).name + '.', -2); }
      if (co.flags && co.flags.pw && r.pw31 !== co.flags.pw) { r.pw31 = co.flags.pw; remember(r, 'You started a price war with ' + co.name + '.', -8); }
      if ((co.price || 0) <= -1 && !r.cheap31) r.cheap31 = S.week;
      if ((co.price || 0) <= -1 && r.cheap31 && S.week - r.cheap31 === 4) remember(r, 'You kept ' + co.name + '’s prices below theirs for a month.', -3);
      if ((co.price || 0) > -1 && r.cheap31) r.cheap31 = 0;
      const rv = (co.rvN || 0) >= 30 ? ratingOf(co) : 0;
      if (rv >= 4.5 && !r.rv31 && known(r)) { r.rv31 = 1; remember(r, co.name + ' beat them on reviews: ' + rv.toFixed(1) + ' stars.', -2); }
    });
  }
  const mr0 = window.meetRival;
  if (typeof mr0 === 'function') meetRival = function (co, r) {
    const res = mr0.apply(this, arguments);
    try { if (res === 'ok' || res === true || res === undefined) remember(r, 'Had lunch with you.', 4); } catch (e) { }
    return res;
  };
  R7.afterWeek = R7.afterWeek || [];
  R7.afterWeek.push(() => { try { rivalWeek(); netWeek(); } catch (e) { console.error(e); } });
  V.titles.riv31 = 'Rival';
  V.heads.riv31 = p => { const x = rivalsAll().find(y => y.r.id === p.id); return x ? { t: x.r.owner, sub: 'Owner of ' + esc(x.r.name), right: pillp(moodOf(x.r)[0], moodOf(x.r)[1]) } : { t: 'Rival' }; };
  V.riv31 = function (p) {
    const x = rivalsAll().find(y => y.r.id === p.id);
    if (!x) return card('This rival is no longer in your markets.');
    const r = x.r, t = tempOf(r), g = grudgeOf(r), md = moodOf(r);
    let h = '<div class="card"><div class="cchd"><span class="av">' + esc(ini(r.owner)) + '</span><span class="ctext"><b>' + esc(r.owner) + '</b><small>' + esc(r.name) + ' · ' + esc(cityOf(x.co.city).name) + ' · against your ' + esc(x.co.name) + '</small></span>' + pillp(md[0], md[1]) + '</div><div class="chips">' + pillp(t[0]) + pillp(g[0]) + '</div><span class="tipt">' + esc(r.owner.split(' ')[0]) + ' ' + t[1] + '. ' + (g[1] >= 1 ? 'Nothing you do is ever forgotten.' : g[1] > 0.95 ? 'Old wrongs fade slowly.' : 'Old wrongs fade fast.') + '</span></div>';
    h += '<h2 class="sec">How they see you</h2><div class="card"><div class="bhead"><b>' + md[0] + '</b><small>' + (known(r) ? 'Relationship: ' + esc(relW(r.rel || 40).toLowerCase()) : 'You have not met') + '</small></div><span class="tipt">' + esc(nextMove(r)) + '</span></div>';
    const M = r.mem31 || [];
    h += '<h2 class="sec">They remember</h2>' + (M.length ? '<div class="card tl31">' + M.slice(0, 10).map(m => '<div class="te31"><i class="' + (m.d > 0 ? 'g' : m.d < 0 ? 'r' : '') + '"></i><span class="ctext"><b class="wrap">' + esc(m.t) + '</b><small>' + dateStr(m.w) + '</small></span></div>').join('') + '</div>' : '<div class="calm">Nothing yet. You have not crossed paths.</div>');
    h += btn('Invite to lunch', 'riv31meet', { id: r.id }, 'wide');
    return h;
  };
  ACT.riv31meet = p => {
    const x = rivalsAll().find(y => y.r.id === p.id);
    if (!x) return;
    const r0 = typeof meetRival === 'function' ? meetRival(x.co, x.r) : 'no';
    save();
    render();
    toast(r0 === 'wait' ? 'You met recently. Give it a few weeks.' : r0 === 'cash' ? 'Not enough cash for the lunch.' : 'You had lunch with ' + x.r.owner + '.', r0 === 'wait' || r0 === 'cash');
  };
  const rv31 = V.rivals;
  if (rv31) V.rivals = function () {
    let h = rv31.apply(this, arguments);
    try {
      const L = rivalsAll();
      if (L.length) h += '<h2 class="sec">Owners you compete with</h2><div class="lrows">' + L.slice(0, 12).map(({ r, co }) => { const md = moodOf(r); return '<button class="lrow" data-a="go" data-p="' + P({ n: 'riv31', p: { id: r.id } }) + '"><span class="av">' + esc(ini(r.owner)) + '</span><span class="ctext"><b>' + esc(r.owner) + '</b><small>' + esc(r.name) + ' · ' + esc(tempOf(r)[0]) + (r.mem31 && r.mem31[0] ? ' · ' + esc(r.mem31[0].t) : '') + '</small></span>' + pillp(md[0], md[1]) + '</button>'; }).join('') + '</div>';
    } catch (e) { console.error(e); }
    return h;
  };

  /* ---------- 6A: public image ---------- */
  const W5 = (x, w) => w[x >= 75 ? 4 : x >= 58 ? 3 : x >= 42 ? 2 : x >= 25 ? 1 : 0];
  function image() {
    const pr = (S.pr28 && S.pr28.img) || { trust: 50, bold: 50, care: 50 };
    const cos = live().filter(c => c.st === 'open');
    const avg = (a, f, d) => a.length ? sum(a, f) / a.length : d;
    const give = window.R28 && R28.giveCount ? R28.giveCount() : 0;
    const late = sum(cos, c => (c.pr29 && c.pr29.late && c.pr29.late.why !== 'slip') ? 1 : 0);
    const fines = sum(live(), c => (c.bk && c.bk.t && c.bk.t.fine) || 0) > 0 ? Math.min(5, sum(live(), c => (c.bk && c.bk.t && c.bk.t.fine) ? 1 : 0)) : 0;
    const R = rivalsAll(), nm = S.nem28;
    const pw = sum(cos, c => c.flags && c.flags.pw ? 1 : 0), buys = window.R27 && R27.amb ? (R27.amb().cnt.buy || 0) : 0;
    let nw = 0; try { nw = netWorth().total; } catch (e) { }
    const g = {
      press: (pr.trust + pr.care + pr.bold) / 3 + Math.min(10, give * 3) - fines * 4,
      bank: (S.credit != null ? S.credit : 50) - late * 6,
      staff: avg(cos, c => c.mood != null ? c.mood : 60, 55) - late * 12,
      rivals: R.some(x => known(x.r)) || nm ? avg(R.filter(x => known(x.r)), x => x.r.rel || 40, 45) + (nm ? (nm.w - nm.l) * 2 : 0) : null,
      city: 40 + give * 9 - fines * 6 + Math.min(12, cos.length * 2),
      public: avg(cos, c => c.rep || 50, 50) + give * 2
    };
    const agg = pw * 2 + buys * 2 + (nm && nm.w > nm.l ? 2 : 0) + Math.min(6, sum(R, x => Math.min(2, (x.r.mem31 || []).filter(m => m.d <= -3).length)) * 0.5);
    const con = fines * 2 + late * 3 + sum(cos, c => (c.rvN || 0) >= 20 && ratingOf(c) < 3.2 ? 1 : 0) * 2 + (pr.trust < 40 ? 2 : 0);
    const gen = give * 2.5 + (pr.care > 60 ? 2 : 0);
    const suc = nw > KC(10e6) ? 3 : nw > KC(1e6) ? 2 : cos.length ? 1 : 0;
    let lab;
    if (!cos.length && nw < KC(500000)) lab = ['Unknown newcomer', 'Few people have heard of you yet.', 'Every door is open, but nobody is holding one for you.', 'Nothing yet.'];
    else if (con >= 5 && con >= agg && con >= gen) lab = ['Controversial tycoon', 'People talk about you, and not kindly.', 'Bold deals still happen: some partners like a fighter.', 'Journalists dig, staff hesitate to join, councils say no first.'];
    else if (agg >= 5 && agg >= gen) lab = ['Aggressive dealmaker', 'Feared and watched. Rivals expect a fight.', 'Sellers call you first; weak rivals fold faster.', 'Rivals gang up, poach your people and hit back.'];
    else if (gen >= 5) lab = ['Respected philanthropist', 'Known for what you give back.', 'Councils, the press and good people listen to you.', 'People expect you to give again; stopping is noticed.'];
    else if (suc >= 2) lab = ['Self-made entrepreneur', 'Admired for building it yourself.', 'Banks, investors and talent come to you.', 'A big failure would be news.'];
    else lab = ['Up-and-coming owner', 'Small but noticed.', 'People are curious about what you do next.', 'One bad story can define you.'];
    return { g, lab, agg, con, gen };
  }
  R31.image = image;
  const GW = {
    press: ['Hostile', 'Sceptical', 'Neutral', 'Positive', 'Admiring'],
    bank: ['Avoid you', 'Cautious', 'Neutral', 'Trust you', 'Compete for you'],
    staff: ['Want out', 'Unhappy', 'Okay', 'Loyal', 'Proud to work for you'],
    rivals: ['Resent you', 'Wary', 'Neutral', 'Respect you', 'Friendly'],
    city: ['Want you gone', 'Sceptical', 'Hardly know you', 'Value you', 'See you as a pillar'],
    public: ['Avoid your places', 'Mixed', 'Fine', 'Like you', 'Love your places']
  };
  const GN = { press: 'The press', bank: 'Bankers', staff: 'Your staff', rivals: 'Rivals', city: 'The city council', public: 'Customers' };
  V.titles.img31 = 'Public image';
  V.heads.img31 = () => ({ t: 'Public image', sub: 'How people see you, not your companies' });
  V.img31 = function () {
    const I = image();
    let h = '<div class="card img31"><small>Seen as</small><h2>' + esc(I.lab[0]) + '</h2><span class="tipt">' + esc(I.lab[1]) + '</span></div>';
    h += '<div class="duo"><div><span>Opens</span><b class="wrap31">' + esc(I.lab[2]) + '</b></div><div><span>Risks</span><b class="wrap31">' + esc(I.lab[3]) + '</b></div></div>';
    h += '<h2 class="sec">By group</h2><div class="card">' + Object.keys(GN).map(k => row(GN[k], esc(I.g[k] == null ? 'Do not know you yet' : W5(I.g[k], GW[k])))).join('') + '</div>';
    h += '<div class="note">Built from what you actually do: interviews, giving back, how you pay and treat staff, fines, price wars and buyouts, and what your customers say. It shifts slowly. The groups also decide how likely people are to do you a favour.</div>';
    return h;
  };

  /* ---------- 7: people you know, favours and promises ---------- */
  const NET = () => (S.net31 = S.net31 || { g: {}, f: [], ask: -99, n: 0 });
  const nm2 = () => pick(C0().first) + ' ' + pick(C0().last);
  function gen(key, role, org, base) {
    const N = NET();
    if (!N.g[key]) N.g[key] = { id: 'g:' + key, name: nm2(), role, org, adj: 0, base };
    N.g[key].org = org;
    return N.g[key];
  }
  const ROLE_ORDER = ['Executives', 'Investors', 'Bankers', 'Lawyers', 'Journalists', 'Politicians', 'Suppliers', 'Rival owners'];
  function roster() {
    const out = [], I = image().g;
    live().forEach(co => { if (co.mgr && S.npcs[co.mgr]) out.push({ id: 'mgr:' + co.id, name: S.npcs[co.mgr].name, role: 'Executives', org: titleFor(co, 'mgr') + ', ' + co.name, rel: clamp((co.mood != null ? co.mood : 60) + 4, 0, 100), co }); });
    if (live().length) {
      const j = gen('press', 'Journalists', R31.paperName() || 'the paper'), b = gen('bank', 'Bankers', 'Business adviser at your bank'), pol = gen('pol', 'Politicians', 'City council, ' + city0().name);
      out.push({ id: j.id, name: j.name, role: j.role, org: j.org, rel: clamp(20 + I.press * 0.6 + j.adj, 0, 100), g: j });
      out.push({ id: b.id, name: b.name, role: b.role, org: b.org, rel: clamp(15 + I.bank * 0.6 + b.adj, 0, 100), g: b });
      out.push({ id: pol.id, name: pol.name, role: pol.role, org: pol.org, rel: clamp(10 + I.city * 0.55 + pol.adj, 0, 100), g: pol });
      const law = live().find(c => c.law);
      const l = gen('law', 'Lawyers', law ? 'Partner at ' + law.law.name : 'Business lawyer');
      out.push({ id: l.id, name: l.name, role: l.role, org: l.org, rel: clamp(30 + l.adj, 0, 100), g: l });
    }
    if (live().some(c => (c.holders || []).some(x => x.pct > 0)) || (S.startups || []).length) {
      const iv = gen('inv', 'Investors', 'Angel investor');
      out.push({ id: iv.id, name: iv.name, role: iv.role, org: iv.org, rel: clamp(30 + iv.adj, 0, 100), g: iv });
    }
    try { knownVendors().filter(v => vrel(v.id) >= 8).slice(0, 6).forEach(v => out.push({ id: 'sup:' + v.id, name: v.owner, role: 'Suppliers', org: 'Owner of ' + v.name, rel: vrel(v.id), v })); } catch (e) { }
    rivalsAll().filter(x => known(x.r)).slice(0, 6).forEach(({ r }) => out.push({ id: 'riv:' + r.id, name: r.owner, role: 'Rival owners', org: 'Owner of ' + r.name, rel: r.rel || 40, r }));
    return out;
  }
  R31.roster = roster;
  function bumpRel(c, d) {
    if (c.g) c.g.adj = clamp((c.g.adj || 0) + d, -60, 60);
    else if (c.r) c.r.rel = clamp((c.r.rel || 40) + d, 0, 100);
    else if (c.v) vbump(c.v.id, d);
    else if (c.co) c.co.mood = clamp((c.co.mood != null ? c.co.mood : 60) + d, 0, 100);
  }
  const ASKS = {
    Journalists: [['wants an exclusive comment on a story about local business', 0, 'a friendly story about one of your companies']],
    Bankers: [['asks you to move part of your savings to the bank this quarter', 0, 'better terms on your next loan']],
    Politicians: [['asks you to sponsor the city summer festival', 25000, 'help with paperwork at the council']],
    Lawyers: [['asks you to recommend the firm to another owner', 0, 'free help with your next fine']],
    Investors: [['asks you to mentor a young founder for an afternoon', 0, 'an introduction that brings business']],
    Suppliers: [['asks you to place a larger order early to help their quarter', 15000, 'a better price from now on']],
    Executives: [['asks for a long weekend off after a hard month', 0, 'extra effort when it counts']],
    'Rival owners': [['asks you to keep out of their part of town this year', 0, 'a truce instead of a fight']]
  };
  function giveWhat(c) {
    const co = live().filter(x => x.st === 'open').sort((a, b) => companyValue(b) - companyValue(a))[0];
    if (c.role === 'Journalists') { if (co) { co.aware = Math.min(100, (co.aware || 0) + 6); co.rep = Math.min(100, (co.rep || 50) + 1); } return 'A friendly story about ' + (co ? co.name : 'you') + ' ran in ' + (R31.paperName() || 'the paper') + '.'; }
    if (c.role === 'Bankers') { const L0 = NET().loanCut; NET().loanCut = { until: Math.max(L0 && L0.until > S.week ? L0.until : S.week, S.week) + 26, cut: 0.005 }; return 'your loans cost half a percentage point less for six months (until ' + dateStr(NET().loanCut.until) + ').'; }
    if (c.role === 'Politicians') { const d = live().map(x => [x, docsMissing(x).filter(k => k !== 'mva_na')]).find(x => x[1].length); if (d) { d[0].docs[d[1][0]] = { st: 'ok', done: S.week, ok: S.week }; return 'A missing permit for ' + d[0].name + ' was sorted out quickly.'; } live().forEach(x => { x.rep = Math.min(100, (x.rep || 50) + 1); }); return 'Good words about you at the council.'; }
    if (c.role === 'Lawyers') { NET().fineCut = 1; return 'Your next fine will be halved.'; }
    if (c.role === 'Investors') { if (co) co.aware = Math.min(100, (co.aware || 0) + 4); return 'An introduction brought ' + (co ? co.name : 'you') + ' new business contacts.'; }
    if (c.role === 'Suppliers') { vbump(c.v.id, 10); return 'Better terms from ' + c.org.replace('Owner of ', '') + '.'; }
    if (c.role === 'Executives') { c.co.mood = clamp((c.co.mood || 60) + 10, 0, 100); return c.name + ' pulls the team through a hard month.'; }
    if (c.role === 'Rival owners') { c.r.rel = clamp((c.r.rel || 40) + 12, 0, 100); return c.name + ' agreed to keep things calm.'; }
    return 'They helped.';
  }
  /* a contact asks now and then; what you answer is remembered */
  function netWeek() {
    const N = NET();
    if (!live().length) return;
    /* broken promises */
    N.f.forEach(f => {
      if (f.k === 'promise' && f.st === 'open' && S.week > f.due) {
        f.st = 'broken';
        const c = roster().find(x => x.id === f.who);
        if (c) { bumpRel(c, -12); if (c.r) remember(c.r, 'You broke a promise to them.', -6); }
        note('You did not keep your promise to ' + f.name + ': ' + f.t + '.', 'bad');
      }
      if (f.k === 'owe' && f.st === 'open' && S.week >= f.due && !f.asked) {
        f.asked = 1;
        addMsg({ kind: 'ask', from: f.name, title: f.name + ' asks you to return the favour', body: 'You owe me one. ' + f.t.charAt(0).toUpperCase() + f.t.slice(1) + '?', opts: [{ l: 'Return the favour', d: '', fx: {} }, { l: 'Not now', d: '', fx: {} }], act: 'fav31', data: { f: f.id, k: 'back' }, exp: S.week + 2 });
      }
    });
    if (S.week - N.ask < 8 || !chance(0.18)) return;
    /* round 39: nobody asks again while they still owe you, or within half a year of their last request */
    N.la = N.la || {};
    const L = roster().filter(c => c.rel >= 22 && ASKS[c.role] && !(N.la[c.id] && S.week - N.la[c.id] < 26) && !N.f.some(f => f.who === c.id && f.st === 'open'));
    if (!L.length) return;
    const c = pick(L), a = ASKS[c.role][0], cost = a[1] ? KC(a[1]) : 0;
    N.ask = S.week;
    N.la[c.id] = S.week;
    addMsg({ kind: 'ask', from: c.name, title: c.name + ' ' + a[0], body: c.org + '. ' + (cost ? 'It would cost about ' + money(cost) + '. ' : '') + 'Helping now means they owe you; a promise must be kept within six weeks; saying no is remembered.', opts: [{ l: 'Help now' + (cost ? ' · ' + money(cost) : ''), d: '', fx: {} }, { l: 'Promise to help later', d: '', fx: {} }, { l: 'Say no', d: '', fx: {} }], act: 'fav31', data: { who: c.id, name: c.name, role: c.role, t: a[0].replace(/^asks you to |^wants |^asks for /, ''), give: a[2], cost }, exp: S.week + 2 });
  }
  ACTS.fav31 = (m, idx) => {
    const N = NET(), d = m.data || {};
    if (d.k === 'back') {
      const f = N.f.find(x => x.id === d.f);
      if (!f) return true;
      const c = roster().find(x => x.id === f.who);
      if (idx === 0) { f.st = 'done'; if (c) bumpRel(c, 5); note('You returned the favour to ' + f.name + '.', 'good'); }
      else { f.st = 'broken'; if (c) bumpRel(c, -15); note(f.name + ' will remember that you did not return the favour.', 'bad'); }
      return true;
    }
    const c = roster().find(x => x.id === d.who);
    if (!c) return true;
    if (idx === 0) {
      if (d.cost) payMe(d.cost, 'Favour for ' + d.name);
      bumpRel(c, 6);
      payBack(c, d.name, d.role, d.give);
    } else if (idx === 1) {
      bumpRel(c, 2);
      N.f.unshift({ id: uid(), k: 'promise', who: c.id, name: d.name, role: d.role, t: d.t, give: d.give, cost: d.cost, w: S.week, due: S.week + 6, st: 'open' });
    } else { bumpRel(c, -3); if (c.r) remember(c.r, 'You turned down their request.', -2); }
    if (N.f.length > 40) N.f.length = 40;
    return true;
  };
  /* round 39: some favours pay back at once and say so; the rest are owed and can be called in */
  function payBack(c, name, role, give) {
    const N = NET();
    if (role === 'Bankers' || role === 'Lawyers' || role === 'Suppliers' || role === 'Journalists' || role === 'Investors') {
      const what = giveWhat(c);
      N.f.unshift({ id: uid(), k: 'owed', who: c.id, name, role, t: give, w: S.week, st: 'used' });
      note(name + ' returned the favour: ' + what, 'good');
      return what;
    }
    N.f.unshift({ id: uid(), k: 'owed', who: c.id, name, role, t: give, w: S.week, st: 'open' });
    note(name + ' owes you a favour: ' + give + '. Call it in under Group › You › People you know › Favours.', 'good');
    return name + ' owes you one: ' + give + '.';
  }
  ACT.fav31keep = p => {
    const N = NET(), f = N.f.find(x => x.id === p.id);
    if (!f || f.st !== 'open') return;
    if (f.cost && S.cash < f.cost) return toast('Not enough cash.', true);
    if (f.cost) payMe(f.cost, 'Kept a promise to ' + f.name);
    f.st = 'done';
    const c = roster().find(x => x.id === f.who);
    if (c) bumpRel(c, 6);
    const what = c ? payBack(c, f.name, f.role, f.give || 'help when you need it') : '';
    save(); render(); toast('Promise kept. ' + (what || f.name + ' owes you one.'));
  };
  ACT.fav31call = p => {
    const N = NET(), f = N.f.find(x => x.id === p.id);
    if (!f || f.st !== 'open' || f.k !== 'owed') return;
    if (f.tried && S.week - f.tried < 4) return toast('You asked recently. Give it a few weeks.', true);
    const c = roster().find(x => x.id === f.who);
    if (!c) { f.st = 'gone'; save(); render(); return; }
    const odds = clamp(0.35 + c.rel / 200 + (c.role === 'Journalists' ? (image().g.press - 50) / 200 : c.role === 'Politicians' ? (image().g.city - 50) / 200 : c.role === 'Bankers' ? (image().g.bank - 50) / 200 : 0), 0.2, 0.9);
    if (chance(odds)) {
      f.st = 'used';
      const what = giveWhat(c);
      save(); render(); toast(what);
    } else {
      f.tried = S.week;
      bumpRel(c, -2);
      save(); render(); toast(c.name + ' could not help this time.', true);
    }
  };
  ACT.fav31ask = p => {
    const c = roster().find(x => x.id === p.id), N = NET();
    if (!c) return;
    if (c.rel < 64) return toast('You need to be close to ask a favour without one owed.', true);
    if (N.f.some(f => f.who === c.id && f.k === 'owe' && f.st === 'open')) return toast('You already owe ' + c.name + ' one.', true);
    if (chance(clamp(0.25 + c.rel / 250, 0.2, 0.7))) {
      const what = giveWhat(c);
      N.f.unshift({ id: uid(), k: 'owe', who: c.id, name: c.name, role: c.role, t: (ASKS[c.role] || [['help them in return']])[0][0].replace(/^asks you to |^wants |^asks for /, ''), w: S.week, due: S.week + rint(8, 20), st: 'open' });
      save(); render(); toast(what + ' You owe ' + c.name.split(' ')[0] + ' one now.');
    } else { bumpRel(c, -3); save(); render(); toast(c.name + ' said no.', true); }
  };
  /* favours with real effects */
  const lr0 = loanRate;
  loanRate = function (l) { const r = lr0.apply(this, arguments); const L = S.net31 && S.net31.loanCut; return L && S.week < L.until ? Math.max(0.005, r - L.cut) : r; };
  const pc31 = payCo;
  payCo = function (co, amt, cat) {
    if (cat === 'fine' && S.net31 && S.net31.fineCut && amt > 0) { S.net31.fineCut = 0; arguments[1] = amt * 0.5; note('Your lawyer got the fine halved.', 'good', co && co.id); }
    return pc31.apply(this, arguments);
  };
  const relCls = r => r >= 64 ? 'grn' : r >= 36 ? '' : r >= 22 ? 'amb' : 'red';
  /* round 37: 40 is where everyone starts, so 40 reads as a plain acquaintance (the supplier scale starts at 0) */
  const relW = r => r >= 78 ? 'Trusted' : r >= 64 ? 'Close' : r >= 50 ? 'Friendly' : r >= 36 ? 'Acquaintance' : r >= 22 ? 'Cool' : 'Strained';
  V.titles.net31 = 'People you know';
  V.heads.net31 = () => ({ t: 'People you know', sub: 'Contacts, the web between you, favours and promises' });
  V.net31 = function (p) {
    const t = (p && p.t) || ui.net31t || 'people';
    ui.net31t = t;
    const L = roster(), N = NET();
    let h = '<div class="seg" style="grid-template-columns:repeat(3,1fr)">' + [['people', 'By role'], ['web', 'Web'], ['fav', 'Favours']].map(x => '<button class="' + (x[0] === t ? 'on' : '') + '" data-a="go" data-p="' + P({ n: 'net31', p: { t: x[0] } }) + '">' + x[1] + '</button>').join('') + '</div>';
    if (!L.length) return h + '<div class="calm">You know nobody in business yet. Open a company and people will find you.</div>';
    if (t === 'people') {
      ROLE_ORDER.forEach(role => {
        const G = L.filter(c => c.role === role);
        if (!G.length) return;
        h += '<h2 class="sec">' + role + '</h2><div class="lrows">' + G.map(c => {
          const owe = N.f.filter(f => f.who === c.id && f.st === 'open');
          const tag = owe.some(f => f.k === 'owed') ? ' · owes you' : owe.some(f => f.k === 'owe') ? ' · you owe them' : owe.some(f => f.k === 'promise') ? ' · promise open' : '';
          return '<button class="lrow" data-a="net31p" data-p="' + P({ id: c.id }) + '"><span class="av">' + esc(ini(c.name)) + '</span><span class="ctext"><b>' + esc(c.name) + '</b><small>' + esc(c.org) + tag + '</small></span>' + pillp(esc(relW(c.rel)), relCls(c.rel)) + '</button>';
        }).join('') + '</div>';
      });
    } else if (t === 'web') {
      const S0 = L.slice().sort((a, b) => b.rel - a.rel).slice(0, 14), n = S0.length, W = 340, H = 340, cx = W / 2, cy = H / 2, R0 = 128;
      let lines = '', dots = '';
      S0.forEach((c, i) => {
        const a = -Math.PI / 2 + i * 2 * Math.PI / n, x = cx + R0 * Math.cos(a), y = cy + R0 * Math.sin(a);
        const col = c.rel >= 64 ? 'var(--green)' : c.rel >= 36 ? 'var(--muted)' : c.rel >= 22 ? 'var(--amber)' : 'var(--red)';
        lines += '<line x1="' + cx + '" y1="' + cy + '" x2="' + x.toFixed(1) + '" y2="' + y.toFixed(1) + '" stroke="' + col + '" stroke-width="' + (0.6 + c.rel / 28).toFixed(1) + '"' + (c.rel < 22 ? ' stroke-dasharray="4 4"' : '') + ' opacity=".8"></line>';
        dots += '<g><circle cx="' + x.toFixed(1) + '" cy="' + y.toFixed(1) + '" r="17" fill="var(--surface2)" stroke="' + col + '" stroke-width="1.5"></circle><text x="' + x.toFixed(1) + '" y="' + (y + 4).toFixed(1) + '" text-anchor="middle" font-size="11" font-weight="700" fill="var(--text)">' + esc(ini(c.name)) + '</text><text x="' + x.toFixed(1) + '" y="' + (y + (y > cy ? 31 : -23)).toFixed(1) + '" text-anchor="middle" font-size="9.5" fill="var(--muted)">' + esc(c.role.replace(/s$/, '').replace('Executive', 'Exec').replace('Rival owner', 'Rival')) + '</text></g>';
      });
      h += '<div class="card web31"><svg viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Your network: thicker lines are closer relationships">' + lines + '<circle cx="' + cx + '" cy="' + cy + '" r="24" fill="var(--amber)"></circle><text x="' + cx + '" y="' + (cy + 5) + '" text-anchor="middle" font-size="13" font-weight="800" fill="#1b140c">' + esc(ini(S.player.name)) + '</text>' + dots + '</svg><div class="leg31"><span><i style="background:var(--green)"></i>Close</span><span><i style="background:var(--muted)"></i>Fine</span><span><i style="background:var(--amber)"></i>Cool</span><span><i style="background:var(--red)"></i>Strained</span></div></div>';
      h += '<div class="note">Thicker lines are closer. Tap a name under By role to see your history with them.</div>';
    } else {
      const open = N.f.filter(f => f.st === 'open'), done = N.f.filter(f => f.st !== 'open').slice(0, 8);
      const grp = (k, t2, empty) => {
        const G = open.filter(f => f.k === k);
        return '<h2 class="sec">' + t2 + '</h2>' + (G.length ? '<div class="lrows">' + G.map(f => '<div class="lrow"><span class="av">' + esc(ini(f.name)) + '</span><span class="ctext"><b class="wrap">' + esc(f.name) + '</b><small class="wrap">' + esc(f.t) + (f.due && k !== 'owed' ? ' · by ' + dateStr(f.due) : '') + '</small></span>' + (k === 'owed' ? btn('Ask', 'fav31call', { id: f.id }, 'chip primary') : k === 'promise' ? btn(f.cost ? 'Keep · ' + mshort(f.cost) : 'Keep', 'fav31keep', { id: f.id }, 'chip primary') : pillp('They will ask', 'amb')) + '</div>').join('') + '</div>' : '<div class="calm">' + empty + '</div>');
      };
      h += grp('owed', 'They owe you', 'Nobody owes you a favour yet. Help people when they ask.');
      h += grp('promise', 'Promises you made', 'No open promises.');
      h += grp('owe', 'You owe them', 'You owe nobody.');
      if (done.length) h += '<h2 class="sec">History</h2><div class="lrows">' + done.map(f => '<div class="lrow"><span class="ctext"><b>' + esc(f.name) + '</b><small class="wrap">' + esc(f.t) + '</small></span>' + pillp(f.st === 'broken' ? 'Broken' : f.st === 'used' ? 'Called in' : 'Done', f.st === 'broken' ? 'red' : 'grn') + '</div>').join('') + '</div>';
      h += '<div class="note">A favour owed is a chance, not a promise: how close you are and how they see you decide whether they come through.</div>';
    }
    return h;
  };
  ACT.net31p = p => {
    const c = roster().find(x => x.id === p.id);
    if (!c) return;
    const N = NET(), F = N.f.filter(f => f.who === c.id).slice(0, 6);
    openSheet('<div class="cchd"><span class="av">' + esc(ini(c.name)) + '</span><span class="ctext"><b>' + esc(c.name) + '</b><small>' + esc(c.org) + '</small></span>' + pillp(esc(relW(c.rel)), relCls(c.rel)) + '</div>' + (F.length ? '<div class="lrows">' + F.map(f => '<div class="lrow"><span class="ctext"><b class="wrap">' + esc(f.k === 'owed' ? 'Owes you: ' + f.t : f.k === 'owe' ? 'You owe: ' + f.t : 'Promise: ' + f.t) + '</b><small>' + dateStr(f.w) + ' · ' + esc(f.st) + '</small></span></div>').join('') + '</div>' : '<span class="tipt">No favours between you yet.</span>') + (c.r ? btn('See what they remember', 'go', { n: 'riv31', p: { id: c.r.id } }, 'wide') : '') + btn('Ask a favour', 'fav31ask', { id: c.id }, 'wide') + btn('Close', 'sheetclose', undefined, 'ghost wide'));
  };

  /* ---------- 8: maps ---------- */
  V.titles.map31 = 'Maps';
  V.heads.map31 = () => ({ t: 'Maps', sub: 'What you own, where you are, who is around you' });
  V.map31 = function (p) {
    const t = (p && p.t) || ui.map31t || 'own';
    ui.map31t = t;
    let h = '<div class="seg" style="grid-template-columns:repeat(3,1fr)">' + [['own', 'Ownership'], ['where', 'Presence'], ['circ', 'Influence']].map(x => '<button class="' + (x[0] === t ? 'on' : '') + '" data-a="go" data-p="' + P({ n: 'map31', p: { t: x[0] } }) + '">' + x[1] + '</button>').join('') + '</div>';
    const cos = live();
    if (!cos.length) return h + '<div class="calm">Nothing to map yet. Open a company first.</div>';
    if (t === 'own') {
      const node = (c, depth) => '<button class="node31" style="margin-left:' + depth * 22 + 'px" data-a="go" data-p="' + P({ n: 'co', p: { id: c.id } }) + '"><span class="av sm31">' + esc(ini(c.name)) + '</span><span class="ctext"><b>' + esc(c.name) + '</b><small>' + (c.type === 'hold' ? 'Holding' : esc(BD[c.type].n)) + ' · ' + mshort(companyValue(c)) + ((c.holders || []).filter(x => x.pct > 0).length ? ' · others own ' + Math.round(sum(c.holders.filter(x => x.pct > 0), x => x.pct)) + '%' : '') + '</small></span>' + pillp(Math.round(c.own) + '%', c.own >= 100 ? 'grn' : 'amb') + '</button>';
      let nw = 0; try { nw = netWorth().total; } catch (e) { }
      h += '<div class="tree31"><div class="node31 me31"><span class="av sm31">' + esc(ini(S.player.name)) + '</span><span class="ctext"><b>' + esc(S.player.name) + '</b><small>Net worth ' + mshort(nw) + '</small></span></div>';
      const holds = cos.filter(c => c.type === 'hold');
      holds.forEach(hd => { h += '<i class="ln31"></i>' + node(hd, 1); cos.filter(c => c.hold === hd.id).forEach(c => { h += '<i class="ln31 d2"></i>' + node(c, 2); }); });
      cos.filter(c => c.type !== 'hold' && !(c.hold && getCo(c.hold))).forEach(c => { h += '<i class="ln31"></i>' + node(c, 1); });
      (S.startups || []).filter(s => s.st === 'live').forEach(s => { h += '<i class="ln31"></i><div class="node31" style="margin-left:22px"><span class="av sm31">' + esc(ini(s.name || 'S')) + '</span><span class="ctext"><b>' + esc(s.name || 'Startup') + '</b><small>Startup stake · ' + mshort((s.val || 0) * (s.pct || 0) / 100) + '</small></span>' + pillp(Math.round(s.pct || 0) + '%', 'blue') + '</div>'; });
      h += '</div>';
    } else if (t === 'where') {
      const ccs = Array.from(new Set(cos.map(c => c.country || S.country)));
      ccs.forEach(cc => {
        const C = CO[cc];
        if (!C) return;
        const cities = (C.cities || []).slice().sort((a, b) => (b.pop || 0) - (a.pop || 0)).slice(0, 12);
        h += '<h2 class="sec">' + esc(C.flag || '') + ' ' + esc(C.name) + '</h2><div class="tiles31">' + cities.map(ct => {
          const here = cos.filter(c => (c.country || S.country) === cc && c.city === ct.id);
          const lvl = here.length >= 4 ? 3 : here.length >= 2 ? 2 : here.length ? 1 : 0;
          const types = Array.from(new Set(here.map(c => c.type === 'hold' ? 'Holding' : BD[c.type].n))).slice(0, 2).join(', ');
          return '<div class="tile31 l' + lvl + '"><b>' + esc(ct.name) + '</b><small>' + (here.length ? here.length + (here.length > 1 ? ' companies' : ' company') : 'Not here') + '</small>' + (types ? '<small class="ty31">' + esc(types) + '</small>' : '') + '</div>';
        }).join('') + '</div>';
      });
      h += '<div class="note">Darker tiles: more of your companies. Cities are ordered by size.</div>';
    } else {
      const ring = (items, r0, cls) => items.slice(0, 12).map((x, i, a) => { const ang = -Math.PI / 2 + (i + (cls === 'o' ? 0.5 : 0)) * 2 * Math.PI / Math.max(1, a.length), x0 = 170 + r0 * Math.cos(ang), y0 = 170 + r0 * Math.sin(ang); return '<g><circle cx="' + x0.toFixed(1) + '" cy="' + y0.toFixed(1) + '" r="' + (cls === 'i' ? 15 : 12) + '" fill="' + (cls === 'i' ? 'var(--amber)' : cls === 'm' ? 'var(--green-soft)' : 'var(--red-soft)') + '" stroke="' + (cls === 'i' ? 'var(--amber)' : cls === 'm' ? 'var(--green)' : 'var(--red)') + '"></circle><text x="' + x0.toFixed(1) + '" y="' + (y0 + 4).toFixed(1) + '" text-anchor="middle" font-size="' + (cls === 'i' ? 10.5 : 9.5) + '" font-weight="700" fill="' + (cls === 'i' ? '#1b140c' : 'var(--text)') + '">' + esc(ini(x)) + '</text></g>'; }).join('');
      const R = roster(), allies = R.filter(c => c.rel >= 50).map(c => c.name), others = R.filter(c => c.rel < 50).map(c => c.name);
      h += '<div class="card web31"><svg viewBox="0 0 340 340" role="img" aria-label="Circles of influence: your companies inside, allies in the middle ring, rivals and the wary outside"><circle cx="170" cy="170" r="160" fill="none" stroke="var(--line)"></circle><circle cx="170" cy="170" r="110" fill="none" stroke="var(--line)"></circle><circle cx="170" cy="170" r="58" fill="none" stroke="var(--line)"></circle>' + ring(cos.map(c => c.name), 40, 'i') + ring(allies, 86, 'm') + ring(others, 138, 'o') + '<text x="170" y="174" text-anchor="middle" font-size="12" font-weight="800" fill="var(--text)">' + esc(ini(S.player.name)) + '</text></svg><div class="leg31"><span><i style="background:var(--amber)"></i>Yours (' + cos.length + ')</span><span><i style="background:var(--green)"></i>Allies (' + allies.length + ')</span><span><i style="background:var(--red)"></i>Rivals and the wary (' + others.length + ')</span></div></div>';
      const I = image();
      h += '<div class="card">' + row('Seen as', esc(I.lab[0])) + row('Allies', allies.length ? esc(allies.slice(0, 3).join(', ')) + (allies.length > 3 ? ' +' + (allies.length - 3) : '') : 'None yet') + '</div>';
    }
    return h;
  };

  /* ---------- the office links to all of it ---------- */
  const of31 = V.office;
  if (of31) V.office = function () {
    let h = of31.apply(this, arguments);
    try {
      const I = image(), N = NET(), nOwed = N.f.filter(f => f.st === 'open' && f.k === 'owed').length, nProm = N.f.filter(f => f.st === 'open' && f.k === 'promise').length;
      h = '<h2 class="sec first">You</h2><div class="lrows"><button class="lrow" data-a="go" data-p="' + P({ n: 'img31' }) + '"><span class="lic">' + svg('star', 20) + '</span><span class="ctext"><b>Public image</b><small>Seen as ' + esc(I.lab[0].toLowerCase()) + '</small></span><i>›</i></button><button class="lrow" data-a="go" data-p="' + P({ n: 'net31', p: {} }) + '"><span class="lic">' + svg('people', 20) + '</span><span class="ctext"><b>People you know</b><small>' + roster().length + ' contacts' + (nOwed ? ' · ' + nOwed + ' owe you' : '') + (nProm ? ' · ' + nProm + ' promise' + (nProm > 1 ? 's' : '') + ' open' : '') + '</small></span><i>›</i></button><button class="lrow" data-a="go" data-p="' + P({ n: 'map31', p: {} }) + '"><span class="lic">' + svg('chart', 20) + '</span><span class="ctext"><b>Maps</b><small>Ownership, presence, influence</small></span><i>›</i></button><button class="lrow" data-a="go" data-p="' + P({ n: 'rivals' }) + '"><span class="lic">' + svg('fire', 20) + '</span><span class="ctext"><b>Rivals</b><small>' + rivalsAll().length + ' owners in your markets</small></span><i>›</i></button></div>' + h;
    } catch (e) { console.error(e); }
    return h;
  };

  /* ---------- 10: the week in numbers ---------- */
  const W31 = () => (S.wk31 = S.wk31 || []);
  function shareVal() {
    let v = 0, px = {};
    try { for (const s in S.inv.stocks) { const p0 = S.stocks[s] ? S.stocks[s].p : 0; px[s] = p0; v += S.inv.stocks[s].q * p0; } } catch (e) { }
    try { live().filter(c => c.type === 'hold' && c.listed).forEach(c => { const x = companyValue(c) * c.own / 100; px['grp:' + c.id] = x; v += x; }); } catch (e) { }
    return { v, px };
  }
  function snap(fin) {
    let nw = { total: 0 };
    try { nw = netWorth(); } catch (e) { }
    const sh = shareVal();
    const cosR = fin ? (fin.cos || []).map(c => ({ id: c.id, name: c.name, rev: Math.round(c.rev || 0), profit: Math.round(c.profit || 0) })) : [];
    return { w: fin ? fin.w : S.week, cash: Math.round(S.cash), nw: Math.round(nw.total), nwp: { personal: nw.personal, inv: (nw.inv || 0) + (nw.crypto || 0) + (nw.funds || 0), cos: nw.cos, debt: nw.debt }, sh: Math.round(sh.v), px: sh.px, rev: sum(cosR, c => c.rev), profit: sum(cosR, c => c.profit), cos: cosR, bw: fin ? Object.assign({}, fin.bw || {}) : {} };
  }
  let pend31 = null;
  const rd31 = window.R10DAY;
  window.R10DAY = function (d) {
    const r = rd31 ? rd31.apply(this, arguments) : undefined;
    try {
      stamp();
      if (d === 0 && pend31) { const L = W31(); L.push(snap(pend31)); if (L.length > 12) L.shift(); }
      pend31 = S.pend ? S.pend.rep : null;
    } catch (e) { console.error(e); }
    return r;
  };
  const LINES = [['cash', 'Cash', x => x.cash], ['sh', 'Shares', x => x.sh], ['rev', 'Revenue', x => x.rev], ['profit', 'Profit', x => x.profit], ['nw', 'Net worth', x => x.nw]];
  function weekCard() {
    const L = W31(), a = L[L.length - 1], b = L[L.length - 2];
    if (!a) return '';
    return '<div class="card wk31"><div class="bhead"><b>Week ' + (b ? 'in numbers' : 'one in numbers') + '</b><small>Tap a line for the sum</small></div>' + LINES.filter(x => x[0] !== 'sh' || a.sh || (b && b.sh)).map((x, i) => {
      const v = x[2](a), pv = b ? x[2](b) : null, dv = pv == null ? null : v - pv;
      return '<button class="wkl31" data-a="fin31" data-p="' + P({ k: x[0] }) + '" style="animation-delay:' + (0.1 + i * 0.12).toFixed(2) + 's"><span>' + x[1] + '</span><b class="cnt28' + (x[0] === 'profit' ? ' ' + sgn(v) : '') + '" data-to="' + v + '">' + mshort(0) + '</b>' + (dv != null ? '<em class="' + sgn(dv) + '">' + plus(dv) + '</em>' : '<em>–</em>') + '<i>›</i></button>';
    }).join('') + '</div>';
  }
  R31.weekCard = weekCard;
  const COSTN = { cogs: 'Materials and goods', wages: 'Wages and payroll', rent: 'Rent and power', mkt: 'Marketing', ins: 'Insurance', acc: 'Accounting', dep: 'Depreciation', int: 'Interest', oth: 'Leasing and other costs', fine: 'Fines', loss: 'Refunds and losses' };
  ACT.fin31 = p => {
    const L = W31(), a = L[L.length - 1], b = L[L.length - 2] || null;
    if (!a) return;
    const ch = (x, y) => '<b>' + mshort(x) + '</b>' + (y != null ? '<small class="' + sgn(x - y) + '"> ' + plus(x - y) + '</small>' : '');
    let h = '';
    if (p.k === 'nw') {
      h = '<h2>Net worth</h2>' + row('Cash and savings', ch(a.nwp.personal, b && b.nwp.personal)) + row('Investments', ch(a.nwp.inv, b && b.nwp.inv)) + row('Your share of companies', ch(a.nwp.cos, b && b.nwp.cos)) + row('Personal debt', '−' + mshort(a.nwp.debt || 0)) + row('Net worth', ch(a.nw, b && b.nw), 'total') + '<span class="tipt">Companies count at what they would likely sell for, times the share you own.</span>';
    } else if (p.k === 'cash') {
      const tx = (S.log || []).filter(x => x.w >= a.w && x.w <= a.w + 1).slice(0, 8);
      h = '<h2>Cash</h2>' + row('Start of the week', mshort(b ? b.cash : a.cash)) + (tx.length ? tx.map(x => row(esc(x.l), '<span class="' + sgn(x.a) + '">' + plus(x.a) + '</span>')).join('') : '<span class="tipt">No personal transactions this week.</span>') + row('End of the week', ch(a.cash, b && b.cash), 'total');
    } else if (p.k === 'rev') {
      h = '<h2>Revenue</h2>' + (a.cos.length ? a.cos.map(c => { const pc = b && b.cos.find(x => x.id === c.id); return row(esc(c.name), ch(c.rev, pc ? pc.rev : null)); }).join('') : '<span class="tipt">No sales this week.</span>') + row('All companies', ch(a.rev, b && b.rev), 'total');
    } else if (p.k === 'profit') {
      const ks = Object.keys(COSTN).filter(k => a.bw[k]);
      h = '<h2>Profit</h2>' + row('Revenue', mshort(a.rev)) + ks.map(k => row(COSTN[k], '−' + mshort(a.bw[k]))).join('') + row('Profit', ch(a.profit, b && b.profit), 'total') + '<span class="tipt">Costs as they were earned this week. The cash for them leaves on payday and on the last day of the month.</span>';
    } else if (p.k === 'sh') {
      const ks = Object.keys(a.px || {});
      h = '<h2>Shares</h2>' + (ks.length ? ks.map(s => { const g = s.indexOf('grp:') === 0, nm = g ? (getCo(+s.slice(4)) || { name: 'Your group' }).name + ' (your listed group)' : s; const v = g ? a.px[s] : (S.inv.stocks[s] ? S.inv.stocks[s].q * a.px[s] : 0), pv = b && b.px && b.px[s] != null ? (g ? b.px[s] : (S.inv.stocks[s] ? S.inv.stocks[s].q * b.px[s] : 0)) : null; return row(esc(nm), ch(v, pv)); }).join('') : '<span class="tipt">You hold no shares.</span>') + row('All shares', ch(a.sh, b && b.sh), 'total');
    }
    openSheet(h + btn('Close', 'sheetclose', undefined, 'ghost wide'));
  };
  const wr31 = V.weekreport;
  if (wr31) V.weekreport = function () { const h = wr31.apply(this, arguments); try { return weekCard() + h; } catch (e) { return h; } };
  /* round 35: the numbers count up inside the week report itself; no second pop-up the day after */
})();

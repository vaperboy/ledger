/* ===== Round 27c: companies that depend on each other.
   A buyer can switch an input (cleaning, building materials, freight, food, power...) from outside suppliers to one of
   your own companies, at market price, cost plus 10% or cost. The supplier gets the volume (and uses its capacity),
   the group keeps the margin, and supply is steadier, until the supplier struggles: then the buyer pays for emergency
   supply and its reputation suffers. Your own bank can lend to the group, but only within real limits. ===== */
(function () {
  const R27 = window.R27 = window.R27 || {};
  const U = window.UI, { toast, save, render, svg, row } = U;
  const P = o => esc(JSON.stringify(o));
  const pillp = (t, c) => '<span class="pill ' + (c || '') + '">' + t + '</span>';
  const ini = n => String(n || '?').replace(/[^\p{L}0-9 ]/gu, ' ').trim().split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase() || '?';
  const sumF = (a, f) => a.reduce((t, x) => t + (f(x) || 0), 0);

  /* what each kind of business buys, from whom, and how much of its sales it spends on it */
  const KINDS = {
    clean: { n: 'Cleaning', sup: ['cleaning'], local: 1, cat: 'oth', b: { hotel: 0.035, restaurant: 0.015, cafe: 0.012, gym: 0.02, nightclub: 0.015, casino: 0.015, fun: 0.015, grocery: 0.008, boutique: 0.008, hardware: 0.006, cardealer: 0.008, physio: 0.015, law: 0.01, acctfirm: 0.01, cons: 0.01, webdev: 0.008, mktg: 0.008, staffing: 0.006, bank: 0.004, insco: 0.004, estate: 0.01, barber: 0.012, pets: 0.012, drivsk: 0.006, kiosk: 0.006 } },
    build: { n: 'Building materials', sup: ['hardware'], cat: 'cogs', b: { construction: 0.3, realdev: 0.25, electrician: 0.18, plumber: 0.2, handy: 0.15 } },
    freight: { n: 'Freight', sup: ['trucking'], cat: 'cogs', b: { factory: 0.05, furniture: 0.05, bakery: 0.03, brewery: 0.05, farm: 0.05, salmon: 0.06, grocery: 0.025, hardware: 0.03, cardealer: 0.015, construction: 0.02 } },
    parcel: { n: 'Parcel delivery', sup: ['courier'], cat: 'cogs', b: { webshop: 0.07, boutique: 0.01, pets: 0.005, furniture: 0.01 } },
    bread: { n: 'Bread and pastries', sup: ['bakery'], local: 1, cat: 'cogs', b: { cafe: 0.06, restaurant: 0.02, hotel: 0.015, grocery: 0.02, kiosk: 0.03, foodtruck: 0.03 } },
    beer: { n: 'Beer', sup: ['brewery'], cat: 'cogs', b: { restaurant: 0.03, nightclub: 0.08, hotel: 0.015, grocery: 0.015, fun: 0.02, kiosk: 0.01 } },
    produce: { n: 'Farm produce', sup: ['farm'], cat: 'cogs', b: { restaurant: 0.04, cafe: 0.02, hotel: 0.02, grocery: 0.04, bakery: 0.04, brewery: 0.03, foodtruck: 0.03 } },
    fish: { n: 'Fish', sup: ['salmon'], cat: 'cogs', b: { restaurant: 0.03, grocery: 0.02, hotel: 0.01 } },
    furn: { n: 'Furniture', sup: ['furniture'], cat: 'oth', b: { hotel: 0.02, restaurant: 0.008, cafe: 0.008, realdev: 0.03 } },
    web: { n: 'Web and IT', sup: ['webdev'], cat: 'oth', b: { webshop: 0.03, boutique: 0.008, hotel: 0.004, mktg: 0.02, bank: 0.01, insco: 0.01, staffing: 0.006 } },
    ads: { n: 'Marketing services', sup: ['mktg'], cat: 'mkt', b: { hotel: 0.015, restaurant: 0.01, gym: 0.015, cardealer: 0.01, webshop: 0.02, boutique: 0.015, fun: 0.01 } },
    temp: { n: 'Temporary staff', sup: ['staffing'], local: 1, cat: 'wages', b: { hotel: 0.02, restaurant: 0.015, grocery: 0.01, construction: 0.03, factory: 0.02, courier: 0.02, event: 0.03, fun: 0.015 } },
    power: { n: 'Electricity', sup: ['power'], cat: 'oth', nocap: 1, b: { factory: 0.04, bakery: 0.03, brewery: 0.03, salmon: 0.03, hotel: 0.02, grocery: 0.015, farm: 0.02, casino: 0.01, gym: 0.01 } }
  };
  R27.KINDS = KINDS;
  const MODES = { mkt: 'Market price', c10: 'Cost + 10%', cost: 'At cost' };
  const L27 = () => { S.l27 = S.l27 || []; return S.l27; };
  const live = c => c && c.st === 'open';
  const kindsFor = co => Object.keys(KINDS).filter(k => KINDS[k].b[co.type] && KINDS[k].sup.indexOf(co.type) < 0);
  const ann = c => window.R26 && R26.annRev ? R26.annRev(c) : (c.lastW ? c.lastW.rev * 52 : 0);
  /* your companies that could supply this buyer */
  function suppliersFor(co, k) {
    const K = KINDS[k];
    return S.cos.filter(s => live(s) && s.id !== co.id && K.sup.indexOf(s.type) >= 0 && s.country === co.country && (!K.local || s.city === co.city));
  }
  R27.suppliersFor = suppliersFor;
  function links() { return L27().filter(l => { const b = getCo(l.b), s = getCo(l.s); return b && s && b.st !== 'sold' && b.st !== 'bust' && s.st !== 'sold' && s.st !== 'bust'; }); }
  R27.links = links;
  const linkOf = (co, k) => L27().find(l => l.b === co.id && l.k === k);
  /* the supplier's full cost per krone of sales, from its own results */
  function costRatio(s) {
    const h = (s.hist || []).slice(-3), rv = sumF(h, x => x.rev), pf = sumF(h, x => x.profit);
    let cr = rv > 0 ? 1 - pf / rv : 1 - (BD[s.type].m || 0.1);
    const pk = R27.perk ? R27.perk('titan') : -1;
    if (pk >= 0) cr *= 1 - [0.05, 0.08, 0.12][pk];
    return clamp(cr, 0.45, 1.3);
  }
  function varRatio(s) {
    const b = s.bk && s.bk.m && s.bk.m.rev ? s.bk.m : s.bk && s.bk.y;
    return clamp(b && b.rev ? (b.cogs || 0) / b.rev : (BD[s.type].cogs || 0.3), 0.05, 0.8);
  }
  /* a transfer price never goes above what the buyer would pay outside */
  const pfOf = (l, s) => l.mode === 'mkt' ? 1 : l.mode === 'c10' ? Math.min(1, costRatio(s) * 1.1) : Math.min(1, costRatio(s));
  R27.pfOf = pfOf;
  /* weekly spend on the input, and how much of the supplier's capacity it takes */
  function spendOf(b, k) { return Math.max(0, (b.lastW ? b.lastW.rev || 0 : 0) * (KINDS[k].b[b.type] || 0)); }
  function unitsOf(s, x) { let tk = 0; try { tk = ticketEff(s, BD[s.type]); } catch (e) { } return tk > 0 ? x / tk : 0; }

  /* ---------- the weekly settlement ---------- */
  function tradeWeek() {
    const res = {};
    L27().slice().forEach(l => {
      const b = getCo(l.b), s = getCo(l.s), K = KINDS[l.k];
      if (!b || !K || b.st === 'sold' || b.st === 'bust') { S.l27 = L27().filter(x => x !== l); return; }
      if (!s || s.st === 'sold' || s.st === 'bust') {
        S.l27 = L27().filter(x => x !== l);
        if (b.st === 'open') addMsg({ kind: 'info', from: b.name, title: 'Supplier gone: ' + K.n.toLowerCase() + ' for ' + b.name, body: (s ? s.name : 'Your supplier') + ' no longer exists, so ' + b.name + ' buys ' + K.n.toLowerCase() + ' outside again, at short notice and higher prices for a few weeks.', co: b.id, tone: 'bad', status: 'done' });
        if (b.st === 'open') b.mods.push({ k: 'cogsup', m: 1.03, w: 4 });
        return;
      }
      if (b.st !== 'open') { s.int27u = 0; return; }
      const x = spendOf(b, l.k);
      if (x <= 0) { l.last = { x: 0, f: 1, w: S.week }; return; }
      const u = K.nocap ? 0 : unitsOf(s, x);
      /* how much the supplier could deliver: last week's capacity plus what it held back for the group */
      const capB = s.st === 'open' ? (s.lastW ? (s.lastW.cap || 0) : 0) + (s.int27r || 0) : 0;
      const f = K.nocap ? (s.st === 'open' ? 1 : 0) : u > 0 ? clamp(capB / u, 0, 1) : 1;
      const pf = pfOf(l, s), vr = varRatio(s);
      const got = x * f;
      /* the buyer: what it paid outside before, against what it pays the group now */
      const diff = got * (1 - pf);
      if (diff > 0) { coIn(b, diff, null, null); bk(b, K.cat, -diff); }
      else if (diff < 0) payCo(b, -diff, K.cat, null);
      /* the supplier: sales to the group and the goods that go into them */
      if (got > 0) { coIn(s, got * pf, 'rev', null); payCo(s, got * vr, 'cogs', null); }
      /* what it could not deliver is bought outside at a premium, and customers notice */
      if (f < 0.98) {
        payCo(b, x * (1 - f) * 0.2, K.cat, null);
        if (f < 0.8) { b.rep = Math.max(0, b.rep - 0.4 * (1 - f)); if (!l.warn || S.week - l.warn > 6) { l.warn = S.week; addMsg({ kind: 'info', from: b.name, title: s.name + ' could not deliver to ' + b.name, body: s.name + ' delivered only ' + Math.round(f * 100) + '% of the ' + K.n.toLowerCase() + ' ' + b.name + ' needed. The rest was bought outside at short notice, and some customers noticed.', co: b.id, tone: 'bad', status: 'done', go: { l: 'Supply chain', a: 'go', p: { n: 'chain27', p: { id: b.id } } } }); } }
      }
      l.last = { x, f, pf, w: S.week, save: diff };
      l.sum = (l.sum || 0) + diff;
      l.gm = (l.gm || 0) + got * (1 - vr);
      res[s.id] = (res[s.id] || 0) + u * f;
      s.i27rev = (s.i27rev || 0) * 0.8 + got * pf * 0.2;
    });
    /* capacity the suppliers hold back next week */
    S.cos.forEach(c => { c.int27u = res[c.id] || 0; });
  }
  R27.tradeWeek = tradeWeek;
  const cap0 = window.capacity;
  window.capacity = function (co, bd) {
    const r = cap0.apply(this, arguments);
    try { if (co && co.int27u > 0 && r && isFinite(r.cap)) { r.int27 = Math.min(r.cap, co.int27u); co.int27r = r.int27; r.cap = Math.max(0, r.cap - co.int27u); } else if (co) co.int27r = 0; } catch (e) { }
    return r;
  };
  R7.afterWeek = R7.afterWeek || [];
  R7.afterWeek.push(() => { try { tradeWeek(); } catch (e) { console.error(e); } });

  /* ---------- supply from inside protects against outside supplier trouble ---------- */
  const fe0 = window.fireEvent;
  if (fe0) window.fireEvent = function (co, bd, e) {
    if (e && (e.id === 'g_supply' || e.id === 'g_supbust' || e.id === 'pr_raw' || e.id === 'p_matprice' || e.id === 'pr_flour' || e.id === 'l_fuel' || e.id === 'r_carrier') && co && links().some(l => l.b === co.id && getCo(l.s) && getCo(l.s).st === 'open' && (KINDS[l.k].cat === 'cogs'))) return;
    return fe0.apply(this, arguments);
  };

  /* ---------- your own bank: related-party lending at arm's length, within 25% of its capital ---------- */
  function bankRoom(b) {
    if (!b || b.st !== 'open' || !b.fm) return 0;
    const eq = Math.max(0, b.fm.equity != null ? b.fm.equity : companyAssets(b) - companyDebts(b));
    const used = sumF(S.loans.filter(l => l.bank === b.id), l => l.bal);
    const req = (BD.bank.tw && BD.bank.tw.capitalReq) || 0.12;
    const capOk = (b.fm.cr || 0) >= req;
    return capOk ? Math.max(0, Math.min(eq * 0.25 - used, b.cash * 0.8)) : 0;
  }
  R27.bankRoom = bankRoom;
  const lo1 = window.loanOffer;
  window.loanOffer = function (kind, amt, co) {
    const o = lo1.apply(this, arguments);
    try {
      if (o.ownBank) {
        o.margin += 0.006; /* loans to its own owner are priced like anyone else's */
        const b = getCo(o.ownBank), room = bankRoom(b);
        if (!(amt > 0) || amt > room) { o.ownNote = b ? b.name + ' can lend its own group at most ' + money(Math.max(0, room)) + ' more (25% of its capital, and only while its capital ratio is above the minimum). An outside bank lends the rest.' : ''; o.ownBank = 0; }
      }
    } catch (e) { console.error(e); }
    return o;
  };
  /* finance a purchase through your own bank */
  const ro0 = ACT.rivoffer;
  ACT.rivoffer = p => {
    ro0(p);
    try {
      const b = S.cos.find(c => c.type === 'bank' && c.st === 'open');
      if (!b || !ui.sheet || !/data-a="rivclose"/.test(ui.sheet.html)) return;
      const m = ui.sheet.html.match(/data-a="rivclose" data-p="([^"]+)"/);
      if (!m) return;
      const pp = JSON.parse(m[1].replace(/&quot;/g, '"').replace(/&amp;/g, '&'));
      const room = bankRoom(b), amt = Math.round(Math.min(pp.price * 0.7, room) / 1000) * 1000;
      const add = amt >= pp.price * 0.2 ? '<button class="btn wide" data-a="rivfin27" data-p="' + P(Object.assign({}, pp, { amt, bank: b.id })) + '">Buy with ' + money(amt) + ' from ' + esc(b.name) + '</button><p class="muted small">A loan to you from your own bank, at normal terms. It may lend its owner at most a quarter of its capital.</p>' : '<p class="muted small">' + esc(b.name) + ' cannot lend you enough for this: at most ' + money(room) + ' (25% of its capital, and only above its capital minimum).</p>';
      ui.sheet.html = ui.sheet.html.replace(/(<button[^>]*data-a="rivclose"[^>]*>[^<]*<\/button>)/, '$1' + add);
      render();
    } catch (e) { console.error(e); }
  };
  ACT.rivfin27 = p => {
    const b = getCo(p.bank);
    if (!b || p.amt > bankRoom(b) + 1) { toast('Your bank cannot lend that much.', true); return; }
    const l = { id: uid(), kind: 'biz', name: 'Acquisition loan from ' + b.name, bal: p.amt, amt0: p.amt, margin: creditMargin() + 0.01, pay: 0, termM: 96, co: 0, w0: S.week, guar: 0, bank: b.id };
    l.pay = annuity(p.amt, policy() + l.margin, 96);
    moveCash(b, -p.amt);
    b.fm.gb = (b.fm.gb || 0) + p.amt;
    S.loans.push(l);
    gainMe(p.amt, 'Acquisition loan from ' + b.name);
    if (R27.amb) R27.amb().cnt.bankfin++;
    ACT.rivclose({ id: p.id, r: p.r, price: p.price });
  };

  /* ---------- Supply chain screen ---------- */
  V.titles.chain27 = 'Supply chain';
  V.heads = V.heads || {};
  V.heads.chain27 = p => { const co = getCo(p.id); return { t: 'Supply chain', sub: co ? esc(co.name) : '' }; };
  function outsideName(co, k) {
    if (KINDS[k].cat === 'cogs') { try { const v = goodsEff(co).v; if (v) return v.name; } catch (e) { } }
    return 'Outside suppliers';
  }
  V.chain27 = function (p) {
    const co = getCo(p.id);
    if (!co) return '<div class="calm">Gone.</div>';
    const ks = kindsFor(co);
    const buyers = links().filter(l => l.s === co.id);
    let h = '';
    /* what it buys */
    /* the inputs worth showing: linked ones, ones you could supply, and the three biggest; the rest in one line */
    const shown = ks.filter(k => linkOf(co, k) || suppliersFor(co, k).length);
    ks.slice().sort((a, b) => spendOf(co, b) - spendOf(co, a)).forEach(k => { if (shown.length < 3 && shown.indexOf(k) < 0) shown.push(k); });
    const rest = ks.filter(k => shown.indexOf(k) < 0);
    if (shown.length) h += shown.map(k => {
      const l = linkOf(co, k), s = l && getCo(l.s), x = spendOf(co, k) * 52;
      const can = suppliersFor(co, k);
      const sub = l && s ? esc(KINDS[k].n) + ' · ' + esc(MODES[l.mode]) + ' · ' + mshort(x) + ' a year' : esc(KINDS[k].n) + ' · ' + mshort(x) + ' a year' + (can.length ? ' · you could supply it' : '');
      const pl = l && s ? (l.last && l.last.f < 0.9 ? pillp('Short', 'red') : pillp('Yours', 'grn')) : can.length ? pillp('Outside', 'amb') : pillp('Outside');
      return '<button class="card opt2" data-a="ch27k" data-p="' + P({ id: co.id, k }) + '"><div class="cchd"><span class="av">' + esc(ini(l && s ? s.name : outsideName(co, k))) + '</span><span class="ctext"><b>' + esc(l && s ? s.name : outsideName(co, k)) + '</b><small>' + sub + '</small></span>' + pl + '</div></button>';
    }).join('') + (rest.length ? '<p class="muted small">Also buys ' + esc(rest.map(k => KINDS[k].n.toLowerCase().replace(/\bit\b/, 'IT')).join(', ')) + ' from outside suppliers.</p>' : '') + '<div style="margin-left:28px;width:2px;height:14px;background:var(--line)"></div>';
    h += '<div class="card" style="border-color:var(--amber)"><div class="cchd"><span class="av">' + esc(ini(co.name)) + '</span><span class="ctext"><b>' + esc(co.name) + '</b><small>' + esc(BD[co.type].n) + ' · yours</small></span></div></div>';
    /* who it sells to inside the group */
    if (buyers.length) {
      const r = ann(co) || 1;
      h += '<div style="margin-left:28px;width:2px;height:14px;background:var(--line)"></div>' + buyers.map(l => {
        const b = getCo(l.b), sh = (l.last ? l.last.x * l.last.f * l.last.pf * 52 : 0) / r;
        return '<button class="card opt2" data-a="go" data-p="' + P({ n: 'chain27', p: { id: b.id } }) + '"><div class="cchd"><span class="av">' + esc(ini(b.name)) + '</span><span class="ctext"><b>' + esc(b.name) + '</b><small>Buys ' + esc(KINDS[l.k].n.toLowerCase()) + ' · ' + Math.round(sh * 100) + '% of sales · ' + esc(MODES[l.mode]) + '</small></span>' + (sh > 0.3 ? pillp('Dependent', 'red') : pillp('Group', 'blue')) + '</div></button>';
      }).join('');
    }
    /* ideas: supply yourself */
    const ideas = ks.filter(k => !linkOf(co, k) && !suppliersFor(co, k).length).map(k => ({ k, t: KINDS[k].sup[0], x: spendOf(co, k) * 52 })).filter(i => i.x > 0 && BD[i.t] && (() => { try { return legalStatus(i.t, co.country).ok; } catch (e) { return false; } })()).map(i => { let est = 0; try { est = setupEstimate(i.t, { city: co.city, country: co.country, size: 0.5 }).total; } catch (e) { } i.est = est; i.keep = i.x * (BD[i.t].m || 0.1) * 0.9; return i; }).filter(i => i.keep > 0 && i.est / i.keep <= 12).sort((a, b) => b.x - a.x).slice(0, 2);
    if (ideas.length) {
      h += '<h2 class="sec">Supply it yourself</h2>' + ideas.map(i => {
        const est = i.est, save1 = i.keep;
        return '<div class="card"><div class="bhead"><b>Start your own ' + esc(BD[i.t].n.toLowerCase()) + '</b>' + pillp(mshort(est)) + '</div><span class="tipt">' + esc(co.name) + ' spends about ' + mshort(i.x) + ' a year on ' + esc(KINDS[i.k].n.toLowerCase()) + '. Your own supplier would keep the margin in the group and could sell to others too, but it ties up capital, and if it struggles, ' + esc(co.name) + ' does too.</span><div class="trio" style="grid-template-columns:1fr 1fr"><div><span>Keeps per year</span><b class="pos">~' + mshort(save1) + '</b></div><div><span>Payback</span><b>' + (save1 > 0 ? Math.max(1, Math.round(est / save1)) + ' years' : '–') + '</b></div></div><button class="btn primary wide" data-a="go" data-p="' + P({ n: 'newco', p: { bd: i.t } }) + '">Start one</button></div>';
      }).join('');
    }
    /* risks */
    const rk = [];
    links().filter(l => l.b === co.id).forEach(l => { const s = getCo(l.s); rk.push(row('If ' + esc(s.name) + ' fails', '<span class="neg">' + esc(KINDS[l.k].n) + ' bought outside at +20%, reputation hit</span>')); });
    buyers.forEach(l => { const b = getCo(l.b), sh = ann(co) > 0 && l.last ? l.last.x * l.last.f * l.last.pf * 52 / ann(co) : 0; if (sh > 0.1) rk.push(row('If ' + esc(b.name) + ' leaves', '<span class="neg">−' + Math.round(sh * 100) + '% of sales</span>')); });
    if (co.int27u > 0) rk.push(row('Capacity held for the group', Math.round(co.int27u) + ' ' + esc(unitPl(BD[co.type].unit, 2)) + ' a week'));
    if (rk.length) h += '<h2 class="sec">Risks</h2><div class="card">' + rk.join('') + '</div>';
    if (!ks.length && !buyers.length) h += '<div class="card"><span class="tipt">' + esc(co.name) + ' does not buy anything your other businesses could supply, and none of them buy from it.</span></div>';
    return h;
  };
  ACT.ch27k = p => {
    const co = getCo(p.id), k = p.k, K = KINDS[k];
    if (!co || !K) return;
    const l = linkOf(co, k), can = suppliersFor(co, k), x = spendOf(co, k) * 52;
    let h = '<h2>' + esc(K.n) + ' for ' + esc(co.name) + '</h2><p class="muted small">About ' + mshort(x) + ' a year. ' + (K.local ? 'Has to come from the same city.' : 'Can come from anywhere in ' + esc((CO[co.country] || CC()).name) + '.') + '</p>';
    if (!can.length) h += '<p class="small">None of your companies supply ' + esc(K.n.toLowerCase()) + (K.local ? ' in ' + esc(cityOf(co.city).name) : '') + '. A ' + esc(BD[K.sup[0]].n.toLowerCase()) + ' of your own could.</p>';
    can.forEach(s => {
      const u = K.nocap ? 0 : unitsOf(s, x / 52), cap = s.lastW ? (s.lastW.cap || 0) + (s.int27u || 0) : 0;
      const use = cap > 0 ? u / cap : 1, cr = costRatio(s);
      h += '<div class="card"><div class="bhead"><b>' + esc(s.name) + '</b>' + (l && l.s === s.id ? pillp('Current', 'grn') : '') + '</div>' +
        row('Uses of its capacity', K.nocap ? 'None' : '<span class="' + (use > 0.6 ? 'neg' : use > 0.3 ? 'amb' : '') + '">' + Math.round(use * 100) + '%</span>') +
        row('Its costs, as a share of its sales', Math.round(cr * 100) + '%') +
        '<div class="chips">' + Object.keys(MODES).map(md => { const pf = md === 'mkt' ? 1 : md === 'c10' ? Math.min(1, cr * 1.1) : Math.min(1, cr); return '<button class="btn chip' + (l && l.s === s.id && l.mode === md ? ' primary' : '') + '" data-a="ch27set" data-p="' + P({ id: co.id, k, s: s.id, m: md }) + '">' + MODES[md] + (pf < 1 ? ' · saves ' + mshort(x * (1 - pf)) : '') + '</button>'; }).join('') + '</div>' +
        '<span class="tipt">' + (use > 0.6 ? esc(s.name) + ' would have little room left for its own customers. ' : '') + 'Market price keeps the profit in ' + esc(s.name) + '; at cost it moves to ' + esc(co.name) + '. ' + (s.own < 100 || co.own < 100 ? 'Outside owners of the company that loses out will not like a price below market. ' : '') + 'If ' + esc(s.name) + ' is short of people or closes, ' + esc(co.name) + ' pays for emergency supply and its customers notice.</span></div>';
    });
    if (l) h += btn('Back to outside suppliers', 'ch27off', { id: co.id, k }, 'wide');
    h += btn('Close', 'sheetclose', undefined, 'ghost wide');
    openSheet(h);
  };
  ACT.ch27set = p => {
    const co = getCo(p.id), s = getCo(p.s);
    if (!co || !s) return;
    S.l27 = L27().filter(l => !(l.b === co.id && l.k === p.k));
    L27().push({ id: uid(), k: p.k, b: co.id, s: s.id, mode: p.m, w0: S.week });
    closeSheet();
    save();
    render(true);
    toast(esc(s.name) + ' now supplies ' + KINDS[p.k].n.toLowerCase() + ' to ' + co.name + '.');
  };
  ACT.ch27off = p => {
    S.l27 = L27().filter(l => !(l.b === p.id && l.k === p.k));
    closeSheet();
    save();
    render(true);
  };
  /* the company screen links to its supply chain */
  const ov1 = CT.ov;
  CT.ov = function (co, bd) {
    const h = ov1.apply(this, arguments);
    try {
      if (!co || co.st !== 'open') return h;
      const ks = kindsFor(co), mine = links().filter(l => l.b === co.id), sells = links().filter(l => l.s === co.id);
      if (!ks.length && !sells.length) {
        const isSup = Object.keys(KINDS).some(k => KINDS[k].sup.indexOf(co.type) >= 0);
        if (!isSup) return h;
      }
      const can = ks.filter(k => suppliersFor(co, k).length && !linkOf(co, k)).length;
      const sub = mine.length ? mine.length + ' input' + (mine.length > 1 ? 's' : '') + ' from your companies' : sells.length ? 'Supplies ' + sells.length + ' of your companies' : can ? can + ' input' + (can > 1 ? 's' : '') + ' your companies could supply' : 'Suppliers and customers';
      return h + '<div class="lrows"><button class="lrow" data-a="go" data-p="' + P({ n: 'chain27', p: { id: co.id } }) + '"><span class="lic">' + svg('truck', 20) + '</span><span class="ctext"><b>Supply chain</b><small>' + sub + (sells.length && mine.length ? ' · supplies ' + sells.length : '') + '</small></span>' + (can ? pillp('Idea', 'amb') : '') + '<i>›</i></button></div>';
    } catch (e) { console.error(e); return h; }
  };
})();

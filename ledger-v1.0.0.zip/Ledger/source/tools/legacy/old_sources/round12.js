/* ===== Round 12: shelf stock with deliveries (no sales cap), chains of your own stores with shared rules,
   one board per company or chain, your left hand on every board, and emergency meetings. ===== */
{
  const P12 = o => esc(JSON.stringify(o));
  const first = nm => String(nm || '').split(' ')[0];
  const r500 = v => Math.max(500, Math.round(v / 500) * 500);
  const kf = v => { const a = Math.abs(v || 0), s = v < 0 ? '−' : ''; return s + (a >= 1e6 ? (a / 1e6).toFixed(1) + ' M' : a >= 1e4 ? Math.round(a / 1e3) + ' k' : String(Math.round(a))); };
  const R10 = window.R10;
  const R12 = window.R12 = {};
  window.R12boards = 1;
  const wdOf = (w, d) => (new Date(wDate(w).getTime() + d * 86400000).getUTCDay() + 6) % 7;
  const liveCo = c => c && c.st !== 'sold' && c.st !== 'bust';
  const seg12 = (items, cur, act, p0) => '<div class="seg7 seg12">' + items.map(x => '<button class="' + (String(x[0]) === String(cur) ? 'on' : '') + '" data-a="' + act + '" data-p="' + P12(Object.assign({}, p0 || {}, { v: x[0] })) + '">' + x[1] + '</button>').join('') + '</div>';

  /* ================= A. the shelf: deliveries and who orders ================= */
  const every = bd => { const st = (bd.tw && bd.tw.stock) || 0; return !st || st <= 2 || (bd.tw && bd.tw.perish) ? 1 : st <= 14 ? 3.5 : 7; };
  const isDelivery = (bd, wd) => { const e = every(bd); return e === 1 || (e === 3.5 ? wd === 0 || wd === 3 : wd === 0); };
  const gapFrom = (bd, wd) => { const e = every(bd); return e === 1 ? 1 : e === 3.5 ? (wd < 3 ? 3 - wd : 7 - wd) : 7 - wd || 7; };
  function orderer(co) {
    if (co.mgr && S.npcs[co.mgr]) return { who: 'mgr', q: mgrQual(co), name: S.npcs[co.mgr].name };
    const a = co.asst;
    if (a && (a.duties || []).indexOf('equip') >= 0 && S.npcs[a.npc]) return { who: 'asst', q: clamp((S.npcs[a.npc].skill || 50) / 100, 0.2, 0.95), name: S.npcs[a.npc].name };
    return { who: 'owner', q: 0, name: 'You' };
  }
  R12.orderer = orderer;
  window.R12DELIV = function (co, bd, L, wk, d) {
    if (R10.kindOf(bd) !== 'goods') return;
    const wd = wdOf(wk, d);
    if (co.shelf != null && !isDelivery(bd, wd)) return;
    const gap = gapFrom(bd, wd), sh = R10.shapeOf(bd);
    let share = 0;
    for (let i = 0; i < gap; i++) share += sh[(wd + i) % 7];
    const o = orderer(co);
    let weekly, used;
    if (o.who === 'owner') {
      /* you order from last week: what sold, plus some of what you could not sell */
      weekly = co.dlast && co.dlast.u ? co.dlast.u + 0.6 * (co.dlast.lost || 0) : demand(co, bd).D;
      used = share;
    } else {
      weekly = demand(co, bd).D * Math.max(0.5, 1 + gauss() * (1 - o.q) * 0.25);
      used = share;
    }
    const expect = weekly * used;
    const pol = co.stockPol != null ? co.stockPol : 1;
    const cover = [1.0, 1.2, 1.5][pol] || 1.2;
    const target = Math.ceil(expect * cover + (o.who === 'owner' ? 0 : Math.sqrt(Math.max(0, expect)) * 0.6 * o.q));
    if (bd.tw && bd.tw.perish && co.shelf != null) {
      const spare = Math.max(0, co.shelf - 0.35 * (co.lastExp || 0));
      const unitCost = ticketEff(co, bd) * (bd.cogs || 0.3);
      if (spare > 0 && unitCost > 0) payCo(co, spare * unitCost * 0.25, 'loss', null);
      co.shelf = 0;
    }
    co.shelf = Math.max(co.shelf || 0, target);
    co.lastExp = expect;
  };
  /* the company overview tells you about sold-out days and overtime */
  const ur10 = window.unitsRows;
  window.unitsRows = function (co, bd, w) {
    let h = ur10.apply(this, arguments);
    const dl = co.dlast;
    if (dl && dl.so) h += row('Sold out last week', '<span class="neg">' + dl.so + (dl.so > 1 ? ' days' : ' day') + ' · about ' + dl.lost + ' sales lost</span>');
    if (dl && dl.ot) h += row('Overtime last week', '<span class="amb">' + dl.ot + ' ' + esc(unitPl(bd.unit, dl.ot)) + ' above normal hours</span>');
    if (R10.kindOf(bd) === 'goods' && co.shelf != null) h += row('Orders stock', esc(orderer(co).who === 'owner' ? 'You · ' + ['lean', 'normal', 'plenty'][co.stockPol || 0] : orderer(co).name + ' · by demand'));
    return h;
  };

  /* ================= B. chains ================= */
  const CHS = () => (S.chains = S.chains || []);
  const chainById = id => CHS().find(c => String(c.id) === String(id));
  const chainOf = co => co && co.chain ? chainById(co.chain) : null;
  const storesOf = ch => S.cos.filter(c => c.chain != null && String(c.chain) === String(ch.id) && liveCo(c));
  R12.chainOf = chainOf;
  R12.storesOf = storesOf;
  const MKL = { own: 0, light: 0.015, normal: 0.03, heavy: 0.05 };
  const PAYL = [[0, 'Market pay'], [0.05, '+5%'], [0.1, '+10%']];
  function makeChain(co, name) {
    if (co.chain) return chainOf(co);
    const ch = { id: uid(), name: name || co.name, type: co.type, w0: S.week, rules: { price: co.price || 0, knob: Object.assign({}, co.knob || {}), stockPol: co.stockPol != null ? co.stockPol : 1, pay: 0, mkt: 'own' } };
    CHS().push(ch);
    joinChain(ch, co, false);
    return ch;
  }
  function joinChain(ch, co, rename) {
    co.chain = ch.id;
    co.off = co.off || { price: 0, mkt: 0, pay: 0, stock: null };
    if (rename && !String(co.name).startsWith(ch.name)) co.name = storeName(ch, co);
    applyRules(ch, co);
    const rg = chiefFor(ch, co);
    if (rg) co.region = rg.id;
  }
  function storeName(ch, co) {
    const cn = cityOf(co.city).name, taken = n => S.cos.some(c => c !== co && c.name === n);
    let n = ch.name + ' ' + cn;
    if (!taken(n)) return n;
    for (let i = 2; i < 40; i++) if (!taken(ch.name + ' ' + cn + ' ' + i)) return ch.name + ' ' + cn + ' ' + i;
    return ch.name + ' ' + uid();
  }
  function applyRules(ch, co) {
    const R = ch.rules, o = co.off || {};
    co.price = clamp((window.PX16 && o.pp ? PX16.lvl(PX16.pm(R.price || 0) * (1 + o.pp)) : (R.price || 0)) + (o.price || 0), -3, 3);
    co.knob = Object.assign({}, co.knob || {}, R.knob || {});
    co.stockPol = o.stock != null ? o.stock : R.stockPol;
  }
  R12.applyAll = ch => storesOf(ch).forEach(c => applyRules(ch, c));
  const chiefs = ch => ((S.group && S.group.regional) || []).filter(r => String(r.scope) === 'chain:' + ch.id || String(r.scope).indexOf('chain:' + ch.id + ':') === 0);
  function chiefFor(ch, co) {
    const L = chiefs(ch);
    return L.find(r => r.scope === 'chain:' + ch.id + ':' + co.city) || L.find(r => r.scope === 'chain:' + ch.id) || null;
  }
  /* weekly: rules, brand marketing, shared customers, volume discounts, cheaper books, chiefs, hints */
  function fitCh(bd, k) { const c = CH[k]; return chAff(bd, k) * ((1 - bd.aud) * (c.loc || 0.5) + bd.aud * (c.b2b || 0.5)) * c.eff; }
  function chainWeek() {
    CHS().forEach(ch => {
      const L = storesOf(ch);
      if (!L.length) return;
      const bd = BD[ch.type], n = L.length;
      L.forEach(co => {
        applyRules(ch, co);
        const rg = chiefFor(ch, co);
        if (rg) co.region = rg.id;
        if (co.st !== 'open') return;
        const lvl = MKL[ch.rules.mkt] || 0, own = ch.rules.mkt === 'own';
        if (!own || (co.off && co.off.mkt)) {
          const rev = co.lastW ? co.lastW.rev || 0 : 0;
          const share = (own ? 0 : lvl) + ((co.off && co.off.mkt) || 0);
          const ks = Object.keys(CH).filter(k => !CH[k].prem && !CH[k].nat && !CH[k].var).sort((a, b) => fitCh(bd, b) - fitCh(bd, a)).slice(0, 2);
          const b = Math.round(Math.max(rev * share, share > 0 ? KC(300) : 0) / ks.length);
          (co.mk12 || []).forEach(k => { if (ks.indexOf(k) < 0) delete co.mkt[k]; });
          ks.forEach(k => { if (b > 0) co.mkt[k] = { b, since: (co.mkt[k] && co.mkt[k].since) || S.week }; else delete co.mkt[k]; });
          co.mk12 = ks;
        }
        if (n >= 2 && co.lastW && co.lastW.cogs > 0) rebate(co, co.lastW.cogs * Math.min(0.05, 0.01 * (n - 1)));
        const acc = co.bk && co.bk.w ? co.bk.w.acc || 0 : 0;
        if (n >= 2 && acc > 0) { coIn(co, Math.round(acc * 0.15), null, null); bk(co, 'acc', -Math.round(acc * 0.15)); }
      });
      const byCity = {};
      L.forEach(c => { byCity[c.city] = Math.max(byCity[c.city] || 0, c.aware || 0); });
      L.forEach(c => { c.aware = Math.max(c.aware || 0, byCity[c.city] * 0.85); });
      if (isMonthEnd(S.week)) L.forEach(co => co.staff.forEach(s => {
        const nn = S.npcs[s.id];
        if (!nn) return;
        const tgt = wageFor(s.role, co) * (0.7 + (nn.skill || 50) / 160) * (1 + (ch.rules.pay || 0) + ((co.off && co.off.pay) || 0));
        if (s.wage < tgt * 0.97) s.wage = Math.round(tgt / 100) * 100;
      }));
      const cities = new Set(L.map(c => c.city)).size;
      if (n >= 3 && !chiefs(ch).length && !ch.sug3) {
        ch.sug3 = S.week;
        addMsg({ kind: 'info', from: 'Your left hand', title: ch.name + ' has ' + n + ' stores. Time for a chain chief?', body: 'A chain chief keeps every store on the chain’s rules, coaches the store managers and moves staff to where they are needed. You can promote one of your store managers or search outside.', co: L[0].id, tone: 'n', status: 'done', go: { l: 'See the chain team', a: 'go', p: { n: 'chain12', p: { id: ch.id, t: 'team' } } } });
      }
      if (n >= 8 && cities >= 2 && !ch.sug8) {
        ch.sug8 = S.week;
        addMsg({ kind: 'info', from: chiefs(ch)[0] && S.npcs[chiefs(ch)[0].npc] ? S.npcs[chiefs(ch)[0].npc].name : 'Your left hand', title: ch.name + ' is too big for one chief', body: n + ' stores in ' + cities + ' cities. One chief per area would keep closer to each store.', co: L[0].id, tone: 'n', status: 'done', go: { l: 'See the chain team', a: 'go', p: { n: 'chain12', p: { id: ch.id, t: 'team' } } } });
      }
    });
  }
  /* promotions: a store manager or worker can become chain chief */
  window.R12chiefPosts = function (c) {
    const ch = chainOf(c.co);
    if (!ch) return [];
    const L = storesOf(ch), out = [];
    if (!chiefs(ch).some(r => r.scope === 'chain:' + ch.id) && L.length >= 2) out.push({ k: 'chain:' + ch.id, t: 'Chain chief', where: ch.name + ' · ' + L.length + ' stores' });
    if (L.length >= 8) Array.from(new Set(L.map(x => x.city))).forEach(city => { if (!chiefs(ch).some(r => r.scope === 'chain:' + ch.id + ':' + city)) out.push({ k: 'chain:' + ch.id + ':' + city, t: 'Area chief', where: ch.name + ' · ' + cityOf(city).name }); });
    return out;
  };
  window.R12hireChief = function (scope, n, w, auth) {
    scope = String(scope);
    const id = scope.split(':')[0], ch = chainById(id);
    if (!ch) return false;
    n.hired = -1;
    const rg = { id: uid(), npc: n.id, scope: 'chain:' + scope, wage: w, lvl: auth == null ? 1 : auth, buy: [0, 250000, 1e9][auth == null ? 1 : auth] };
    S.group.regional.push(rg);
    storesOf(ch).forEach(c => { const r = chiefFor(ch, c); if (r) c.region = r.id; });
    return rg;
  };
  window.R12execSeat = function (n, post) {
    if (post.k.indexOf('chain:') !== 0) return 'none';
    const ch = chainById(post.k.slice(6).split(':')[0]);
    return ch ? addSeat('ch:' + ch.id, { id: n.id, kind: 'exec', t: post.t }) : 'none';
  };

  /* ---------- the Companies tab: a chain is one folder card ---------- */
  const shown = new Set();
  const cc0 = coCard2;
  coCard2 = function (co) {
    const ch = chainOf(co);
    if (!ch) return cc0.apply(this, arguments);
    if (shown.has(ch.id)) return '';
    shown.add(ch.id);
    return chainCard(ch);
  };
  function chainCard(ch) {
    const L = storesOf(ch), bd = BD[ch.type];
    const tot = sum(L, c => lastProfit(c) || 0);
    const cf = chiefs(ch)[0], cn = cf && S.npcs[cf.npc];
    const bad = L.filter(c => badAlerts(c).length).length;
    const tag = cn ? '<span class="badge green">' + esc(first(cn.name)) + ' runs it</span>' : bad ? '<span class="badge red">' + bad + ' need you</span>' : '<span class="badge blue">' + L.length + ' stores</span>';
    return '<button class="ccard ch12" data-a="go" data-p="' + P12(L.length === 1 ? { n: 'co', p: { id: L[0].id } } : { n: 'chain12', p: { id: ch.id } }) + '"><div class="cchd"><span class="avst">' + L.slice(0, 3).map(c => av(ini(c.name))).join('') + '</span><span class="ctext"><b>' + esc(ch.name) + '</b><small>Chain · ' + esc(bd.n) + ' · ' + L.length + ' stores</small></span>' + tag + '</div>' +
      '<div class="duo"><div><span>Last month</span><b class="' + sgn(tot) + '">' + plus(tot) + '</b></div><div><span>Staff</span><b>' + sum(L, c => c.staff.length + (c.mgr ? 1 : 0)) + '</b></div></div>' +
      '<div class="chrows">' + L.slice(0, 3).map(c => { const p = lastProfit(c); const m = c.mgr && S.npcs[c.mgr]; return '<div class="chr"><span>' + esc(c.name) + '</span><small>' + esc(m ? m.name : 'You run it') + '</small><b class="' + (p == null ? '' : sgn(p)) + '">' + (p == null ? '—' : kf(p)) + '</b></div>'; }).join('') + (L.length > 3 ? '<div class="chr more"><span>+ ' + (L.length - 3) + ' more</span></div>' : '') + '</div></button>';
  }
  const cos12 = V.cos;
  V.cos = function () { shown.clear(); return cos12.apply(this, arguments); };

  /* ---------- the chain folder ---------- */
  V.titles.chain12 = 'Chain';
  V.heads.chain12 = p => { const ch = chainById(p.id); return ch ? { t: ch.name, sub: 'Chain · ' + BD[ch.type].n + ' · ' + storesOf(ch).length + ' stores' } : {}; };
  V.chain12 = function (p) {
    if (R12.chainX) { const r = R12.chainX(p); if (r != null) return r; }
    const ch = chainById(p.id);
    if (!ch) return '<div class="calm">This chain no longer exists.</div>';
    const L = storesOf(ch);
    const t = p.t || 'all';
    let h = '<div class="ptabs">' + [['all', 'All stores'], ['rules', 'Rules'], ['team', 'Team'], ['board', 'Board']].map(x => '<button class="' + (t === x[0] ? 'on' : '') + '" data-a="ch12tab" data-p="' + P12({ id: ch.id, t: x[0] }) + '">' + x[1] + '</button>').join('') + '</div>';
    h += chips(L.map(c => [c.id, c.name.replace(ch.name, '').trim() || c.name]), t === 'store' ? p.s : '', 'ch12store', { id: ch.id });
    if (t === 'store') return h + storeTab(ch, getCo(p.s));
    if (t === 'rules') return h + rulesTab(ch);
    if (t === 'team') return h + teamTab(ch);
    if (t === 'board') return h + boardView('ch:' + ch.id);
    return h + allTab(ch);
  };
  ACT.ch12tab = p => { ui.view.p = { id: p.id, t: p.t }; render(true); };
  ACT.ch12store = p => { ui.view.p = { id: p.id, t: 'store', s: p.v }; render(true); };
  function monthOf(c, i) { const H = c.hist || []; return H[H.length - 1 - (i || 0)] || {}; }
  function allTab(ch) {
    const L = storesOf(ch);
    const rev = sum(L, c => monthOf(c).rev || 0), pr = sum(L, c => monthOf(c).profit || 0);
    let h = '<div class="tri"><div><span>Revenue/mo</span><b>' + kf(rev) + '</b></div><div><span>Profit/mo</span><b class="' + sgn(pr) + '">' + kf(pr) + '</b></div><div><span>Staff</span><b>' + sum(L, c => c.staff.length + (c.mgr ? 1 : 0)) + '</b></div></div>';
    const cf = chiefs(ch);
    if (cf.length) h += '<div class="lrows">' + cf.map(r => { const n = S.npcs[r.npc]; return '<div class="lrow">' + faceAv(n) + '<span class="ctext"><b>' + esc(n.name) + '</b><small>' + (r.scope.split(':').length > 2 ? 'Area chief · ' + esc(cityOf(r.scope.split(':')[2]).name) : 'Chain chief') + ' · ' + mshort(r.wage) + '/mo</small></span></div>'; }).join('') + '</div>';
    else if (L.length >= 3) h += '<div class="card dec1"><b>Hire a chain chief</b><span class="tipt">' + L.length + ' stores is a lot to run yourself. A chief keeps every store on the rules and coaches the managers.</span><div class="two">' + btn('Promote one of yours', 'ch12tab', { id: ch.id, t: 'team' }, 'primary') + btn('Search outside', 'go', { n: 'chief12', p: { id: ch.id } }, 'ghost') + '</div></div>';
    h += '<h2 class="sec">Stores</h2><div class="lrows">' + L.map(c => { const p = lastProfit(c); const m = c.mgr && S.npcs[c.mgr]; const al = badAlerts(c); return '<button class="lrow" data-a="ch12store" data-p="' + P12({ id: ch.id, v: c.id }) + '">' + av(ini(c.name)) + '<span class="ctext"><b>' + esc(c.name) + '</b><small>' + (al.length ? '<em class="neg">' + esc(al[0][0]) + '</em>' : esc(m ? m.name : 'You run it · ' + (c.ohrs || 0) + ' h')) + (offCount(c) ? ' · own rules' : '') + '</small></span><b class="num ' + (p == null ? '' : sgn(p)) + '">' + (p == null ? '—' : kf(p)) + '</b></button>'; }).join('') + '</div>';
    h += '<div class="two">' + btn('＋ Open a new store', 'ch12new', { id: ch.id }, 'primary') + btn('Add a company', 'ch12tab', { id: ch.id, t: 'team' }, 'ghost') + '</div>';
    return h;
  }
  const offCount = c => { const o = c.off || {}; return (o.price || o.pp ? 1 : 0) + (o.mkt ? 1 : 0) + (o.pay ? 1 : 0) + (o.stock != null ? 1 : 0); };
  function storeTab(ch, c) {
    if (!c || String(c.chain) !== String(ch.id)) return '<div class="calm">Pick a store.</div>';
    const m0 = monthOf(c), m1 = monthOf(c, 1);
    const mg = m0.rev ? Math.round((m0.profit || 0) / m0.rev * 100) + '%' : '—';
    const m = c.mgr && S.npcs[c.mgr];
    let h = '<div class="tri"><div><span>Revenue/mo</span><b>' + kf(m0.rev || 0) + '</b></div><div><span>Profit/mo</span><b class="' + sgn(m0.profit || 0) + '">' + kf(m0.profit || 0) + '</b></div><div><span>Margin</span><b>' + mg + '</b></div></div>';
    h += '<div class="card">' + row('Run by', esc(m ? m.name : 'You · ' + (c.ohrs || 0) + ' h a week')) + row('Staff', c.staff.length) + row('Rating', ratingOf(c).toFixed(1) + ' ★') + row('City', esc(cityOf(c.city).name)) + (m1.rev ? row('Month before', kf(m1.rev) + ' revenue · ' + kf(m1.profit || 0) + ' profit') : '') + (c.dlast && c.dlast.so ? row('Sold out last week', '<span class="neg">' + c.dlast.so + (c.dlast.so > 1 ? ' days' : ' day') + '</span>') : '') + '</div>';
    const o = c.off = c.off || { price: 0, mkt: 0, pay: 0, stock: null };
    const own = (v, d) => v !== d ? ' <span class="pill amb">Own rule</span>' : '';
    h += '<h2 class="sec">Own rules for this store</h2><div class="card">' +
      '<div class="bhead"><b>Price</b>' + own((o.pp || 0) + (o.price || 0), 0) + '</div>' + seg12([[-0.1, '−10%'], [-0.05, '−5%'], [0, 'Chain'], [0.05, '+5%'], [0.1, '+10%']], o.pp || 0, 'ch12off', { id: c.id, k: 'pp' }) +
      '<div class="bhead gap"><b>Local marketing</b>' + own(o.mkt, 0) + '</div>' + seg12([[0, 'None extra'], [0.01, '+1%'], [0.02, '+2%'], [0.03, '+3%']], o.mkt, 'ch12off', { id: c.id, k: 'mkt' }) +
      '<div class="bhead gap"><b>Pay</b>' + own(o.pay, 0) + '</div>' + seg12([[-0.1, '−10%'], [0, 'Chain pay'], [0.1, '+10%']], o.pay, 'ch12off', { id: c.id, k: 'pay' }) +
      (R10.kindOf(BD[ch.type]) === 'goods' ? '<div class="bhead gap"><b>Ordering</b>' + own(o.stock, null) + '</div>' + seg12([['', 'Chain'], [0, 'Lean'], [1, 'Normal'], [2, 'Plenty']], o.stock == null ? '' : o.stock, 'ch12off', { id: c.id, k: 'stock' }) : '') +
      '<span class="tipt">Opening hours and business choices always follow the chain.</span></div>';
    h += btn('Open the full store page ›', 'go', { n: 'co', p: { id: c.id } }, 'wide');
    return h;
  }
  ACT.ch12off = p => {
    const c = getCo(p.id), ch = chainOf(c);
    if (!ch) return;
    c.off = c.off || { price: 0, mkt: 0, pay: 0, stock: null };
    c.off[p.k] = p.k === 'stock' ? (p.v === '' ? null : +p.v) : +p.v;
    applyRules(ch, c);
    save();
    render();
  };
  function rulesTab(ch) {
    const R = ch.rules, bd = BD[ch.type];
    let h = '<div class="card sense"><span class="tipt">Set once for every store. A store can get its own price step, local marketing, pay and ordering in its tab. Opening hours are the same everywhere.</span></div>';
    h += window.PX16 ? PX16.chainCard(ch) : '<div class="card"><div class="bhead"><b>Prices</b></div>' + chips(PRICE_NAMES.map((n, i) => [i - 3, n]), R.price, 'ch12rule', { id: ch.id, k: 'price' }) + '</div>';
    (bd.knobs || []).forEach(k => {
      h += '<div class="card"><div class="bhead"><b>' + esc(k.n) + '</b>' + (k.id === 'hrs' ? '<span class="pill">Same in every store</span>' : '') + '</div>' + chips(k.opts.map((o, i) => [i, o.n]), R.knob[k.id] != null ? R.knob[k.id] : (k.def || 0), 'ch12rule', { id: ch.id, k: 'knob', kk: k.id }) + '</div>';
    });
    if (R10.kindOf(bd) === 'goods') h += '<div class="card"><div class="bhead"><b>Ordering</b></div>' + seg12([[0, 'Lean'], [1, 'Normal'], [2, 'Plenty']], R.stockPol, 'ch12rule', { id: ch.id, k: 'stockPol' }) + '<span class="tipt">Store managers order by demand. Without a manager the store orders from last week’s sales.</span></div>';
    h += '<div class="card"><div class="bhead"><b>Pay</b></div>' + seg12(PAYL, R.pay, 'ch12rule', { id: ch.id, k: 'pay' }) + '<span class="tipt">Checked every month. Anyone below the chain’s level gets a raise.</span></div>';
    h += '<div class="card"><div class="bhead"><b>Marketing</b></div>' + seg12([['own', 'Each store'], ['light', 'Light'], ['normal', 'Normal'], ['heavy', 'Heavy']], R.mkt, 'ch12rule', { id: ch.id, k: 'mkt' }) + '<span class="tipt">One brand: what you spend in a city helps every store there.</span></div>';
    return h;
  }
  ACT.ch12rule = p => {
    const ch = chainById(p.id);
    if (!ch) return;
    if (p.k === 'knob') ch.rules.knob[p.kk] = +p.v;
    else if (p.k === 'mkt') ch.rules.mkt = p.v;
    else ch.rules[p.k] = +p.v;
    R12.applyAll(ch);
    save();
    render();
    toast('Every store follows the new rule.');
  };
  function teamTab(ch) {
    const L = storesOf(ch);
    let h = '';
    const cf = chiefs(ch);
    h += '<h2 class="sec">Chiefs</h2>' + (cf.length ? '<div class="lrows">' + cf.map(r => { const n = S.npcs[r.npc]; return '<div class="lrow">' + faceAv(n) + '<span class="ctext"><b>' + esc(n.name) + '</b><small>' + (r.scope.split(':').length > 2 ? 'Area chief · ' + esc(cityOf(r.scope.split(':')[2]).name) : 'Chain chief') + ' · ' + mshort(r.wage) + '/mo</small></span>' + btn('Let go', 'ch12fire', { r: r.id }, 'chip ghost') + '</div>'; }).join('') + '</div>' : '<div class="card"><p class="muted small">' + (L.length >= 3 ? 'No chief yet. Promote a store manager or search outside.' : 'A chief makes sense from 3 stores.') + '</p>' + btn('Search outside', 'go', { n: 'chief12', p: { id: ch.id } }, 'wide') + '</div>');
    h += '<h2 class="sec">Store managers</h2><div class="lrows">' + L.map(c => { const m = c.mgr && S.npcs[c.mgr]; return m ? '<button class="lrow" data-a="go" data-p="' + P12({ n: 'pr11', p: { id: c.id, m: 1 } }) + '">' + faceAv(m) + '<span class="ctext"><b>' + esc(m.name) + '</b><small>' + esc(c.name) + ' · promote ›</small></span></button>' : '<button class="lrow" data-a="go" data-p="' + P12({ n: 'mgrhire', p: { id: c.id } }) + '">' + av(ini(c.name)) + '<span class="ctext"><b>' + esc(c.name) + '</b><small class="neg">No manager · find one ›</small></span></button>'; }).join('') + '</div>';
    const short = [];
    L.forEach(c => stdStaff(BD[c.type], c.size).forEach(r => { const have = c.staff.filter(x => x.role === r[0]).length; if (have < r[1]) { const from = L.find(o => o !== c && o.staff.filter(x => x.role === r[0]).length > stdStaff(BD[o.type], o.size).filter(z => z[0] === r[0]).reduce((a, z) => a + z[1], 0)); short.push({ c, r: r[0], from }); } }));
    if (short.length) h += '<h2 class="sec">Short of staff</h2><div class="lrows">' + short.slice(0, 6).map(x => '<div class="lrow"><span class="ctext"><b>' + esc(x.c.name) + '</b><small>Needs a ' + esc(ROLES[x.r][0].toLowerCase()) + (x.from ? ' · ' + esc(x.from.name) + ' has one spare' : '') + '</small></span>' + (x.from ? btn('Move one', 'ch12lend', { from: x.from.id, to: x.c.id, r: x.r }, 'chip primary') : btn('Hire', 'hirego', { id: x.c.id }, 'chip')) + '</div>').join('') + '</div>';
    const join = S.cos.filter(c => liveCo(c) && c.type === ch.type && !c.chain);
    if (join.length) h += '<h2 class="sec">Add your other ' + esc(BD[ch.type].n.toLowerCase()) + ' companies</h2><div class="lrows">' + join.map(c => '<div class="lrow">' + av(ini(c.name)) + '<span class="ctext"><b>' + esc(c.name) + '</b><small>' + esc(cityOf(c.city).name) + '</small></span>' + btn('Add', 'ch12join', { id: ch.id, c: c.id, rn: 0 }, 'chip') + btn('Add, rename', 'ch12join', { id: ch.id, c: c.id, rn: 1 }, 'chip primary') + '</div>').join('') + '</div>';
    return h;
  }
  ACT.ch12fire = p => { fireExec('region', p.r); save(); render(); };
  ACT.ch12lend = p => {
    const a = getCo(p.from), b = getCo(p.to);
    if (!a || !b) return;
    const s = a.staff.filter(x => x.role === p.r).sort((x, y) => staffSkill(x) - staffSkill(y))[0];
    if (!s) return;
    a.staff = a.staff.filter(x => x !== s);
    b.staff.push(s);
    if (S.npcs[s.id]) S.npcs[s.id].hired = b.id;
    toast(S.npcs[s.id].name + ' moves to ' + b.name + '.');
    save();
    render();
  };
  ACT.ch12join = p => {
    const ch = chainById(p.id), c = getCo(p.c);
    if (!ch || !c) return;
    joinChain(ch, c, !!p.rn);
    toast(c.name + ' joins ' + ch.name + '.');
    save();
    render();
  };
  ACT.ch12new = p => {
    if (R12.newStoreX) return R12.newStoreX(p);
    const ch = chainById(p.id);
    if (!ch) return;
    ui.chainNew = ch.id;
    ui.nc = null;
    go('newco', { bd: ch.type });
  };
  const sc0 = window.startCompany;
  window.startCompany = function (type, o) {
    const co = sc0.apply(this, arguments);
    try {
      if (co && typeof co === 'object' && ui.chainNew) {
        const ch = chainById(ui.chainNew);
        ui.chainNew = null;
        if (ch && ch.type === type) joinChain(ch, co, true);
      }
    } catch (e) { console.error(e); }
    return co;
  };
  /* search outside for a chain chief */
  V.titles.chief12 = 'Chain chief';
  V.chief12 = function (p) {
    const ch = chainById(p.id);
    if (!ch) return '';
    const C = (ch.cands || []).map(id => S.npcs[id]).filter(n => n && !n.hired);
    let h = '<div class="card sense"><span class="tipt">A chain chief works from your stores, so no office desk is needed. They check every store against the rules, coach managers and move staff.</span></div>';
    h += btn('Search · ' + mshort(KC(20000)), 'ch12find', { id: ch.id }, C.length ? 'wide' : 'primary wide');
    h += C.map(n => '<div class="card"><div class="cchd">' + faceAv(n) + '<span class="ctext"><b>' + esc(n.name) + '</b><small>' + n.age + ' · ' + esc(n.resume || 'experienced manager') + '</small></span></div>' + row('Asks', money(n.ask) + '/mo') + '<div class="chips">' + [0.9, 1, 1.1].map(f => btn(Math.round(f * 100) + '% · ' + mshort(r500(n.ask * f)), 'ch12hire', { id: ch.id, n: n.id, w: r500(n.ask * f) }, 'chip' + (f === 1 ? ' primary' : ''))).join('') + '</div></div>').join('');
    return h;
  };
  ACT.ch12find = p => {
    const ch = chainById(p.id), cost = KC(20000);
    if (!ch) return;
    if (S.cash < cost) { U.res('cash'); return; }
    payMe(cost, 'Search for a chain chief');
    ch.cands = [0, 1, 2].map(() => { const n = genExec('region'); S.npcs[n.id] = n; return n.id; });
    save();
    render();
  };
  ACT.ch12hire = p => {
    const ch = chainById(p.id), n = S.npcs[p.n];
    if (!ch || !n || n.hired) return;
    const pr = clamp((p.w / n.ask - 0.88) / 0.14, 0, 1);
    if (p.w < n.ask && !chance(pr)) { toast(first(n.name) + ' turns it down at that pay.', true); ch.cands = ch.cands.filter(x => x !== n.id); save(); render(); return; }
    R12hireChief(ch.id, n, p.w, 1);
    addSeat('ch:' + ch.id, { id: n.id, kind: 'exec', t: 'Chain chief' });
    n.k11 = { post: 'chain:' + ch.id, t: 'Chain chief', wage: p.w, bonus: 0, duties: ['quality', 'coach'], auth: 1, rep: 'month', w0: S.week };
    ch.cands = [];
    toast(n.name + ' is your chain chief.');
    save();
    U.back();
  };
  /* the Grow tab: make a chain, or see the one this company belongs to */
  function growCard(co) {
    if (R12.growX) return R12.growX(co);
    const ch = chainOf(co);
    if (ch) return '<div class="card"><div class="bhead"><b>Part of ' + esc(ch.name) + '</b><span class="pill blue">' + storesOf(ch).length + ' stores</span></div><span class="tipt">Same name, same owner, its own manager and staff. Rules are set for the whole chain.</span><div class="two">' + btn('Open the chain', 'go', { n: 'chain12', p: { id: ch.id } }, 'primary') + btn('＋ New store', 'ch12new', { id: ch.id }, 'ghost') + '</div></div>';
    if (co.st !== 'open' || ['fin', 'energy', 'club', 'hold', 'rent'].indexOf(BD[co.type].fam) >= 0) return '';
    return '<div class="card"><div class="bhead"><b>Make it a chain</b></div><span class="tipt">Open more stores under the same name. Each store has its own manager and staff, follows shared rules, and the chain gets its own folder.</span>' + U.inp('ch12n', 'Chain name', co.name, 'text') + btn('Make ' + esc(co.name) + ' a chain', 'ch12make', { id: co.id }, 'primary wide') + '</div>';
  }
  ACT.ch12make = p => {
    const co = getCo(p.id);
    if (!co) return;
    const nm = String((ui.inp && ui.inp.ch12n) || co.name).trim() || co.name;
    const ch = makeChain(co, nm);
    save();
    go('chain12', { id: ch.id, t: 'team' });
    toast(ch.name + ' is now a chain. Add stores or open new ones.');
  };
  ['sites', 'franchisor'].forEach(k => {
    const f0 = window.CT[k];
    if (f0) window.CT[k] = function (co) { return growCard(co) + f0.apply(this, arguments); };
  });

  /* ================= C. boards: one per company or chain ================= */
  const MAXB = 7;
  function brdKeyOf(co) { return co.chain && chainById(co.chain) ? 'ch:' + co.chain : 'co:' + co.id; }
  function brdOf(key) {
    const [t, id] = [key.slice(0, 2), key.slice(3)];
    const o = t === 'ch' ? chainById(id) : getCo(+id) || S.cos.find(c => String(c.id) === id);
    if (!o) return null;
    o.brd = o.brd || { seats: [], mode: 'needed', freq: 4, last: -99, mts: [], cands: [] };
    return o.brd;
  }
  const brdName = key => key.slice(0, 2) === 'ch' ? (chainById(key.slice(3)) || {}).name : ((getCo(+key.slice(3)) || S.cos.find(c => String(c.id) === key.slice(3)) || {}).name);
  const brdCos = key => key.slice(0, 2) === 'ch' ? (chainById(key.slice(3)) ? storesOf(chainById(key.slice(3))) : []) : [getCo(+key.slice(3)) || S.cos.find(c => String(c.id) === key.slice(3))].filter(liveCo);
  R12.brdOf = brdOf;
  function addSeat(key, seat) {
    const b = brdOf(key);
    if (!b) return false;
    if (b.seats.some(x => x.id === seat.id)) return true;
    if (b.seats.length + 2 >= MAXB) return false;
    b.seats.push(Object.assign({ w0: S.week, fee: 0, ok: 0, no: 0, mood: 60 }, seat));
    return true;
  }
  function seatsOf(key) {
    const b = brdOf(key);
    if (!b) return [];
    b.seats = b.seats.filter(x => { const n = S.npcs[x.id]; return n && (x.kind === 'adv' ? n.hired === -4 : n.hired === -1 || n.hired === -2 || n.hired === -3); });
    return b.seats;
  }
  const LH = () => S.lh && S.npcs[S.lh.id] ? S.lh : null;
  const lhN = () => LH() ? S.npcs[S.lh.id] : null;
  const ADV12 = { fin: ['Finance advisor', 'fin'], law: ['Legal advisor', 'risk'], ind: ['Industry expert', 'ops'], mkt: ['Marketing advisor', 'sales'], chair: ['Experienced chair', 'people'] };
  const qOf = n => n && n.stats ? (n.stats.ops + n.stats.people + n.stats.sales + n.stats.fin + n.stats.risk) / 500 : 0.5;
  /* move the old group board: advisors go to the board of your biggest company */
  function migrate() {
    const b = S.board;
    if (!b || b.m12) return;
    b.m12 = 1;
    const big = liveCos().filter(c => c.st === 'open' && c.type !== 'hold').sort((x, y) => ((monthOf(y).rev || 0) - (monthOf(x).rev || 0)))[0];
    (b.seats || []).forEach(x => { if (x.kind === 'adv' && big) addSeat(brdKeyOf(big), x); });
    b.seats = [];
  }
  function boardView(key) {
    if (R12.boardViewX) return R12.boardViewX(key);
    migrate();
    const b = brdOf(key);
    if (!b) return '<div class="calm">No board.</div>';
    const L = seatsOf(key), cos = brdCos(key), lh = lhN();
    const co0 = cos[0];
    let h = '<div class="card"><div class="bhead"><b>' + (L.length + 1 + (lh ? 1 : 0)) + ' of ' + MAXB + ' at the table</b><span class="pill blue">' + (b.mode === 'regular' ? (b.freq === 13 ? 'Every quarter' : 'Every month') : 'Only when needed') + '</span></div>' +
      seg12([['regular', 'Regular meetings'], ['needed', 'Only when needed']], b.mode, 'bd12mode', { k: key }) + (b.mode === 'regular' ? seg12([[4, 'Monthly'], [13, 'Quarterly']], b.freq, 'bd12freq', { k: key }) : '') +
      '<span class="tipt">' + (b.mode === 'regular' ? 'Meets on schedule, and at once if something drastic happens.' : 'Meets only for emergencies and big decisions.') + '</span>' + btn('Hold a meeting now', 'bd12meet', { k: key }, 'wide') + '</div>';
    h += '<div class="lrows"><div class="lrow"><span class="av">' + esc(ini(S.player.name)) + '</span><span class="ctext"><b>' + esc(S.player.name) + '</b><small>You · chair</small></span></div>' +
      (lh ? '<div class="lrow">' + faceAv(lh) + '<span class="ctext"><b>' + esc(lh.name) + '</b><small>Your left hand · on every board</small></span></div>' : '<button class="lrow" data-a="go" data-p="' + P12({ n: 'boards12', p: {} }) + '"><span class="av dim">＋</span><span class="ctext"><b>Your left hand</b><small>Hire a personal advisor who sits on every board ›</small></span></button>') +
      cos.filter(c => c.mgr && S.npcs[c.mgr]).slice(0, 3).map(c => '<div class="lrow">' + faceAv(S.npcs[c.mgr]) + '<span class="ctext"><b>' + esc(S.npcs[c.mgr].name) + '</b><small>' + esc(titleFor(c, 'mgr')) + (cos.length > 1 ? ' · ' + esc(c.name) : '') + ' · reports, no vote</small></span></div>').join('') +
      L.map(x => { const n = S.npcs[x.id]; return '<div class="lrow">' + faceAv(n) + '<span class="ctext"><b>' + esc(n.name) + '</b><small>' + esc(x.t) + (x.fee ? ' · ' + mshort(x.fee) + '/mo' : '') + (x.ok + x.no ? ' · ' + Math.round(x.ok / (x.ok + x.no) * 100) + '% of advice taken' : '') + '</small></span>' + (x.kind === 'adv' ? btn('Remove', 'bd12rm', { k: key, id: x.id }, 'chip ghost') : '') + '</div>'; }).join('') +
      (co0 && co0.own < 100 ? '<div class="lrow"><span class="av dim">IN</span><span class="ctext"><b>Investors</b><small>Outside owners · ' + Math.round(100 - co0.own) + '% · vote on big moves</small></span></div>' : '') + '</div>';
    if (L.length + 2 < MAXB) {
      h += '<h2 class="sec">Invite an advisor</h2><div class="chips">' + Object.keys(ADV12).map(k => btn(ADV12[k][0], 'bd12find', { k: key, t: k }, 'chip')).join('') + '</div>';
      const C = (b.cands || []).map(id => S.npcs[id]).filter(n => n && !n.hired);
      if (C.length) h += C.map(n => '<div class="card"><div class="cchd">' + faceAv(n) + '<span class="ctext"><b>' + esc(n.name) + '</b><small>' + esc(ADV12[n.adv][0]) + ' · ' + n.age + ' · ' + esc(n.advBg || '') + '</small></span></div><div class="chips">' + [0.9, 1, 1.15].map(f => btn(mshort(r500(n.fee11 * f)) + '/mo', 'bd12inv', { k: key, n: n.id, f: r500(n.fee11 * f) }, 'chip' + (f === 1 ? ' primary' : ''))).join('') + '</div></div>').join('');
    }
    const M = (b.mts || []).slice(0, 5);
    if (M.length) h += '<h2 class="sec">Meetings</h2><div class="lrows">' + M.map(m => '<button class="lrow" data-a="go" data-p="' + P12({ n: 'bmeet12', p: { k: key, id: m.id } }) + '"><span class="ctext"><b>' + (m.emg ? 'Emergency · ' : '') + esc(dateStr(m.w)) + '</b><small>' + esc(m.emg ? m.title : m.items.length + ' points · ' + m.items.filter(x => x.st === 'yes').length + ' taken') + '</small></span>' + (m.emg ? '<span class="pill ' + (m.st ? '' : 'red') + '">' + (m.st === 'late' ? 'No answer' : m.st ? 'Decided' : 'Open') + '</span>' : '') + '<i>›</i></button>').join('') + '</div>';
    return h;
  }
  R12.boardView = boardView;
  V.titles.board12 = 'Board';
  V.board12 = p => boardView(p.k);
  ACT.bd12mode = p => { const b = brdOf(p.k); if (b) b.mode = p.v; save(); render(); };
  ACT.bd12freq = p => { const b = brdOf(p.k); if (b) b.freq = +p.v; save(); render(); };
  ACT.bd12rm = p => { const b = brdOf(p.k), n = S.npcs[p.id]; if (n) n.hired = 0; if (b) b.seats = b.seats.filter(x => x.id !== p.id); save(); render(); };
  ACT.bd12find = p => {
    const b = brdOf(p.k), cost = KC(10000);
    if (!b) return;
    if (S.cash < cost) { U.res('cash'); return; }
    payMe(cost, 'Search for a board advisor');
    b.cands = [0, 1, 2].map(() => {
      const n = genManager(null, 'gen');
      n.adv = p.t;
      n.advBg = pick(['former director', 'ex-banker', 'sits on two other boards', 'built and sold a company', 'twenty years in the trade', 'former partner at a big firm']);
      n.fee11 = r500(KC(6000 + ((n.stats || {})[ADV12[p.t][1]] || 55) * 180));
      S.npcs[n.id] = n;
      return n.id;
    });
    save();
    render();
  };
  ACT.bd12inv = p => {
    const n = S.npcs[p.n], b = brdOf(p.k);
    if (!n || n.hired || !b) return;
    if (!(p.f >= n.fee11 || (p.f >= n.fee11 * 0.9 && chance(0.5)))) { toast(first(n.name) + ' says no at that fee.', true); b.cands = b.cands.filter(x => x !== n.id); save(); render(); return; }
    n.hired = -4;
    addSeat(p.k, { id: n.id, kind: 'adv', t: ADV12[n.adv][0], fee: p.f, type: n.adv });
    b.cands = [];
    toast(n.name + ' joins the board of ' + brdName(p.k) + '.');
    save();
    render();
  };
  /* ---------- your left hand ---------- */
  V.titles.boards12 = 'Boards';
  V.boards12 = function () {
    migrate();
    const lh = lhN();
    let h = '';
    if (lh) {
      const L = LH();
      h += '<div class="card"><div class="cchd">' + faceAv(lh) + '<span class="ctext"><b>' + esc(lh.name) + '</b><small>Your left hand · ' + skillBand(Math.round(qOf(lh) * 100)) + ' · ' + mshort(L.fee) + '/mo</small></span></div>' +
        '<span class="tipt">Sits on every board, briefs you before every vote and every emergency, and speaks for you when you do not answer in time.</span>' +
        '<div class="bhead gap"><b>When you do not answer</b></div>' + seg12([[1, 'Decides for you'], [0, 'Waits for you']], L.auto ? 1 : 0, 'lh12set', { k: 'auto' }) +
        '<div class="bhead gap"><b>Briefing</b></div>' + seg12([['week', 'Every week'], ['month', 'Every month'], ['off', 'Off']], L.brief || 'month', 'lh12set', { k: 'brief' }) + btn('Let go', 'lh12fire', {}, 'ghost wide') + '</div>';
    } else {
      const C = (S.lhc || []).map(id => S.npcs[id]).filter(n => n && !n.hired);
      h += '<div class="card dec1"><b>Your left hand</b><span class="tipt">One personal advisor who sits on every board you have, briefs you before votes and emergencies, and decides for you when you are busy. Paid from your own account.</span>' + btn('Find candidates · ' + mshort(KC(15000)), 'lh12find', {}, 'primary wide') + '</div>';
      h += C.map(n => '<div class="card"><div class="cchd">' + faceAv(n) + '<span class="ctext"><b>' + esc(n.name) + '</b><small>' + n.age + ' · ' + esc(n.advBg || '') + ' · ' + skillBand(Math.round(qOf(n) * 100)) + '</small></span></div><div class="chips">' + [0.9, 1, 1.15].map(f => btn(mshort(r500(n.fee11 * f)) + '/mo', 'lh12hire', { n: n.id, f: r500(n.fee11 * f) }, 'chip' + (f === 1 ? ' primary' : ''))).join('') + '</div></div>').join('');
    }
    const keys = [];
    CHS().forEach(ch => { if (storesOf(ch).length) keys.push('ch:' + ch.id); });
    liveCos().filter(c => c.st !== 'setup' && c.type !== 'hold' && !c.chain).forEach(c => keys.push('co:' + c.id));
    h += '<h2 class="sec">Boards</h2><div class="lrows">' + keys.map(k => { const b = brdOf(k); const L = seatsOf(k); const emg = (b.mts || []).filter(m => m.emg && !m.st).length; return '<button class="lrow" data-a="go" data-p="' + P12({ n: 'board12', p: { k } }) + '"><span class="av">' + esc(ini(brdName(k))) + '</span><span class="ctext"><b>' + esc(brdName(k)) + '</b><small>' + (k[0] === 'c' && k[1] === 'h' ? 'Chain · ' : '') + (L.length + 1 + (lh ? 1 : 0)) + ' at the table · ' + (b.mode === 'regular' ? 'regular meetings' : 'only when needed') + '</small></span>' + (emg ? '<span class="pill red">Emergency</span>' : '') + '<i>›</i></button>'; }).join('') + '</div>';
    return h;
  };
  ACT.lh12find = () => {
    const cost = KC(15000);
    if (S.cash < cost) { U.res('cash'); return; }
    payMe(cost, 'Search for a personal advisor');
    S.lhc = [0, 1, 2].map(() => { const n = genManager(null, 'gen'); n.advBg = pick(['former CEO', 'ran a family office', 'ex-investment banker', 'built three companies', 'long-time board member']); n.fee11 = r500(KC(15000 + qOf(n) * 30000)); S.npcs[n.id] = n; return n.id; });
    save();
    render();
  };
  ACT.lh12hire = p => {
    const n = S.npcs[p.n];
    if (!n || n.hired) return;
    if (!(p.f >= n.fee11 || (p.f >= n.fee11 * 0.9 && chance(0.5)))) { toast(first(n.name) + ' says no at that fee.', true); S.lhc = (S.lhc || []).filter(x => x !== n.id); save(); render(); return; }
    n.hired = -5;
    S.lh = { id: n.id, fee: p.f, w0: S.week, auto: 1, brief: 'month' };
    S.lhc = [];
    toast(n.name + ' is your left hand.');
    save();
    render();
  };
  ACT.lh12set = p => { const L = LH(); if (!L) return; if (p.k === 'auto') L.auto = +p.v; else L.brief = p.v; save(); render(); };
  ACT.lh12fire = () => confirmThen('Let your left hand go?', 'They leave every board.', 'Let go', () => { const n = lhN(); if (n) n.hired = 0; S.lh = null; save(); render(); });
  window.R12boardsCard = function () {
    const lh = lhN();
    const nE = (S.cos || []).reduce((t, c) => t + ((c.brd && c.brd.mts) || []).filter(m => m.emg && !m.st).length, 0) + CHS().reduce((t, ch) => t + ((ch.brd && ch.brd.mts) || []).filter(m => m.emg && !m.st).length, 0);
    return '<button class="card opt2" data-a="go" data-p="' + P12({ n: 'boards12', p: {} }) + '"><div class="bhead"><b>Boards</b>' + (nE ? '<span class="pill red">' + nE + ' emergency</span>' : '<span class="pill blue">One per company ›</span>') + '</div><span class="tipt">' + (lh ? 'Your left hand: ' + esc(lh.name) : 'Hire your left hand, a personal advisor on every board') + '</span></button>';
  };
  V.board11 = function () { return V.boards12(); };
  /* the company's More tab gets its board; a chain store shows its chain */
  const more0 = window.CT.more;
  window.CT.more = function (co, bd) {
    let h = more0.apply(this, arguments);
    if (co.st === 'setup' || co.type === 'hold') return h;
    const key = brdKeyOf(co), b = brdOf(key), emg = (b.mts || []).filter(m => m.emg && !m.st).length;
    return h + '<h2 class="sec">Board</h2><div class="lrows"><button class="lrow" data-a="go" data-p="' + P12({ n: 'board12', p: { k: key } }) + '"><span class="lic">' + svg('people', 20) + '</span><span class="ctext"><b>' + (co.chain ? 'Board of ' + esc(brdName(key)) : 'Board') + '</b><small>' + (b.mode === 'regular' ? 'Regular meetings' : 'Only when needed') + ' · ' + (seatsOf(key).length + 1 + (lhN() ? 1 : 0)) + ' at the table</small></span>' + (emg ? '<span class="pill red">Emergency</span>' : '<i>›</i>') + '</button></div>';
  };
  const co12 = V.co;
  V.co = function (p) {
    const h = co12.apply(this, arguments);
    const co = p && getCo(p.id), ch = chainOf(co);
    if (!ch || (p.t && p.t !== 'ov')) return h;
    const i = h.indexOf('<div class="card ovhero"');
    const ban = '<button class="card opt2 chban" data-a="go" data-p="' + P12({ n: 'chain12', p: { id: ch.id, t: 'store', s: co.id } }) + '"><div class="bhead"><b>Store in ' + esc(ch.name) + '</b><span class="pill blue">' + storesOf(ch).length + ' stores ›</span></div></button>';
    return i >= 0 ? h.slice(0, i) + ban + h.slice(i) : h;
  };

  /* ---------- meetings: numbers, advice, your decisions ---------- */
  function voters(key) {
    if (R12.votersX) return R12.votersX(key);
    const L = seatsOf(key).map(x => ({ id: x.id, n: S.npcs[x.id], t: x.t, type: x.kind === 'adv' ? x.type : 'exec', seat: x }));
    const lh = lhN();
    if (lh) L.unshift({ id: lh.id, n: lh, t: 'Your left hand', type: 'lh', lh: 1 });
    return L;
  }
  function recs(v, cos) {
    if (R12.recsX && !R12._inRecs) { R12._inRecs = 1; try { return R12.recsX(v, cos); } finally { R12._inRecs = 0; } }
    const out = [], H3 = c => (c.hist || []).slice(-3), typ = v.type;
    if (typ === 'fin' || typ === 'lh' || typ === 'exec') {
      const bad = cos.find(c => H3(c).length === 3 && H3(c).every(x => x.profit < 0));
      if (bad) out.push({ text: bad.name + ' lost money three months in a row (' + H3(bad).map(x => kf(x.profit)).join(', ') + '). Put it up for sale?', act: 'go', p: { n: 'sale', p: { id: bad.id } } });
    }
    if (typ === 'ind' || typ === 'exec' || typ === 'lh') {
      const low = cos.filter(c => H3(c).length && (c.price || 0) < 3 && H3(c)[H3(c).length - 1].rev > 0).map(c => { const h = H3(c)[H3(c).length - 1]; return { c, m: h.profit / h.rev }; }).filter(x => x.m > -0.15 && x.m < (BD[x.c.type].m || 0.08) - 0.03).sort((a, b) => a.m - b.m)[0];
      if (low) out.push({ text: 'Margin at ' + low.c.name + ' is ' + Math.round(low.m * 100) + '%, the trade normally makes about ' + Math.round((BD[low.c.type].m || 0.08) * 100) + '%. Raise prices one step.', act: 'price', p: { id: low.c.id } });
    }
    if (typ === 'mkt' || typ === 'chair') {
      const quiet = cos.filter(c => (c.aware || 0) < 35).sort((a, b) => a.aware - b.aware)[0];
      if (quiet) out.push({ text: 'Only ' + Math.round(quiet.aware) + '% of the area knows ' + quiet.name + '. Spend more on marketing.', act: 'go', p: { n: 'co', p: { id: quiet.id, t: 'mk' } } });
    }
    if (typ === 'law') {
      const miss = cos.find(c => (BD[c.type].docs || []).some(d => !docOk(c, d)));
      if (miss) out.push({ text: miss.name + ' is missing paperwork it needs. Fix it before an inspection finds it.', act: 'go', p: { n: 'co', p: { id: miss.id } } });
    }
    if (typ === 'exec' || typ === 'chair' || typ === 'lh') {
      const nom = cos.find(c => !c.mgr && c.staff.length >= 3);
      if (nom) out.push({ text: nom.name + ' has ' + nom.staff.length + ' staff and no manager. Hire one.', act: 'go', p: { n: 'mgrhire', p: { id: nom.id } } });
    }
    if (typ === 'lh' || typ === 'fin') {
      const so = cos.find(c => c.dlast && c.dlast.so >= 2);
      if (so) out.push({ text: so.name + ' sold out ' + so.dlast.so + ' days last week, about ' + so.dlast.lost + ' sales lost. Order more.', act: 'stock', p: { id: so.id } });
    }
    return out.slice(0, 2).map(x => Object.assign({ who: v.id, st: null }, x));
  }
  function exceptions(cos) {
    const ex = [];
    cos.forEach(c => {
      if (c.dlast && c.dlast.ot) ex.push([c.name + ': overtime', c.dlast.ot + ' ' + unitPl(BD[c.type].unit, c.dlast.ot) + ' above normal hours', 'Watch', 'amb']);
      if (c.staff.some(s => s.notice > 0)) ex.push([c.name + ': someone is leaving', c.staff.filter(s => s.notice > 0).length + ' on notice', 'Watch', 'red']);
      if (c.staff.some(s => s.flag)) ex.push([c.name + ': problem worker', 'Needs a talk', 'Watch', 'red']);
      const r = ratingOf(c);
      if (c.rt12 != null && r - c.rt12 >= 0.2) ex.push([c.name + ': better reviews', 'Rating ' + c.rt12.toFixed(1) + ' → ' + r.toFixed(1), 'Good', 'green']);
      if (c.mgr && (c.mood || 60) < 40) ex.push([c.name + ': low morale', Math.round(c.mood) + ' / 100', 'Watch', 'amb']);
    });
    return ex.slice(0, 6);
  }
  function meetNums(cos) {
    return cos.map(c => { const a = monthOf(c), b = monthOf(c, 1); return { id: c.id, name: c.name, rev: a.rev || 0, prof: a.profit || 0, prev: b.profit || 0, m: a.rev ? (a.profit || 0) / a.rev : null, cash: Math.round(c.cash) }; });
  }
  function holdMeeting(key, why) {
    const cos = brdCos(key);
    if (!cos.length) return null;
    const V2 = voters(key);
    const items = [];
    V2.forEach(v => recs(v, cos).forEach(r => { if (!items.some(y => y.text === r.text)) items.push(r); }));
    if (R12.extraX) try { R12.extraX(key, cos, items); } catch (e) { console.error(e); }
    const m = { id: uid(), w: S.week, rows: meetNums(cos), items, ex: exceptions(cos), why: why || '' };
    const lh = lhN();
    if (lh) m.lh = items.length ? 'Start with this: ' + items[0].text.split('. ')[0].replace(/\.$/, '') + '. ' + (items.length > 1 ? 'The rest can wait a week.' : '') : 'Nothing urgent. Keep an eye on cash and the next tax bill.';
    const b = brdOf(key);
    b.mts = [m].concat(b.mts || []).slice(0, 8);
    b.last = S.week;
    const rev = sum(m.rows, x => x.rev), pr = sum(m.rows, x => x.prof);
    addMsg({ kind: 'info', from: 'Board of ' + brdName(key), title: 'Board meeting · ' + brdName(key), body: 'Revenue last month ' + money(rev) + ', profit ' + plus(pr) + '. ' + items.filter(x => x.act).length + ' points for you.', co: cos[0].id, tone: 'n', status: 'done', go: { l: 'Open the meeting', a: 'go', p: { n: 'bmeet12', p: { k: key, id: m.id } } } });
    return m;
  }
  ACT.bd12meet = p => {
    const b = brdOf(p.k);
    if (!b) return;
    if (S.week - (b.last || -99) < 2) { toast('This board met less than two weeks ago.', true); return; }
    const m = holdMeeting(p.k);
    if (m) { save(); go('bmeet12', { k: p.k, id: m.id }); }
  };
  V.titles.bmeet12 = 'Board meeting';
  V.bmeet12 = function (p) {
    const b = brdOf(p.k), m = b && (b.mts || []).find(x => x.id === p.id);
    if (!m) return '<div class="calm">This meeting is gone.</div>';
    if (m.emg) return emgView(p.k, m);
    const rev = sum(m.rows, x => x.rev), pr = sum(m.rows, x => x.prof), prev = sum(m.rows, x => x.prev);
    let h = '<div class="card ovhero"><span class="lab">' + esc(brdName(p.k)) + ' · ' + esc(dateStr(m.w)) + '</span><b class="huge ' + sgn(pr) + '">' + plus(pr) + '</b><span class="pills"><span class="pl">Profit last month</span>' + (prev ? '<span class="pl ' + (pr >= prev ? 'g' : 'r') + '">' + (pr >= prev ? '▲ ' : '▼ ') + kf(Math.abs(pr - prev)) + ' vs month before</span>' : '') + '</span></div>';
    h += '<div class="tri"><div><span>Revenue</span><b>' + kf(rev) + '</b></div><div><span>Profit</span><b class="' + sgn(pr) + '">' + kf(pr) + '</b></div><div><span>Cash</span><b>' + kf(sum(m.rows, x => x.cash)) + '</b></div></div>';
    if (m.lh && lhN()) h += '<div class="card"><div class="cchd">' + faceAv(lhN()) + '<span class="ctext"><b>' + esc(lhN().name) + '</b><small>Your left hand, to you only</small></span></div><p>' + esc(m.lh) + '</p></div>';
    const open = m.items.filter(x => x.act);
    h += '<h2 class="sec">Needs your decision (' + open.filter(x => !x.st).length + ')</h2>' + (open.length ? open.map((x, j) => {
      const i = m.items.indexOf(x), n = S.npcs[x.who];
      const st = x.st === 'yes' ? '<span class="pill green">Done</span>' : x.st === 'no' ? '<span class="pill">Not now</span>' : '<div class="two">' + btn('Approve', 'bd12yes', { k: p.k, m: m.id, i }, 'primary') + btn('Reject', 'bd12no', { k: p.k, m: m.id, i }, 'ghost') + '</div>';
      return '<div class="card' + (j === 0 && !x.st ? ' dec1' : '') + '"><b>' + esc(x.text) + '</b><span class="tipt">' + esc(n ? n.name : 'The board') + ' recommends.</span>' + (R12.invText ? R12.invText(x, p.k) : '') + st + '</div>';
    }).join('') : '<div class="calm">Nothing to decide.</div>');
    if (m.ex && m.ex.length) h += '<h2 class="sec">Exceptions</h2><div class="card lrows">' + m.ex.map(e => '<div class="lrow"><span class="ctext"><b>' + esc(e[0]) + '</b><small>' + esc(e[1]) + '</small></span><span class="pill ' + e[3] + '">' + e[2] + '</span></div>').join('') + '</div>';
    if (m.rows.length > 1) h += '<h2 class="sec">Per store, last month</h2><div class="card tbl11"><div class="t11 hd"><span>Store</span><span>Revenue</span><span>Profit</span><span>Margin</span></div>' + m.rows.map(r => '<div class="t11"><span>' + esc(r.name) + '</span><span>' + kf(r.rev) + '</span><span class="' + (r.prof >= 0 ? 'pos' : 'neg') + '">' + kf(r.prof) + '</span><span>' + (r.m == null ? '–' : Math.round(r.m * 100) + '%') + '</span></div>').join('') + '</div>';
    return h;
  };
  function seatFor(key, id) { return seatsOf(key).find(x => x.id === id); }
  ACT.bd12yes = p => {
    const b = brdOf(p.k), m = b && b.mts.find(x => x.id === p.m), it = m && m.items[p.i];
    if (!it || it.st) return;
    it.st = 'yes';
    const s = seatFor(p.k, it.who);
    if (s) { s.ok++; s.mood = Math.min(100, s.mood + 4); }
    save();
    const co = it.p && getCo(it.p.id);
    if (it.act === 'price' && co) {
      const ch = chainOf(co);
      if (ch) { co.off = co.off || {}; co.off.price = Math.min(1, (co.off.price || 0) + 1); applyRules(ch, co); } else co.price = Math.min(3, (co.price || 0) + 1);
      toast('Prices at ' + co.name + ' up one step.');
      render();
    } else if (it.act === 'stock' && co) {
      const ch = chainOf(co);
      if (ch) { co.off = co.off || {}; co.off.stock = 2; applyRules(ch, co); } else co.stockPol = 2;
      toast(co.name + ' now orders plenty.');
      render();
    } else if (it.act === 'go') go(it.p.n, it.p.p);
    else render();
  };
  ACT.bd12no = p => {
    const b = brdOf(p.k), m = b && b.mts.find(x => x.id === p.m), it = m && m.items[p.i];
    if (!it || it.st) return;
    it.st = 'no';
    const s = seatFor(p.k, it.who);
    if (s) {
      s.no++;
      s.mood = Math.max(0, s.mood - 6);
      const n = S.npcs[s.id];
      if (s.kind === 'adv' && s.mood < 25 && n) { n.hired = 0; b.seats = b.seats.filter(x => x !== s); info(n.name, 'Leaving the board', 'You rarely take my advice, so I am stepping down from the board of ' + brdName(p.k) + '.', null, 'bad'); }
    }
    save();
    render();
  };

  /* ================= D. emergency meetings ================= */
  const EMG = {
    drop: { t: 'Revenue fell sharply', opts: [['Cut prices one step', 'price-'], ['Marketing push, +50%', 'mkt+'], ['Wait and watch', 'wait']] },
    cash: { t: 'Cash is running out', opts: [['Move money in from you', 'cashin'], ['Stop all marketing', 'mkt0'], ['Wait and watch', 'wait']] },
    mgr: { t: 'The manager has left', opts: [['Find a new manager now', 'hire'], ['Run it yourself, 20 h', 'self'], ['Wait and watch', 'wait']] },
    loss: { t: 'Three months of losses', opts: [['Put it up for sale', 'sell'], ['Cut costs: stop marketing', 'mkt0'], ['Give it three more months', 'wait']] },
    stock: { t: 'Selling out again and again', opts: [['Order plenty from now on', 'stock'], ['Give stock to the assistant', 'asst'], ['Wait and watch', 'wait']] },
    rating: { t: 'Reviews are falling fast', opts: [['Train the staff', 'course'], ['Raise pay 5%', 'raise'], ['Wait and watch', 'wait']] }
  };
  function lhPick(kind, co) {
    const n = lhN(), o = EMG[kind].opts;
    let best = 0;
    if (kind === 'drop') best = co.aware < 40 ? 1 : 0;
    if (kind === 'cash') best = S.cash > Math.abs(co.wkD || 0) * 8 ? 0 : 1;
    if (kind === 'mgr') best = co.staff.length >= 3 ? 0 : 1;
    if (kind === 'loss') best = (co.hist || []).slice(-6).filter(x => x.profit < 0).length >= 5 ? 0 : 1;
    if (kind === 'stock') best = co.asst ? 1 : 0;
    if (kind === 'rating') best = co.staff.some(s => s.notice > 0) ? 1 : 0;
    if (n && Z() > 0.5 + qOf(n) * 0.5) best = (best + 1) % (o.length - 1);
    return best;
  }
  function memberVotes(key, kind, co) {
    return voters(key).map(v => {
      let pick2 = v.lh ? lhPick(kind, co) : v.type === 'fin' ? (kind === 'loss' ? 0 : kind === 'cash' ? 1 : 2) : v.type === 'mkt' ? (kind === 'drop' ? 1 : 2) : v.type === 'exec' ? 0 : 0;
      if (Z() < 0.15) pick2 = Math.floor(Z() * EMG[kind].opts.length);
      return { id: v.id, name: v.n.name, t: v.t, pick: pick2, lh: !!v.lh };
    });
  }
  function emergency(co, kind, why) {
    co.emg12 = co.emg12 || {};
    if (co.emg12[kind] && S.week - co.emg12[kind] < 6) return;
    const key = brdKeyOf(co), b = brdOf(key);
    const E = EMG[kind];
    /* round 38: no board, no board meeting. You see your own company's trouble directly;
       a manager without a board asks you in a normal message. */
    if (R12.active && !R12.active(key)) {
      const mg = co.mgr && S.npcs[co.mgr];
      if (!mg && kind !== 'mgr') return;
      co.emg12[kind] = S.week;
      addMsg({ kind: 'ask', from: mg ? mg.name + ', ' + titleFor(co, 'mgr').toLowerCase() : co.name, title: E.t + ' at ' + co.name, body: why + (mg ? '\nWhat do you want me to do?' : ''), co: co.id, opts: E.opts.map(o => ({ l: o[0], d: '', fx: {} })), act: 'emg37', data: { kind }, exp: S.week + 2, tone: 'bad' });
      return;
    }
    co.emg12[kind] = S.week;
    const votes = memberVotes(key, kind, co);
    const lh = votes.find(v => v.lh);
    const m = { id: uid(), w: S.week, emg: 1, kind, co: co.id, title: E.t + ' · ' + co.name, why, votes, opts: E.opts.map(o => o[0]), lhPick: lh ? lh.pick : null, st: null };
    b.mts = [m].concat(b.mts || []).slice(0, 8);
    const tally = E.opts.map((o, i) => votes.filter(v => v.pick === i).length);
    addMsg({ kind: 'ask', from: R12.active && !R12.active(key) ? 'Urgent decision' : 'Emergency board meeting', title: E.t + ' at ' + co.name, body: why + (lh ? '\n' + lhN().name + ' (your left hand): ' + E.opts[lh.pick][0] + '.' : '') + (votes.length ? '\nBoard: ' + E.opts.map((o, i) => o[0] + ' ' + tally[i]).join(' · ') : ''), co: co.id, opts: E.opts.map(o => ({ l: o[0], d: '', fx: {} })), act: 'emg12', data: { k: key, id: m.id }, exp: S.week + 2, tone: 'bad' });
  }
  R12.emergency = emergency;
  ACTS.emg37 = (m, idx) => { const co = getCo(m.co), E = EMG[m.data && m.data.kind]; if (co && E && E.opts[idx]) doEmg(co, E.opts[idx][1]); return true; };
  function doEmg(co, code) {
    const ch = chainOf(co);
    if (code === 'price-') { if (ch) { co.off = co.off || {}; co.off.price = Math.max(-1, (co.off.price || 0) - 1); applyRules(ch, co); } else co.price = Math.max(-3, (co.price || 0) - 1); }
    else if (code === 'mkt+') Object.keys(co.mkt || {}).forEach(k => { co.mkt[k].b = Math.round(co.mkt[k].b * 1.5); });
    else if (code === 'mkt0') co.mkt = {};
    else if (code === 'cashin') { const x = Math.round(Math.max(KC(20000), Math.abs(co.wkD || 0) * 6) / 1000) * 1000; if (S.cash >= x) { moveCash(ME, -x); moveCash(co, x); logTx(0, -x, 'Into ' + co.name); } }
    else if (code === 'hire') setTimeout(() => go('mgrhire', { id: co.id }), 0);
    else if (code === 'self') co.ohrs = Math.max(co.ohrs || 0, 20);
    else if (code === 'sell') { S.sales = S.sales || []; if (!S.sales.some(x => x.co === co.id)) S.sales.push({ id: uid(), co: co.id, pct: 100, m: 'broker', w0: S.week, offers: [] }); }
    else if (code === 'stock') { if (ch) { co.off = co.off || {}; co.off.stock = 2; applyRules(ch, co); } else co.stockPol = 2; }
    else if (code === 'asst') { if (co.asst) { co.asst.duties = co.asst.duties || []; if (co.asst.duties.indexOf('equip') < 0) co.asst.duties = co.asst.duties.slice(-1).concat('equip'); } else setTimeout(() => go('co', { id: co.id, t: 'st' }), 0); }
    else if (code === 'course') { payCo(co, KC(4000) * Math.max(1, co.staff.length), 'oth', 'Staff training'); co.q = Math.min(100, (co.q || 50) + 4); }
    else if (code === 'raise') co.staff.forEach(s => { s.wage = Math.round(s.wage * 1.05 / 100) * 100; s.happy = S.week + 26; });
  }
  ACTS.emg12 = (m, idx) => {
    const b = brdOf(m.data.k), mt = b && (b.mts || []).find(x => x.id === m.data.id);
    const co = getCo(m.co);
    if (!mt || !co || mt.st) return true;
    mt.st = 'you';
    mt.pickI = idx;
    doEmg(co, EMG[mt.kind].opts[idx][1]);
    voters(m.data.k).forEach(v => { const vv = mt.votes.find(x => x.id === v.id); const s = v.seat; if (s && vv) { if (vv.pick === idx) s.ok++; else { s.no++; s.mood = Math.max(0, s.mood - 4); } } });
    return true;
  };
  ACT.emg12pick = p => {
    const msg = S.inbox.find(x => x.act === 'emg12' && x.data && x.data.id === p.id) || (S.pend && S.pend.msgs.map(x => x.m).find(x => x.act === 'emg12' && x.data && x.data.id === p.id));
    const b = brdOf(p.k), mt = b && (b.mts || []).find(x => x.id === p.id);
    if (!mt || mt.st) return;
    if (msg) { ACTS.emg12(msg, p.i); msg.status = 'done'; msg.pick = p.i; msg.read = 1; }
    else { const co = getCo(mt.co); if (co) { mt.st = 'you'; mt.pickI = p.i; doEmg(co, EMG[mt.kind].opts[p.i][1]); } }
    save();
    render();
  };
  function emgView(key, m) {
    const co = getCo(m.co);
    let h = '<div class="card emgc"><div class="bhead"><b>' + esc(m.title) + '</b><span class="pill red">' + (m.st ? 'Decided' : 'Open') + '</span></div><span class="tipt">' + esc(m.why) + '</span></div>';
    if (co && co.rw12 && co.rw12.length > 2) h += '<div class="card"><h3>Revenue, last weeks</h3><div style="display:flex;justify-content:center">' + spark12(co.rw12) + '</div></div>';
    h += '<h2 class="sec">What the board says</h2><div class="card lrows">' + (m.votes.length ? m.votes.map(v => '<div class="lrow">' + faceAv(S.npcs[v.id]) + '<span class="ctext"><b>' + esc(v.name) + '</b><small>' + esc(v.lh ? 'Your left hand' : v.t) + '</small></span><span class="pill' + (v.lh ? ' blue' : '') + '">' + esc(m.opts[v.pick]) + '</span></div>').join('') : '<div class="lrow"><span class="ctext"><small>No one else on this board yet.</small></span></div>') + '</div>';
    if (m.st && m.st !== 'late') h += '<div class="card">' + row('Decided by', m.st === 'lh' ? 'Your left hand' : 'You') + row('Choice', esc(m.opts[m.pickI] || '—')) + '</div>';
    else if (m.st === 'late') h += '<div class="calm">No one answered in time.</div>';
    else h += '<h2 class="sec">Your decision</h2><div class="card"><div class="chips">' + m.opts.map((o, i) => btn(o, 'emg12pick', { k: key, id: m.id, i }, 'chip' + (i === m.lhPick ? ' primary' : ''))).join('') + '</div>' + (m.lhPick != null ? '<span class="tipt">Highlighted: what your left hand would do.</span>' : '') + '</div>';
    return h;
  }
  function spark12(L) {
    const w = 300, hgt = 60, mx = Math.max.apply(null, L.concat([1])), n = L.length;
    const pts = L.map((v, i) => Math.round(i / Math.max(1, n - 1) * w) + ',' + Math.round(hgt - v / mx * (hgt - 6) - 3)).join(' ');
    return '<svg width="' + w + '" height="' + hgt + '" viewBox="0 0 ' + w + ' ' + hgt + '"><polyline fill="none" stroke="var(--amber)" stroke-width="2.5" points="' + pts + '"/></svg>';
  }
  function emgWeek() {
    liveCos().forEach(co => {
      if (co.st !== 'open' || co.type === 'hold' || !co.lastW) return;
      co.rw12 = (co.rw12 || []).concat(Math.round(co.lastW.rev || 0)).slice(-10);
      const R = co.rw12;
      const age = S.week - (co.wOpen != null ? co.wOpen : co.w0 || 0);
      if (R.length >= 6 && age >= 8) {
        const avg = sum(R.slice(-6, -2), x => x) / 4, last2 = R.slice(-2);
        if (avg > KC(2000) && last2.every(x => x < avg * 0.75)) emergency(co, 'drop', 'Revenue the last two weeks: ' + money(last2[0]) + ' and ' + money(last2[1]) + ', against about ' + money(Math.round(avg)) + ' a week before.');
      }
      if ((co.wkD || 0) < 0 && co.cash > 0 && co.cash / -co.wkD < 4) emergency(co, 'cash', 'Cash ' + money(Math.round(co.cash)) + ', and the company burns about ' + money(Math.round(-co.wkD)) + ' a week. That is under four weeks left.');
      if (co.mgr12 && !co.mgr && co.staff.length) emergency(co, 'mgr', (S.npcs[co.mgr12] ? S.npcs[co.mgr12].name : 'The manager') + ' is gone. ' + co.staff.length + ' staff have no one in charge.');
      co.mgr12 = co.mgr || null;
      if (isMonthEnd(S.week)) {
        const H = (co.hist || []).slice(-3);
        if (age >= 26 && H.length === 3 && H.every(x => x.profit < 0)) emergency(co, 'loss', 'Losses: ' + H.map(x => money(Math.round(x.profit))).join(', ') + '.');
      }
      co.so12 = co.dlast && co.dlast.so >= 3 ? (co.so12 || 0) + 1 : 0;
      if (co.so12 >= 2) emergency(co, 'stock', 'Sold out ' + co.dlast.so + ' days last week, about ' + co.dlast.lost + ' sales lost.');
      const r = ratingOf(co);
      co.rth12 = (co.rth12 || []).concat(r).slice(-5);
      if (co.rth12.length >= 5 && co.rth12[0] - r >= 0.4 && (co.rvN || 0) >= 20) emergency(co, 'rating', 'The rating fell from ' + co.rth12[0].toFixed(1) + ' to ' + r.toFixed(1) + ' in a month.');
      if (S.week % 4 === 0) co.rt12 = r;
    });
    /* emergencies nobody answered are marked as such */
    const allB = CHS().map(ch => ch.brd).concat(S.cos.map(c => c.brd)).filter(Boolean);
    allB.forEach(b => (b.mts || []).forEach(m => { if (m.emg && !m.st && S.week - m.w >= 3) m.st = 'late'; }));
    /* your left hand answers what you left waiting */
    const L = LH();
    if (L && L.auto) S.inbox.forEach(m => {
      if (m.status !== 'open' || m.act !== 'emg12' || S.week < m.w + 1) return;
      const b = brdOf(m.data.k), mt = b && (b.mts || []).find(x => x.id === m.data.id);
      if (!mt || mt.st || mt.lhPick == null) return;
      ACTS.emg12(m, mt.lhPick);
      mt.st = 'lh';
      m.status = 'done';
      m.pick = mt.lhPick;
      note(lhN().name + ' decided for you at ' + (getCo(m.co) || {}).name + ': ' + mt.opts[mt.lhPick] + '.', 'n', m.co);
    });
  }
  /* regular meetings, fees, briefings */
  function boardsWeek() {
    if (!isMonthEnd(S.week)) return;
    const mi = monthIdx(S.week) % 12;
    const keys = CHS().filter(ch => storesOf(ch).length).map(ch => 'ch:' + ch.id).concat(liveCos().filter(c => c.st === 'open' && c.type !== 'hold' && !c.chain).map(c => 'co:' + c.id));
    keys.forEach(k => {
      const b = brdOf(k), cos = brdCos(k);
      if (!b || !cos.length) return;
      const fee = sum(seatsOf(k), x => x.fee || 0);
      if (fee) cos.forEach(c => payCo(c, fee / cos.length, 'oth', null));
      if ((!R12.active || R12.active(k)) && b.mode === 'regular' && (b.freq !== 13 || mi % 3 === 2) && S.week - (b.last || -99) >= 2 && (seatsOf(k).length || lhN())) holdMeeting(k);
    });
    const L = LH();
    if (L) payMe(L.fee, 'Left hand: ' + lhN().name);
  }
  function briefing() {
    const L = LH();
    if (!L || L.brief === 'off') return;
    if (L.brief === 'month' && !isMonthEnd(S.week)) return;
    const open = S.inbox.filter(m => m.status === 'open').length;
    const losers = liveCos().filter(c => c.st === 'open' && c.lastW && (c.wkD || 0) < 0).slice(0, 3).map(c => c.name);
    const so = liveCos().filter(c => c.dlast && c.dlast.so).map(c => c.name).slice(0, 2);
    const lines = [open ? open + (open > 1 ? ' things wait for you.' : ' thing waits for you.') : 'Nothing waits for you.', losers.length ? 'Losing money last week: ' + losers.join(', ') + '.' : 'Every company made money last week.', so.length ? 'Sold out: ' + so.join(', ') + '.' : '', 'Your cash: ' + money(Math.round(S.cash)) + '.'].filter(Boolean);
    addMsg({ kind: 'info', from: lhN().name, role: 'Your left hand', title: (L.brief === 'week' ? 'Weekly' : 'Monthly') + ' briefing', body: lines.join('\n'), tone: 'n', status: 'done' });
  }
  /* ---------- votes on big moves, per board ---------- */
  function voteOn(kind, co, amt) {
    const key = brdKeyOf(co), V2 = voters(key);
    const H = (co.hist || []).slice(-3), p3 = sum(H, x => x.profit || 0), r3 = sum(H, x => x.rev || 0);
    const yp = Math.max(1, sum((co.hist || []).slice(-12), x => x.profit || 0)), debt = sum(S.loans || [], l => l.co === co.id ? l.bal || 0 : 0);
    const L = V2.map(v => {
      let yes, why;
      if (kind === 'sell') { yes = p3 < 0 || (r3 > 0 && p3 / r3 < 0.02); why = yes ? (p3 < 0 ? 'It lost ' + mshort(-p3) + ' in three months.' : 'It barely makes money.') : 'It made ' + mshort(p3) + ' in three months. Keep it.'; }
      else if (kind === 'close') { yes = p3 < 0; why = yes ? 'Losses of ' + mshort(-p3) + ' in three months.' : 'It is profitable. Sell it rather than close it.'; }
      else { const ratio = (debt + amt) / yp; yes = ratio < 3; why = yes ? 'Debt stays at ' + ratio.toFixed(1) + ' years of profit.' : 'Debt would be ' + (ratio > 50 ? 'far more than' : ratio.toFixed(0) + ' times') + ' a year of profit.'; }
      if (Z() < 0.12 * (1 - qOf(v.n))) { yes = !yes; why = yes ? 'The risk is worth taking.' : 'Too early to decide.'; }
      return { id: v.id, name: v.n.name, t: v.t, lh: !!v.lh, yes, why };
    });
    if (co.own < 100) { const yes = kind === 'loan' ? p3 > 0 : p3 < 0; L.push({ id: null, name: 'Investors', t: Math.round(100 - co.own) + '% of the shares', yes, why: yes ? 'Agreed.' : 'Not with these numbers.' }); }
    return L;
  }
  function voteSheet(kind, co, amt, go2, label) {
    if (R12.voteSheetX) return R12.voteSheetX(kind, co, amt, go2, label);
    const L = voteOn(kind, co, amt);
    if (L.length < 2) return go2();
    const y = L.filter(x => x.yes).length, nn = L.length - y, pass = y > nn, outside = co.own < 50;
    ui.b12cont = () => { closeSheet(); go2(); };
    openSheet('<h2>Board vote: ' + esc(label) + '</h2><p class="muted small">' + y + ' for, ' + nn + ' against.' + (outside && !pass ? ' Outside owners hold ' + Math.round(100 - co.own) + '%, so the no vote stops it.' : '') + '</p><div class="lrows">' + L.map(x => '<div class="lrow">' + (x.id ? faceAv(S.npcs[x.id]) : '<span class="av dim">IN</span>') + '<span class="ctext"><b>' + esc(x.name) + (x.lh ? ' · your left hand' : '') + ' · ' + (x.yes ? 'for' : 'against') + '</b><small>' + esc(x.why) + '</small></span></div>').join('') + '</div>' +
      (outside && !pass ? btn('OK', 'sheetclose', undefined, 'wide') : '<div class="two">' + btn(pass ? 'Go ahead' : 'Go ahead anyway', 'b12go', {}, pass ? 'primary' : 'danger') + btn('Cancel', 'sheetclose', undefined, 'ghost') + '</div>'));
  }
  ACT.b12go = () => { const f = ui.b12cont; ui.b12cont = null; if (f) f(); };
  const sg12 = ACT.salego;
  ACT.salego = p => { const co = getCo(p.id); if (!co || p.bv12) return sg12(p); voteSheet('sell', co, 0, () => sg12(Object.assign({}, p, { bv12: 1 })), 'sell ' + (p.pct === 100 ? co.name : p.pct + '% of ' + co.name)); };
  const wu12 = ACT.winduo;
  ACT.winduo = p => { const co = getCo(p.id); if (!co || p.bv12) return wu12(p); voteSheet('close', co, 0, () => wu12(Object.assign({}, p, { bv12: 1 })), 'close ' + co.name); };
  const lg12 = ACT.loango;
  ACT.loango = p => {
    const co = getCo(p.id), a = Math.round(U.inum('lamt', 0));
    const g = document.getElementById('guar'), gv = g ? g.checked : false;
    if (!co || p.bv12 || a < KC(1000000)) return lg12(p);
    voteSheet('loan', co, a, () => { const el = document.createElement('input'); el.type = 'checkbox'; el.id = 'guar'; el.checked = gv; el.style.display = 'none'; document.body.appendChild(el); try { lg12(Object.assign({}, p, { bv12: 1 })); } finally { el.remove(); } }, 'borrow ' + mshort(a) + ' for ' + co.name);
  };

  Object.assign(R12, { recs0: recs, emergency, chainById, storesOf, chainOf, chiefs, chiefFor, joinChain, storeName, makeChain, applyRules, monthOf, brdOf, brdKeyOf, brdCos, brdName, seatsOf, addSeat, lhN, LH, qOf, offCount, storeTab, rulesTab, teamTab, holdMeeting, seg12, kf, P12, first, r500, voteOn, emgWeekRef: null });
  R7.afterWeek = R7.afterWeek || [];
  R7.afterWeek.push(() => {
    try { migrate(); } catch (e) { console.error(e); }
    try { chainWeek(); } catch (e) { console.error(e); }
    try { emgWeek(); } catch (e) { console.error(e); }
    try { boardsWeek(); } catch (e) { console.error(e); }
    try { briefing(); } catch (e) { console.error(e); }
  });
}

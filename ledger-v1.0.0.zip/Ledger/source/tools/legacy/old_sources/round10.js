/* ===== Round 10: sales happen day by day, in whole units. A home is sold or it is not.
   Each day every open company gets its customers for that day (busier on the days that business is busy),
   serves them as far as its capacity for the day allows, and is paid for each full sale that same day.
   The week-end close books exactly the sales that happened on the days. Commission follows each seller's
   own full sales. Next day takes a short moment, so days cannot be spammed. ===== */
{
  const DIV = { tonne: 1, litre: 1, barrel: 1, MWh: 1, 'm2-week': 1, 'member-week': 1, 'unit-week': 1, 'space-week': 1, kbbl: 1 };
  const FAMS = { svc: 1, retail: 1, venue: 1, logi: 1, prod: 1 };
  /* share of a week's customers on each day, Monday first */
  const SH = {
    shop: [0.12, 0.12, 0.13, 0.14, 0.16, 0.19, 0.14],
    fun: [0.07, 0.08, 0.11, 0.13, 0.21, 0.25, 0.15],
    care: [0.15, 0.16, 0.16, 0.17, 0.17, 0.14, 0.05],
    work: [0.205, 0.205, 0.205, 0.205, 0.18, 0, 0],
    wk6: [0.18, 0.18, 0.18, 0.18, 0.17, 0.11, 0],
    flat: [1 / 7, 1 / 7, 1 / 7, 1 / 7, 1 / 7, 1 / 7, 1 / 7]
  };
  function shapeOf(bd) {
    if (bd.fam === 'venue') return bd.ticket < 150 ? SH.shop : SH.fun;
    if (bd.fam === 'retail') return bd.tw && bd.tw.ecom ? SH.flat : bd.ticket >= 100000 ? SH.care : SH.shop;
    if (bd.fam === 'svc') return bd.id === 'carclean' ? SH.shop : bd.aud >= 0.6 ? SH.work : SH.care;
    if (bd.fam === 'prod') return bd.ticket < 100 && bd.aud < 0.5 ? SH.shop : SH.work;
    if (bd.fam === 'logi') return bd.id === 'taxi' ? SH.fun : bd.id === 'courier' ? SH.wk6 : bd.id === 'airline' ? SH.flat : SH.work;
    return SH.flat;
  }
  /* how many of today's unserved customers come back tomorrow: nobody waits for a coffee, everybody waits for a house */
  function keepOf(bd, sh) {
    const t = bd.ticket || 0;
    let k = t >= 20000 ? 0.99 : t >= 1500 ? 0.95 : t >= 400 ? 0.6 : 0;
    if (sh === SH.work) k = Math.max(k, 0.8);
    return k;
  }
  const divisible = bd => !!DIV[bd.unit];
  function dailyOk(co, bd) {
    return !!(co && bd && co.st === 'open' && FAMS[bd.fam] && bd.id !== 'salmon' && !(bd.tw && bd.tw.sub) && !divisible(bd));
  }
  window.R10 = { dailyOk, shapeOf, SH };
  const wdIdx = (w, d) => (new Date(wDate(w).getTime() + d * 86400000).getUTCDay() + 6) % 7;
  const dayPrice = (co, bd) => ticketEff(co, bd) * (bd.tw && bd.tw.rateIdx ? S.econ.freight : 1);
  function binom(n, p) {
    if (n <= 0 || p <= 0) return 0;
    if (p >= 1) return n;
    if (n > 40) return clamp(Math.round(n * p + gauss() * Math.sqrt(n * p * (1 - p))), 0, n);
    let k = 0;
    for (let i = 0; i < n; i++) if (Z() < p) k++;
    return k;
  }
  /* who made the sales: salespeople by skill, and you if you sell there yourself */
  function sellers(co, bd, wk, d) {
    const list = co.staff.filter(s => SALES_ROLES[s.role] && !(window.R11off && window.R11off(co, s, wk, d))).map(s => [s, staffSkill(s) + 10]);
    const sellsHere = list.length || (bd.std || []).some(x => SALES_ROLES[x[0]]);
    if (!sellsHere) return null;
    if (!co.mgr && (co.ohrs || 0) > 0) list.push([null, Math.min(1, co.ohrs / 40) * ((co.oskill || 40) + 10)]);
    return list.length ? list : null;
  }
  function attribute(co, bd, n, price, wk, d) {
    const L = sellers(co, bd, wk, d);
    if (!L || n <= 0) return;
    const W = sum(L, x => x[1]);
    const got = L.map(() => 0);
    if (n <= 200) {
      for (let i = 0; i < n; i++) {
        let r = Z() * W, j = 0;
        while (j < L.length - 1 && (r -= L[j][1]) > 0) j++;
        got[j]++;
      }
    } else {
      let left = n;
      L.forEach((x, j) => { got[j] = Math.floor(n * x[1] / W); left -= got[j]; });
      for (let j = 0; left > 0; j = (j + 1) % L.length, left--) got[j]++;
    }
    L.forEach((x, j) => {
      if (!got[j]) return;
      const o = x[0] || co;
      const k = x[0] ? 'ws' : 'ows';
      if (!o[k] || o[k].w !== wk) o[k] = { w: wk, u: 0, r: 0 };
      o[k].u += got[j];
      o[k].r += got[j] * price;
    });
  }
  /* one day of trade for one company. D and cap are per week; the day takes its share of both. */
  /* how a trade is limited: goods by what is on the shelf, rooms and seats by how many there are,
     services by staff hours (overtime stretches them by up to a fifth) */
  const ROOMS = { hotel: 1, fun: 1, casino: 1, airline: 1, shipping: 1 }; /* seats and cargo space cannot be sold twice */
  const kindOf = bd => ROOMS[bd.id] ? 'rooms' : bd.fam === 'svc' || bd.fam === 'logi' ? 'service' : 'goods';
  window.R10.kindOf = kindOf;
  function tradeDay(co, bd, L, wk, d, D, cap, Da, stockF, price) {
    const sh = shapeOf(bd), s = sh[wdIdx(wk, d)];
    const keep = keepOf(bd, sh);
    const kind = kindOf(bd);
    if (window.R12DELIV) window.R12DELIV(co, bd, L, wk, d);
    const shelfOn = kind === 'goods' && co.shelf != null && window.R12DELIV;
    const lam = Math.max(0, D * s * Math.max(0, 1 + gauss() * 0.1) * (shelfOn ? 1 : stockF));
    L.q = binom(L.q || 0, keep) + pois(lam);
    L.cap = Math.max(0, cap);
    let room;
    if (L.cap <= 0) room = 0;
    else if (kind === 'goods') room = Infinity;
    else {
      /* overtime only when an extra job still pays after time-and-a-half */
      const wpu = (co.lastWages || 0) / Math.max(1, L.cap);
      const otOk = kind === 'service' && price * (1 - (bd.cogs || 0.3)) > 1.5 * wpu;
      room = Math.max(0, Math.floor(L.cap * (otOk ? 1.2 : 1) + (L.ca || 0) - L.u + 1e-9));
    }
    let sold = Math.max(0, Math.min(L.q, room));
    if (shelfOn) {
      const have = Math.max(0, Math.floor(co.shelf + 1e-9));
      if (sold > have) { L.lost = (L.lost || 0) + sold - have; L.so = (L.so || 0) + 1; sold = have; }
      co.shelf = Math.max(0, co.shelf - sold);
    }
    L.q -= sold;
    const vr = vatRate(co);
    const cash = Math.round(sold * price * (1 + vr) * (1 - (bd.b2b || 0)));
    if (cash) coIn(co, cash, null, null);
    L.days[d] = { u: sold, r: sold * price, wd: wdIdx(wk, d) };
    L.u += sold;
    L.r += sold * price;
    L.paid += cash;
    attribute(co, bd, sold, price, wk, d);
    return sold;
  }
  const newLog = (co, wk) => {
    const o = co.dl || {};
    const carry = o.cap != null ? clamp(o.cap + (o.ca || 0) - (o.u || 0), 0, Math.max(1, o.cap * 0.5)) : (o.ca || 0);
    return (co.dl = { w: wk, days: {}, u: 0, r: 0, paid: 0, q: o.q || 0, ca: carry });
  };
  function stockFactor(co, bd, D, cap) {
    if (!(bd.tw && bd.tw.stock)) return 1;
    const base = Math.min(D, cap);
    if (base <= 0) return 1;
    try { return clamp(stockUnits(co, bd, { D, cap }, base) / base, 0, 1); } catch (e) { return 1; }
  }
  /* the day just started: every open company trades it */
  const big = [];
  window.R10DAY = function (d) {
    S.dmode = 1;
    S.cos.forEach(co => {
      const bd = BD[co.type];
      if (!dailyOk(co, bd)) return;
      try {
        setCtx(co);
        const L = co.dl && co.dl.w === S.week ? co.dl : newLog(co, S.week);
        if (L.days[d]) return;
        const dm = demand(co, bd), cp = capacity(co, bd);
        const c = { D: dm.D, cap: cp.cap };
        acctDemand(co, c);
        const price = dayPrice(co, bd);
        const n = tradeDay(co, bd, L, S.week, d, c.D, c.cap, c.Da || 0, stockFactor(co, bd, c.D, c.cap), price);
        if (n > 0 && bd.ticket >= 20000) big.push([co, n, Math.round(n * price), bd]);
      } catch (e) { console.error(e); } finally { setCtx(null); }
    });
  };
  /* week-end close: the week's books use the full sales that happened on its days */
  window.R10U = function (co, bd, ctx) {
    if (!dailyOk(co, bd)) return false;
    const wk = S.week - 1;
    let L = co.dl && co.dl.w === wk ? co.dl : null;
    if (!L) {
      L = newLog(co, wk);
      /* played week by week (no days were traded): trade all seven days now */
      if (!S.dmode) {
        const price = ctx.price, sf = stockFactor(co, bd, ctx.D, ctx.cap);
        for (let d = 0; d < 7; d++) tradeDay(co, bd, L, wk, d, ctx.D, ctx.cap, ctx.Da || 0, sf, price);
      }
    }
    ctx.units = L.u;
    if (L.u > 0) ctx.price = L.r / L.u;
    ctx.paidD = L.paid;
    /* more work than the staff's normal hours: paid as overtime, and a crowded shop serves worse */
    let ot = 0;
    if (ctx.cap > 0 && L.u > ctx.cap * 1.05) {
      ot = Math.round(L.u - ctx.cap * 1.05);
      if (kindOf(bd) === 'service') {
        const wpu = (co.lastWages || 0) / ctx.cap;
        if (wpu > 0) payCo(co, ot * wpu * 1.5, 'wages', null);
      } else if (L.u > ctx.cap * 1.2) {
        /* a full shop still sells, but queues grow, service slips and staff wear out */
        co.q = Math.max(0, (co.q || 50) - Math.min(6, (L.u / ctx.cap - 1.2) * 12));
        co.staff.forEach(s => { if (Z() < 0.02 * (L.u / ctx.cap - 1.2) * 5) s.happy = 0; });
      }
    }
    co.dlast = { w: wk, days: L.days, u: L.u, ot, lost: L.lost || 0, so: L.so || 0 };
    co.dl = { w: -1, days: {}, u: L.u, r: 0, paid: 0, q: L.q, ca: L.ca, cap: L.cap != null ? L.cap : ctx.cap };
    co.staff.forEach(s => {
      if (!SALES_ROLES[s.role]) return;
      const ws = s.ws && s.ws.w === wk ? s.ws : { u: 0, r: 0 };
      s.lw = { w: S.week, u: ws.u, r: ws.r };
      s.uh = (s.uh || []).concat(ws.u).slice(-8);
      s.ws = null;
    });
    const ow = co.ows && co.ows.w === wk ? co.ows : null;
    co.olw = ow ? { u: ow.u, r: ow.r } : null;
    co.ows = null;
    return true;
  };
  /* commission is paid on each seller's own full sales */
  window.commissionWeek = function (co) {
    const sr = co.staff.filter(s => SALES_ROLES[s.role]);
    if (!sr.length) return 0;
    const rev = co.lastW ? co.lastW.rev || 0 : 0;
    const tot = sum(sr, s => staffSkill(s) + 10);
    const own = dailyOk(co, BD[co.type]);
    let c = 0;
    sr.forEach(s => {
      if (!s.pay || s.pay.m === 'fix') return;
      const x = own ? (s.lw && s.lw.w === S.week ? s.lw.r : 0) * s.pay.rate : rev * (staffSkill(s) + 10) / Math.max(1, tot) * s.pay.rate;
      s.commEma = (s.commEma == null ? x : s.commEma) * 0.9 + x * 0.1;
      s.lastComm = x;
      c += x;
    });
    return c;
  };

  /* ---------- numbers of whole things ---------- */
  const capF = s => String(s).replace(/^./, x => x.toUpperCase());
  function fmtU(n, unit) {
    const div = !!DIV[unit];
    const k = div ? (n >= 10 ? Math.round(n) : Math.round(n * 10) / 10) : Math.round(n || 0);
    return k + ' ' + unitPl(unit, k);
  }
  /* a rate per week in words: "3 homes sold a week", "2 a month", "1 every 5 weeks" */
  function rateW(x, unit) {
    x = x || 0;
    if (DIV[unit]) return fmtU(x, unit) + ' a week';
    if (x >= 0.95) { const k = Math.round(x); return k + ' ' + unitPl(unit, k) + ' a week'; }
    if (x * 4.33 >= 0.95) { const k = Math.round(x * 4.33); return k + ' ' + unitPl(unit, k) + ' a month'; }
    if (x > 0.01) return '1 ' + unit + ' every ' + Math.round(1 / x) + ' weeks';
    return 'no ' + unitPl(unit, 2);
  }
  window.fmtU = fmtU;
  window.rateW = rateW;
  /* round 42: each trade says what it actually did, not "Cars sold" for a car wash */
  window.UNITW = { 'billable hour': 'Hours billed', 'lesson hour': 'Lesson hours taught', car: 'Cars cleaned', shoot: 'Shoots done', job: 'Jobs done', 'cleaning hour': 'Cleaning hours worked', 'dev hour': 'Dev hours billed', 'placed hour': 'Hours placed', treatment: 'Treatments given', lesson: 'Lessons given', 'home sold': 'Homes sold', visit: 'Visits made', meal: 'Meals sold', order: 'Orders', cover: 'Diners served', guest: 'Guests', 'member-week': 'Paying members', 'room-night': 'Room nights sold', 'guest visit': 'Guest visits', ticket: 'Tickets sold', basket: 'Customers served', 'car sold': 'Cars sold', contract: 'Contracts finished', 'unit sold': 'Homes sold', event: 'Events delivered', item: 'Items sold', litre: 'Litres sold', piece: 'Pieces sold', tonne: 'Tonnes sold', 'order lot': 'Orders delivered', ride: 'Rides driven', parcel: 'Parcels delivered', trip: 'Trips driven', voyage: 'Voyages sailed', flight: 'Flights flown', 'unit-week': 'Flats let', 'm2-week': 'Square metres let', 'space-week': 'Spaces let', policy: 'Policies in force', customer: 'Customers', client: 'Clients', MWh: 'Power sold (MWh)', barrel: 'Barrels sold', match: 'Matches played' };
  const soldLabel = unit => window.UNITW[unit] || (/sold$/.test(unit) ? capF(unitPl(unit, 2)) : capF(unitPl(unit, 2)) + ' sold');
  window.soldLabel = soldLabel;
  /* the company overview: today, this week so far, last week */
  window.unitsRows = function (co, bd, w) {
    const unit = bd.unit;
    if (!dailyOk(co, bd)) return row(soldLabel(unit), fmtU(w.units || 0, unit).replace(/ .*/, ''));
    const L = co.dl && co.dl.w === S.week ? co.dl : null;
    const td = L && L.days[S.day || 0] ? L.days[S.day || 0].u : 0;
    const wk = L ? L.u : 0;
    return row(soldLabel(unit) + ' this week', wk + (td ? ' · ' + td + ' today' : '')) + row('Last week', Math.round(w.units || 0));
  };
  /* a worker's own sales, or the team's output per person, in whole things */
  window.staffSalesRow = function (co, s, bd, per, mine) {
    const unit = bd.unit;
    if (SALES_ROLES[s.role] && dailyOk(co, bd)) {
      const h = s.uh || [];
      const lw = s.lw ? s.lw.u : 0;
      return row(soldLabel(unit), 'Last week ' + lw + (h.length > 1 ? ' · last ' + h.length + ' weeks ' + sum(h, x => x) : '')) + (s.pay && s.pay.m !== 'fix' ? row('Commission last week', money(Math.round(s.lastComm || 0))) : '');
    }
    return row(capF(unitPl(unit, 2)) + ' per person', esc(rateW(mine, unit)) + ' · team ' + esc(rateW(per, unit)));
  };

  /* ---------- Next day takes a moment; Until needed lets the days tick by ---------- */
  const DAY_MS = 650, TICK_MS = 320; /* round 39: a day takes a moment, so nothing slips past unseen */
  const nd0 = ACT.nextday;
  function busyBar(on) {
    const bar = document.querySelector('.advbar');
    if (bar) bar.classList.toggle('busy', !!on);
  }
  function sayBig() {
    if (!big.length) return;
    const x = big.splice(0)[0];
    if (!x) return;
    const unit = x[3].unit;
    toast(x[0].name + ': ' + (x[1] === 1 ? '1 ' + unit.replace(/ sold$/, '') + ' sold' : x[1] + ' ' + unitPl(unit.replace(/ sold$/, ''), 2) + ' sold') + ' today · ' + mshort(x[2]));
  }
  ACT.nextday = () => {
    if (ui.repLock || ui.dayBusy) return;
    ui.dayBusy = 1;
    busyBar(1);
    big.length = 0;
    setTimeout(() => {
      ui.dayBusy = 0;
      try { nd0(); } finally { busyBar(0); }
      sayBig();
    }, DAY_MS);
  };
  const un0 = ACT.untilneeded;
  ACT.untilneeded = () => {
    if (ui.untl) { ui.untl.stop = 1; return; }
    if (ui.repLock || ui.dayBusy) return;
    if (typeof mergeReps !== 'function' || typeof showWeekReport !== 'function') return un0();
    ui.dayBusy = 1;
    const T = ui.untl = { reps: [], hit: false, n: 0, stop: 0 };
    big.length = 0;
    const finish = () => {
      ui.untl = null;
      ui.dayBusy = 0;
      if (T.reps.length) S.lastRep = mergeReps(T.reps);
      ui.popAfterRep = T.hit;
      save();
      if (S.over) return render(true);
      if (T.reps.length) { showWeekReport(); return; }
      render();
      sayBig();
      if (T.hit && window.showPop) window.showPop();
      /* never stop silently: if nothing opened, say what stopped it */
      if (T.hit) setTimeout(() => { if (!ui.sheet && !ui.untl && T.why) toast('Stopped: ' + T.why); }, 700);
    };
    const tick = () => {
      if (ui.untl !== T) return;
      if (T.stop || S.over || T.n >= 26 * 7) return finish();
      const r = dayStep();
      T.n++;
      if (r.done) T.reps.push(r.done);
      /* round 45: stop for decisions and serious bad news, not for routine reading */
      const st = r.got.find(m => m.status === 'open' || (!m.read && m.tone === 'bad'));
      if (st) { T.hit = true; T.why = st.title || ''; }
      if (!T.hit && window.untlStop) { try { const w = window.untlStop(T); if (w) { T.hit = true; T.why = typeof w === 'string' ? w : ''; } } catch (e) { } }
      if (T.hit || S.over) return finish();
      if (ui.tab === 'home' && !ui.stack.length && !ui.sheet) render();
      setTimeout(tick, TICK_MS);
    };
    render();
    setTimeout(tick, TICK_MS);
  };
  /* while days tick, the buttons say so; tapping Until needed again stops it */
  const home10 = V.home;
  V.home = function () {
    let h = home10.apply(this, arguments);
    if (ui.untl) h = h.replace('<button class="btn untl" data-a="untilneeded">Until needed</button>', '<button class="btn untl run" data-a="untilneeded">Stop · ' + esc(todayLabel().split(' · ')[1].split(' ').slice(0, 2).join(' ')) + '</button>').replace('<button class="btn primary go" data-a="nextday">', '<button class="btn primary go" data-a="nextday" disabled>');
    return h;
  };
}

path = '/home/claude/w3/ledger.html'
t = open(path, encoding='utf8').read()


def rep(old, new, count=1):
    global t
    n = t.count(old)
    if n != count:
        raise SystemExit('MATCH %d (want %d): %s' % (n, count, old[:110]))
    t = t.replace(old, new)


# ---------- 15A: no accountant is picked for you ----------
rep("""      form: bd.needAS ? 'AS' : 'ENK',
      acc: S.pool.acc[1].id,""", """      form: bd.needAS ? 'AS' : 'ENK',
      acc: null,""")
rep("""        st.city = ui.ncPre.city;
        st.acc = poolFor(st.country).acc[1].id;""", """        st.city = ui.ncPre.city;
        st.acc = null;""")
rep("""      st.indep = 0;
      st.acc = poolFor(p.v).acc[1].id;""", """      st.indep = 0;
      st.acc = null;""")
rep("""  ACT.ncgo = p => {
    const st = ui.nc, bd = BD[p.bd];""", """  ACT.ncgo = p => {
    const st = ui.nc, bd = BD[p.bd];
    if (st.form === 'AS' && !st.acc) {
      toast('Pick an accountant first.', true);
      return;
    }""")

# ---------- 8: managers and worker paperwork ----------
rep("""function managerOnboard(co, s) {
  const n = co.mgr ? S.npcs[co.mgr] : null;
  const r = n ? n.stats.risk : 50;
  onbItems(s.role).forEach(it => {
    if (chance(0.55 + r * 0.004)) s.onb[it[0]] = 1;
  });
}""", """/* experienced managers (5+ years) or managers who have been fined before do all paperwork at once;
   newer managers sometimes forget one or two items */
function mgrDoesAll(co, n) {
  return !!(co.flags && co.flags.onbAll) || (n && (n.exp || 0) >= 5);
}
function managerOnboard(co, s) {
  const n = co.mgr ? S.npcs[co.mgr] : null;
  if (!n || !s || !s.onb) return;
  const items = onbItems(s.role);
  if (mgrDoesAll(co, n)) {
    items.forEach(it => {
      s.onb[it[0]] = 1;
    });
    return;
  }
  let missed = 0;
  items.forEach(it => {
    if (missed < 2 && !chance(0.78 + (n.exp || 0) * 0.03)) missed++;
    else s.onb[it[0]] = 1;
  });
}""")
rep("""  // paperwork catch-up
  co.staff.forEach(s => {
    const m = onbMissing(s);
    if (m.length && chance(0.1 + risk * 0.004)) s.onb[m[0][0]] = 1;
  });""", """  // paperwork catch-up: experienced or previously fined managers finish everything, newer ones get to it slowly
  co.staff.forEach(s => {
    const m = onbMissing(s);
    if (!m.length) return;
    if (mgrDoesAll(co, n)) m.forEach(it => {
      s.onb[it[0]] = 1;
    });
    else if (chance(0.25 + risk * 0.003)) s.onb[m[0][0]] = 1;
  });
  // 9A: good managers check business customers before invoicing; weaker ones take longer to think of it
  if (bd.b2b > 0 && !co.flags.ccheck && chance(0.05 + q * 0.5)) {
    co.flags.ccheck = 1;
    note(n.name + ' now credit-checks business customers before invoicing at ' + co.name + '.', 'good', co.id);
  }""")
rep("""      payCo(co, f, 'fine', 'Paperwork fine');
      co.rep = clamp(co.rep - 1, 0, 100);""", """      payCo(co, f, 'fine', 'Paperwork fine');
      co.rep = clamp(co.rep - 1, 0, 100);
      if (co.mgr && !co.flags.onbAll) {
        co.flags.onbAll = 1;
        const mn = S.npcs[co.mgr];
        if (mn) note(mn.name + ' got the fine at ' + co.name + ' and now completes all staff paperwork straight away.', 'n', co.id);
      }""")

# ---------- 12: raises only with a reason; better managers negotiate smaller raises ----------
rep("""    const mk = Math.round(wageFor(s.role, co) * (0.7 + nn.skill / 160) / 100) * 100;
    if (mk <= s.wage * 1.08 || (s.askW && S.week - s.askW < 12)) return;
    const d = mk - s.wage;""", """    const mk0 = Math.round(wageFor(s.role, co) * (0.7 + nn.skill / 160) / 100) * 100;
    const tenW = S.week - (s.w0 || S.week);
    const why = s.notice > 0 ? 'has handed in notice' : (mk0 > s.wage * 1.25 ? 'is paid far below market and may leave' : (staffSkill(s) >= 68 && tenW >= 26 && mk0 > s.wage * 1.04 ? 'has performed strongly for ' + Math.round(tenW / 4.35) + ' months' : ''));
    if (!why || mk0 <= s.wage * 1.03 || (s.askW && S.week - s.askW < 12)) return;
    /* a better manager closes the deal with a smaller raise and keeps the person just as happy */
    const mk = Math.max(s.wage + 100, Math.round((s.wage + (mk0 - s.wage) * (1 - 0.55 * q)) / 100) * 100);
    s.happy = S.week + Math.round(26 * (0.6 + q));
    const d = mk - s.wage;""")
rep("""        body: nn.name + ' (' + ROLES[s.role][0] + ') is paid below market. Suggested: ' + money(mk) + ' per month (+' + money(d) + ').',""",
    """        body: nn.name + ' (' + ROLES[s.role][0] + ') ' + why + '. I negotiated it down to ' + money(mk) + ' per month (+' + money(d) + ').',""")
rep("""    if (chance((0.0016 + Math.max(0, gap) * 0.012) * (hasHQ('hr') ? 0.75 : 1) * (hasLead(co) ? 0.8 : 1)) && !(co.flags.noquit)) out.push(['quit', s]);""",
    """    if (chance((0.0016 + Math.max(0, gap) * 0.012) * (hasHQ('hr') ? 0.75 : 1) * (hasLead(co) ? 0.8 : 1) * (s.happy && S.week < s.happy ? 0.4 : 1)) && !(co.flags.noquit)) out.push(['quit', s]);""")

# ---------- 13A: real experience curve towards each person's potential ----------
rep("""  co.staff.forEach(s => {
    s.skillGain = clamp(s.skillGain + 0.012 * (1 - staffSkill(s) / 110), -10, 30);
  });""", """  co.staff.forEach(s => {
    const n = S.npcs[s.id];
    if (!n) return;
    if (n.pot == null) n.pot = clamp(Math.round(n.skill + 16 + hrng(S.seed + ':pot:' + s.id)() * 30), n.skill + 8, 98);
    const cur = n.skill + s.skillGain;
    const age = n.age + Math.floor((S.week - (s.w0 || S.week)) / 52);
    const ageF = age < 25 ? 1.35 : age < 35 ? 1.1 : age < 50 ? 0.85 : age < 60 ? 0.6 : 0.35;
    s.skillGain = clamp(s.skillGain + Math.max(0, n.pot - cur) * 0.0065 * ageF, -10, Math.max(30, n.pot - n.skill));
  });""")
rep("""  if (s) s.skillGain = clamp(s.skillGain + gain, -10, 30); else co.oskill = clamp(co.oskill + gain, 0, 100);""",
    """  if (s) s.skillGain = clamp(s.skillGain + gain, -10, 70); else co.oskill = clamp(co.oskill + gain, 0, 100);""")

# ---------- 4: insurer first, its policies underneath ----------
rep("""  CT.insurance = function (co, bd) {
    let h = '<div class="card"><h3>Insurance""", """  CT.insurance = function (co, bd) {
    if (!co.insr) {
      const live = Object.keys(INSP).filter(k => co.ins[k]);
      return '<div class="card sense"><b>Pick an insurance company first</b><p>Each insurer prices and pays out differently. Its policies appear here once you choose one.</p></div>' +
        (live.length ? '<div class="card">' + row('Policies already running', live.map(k => esc(INSP[k][0])).join(', ')) + '</div>' : '') +
        poolFor(co.country).ins.map(a => provRow(a, 'ins', null, { a: 'provpick', p: { id: co.id, k: 'ins', a: a.id } })).join('');
    }
    let h = '<div class="card"><h3>Insurance""")

# ---------- 5: the open staff card stays open and the screen keeps its place ----------
rep("""      return '<details class="srow"><summary class="lrow">""", """      return '<details class="srow" data-sid="' + esc(String(s.id)) + '"' + (String(ui.openStaff) === String(s.id) ? ' open' : '') + '><summary class="lrow">""")

# ---------- 2a: one way to start marketing ----------
rep("""    const adds = off.filter(k => !CH[k].prem).slice(0, 5);
    h += '<h2 class="sec">Add a channel</h2><div class="chips">' + adds.map(k => btn(esc(CH[k].n), 'plopen', { id: co.id, ch: k }, 'chip')) .join('') + btn('More…', 'addch', { id: co.id }, 'chip') + '</div>';
""", "")
# compact planner: channel as a native picker
rep("""    let h = '<h2>Campaign</h2><div class="opt"><b>Channel</b><div class="chips">' + keys.slice(0, 7).map(k => chip(CH[k].n, 'ch', k, k === PL.ch)).join('') + '</div></div>';""",
    """    let h = '<h2>Campaign</h2><div class="opt"><b>Channel</b><select class="sel" onchange="UI.ACT.plset({k:\\'ch\\',v:this.value})">' + keys.map(k => '<option value="' + k + '"' + (k === PL.ch ? ' selected' : '') + '>' + esc(CH[k].n) + '</option>').join('') + '</select><small>' + esc(CH[PL.ch].note) + '</small></div>';""")

# ---------- picker: compact grid instead of a long list ----------
rep("""    openSheet('<h2>Choose</h2><div class="pklist">' + p.items.map(it => '<button class="opt pk """,
    """    openSheet('<h2>Choose</h2><div class="pklist pkgrid' + (p.items.length > 8 ? ' many' : '') + '">' + p.items.map(it => '<button class="opt pk """)

# ---------- 6B: manager focus instead of a long list of requests ----------
rep("""    if (mco) h += '<div class="card"><h3>Ask ' + esc(k.split(' ')[0]) + ' for a change</h3><p class="muted small">At ' + esc(mco.name) + '. ' + esc(k.split(' ')[0]) + ' decides how to do it and answers you here.</p><div class="btnrow col">' + ASK_OPTS.map(o => btn(o[1], 'askdo', { id: mco.id, k: o[0] }, 'chip wide')).join('') + btn('Call a meeting with ' + esc(k.split(' ')[0]), 'phmeet', { who: mco.id }, 'ghost wide') + '</div></div>';""",
    """    if (mco) h += '<div class="card"><h3>Focus for ' + esc(mco.name) + '</h3>' + chips([['profit', 'Profit'], ['growth', 'Growth'], ['quality', 'Quality']], mco.focus || '', 'setfocus', { id: mco.id }) + (mco.focusPlan && mco.focusPlan.length ? '<small>Plan: ' + esc(mco.focusPlan.map(x => FOCUS_ACT[x] || x).join(', then ')) + '</small>' : '') + '</div>';""")

open(path, 'w', encoding='utf8').write(t)
print('patch5 ok')

# ---------- 1B in the interview screen: only the last three lines, plus a patience meter ----------
t = open(path, encoding='utf8').read()
def rep2(old, new):
    global t
    assert t.count(old) == 1, old[:100]
    t = t.replace(old, new)
rep2("""    h += '<h2 class="sec">Salary discussion</h2><div class="chat"><div class="bub them">“' + esc(n.resume) + '” I am asking ' + money(n.ask) + ' a month.</div>' + talk.map(x => '<div class="bub ' + (x.me ? 'me' : 'them') + '">' + esc(x.t) + '</div>').join('') + '</div>';""",
     """    const lines = [{ me: 0, t: '“' + n.resume + '” I am asking ' + money(n.ask) + ' a month.' }].concat(talk).slice(-3);
    h += '<div class="sh"><h2 class="sec">Salary discussion</h2><small>Patience ' + (window.patDots ? window.patDots(n) : '') + '</small></div><div class="chat">' + lines.map(x => '<div class="bub ' + (x.me ? 'me' : 'them') + '">' + esc(x.t) + '</div>').join('') + '</div>';""")
rep2("""    const open = cl.map(id => S.npcs[id]).filter(n => n && !n.hired && !(ui.passed && ui.passed[n.id]));""",
     """    const open = cl.map(id => S.npcs[id]).filter(n => n && !n.hired && !n.gone && !(ui.passed && ui.passed[n.id]));""")
open(path, 'w', encoding='utf8').write(t)
print('interview ok')

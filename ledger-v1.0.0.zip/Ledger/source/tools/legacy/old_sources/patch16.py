# round 29: payday. Bills are paid on real days when the game is played day by day.
path = '/home/claude/w3/ledger.html'
T = '/home/claude/w3/tools/'
t = open(path, encoding='utf8').read()
mark = '/* ---------- no zooming: pinch, double tap, ctrl+wheel, ctrl +/- ---------- */'
assert t.count(mark) == 1
t = t.replace(mark, open(T + 'round29.js', encoding='utf8').read() + '\n' + mark)
# settle(): in day mode, wages, rent and suppliers are paid on their own days (round 29); tax keeps its month-end timing
a = "  ['wages', 'rent', 'other', 'tax'].forEach(k => {\n    if (k === 'tax' && (!co.taxDue"
assert t.count(a) == 1, 'settle'
t = t.replace(a, "  (window.R29 && R29.on() ? ['tax'] : ['wages', 'rent', 'other', 'tax']).forEach(k => {\n    if (k === 'tax' && (!co.taxDue")
a = "  co.wageShort = co.pay.wages || 0;\n  return unpaid;"
assert t.count(a) == 1, 'wageShort'
t = t.replace(a, "  if (!(window.R29 && R29.on())) co.wageShort = co.pay.wages || 0;\n  return unpaid;")
# the owner's salary in a limited company: part of payroll on payday in day mode
a = "  if (co.form === 'AS' && co.ownerSalary > 0 && co.st === 'open') {\n    const sal = co.ownerSalary, cost = sal * OC();"
assert t.count(a) == 1, 'ownersal'
t = t.replace(a, "  if (co.form === 'AS' && co.ownerSalary > 0 && co.st === 'open' && !(window.R29 && R29.on())) {\n    const sal = co.ownerSalary, cost = sal * OC();")
i = t.rindex('</style>')
t = t[:i] + open(T + 'round29.css', encoding='utf8').read() + '\n' + t[i:]
open(path, 'w', encoding='utf8').write(t)
print('patch16 ok')

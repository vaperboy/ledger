# round 34: hours are hours
path = '/home/claude/w3/ledger.html'
T = '/home/claude/w3/tools/'
t = open(path, encoding='utf8').read()
mark = '/* ---------- no zooming: pinch, double tap, ctrl+wheel, ctrl +/- ---------- */'
assert t.count(mark) == 1
t = t.replace(mark, open(T + 'round34.js', encoding='utf8').read() + '\n' + mark)
# each working day gets its share of the week's capacity (a credit that carries over within the week)
a = "      room = Math.max(0, Math.floor(L.cap * (otOk ? 1.2 : 1) + (L.ca || 0) - L.u + 1e-9));"
assert t.count(a) == 1, 'room'
t = t.replace(a, "      const nWd = sh.filter(x => x > 0).length || 7;\n      L.wd = nWd;\n      L.cr = (L.cr || 0) + (s > 0 ? (L.cap * (otOk ? 1.2 : 1) + (L.ca || 0)) / nWd : 0); /* round 34: today's share of the week's work */\n      room = Math.max(0, Math.floor(Math.min(L.cap * (otOk ? 1.2 : 1) + (L.ca || 0) - L.u, L.cr) + 1e-9));")
a = "    L.q -= sold;"
assert t.count(a) == 1, 'cr'
t = t.replace(a, "    L.q -= sold;\n    if (L.cr != null) L.cr = Math.max(0, L.cr - sold);")
# staff work at least their contract on a working day
a = "h = DRIVE[s.role] == null ? clamp(7.5 + (sd - 1) * 1.5 + gauss() * 0.5, 4, 10) : clamp(8 + (sd - 1) * 2.5 + gauss() * 1.2, 5, 12);"
assert t.count(a) == 1, 'hours'
t = t.replace(a, "h = DRIVE[s.role] == null ? clamp(7.5 + Math.max(0, (sd - 1) * 1.5 + gauss() * 0.5), 7.5, 10) : clamp(7.5 + Math.max(0, (sd - 1) * 2.5 + gauss() * 1.2), 7.5, 12);")
# "fully booked" means a full working day, not a seventh of the week
a = "if (cap > 0 && x.u >= cap / 7 * 0.98) L[L.length - 1].full = 1;"
assert t.count(a) == 1, 'full'
t = t.replace(a, "if (cap > 0 && x.u >= cap / (co.dl.wd || 7) * 0.98) L[L.length - 1].full = 1;")
open(path, 'w', encoding='utf8').write(t)
print('patch21 ok')

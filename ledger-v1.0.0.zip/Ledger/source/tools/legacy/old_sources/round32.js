/* ===== Round 32: PC and iPad.
   Phones keep the phone layout. From 760 px wide the bottom bar becomes a side menu with your name, the date and your net
   worth on top, and screens get room instead of a cropped phone column. From 1000 px Home splits into two columns and
   Companies shows the list beside the selected company's details, like a manager game. ===== */
window.R32 = window.R32 || {};
(function () {
  const R32 = window.R32;
  const U = window.UI, { ui, V, esc } = U;
  const P = o => esc(JSON.stringify(o));
  const ini = n => String(n || '?').replace(/[^\p{L}0-9 ]/gu, ' ').trim().split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase() || '?';
  const isWide = () => window.innerWidth >= 760, isWideX = () => window.innerWidth >= 1000;
  R32.isWide = isWide;
  let last = null;
  function mode() {
    const w = isWide(), x = isWideX(), k = (w ? 1 : 0) + (x ? 2 : 0);
    document.documentElement.classList.toggle('wide32', w);
    document.documentElement.classList.toggle('wide32x', x);
    if (last !== null && last !== k && typeof S !== 'undefined' && S) { try { U.render(true); } catch (e) { } }
    last = k;
  }
  window.addEventListener('resize', mode);
  mode();
  /* the side menu gets who you are and where you stand */
  function brand() {
    try {
      if (!isWide() || typeof S === 'undefined' || !S || !S.player) return;
      const nav = document.querySelector('nav.nb');
      if (!nav) return;
      let nw = 0;
      try { nw = netWorth().total; } catch (e) { }
      const html = '<small>' + esc(window.todayLabel ? todayLabel() : '') + '</small><b>' + esc(S.player.name || '') + '</b><span>Net worth ' + esc(mshort(nw)) + '</span>';
      let b = nav.querySelector('.brand32');
      if (!b) { b = document.createElement('button'); b.className = 'brand32'; b.setAttribute('data-a', 'tab'); b.setAttribute('data-p', 'home'); nav.insertBefore(b, nav.firstChild); }
      if (b.innerHTML !== html) b.innerHTML = html;
    } catch (e) { }
  }
  new MutationObserver(() => { if (isWide()) brand(); }).observe(document.body, { childList: true, subtree: true });
  /* companies: the list beside the details */
  const live = () => S.cos.filter(c => c.st !== 'sold' && c.st !== 'bust');
  function list(sel) {
    return '<div class="list32">' + live().map(co => {
      const al = (window.coAlerts(co) || []).filter(a => a[1] === 'bad');
      const last = co.hist && co.hist.length ? co.hist[co.hist.length - 1].profit : null;
      return '<button class="li32' + (co.id === sel ? ' on' : '') + '" data-a="go" data-p="' + P({ n: 'co', p: { id: co.id } }) + '"><span class="av">' + esc(ini(co.name)) + '</span><span class="ctext"><b>' + esc(co.name) + '</b><small>' + (co.type === 'hold' ? 'Holding' : esc(BD[co.type].n)) + ' · ' + (co.mgr && S.npcs[co.mgr] ? esc(S.npcs[co.mgr].name) : 'You run it') + '</small>' + (al.length ? '<small class="neg">' + esc(al[0][0]) + '</small>' : '') + '</span>' + (last != null ? '<b class="' + (last >= 0 ? 'pos' : 'neg') + '">' + (last >= 0 ? '+' : '−') + mshort(Math.abs(last)) + '</b>' : '') + '</button>';
    }).join('') + '</div>';
  }
  const co32 = V.co;
  V.co = function (p) {
    const h = co32.apply(this, arguments);
    try {
      if (!isWideX() || !p || !getCo(p.id) || live().length < 2) return h;
      ui.sel32 = p.id;
      return '<div class="split32">' + list(p.id) + '<div class="det32">' + h + '</div></div>';
    } catch (e) { return h; }
  };
  const cos32 = V.cos;
  V.cos = function () {
    const h = cos32.apply(this, arguments);
    try {
      if (!isWideX()) return h;
      const L = live();
      if (!L.length) return h;
      const sel = L.find(c => c.id === ui.sel32) || L[0];
      return '<div class="split32 cos32"><div class="list32 wide">' + h + '</div><div class="det32"><div class="dethd32"><b>' + esc(sel.name) + '</b><small>' + (sel.type === 'hold' ? 'Holding' : esc(BD[sel.type].n)) + '</small></div>' + co32.call(this, { id: sel.id }) + '</div></div>';
    } catch (e) { return h; }
  };
})();

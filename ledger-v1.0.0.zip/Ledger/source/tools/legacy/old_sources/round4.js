/* ---------- 1B: salary talk has a patience meter ---------- */
  const offer1 = ACT.offer;
  ACT.offer = p => {
    const n = S.npcs[p.n];
    if (!n) return offer1(p);
    if (n.pat == null) n.pat = n.pers === 'driven' ? 2 : n.pers === 'loyal' || n.pers === 'steady' ? 4 : 3;
    if (n.gone) {
      toast(n.name + ' has taken another job.', true);
      return;
    }
    const w = Math.round(U.inum('w' + n.id, n.ask) / 100) * 100;
    offer1(p);
    if (n.hired) return;
    n.pat -= w < n.ask * 0.9 ? 2 : 1;
    const L = ui.talk && ui.talk[n.id];
    if (n.pat <= 0) {
      n.gone = 1;
      if (L) L.push({ me: 0, t: 'I have accepted another offer. Good luck.' });
      ui.cand = null;
      toast(n.name + ' is no longer interested.', true);
    }
    render();
  };
  window.patDots = n => {
    const max = n.pers === 'driven' ? 2 : n.pers === 'loyal' || n.pers === 'steady' ? 4 : 3;
    const left = n.pat == null ? max : Math.max(0, n.pat);
    return '<span class="pdots">' + Array.from({ length: max }, (x, i) => '<i class="' + (i < left ? 'on' : '') + '"></i>').join('') + '</span>';
  };

/* ---------- 6B: the manager follows a focus and explains the plan by text ---------- */
  const FOCUS_ACT = window.FOCUS_ACT = {
    price_up: 'raise prices a little',
    price_down: 'lower prices a little',
    hire: 'hire one more person',
    cut: 'trim staff costs',
    mkt_more: 'spend more on marketing',
    mkt_less: 'cut weak marketing',
    quality: 'step up maintenance and quality',
    save: 'reduce running costs'
  };
  const FOCUS_N = { profit: 'Profit', growth: 'Growth', quality: 'Quality' };
  function planFor(co, focus, skip) {
    const w = co.lastW || {}, util = w.util || 0;
    const mk = Object.keys(co.mkt || {}).filter(k => co.mkt[k] && co.mkt[k].b).length;
    const std = stdStaff(BD[co.type], co.size || 1);
    const short = std.some(x => co.staff.filter(s => s.role === x[0] && !s.notice).length < x[1]);
    const c = [];
    const add = (k, why, ok) => {
      if (ok && c.every(x => x[0] !== k)) c.push([k, why]);
    };
    if (focus === 'profit') {
      add('price_up', 'we are busy most days, so a small price rise costs few customers', util > 0.85 && co.price < 2);
      add('mkt_less', 'some of the ad money is not bringing customers back', mk > 0 && co.aware > 55);
      add('save', 'upkeep is higher than the business needs right now', co.maint > 1);
      add('cut', 'we have more people than work', util < 0.5 && co.staff.length > 1);
      add('price_up', 'our prices are below what the market pays', co.price < 0);
      add('save', 'every small saving goes straight to profit', co.maint > 0);
    } else if (focus === 'growth') {
      add('hire', 'we turn customers away because we lack hands', util > 0.9 || short);
      add('mkt_more', 'more people need to know about us', co.aware < 60);
      add('price_down', 'demand is soft and a lower price wins customers', util < 0.6 && co.price > -2);
      add('mkt_more', 'growth comes from new customers', true);
    } else {
      add('quality', 'better upkeep means fewer breakdowns and happier customers', co.maint < 2);
      add('hire', 'the team is stretched and quality slips when we rush', util > 0.95 || short);
      add('price_up', 'better quality lets us charge a little more', co.maint >= 2 && co.price < 1);
    }
    const q = mgrQual(co);
    let list = c.filter(x => !skip || skip.indexOf(x[0]) < 0);
    if (q < 0.45 && list.length > 1 && chance(0.35)) list = list.slice(1).concat(list.slice(0, 1));
    return list.slice(0, 2);
  }
  function planText(co, plan) {
    return plan.length ? 'For ' + co.name + ' I would ' + plan.map((x, i) => (i ? 'then ' : '') + FOCUS_ACT[x[0]] + ', because ' + x[1]).join('; ') + '.' : 'Honestly, I would not change anything at ' + co.name + ' right now.';
  }
  function sendPlan(co, focus, plan, alt) {
    const n = S.npcs[co.mgr];
    addMsg({
      kind: 'ask',
      from: n.name,
      role: titleFor(co, 'mgr'),
      title: (alt ? 'Another idea' : 'My plan') + ': ' + FOCUS_N[focus],
      body: planText(co, plan),
      co: co.id,
      opts: [{ l: 'Sounds smart', d: 'Go ahead', fx: {} }, { l: alt ? 'Keep the first plan' : 'Let us discuss', d: '', fx: {} }],
      act: 'focusplan',
      data: { id: co.id, focus, plan: plan.map(x => x[0]), alt: alt ? 1 : 0, first: co.focusDraft || null },
      exp: S.week + 2
    });
  }
  ACT.setfocus = p => {
    const co = getCo(p.id);
    if (!co || !co.mgr || !S.npcs[co.mgr]) return;
    co.focus = p.v;
    const plan = planFor(co, p.v);
    co.focusDraft = plan.map(x => x[0]);
    sendPlan(co, p.v, plan, false);
    save();
    render();
  };
  function runStep(co, k) {
    const ids = new Set(S.inbox.map(m => m.id));
    co.askW = null;
    askManager(co, k);
    const said = S.inbox.filter(m => !ids.has(m.id));
    S.inbox = S.inbox.filter(m => ids.has(m.id));
    return said.length ? said[0].body : '';
  }
  ACTS.focusplan = (m, idx) => {
    const co = getCo(m.data.id);
    if (!co || !co.mgr || !S.npcs[co.mgr]) return true;
    const n = S.npcs[co.mgr];
    if (idx === 0 || m.data.alt) {
      const plan = idx === 0 ? m.data.plan : (m.data.first || []);
      co.focusPlan = plan.slice();
      co.focusW = S.week;
      const said = plan.length ? runStep(co, plan[0]) : '';
      if (plan.length) co.focusPlan.shift();
      addMsg({ kind: 'info', from: n.name, role: titleFor(co, 'mgr'), title: 'Re: ' + FOCUS_N[m.data.focus], body: (plan.length ? 'Good. ' + said + (co.focusPlan.length ? ' Next I will ' + FOCUS_ACT[co.focusPlan[0]] + '.' : '') : 'Then we keep things as they are.'), co: co.id, tone: 'n', status: 'done' });
      return true;
    }
    const alt = planFor(co, m.data.focus, m.data.plan);
    sendPlan(co, m.data.focus, alt, true);
    return true;
  };
  /* every four weeks the manager carries out the next step, and re-plans when a step is done */
  function focusWeek() {
    S.cos.forEach(co => {
      if (!co.focus || !co.mgr || !S.npcs[co.mgr] || co.st !== 'open') return;
      if (S.week - (co.focusW || 0) < 4) return;
      co.focusW = S.week;
      if (!co.focusPlan || !co.focusPlan.length) co.focusPlan = planFor(co, co.focus).map(x => x[0]);
      const k = co.focusPlan.shift();
      if (!k) return;
      const said = runStep(co, k);
      if (said) note(S.npcs[co.mgr].name + ' (' + FOCUS_N[co.focus] + '): ' + said, 'n', co.id);
    });
  }

/* ---------- 13A: long, strong service earns better titles ---------- */
  function titleWeek() {
    if (S.week % 4 !== 1) return;
    S.cos.forEach(co => {
      if (co.st !== 'open') return;
      co.staff.forEach(s => {
        const n = S.npcs[s.id];
        if (!n || s.flag || s.notice) return;
        const ten = S.week - (s.w0 || S.week);
        if (ten < 156 || staffSkill(s) < 72) return;
        if (s.titleW && S.week - s.titleW < 52) return;
        const lad = ladderFor(co, s);
        if (!lad || !lad.length) return;
        const to = lad[0];
        s.titleW = S.week;
        const mn = co.mgr && S.npcs[co.mgr];
        addMsg({
          kind: 'ask',
          from: mn ? mn.name : n.name,
          role: mn ? titleFor(co, 'mgr') : ROLES[s.role][0],
          title: 'Promotion: ' + n.name + ' at ' + co.name,
          body: (mn ? n.name + ' has ' + Math.floor(ten / 52) + ' years here with strong results and deserves a step up to ' : 'After ' + Math.floor(ten / 52) + ' years of good work I would like a step up to ') + esc(ROLES[to] ? ROLES[to][0] : to) + '.',
          co: co.id,
          opts: [{ l: 'Promote', d: 'Better title and pay', fx: {} }, { l: 'Not now', d: 'May lower motivation', fx: {} }],
          act: 'titleask',
          data: { id: co.id, sid: s.id, role: to },
          exp: S.week + 3
        });
      });
    });
  }
  ACTS.titleask = (m, idx) => {
    const co = getCo(m.data.id);
    if (!co) return true;
    if (idx === 0) {
      const r = promoteStaff(co, m.data.sid, m.data.role);
      if (r && r !== 'ok' && r !== true) note('The promotion could not go through: ' + r, 'n', co.id);
    } else {
      const s = co.staff.find(x => x.id === m.data.sid);
      if (s) s.happy = 0;
    }
    return true;
  };
  const nextWeek1 = window.nextWeek;
  window.nextWeek = function () {
    const r = nextWeek1.apply(this, arguments);
    try {
      if (S && !S.over) {
        focusWeek();
        titleWeek();
      }
    } catch (e) {
      console.error(e);
    }
    return r;
  };

/* ---------- staff card stays open while you work on it ---------- */
  document.addEventListener('toggle', e => {
    const d = e.target;
    if (!d || !d.classList || !d.classList.contains('srow')) return;
    const sid = d.getAttribute('data-sid');
    if (d.open) ui.openStaff = sid;
    else if (String(ui.openStaff) === sid) ui.openStaff = null;
  }, true);

/* ---------- 14B: the week report opens every week, Until needed sums the skipped weeks ---------- */
  function mergeReps(list) {
    if (list.length === 1) return list[0];
    const o = { ev: [], bw: {}, cos: [], meD: 0, nw0: list[0].nw0, w: list[list.length - 1].w, weeks: list.length };
    const byCo = {};
    list.forEach(r => {
      o.ev = o.ev.concat(r.ev || []);
      o.meD += r.meD || 0;
      for (const k in r.bw || {}) o.bw[k] = (o.bw[k] || 0) + r.bw[k];
      (r.cos || []).forEach(c => {
        const x = byCo[c.id] || (byCo[c.id] = { id: c.id, name: c.name, rev: 0, profit: 0, units: 0, unit: c.unit });
        x.rev += c.rev;
        x.profit += c.profit;
        x.units += c.units || 0;
      });
    });
    o.cos = Object.keys(byCo).map(k => byCo[k]);
    return o;
  }
  function showWeekReport() {
    ui.repLock = Date.now();
    ui.repAnim = 1;
    go('weekreport');
    setTimeout(() => {
      ui.repLock = 0;
      const b = document.querySelector('.repgo');
      if (b) {
        b.disabled = false;
        b.classList.remove('wait');
      }
    }, 1400);
  }
  ACT.nextday = () => {
    if (ui.repLock) return;
    const r = dayStep();
    save();
    if (S.over) return render(true);
    if (r.done) {
      showWeekReport();
      return;
    }
    render();
    if (r.got.some(m => m.status === 'open') && window.showPop) window.showPop();
  };
  ACT.untilneeded = () => {
    if (ui.repLock) return;
    const reps = [];
    let hit = false;
    for (let i = 0; i < 26 * 7 && !S.over; i++) {
      const r = dayStep();
      if (r.done) reps.push(r.done);
      if (r.got.some(m => m.status === 'open' || !m.read)) {
        hit = true;
        break;
      }
    }
    if (reps.length) S.lastRep = mergeReps(reps);
    ui.popAfterRep = hit;
    save();
    if (S.over) return render(true);
    if (reps.length) {
      showWeekReport();
      return;
    }
    render();
    if (hit && window.showPop) window.showPop();
  };
  ACT.repdone = () => {
    if (ui.repLock) return;
    ui.repAnim = 0;
    U.back();
    if (window.showPop) window.showPop(true);
  };

/* ---------- pop-ups never scroll: overflowing content is split into pages ---------- */
  let fitting = false;
  function fitSheet() {
    const sh = document.querySelector('#app .sheet');
    if (!sh || fitting) return;
    fitting = true;
    try {
      const kids = Array.prototype.slice.call(sh.children).filter(x => !x.classList.contains('pager'));
      kids.forEach(x => {
        x.style.display = '';
      });
      const old = sh.querySelector('.pager');
      if (old) old.remove();
      sh.style.overflowY = 'hidden';
      if (sh.scrollHeight <= sh.clientHeight + 2) return;
      const head = kids[0] && kids[0].tagName === 'H2' ? kids[0] : null;
      const lastBtn = kids[kids.length - 1];
      const foot = lastBtn && lastBtn !== head && (lastBtn.classList.contains('btnrow') || lastBtn.classList.contains('btn') || (lastBtn.classList.contains('chips') && lastBtn.querySelector('.btn.primary'))) ? lastBtn : null;
      const body = kids.filter(x => x !== head && x !== foot);
      const cs = getComputedStyle(sh);
      const gap = parseFloat(cs.rowGap || cs.gap) || 8;
      const room = sh.clientHeight - parseFloat(cs.paddingTop) - parseFloat(cs.paddingBottom) - (head ? head.offsetHeight + gap : 0) - (foot ? foot.offsetHeight + gap : 0) - 52;
      const pages = [[]];
      let used = 0;
      body.forEach(x => {
        const hgt = x.offsetHeight + gap;
        if (pages[pages.length - 1].length && used + hgt > room) {
          pages.push([]);
          used = 0;
        }
        pages[pages.length - 1].push(x);
        used += hgt;
      });
      if (pages.length < 2) return;
      const key = (ui.sheet && ui.sheet.html || '').length;
      if (ui.pgKey !== key) {
        ui.pgKey = key;
        ui.pg = 0;
      }
      const pg = Math.min(ui.pg || 0, pages.length - 1);
      pages.forEach((p, i) => p.forEach(x => {
        x.style.display = i === pg ? '' : 'none';
      }));
      const nav = document.createElement('div');
      nav.className = 'pager';
      nav.innerHTML = '<button type="button" class="btn chip" ' + (pg ? '' : 'disabled') + '>‹ Back</button><span>' + (pg + 1) + ' / ' + pages.length + '</span><button type="button" class="btn chip primary" ' + (pg < pages.length - 1 ? '' : 'disabled') + '>Next ›</button>';
      const b = nav.querySelectorAll('button');
      b[0].onclick = ev => {
        ev.stopPropagation();
        ui.pg = Math.max(0, pg - 1);
        fitting = false;
        fitSheet();
      };
      b[1].onclick = ev => {
        ev.stopPropagation();
        ui.pg = Math.min(pages.length - 1, pg + 1);
        fitting = false;
        fitSheet();
      };
      if (foot) sh.insertBefore(nav, foot); else sh.appendChild(nav);
    } finally {
      fitting = false;
    }
  }
  new MutationObserver(() => {
    if (!fitting) requestAnimationFrame(fitSheet);
  }).observe(document.getElementById('app') || document.body, { childList: true });


/* ===== Round 33: every trade sells its own way.
   Nine sales mechanics, each with real effects, and every business type gets the three that fit it:
     contract  recurring B2B deals offered now and then: steady extra volume at a discount, for a set number of weeks
     tender    a big one-off you bid for: bid low, at list or high; the lower the bid the better the odds
     offer     a one-off order from a group or client (private dinner, team party, festival pitch): accept or decline
     referral  happy customers bring others; works only with a good rating
     platform  sell through an app or booking site: more customers, but a commission on what goes through it
     members   memberships, subscriptions, loyalty: steadier demand, a small cost in perks
     peak      a season that belongs to the trade (January rush, wedding season, tax season): prepare with temps or not
     emergency on-call service: a weekly cost, more jobs at a premium price
     upsell    add-ons at the till or in the booking: a set-up cost, then extra revenue on every sale
   Managers handle offers and contracts themselves; owner-run companies ask you. ===== */
window.R33 = window.R33 || {};
(function () {
  const R33 = window.R33;
  const U = window.UI, { ui, V, ACT, esc, row, btn, render, save, toast } = U;
  const P = o => esc(JSON.stringify(o));
  const pillp = (t, c) => '<span class="pill ' + (c || '') + '">' + t + '</span>';
  const MO = ['', 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  /* [mechanic, name, who/what, options] per business type */
  const W = {
    cons: [['referral', 'Word of mouth from clients'], ['contract', 'Monthly retainer', 'a local company'], ['tender', 'Public framework tender', 'the municipality']],
    tutor: [['members', 'Monthly lesson packages'], ['platform', 'Tutoring marketplace', '', { lift: 0.25, fee: 0.15 }], ['peak', 'Exam season', '', { m: [5, 6, 12], b: 0.35 }]],
    carclean: [['members', 'Monthly wash subscription'], ['contract', 'Fleet cleaning contract', 'a car-sharing company'], ['peak', 'Spring salt wash', '', { m: [3, 4], b: 0.4 }]],
    photo: [['peak', 'Wedding season', '', { m: [5, 6, 7, 8], b: 0.45 }], ['referral', 'Couples recommend you'], ['offer', 'Corporate photo shoot', 'a company']],
    handy: [['emergency', 'Urgent call-outs'], ['platform', 'Job-matching app', '', { lift: 0.3, fee: 0.1 }], ['referral', 'Neighbours recommend you']],
    cleaning: [['contract', 'Office cleaning contract', 'an office building'], ['members', 'Fortnightly home cleaning'], ['tender', 'Municipal cleaning tender', 'the municipality']],
    webdev: [['contract', 'Maintenance retainer', 'a client'], ['tender', 'Software tender', 'a public agency'], ['referral', 'Client referrals']],
    mktg: [['contract', 'Monthly retainer', 'a brand'], ['tender', 'Pitch for a big brand', 'a national brand'], ['referral', 'Client referrals']],
    law: [['contract', 'Corporate retainer', 'a company'], ['referral', 'Referrals from accountants'], ['emergency', 'Urgent cases']],
    acctfirm: [['contract', 'Monthly bookkeeping', 'a small business'], ['peak', 'Tax season', '', { m: [3, 4], b: 0.4 }], ['referral', 'Client referrals']],
    staffing: [['contract', 'Framework agreement', 'a warehouse company'], ['peak', 'Summer temps', '', { m: [6, 7], b: 0.35 }], ['tender', 'Public staffing tender', 'the region']],
    barber: [['members', 'Haircut membership'], ['platform', 'Online booking app', '', { lift: 0.15, fee: 0.06 }], ['upsell', 'Hair products at the till', '', { u: 0.1 }]],
    drivsk: [['peak', 'Spring and summer rush', '', { m: [4, 5, 6], b: 0.35 }], ['members', 'Lesson packages'], ['referral', 'Students recommend you']],
    physio: [['contract', 'Company health deal', 'a local employer'], ['referral', 'Doctor referrals'], ['members', 'Treatment series']],
    estate: [['referral', 'Past sellers recommend you'], ['peak', 'Spring market', '', { m: [3, 4, 5], b: 0.35 }], ['upsell', 'Styling and staging package', '', { u: 0.06 }]],
    pets: [['members', 'Daycare membership'], ['peak', 'Summer holiday boarding', '', { m: [6, 7], b: 0.5 }], ['upsell', 'Grooming add-ons', '', { u: 0.12 }]],
    foodtruck: [['offer', 'Festival pitch', 'a festival'], ['peak', 'Festival summer', '', { m: [6, 7, 8], b: 0.4 }], ['contract', 'Office lunch rota', 'a business park']],
    cafe: [['members', 'Loyalty card'], ['contract', 'Office catering', 'an office'], ['platform', 'Food delivery apps', '', { lift: 0.18, fee: 0.3 }]],
    restaurant: [['platform', 'Food delivery apps', '', { lift: 0.15, fee: 0.3 }], ['offer', 'Private dining group', 'a company'], ['upsell', 'Wine pairing', '', { u: 0.12 }]],
    nightclub: [['offer', 'Private party booking', 'a company'], ['peak', 'Christmas parties', '', { m: [11, 12], b: 0.45 }], ['upsell', 'Table service', '', { u: 0.15 }]],
    gym: [['members', 'Memberships'], ['peak', 'January rush', '', { m: [1], b: 0.45 }], ['contract', 'Corporate wellness deal', 'a large employer']],
    hotel: [['platform', 'Booking sites', '', { lift: 0.3, fee: 0.17 }], ['offer', 'Conference booking', 'a company'], ['upsell', 'Breakfast and late checkout', '', { u: 0.1 }]],
    casino: [['upsell', 'VIP hosting', '', { u: 0.08 }], ['offer', 'Tour group', 'a tour operator'], ['peak', 'Holiday season', '', { m: [12], b: 0.3 }]],
    fun: [['offer', 'Birthday and team parties', 'a company'], ['peak', 'School holidays', '', { m: [6, 7, 10], b: 0.4 }], ['members', 'Annual pass']],
    kiosk: [['members', 'Loyalty app'], ['upsell', 'Coffee and hot food', '', { u: 0.1 }], ['platform', 'Delivery apps', '', { lift: 0.12, fee: 0.25 }]],
    boutique: [['peak', 'Black Friday and Christmas', '', { m: [11, 12], b: 0.5 }], ['platform', 'Online marketplace', '', { lift: 0.2, fee: 0.15 }], ['members', 'Stylist club']],
    webshop: [['platform', 'Marketplaces', '', { lift: 0.3, fee: 0.15 }], ['peak', 'Black Friday', '', { m: [11], b: 0.6 }], ['members', 'Subscribe and save']],
    grocery: [['members', 'Loyalty programme'], ['platform', 'Grocery delivery', '', { lift: 0.1, fee: 0.2 }], ['peak', 'Christmas and Easter', '', { m: [3, 12], b: 0.2 }]],
    hardware: [['contract', 'Trade account for builders', 'a building firm'], ['peak', 'Spring building season', '', { m: [4, 5], b: 0.35 }], ['upsell', 'Delivery and tool hire', '', { u: 0.08 }]],
    cardealer: [['upsell', 'Financing and insurance', '', { u: 0.04 }], ['contract', 'Company car fleet', 'a company'], ['peak', 'Spring car season', '', { m: [3, 4], b: 0.3 }]],
    construction: [['tender', 'Public tender', 'the municipality'], ['contract', 'Framework agreement', 'a housing association'], ['referral', 'Developers recommend you']],
    electrician: [['emergency', 'Urgent call-outs'], ['contract', 'Service agreement', 'a property manager'], ['tender', 'Installation tender', 'a developer']],
    plumber: [['emergency', 'Emergency call-outs'], ['contract', 'Insurance repair agreement', 'an insurance company'], ['referral', 'Neighbours recommend you']],
    event: [['tender', 'Conference tender', 'a large company'], ['peak', 'Christmas party season', '', { m: [11, 12], b: 0.4 }]],
    engcons: [['tender', 'Design competition', 'a developer'], ['contract', 'Framework agreement', 'the municipality'], ['referral', 'Clients recommend you']],
    bakery: [['contract', 'Café and hotel supply', 'a hotel'], ['peak', 'Christmas baking', '', { m: [12], b: 0.45 }], ['offer', 'Wedding cake order', 'a couple']],
    brewery: [['contract', 'Bar supply agreement', 'a bar chain'], ['peak', 'Summer and Christmas beer', '', { m: [6, 7, 12], b: 0.3 }], ['offer', 'Beer festival', 'a festival']],
    furniture: [['offer', 'Hotel or office fit-out', 'a hotel'], ['platform', 'Design marketplace', '', { lift: 0.2, fee: 0.15 }], ['referral', 'Customers recommend you']],
    salmon: [['contract', 'Export contract', 'an importer'], ['tender', 'Retail chain tender', 'a supermarket chain']],
    factory: [['contract', 'Supply agreement', 'a manufacturer'], ['tender', 'Large order tender', 'an industrial buyer'], ['referral', 'Buyers recommend you']],
    taxi: [['platform', 'Ride-hailing app', '', { lift: 0.3, fee: 0.25 }], ['contract', 'Company account', 'a company'], ['peak', 'Christmas party nights', '', { m: [12], b: 0.35 }]],
    courier: [['contract', 'Webshop delivery contract', 'a webshop'], ['peak', 'Christmas parcels', '', { m: [11, 12], b: 0.5 }], ['platform', 'Delivery platform', '', { lift: 0.2, fee: 0.15 }]],
    trucking: [['contract', 'Haulage contract', 'a wholesaler'], ['tender', 'Freight tender', 'a manufacturer']],
    shipping: [['contract', 'Charter contract', 'a trading house'], ['tender', 'Cargo tender', 'an exporter']],
    airline: [['contract', 'Public route contract', 'the transport authority'], ['upsell', 'Seat and bag fees', '', { u: 0.08 }], ['peak', 'Summer holidays', '', { m: [6, 7], b: 0.3 }]]
  };
  R33.W = W;
  const TXT = {
    contract: 'Companies ask for steady deals: a set volume every week for a while, at a discount.',
    tender: 'Big jobs go out to bid. Bid low for better odds, high for better margins.',
    offer: 'One-off orders from groups and clients. Take them when you have room.',
    referral: 'Happy customers bring others. Works only while your rating is good.',
    platform: 'More customers through the app or site, but it takes a cut of what goes through it.',
    members: 'Regulars who pay ahead come back more steadily. Perks cost a little.',
    peak: 'A season that belongs to your trade. Temporary help lets you serve the rush.',
    emergency: 'Being on call costs a weekly fee and brings jobs at a premium price.',
    upsell: 'Add-ons on every sale. A one-off set-up cost, then extra revenue.'
  };
  const ways = co => (co && W[co.type]) || [];
  const st = co => (co.sw33 = co.sw33 || { on: {}, ct: [], one: [], ref: 0, mem: 0, peak: {}, last: -99, log: [] });
  const has = (co, k) => ways(co).find(w => w[0] === k);
  const opt = (w, k, d) => (w && w[3] && w[3][k] != null ? w[3][k] : d);
  const mon = () => wMonth(S.week) + 1;
  const inPeak = (co, w) => w && opt(w, 'm', []).indexOf(mon()) >= 0;
  const Dc = co => Math.max(0.3, (BD[co.type].Dc || 1) * cityOf(co.city).dem);
  /* deals are sized to the company's real business, not to a typical one */
  const Dreal = co => Math.max(0.5, Math.min(Dc(co), Math.max((co.lastW && co.lastW.D) || 0, (co.lastW && co.lastW.units) || 0, Dc(co) * 0.15)));
  const an = s => (/^[aeiou]/i.test(s) ? 'an ' : 'a ') + s;
  const unitW = (co, n) => unitPl(String(BD[co.type].unit || 'sale').replace(/ sold$/, ''), n);
  const ratingF = co => clamp(((co.rvN || 0) >= 5 ? ratingOf(co) : 3.8) - 3, 0, 1.5) / 1.5;
  R33.ways = ways;
  function logW(co, t) { const s = st(co); s.log.unshift({ w: S.week, t }); if (s.log.length > 12) s.log.length = 12; }

  /* ---------- demand and capacity ---------- */
  const dem33 = window.demand;
  window.demand = function (co, bd) {
    const r = dem33.apply(this, arguments);
    try {
      if (!ways(co).length || co.st !== 'open' || !r || !(r.D >= 0)) return r;
      const s = st(co), D0 = r.D;
      let f = 1;
      const pl = has(co, 'platform'); if (pl && s.on.platform) f *= 1 + opt(pl, 'lift', 0.2);
      if (has(co, 'members') && s.on.members) f *= 1 + Math.min(0.2, s.mem / (Dc(co) * 6 + 1));
      const pk = has(co, 'peak'); if (inPeak(co, pk)) f *= 1 + opt(pk, 'b', 0.3);
      if (has(co, 'emergency') && s.on.emergency) f *= 1.07;
      r.D = D0 * f + (has(co, 'referral') ? s.ref : 0) + sum(s.ct, c => c.u) + sum(s.one.filter(o => o.w === S.week), o => o.u);
      r.parts = r.parts || {};
      r.parts.sales33 = D0 > 0 ? r.D / D0 : 1;
    } catch (e) { console.error(e); }
    return r;
  };
  const cap33 = window.capacity;
  window.capacity = function (co, bd) {
    const r = cap33.apply(this, arguments);
    try { const s = co.sw33, pk = has(co, 'peak'); if (s && pk && inPeak(co, pk) && s.peak[S.week] === 'temps' && r && r.cap) r.cap *= 1.25; } catch (e) { }
    return r;
  };

  /* ---------- weekly: money, members, referrals, offers ---------- */
  function weekly(co) {
    const bd = BD[co.type], s = st(co), w0 = co.lastW || {}, rev = w0.rev || 0, units = w0.units || 0, tk = ticketEff(co, bd);
    /* contracts: discount on what they buy, then run out */
    s.ct.forEach(c => { const u = Math.min(c.u, units); if (u > 0 && c.d) { const x = Math.round(u * tk * c.d); if (x > 0) { bk(co, 'rev', -x); moveCash(co, -x); } else if (x < 0) coIn(co, -x, 'rev', null); } });
    s.ct = s.ct.filter(c => { if (S.week < c.end) return true; logW(co, c.n + ' with ' + c.who + ' ended.'); note(c.n + ' with ' + c.who + ' has ended at ' + co.name + '.', 'n', co.id); return false; });
    s.one = s.one.filter(o => o.w >= S.week);
    const pl = has(co, 'platform');
    if (pl && s.on.platform && rev > 0) { const lift = opt(pl, 'lift', 0.2); payCo(co, rev * lift / (1 + lift) * opt(pl, 'fee', 0.2), 'oth', null); }
    if (has(co, 'members')) {
      if (s.on.members) { s.mem = Math.max(0, s.mem * 0.97 + units * 0.03 * (0.5 + ratingF(co))); if (rev > 0) payCo(co, rev * 0.02, 'oth', null); }
      else s.mem *= 0.85;
    }
    if (has(co, 'referral')) s.ref = s.ref * 0.75 + units * 0.05 * ratingF(co);
    if (has(co, 'emergency') && s.on.emergency) { payCo(co, KC(2500, co.country), 'wages', null); if (units > 0) coIn(co, Math.round(units * 0.07 * tk * 0.5), 'rev', null); }
    const up = has(co, 'upsell');
    if (up && s.on.upsell && rev > 0) { const x = Math.round(rev * opt(up, 'u', 0.08)); coIn(co, x, 'rev', null); payCo(co, x * 0.35, 'cogs', null); }
    /* a season of your own: ask three weeks ahead */
    const pk = has(co, 'peak');
    if (pk) {
      const ahead = wMonth(S.week + 3) + 1, ms = opt(pk, 'm', []);
      if (ms.indexOf(ahead) >= 0 && ms.indexOf(mon()) < 0 && !(s.peakY === wYear(S.week) && s.peakM === ahead)) {
        s.peakY = wYear(S.week); s.peakM = ahead;
        const wk = 4 * ms.filter(m => m >= ahead).length || 4, cost = Math.round(KC(9000, co.country) * Math.max(1, Math.sqrt(Dc(co) / 20)));
        ask(co, pk, MO[ahead] + ': ' + pk[1].toLowerCase() + ' is coming', 'Customers come in waves in ' + ms.map(m => MO[m]).join(' and ') + '. Temporary help lets you serve about a quarter more for ' + wk + ' weeks, at about ' + money(cost) + ' a week.', [{ l: 'Hire temporary help', d: '', fx: {} }, { l: 'Ride it out', d: '', fx: {} }], { k: 'peak', cost, wk }, co.lastW && co.lastW.util > 0.8 ? 0 : 1);
      }
      if (inPeak(co, pk) && s.peak[S.week] === 'temps') payCo(co, s.peakCost || 0, 'wages', null);
    }
    /* offers, contracts, tenders: now and then, more often when people know you */
    if (S.week - s.last < 6) return;
    const kinds = ways(co).filter(w => ['contract', 'tender', 'offer'].indexOf(w[0]) >= 0);
    if (!kinds.length || !chance(0.12 * (0.6 + (co.aware || 20) / 60) * (0.5 + ratingF(co)))) return;
    const w = pick(kinds), who = clientName(co, w);
    s.last = S.week;
    if (w[0] === 'contract') {
      const u = Math.max(0.2, Math.round(Dreal(co) * rng(0.08, 0.22) * 10) / 10), d = Math.round(rng(0.05, 0.15) * 100) / 100, wk = pick([13, 26, 52]);
      ask(co, w, who + ' offers ' + an(w[1].toLowerCase()), 'About ' + fmtU(co, u) + ' a week for ' + wk + ' weeks, at ' + Math.round(d * 100) + '% below your price. Worth about ' + money(u * tk * (1 - d) * wk) + ' in total.', [{ l: 'Accept', d: '', fx: {} }, { l: 'Decline', d: '', fx: {} }], { k: 'contract', who, u, d, wk }, d <= 0.12 && (!co.lastW || co.lastW.util < 0.92) ? 0 : 1);
    } else if (w[0] === 'tender') {
      const big = bd.fam === 'project' ? 1 : 0, u = big ? 0 : Math.max(0.5, Math.round(Dreal(co) * rng(0.15, 0.35) * 10) / 10), wk = big ? 0 : pick([13, 26]);
      const val = big ? Math.round(bd.ticket * ticketMult(co, bd) * rng(1.5, 3) / 1000) * 1000 : Math.round(u * tk * wk);
      ask(co, w, who + ': ' + w[1].toLowerCase(), (big ? 'A large job worth about ' + money(val) + '.' : 'About ' + fmtU(co, u) + ' a week for ' + wk + ' weeks, worth about ' + money(val) + '.') + ' Several firms will bid. The result comes in a week.', [{ l: 'Bid low (−15%)', d: 'Better odds, thinner margin', fx: {} }, { l: 'Bid at list price', d: '', fx: {} }, { l: 'Bid high (+15%)', d: 'Worse odds, fat margin', fx: {} }, { l: 'Do not bid', d: '', fx: {} }], { k: 'tender', who, u, wk, val, big }, 1);
    } else {
      const u = Math.max(1, Math.round(Dreal(co) * rng(0.1, 0.3))), when = S.week + rint(1, 3);
      ask(co, w, who + ' asks about ' + an(w[1].toLowerCase()), fmtU(co, u) + ' in the week of ' + dateStr(when) + ', about ' + money(u * tk) + '. You need room that week.', [{ l: 'Accept', d: '', fx: {} }, { l: 'Decline', d: '', fx: {} }], { k: 'offer', who, u, when }, (!co.lastW || co.lastW.util < 0.85) ? 0 : 1);
    }
  }
  const fmtU = (co, u) => (u >= 10 ? Math.round(u) : Math.round(u * 10) / 10) + ' ' + unitW(co, u);
  function clientName(co, w) {
    const k = w[2] || 'a client';
    if (/couple/.test(k)) return personName() + ' and partner';
    try { return brandCoName(CO[co.country] || CC(), /hotel|bar|festival|chain|supermarket/.test(k) ? 'venue' : 'svc'); } catch (e) { return k.charAt(0).toUpperCase() + k.slice(1); }
  }
  /* owner-run companies ask you; managers decide (def = the option a manager takes) */
  function ask(co, w, title, body, opts, data, def) {
    data.id = co.id;
    if (co.mgr && S.npcs[co.mgr]) { decide(co, data, def); return; }
    addMsg({ kind: 'ask', from: co.name, title, body, co: co.id, opts, act: 'sw33', data, exp: S.week + 2 });
  }
  function decide(co, d, idx) {
    const s = st(co), mg = co.mgr && S.npcs[co.mgr];
    if (d.k === 'contract' && idx === 0) { s.ct.push({ n: (has(co, 'contract') || [0, 'Contract'])[1], who: d.who, u: d.u, d: d.d, end: S.week + d.wk }); logW(co, (mg ? mg.name + ' signed' : 'Signed') + ' ' + an(has(co, 'contract')[1].toLowerCase()) + ' with ' + d.who + '.'); }
    if (d.k === 'offer' && idx === 0) { s.one.push({ w: d.when, u: d.u, who: d.who }); logW(co, (mg ? mg.name + ' took' : 'Took') + ' an order from ' + d.who + '.'); }
    if (d.k === 'peak') { if (idx === 0) { const ms = opt(has(co, 'peak'), 'm', []); s.peakCost = d.cost; for (let i = 3; i < 3 + d.wk + 2; i++) s.peak[S.week + i] = 'temps'; logW(co, 'Hired temporary help for the ' + has(co, 'peak')[1].toLowerCase() + '.'); } }
    if (d.k === 'tender' && idx < 3) {
      const odds = [0.55, 0.35, 0.18][idx] * (0.6 + ratingF(co) * 0.5) * clamp(window.rivalMult ? window.rivalMult(co, BD[co.type]) : 1, 0.6, 1.2), pf = [0.85, 1, 1.15][idx];
      s.tend = { w: S.week + 1, win: chance(odds), pf, d };
    }
  }
  ACTS.sw33 = (m, idx) => {
    const d = m.data || {}, co = getCo(d.id);
    if (!co || idx < 0) return true;
    decide(co, d, idx);
    return true;
  };
  function tenderResult(co) {
    const s = st(co), t = s.tend;
    if (!t || S.week < t.w) return;
    s.tend = null;
    const d = t.d, bd = BD[co.type];
    if (!t.win) { logW(co, 'Lost the ' + has(co, 'tender')[1].toLowerCase() + ' to ' + d.who + '.'); info(d.who, 'Tender lost', co.name + ' did not win. Another firm got the job.', co.id, 'bad'); return; }
    if (d.big && co.fm) {
      co.fm.jobs = co.fm.jobs || [];
      const tw = bd.tw || {};
      co.fm.jobs.push({ id: uid(), v: Math.round(d.val * t.pf), wks: Math.max(2, Math.round((tw.wks || 6) * rng(1.2, 1.8))), p: 0, cf: Math.max(0.05, ((tw.mat || 0.5) + (tw.sub || 0)) * (1 + gauss() * (tw.over || 0.1)) / t.pf), delay: 0, w0: S.week, client: d.who });
    } else s.ct.push({ n: has(co, 'tender')[1], who: d.who, u: d.u, d: 1 - t.pf, end: S.week + d.wk });
    logW(co, 'Won the ' + has(co, 'tender')[1].toLowerCase() + ' from ' + d.who + '.');
    info(d.who, 'Tender won', co.name + ' won the job, worth about ' + money(d.val * t.pf) + '.', co.id, 'good');
  }
  R7.afterWeek = R7.afterWeek || [];
  R7.afterWeek.push(() => {
    S.cos.forEach(co => {
      if (co.st !== 'open' || !ways(co).length) return;
      try { setCtx(co); tenderResult(co); weekly(co); } catch (e) { console.error(e); } finally { setCtx(null); }
    });
  });

  /* ---------- the Clients tab: your sales channels ---------- */
  ACT.sw33t = p => {
    const co = getCo(p.id);
    if (!co) return;
    const s = st(co), k = p.k;
    if (k === 'upsell' && !s.on.upsell && !s.paidUp) {
      const c = KC(12000, co.country);
      if (co.cash < c) return toast('Not enough company cash for the set-up (' + money(c) + ').', true);
      payCo(co, c, 'oth', 'Set-up: ' + has(co, 'upsell')[1].toLowerCase());
      s.paidUp = 1;
    }
    s.on[k] = !s.on[k];
    logW(co, (s.on[k] ? 'Started: ' : 'Stopped: ') + has(co, k)[1].toLowerCase() + '.');
    save();
    render();
  };
  function statusOf(co, w) {
    const s = st(co), k = w[0], bd = BD[co.type];
    if (k === 'contract') { const L = s.ct.filter(c => c.n === w[1]); return [L.length ? L.length + ' running · ' + fmtU(co, sum(L, c => c.u)) + '/wk' : 'None running', L.length ? 'grn' : '', L.map(c => esc(c.who) + ' until ' + dateStr(c.end)).join(' · ')]; }
    if (k === 'tender') { const L = s.ct.filter(c => c.n === w[1]); return [s.tend ? 'Waiting for the result' : L.length ? 'Won · running' : 'Waiting for the next one', s.tend ? 'amb' : L.length ? 'grn' : '', ''] ; }
    if (k === 'offer') { const L = s.one.filter(o => o.w >= S.week); return [L.length ? L.length + ' booked' : 'None booked', L.length ? 'grn' : '', L.map(o => esc(o.who) + ', ' + dateStr(o.w)).join(' · ')]; }
    if (k === 'referral') { const r = s.ref; return [ratingF(co) < 0.2 ? 'Too few happy customers' : r >= 0.5 ? 'About ' + fmtU(co, r) + ' a week' : 'A trickle', ratingF(co) < 0.2 ? 'red' : r >= 0.5 ? 'grn' : '', 'Better ratings, more recommendations.']; }
    if (k === 'peak') { const ms = opt(w, 'm', []); return [inPeak(co, w) ? 'On now' : 'Next: ' + MO[ms.find(m => m > mon()) || ms[0]], inPeak(co, w) ? 'amb' : '', 'Busy in ' + ms.map(m => MO[m]).join(', ') + (s.peak[S.week] === 'temps' ? ' · temps hired' : '')]; }
    const on = !!s.on[k];
    const extra = k === 'platform' ? 'About ' + Math.round(opt(w, 'lift', 0.2) * 100) + '% more customers · ' + Math.round(opt(w, 'fee', 0.2) * 100) + '% commission on them' : k === 'members' ? (on ? Math.round(s.mem) + ' members' : 'Not offered') + ' · perks cost 2% of sales' : k === 'emergency' ? 'On call ' + money(KC(2500, co.country)) + '/wk · urgent jobs pay half again' : k === 'upsell' ? 'About ' + Math.round(opt(w, 'u', 0.08) * 100) + '% extra per sale' + (s.paidUp ? '' : ' · set-up ' + money(KC(12000, co.country))) : '';
    return [on ? 'On' : 'Off', on ? 'grn' : '', extra, 1];
  }
  function salesCard(co) {
    const L = ways(co);
    if (!L.length) return '';
    const s = st(co);
    const on = L.filter(w => s.on[w[0]]).map(w => w[1]), k = co.id + ':sales33';
    const sumTxt = on.length ? on.join(', ') + ' on' : L.map(w => w[1]).slice(0, 2).join(', ') + '…';
    return '<details class="card knob30 sw33" data-k30="' + esc(k) + '"' + (ui.k30 && ui.k30[k] ? ' open' : '') + '><summary><span class="ctext"><b>Ways to sell</b><small>' + esc(sumTxt) + '</small></span><i class="chev30">›</i></summary><div class="swin33">' + L.map(w => {
      const x = statusOf(co, w);
      return '<div class="swr33"><div class="bhead"><b>' + esc(w[1]) + '</b>' + (x[3] ? '<button class="pill ' + (x[1] || '') + '" data-a="sw33t" data-p="' + P({ id: co.id, k: w[0] }) + '">' + x[0] + ' · tap to ' + (x[0] === 'On' ? 'stop' : 'start') + '</button>' : pillp(x[0], x[1])) + '</div><span class="tipt">' + esc(TXT[w[0]]) + (x[2] ? ' ' + x[2] : '') + '</span></div>';
    }).join('') + (s.log.length ? '<div class="swlog33">' + s.log.slice(0, 3).map(l => '<small>' + dateStr(l.w) + ' · ' + esc(l.t) + '</small>').join('') + '</div>' : '') + '</div></details>';
  }
  R33.salesCard = salesCard;
  const cli33 = window.CT.cli;
  window.CT.cli = function (co, bd) {
    let h = cli33.apply(this, arguments);
    try {
      const c = salesCard(co);
      if (!c) return h;
      const i = h.indexOf('<h2 class="sec">How you sell</h2>');
      return i >= 0 ? h.slice(0, i + '<h2 class="sec">How you sell</h2>'.length) + c + h.slice(i + '<h2 class="sec">How you sell</h2>'.length) : h + '<h2 class="sec">How you sell</h2>' + c;
    } catch (e) { console.error(e); return h; }
  };
})();

# round 35: menus where you look for them, a one-screen week report
path = '/home/claude/w3/ledger.html'
T = '/home/claude/w3/tools/'
t = open(path, encoding='utf8').read()
mark = '/* ===== Round 32: PC and iPad.'
assert t.count(mark) == 1, 'r32 mark'
t = t.replace(mark, open(T + 'round35.js', encoding='utf8').read() + '\n' + mark)
i = t.rindex('</style>')
t = t[:i] + open(T + 'round35.css', encoding='utf8').read() + '\n' + t[i:]
R = [
    ("['hq', 'Office', 'office']", "['hq', 'Group', 'office']", 1),
    ("['meet', 'Meetings', 'chat']", "['meet', 'Inbox', 'chat']", 1),
    ("const TABN = { home: 'Home', cos: 'Companies', hq: 'Office', phone: 'Phone', meet: 'Meetings' };", "const TABN = { home: 'Home', cos: 'Companies', hq: 'Group', phone: 'Phone', meet: 'Inbox' };", 1),
    ("V.titles.meetings = 'Meetings';", "V.titles.meetings = 'Inbox';", 1),
    ("'<header class=\"hh\"><h1>Meetings</h1>'", "'<header class=\"hh\"><h1>Inbox</h1>'", 1),
    ("['meet', 'Meet', 0]", "['meet', 'Meetings', 0]", 1),
    ("books: ['Results and balance', 'chart']", "books: ['Accounts', 'chart']", 1),
    ("value: ['Value and ownership', 'coin']", "value: ['Ownership and value', 'coin']", 2),
    ("reach: ['Brand reach', 'globe']", "reach: ['Chain and reach', 'globe']", 1),
    ("tx: ['Recent transactions', 'doc']", "tx: ['Transactions', 'doc']", 1),
]
for a, b, n in R:
    assert t.count(a) == n, (a, t.count(a))
    t = t.replace(a, b)
open(path, 'w', encoding='utf8').write(t)
print('patch22 ok')

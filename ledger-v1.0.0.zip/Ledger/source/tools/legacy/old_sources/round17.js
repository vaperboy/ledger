/* ===== Round 17: nine startup sectors built like the software startup (product, pay model, who builds it,
   test and launch), your own product as a feature in your companies once testing starts, pitching to rivals
   (friends trust you, strangers judge the product), and a price war screen without the help boxes. ===== */
{
  const P = o => esc(JSON.stringify(o));
  const pill = (t, c) => '<span class="pill ' + (c || '') + '">' + t + '</span>';
  const FDs = () => (S.founded = S.founded || []);
  const FOUNDER = () => (S.founder = S.founder || { exits: 0, fails: 0, raised: 0 });
  const ids = s => s.split(' ');
  const has = (list, bd) => ids(list).indexOf(bd.id) >= 0;
  const consumer = bd => (bd.aud || 0) < 0.6 && ['fin', 'energy', 'hold', 'club', 'rent'].indexOf(bd.fam) < 0;

  /* ---------- the nine sectors: what you can build, how it is paid for, who builds it, and what it does for your own companies ---------- */
  const CAT = {
    saas: { n: 'SaaS / Software', ck: 1, seed: 250000, work: 30, self: 1, b: 'coders', arpu: 1200, g: 1,
      prods: [['crm', 'CRM and sales'], ['book', 'Booking and scheduling'], ['acct', 'Accounting and payroll'], ['shop', 'Shop and payments'], ['job', 'Job and quoting'], ['fleet', 'Fleet and routing'], ['cad', 'Design and CAD'], ['health', 'Patient journals'], ['ticket', 'Ticketing and events'], ['erp', 'ERP and planning']],
      models: [['once', 'One-time purchase'], ['sub', 'Subscription'], ['both', 'Setup fee + subscription']] },
    fintech: { n: 'FinTech', ck: 2, seed: 1500000, work: 48, self: 1, b: 'coders', arpu: 1800, g: 0.8,
      prods: [['pay', 'Payments and card terminals'], ['bankapp', 'Banking app'], ['invest', 'Investing app'], ['ins', 'Insurance platform'], ['lend', 'Lending platform']],
      models: [['fee', 'Fee per transaction'], ['sub', 'Subscription'], ['both', 'Subscription + fees']] },
    ecom: { n: 'E-commerce', ck: 1, seed: 400000, work: 30, self: 1, b: 'coders', arpu: 900, g: 1.1,
      prods: [['store', 'Online store builder'], ['mkt', 'Marketplace for shops'], ['check', 'Checkout and shipping']],
      models: [['sub', 'Subscription'], ['fee', 'Share of each sale'], ['both', 'Subscription + share']] },
    ai: { n: 'AI / Machine Learning', ck: 2, seed: 800000, work: 40, self: 1, b: 'coders', arpu: 1500, g: 1.2,
      prods: [['code', 'AI coding assistant'], ['create', 'AI design and content'], ['agent', 'AI agents for office work'], ['auto', 'Process automation']],
      models: [['sub', 'Subscription'], ['use', 'Pay per use']] },
    health: { n: 'HealthTech', ck: 3, seed: 3000000, work: 60, self: 1, b: 'developers and clinicians', arpu: 2500, g: 0.5,
      prods: [['diag', 'Diagnostics'], ['clinic', 'Clinic software'], ['well', 'Wellness and training app'], ['tele', 'Video consultations']],
      models: [['sub', 'Subscription'], ['lic', 'Licence per clinic']] },
    edtech: { n: 'EdTech', ck: 1, seed: 300000, work: 30, self: 1, b: 'coders', arpu: 600, g: 1.1,
      prods: [['plat', 'Learning platform'], ['tutor', 'Tutoring app'], ['drive', 'Driving theory app'], ['corp', 'Staff training']],
      models: [['sub', 'Subscription'], ['once', 'One-time purchase']] },
    market: { n: 'Marketplace / Platform', ck: 2, seed: 600000, work: 38, self: 1, b: 'coders', arpu: 800, g: 1.3,
      prods: [['svc', 'Booking platform for local services'], ['ride', 'Ride and delivery app'], ['food', 'Food delivery app'], ['b2b', 'Supplier marketplace for businesses']],
      models: [['fee', 'Commission per booking'], ['sub', 'Subscription for sellers']] },
    consumer: { n: 'Consumer Apps', ck: 1, seed: 400000, work: 32, self: 1, b: 'coders', arpu: 2000, g: 2.5, users: 1,
      prods: [['social', 'Social media app'], ['ent', 'Entertainment app'], ['prod', 'Productivity app'], ['life', 'Lifestyle app']],
      models: [['ads', 'Free with ads'], ['freemium', 'Free + premium'], ['paid', 'Paid app']] },
    clean: { n: 'CleanTech / ClimateTech', ck: 4, seed: 15000000, work: 80, self: 0, b: 'engineers', arpu: 6000, g: 0.3,
      prods: [['solar', 'Solar and storage'], ['ev', 'EV charging and fleets'], ['eff', 'Energy efficiency'], ['recy', 'Recycling']],
      models: [['sale', 'Sell the hardware'], ['lease', 'Lease / service contract']] }
  };
  const CATK = Object.keys(CAT);
  const nameOf = (cat, prod) => { const c = CAT[cat]; const x = c && c.prods.find(y => y[0] === prod); return x ? x[1] : ''; };
  /* investing in other people's startups uses the same nine sectors */
  if (typeof SU_SECT !== 'undefined') { SU_SECT.length = 0; CATK.forEach(k => SU_SECT.push(CAT[k].n)); }

  /* what your own product does for one of your companies: d = more customers, k = more capacity, aw = marketing works better, c = lower running costs */
  function fxFor(cat, prod, bd) {
    if (!bd) return null;
    const F = (o, t) => Object.assign({ t }, o);
    if (cat === 'fintech') {
      if (bd.fam === 'fin') return F({ d: 0.12 }, 'Own app: easier to use, more customers');
      if (prod === 'pay' && (bd.fam === 'retail' || bd.fam === 'venue')) return F({ d: 0.03 }, 'Faster checkout');
      return null;
    }
    if (cat === 'ecom') return bd.fam === 'retail' || has('bakery brewery furniture', bd) ? F({ d: 0.08 }, 'Sells online through your platform') : null;
    if (cat === 'ai') {
      if (prod === 'code') return has('webdev', bd) ? F({ k: 0.15 }, 'Coders work faster') : null;
      if (prod === 'create') return has('mktg photo event engcons furniture', bd) ? F({ k: 0.12 }, 'Faster creative work') : null;
      if (prod === 'agent') return has('cons acctfirm law staffing estate mktg', bd) ? F({ k: 0.1 }, 'Less office work') : null;
      return bd.fam === 'prod' || bd.fam === 'logi' ? F({ k: 0.08 }, 'Automated planning') : null;
    }
    if (cat === 'health') {
      if (prod === 'well') return has('gym physio', bd) ? F({ d: 0.07 }, 'Members train in your app') : null;
      return has('physio', bd) ? F({ d: 0.05, k: 0.06 }, 'Faster patient work') : null;
    }
    if (cat === 'edtech') {
      if (prod === 'drive') return has('drivsk', bd) ? F({ d: 0.08, k: 0.05 }, 'Students pass faster') : null;
      if (prod === 'corp') return (bd.std || []).reduce((t, s) => t + s[1], 0) >= 8 ? F({ k: 0.03 }, 'Staff learn faster') : null;
      return has('tutor', bd) ? F({ k: 0.12, d: 0.04 }, 'Lessons on your own platform') : null;
    }
    if (cat === 'market') {
      if (prod === 'ride') return has('taxi courier', bd) ? F({ d: 0.1 }, 'Rides booked in your app') : null;
      if (prod === 'food') return has('restaurant foodtruck cafe bakery', bd) ? F({ d: 0.07 }, 'Orders through your delivery app') : null;
      if (prod === 'b2b') return bd.fam === 'prod' || has('hardware', bd) ? F({ d: 0.05 }, 'Business buyers find you') : null;
      return has('handy cleaning pets carclean barber photo tutor', bd) ? F({ d: 0.07 }, 'Bookings from your platform') : null;
    }
    if (cat === 'consumer') {
      if (prod === 'social') return consumer(bd) ? F({ aw: 0.3 }, 'Your own social media') : null;
      if (prod === 'ent') return bd.fam === 'venue' ? F({ aw: 0.15, d: 0.03 }, 'Promoted in your app') : null;
      if (prod === 'life') return has('gym cafe boutique barber restaurant', bd) ? F({ aw: 0.15 }, 'Featured in your app') : null;
      return bd.fam === 'svc' ? F({ k: 0.03 }, 'Staff organise better') : null;
    }
    if (cat === 'clean') {
      if (prod === 'ev') return bd.fam === 'logi' ? F({ c: 0.1 }, 'Cheaper fuel and charging') : null;
      if (prod === 'recy') return bd.fam === 'prod' ? F({ c: 0.04 }, 'Waste becomes income') : null;
      if (bd.id === 'power') return F({ d: 0.05 }, 'Your own solar tech');
      return bd.fam === 'prod' || has('hotel grocery gym', bd) ? F({ c: 0.06 }, 'Lower energy costs') : null;
    }
    return null;
  }
  const liveCos = () => S.cos.filter(c => c.st === 'open' || c.st === 'setup');
  const usable = (cat, prod) => liveCos().filter(c => fxFor(cat, prod, BD[c.type]));
  const fxTxt = x => [x.d ? '+' + Math.round(x.d * 100) + '% customers' : '', x.k ? '+' + Math.round(x.k * 100) + '% capacity' : '', x.aw ? 'marketing +' + Math.round(x.aw * 100) + '%' : '', x.c ? '−' + Math.round(x.c * 100) + '% running costs' : ''].filter(Boolean).join(' · ');

  /* the effect a company gets right now from your products it uses */
  function fxNow(co) {
    const out = { d: 0, k: 0, aw: 0, c: 0 };
    FDs().forEach(f => {
      const w = f.sw16;
      if (!w || f.st !== 'live' || (w.phase !== 'beta' && w.phase !== 'live') || (w.use || []).indexOf(co.id) < 0) return;
      if (co.gl16 && co.gl16[f.id] === S.week) return;
      const x = fxFor(w.cat, w.prod, BD[co.type]);
      if (!x) return;
      const s = (w.phase === 'live' ? 1 : 0.6) * (0.6 + (f.q || 0.5) * 0.6);
      ['d', 'k', 'aw', 'c'].forEach(k => { if (x[k]) out[k] += x[k] * s; });
    });
    return out;
  }
  const dem0 = window.demand;
  window.demand = function (co, bd) {
    const r = dem0.apply(this, arguments);
    try { if (S.founded && S.founded.length) { const x = fxNow(co); if (x.d) { r.D *= 1 + x.d; r.parts.own = 1 + x.d; } } } catch (e) { console.error(e); }
    return r;
  };
  const cap0 = window.capacity;
  window.capacity = function (co, bd) {
    const r = cap0.apply(this, arguments);
    try { if (S.founded && S.founded.length) { const x = fxNow(co); if (x.k && r && r.cap) r.cap *= 1 + x.k; } } catch (e) { console.error(e); }
    return r;
  };
  const mw0 = window.mktWeek;
  window.mktWeek = function (co, bd) {
    const a0 = co.aware;
    const r = mw0.apply(this, arguments);
    try { if (S.founded && S.founded.length && co.aware > a0) { const x = fxNow(co); if (x.aw) co.aware = clamp(a0 + (co.aware - a0) * (1 + x.aw), 0, 100); } } catch (e) { console.error(e); }
    return r;
  };
  /* your own hours spent building count against your week */
  const hu0 = window.hoursUsed;
  window.hoursUsed = function () { return hu0.apply(this, arguments) + FDs().filter(f => f.st === 'live' && f.sw16 && f.sw16.selfH).reduce((t, f) => t + f.sw16.selfH, 0); };

  /* ---------- the setup screen: same as software, for every sector ---------- */
  function interest(ck, tr) {
    const f = FOUNDER();
    const track = Math.min(0.36, f.exits * 0.12) - Math.min(0.3, f.fails * 0.06);
    const pen = (ck - 1) * 0.13 * (f.exits ? 0.4 : 1);
    return clamp(0.3 + track + tr * 0.45 - pen + (((S.econ && S.econ.dem) || 1) - 1), 0.02, 0.97);
  }
  const intWord = x => (x >= 0.7 ? 'Strong' : x >= 0.45 ? 'Some interest' : x >= 0.25 ? 'Weak' : 'Almost none');
  const CAPN = ['', 'Low', 'Medium', 'High', 'Very high', 'Huge'];
  const devCost = cat => KC(cat === 'clean' || cat === 'health' ? 75000 : 65000);
  const freeH = () => Math.min(20, Math.max(0, (R7.HCAP || 80) - window.hoursUsed()));
  function sheet() {
    const s = ui.fs = ui.fs && ui.fs.v17 ? ui.fs : { v17: 1, sec: 'saas', prod: 'crm', model: 'sub', who: 'c2', m: 1 };
    const d = CAT[s.sec];
    if (!d.prods.some(x => x[0] === s.prod)) s.prod = d.prods[0][0];
    if (!d.models.some(x => x[0] === s.model)) s.model = d.models[0][0];
    if (s.who === 'self' && !d.self) s.who = 'c2';
    const min = KC(d.seed), devs = s.who === 'c4' ? 4 : s.who === 'c2' ? 2 : 0, self = s.who === 'self' ? freeH() : 0;
    const speed = devs + self / 40 * 0.7, wk = speed > 0 ? Math.ceil(d.work / speed) : 99;
    const use = usable(s.sec, s.prod);
    const who = [['self', 'Myself · ' + freeH() + ' h/wk'], ['c2', '2 ' + d.b], ['c4', '4 ' + d.b]].filter(x => x[0] !== 'self' || d.self);
    const tile = (k, v) => '<div><span>' + k + '</span><b>' + v + '</b></div>';
    const useTxt = s.sec === 'saas' ? 'Via the shop' : use.length ? esc(use.slice(0, 2).map(c => c.name).join(', ')) + (use.length > 2 ? ' +' + (use.length - 2) : '') : 'None yet';
    const runway = Math.round(min * s.m / (min / 26 + devs * devCost(s.sec) * 12 / 52));
    return '<h2>Found a startup</h2>' + U.inp('fname', 'Startup name', null, 'text') +
      '<div class="two f41"><div><div class="lab">Sector</div>' + U.ddown(CATK.map(k => [k, CAT[k].n]), s.sec, 'f17sec') + '</div><div><div class="lab">What it does</div>' + U.ddown(d.prods, s.prod, 'f17prod') + '</div></div>' +
      '<div class="lab">How customers pay</div>' + chips(d.models, s.model, 'f17model') +
      '<div class="lab">Who builds it</div>' + chips(who, s.who, 'f17who') +
      '<div class="tri">' + tile('Ready to test', wk >= 99 ? '—' : Math.ceil(wk / 2) + ' wk') + tile('Ready to sell', wk >= 99 ? '—' : wk + ' wk') + tile(devs ? capF(d.b) + ' /mo' : 'Builders', devs ? mshort(devs * devCost(s.sec)) : 'You') + tile('Capital need', CAPN[d.ck]) + tile('Investors', intWord(interest(d.ck, 0.05))) + tile('Runway', runway + ' wk') + '</div>' +
      row('Your companies that can use it', useTxt) +
      '<div class="lab">Your seed money</div>' + chips([[1, mshort(min)], [2, mshort(min * 2)], [4, mshort(min * 4)]], s.m, 'f17seed') +
      '<div class="btnrow">' + btn('Cancel', 'sheetclose', undefined, 'ghost') + btn('Found it', 'f17go', undefined, 'primary') + '</div>';
  }
  const capF = t => t.charAt(0).toUpperCase() + t.slice(1);
  ACT.found = () => openSheet(sheet());
  ['sec', 'prod', 'model', 'who', 'seed'].forEach(k => { ACT['f17' + k] = p => { ui.fs[k === 'seed' ? 'm' : k] = k === 'seed' ? +p.v : p.v; openSheet(sheet()); }; });
  const swPrice = m => (m === 'once' ? KC(15000) : m === 'sub' ? KC(1200) : KC(800));
  ACT.f17go = () => {
    const s = ui.fs, d = CAT[s.sec], seed = KC(d.seed) * s.m;
    if (liquid() < seed) { toast('You need ' + money(seed) + '.', true); return; }
    if (S.cash < seed) { const r = seed - Math.max(0, S.cash); S.sav.bal -= r; moveCash(ME, r); }
    moveCash(ME, -seed);
    logTx(0, -seed, 'Founded a startup');
    const F = FOUNDER();
    const nm = (ui.inp.fname || '').trim() || coinName(CC()) + pick(['ly', ' Labs', 'io', ' Tech']);
    const devs = s.who === 'c4' ? 4 : s.who === 'c2' ? 2 : 0, selfH = s.who === 'self' ? freeH() : 0;
    const f = { id: uid(), name: nm, sec: s.sec, secn: nameOf(s.sec, s.prod), ck: d.ck, stage: 0, pct: 100, val: seed * 1.2, cash: seed, burn: seed / (26 * s.m) + devs * devCost(s.sec) * 12 / 52, in: seed, q: clamp(rng(0.25, 0.7) + F.exits * 0.05 - F.fails * 0.02, 0.1, 0.92), tr: 0.05, w0: S.week, wNext: S.week + rint(20, 34), st: 'live', offers: [] };
    if (s.sec === 'saas') f.sw = { type: s.prod, model: s.model, devs, selfH, prog: 0, phase: 'build', cust: 0, price: swPrice(s.model), revW: 0, int: 50 };
    else f.sw16 = { cat: s.sec, prod: s.prod, model: s.model, devs, selfH, prog: 0, phase: 'build', cust: 0, revW: 0, int: 0, use: [], deals: [] };
    FDs().push(f);
    ui.sheet = null;
    ui.inp.fname = '';
    ui.stab = 'found';
    save();
    render(true);
    toast(nm + ' is founded.');
  };

  /* ---------- building, testing, selling, and the bill your own companies pay ---------- */
  function weekly() {
    FDs().forEach(f => {
      const w = f.sw16;
      if (!w) return;
      if (f.st !== 'live') { w.use = []; return; }
      const d = CAT[w.cat];
      const speed = w.devs + w.selfH / 40 * 0.7 * (R7.ownerFactor ? R7.ownerFactor() : 1);
      if (w.phase !== 'live') {
        w.prog = Math.min(1, w.prog + speed / d.work * (0.7 + f.q * 0.6));
        if (w.phase === 'build' && w.prog >= 0.5) { w.phase = 'beta'; note(f.name + ' is ready to test. You can switch it on in your own companies.', 'good'); }
        if (w.prog >= 1) { w.phase = 'live'; note(f.name + ' is launched.', 'good'); news(f.name + ' launches.', 'good'); }
      }
      let rev = 0;
      const arpu = KC(d.arpu);
      if (w.phase === 'live') {
        const nc = Math.max(0, Math.round((f.q * 2.2 + f.tr * 3 + w.devs * 0.3) * d.g * (1 + w.cust / 250) * rng(0.2, 1.3)));
        w.cust = Math.round(w.cust * (1 - 0.005 - (1 - f.q) * 0.02)) + nc;
        const one = ['once', 'sale', 'lic'].indexOf(w.model) >= 0;
        rev = one ? nc * arpu * 8 : w.cust * arpu * 12 / 52 * (w.model === 'both' ? 1.15 : 1);
        f.tr = clamp(f.tr + Math.min(0.01, rev / Math.max(1, f.burn) * 0.004), 0, 1);
      } else if (w.phase === 'beta') w.cust = Math.max(w.cust, 2 + Math.floor(w.prog * 8));
      /* your companies pay the internal price */
      (w.use || []).forEach(id => {
        const co = getCo(id);
        if (!co || co.st !== 'open') return;
        if (w.phase === 'beta' && chance(0.1)) { co.gl16 = co.gl16 || {}; co.gl16[f.id] = S.week + 1; note(f.name + ' (test version) failed at ' + co.name + ' this week.', 'bad', co.id); }
        const fee = Math.round(arpu * w.int / 100 * 12 / 52);
        if (fee > 0) { payCo(co, fee, 'oth', 'Own product: ' + f.name); rev += fee; }
        const x = fxFor(w.cat, w.prod, BD[co.type]);
        if (x && x.c) addMod(co, 'cogsup', 1 - x.c * (w.phase === 'live' ? 1 : 0.6) * (0.6 + f.q * 0.6), 2);
      });
      w.revW = Math.round(rev);
      f.cash += rev;
      if (rev > 0) f.val = Math.max(f.val, rev * 52 * 3);
      /* a friend who bought a poor product out of trust may regret it */
      (w.deals || []).forEach(x => {
        if (x.chk && S.week >= x.chk) {
          x.chk = 0;
          const r = findRival(x.rid);
          if (r && chance(0.6)) { r.rel = Math.max(0, r.rel - 12); w.cust = Math.max(0, w.cust - x.n); note(r.name + ' dropped ' + f.name + ': it did not work well for them. They are less friendly now.', 'bad'); }
        }
      });
    });
    /* SaaS keeps its own weekly engine from before; only its rival deals need checking here */
    FDs().forEach(f => (f.sw && f.sw.deals16 || []).forEach(x => {
      if (x.chk && S.week >= x.chk) { x.chk = 0; const r = findRival(x.rid); if (r && chance(0.6)) { r.rel = Math.max(0, r.rel - 12); f.sw.cust = Math.max(0, f.sw.cust - x.n); note(r.name + ' dropped ' + f.name + ': it did not work well for them.', 'bad'); } }
    }));
  }
  R7.afterWeek = R7.afterWeek || [];
  R7.afterWeek.push(() => { try { weekly(); } catch (e) { console.error(e); } });

  /* ---------- pitching to rivals: trust comes from the relationship, strangers judge the product ---------- */
  function findRival(id) { for (const k in S.mk || {}) { const r = (S.mk[k].riv || []).find(x => x.id === id); if (r) return r; } return null; }
  const prodOf = f => (f.sw16 ? { cat: f.sw16.cat, prod: f.sw16.prod, w: f.sw16 } : f.sw ? { cat: 'saas', prod: f.sw.type, w: f.sw } : null);
  const ready = f => { const p = prodOf(f); return f.st === 'live' && p && (p.w.phase === 'beta' || p.w.phase === 'live'); };
  function targets(f) {
    const p = prodOf(f), seen = {}, L = [];
    S.cos.filter(c => c.st === 'open' && BD[c.type].Dc).forEach(c => {
      const bd = BD[c.type];
      if (p.cat !== 'saas' && !fxFor(p.cat, p.prod, bd)) return;
      if (p.cat === 'saas' && ['hold', 'club'].indexOf(bd.fam) >= 0) return;
      rivalsOf(c).forEach(r => { if (!seen[r.id]) { seen[r.id] = 1; L.push({ r, co: c }); } });
    });
    return L.sort((a, b) => b.r.rel - a.r.rel).slice(0, 10);
  }
  const trustOf = r => clamp((r.rel - 45) / 45, 0, 1);
  function pitchOdds(f, r) {
    const p = prodOf(f), t = trustOf(r);
    return t * 0.92 + (1 - t) * clamp(f.q * 0.85 - 0.12 - (p.w.phase === 'beta' ? 0.15 : 0), 0.03, 0.85);
  }
  ACT.p17open = p => {
    const f = FDs().find(x => x.id === p.id);
    if (!f || !ready(f)) return;
    const L = targets(f);
    openSheet('<h2>Pitch ' + esc(f.name) + '</h2>' + (L.length ? '<div class="lrows">' + L.map(x => {
      const wait = x.r.p17 && x.r.p17[f.id] && S.week - x.r.p17[f.id] < 8 ? 8 - (S.week - x.r.p17[f.id]) : 0;
      const done = (prodOf(f).w.deals || prodOf(f).w.deals16 || []).some(d => d.rid === x.r.id);
      return '<div class="lrow">' + av(ini(x.r.name)) + '<span class="ctext"><b>' + esc(x.r.name) + '</b><small>' + esc(x.r.owner || '') + ' · ' + esc(relWord(x.r.rel)) + '</small></span>' + (done ? pill('Customer', 'grn') : wait ? pill(wait + ' wk', '') : btn('Pitch', 'p17go', { id: f.id, r: x.r.id }, 'chip primary')) + '</div>';
    }).join('') + '</div>' : '<div class="calm">None of your companies has rivals who could use it.</div>') + btn('Close', 'sheetclose', undefined, 'ghost wide'));
  };
  ACT.p17go = p => {
    const f = FDs().find(x => x.id === p.id), r = findRival(p.r);
    if (!f || !r || !ready(f)) return;
    r.p17 = r.p17 || {};
    r.p17[f.id] = S.week;
    const pr = prodOf(f), w = pr.w, t = trustOf(r);
    if (chance(pitchOdds(f, r))) {
      const n = Math.max(1, Math.round(1 + (r.size || 1) * 3));
      w.cust += n;
      r.rel = Math.min(100, r.rel + 3);
      const deal = { rid: r.id, n, w: S.week, chk: t > 0.6 && f.q < 0.45 ? S.week + rint(6, 10) : 0 };
      if (f.sw16) (w.deals = w.deals || []).push(deal); else (w.deals16 = w.deals16 || []).push(deal);
      toast(r.name + ' signs up for ' + f.name + '.');
      info(r.owner || r.name, r.name + ' buys ' + f.name, t > 0.6 ? '"I trust you. If you built it, we will use it."' : '"We tried it and it does what we need. Count us in."', 0, 'good');
    } else {
      if (t < 0.3 && chance(0.3)) r.rel = Math.max(0, r.rel - 2);
      toast(r.name + ' said no' + (t > 0.6 ? ', for now.' : '. They were not convinced.'), true);
    }
    save();
    ACT.p17open({ id: f.id });
  };

  /* ---------- the startups tab: product cards for every sector, switching it on in your companies ---------- */
  function card17(f) {
    const w = f.sw16, d = CAT[w.cat], use = usable(w.cat, w.prod);
    const used = (w.use || []).filter(id => getCo(id));
    let h = '<div class="card"><div class="cchd">' + (window.pic ? pic('soft', f.id) : av(ini(f.name))) + '<span class="ctext"><b>' + esc(f.name) + '</b><small>' + esc(d.n) + ' · ' + esc(nameOf(w.cat, w.prod)) + '</small></span>' + pill(w.phase === 'build' ? 'Building' : w.phase === 'beta' ? 'Testing' : 'On sale', w.phase === 'live' ? 'grn' : 'amb') + '</div>';
    if (w.phase !== 'live') h += '<div class="kv"><span>Progress</span><b>' + Math.round(w.prog * 100) + '%</b></div>' + bar(w.prog * 100, 'var(--blue)');
    h += '<div class="tri"><div><span>' + (d.users ? 'Users' : 'Customers') + '</span><b>' + (d.users ? Math.round(w.cust * 1000).toLocaleString('en-US').replace(/,/g, ' ') : w.cust) + '</b></div><div><span>Revenue / wk</span><b>' + mshort(w.revW || 0) + '</b></div><div><span>Your companies</span><b>' + used.length + '</b></div></div>';
    h += '<div class="t17row"><span>' + w.devs + ' ' + esc(d.b) + (w.selfH ? ' + you ' + w.selfH + ' h' : '') + '</span>' + btn('＋', 'w17dev', { id: f.id, d: 1 }, 'chip') + btn('−', 'w17dev', { id: f.id, d: -1 }, 'chip') + (d.self && (w.selfH || freeH() >= 5) ? btn(w.selfH ? 'Stop me' : 'Me ' + freeH() + ' h', 'w17self', { id: f.id }, 'chip') : '') + '</div>';
    if (use.length) {
      h += '<div class="lrows t17use">' + use.map(c => {
        const x = fxFor(w.cat, w.prod, BD[c.type]), on = (w.use || []).indexOf(c.id) >= 0;
        return '<div class="lrow"><span class="ctext"><b>' + esc(c.name) + '</b><small>' + esc(x.t) + ' · ' + fxTxt(x) + (w.phase === 'beta' ? ' · test version' : '') + '</small></span>' + (w.phase === 'build' ? pill('Not ready') : btn(on ? 'Stop' : 'Use', 'w17use', { id: f.id, c: c.id }, on ? 'chip ghost' : 'chip primary')) + '</div>';
      }).join('') + '</div>';
      h += '<div class="t17row"><span>Your companies pay</span>' + U.ddown([[0, 'Free'], [25, '25% of price'], [50, '50% of price'], [100, 'Full price']], w.int, 'w17int', { id: f.id }) + '</div>';
    }
    if (ready(f)) h += btn('Pitch to rivals', 'p17open', { id: f.id }, 'wide');
    return h + '</div>';
  }
  const st0 = V.startups;
  V.startups = function () {
    let h = st0.apply(this, arguments);
    if ((ui.stab || 'deals') !== 'found') return h;
    const L = FDs().filter(f => f.st === 'live' && f.sw16);
    if (L.length) h += '<h2 class="sec">Products you are building</h2>' + L.map(card17).join('');
    const sw = FDs().filter(f => f.sw && ready(f));
    if (sw.length) h += '<h2 class="sec">Sell your software to rivals</h2><div class="lrows">' + sw.map(f => '<button class="lrow" data-a="p17open" data-p="' + P({ id: f.id }) + '"><span class="ctext"><b>' + esc(f.name) + '</b><small>' + (f.sw.cust || 0) + ' customers</small></span><i>›</i></button>').join('') + '</div>';
    return h;
  };
  ACT.w17dev = p => { const f = FDs().find(x => x.id === p.id), w = f && f.sw16; if (!w) return; const n = Math.max(0, Math.min(10, w.devs + p.d)); f.burn += (n - w.devs) * devCost(w.cat) * 12 / 52; w.devs = n; save(); render(); };
  ACT.w17self = p => {
    const f = FDs().find(x => x.id === p.id), w = f && f.sw16;
    if (!w) return;
    if (w.selfH) w.selfH = 0;
    else { const left = (R7.HCAP || 80) - window.hoursUsed(); if (left < 5) { toast('You have no hours left this week.', true); return; } w.selfH = Math.min(20, left); }
    save();
    render();
  };
  ACT.w17use = p => {
    const f = FDs().find(x => x.id === p.id), w = f && f.sw16;
    if (!w || w.phase === 'build') return;
    w.use = w.use || [];
    const i = w.use.indexOf(p.c);
    if (i >= 0) w.use.splice(i, 1); else w.use.push(p.c);
    save();
    render();
    const co = getCo(p.c);
    toast(i >= 0 ? co.name + ' stopped using ' + f.name + '.' : co.name + ' now uses ' + f.name + '.');
  };
  ACT.w17int = p => { const f = FDs().find(x => x.id === p.id); if (f && f.sw16) f.sw16.int = +p.v; save(); render(); };

  /* ---------- price war: no help boxes ---------- */
  const pw0 = V.pricewar;
  V.pricewar = function (p) {
    let h = pw0.apply(this, arguments);
    h = h.replace(/<div class="card sense"><b>[^<]*<\/b><span class="tipt">[^<]*<\/span><\/div>/g, '');
    h = h.replace(/<div class="card"><div class="bhead"><b>How it works<\/b><\/div>(?:<div class="step"><i>\d+<\/i><div>[^<]*<\/div><\/div>)+<\/div>/, '');
    h = h.replace(/<p class="muted small">These are feelings, not numbers\.[^<]*<\/p>/, '');
    h = h.replace(/<span class="tipt">Your prices stay at rock bottom[^<]*<\/span>/, '');
    return h;
  };
}

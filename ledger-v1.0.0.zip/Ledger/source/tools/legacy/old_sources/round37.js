/* ===== Round 37: a newcomer nobody has heard of, premises that match the company, and everything on one line.
   - Chains: the chain screens no longer open stores; a new store is started from New company like any company.
   - Expand: the "More sites" box is gone (another site is simply a new company).
   - Rivals only know you once you take a real share of their market or cross them (round 27a/28b/31 sources).
   - People you know: relationship words on the 0-100 scale where 40 is a plain acquaintance (round 31 source).
   - Pop-ups and message cards show their whole title.
   - Companies that start at home can rent or buy an office; a team of four or more outgrows the kitchen table.
   - The overview picture follows the real premises (round 28a source).
   - Decision limits and other choice rows fit on one line. ===== */
window.R37 = window.R37 || {};
(function () {
  'use strict';
  const R37 = window.R37;
  const U = window.UI;
  if (!U) return;
  const { ui, V, ACT, esc, row, btn, card, go, render, save, svg, openSheet, closeSheet, toast } = U;
  const CT = window.CT;
  const P = o => esc(JSON.stringify(o));
  const live = () => S.cos.filter(c => c.st !== 'sold' && c.st !== 'bust');
  const rowBtn = (a, p, ic, title, sub, right) => '<button class="lrow" data-a="' + a + '" data-p="' + P(p) + '"><span class="lic">' + svg(ic, 20) + '</span><span class="ctext"><b>' + title + '</b>' + (sub ? '<small>' + esc(sub) + '</small>' : '') + '</span>' + (right || '<i>›</i>') + '</button>';
  const dropNewStore = h => String(h || '').replace(/<button[^>]*data-a="ch12new"[^>]*>[^<]*<\/button>/g, '').replace(/<div class="two"><\/div>/g, '');

  /* ================= chains: new stores come from New company ================= */
  if (CT.sites) CT.sites = function () { return ''; };
  if (window.R12 && R12.growX) { const gx = R12.growX; R12.growX = function () { return dropNewStore(gx.apply(this, arguments)); }; }
  const ch37 = V.chain12;
  if (ch37) V.chain12 = function () { const h = dropNewStore(ch37.apply(this, arguments)); return h; };
  const nb37 = V.newbiz;
  if (nb37) V.newbiz = function () {
    let h = nb37.apply(this, arguments);
    try {
      const CH = (S.chains || []).filter(ch => window.R12 && R12.storesOf && R12.storesOf(ch).length);
      if (!CH.length || !ACT.ch12new) return h;
      const rows = '<h2 class="sec">A new store in your chain</h2><div class="lrows">' + CH.map(ch => rowBtn('ch12new', { id: ch.id }, 'biz', esc(ch.name), R12.storesOf(ch).length + ' stores · same name, rules and paperwork')).join('') + '</div>';
      const i = h.indexOf('<h2 class="sec">Start from scratch</h2>');
      return i >= 0 ? h.slice(0, i) + rows + h.slice(i) : h + rows;
    } catch (e) { return h; }
  };

  /* ================= rivals you have never met ================= */
  if (typeof relLabel === 'function') {
    const rl0 = relLabel;
    relLabel = function (r) {
      try { if (window.R31 && R31.known && r && r.owner && !R31.known(r)) return 'Never met'; } catch (e) { }
      return rl0.apply(this, arguments);
    };
  }

  /* ================= an office for companies that start at home ================= */
  const homeTrade = co => !!(co && BD[co.type] && BD[co.type].prem && BD[co.type].prem[0] === 'home');
  const heads = co => (co.staff || []).length + (co.mgr ? 1 : 0) + (!co.mgr && (co.ohrs || 0) > 0 ? 1 : 0);
  /* round 45: a trade that started at home moves into its natural kind of place (a workshop for a plumber, an office for an agency) */
  const baseKind = co => { const b = BD[co.type]; return b && b.prem45 ? b.prem45[0] : 'office'; };
  const placeW = co => ({ office: 'office', industrial: 'workshop', warehouse: 'warehouse', retail: 'shop', clinic: 'clinic' }[baseKind(co)] || 'place');
  R37.placeW = placeW;
  const offM2 = co => { const b = BD[co.type]; const o = Math.max(20, Math.round(Math.max(3, heads(co) + 1) * 9 / 5) * 5); return b && b.prem45 && b.prem45[0] !== 'office' ? Math.max(o, Math.round(b.prem45[1] * Math.max(0.3, Math.min(1, (co.size || 1))) * 0.6 / 5) * 5) : o; };
  const atHome = co => homeTrade(co) && !(co.prem && co.prem.m2);
  R37.atHome = atHome;
  function asOffice(co, f) {
    const bd = BD[co.type], old = bd.prem;
    bd.prem = [baseKind(co), offM2(co)];
    try { return f(); } finally { bd.prem = old; }
  }
  /* listings for an office, kept apart from the home trade's own (empty) list */
  if (typeof premListings === 'function') {
    const pl0 = premListings;
    premListings = function (co) {
      const bd = co && BD[co.type];
      if (!bd || !homeTrade(co)) return pl0.apply(this, arguments);
      const want = offM2(co), key = S.seed + ':pl37:' + co.type + ':' + co.city + ':' + want + ':' + Math.floor(S.week / 26);
      if (_catMemo[key]) return _catMemo[key];
      const R = hrng(key), C = CO[co.country || S.country] || CC();
      const L = PL_TIERS.map((t, i) => ({ i, n: PL_TIERS_B[i], m2: Math.max(15, Math.round(want * t[1] * (0.92 + R() * 0.16) / 5) * 5), rentF: t[2] * (0.94 + R() * 0.12), loc: t[3], landlord: C.nameA[Math.floor(R() * C.nameA.length)] + ' ' + PL_WORDS[Math.floor(R() * PL_WORDS.length)] }));
      _catMemo[key] = L;
      return L;
    };
  }
  const ps37 = ACT.premsheet, pset37 = ACT.premset;
  if (ps37) ACT.premsheet = p => { const co = getCo(p && p.id); return homeTrade(co) ? asOffice(co, () => ps37(p)) : ps37(p); };
  if (pset37) ACT.premset = p => { const co = getCo(p && p.id); if (homeTrade(co)) co.off37 = Date.now(); return homeTrade(co) ? asOffice(co, () => pset37(p)) : pset37(p); };
  /* a home trade that signs for space gets an office, also when the move is confirmed later */
  if (typeof setPrem === 'function') {
    const sp0 = setPrem;
    setPrem = function (co, kind, m2, buy, lst) {
      if (homeTrade(co) && kind === 'home' && m2 > 0 && co.off37 && Date.now() - co.off37 < 6e5) { kind = baseKind(co); delete co.off37; }
      return sp0.call(this, co, kind, m2, buy, lst);
    };
  }
  ACT.home37 = p => {
    const co = getCo(p.id);
    if (!co) return;
    U.confirmThen('Give up the ' + placeW(co) + '?', 'Everyone works from home again. ' + (co.prem && co.prem.owned ? 'The building is sold at today’s value and the mortgage paid off.' : 'The deposit comes back.'), 'Move home', () => {
      try {
        if (co.prem && co.prem.owned) {
          const l = S.loans.find(x => x.id === co.prem.loan);
          const val = co.prem.val || 0, debt = l ? l.bal : 0;
          if (l) S.loans.splice(S.loans.indexOf(l), 1);
          coIn(co, Math.max(0, val - debt), null, 'Office sold');
          if (debt > val) payCo(co, debt - val, null, 'Mortgage shortfall');
        }
        setPrem(co, 'home', 0, false);
        save(); render(true);
      } catch (e) { console.error(e); }
    });
  };
  /* the Premises tab: a home company can move into an office, and back */
  const eq37 = CT.eq;
  if (eq37) CT.eq = function (co, bd) {
    let h = eq37.apply(this, arguments);
    try {
      if (!homeTrade(co) || (ui.eqt || 'need') !== 'place') return h;
      const n = heads(co), big = n >= 4;
      const W = placeW(co), perk = window.R45 && R45.perks ? R45.perks(co) : 'Clients take you more seriously.';
      let x = '<div class="card"><div class="bhead"><b>' + (atHome(co) ? 'A ' + W + ' of your own' : 'Your ' + W) + '</b>' + (atHome(co) && big ? '<span class="pill red">Outgrown</span>' : '') + '</div>';
      if (atHome(co)) x += '<span class="tipt">' + (big ? n + ' people working out of your home: morale and quality slip every week. ' : 'Working from home costs nothing, but nobody else can work there: to hire anyone you need a place. From home, people only hear of you from happy customers. ') + 'A ' + W + ' of about ' + offM2(co) + ' m²: ' + perk + '</span>' + btn('Find a ' + W, 'premsheet', { id: co.id }, 'primary wide');
      else x += row('Room for', Math.floor(co.prem.m2 / 9) + ' people · you have ' + n) + btn('Move or buy another ' + W, 'premsheet', { id: co.id }, 'wide') + btn('Move back home', 'home37', { id: co.id }, 'ghost wide');
      return h + x + '</div>';
    } catch (e) { console.error(e); return h; }
  };
  /* a big team at home: morale and quality slip, clients notice */
  R7.afterWeek = R7.afterWeek || [];
  R7.afterWeek.push(() => {
    try {
      live().filter(c => c.st === 'open' && atHome(c) && heads(c) >= 4).forEach(c => {
        const k = heads(c) >= 6 ? 2 : 1;
        c.mood = Math.max(25, (c.mood != null ? c.mood : 60) - k);
        c.q = Math.max(35, (c.q != null ? c.q : 50) - 0.3 * k);
      });
    } catch (e) { console.error(e); }
  });
  const al37 = window.coAlerts;
  window.coAlerts = function (co) {
    const out = al37.apply(this, arguments);
    try { if (co && co.st === 'open' && atHome(co) && heads(co) >= 4) out.push(['Outgrown the home office', heads(co) >= 6 ? 'bad' : 'warn']); } catch (e) { }
    return out;
  };
  ACT.office37 = p => { ui.eqt = 'place'; go('co', { id: p.id, t: 'ops', s: 'assets' }); };
  /* a route can ask for a tab inside the equipment page once */
  const co37 = V.co;
  V.co = function (p) { if (p && p.eqt && !p.eq37) { ui.eqt = p.eqt; p.eq37 = 1; } return co37.apply(this, arguments); };

  /* ================= one line: rows of choices that would wrap are reshaped after each render ================= */
  function fitChips() {
    document.querySelectorAll('.chips:not(.pct37):not(.grid37):not(.col37)').forEach(c => {
      const k = [...c.children].filter(x => x.tagName === 'BUTTON');
      if (k.length < 2 || !c.offsetParent || c.closest('.sheet.plan') || c.closest('.ichat') || getComputedStyle(c).display === 'grid') return;
      const wraps = () => new Set(k.map(x => Math.round(x.getBoundingClientRect().top / 6))).size > 1;
      if (!wraps()) return;
      if (k.every(x => /^\d+% · /.test(x.textContent.trim()))) {
        k.forEach(x => { const m = /^(\d+%) · (.*)$/.exec(x.textContent.trim()); x.innerHTML = '<b>' + esc(m[1]) + '</b><small>' + esc(m[2]) + '</small>'; });
        c.classList.add('pct37');
        return;
      }
      /* short labels: an even grid, one row if it fits, otherwise rows of three; long labels: one per line */
      const short = k.every(x => x.textContent.trim().length <= 12);
      if (short || k.length <= 4) {
        c.classList.add('grid37'); c.style.setProperty('--n37', Math.min(k.length, 5));
        if (!k.some(x => x.scrollWidth > x.clientWidth + 1)) return;
        if (short && k.length > 3) { c.style.setProperty('--n37', 3); if (!k.some(x => x.scrollWidth > x.clientWidth + 1)) return; }
        c.classList.remove('grid37');
      }
      c.classList.add('col37');
    });
  }
  R37.fitChips = fitChips;
  let fitQ = 0;
  new MutationObserver(() => { if (fitQ) return; fitQ = 1; requestAnimationFrame(() => { fitQ = 0; try { fitChips(); } catch (e) { } }); }).observe(document.body, { childList: true, subtree: true });
  document.addEventListener('toggle', () => requestAnimationFrame(() => { try { fitChips(); } catch (e) { } }), true);

  /* ================= one line: the decision limit ================= */
  const grp37 = V.group;
  if (grp37) V.group = function () {
    let h = grp37.apply(this, arguments);
    try {
      const i = h.indexOf('<h3>How decisions flow</h3>');
      if (i < 0) return h;
      const s = h.lastIndexOf('<div class="card', i), e = R30.blockEnd(h, s), G = S.group;
      const lab = v => mshort(v);
      const box = '<div class="card dec37"><div class="bhead"><b>Deals that come to you</b><small>above ' + esc(lab(G.big)) + '</small></div>' + U.chips([1000000, 5000000, 20000000, 100000000].map(niceAmt).map(v => [v, lab(v)]), G.big, 'setbig') + '<span class="tipt">Manager → regional → CEO → you.</span></div>';
      return h.slice(0, s) + box + h.slice(e);
    } catch (e) { console.error(e); return h; }
  };
})();

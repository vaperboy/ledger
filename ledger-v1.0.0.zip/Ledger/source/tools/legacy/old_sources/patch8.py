import re
path = '/home/claude/w3/ledger.html'
T = '/home/claude/w3/tools/'
t = open(path, encoding='utf8').read()
def rep(old, new, count=1):
    global t
    n = t.count(old)
    if n != count: raise SystemExit('MATCH %d (want %d): %s' % (n, count, old[:110]))
    t = t.replace(old, new)
rep("""  function dealPart(co, bd, k) {""", """  function dealPart(co, bd, k) {
    if (window.R7DEAL && window.R7DEAL[k]) { const r7 = window.R7DEAL[k](co, bd); if (r7 != null) return r7; }""")
# prices and choices live in the Clients tab now; maintenance lives in Equipment
rep("""      prices: bd.fam !== 'club',
      time: 0,
      upkeep: bd.fam !== 'club',
      choices: bd.knobs.length > 0,""", """      prices: 0,
      time: 0,
      upkeep: bd.fam !== 'club' && !!(bd.tw.stock || bd.fam === 'retail' || bd.fam === 'prod'),
      choices: 0,""")
rep("""      h += card('<h3>Maintenance policy</h3>' + chips([[0, 'Minimal'], [1, 'Normal'], [2, 'Thorough']], co.maint, 'maint', { id: co.id }) + '<p class="muted small">Better maintenance costs more but reduces breakdowns and keeps quality up.</p>');
""", "")
rep("""    if (k === 'upkeep') return 'Maintenance ' + OPS_ST[co.maint].toLowerCase() + (bd.tw.stock || bd.fam === 'retail' || bd.fam === 'prod' ? ' · stock ' + OPS_SK[co.stockPol].toLowerCase() : '');""",
    """    if (k === 'upkeep') return 'Stock ' + OPS_SK[co.stockPol].toLowerCase();""")
rep("""    upkeep: ['Maintenance and stock', 'tool'],""", """    upkeep: ['Stock', 'tool'],""")
# you in the staff tab: pay yourself, your hours, an assistant
old = re.search(r"    h \+= '<div class=\"lrow solo\"><span class=\"av\">' \+ esc\(ini2\(S\.player && S\.player\.name\)\) \+ '</span><span class=\"ctext\"><b>You \(owner\)</b><small>' \+ \(m \? 'Sees every number, decides big things' : 'Runs it day to day · ' \+ co\.ohrs \+ ' h a week'\) \+ '</small></span></div>';", t).group(0)
rep(old, """    h += '<button class="lrow solo" data-a="go" data-p="' + esc(JSON.stringify({ n: 'payself', p: { id: co.id } })) + '"><span class="av">' + esc(ini2(S.player && S.player.name)) + '</span><span class="ctext"><b>You (owner)</b><small>' + (m ? 'Sees every number, decides big things' : 'Runs it day to day · ' + co.ohrs + ' h a week') + ' · pay yourself</small></span><i>›</i></button>' + (window.asstRow ? window.asstRow(co) : '');""")
rep("""if (!co.mgr) h += card('<h3>Your time here</h3>'""", """if (!co.mgr) h += window.ownerHoursRow ? window.ownerHoursRow(co) : card('<h3>Your time here</h3>'""")
# money chips end on round local numbers
for a in ["[0, 3000, 8000, 15000, 30000].map(v => [v, v ? mshort(v) : 'None'])", "[0, 20000, 40000, 60000, 80000].map(v => [v, v ? mshort(v) : 'None'])", "[50000, 150000, 300000].map(v => [v, mshort(v)])", "[1000000, 5000000, 20000000, 100000000].map(v => [v, mshort(v)])", "[100000, 500000, 2000000, 10000000].map(v => [v, mshort(v)])", "[50000, 250000, 1000000].map(v => [v, mshort(v)])"]:
    n = t.count(a)
    if n < 1: raise SystemExit('chip list missing: ' + a)
    t = t.replace(a, a.replace('].map(v =>', '].map(niceAmt).map(v =>', 1))
js = ''.join(open(T + f, encoding='utf8').read() + '\n' for f in ['round7a.js', 'round7b.js', 'round8.js', 'round9.js'])
mark = '/* ---------- no zooming: pinch, double tap, ctrl+wheel, ctrl +/- ---------- */'
rep(mark, js + mark)
css = open(T + 'round7.css', encoding='utf8').read() + open(T + 'round9.css', encoding='utf8').read()
i = t.rindex('</style>')
t = t[:i] + css + t[i:]
open(path, 'w', encoding='utf8').write(t)
print('patch8 ok')

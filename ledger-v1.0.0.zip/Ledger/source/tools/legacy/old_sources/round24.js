/* ===== Round 24: managers who work, and an assistant manager who is a worker first ===== */
window.R24 = window.R24 || {};
(function () {
  const need = (co, bd) => bd.std.reduce((a, s) => a + s[1], 0) * (co.size || 1);
  const mgrOf = co => co.mgr && S.npcs[co.mgr];
  const monthProfit = co => { const H = (co.hist || []).slice(-3); return H.length ? H.reduce((a, x) => a + (x.profit || 0), 0) / H.length : 0; };
  /* how hard the business is pushing against its capacity over the last weeks (0 = slack, 1 = turning many away) */
  function pressure(co) {
    const H = (co.wh22 || []).slice(-3).filter(x => x.d != null);
    if (!H.length) { const w = co.lastW || {}; return w.cap > 0 ? Math.max(0, Math.min(1, ((w.D || 0) / w.cap - 0.95) / 0.3)) : 0; }
    const d = H.reduce((a, x) => a + Math.min(3, x.d), 0) / H.length;
    return Math.max(0, Math.min(1, (d - 0.95) / 0.3));
  }
  R24.pressure = pressure;
  /* the manager's own hands-on time.
     Small places: the manager is a working manager and spends most of the week on the floor.
     Big places: management takes most of the time. A big business that makes a lot of money lets its manager step back,
     but when demand runs ahead of capacity the manager pitches in. */
  R24.mgrBase = function (co, bd) {
    const n = need(co, bd);
    let base = n < 3 ? 0.85 : n < 6 ? 0.7 : n < 10 ? 0.55 : n < 16 ? 0.35 : 0.15;
    const m = mgrOf(co);
    if (n >= 10 && m && monthProfit(co) > (co.mgrWage || m.ask || 50000) * 4) base = 0;
    return base;
  };
  window.mgrFTE = function (co, bd) {
    const base = R24.mgrBase(co, bd), n = need(co, bd);
    const surge = (n < 10 ? 0.35 : 0.6) * pressure(co);
    return Math.min(1, base + surge);
  };
  /* when the manager works, they work like the best person in the team (or better, if their own skill is higher) */
  R24.mgrEff = function (co) {
    const m = mgrOf(co);
    if (!m) return 1;
    const best = co.staff.reduce((a, s) => Math.max(a, staffSkill(s)), 0);
    const sk = Math.min(95, Math.max(m.stats.ops || 50, best + 3));
    return 0.75 + 0.5 * sk / 100;
  };
  /* the assistant manager: a full worker who also takes up to two jobs off your plate */
  R24.asstFTE = function (co, bd) {
    const a = co.asst, n = a && S.npcs[a.npc];
    if (!n || co.st !== 'open') return 0;
    const share = 1 - 0.12 * ((a.duties || []).length);
    const sk = Math.min(95, n.skill || ((n.stats && (n.stats.ops + n.stats.people) / 2) || 55));
    return share * (0.75 + 0.5 * sk / 100);
  };
  /* pay: more than the team's typical hands-on pay, clearly less than a manager */
  R24.asstAsk = function (co, n) {
    const bd = bdOf(co);
    const tot = bd.std.reduce((m, s) => m + s[1], 0) || 1, avg = bd.std.reduce((m, s) => m + wageFor(s[0], co) * s[1], 0) / tot;
    const sk = n.stats ? (n.stats.ops + n.stats.people) / 2 : 55;
    const mgrAsk = n.ask0 || n.ask;
    const ask = Math.max(avg * 1.05, Math.min(mgrAsk * 0.8, avg * (1.1 + sk / 600)));
    return Math.round(ask / 500) * 500;
  };
})();
/* a manager always earns clearly more than the team they lead (and more than an assistant manager would) */
(function () {
  const gm = window.genManager;
  window.genManager = function (co, mtype) {
    const n = gm.apply(this, arguments);
    try {
      const bd = co && BD[co.type];
      if (bd && bd.std && bd.std.length) {
        /* the floor is the team's typical pay, not its best-paid specialist: a law firm's office manager does not out-earn its lawyers */
        const tot = bd.std.reduce((m, s) => m + s[1], 0) || 1, avg = bd.std.reduce((m, s) => m + wageFor(s[0], co) * s[1], 0) / tot;
        const st = n.stats || {}, sk = ((st.ops || 60) + (st.people || 60) + (st.sales || 60) + (st.fin || 60)) / 4;
        const floor = avg * (1.2 + sk / 500);
        if (n.ask < floor) n.ask = rl(rnd(floor, 500), co.country);
      }
    } catch (e) { console.error(e); }
    return n;
  };
})();
/* ===== Franchise lifecycle (round 24) =====
   You as franchisor: units earn what your own concept earns, pay royalties (or fall behind when they lose money),
   can be terminated by you, renew or leave when their contract ends, and close when they go broke.
   You as franchisee: royalties you cannot pay become arrears, the brand enforces its quality standard,
   the contract ends after its term (renew or go independent), and you can buy yourself out early. */
(function () {
  const r0 = Math.round;
  const termOf = f => f.term || 10;
  /* what the concept earns: the franchisor's own operating margin over recent months, kept within reason for the trade */
  /* the store's own margin is tracked week by week without the franchise money (fees, royalties, support), so
     paying for your franchisees' setup does not make your concept look worse */
  function conceptMargin(co, bd) {
    const f = co.fr || {};
    let own = f.cmE;
    if (own == null) { const H = (co.hist || []).slice(-6), rev = H.reduce((a, x) => a + (x.rev || 0), 0), pr = H.reduce((a, x) => a + (x.profit || 0), 0); own = rev > 0 ? pr / rev : bd.m; }
    return clamp(own, bd.m - 0.04, bd.m + 0.12);
  }
  const frIn = (co, a) => { if (co && co.fr) co.fr.wIn = (co.fr.wIn || 0) + a; };
  const frOut = (co, a) => { if (co && co.fr) co.fr.wOut = (co.fr.wOut || 0) + a; };
  R7.afterWeek.push(() => {
    try {
      S.cos.forEach(co => {
        const f = co.fr;
        if (!f || !f.on) return;
        /* the store's own trading: its sales, its cost of goods and its running costs; franchise money never enters */
        const w = co.lastW || {}, r = w.rev || 0;
        if (r > 0 && co.st === 'open') { const e = (w.cogs || 0) + coWeekCost(co) - (w.cogs || 0) * 0.5; const m = clamp((r - e) / r, -1, 1); f.cmE = f.cmE == null ? m : f.cmE + (m - f.cmE) * 0.06; }
        f.wIn = 0; f.wOut = 0;
      });
    } catch (e) { console.error(e); }
  });
  R24.conceptMargin = conceptMargin;
  const fa0 = window.frAccept;
  window.frAccept = function (co, aid) {
    const c0 = co.cash;
    const r = fa0.apply(this, arguments);
    try {
      if (r === 'ok') {
        const fee = co.fr.fee || 0; frIn(co, fee); frOut(co, Math.max(0, c0 + fee - co.cash));
        const u = co.fr.units[co.fr.units.length - 1];
        u.end = S.week + termOf(co.fr) * 52;
        u.q = clamp(u.skill + rint(-10, 10), 20, 95);
        u.loc = gauss() * 0.045; /* some sites are simply better than others */
        u.owed = 0; u.late = 0;
      }
    } catch (e) { console.error(e); }
    return r;
  };
  function unitAsk(co, u, kind) {
    const f = co.fr, act = 'fr24';
    const due = u.rev * f.roy;
    const body = kind === 'owed'
      ? u.name + ' (' + cityOf(u.city).name + ') is ' + Math.round(u.late) + ' weeks behind and owes ' + money(u.owed) + ' in royalties. The unit is losing money.'
      : u.name + ' (' + cityOf(u.city).name + ') failed a brand inspection. Poor units drag down the whole brand.';
    addMsg({ kind: 'ask', from: co.name + ' franchise', title: kind === 'owed' ? 'Franchisee behind on royalties' : 'Franchisee below standard', body, co: co.id, act, exp: S.week + 3, tone: 'bad', data: { u: u.id, kind },
      opts: [{ l: kind === 'owed' ? 'Give them time' : 'Warn them', d: kind === 'owed' ? 'Arrears stay on the books; they repay when they can.' : 'They get three months to fix it.', fx: {} },
        { l: 'Terminate the contract', d: 'The unit loses your brand. You chase ' + (kind === 'owed' ? 'the arrears through a lawyer.' : 'nothing, but the brand is protected.'), fx: {} }] });
  }
  /* ending a unit: by you (terminate), by the franchisee (leave at contract end) or by bankruptcy */
  function endUnit(co, u, how) {
    const f = co.fr;
    f.units = f.units.filter(x => x !== u);
    if (how === 'term') {
      const legal = KC(15000);
      payCo(co, legal, 'oth', 'Franchise termination: lawyer'); frOut(co, legal);
      const rec = u.owed > 0 ? r0(u.owed * rng(0.25, 0.55)) : 0;
      if (rec) { coIn(co, rec, 'rev', 'Arrears recovered from ' + u.name); frIn(co, rec); }
      f.brand = clamp(f.brand + (u.q < 45 ? 0.5 : -1), 0, 100);
      note('Franchise contract with ' + u.name + ' terminated. ' + (u.owed > 0 ? 'Recovered ' + money(rec) + ' of ' + money(u.owed) + ' owed.' : ''), 'n', co.id);
    } else if (how === 'left') {
      f.brand = Math.max(0, f.brand - 1);
      note(u.name + ' did not renew and left the ' + co.name + ' brand.', 'n', co.id);
    } else {
      f.brand = Math.max(0, f.brand - 2);
      note('The franchise unit run by ' + u.name + ' in ' + cityOf(u.city).name + ' went bankrupt. ' + (u.owed > 0 ? money(u.owed) + ' in royalties is lost.' : ''), 'bad', co.id);
    }
    f.ended = (f.ended || 0) + 1;
    if (u.owed > 0) f.lostOwed = (f.lostOwed || 0) + u.owed * (how === 'term' ? 0.6 : 1);
  }
  ACTS.fr24 = (m, idx) => {
    const co = getCo(m.co), f = co && co.fr;
    const u = f && f.units.find(x => x.id === m.data.u);
    if (!u) return true;
    if (idx === 1) endUnit(co, u, 'term');
    else if (m.data.kind === 'qual') u.qwarn = S.week;
    else u.grace = S.week + 12;
    return true;
  };
  window.frWeek = function (co) {
    const f = co.fr;
    if (!f || !f.on) return;
    const bd = BD[co.type];
    frApplicants(co);
    const cm = conceptMargin(co, bd);
    let roy = 0, sup = 0, renew = 0;
    f.units.slice().forEach(u => {
      if (u.end == null) { u.end = (u.w0 || S.week) + termOf(f) * 52; u.q = u.q != null ? u.q : clamp(u.skill, 20, 95); u.owed = u.owed || 0; u.late = u.late || 0; }
      if (u.loc == null) u.loc = gauss() * 0.045;
      const city = cityOf(u.city);
      const age = S.week - u.w0;
      const ramp = Math.min(1, 0.35 + age / 40);
      const rev = bd.Dc * bd.ticket * city.dem * (0.35 + f.brand / 100 * 0.6) * (0.6 + u.skill / 160) * seasOf(bd) * ramp * (1 + (S.econ.dem - 1) * 0.8) * (0.9 + 0.2 * Z()) * 0.85;
      /* the unit's own margin before fees: your concept, the brand's pull, how good the operator is; a new unit runs below par */
      const m0 = cm + (f.brand / 100 - 0.35) * 0.06 + (u.skill - 55) * 0.0012 + (f.supp > 0 ? 0.01 : 0) - 0.01 - (1 - ramp) * 0.06 + u.loc + gauss() * 0.01;
      const due = rev * f.roy, fund = rev * f.mkt;
      const prof = rev * m0 - due - fund;
      u.rev = rev; u.prof = prof;
      f.fund = (f.fund || 0) + fund;
      /* royalties: paid in full while the unit makes money; a losing unit pays less and less and the rest becomes arrears */
      let paid = due;
      if (prof < 0) { u.late++; if (u.late > 3) paid = due * clamp(0.95 - u.late * 0.05, 0.15, 0.9); }
      else { u.late = Math.max(0, u.late - 1); if (u.owed > 0) { const x = Math.min(u.owed, prof * 0.5); paid += x; u.owed -= x; } }
      u.owed += Math.max(0, due - Math.min(paid, due));
      roy += paid;
      if (f.supp === 2) { if (prof > 0) roy += prof * f.share; else sup += -prof * f.share; }
      u.neg = prof < 0 ? (u.neg || 0) + 1 : Math.max(0, (u.neg || 0) - 1);
      /* the operator's quality drifts with their skill and with whether they can afford to run the place properly */
      u.q = clamp(u.q + (u.skill - u.q) * 0.02 + (prof < 0 ? -0.15 : 0.05), 10, 98);
      if (u.owed > due * 8 && u.late >= 8 && !(u.grace > S.week) && !u.asked) { u.asked = S.week; unitAsk(co, u, 'owed'); }
      if (u.q < 40 && !(u.qwarn > S.week - 13) && !u.qasked) { u.qasked = S.week; unitAsk(co, u, 'qual'); }
      if (u.asked && S.week - u.asked > 13) u.asked = 0;
      if (u.qasked && S.week - u.qasked > 13) u.qasked = 0;
      /* long losses break the operator (with full support you carry them, up to a point) */
      if ((u.neg > 30 && f.supp < 2) || u.neg > 52) { endUnit(co, u, 'bust'); return; }
      /* end of the contract: profitable units mostly renew and pay a renewal fee; struggling ones leave */
      if (S.week >= u.end) {
        if (prof > 0 && u.q >= 45 && chance(0.85)) { u.end = S.week + termOf(f) * 52; renew += r0(f.fee * 0.3); note(u.name + ' renewed the ' + co.name + ' franchise for another ' + termOf(f) + ' years.', 'good', co.id); }
        else endUnit(co, u, 'left');
      }
    });
    if (roy) coIn(co, roy, 'rev', null);
    if (renew) coIn(co, renew, 'rev', 'Franchise renewal fees');
    if (sup) payCo(co, sup, 'oth', 'Covering franchise-unit losses');
    frIn(co, roy + renew); frOut(co, sup);
    const used = (f.fund || 0) * 0.9;
    if (used > 0) { co.aware = Math.min(100, co.aware + Math.sqrt(used) * 0.002); f.fund = 0; }
    const qAvg = f.units.length ? f.units.reduce((a, u) => a + u.q, 0) / f.units.length : 60;
    f.brand = clamp(f.brand + f.units.length * 0.05 + (co.q - 60) * 0.0015 + (qAvg - 55) * 0.002 * Math.min(1, f.units.length / 3) - f.brand * 0.003, 0, 100);
    const mw = masterWeek(co); frIn(co, mw);
    f.income = roy + renew + mw;
  };
  /* unanswered royalty or quality questions: the default is to give time / warn */
  R7.afterWeek.push(() => { try { S.inbox.forEach(m => { if (m.act === 'fr24' && m.auto && !m.done24) { m.done24 = 1; ACTS.fr24(m, 0); } }); } catch (e) { console.error(e); } });
  /* a franchisor that goes bankrupt takes the brand down with it: the units rebrand and leave */
  const bk0 = window.bankrupt;
  window.bankrupt = function (co, why) {
    const had = co && co.fr && co.fr.on && co.st !== 'bust' && co.st !== 'sold';
    const r = bk0.apply(this, arguments);
    try { if (had && co.st === 'bust') { const n = co.fr.units.length; co.fr.units = []; co.fr.on = 0; co.fr.masters = []; if (n) note(n + ' franchise units of ' + co.name + ' rebrand and go their own way.', 'n'); } } catch (e) { console.error(e); }
    return r;
  };

  /* ---------- you as franchisee ---------- */
  R24.fbMinQ = f => Math.round(Math.min(f.std || 60, 72) - 27);
  const brandOf = co => co.franchise && co.franchise.brandId ? fbBrand(co.franchise.brandId) : null;
  window.franchiseeWeek = function (co, rev) {
    const f = co.franchise;
    if (!f || !f.fran) return;
    if (f.term && f.w0 != null && f.end == null) f.end = f.w0 + f.term * 52;
    const due = rev * (f.roy + f.mkt);
    /* royalties come out of the company account; when there is not enough, the unpaid part is owed to the franchisor */
    const can = Math.max(0, Math.min(due + (f.owed || 0), co.cash));
    if (can > 0) payCo(co, can, 'oth', null);
    f.owed = Math.max(0, (f.owed || 0) + due - can);
    if (f.owed > 0.5) { f.lateW = (f.lateW || 0) + 1; } else f.lateW = 0;
    f.brand = clamp(f.brand + (co.q - 55) * 0.004, 10, 90);
    if (f.brandId) co.aware = Math.max(co.aware, 15 + f.brand * 0.45);
    /* the brand's quality standard */
    /* the brand's minimum: stricter brands demand more, but a new unit gets half a year to get up to speed */
    const minQ = R24.fbMinQ(f);
    if (co.st === 'open' && co.lastW && co.lastW.units > 0 && S.week - (f.w0 || 0) >= 26) f.lowQ = co.q < minQ ? (f.lowQ || 0) + 1 : Math.max(0, (f.lowQ || 0) - 1);
    if (f.lowQ === 8) { note('The franchisor warns ' + co.name + ': quality is well below the brand standard. Fix it within two months or the contract can be terminated.', 'bad', co.id); co.rep -= 2; }
    if (f.lowQ >= 17 && !f.asked) fbAsk(co, 'qual');
    if (f.lateW >= 8 && f.owed > due * 6 && !f.asked) fbAsk(co, 'owed');
    if (f.end != null && S.week >= f.end && !f.asked) fbAsk(co, 'end');
  };
  function fbAsk(co, kind) {
    const f = co.franchise, b = brandOf(co), bn = f.brandName || (b && b.name) || 'The franchisor';
    f.asked = S.week;
    const renewFee = r0((f.fee || 0) * 0.3);
    let title, body, opts;
    if (kind === 'owed') { title = bn + ' demands unpaid royalties'; body = co.name + ' owes ' + money(f.owed) + ' in royalties and marketing fees. Pay now or the franchise contract ends.'; opts = [{ l: 'Pay ' + money(f.owed), d: 'From company cash.', fx: {} }, { l: 'Let the contract end', d: 'You lose the brand. The debt stays as a bill to pay.', fx: {} }]; }
    else if (kind === 'qual') { title = bn + ' terminates for poor quality'; body = 'Quality at ' + co.name + ' has been far below the brand standard for months. Invest in a refit and training, or the contract ends.'; opts = [{ l: 'Refit and retrain · ' + money(KC(30000) * (co.size || 1)), d: 'Quality improves; the warning is withdrawn.', fx: {} }, { l: 'Let the contract end', d: 'You run on as an independent.', fx: {} }]; }
    else { title = 'Your ' + bn + ' contract has ended'; body = 'The ' + (f.term || 10) + '-year franchise agreement for ' + co.name + ' is up. Renew on the same terms, or go independent (new signs, fewer people know the name).'; opts = [{ l: 'Renew · ' + money(renewFee), d: 'Another ' + (f.term || 10) + ' years on the same royalty.', fx: {} }, { l: 'Go independent', d: 'No more royalties. Awareness drops.', fx: {} }]; }
    addMsg({ kind: 'ask', from: bn, title, body, co: co.id, act: 'fb24', data: { kind }, exp: S.week + 3, tone: kind === 'end' ? 'n' : 'bad', opts });
  }
  /* leaving the brand: by choice, at contract end, or terminated by the franchisor */
  function leaveBrand(co, why) {
    const f = co.franchise;
    if (!f) return;
    if (f.owed > 0.5) { co.pay.other = (co.pay.other || 0) + f.owed; }
    const sign = KC(8000) * (co.size || 1);
    payCo(co, sign, 'oth', 'New signs and rebranding');
    co.aware = Math.max(5, co.aware * 0.55);
    co.franchise = null;
    if (co.docs) delete co.docs.fran_op;
    note(co.name + (why === 'term' ? ' lost its franchise contract.' : ' is now independent.') + (f.owed > 0.5 ? ' ' + money(f.owed) + ' in unpaid royalties is still owed.' : ''), why === 'term' ? 'bad' : 'n', co.id);
  }
  R24.leaveBrand = leaveBrand;
  ACTS.fb24 = (m, idx) => {
    const co = getCo(m.co), f = co && co.franchise;
    if (!f) return true;
    f.asked = 0;
    const k = m.data.kind;
    if (k === 'owed') { if (idx === 0) { const x = Math.min(f.owed, Math.max(0, co.cash)); payCo(co, x, 'oth', 'Royalty arrears'); f.owed -= x; f.lateW = 0; if (f.owed > 0.5) leaveBrand(co, 'term'); } else leaveBrand(co, 'term'); }
    else if (k === 'qual') { if (idx === 0) { payCo(co, KC(30000) * (co.size || 1), 'oth', 'Refit and training (franchise standard)'); co.q = Math.min(100, (co.q || 50) + 15); f.lowQ = 0; } else leaveBrand(co, 'term'); }
    else { if (idx === 0) { payCo(co, r0((f.fee || 0) * 0.3), 'oth', 'Franchise renewal fee'); f.end = S.week + (f.term || 10) * 52; } else leaveBrand(co, 'end'); }
    return true;
  };
  /* no answer: arrears and quality end the contract; an expired contract is renewed only if you said so, otherwise you go independent */
  R7.afterWeek.push(() => { try { S.inbox.forEach(m => { if (m.act === 'fb24' && m.auto && !m.done24) { m.done24 = 1; const co = getCo(m.co); if (co && co.franchise) ACTS.fb24(m, 1); } }); } catch (e) { console.error(e); } });
  /* leave early: you buy out the rest of the contract */
  R24.buyout = function (co) {
    const f = co.franchise;
    if (!f || f.end == null) return 0;
    const yrs = Math.max(0, (f.end - S.week) / 52);
    const yRoy = ((co.bk.y.rev || 0) / Math.max(1, (S.week % 52) || 52) * 52) * (f.roy + f.mkt);
    return r0(Math.max((f.fee || 0) * 0.25 * Math.min(1, yrs / 3), Math.min((f.fee || 0) * 1.5, yRoy * yrs * 0.5)) / 1000) * 1000 + r0(f.owed || 0);
  };
  ACT.fb24leave = p => {
    const co = getCo(p.id);
    if (!co || !co.franchise) return;
    const fee = R24.buyout(co);
    confirmThen('Leave the franchise?', 'You pay ' + money(fee) + ' to buy out the contract (including any royalties you owe), put up new signs, and lose much of the brand awareness. No more royalties after that.', 'Leave', () => {
      if (fee) payCo(co, fee, 'oth', 'Franchise contract buyout');
      co.franchise.owed = 0;
      leaveBrand(co, 'exit');
      save(); render();
    }, true);
  };
  R24.fbCard = function (co) {
    const f = co.franchise;
    if (!f || !f.fran) return '';
    return row('Quality', Math.round(co.q || 0) + ' (brand minimum ' + R24.fbMinQ(f) + ')') + (f.end != null ? row('Contract ends', dateStr(f.end)) : '') + (f.owed > 0.5 ? row('Royalties owed', '<span class="neg">' + money(f.owed) + '</span>') : '') + (f.brandId ? btn('Leave the franchise · buyout ' + money(R24.buyout(co)), 'fb24leave', { id: co.id }, 'chip ghost danger') : '');
  };
  R24.frUnitRow = function (u) {
    return (u.owed > 0.5 ? ' · owes ' + mshort(u.owed) : '') + (u.end ? ' · until ' + (wYear ? wYear(u.end) : '') : '');
  };
  ACT.fr24term = p => {
    const co = getCo(p.id), u = co && co.fr && co.fr.units.find(x => x.id === p.u);
    if (!u) return;
    confirmThen('Terminate ' + esc(u.name) + '?', 'The unit loses your brand and stops paying royalties. A lawyer costs ' + money(KC(15000)) + (u.owed > 0.5 ? ' and may recover part of the ' + money(u.owed) + ' owed.' : '.'), 'Terminate', () => { endUnit(co, u, 'term'); save(); render(); }, true);
  };
})();
/* ===== Football clubs (round 24): debt you take over, realistic running costs, transfer windows ===== */
(function () {
  const r0 = Math.round, rk = x => Math.round(x / 100000) * 100000;
  /* an existing club carries debt: anywhere from a little to about half its value. You take it over when you buy. */
  R24.clubDebt = function (club) {
    if (club.debt == null) { const h = (fbHash(club.id + ':' + (S.seed || 1)) % 1000) / 1000; club.debt = club.founded ? 0 : rk(club.val * (0.05 + 0.45 * h)); }
    return club.debt;
  };
  const pc0 = window.proposeClub;
  window.proposeClub = function (club, mult) {
    const r = pc0.apply(this, arguments);
    try {
      if (r && r.price) {
        const d = R24.clubDebt(club), eq = Math.max(rk(r.price - d), rk(club.val * 0.1));
        r.msg = r.msg.replace(money(r.price), money(eq)) + (d ? ' On top, you take over ' + money(d) + ' of club debt.' : '');
        r.price = eq; r.debt = d;
      }
    } catch (e) { console.error(e); }
    return r;
  };
  const bc0 = window.buyClub;
  window.buyClub = function (club, price) {
    const d = R24.clubDebt(club);
    const co = bc0.apply(this, arguments);
    try {
      if (co && typeof co === 'object' && d > 0) {
        const l = { id: uid(), kind: 'biz', name: 'Club debt taken over', bal: d, amt0: d, margin: creditMargin() + 0.015, pay: 0, termM: 240, co: co.id, w0: S.week, guar: 0, bank: 0 };
        l.pay = annuity(d, policy() + l.margin, 240);
        S.loans.push(l);
        club.debt = 0;
        note(co.name + ' comes with ' + money(d) + ' of debt, repaid by the club over twenty years. Clubs rarely make money on football alone: plan to put in cash, or sell players.', 'n', co.id);
      }
    } catch (e) { console.error(e); }
    return co;
  };
  /* a club is worth its football value plus cash, minus what it owes */
  const cv0 = window.companyValue;
  window.companyValue = function (co) {
    const v = cv0.apply(this, arguments);
    try { if (co && co.type === 'club' && co.fm && co.st !== 'sold' && co.st !== 'bust') return r0(v - S.loans.filter(l => l.co === co.id).reduce((a, l) => a + l.bal, 0) + (co.fm.book || 0) * 0.8); } catch (e) { }
    return v;
  };
  /* ---------- transfer windows ---------- */
  const TIERS = [['Squad player', 0.04, 1.2, 0.006], ['First-team starter', 0.1, 3, 0.015], ['Star signing', 0.25, 7, 0.035]];
  R24.TIERS = TIERS;
  R24.window = function (co) {
    const lg = leagueOf(co.country), sw = S.week - lg.w0;
    return sw >= 0 && sw < 6 ? 'summer' : sw >= 26 && sw < 30 ? 'winter' : null;
  };
  R24.signFee = (co, i) => rk(clubRev(clubOf(co), co.fm) * TIERS[i][1]);
  R24.sign = function (co, i) {
    const fm = co.fm, T = TIERS[i], fee = R24.signFee(co, i);
    if (!R24.window(co)) return 'closed';
    if (co.cash < fee) return 'cash';
    payCo(co, fee, null, 'Transfer fee: ' + T[0].toLowerCase());
    fm.sq = (fm.sq || 0) + T[2];
    fm.xw = (fm.xw || 0) + T[3];
    fm.book = (fm.book || 0) + fee;
    (fm.amort = fm.amort || []).push({ a: fee / 156, left: 156 });
    fm.tin = (fm.tin || 0) + fee;
    return 'ok';
  };
  R24.sell = function (co, bid) {
    const fm = co.fm;
    coIn(co, bid.fee, 'rev', 'Transfer fee received');
    fm.sq = (fm.sq || 0) - bid.pts;
    fm.xw = Math.max(-0.05, (fm.xw || 0) - bid.xw);
    fm.tout = (fm.tout || 0) + bid.fee;
    co.rep = clamp(co.rep - bid.pts * 0.3, 0, 100);
  };
  ACTS.club24 = (m, idx) => {
    const co = getCo(m.co);
    if (!co || !co.fm || m.data.done) return true;
    m.data.done = 1;
    if (idx === 0) { R24.sell(co, m.data); note(co.name + ' sold ' + m.data.who + ' to ' + m.data.to + ' for ' + money(m.data.fee) + '.', 'good', co.id); }
    return true;
  };
  const cw0 = window.clubWeek;
  window.clubWeek = function (co, bd, ctx) {
    const r = cw0.apply(this, arguments);
    try {
      const fm = co.fm, R = clubRev(clubOf(co), fm);
      /* extra wages for players signed (or saved by selling) on top of the wage budget */
      const xw = (fm.xw || 0) * R / 52;
      ctx.cogs += xw;
      /* signings are paid up front and written off over a three-year contract */
      let dep = 0;
      (fm.amort || []).forEach(a => { if (a.left > 0) { dep += a.a; a.left--; } });
      fm.amort = (fm.amort || []).filter(a => a.left > 0);
      if (dep > 0) { bk(co, 'dep', dep); fm.book = Math.max(0, (fm.book || 0) - dep); }
      /* bids for your players arrive while a window is open */
      const win = R24.window(co);
      if (win && chance(win === 'summer' ? 0.15 : 0.08) && !S.inbox.some(m => m.act === 'club24' && m.co === co.id && m.status === 'open')) {
        const f = rng(0.04, 0.15) * (0.6 + (fm.s || 50) / 100), fee = rk(R * f), pts = f * 22, xw2 = f * 0.12;
        const who = personName(), to = pick(FB_A) + ' ' + pick(['FC', 'United', 'City', 'Athletic', 'SK']);
        addMsg({ kind: 'ask', from: co.name, title: to + ' bid ' + money(fee) + ' for ' + who, body: who + ' is one of your ' + (pts > 4 ? 'best players' : 'regular starters') + '. Selling brings cash now but weakens the team (about ' + pts.toFixed(1) + ' strength points) until you replace him.', co: co.id, act: 'club24', exp: S.week + 2, tone: 'n', data: { who, to, fee, pts, xw: xw2 }, opts: [{ l: 'Sell for ' + money(fee), d: 'Cash now, weaker squad.', fx: {} }, { l: 'Keep him', d: 'No change.', fx: {} }] });
      }
    } catch (e) { console.error(e); }
    return r;
  };
  /* contracts run out and players age: what you bought (or lost) fades over a season or two */
  const se0 = window.seasonEnd;
  window.seasonEnd = function (lg, country, own) {
    const r = se0.apply(this, arguments);
    try { (own || []).forEach(co => { if (!co.fm) return; co.fm.sq = (co.fm.sq || 0) * 0.65; co.fm.xw = (co.fm.xw || 0) * 0.65; }); } catch (e) { console.error(e); }
    return r;
  };
  ACT.club24buy = p => {
    const co = getCo(p.id);
    const fee = R24.signFee(co, p.i);
    confirmThen('Sign a ' + TIERS[p.i][0].toLowerCase() + '?', 'Transfer fee ' + money(fee) + ' now (written off over three years), plus about ' + money(TIERS[p.i][3] * clubRev(clubOf(co), co.fm) / 12) + ' a month in extra wages. The squad gets about ' + TIERS[p.i][2] + ' strength points stronger.', 'Sign', () => { const r = R24.sign(co, p.i); if (r === 'ok') { toast('Signed.'); save(); render(); } else res(r === 'closed' ? 'The transfer window is closed.' : r); }, false);
  };
  R24.clubCard = function (co) {
    const fm = co.fm, win = R24.window(co), lg = leagueOf(co.country), sw = S.week - lg.w0;
    const debt = S.loans.filter(l => l.co === co.id).reduce((a, l) => a + l.bal, 0);
    let h = '<div class="card"><h3>Transfers</h3>' + row('Window', win ? (win === 'summer' ? 'Summer window open' : 'Winter window open') : 'Closed · opens in ' + (sw < 26 ? 26 - sw : 52 - sw) + ' wk') + row('Bought this year / sold', money(fm.tin || 0) + ' / ' + money(fm.tout || 0)) + (debt > 0 ? row('Club debt', money(debt)) : '');
    if (win) h += '<div class="dbtns three3">' + TIERS.map((t, i) => btn(t[0] + ' · ' + mshort(R24.signFee(co, i)), 'club24buy', { id: co.id, i }, i === 1 ? 'primary' : '')).join('') + '</div>';
    h += '<span class="tipt">Clubs bid for your players while a window is open. Selling brings cash and weakens the team; signings cost a fee up front and more wages.</span></div>';
    return h;
  };
  const ov0 = CT.ov;
  CT.ov = function (co, bd) { const h = ov0.apply(this, arguments); return bd && bd.fam === 'club' && co.fm ? h + R24.clubCard(co) : h; };
  /* the offer sheet shows the debt that comes with the club */
  const cb0 = ACT.clubbuy;
  ACT.clubbuy = p => {
    cb0(p);
    try { const c = clubsOf(p.k).find(x => x.id === p.c), d = R24.clubDebt(c); if (d && ui.sheet && ui.sheet.html) { ui.sheet.html = ui.sheet.html.replace('A bad offer can end the talks for a year.', 'It owes ' + money(d) + ' that you take over; the amounts below are for the club including its debt, so you pay that much less in cash. A bad offer can end the talks for a year.'); render(); } } catch (e) { console.error(e); }
  };
})();
/* ===== Oil and gas (round 24) =====
   - a discovery is a decision: develop it alone, bring in a partner who pays half, or sell it as it is
   - a developed field holds a plateau for about two years before it declines
   - lifting costs follow real offshore costs (about 200 NOK a barrel, rising with inflation and material prices)
   - in Norway the state refunds 78% of exploration costs to companies with no taxable income, once a year */
(function () {
  const r0 = Math.round;
  const ox0 = window.oilExplore;
  window.oilExplore = function (co) {
    const c0 = co.cash;
    const r = ox0.apply(this, arguments);
    try {
      if (r === 'hit' || r === 'dry') {
        const cost = c0 - co.cash;
        co.fm.expl = (co.fm.expl || 0) + cost; /* this year's exploration spend, for the refund */
      }
      if (r === 'hit') {
        const f = co.fm.fields[co.fm.fields.length - 1];
        f.plat = 104;
        /* a plateau of about 14% of the reserves a year, and full-cycle development costs nearer real offshore projects */
        f.q0 = f.res * 0.0028;
        f.capex = r0(f.res * 1000 * 130 * Math.pow(1 + S.econ.infl, S.week / 52) ** 0.5);
        const sell = r0(f.res * 1000 * 25 * Math.sqrt(S.econ.oil) / 1e5) * 1e5;
        const capex = f.capex;
        addMsg({ kind: 'ask', from: co.name, title: 'Discovery: ' + f.name, body: 'About ' + r0(f.res / 1000) + ' million barrels. Developing it costs about ' + money(capex) + ' over three years before any oil flows. You have ' + money(co.cash) + ' in the company.', co: co.id, act: 'oil24', exp: S.week + 4, tone: 'good', data: { f: f.id, sell },
          opts: [{ l: 'Develop it ourselves', d: 'You pay all of the development and keep all of the oil.', fx: {} }, { l: 'Bring in a partner for half', d: 'A partner pays half the development and takes half the field.', fx: {} }, { l: 'Sell the discovery · ' + money(sell), d: 'Cash now; no development risk.', fx: {} }] });
      }
    } catch (e) { console.error(e); }
    return r;
  };
  function oilChoice(co, f, idx, sell) {
    if (idx === 1) { f.res = r0(f.res / 2); f.q0 = f.q0 / 2; f.capex = f.capex / 2; f.name += ' (50%)'; note('A partner takes half of ' + f.name + ' and pays half the development.', 'good', co.id); }
    else if (idx === 2) { co.fm.fields = co.fm.fields.filter(x => x !== f); coIn(co, sell, 'rev', 'Discovery sold: ' + f.name); }
  }
  ACTS.oil24 = (m, idx) => {
    const co = getCo(m.co), f = co && co.fm && (co.fm.fields || []).find(x => x.id === m.data.f);
    if (!f || m.data.done) return true;
    m.data.done = 1;
    oilChoice(co, f, idx, m.data.sell);
    return true;
  };
  /* no answer: the company cannot afford it alone → bring in a partner; otherwise develop */
  R7.afterWeek.push(() => {
    try {
      S.inbox.forEach(m => {
        if (m.act !== 'oil24' || !m.auto || m.data.done) return;
        const co = getCo(m.co), f = co && co.fm && (co.fm.fields || []).find(x => x.id === m.data.f);
        m.data.done = 1;
        if (f) { const i = co.cash < f.capex * 1.1 ? 1 : 0; oilChoice(co, f, i, m.data.sell); note('No answer on the discovery, so ' + (i ? 'a partner was brought in for half.' : 'development goes ahead.'), 'n', co.id); }
      });
      /* exploration refund (Norway): paid at the start of the next year for companies without taxable income */
      if (S.week % 52 === 0) S.cos.forEach(co => {
        if (co.type !== 'oilgas' || co.country !== 'NO' || !co.fm || !(co.fm.expl > 0) || co.st === 'bust') return;
        const taxed = (co.pay && co.pay.tax) || 0;
        const ref = r0(co.fm.expl * 0.78);
        if (taxed < 1) { coIn(co, ref, null, 'Exploration cost refund (78%)'); note(co.name + ' gets ' + money(ref) + ' back from the state for last year\'s exploration.', 'good', co.id); }
        co.fm.expl = 0;
      });
    } catch (e) { console.error(e); }
  });
  /* development: when the company cannot pay this week's share, the bank lends against the field (reserve-based lending) */
  R24.oilDevCash = function (co, f, c) {
    if (co.cash >= c) return;
    const need = Math.max(c - co.cash, c * 26);
    const lim = f.res * 1000 * 100 - (f.rbl || 0);
    const amt = r0(Math.min(need, lim) / 1e5) * 1e5;
    if (amt <= 0) return;
    /* interest only until the field produces, then repaid over seven years */
    const l = { id: uid(), kind: 'biz', name: 'Reserve-based loan: ' + f.name, bal: amt, amt0: amt, margin: creditMargin() + 0.025, pay: 0, termM: 84, co: co.id, w0: S.week + f.wl, graceW: S.week + f.wl + 13, guar: 0, bank: 0 };
    l.pay = annuity(amt, policy() + l.margin, 84);
    S.loans.push(l);
    coIn(co, amt, null, 'Loan drawn');
    f.rbl = (f.rbl || 0) + amt;
    note('The bank lends ' + money(amt) + ' against ' + f.name + ' to finish development.', 'n', co.id);
  };
  R24.oilLift = () => 200 * (0.7 + 0.3 * (S.econ.mat || 1)) * Math.pow(1 + S.econ.infl, S.week / 52) ** 0.5;
})();
/* ===== Bank liquidity (round 24): a solvent bank hit by a run borrows from the central bank against its loans
   instead of going bankrupt; it repays as deposits come back. ===== */
(function () {
  const r0 = Math.round;
  function cbLoans(co) { return S.loans.filter(l => l.co === co.id && l.cb); }
  R24.bankLiquidity = function (co) {
    const fm = co.fm;
    if (!fm || co.type !== 'bank' || (co.st !== 'open' && co.st !== 'closed')) return;
    const dep = fm.dep || 0, book = fm.book || 0, eq = fm.equity != null ? fm.equity : co.cash + book - dep;
    const have = cbLoans(co).reduce((a, l) => a + l.bal, 0);
    if (co.cash < dep * 0.03 && eq > 0) {
      const want = dep * 0.08 - co.cash, room = book * 0.5 - have, amt = r0(Math.min(want, room) / 1e5) * 1e5;
      if (amt > 0) {
        const l = { id: uid(), kind: 'biz', name: 'Central bank liquidity facility', bal: amt, amt0: amt, margin: 0.01, pay: 0, termM: 12, co: co.id, w0: S.week + 26, graceW: S.week + 26, guar: 0, bank: 0, cb: 1 };
        l.pay = annuity(amt, policy() + 0.01, 12);
        S.loans.push(l);
        coIn(co, amt, null, 'Loan drawn');
        if (!co.flags.cb24 || S.week - co.flags.cb24 > 26) { co.flags.cb24 = S.week; note(co.name + ' borrows ' + money(amt) + ' from the central bank to meet withdrawals. It is repaid as deposits return.', 'bad', co.id); }
      }
    } else if (have > 0 && co.cash > dep * 0.15) {
      let x = Math.min(have, co.cash - dep * 0.12);
      cbLoans(co).forEach(l => { const p = Math.min(l.bal, x); if (p > 0) { payCo(co, p, null, 'Central bank facility repaid'); l.bal -= p; x -= p; } });
      S.loans = S.loans.filter(l => !(l.cb && l.bal < 1));
    }
  };
  const nw = window.nextWeek;
  window.nextWeek = function () {
    try { S.cos.forEach(co => R24.bankLiquidity(co)); } catch (e) { console.error(e); }
    return nw.apply(this, arguments);
  };
})();
/* ===== Pay spread by skill (round 24) =====
   The country table gives one wage index per country. In lower-wage countries the gap between low-paid and skilled
   jobs is wider than in Norway: a barista in Brazil earns about a tenth of a Norwegian barista, an electrician closer
   to a seventh, a pilot much closer to Norwegian pay. Low-paid jobs therefore follow the index more steeply.
   Countries at or above Norway's wage level are unchanged. */
(function () {
  const wf0 = window.wageFor;
  R24.paySpread = function (role, cc) {
    const C = CO[cc || S.country] || CC(), w = C.wage || 1;
    if (w >= 1) return 1;
    const r = (ROLES[role] || ['', 40000])[1];
    const e = clamp(1 + (1 - r / 80000), 0.7, 1.6);
    return Math.pow(w, e) / w;
  };
  window.wageFor = function (role, co) {
    const v = wf0.apply(this, arguments);
    try { const f = R24.paySpread(role, (co && co.country) || S.country); if (f !== 1) return rlc(rnd(v * f, 100), co && co.country); } catch (e) { }
    return v;
  };
})();

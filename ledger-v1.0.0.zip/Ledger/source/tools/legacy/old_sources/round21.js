/* ===== Round 21: money that adds up for small businesses abroad.
   - fit-out was charged in Norwegian prices in every country and never shown, so cheap rents still failed with "not enough cash"
   - converting to a limited company asked for a new accountant even when you had one, and only took personal cash
   - the home screen "Companies" figure is the companies' value, not their cash ===== */
{
  const fitOf = (co, kind, m2) => KC((FIT[kind] || 0) * m2, co.country) || 0;
  window.R21 = { fitOf };
  /* what renting a listing costs up front: 3 months deposit + fit-out */
  function startCost(co, l) {
    const bd = BD[co.type], kind = bd.prem[0], P = PREM[kind], city = cityOf(co.city);
    const rent = rl(P[1] * l.rentF * city.rent * Math.pow(1 + S.econ.infl, S.week / 52) * l.m2 / 12);
    const bl = co.franchise && co.franchise.bld;
    return { rent, dep: bl ? 0 : rent * 3, fit: fitOf(co, kind, l.m2) };
  }
  /* show the up-front cost on each listing */
  const ps0 = ACT.premsheet;
  ACT.premsheet = p => {
    ps0(p);
    try {
      const co = getCo(p.id), L = premListings(co);
      let i = 0;
      ui.sheet.html = ui.sheet.html.replace(/(<small>Rent [^<]*? a month · buy [^<·]*)/g, m => { const l = L[i++]; if (!l) return m; const c = startCost(co, l); return m + ' · to move in ' + mshort(c.dep + c.fit); });
      ui.sheet.html = ui.sheet.html.replace('Renting needs a 3 month deposit plus fit-out.', 'Renting needs a 3 month deposit plus fit-out. Company cash: ' + money(co.cash) + '.');
      render();
    } catch (e) { console.error(e); }
  };
  /* not enough in the company: say how much is missing and offer to put in your own money */
  const pset0 = ACT.premset;
  ACT.premset = p => {
    const co = getCo(p.id), l = premListings(co)[p.i];
    if (!co || !l || p.buy) return pset0(p);
    const c = startCost(co, l), need = c.dep + c.fit, short = Math.ceil(need - co.cash);
    if (short <= 0) return pset0(p);
    if (liquid() >= short) {
      confirmThen('Put in ' + money(short) + '?', 'Moving in costs ' + money(need) + ' (deposit ' + money(c.dep) + ' + fit-out ' + money(c.fit) + '). The company has ' + money(co.cash) + '. The rest comes from your own money.', 'Put in and rent', () => { injectCash(co, short); pset0(p); });
      return;
    }
    toast('Moving in costs ' + money(need) + ' (deposit ' + money(c.dep) + ' + fit-out ' + money(c.fit) + '). The company has ' + money(co.cash) + ' and you have ' + money(Math.max(0, liquid())) + '.', true);
  };
  /* keep the accountant you already have */
  const pa0 = window.pickAccountant;
  window.pickAccountant = function (co, accId) {
    if (co && co.acc && accId === co.acc.id) return true;
    return pa0.apply(this, arguments);
  };
  /* share capital may come from the business's own cash when your personal cash is short */
  const cv0 = window.convertToAS;
  window.convertToAS = function (co, accId) {
    try {
      const c = CC(), need = c.asCapital + c.asConvFee;
      if (co.form !== 'AS' && S.cash < need && S.cash + Math.max(0, co.cash) >= need) {
        const x = need - Math.max(0, S.cash);
        moveCash(co, -x);
        moveCash(ME, x);
        logTx(0, x, 'From ' + co.name + ' for the share capital', co.id);
      }
    } catch (e) { console.error(e); }
    return cv0.apply(this, arguments);
  };
  const tc0 = ACT.tcAS;
  ACT.tcAS = p => {
    tc0(p);
    try {
      const co = getCo(p.id), c = CC(), need = c.asCapital + c.asConvFee;
      let h = ui.sheet.html;
      if (S.cash < need && S.cash + Math.max(0, co.cash) >= need) h = h.replace(/(<span[^>]*>Paid from<\/span><b>)[^<]*/, '$1Personal ' + mshort(Math.max(0, S.cash)) + ' + company ' + mshort(need - Math.max(0, S.cash)));
      else if (S.cash + Math.max(0, co.cash) < need) h = h.replace('<h3 class="gap">Step 2 of 2', '<div class="card probcard"><b>Not enough money</b><span class="tipt">It costs ' + money(need) + '. You have ' + money(Math.max(0, S.cash)) + ' and the company ' + money(Math.max(0, co.cash)) + '.</span></div><h3 class="gap">Step 2 of 2');
      if (co.acc) {
        const i = h.indexOf('<h3 class="gap">Step 2 of 2');
        const j = h.lastIndexOf('<button', h.indexOf('data-a="sheetclose"'));
        if (i >= 0 && j > i) h = h.slice(0, i) + '<h3 class="gap">Step 2 of 2 · Your accountant</h3><div class="card">' + row('Keeps the books', esc(co.acc.name)) + '</div>' + btn('Convert · pay ' + money(need), 'convgo', { id: co.id, a: co.acc.id }, 'primary wide') + h.slice(j);
      }
      ui.sheet.html = h;
      render();
    } catch (e) { console.error(e); }
  };
  /* home: name the figure for what it is */
  const home0 = V.home;
  V.home = function () {
    const h = home0.apply(this, arguments);
    const cash = sum(S.cos.filter(c => c.st !== 'sold' && c.st !== 'bust'), c => Math.max(0, c.cash || 0));
    return h.replace(/<span>Companies<\/span><b>[^<]*<\/b>/, '<span>In companies</span><b>' + mshort(cash) + '</b>');
  };
}
/* a new game always starts in a city of the chosen country */
{
  const sg0 = ACT.startgame;
  ACT.startgame = () => { const c = CO[ui.sc || CO_ORDER[0]]; if (c && !c.cities.some(x => x.id === ui.city)) ui.city = c.cities[0].id; sg0(); };
}

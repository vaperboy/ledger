path='/home/claude/work/ledger.html'
t=open(path,encoding='utf8').read()
def rep(old,new,count=1):
    global t
    n=t.count(old)
    if n!=count: raise SystemExit('MATCH %d for: %s'%(n,old[:80]))
    t=t.replace(old,new)
rep("""  window.showReport = showReport;
})();""","""  window.showReport = showReport;
  window.msgCard = msgCard;
})();""")
rep("""  ACT.phmeet = p => {
    ui.mt = Object.assign(ui.mt || {}, { who: p.who });
    ui.ph = { n: 'meet', p: {} };
    render(true);
  };""","""  ACT.phmeet = p => {
    ui.mt = Object.assign(ui.mt || {}, { who: p.who });
    U.phoneGo('meet', {});
  };""")
rep("""      toast('The meeting is done. Replies are in Messages.');
      ui.ph = { n: 'msgs', p: {} };
      render(true);""","""      toast('The meeting is done. Replies are in Messages.');
      ui.mtab = 'msgs';
      render(true);""")
# fonts: mockup bold sans
rep("""<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Instrument+Serif&family=Schibsted+Grotesk:wght@400;500;600;700&display=swap">""",
"""<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,600;12..96,700;12..96,800&family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600;9..40,700&display=swap">""")
mod=open('/home/claude/work/tools/mockup_screens.js',encoding='utf8').read()
rep("/* ---- ui/core/boot.js ---- */", mod + "/* ---- ui/core/boot.js ---- */")
css=open('/home/claude/work/tools/mockup.css',encoding='utf8').read()
rep('</body></html>', '<style id="mockup-look">\n' + css + '\n</style>\n</body></html>')
open(path,'w',encoding='utf8').write(t)
print('ok')

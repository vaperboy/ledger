# round 30: screens, monthly bills and results, event bookings, marketing fixes
path = '/home/claude/w3/ledger.html'
T = '/home/claude/w3/tools/'
t = open(path, encoding='utf8').read()
mark = '/* ---------- no zooming: pinch, double tap, ctrl+wheel, ctrl +/- ---------- */'
assert t.count(mark) == 1
t = t.replace(mark, open(T + 'round30.js', encoding='utf8').read() + '\n' + mark)
# marketing: a campaign's own luck plus a chance draw every week (zero customers possible), rivals, price and campaign age count
a = "        const noise = x.vol ? (chance(0.08) ? 4 : rng(0.2, 1)) : rng(0.6, 1.4);"
assert t.count(a) == 1, 'noise'
t = t.replace(a, "        const since30 = co.mkt[k] ? co.mkt[k].since : -1;\n        if (c.luck == null || c.luckS !== since30) { c.luck = x.vol ? Math.exp(gauss() * 0.9 - 0.4) : Math.exp(gauss() * 0.45 - 0.1); c.luckS = since30; }\n        const noise = c.luck * (x.vol ? (chance(0.05) ? 3 : rng(0.5, 1.2)) : rng(0.8, 1.2)) * (window.R30M ? R30M(co, bd, k) : 1);")
a = "        let n = Math.floor(c.acc);\n        if (n === 0 && c.acc > 0.25 && chance((c.acc - 0.25) * 0.4)) n = 1;\n        c.acc -= n;"
assert t.count(a) == 1, 'pois'
t = t.replace(a, "        let n = pois(c.acc);\n        c.acc = 0;")
a = "'Working. About ' + (L.exp >= 1 ? Math.round(L.exp) : L.exp.toFixed(1)) + ' new customers a week expected at this budget.'"
assert t.count(a) == 1, 'why'
t = t.replace(a, "'Working. Likely ' + (window.R30rng ? R30rng(L.exp, k) : Math.round(L.exp)) + ' new customers a week at this budget, and some weeks bring nobody.'")
a = "  const chScore = (bd, k) => (CH[k].b2b * bd.b2b + (1 - bd.b2b)) * CH[k].eff;"
assert t.count(a) == 1, 'chScore'
t = t.replace(a, "  const chScore = (bd, k) => window.R30 && R30.chScore ? R30.chScore(bd, k) : (CH[k].b2b * bd.b2b + (1 - bd.b2b)) * CH[k].eff;")
# city population is stored in thousands (Oslo 710); the campaign model read it as people, so every campaign hit a ceiling of a few hundred
a = "    const cm = ctry(co), city = cityOf(co.city) || {}, pop = city.pop || 150000;"
assert t.count(a) == 1, 'pop'
t = t.replace(a, "    const cm = ctry(co), city = cityOf(co.city) || {}, pop = city.pop ? city.pop * 1000 : 150000;")
a = "    const leads = reach * x.resp * cm[1] * fit * tgt * (window.R19K || 1);"
assert t.count(a) == 1, 'leads'
t = t.replace(a, "    const leads0 = reach * x.resp * cm[1] * fit * tgt * (window.R19K || 1);\n    const M30 = window.R30 && R30.inMarket ? R30.inMarket(co, bd) : Infinity;\n    const leads = M30 === Infinity ? leads0 : leads0 * M30 / (M30 + leads0); /* only so many people shop for this each week */")
# a manager's target push no longer spends on top of a marketing budget the owner configured
a = "if (g.k === 'util' || g.k === 'rev' || g.k === 'aware') { payCo(co, w * 0.015 * push, 'mkt', 'Push for customers');"
assert t.count(a) == 1, 'push'
t = t.replace(a, "if ((g.k === 'util' || g.k === 'rev' || g.k === 'aware') && !Object.keys(co.mkt || {}).some(k => co.mkt[k] && co.mkt[k].b > 0)) { payCo(co, w * 0.015 * push, 'mkt', 'Push for customers');")
i = t.rindex('</style>')
t = t[:i] + open(T + 'round30.css', encoding='utf8').read() + '\n' + t[i:]
open(path, 'w', encoding='utf8').write(t)
print('patch17 ok')

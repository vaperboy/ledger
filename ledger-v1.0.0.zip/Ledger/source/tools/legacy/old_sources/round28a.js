/* ===== Round 28a: moments that feel good.
   Firsts are celebrated with a short full-screen moment and kept on a trophy wall in the office.
   Every company gets a storefront picture that grows with it: an empty unit, a small shop, a busy one with a queue,
   a flagship. And "Next day" now tells you how the day went, with the takings counting up. ===== */
window.R28 = window.R28 || {};
(function () {
  const R28 = window.R28;
  const U = window.UI, { toast, save, render, svg, row } = U;
  const P = o => esc(JSON.stringify(o));
  const pillp = (t, c) => '<span class="pill ' + (c || '') + '">' + t + '</span>';
  const sumF = (a, f) => a.reduce((t, x) => t + (f(x) || 0), 0);
  const live = () => S.cos.filter(c => c.st === 'open' || c.st === 'closed');
  const K = v => v * costIdx(S.country);
  const jobs = () => sumF(live(), c => (c.staff || []).length + (c.mgr ? 1 : 0));
  const nw = () => { try { return netWorth().total; } catch (e) { return 0; } };

  /* ---------- the firsts ---------- */
  const ACH = [
    ['cust', 'First customer', 'bag', () => { const c = live().find(x => (x.dl && x.dl.u > 0) || (x.lastW && x.lastW.units > 0)); return c && c.name + ' served its first customer.'; }],
    ['emp', 'First employee', 'people', () => { const c = live().find(x => (x.staff || []).length); return c && S.npcs[c.staff[0].id] && S.npcs[c.staff[0].id].name + ' joined ' + c.name + '.'; }],
    ['profit', 'First profitable month', 'chart', () => { const c = live().find(x => (x.hist || []).some(h => h.profit > 0)); return c && c.name + ' made money for a whole month.'; }],
    ['year', 'One year in business', 'star', () => { const w0 = Math.min.apply(null, S.cos.map(c => c.w0 == null ? 1e9 : c.w0)); return S.week - w0 >= 52 && 'A year since you started your first company.'; }],
    ['mgr', 'First manager', 'tie', () => { const c = live().find(x => x.mgr && S.npcs[x.mgr]); return c && S.npcs[c.mgr].name + ' now runs ' + c.name + '.'; }],
    ['ten', 'Ten people on the payroll', 'people', () => jobs() >= 10 && 'Ten people now earn their living with you.'],
    ['branch', 'First branch', 'biz', () => { const t = {}; let hit = null; live().forEach(c => { if (c.st === 'open') { if (t[c.type]) hit = c; t[c.type] = 1; } }); const b = live().find(c => c.branch || c.chain); return (hit || b) && 'Your second ' + BD[(hit || b).type].n.toLowerCase() + ' is open.'; }],
    ['million', 'First million', 'coin', () => nw() >= K(1e6) && 'Your net worth passed ' + money(K(1e6)) + '.'],
    ['div', 'First dividend', 'coin', () => (S.stats.dividends || 0) > 0 && 'Your company paid you a share of its profit.'],
    ['stars', 'A 4.5-star business', 'star', () => { const c = live().find(x => (x.rvN || 0) >= 50 && ratingOf(x) >= 4.5); return c && 'Customers rate ' + c.name + ' ' + ratingOf(c).toFixed(1) + ' stars.'; }],
    ['acq', 'First acquisition', 'deal', () => window.R27 && R27.amb && R27.amb().cnt.buy > 0 && 'You bought a competitor.'],
    ['no1', 'No. 1 in a market', 'fire', () => { if (!window.R26) return false; const m = R26.markets().find(x => { const t = R26.truthOf(x); return t.riv.length && t.riv.every(r => r.share < t.share); }); return m && 'Nobody sells more ' + (m.kind === 'fin' ? 'here' : BD[m.type].n.toLowerCase() + ' in ' + cityOf(m.city).name) + ' than you.'; }],
    ['abroad', 'First company abroad', 'globe', () => { const c = live().find(x => x.country !== S.country); return c && c.name + ' opened in ' + CO[c.country].name + '.'; }],
    ['tenm', 'Net worth of 10 million', 'coin', () => nw() >= K(10e6) && 'Your net worth passed ' + money(K(10e6)) + '.'],
    ['hundred', '100 people work for you', 'people', () => jobs() >= 100 && 'A hundred jobs. Families depend on you now.'],
    ['bank', 'Your own bank', 'bank', () => live().some(c => c.type === 'bank' && c.st === 'open') && 'You run a bank.'],
    ['listed', 'Listed on the stock exchange', 'invest', () => live().some(c => c.type === 'hold' && c.listed) && 'Anyone can now buy shares in your group.'],
    ['top10', 'Top 10 in your country', 'fire', () => window.R27 && R27.myRank && (() => { const r = R27.myRank('cc', 'rev'); return r && r.rank <= 10 && 'Only nine companies in ' + (CO[S.country] || CC()).name + ' sell more than you.'; })()],
    ['give', 'First gift to the city', 'house', () => window.R28 && R28.giveCount && R28.giveCount() > 0 && 'Your name is on something that is not a business.'],
    ['mgr10', 'A manager for ten years', 'tie', () => { const c = live().find(x => x.mgr && x.mgrW0 != null && S.week - x.mgrW0 >= 520); return c && S.npcs[c.mgr].name + ' has run ' + c.name + ' for ten years.'; }],
    ['hm', 'Net worth of 100 million', 'coin', () => nw() >= K(100e6) && 'Your net worth passed ' + money(K(100e6)) + '.'],
    ['bn', 'A billionaire', 'coin', () => nw() >= K(1e9) && 'Your net worth passed ' + money(K(1e9)) + '.']
  ];
  R28.ACH = ACH;
  const A = () => S.ach28 = S.ach28 || {};
  function checkAch(silent) {
    const a = A();
    /* an older save: what you already reached goes on the wall without a party */
    let first = !S.ach28i && S.week > 8;
    S.ach28i = 1;
    ACH.forEach(x => {
      if (a[x[0]]) return;
      let r = false;
      try { r = x[3](); } catch (e) { }
      if (!r) return;
      a[x[0]] = { w: S.week, t: r, old: first || silent ? 1 : 0 };
      if (!first && !silent) { S.cel28q = S.cel28q || []; S.cel28q.push(x[0]); }
    });
  }
  R28.checkAch = checkAch;
  /* the full-screen moment */
  function confetti() {
    const C = ['#e7b65b', '#c4a47c', '#93b8a0', '#7aa5d6', '#e5534b', '#f2e3c6'];
    let h = '';
    for (let i = 0; i < 46; i++) h += '<i style="left:' + Math.round(Math.random() * 100) + '%;background:' + C[i % C.length] + ';animation-delay:' + (Math.random() * 0.9).toFixed(2) + 's;animation-duration:' + (1.8 + Math.random() * 1.6).toFixed(2) + 's;transform:rotate(' + Math.round(Math.random() * 360) + 'deg)"></i>';
    return '<div class="conf28">' + h + '</div>';
  }
  R28.confetti = confetti;
  function celHtml(id) {
    const x = ACH.find(a => a[0] === id), r = A()[id];
    if (!x || !r) return '';
    return confetti() + '<div class="cel28b"><div class="cel28i">' + svg(x[2], 40) + '</div><small>' + esc(dateStr(r.w)) + '</small><h2>' + esc(x[1]) + '</h2><p class="lead">' + esc(r.t) + '</p><div class="btnrow col">' + btn('Nice!', 'cel28ok', undefined, 'primary wide') + btn('See the trophy wall', 'cel28wall', undefined, 'ghost wide') + '</div></div>';
  }
  R28.celHtml = celHtml;
  ACT.cel28ok = () => { ui.sheet = null; render(); };
  ACT.cel28wall = () => { ui.sheet = null; ACT.go({ n: 'trophies28', p: {} }); };
  /* show queued moments when nothing else is on screen */
  setInterval(() => {
    try {
      if (!S || S.over || !S.cel28q || !S.cel28q.length || ui.sheet || ui.dayBusy || ui.untl || ui.repLock || (ui.view && ui.view.n === 'weekreport')) return;
      const id = S.cel28q.shift();
      const h = celHtml(id);
      if (h) { ui.sheet = { html: h, cls: 'cel28' }; render(); }
    } catch (e) { }
  }, 600);

  /* ---------- the trophy wall ---------- */
  V.titles.trophies28 = 'Trophy wall';
  V.heads = V.heads || {};
  V.heads.trophies28 = () => { const n = Object.keys(A()).length; return { t: 'Trophy wall', sub: n + ' of ' + ACH.length + ' firsts', right: pillp(n + ' / ' + ACH.length, 'amb') }; };
  V.trophies28 = function () {
    const a = A();
    let h = '<div class="tw28">' + ACH.map(x => { const r = a[x[0]]; return '<button class="tile28' + (r ? ' on' : '') + '" data-a="' + (r ? 'tw28' : 'none') + '" data-p="' + P({ id: x[0] }) + '"><span class="ti">' + svg(x[2], 26) + '</span><b>' + esc(x[1]) + '</b><small>' + (r ? (r.old ? 'Before the wall' : dateStr(r.w)) : 'Not yet') + '</small></button>'; }).join('') + '</div>';
    const hof = S.hof28 || [];
    if (hof.length) h += '<h2 class="sec">Hall of fame</h2><div class="lrows">' + hof.slice(0, 12).map(x => '<div class="lrow"><span class="av">' + esc(String(x.n).split(' ').map(w => w[0]).join('').slice(0, 2)) + '</span><span class="ctext"><b>' + esc(x.n) + '</b><small>' + esc(x.t) + '</small></span></div>').join('') + '</div>';
    return h;
  };
  ACT.tw28 = p => { const h = celHtml(p.id); if (h) { ui.sheet = { html: h.replace(confetti(), ''), cls: 'cel28 calm28' }; render(); } };
  ACT.none = () => { };
  /* a door to the wall from the office */
  const hq0 = V.hq;
  V.hq = function (p) {
    let h = hq0.apply(this, arguments);
    try {
      const n = Object.keys(A()).length;
      const pill = '<button class="pill amb" data-a="go" data-p="' + P({ n: 'trophies28' }) + '">Trophies · ' + n + '</button>';
      const i = h.indexOf('<h1>Office</h1>');
      if (i >= 0) h = h.slice(0, i + 15) + pill + h.slice(i + 15);
    } catch (e) { }
    return h;
  };

  /* ---------- storefront pictures ---------- */
  const PAL = { venue: ['#7a4b2a', '#e7b65b'], retail: ['#2f4b6e', '#7aa5d6'], svc: ['#2f5a48', '#93b8a0'], prod: ['#6b3a2e', '#d08a6a'], logi: ['#4a4f57', '#c4a47c'], project: ['#5c5240', '#e7b65b'], fin: ['#3b3f47', '#d9d4c7'], energy: ['#2c4a3e', '#93b8a0'], rent: ['#4b4458', '#c9b8e0'], club: ['#2d4a2a', '#e5e5e5'], hold: ['#3b3f47', '#c4a47c'] };
  function stageOf(co) {
    const bd = BD[co.type];
    if (co.st === 'setup' || co.st === 'closed') return 0;
    const sold = (co.uh || []).slice(-4).reduce((t, x) => t + x, 0) + (co.lastW ? co.lastW.units || 0 : 0);
    if (sold <= 0) return 0;
    const ref = (bd.Dc || 1) * bd.ticket * 52 * cityOf(co.city).dem;
    const rev = window.R26 && R26.annRev ? R26.annRev(co) : (co.lastW ? co.lastW.rev * 52 : 0);
    const sites = live().filter(c => c.type === co.type && c.st === 'open').length;
    if ((co.size || 1) >= 1.4 || rev >= ref * 1.1 || sites >= 3 || (co.chain)) return 3;
    const u = co.lastW ? co.lastW.util || 0 : 0;
    return u >= 0.82 ? 2 : 1;
  }
  R28.stageOf = stageOf;
  const STN = ['An empty unit', 'A small business', 'Busy, with a queue', 'A flagship'];
  function person(x, y, c, s) { s = s || 1; return '<g transform="translate(' + x + ' ' + y + ') scale(' + s + ')"><circle cx="0" cy="-17" r="4" fill="' + c + '"/><rect x="-4.5" y="-12" width="9" height="13" rx="4" fill="' + c + '"/></g>'; }
  function famIcon(f, x, y, c) {
    if (f === 'venue') return '<g fill="none" stroke="' + c + '" stroke-width="2"><path d="M' + (x - 7) + ' ' + (y - 4) + 'h12v6a6 6 0 0 1-12 0z"/><path d="M' + (x + 5) + ' ' + (y - 2) + 'h3a2 2 0 0 1 0 5h-3"/></g>';
    if (f === 'retail') return '<g fill="none" stroke="' + c + '" stroke-width="2"><rect x="' + (x - 7) + '" y="' + (y - 5) + '" width="14" height="12" rx="2"/><path d="M' + (x - 3) + ' ' + (y - 5) + 'v-2a3 3 0 0 1 6 0v2"/></g>';
    if (f === 'svc') return '<g fill="none" stroke="' + c + '" stroke-width="2"><rect x="' + (x - 8) + '" y="' + (y - 3) + '" width="16" height="10" rx="2"/><path d="M' + (x - 3) + ' ' + (y - 3) + 'v-3h6v3"/></g>';
    if (f === 'fin') return '<g fill="' + c + '"><path d="M' + (x - 9) + ' ' + (y - 3) + 'l9-6 9 6z"/><rect x="' + (x - 7) + '" y="' + (y - 2) + '" width="2.5" height="9"/><rect x="' + (x - 1.2) + '" y="' + (y - 2) + '" width="2.5" height="9"/><rect x="' + (x + 4.5) + '" y="' + (y - 2) + '" width="2.5" height="9"/></g>';
    return '<circle cx="' + x + '" cy="' + y + '" r="5" fill="' + c + '"/>';
  }
  function storeSvg(co) {
    const bd = BD[co.type], f = bd.fam, pal = PAL[f] || PAL.svc, st = stageOf(co) || (co.st === 'open' ? 1 : 0);
    const u = co.lastW ? co.lastW.util || 0 : 0;
    const W = 340, H = 150, gy = 128;
    let s = '<svg class="shop28" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="' + esc(STN[st]) + '"><defs><linearGradient id="sky' + co.id + '" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1d2026"/><stop offset="1" stop-color="#15171b"/></linearGradient></defs><rect width="' + W + '" height="' + H + '" fill="url(#sky' + co.id + ')"/>';
    /* neighbours */
    s += '<rect x="0" y="' + (gy - 70) + '" width="60" height="70" fill="#22252b"/><rect x="280" y="' + (gy - 84) + '" width="60" height="84" fill="#22252b"/>';
    for (let i = 0; i < 3; i++) s += '<rect x="' + (10 + i * 16) + '" y="' + (gy - 58) + '" width="8" height="10" fill="#2c3037"/><rect x="' + (290 + i * 16) + '" y="' + (gy - 70) + '" width="8" height="10" fill="#2c3037"/>';
    const big = st === 3, bx = big ? 66 : 92, bw = big ? 208 : 156, bh = big ? 104 : 74, by = gy - bh;
    /* the building */
    s += '<rect x="' + bx + '" y="' + by + '" width="' + bw + '" height="' + bh + '" rx="3" fill="' + (st === 0 ? '#2a2d33' : pal[0]) + '"/>';
    if (big) { for (let i = 0; i < 5; i++) s += '<rect x="' + (bx + 14 + i * 38) + '" y="' + (by + 8) + '" width="24" height="16" rx="2" fill="#f2d79a" opacity=".85"/>'; }
    if (f === 'prod' && st > 0) s += '<rect x="' + (bx + bw - 34) + '" y="' + (by - 22) + '" width="12" height="22" fill="' + pal[0] + '"/><circle cx="' + (bx + bw - 28) + '" cy="' + (by - 30) + '" r="6" fill="#3a3d44" opacity=".8"/><circle cx="' + (bx + bw - 20) + '" cy="' + (by - 40) + '" r="8" fill="#3a3d44" opacity=".6"/>';
    if (f === 'project' && st > 0) s += '<path d="M' + (bx + bw + 6) + ' ' + gy + 'V' + (by - 26) + 'h-60" stroke="' + pal[1] + '" stroke-width="3" fill="none"/><path d="M' + (bx + bw - 44) + ' ' + (by - 26) + 'v16" stroke="' + pal[1] + '" stroke-width="1.5"/>';
    if (f === 'energy' && st > 0) s += '<path d="M' + (bx + bw + 14) + ' ' + gy + 'V' + (by - 20) + '" stroke="#cfd3d8" stroke-width="2.5"/><path d="M' + (bx + bw + 14) + ' ' + (by - 20) + 'l-16 -10M' + (bx + bw + 14) + ' ' + (by - 20) + 'l16 -10M' + (bx + bw + 14) + ' ' + (by - 20) + 'v18" stroke="#cfd3d8" stroke-width="2"/>';
    /* the sign */
    const sy = big ? by + 30 : by + 6, sw = bw - 24;
    s += '<rect x="' + (bx + 12) + '" y="' + sy + '" width="' + sw + '" height="20" rx="3" fill="' + (st === 0 ? '#34373e' : '#141518') + '"/>';
    const nm = st === 0 ? (co.st === 'setup' ? 'Opening soon' : 'Closed') : co.name;
    s += '<text x="' + (bx + bw / 2) + '" y="' + (sy + 14) + '" text-anchor="middle" font-size="11.5" font-weight="700" fill="' + (st === 0 ? '#8b8f97' : pal[1]) + '" font-family="system-ui, sans-serif">' + esc(nm.length > 26 ? nm.slice(0, 25) + '…' : nm) + '</text>';
    /* awning */
    if (st >= 2) { const ay = sy + 22, n = Math.floor((bw - 8) / 14); for (let i = 0; i < n; i++) s += '<path d="M' + (bx + 4 + i * 14) + ' ' + ay + 'h14l-2 10h-10z" fill="' + (i % 2 ? pal[1] : '#f2e3c6') + '" opacity=".9"/>'; }
    /* windows and door */
    const wy = big ? by + 62 : by + 34, wh = big ? 34 : 30;
    if (st === 0) {
      s += '<rect x="' + (bx + 12) + '" y="' + wy + '" width="' + (bw - 24) + '" height="' + wh + '" fill="#3a3d44"/>';
      for (let i = 0; i < 6; i++) s += '<line x1="' + (bx + 12) + '" x2="' + (bx + bw - 12) + '" y1="' + (wy + 4 + i * 5) + '" y2="' + (wy + 4 + i * 5) + '" stroke="#2a2d33" stroke-width="1.5"/>';
      s += '<rect x="' + (bx + bw / 2 - 16) + '" y="' + (wy + 6) + '" width="32" height="14" fill="#e6e1d6"/><text x="' + (bx + bw / 2) + '" y="' + (wy + 16) + '" text-anchor="middle" font-size="6.5" fill="#333" font-family="system-ui">' + (co.st === 'setup' ? 'SOON' : 'TO LET') + '</text>';
    } else {
      const dw = 22, dx = bx + bw / 2 - dw / 2;
      s += '<rect x="' + (bx + 12) + '" y="' + wy + '" width="' + (dx - bx - 18) + '" height="' + wh + '" rx="2" fill="#f2d79a" opacity="' + (0.55 + 0.4 * Math.min(1, u)) + '"/>';
      s += '<rect x="' + (dx + dw + 6) + '" y="' + wy + '" width="' + (bx + bw - 12 - dx - dw - 6) + '" height="' + wh + '" rx="2" fill="#f2d79a" opacity="' + (0.55 + 0.4 * Math.min(1, u)) + '"/>';
      s += '<rect x="' + dx + '" y="' + (gy - 36) + '" width="' + dw + '" height="36" fill="#141518"/><rect x="' + (dx + 2) + '" y="' + (gy - 34) + '" width="' + (dw - 4) + '" height="32" fill="' + pal[1] + '" opacity=".35"/>';
      s += famIcon(f, bx + 30, wy + wh / 2, '#141518');
    }
    /* street */
    s += '<rect x="0" y="' + gy + '" width="' + W + '" height="' + (H - gy) + '" fill="#191b1f"/><rect x="0" y="' + gy + '" width="' + W + '" height="2" fill="#2a2d33"/>';
    if (f === 'logi' && st > 0) s += '<g transform="translate(' + (bx + bw + 4) + ' ' + (gy - 20) + ')"><rect width="34" height="16" rx="2" fill="' + pal[1] + '"/><rect x="34" y="5" width="12" height="11" rx="2" fill="' + pal[1] + '"/><circle cx="8" cy="18" r="3.5" fill="#111"/><circle cx="38" cy="18" r="3.5" fill="#111"/></g>';
    /* people: more when busy, a queue when full */
    const C = ['#c4a47c', '#93b8a0', '#7aa5d6', '#d08a6a', '#e6e1d6', '#a99bd0'];
    const n = st === 0 ? 0 : Math.min(9, Math.round(Math.min(1.4, u) * (st >= 2 ? 7 : 4)));
    for (let i = 0; i < n; i++) { const qx = bx + bw / 2 - 30 - i * 13; s += person(qx < 6 ? bx + bw / 2 + 30 + (i - 4) * 13 : qx, gy + 14, C[i % C.length], 0.95); }
    if (big) s += '<rect x="' + (bx - 8) + '" y="' + (gy - 14) + '" width="8" height="14" rx="3" fill="#2f5a48"/><rect x="' + (bx + bw) + '" y="' + (gy - 14) + '" width="8" height="14" rx="3" fill="#2f5a48"/>';
    return s + '</svg>';
  }
  /* round 37: the picture follows the premises the company really has */
  function premOf(co) {
    const bd = BD[co.type], k0 = (bd.prem || ['none'])[0];
    const P = co.prem;
    const kind = P && P.m2 ? P.kind : P && P.kind === 'home' ? 'home' : k0;
    return { kind, m2: P && P.m2 ? P.m2 : 0, typ: (bd.prem || [0, 0])[1] || 0 };
  }
  R28.premOf = premOf;
  const SCENE = { home: 'home', none: 'mobile', office: 'office', warehouse: 'hall', industrial: 'hall', yard: 'yard', hotel: 'tower' };
  const sceneOf = co => SCENE[premOf(co).kind] || 'store';
  function frame(co, inner) {
    return '<svg class="shop28" viewBox="0 0 340 150" role="img" aria-label="' + esc(co.name) + '"><defs><linearGradient id="sky' + co.id + '" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1d2026"/><stop offset="1" stop-color="#15171b"/></linearGradient></defs><rect width="340" height="150" fill="url(#sky' + co.id + ')"/>' + inner + '</svg>';
  }
  const street = (W, H, gy) => '<rect x="0" y="' + gy + '" width="' + W + '" height="' + (H - gy) + '" fill="#191b1f"/><rect x="0" y="' + gy + '" width="' + W + '" height="2" fill="#2a2d33"/>';
  const label = (x, y, w, txt, col, bg) => '<rect x="' + (x - w / 2) + '" y="' + y + '" width="' + w + '" height="16" rx="3" fill="' + (bg || '#141518') + '"/><text x="' + x + '" y="' + (y + 11.5) + '" text-anchor="middle" font-size="9.5" font-weight="700" fill="' + col + '" font-family="system-ui, sans-serif">' + esc(txt.length > 30 ? txt.slice(0, 29) + '…' : txt) + '</text>';
  function van(x, y, col, nm, kind) {
    if (kind === 'car') return '<g transform="translate(' + x + ' ' + y + ')"><path d="M0 14v-6l8-7h22l8 7v6z" fill="' + col + '"/><rect x="10" y="3" width="18" height="6" rx="1" fill="#2a2d33"/><rect x="15" y="-3" width="9" height="4" rx="1" fill="#f2d79a"/><circle cx="9" cy="15" r="3.5" fill="#111"/><circle cx="30" cy="15" r="3.5" fill="#111"/></g>';
    return '<g transform="translate(' + x + ' ' + y + ')"><rect x="0" y="0" width="40" height="18" rx="3" fill="' + col + '"/><path d="M40 4h7l5 6v8h-12z" fill="' + col + '"/><rect x="42" y="6" width="5" height="5" fill="#2a2d33"/><circle cx="10" cy="19" r="3.8" fill="#111"/><circle cx="43" cy="19" r="3.8" fill="#111"/>' + (nm ? '<text x="20" y="12" text-anchor="middle" font-size="5.6" font-weight="700" fill="#141518" font-family="system-ui">' + esc(nm.split(' ')[0].slice(0, 12)) + '</text>' : '') + '</g>';
  }
  const lit = (u, i, n) => i < Math.max(1, Math.round(n * Math.min(1, 0.25 + u))) ? '#f2d79a' : '#3a3d44';
  function shopSvg(co) {
    const sc = sceneOf(co);
    if (sc === 'store') return storeSvg(co);
    const bd = BD[co.type], pal = PAL[bd.fam] || PAL.svc, st = stageOf(co), on = co.st === 'open';
    const u = co.lastW ? co.lastW.util || 0 : 0, gy = 128, nm = on ? co.name : co.st === 'setup' ? 'Opening soon' : 'Closed';
    const nv = Math.min(3, (co.veh || []).length), heads = (co.staff || []).length + (co.mgr ? 1 : 0) + (co.ohrs > 0 && !co.mgr ? 1 : 0);
    const pm = premOf(co);
    let s = '<rect x="0" y="' + (gy - 62) + '" width="48" height="62" fill="#22252b"/><rect x="292" y="' + (gy - 78) + '" width="48" height="78" fill="#22252b"/>';
    if (sc === 'home') {
      /* a house: the company is run from the kitchen table */
      s += '<rect x="96" y="' + (gy - 58) + '" width="112" height="58" fill="#3b3530"/><path d="M88 ' + (gy - 56) + 'L152 ' + (gy - 96) + 'L216 ' + (gy - 56) + 'z" fill="#4a3f38"/><rect x="186" y="' + (gy - 92) + '" width="10" height="20" fill="#4a3f38"/>';
      s += '<rect x="108" y="' + (gy - 46) + '" width="26" height="20" rx="2" fill="' + (on ? '#f2d79a' : '#3a3d44') + '" opacity="' + (on ? 0.6 + 0.35 * Math.min(1, u) : 1) + '"/><rect x="170" y="' + (gy - 46) + '" width="26" height="20" rx="2" fill="#3a3d44"/><rect x="142" y="' + (gy - 34) + '" width="20" height="34" fill="#141518"/>';
      if (on) s += '<rect x="113" y="' + (gy - 33) + '" width="14" height="7" rx="1" fill="#141518"/><rect x="114" y="' + (gy - 32) + '" width="12" height="5" fill="' + pal[1] + '" opacity=".8"/>';
      s += '<rect x="60" y="' + (gy - 22) + '" width="3" height="22" fill="#555"/>' + label(62, gy - 38, 74, nm, on ? pal[1] : '#8b8f97');
      s += street(340, 150, gy);
      for (let i = 0; i < nv; i++) s += van(214 + i * 4, gy - 20 - i * 0, pal[1], i === 0 ? co.name : '', bd.fam === 'svc' && /taxi/.test(co.type) ? 'car' : 'van');
    } else if (sc === 'mobile') {
      /* no premises: the vehicle is the business */
      s += '<rect x="60" y="' + (gy - 50) + '" width="220" height="50" fill="#20232a"/>' + street(340, 150, gy);
      const n = Math.max(1, nv);
      for (let i = 0; i < n; i++) s += '<g transform="translate(' + (70 + i * 70) + ' ' + (gy - 40) + ') scale(1.5)">' + van(0, 0, on ? pal[1] : '#555', i === 0 ? co.name : '', /taxi/.test(co.type) ? 'car' : 'van').replace(/^<g transform="translate\(0 0\)">/, '<g>') + '</g>';
      s += label(170, gy - 72, 160, nm, on ? pal[1] : '#8b8f97');
    } else if (sc === 'office') {
      /* an office block: floors grow with the team, lit windows show how busy it is */
      const floors = Math.max(2, Math.min(6, Math.ceil(Math.max(heads, pm.m2 / 25) / 4)));
      const fh = 14, bh = floors * fh + 18, bw = pm.m2 >= 300 ? 170 : 140, bx = 170 - bw / 2, by = gy - bh;
      s += '<rect x="' + bx + '" y="' + by + '" width="' + bw + '" height="' + bh + '" rx="2" fill="#2f3a48"/>';
      const cols = Math.floor((bw - 16) / 18);
      for (let f = 0; f < floors; f++) for (let c = 0; c < cols; c++) s += '<rect x="' + (bx + 10 + c * 18) + '" y="' + (by + 18 + f * fh) + '" width="12" height="8" fill="' + (on ? lit(u, (f * cols + c) % (cols * floors), cols * floors) : '#3a3d44') + '" opacity=".85"/>';
      s += label(170, by - 2, Math.min(bw, 150), nm, on ? pal[1] : '#8b8f97', '#141518');
      s += '<rect x="160" y="' + (gy - 16) + '" width="20" height="16" fill="#141518"/>' + street(340, 150, gy);
      for (let i = 0; i < Math.min(3, heads > 2 ? 2 : 1) && on; i++) s += person(140 - i * 14, gy + 14, ['#c4a47c', '#93b8a0', '#7aa5d6'][i], 0.95);
      for (let i = 0; i < nv; i++) s += van(232 + i * 8, gy - 20, pal[1], i === 0 ? co.name : '');
    } else if (sc === 'hall') {
      /* a workshop or warehouse: roller doors, trucks at the ramp */
      const bw = pm.m2 >= 800 ? 240 : 200, bx = 170 - bw / 2, bh = 64, by = gy - bh;
      s += '<rect x="' + bx + '" y="' + by + '" width="' + bw + '" height="' + bh + '" fill="#3c4048"/><path d="M' + bx + ' ' + by + 'l' + bw / 2 + ' -14l' + bw / 2 + ' 14z" fill="#454a53"/>';
      const doors = bw >= 240 ? 3 : 2;
      for (let i = 0; i < doors; i++) { const dx = bx + 16 + i * ((bw - 32) / doors); s += '<rect x="' + dx + '" y="' + (gy - 36) + '" width="' + ((bw - 32) / doors - 12) + '" height="36" fill="' + (on && i < Math.max(1, Math.round(doors * Math.min(1, u + 0.2))) ? '#5b5f68' : '#2a2d33') + '"/>'; for (let k = 0; k < 6; k++) s += '<line x1="' + dx + '" x2="' + (dx + (bw - 32) / doors - 12) + '" y1="' + (gy - 32 + k * 6) + '" y2="' + (gy - 32 + k * 6) + '" stroke="#2a2d33" stroke-width="1"/>'; }
      if (bd.fam === 'prod' && on) s += '<rect x="' + (bx + bw - 30) + '" y="' + (by - 34) + '" width="10" height="24" fill="#3c4048"/><circle cx="' + (bx + bw - 25) + '" cy="' + (by - 40) + '" r="6" fill="#3a3d44" opacity=".8"/>';
      s += label(170, by + 6, Math.min(bw - 20, 170), nm, on ? pal[1] : '#8b8f97');
      s += street(340, 150, gy);
      for (let i = 0; i < nv; i++) s += van(bx + bw - 60 - i * 58, gy - 8, pal[1], i === 0 ? co.name : '');
    } else if (sc === 'yard') {
      /* a sales yard or lot: a cabin, a fence, what is for sale */
      s += street(340, 150, gy) + '<rect x="40" y="' + (gy - 40) + '" width="70" height="40" fill="#3b3f47"/><rect x="50" y="' + (gy - 30) + '" width="22" height="14" fill="' + (on ? '#f2d79a' : '#3a3d44') + '" opacity=".8"/>' + label(75, gy - 58, 96, nm, on ? pal[1] : '#8b8f97');
      for (let x = 120; x < 330; x += 10) s += '<rect x="' + x + '" y="' + (gy - 14) + '" width="2" height="14" fill="#555a63"/>';
      s += '<rect x="120" y="' + (gy - 12) + '" width="210" height="1.5" fill="#555a63"/>';
      const n = on ? Math.max(1, Math.min(5, Math.round(2 + u * 3))) : 0;
      for (let i = 0; i < n; i++) s += van(130 + i * 40, gy - 30, ['#7aa5d6', '#d08a6a', '#93b8a0', '#e6e1d6', '#c4a47c'][i], '', 'car');
    } else {
      /* a tall building: hotel, casino, head office */
      const bw = 110, bh = 112, bx = 115, by = gy - bh;
      s += '<rect x="' + bx + '" y="' + by + '" width="' + bw + '" height="' + bh + '" fill="#3a3448"/>';
      for (let f = 0; f < 7; f++) for (let c = 0; c < 5; c++) s += '<rect x="' + (bx + 10 + c * 19) + '" y="' + (by + 22 + f * 12) + '" width="10" height="7" fill="' + (on ? lit(u, f * 5 + c, 35) : '#3a3d44') + '" opacity=".85"/>';
      s += label(170, by + 3, 104, nm, on ? pal[1] : '#8b8f97') + street(340, 150, gy) + '<rect x="160" y="' + (gy - 14) + '" width="20" height="14" fill="#141518"/>';
      for (let i = 0; i < Math.min(5, Math.round(u * 6)) && on; i++) s += person(132 - i * 13, gy + 14, ['#c4a47c', '#93b8a0', '#7aa5d6', '#d08a6a', '#e6e1d6'][i], 0.95);
    }
    return frame(co, s);
  }
  R28.shopSvg = shopSvg;
  R28.sceneOf = sceneOf;
  const ov0 = CT.ov;
  CT.ov = function (co, bd) {
    const h = ov0.apply(this, arguments);
    try {
      if (!co || co.type === 'hold') return h;
      const st = stageOf(co), u = co.lastW ? co.lastW.util || 0 : 0;
      const sc = sceneOf(co), pm = premOf(co), P0 = (typeof PREM !== 'undefined' && PREM[pm.kind]) || ['Premises'];
      const where = sc === 'home' ? 'Run from home' : sc === 'mobile' ? 'On the road' : P0[0].replace(/ \/.*$/, '') + (pm.m2 ? ' · ' + pm.m2 + ' m²' : '');
      const busy = st === 0 ? (co.st === 'setup' ? 'Getting ready to open' : 'Quiet for now') : u >= 0.82 ? (sc === 'store' ? 'Busy: customers queue at the door' : 'Busy: fully booked most days') : u >= 0.4 ? 'Steady work' : 'Finding its customers';
      return '<div class="card shopc28">' + shopSvg(co) + '<div class="bhead"><small>' + esc(busy) + '</small>' + pillp(esc(where), st === 3 ? 'amb' : st === 2 ? 'grn' : '') + '</div></div>' + h;
    } catch (e) { console.error(e); return h; }
  };

  /* ---------- a livelier day ---------- */
  const rd0 = window.R10DAY;
  if (rd0) window.R10DAY = function (d) {
    const r = rd0.apply(this, arguments);
    try { dayNotes(d); } catch (e) { console.error(e); }
    return r;
  };
  function dayNotes(d) {
    if (ui.untl) return;
    const L = [];
    let tot = 0;
    S.cos.forEach(co => {
      if (co.st !== 'open' || !co.dl || co.dl.w !== S.week) return;
      const x = co.dl.days[d];
      if (!x) return;
      tot += x.r || 0;
      if (x.u > 0) {
        const bd = BD[co.type], unit = String(bd.unit || 'customers').replace(/ sold$/, '');
        L.push({ co, u: x.u, r: x.r, t: '+' + (x.u >= 10 ? Math.round(x.u) : Math.round(x.u * 10) / 10) + ' ' + unitPl(unit, x.u) });
        co.best28 = co.best28 || 0;
        if (x.r > co.best28 * 1.0 && co.best28 > 0 && S.week - (co.wOpen || co.w0 || 0) > 8) { L[L.length - 1].best = 1; }
        if (x.r > co.best28) co.best28 = x.r;
        const cap = co.dl.cap || 0;
        if (cap > 0 && x.u >= cap / 7 * 0.98) L[L.length - 1].full = 1;
      }
    });
    L.sort((a, b) => b.r - a.r);
    const notes = [];
    L.slice(0, 3).forEach(x => notes.push([x.t, x.co.name + (x.best ? ' · best day ever!' : x.full ? ' · fully booked' : ''), x.r]));
    /* round 41: review notes come from the real reviews written today */
    ui.day28 = { k: S.week * 7 + d, tot: Math.round(tot), notes, at: Date.now() };
  }
  const home0 = V.home;
  V.home = function () {
    let h = home0.apply(this, arguments);
    try {
      const D = ui.day28;
      if (!D || ui.untl || Date.now() - D.at > 60000 || !D.notes.length) return h;
      const card = '<div class="day28"><div class="bhead"><span>Today</span><b class="cnt28" data-to="' + D.tot + '">' + mshort(D.tot) + '</b></div>' + D.notes.map((x, i) => '<div class="dl28" style="animation-delay:' + (0.15 + i * 0.12).toFixed(2) + 's"><b>' + esc(x[0]) + '</b><span>' + esc(x[1]) + '</span>' + (x[2] ? '<small>' + mshort(x[2]) + '</small>' : '') + '</div>').join('') + '</div>';
      const i = h.indexOf('<div class="advbar">');
      return i > 0 ? h.slice(0, i) + card + h.slice(i) : h;
    } catch (e) { return h; }
  };
  /* numbers count up when they appear */
  new MutationObserver(() => {
    document.querySelectorAll('.cnt28:not([data-done])').forEach(el => {
      el.setAttribute('data-done', '1');
      const to = +el.getAttribute('data-to') || 0, t0 = performance.now(), dur = 700;
      const step = t => { const k = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - k, 3); el.textContent = mshort(Math.round(to * e)); if (k < 1) requestAnimationFrame(step); };
      requestAnimationFrame(step);
    });
  }).observe(document.body, { childList: true, subtree: true });

  R7.afterWeek = R7.afterWeek || [];
  R7.afterWeek.push(() => { try { checkAch(); } catch (e) { console.error(e); } });
  const rd1 = window.R10DAY;
  if (rd1) window.R10DAY = function (d) { const r = rd1.apply(this, arguments); try { if (!ui.untl) checkAch(); } catch (e) { } return r; };
})();

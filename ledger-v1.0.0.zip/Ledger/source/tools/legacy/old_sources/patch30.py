# round 47
path = '/home/claude/w3/ledger.html'
T = '/home/claude/w3/tools/'
t = open(path, encoding='utf8').read()
def rep(a, b, n=1):
    global t
    assert t.count(a) == n, a[:60]
    t = t.replace(a, b)
# the luxury catalogue is shared with the web shop
rep("const SELL_FEE = 0.08;", "const SELL_FEE = 0.08; window.LUX47 = { LUX, LUXI, SELL_FEE };")
# share capital is company cash: it pays for part of the start, it is not a cost on top
rep("(o.form === 'AS' ? CC().asCapital + CC().asFee : 0);", "(o.form === 'AS' ? CC().asFee : 0); r.cap = o.form === 'AS' ? CC().asCapital : 0;")
rep("(r.wait || 0) + (o.form === 'AS' ? CC().asCapital + CC().asFee : 0), cc);", "(r.wait || 0) + (o.form === 'AS' ? CC().asFee : 0), cc);")
rep("row('Company capital and registration fee', nok(CC().asCapital + CC().asFee))", "row('Registration fee', nok(CC().asFee))")
rep("const rec = Math.round(est.total / 5000) * 5000;", "const rec = Math.round(Math.max(0, est.total - (st.form === 'AS' ? CC().asCapital + CC().asFee : 0)) / 5000) * 5000;")
rep("'Limited liability. Needs share capital ' + money(CC().asCapital) + ' and a '", "'Limited liability. Needs share capital of ' + money(CC().asCapital) + ', which stays in the company as its cash, and a '")
rep("<span class=\"lab\">You put into the company</span><b class=\"huge\">' + nok(c.asCapital) + '</b>'", "<span class=\"lab\">You put into the company</span><b class=\"huge\">' + nok(c.asCapital) + '</b><span class=\"lab\">It stays in the company as cash it can spend</span>'")
mark = '/* ---------- no zooming: pinch, double tap, ctrl+wheel, ctrl +/- ---------- */'
assert t.count(mark) == 1
import base64, os, json
imgs = {}
for f in sorted(os.listdir(T + 'cars47')):
    if f.endswith('.webp'): imgs[f[:-5]] = 'data:image/webp;base64,' + base64.b64encode(open(T + 'cars47/' + f, 'rb').read()).decode()
t = t.replace(mark, 'window.CARIMG47 = ' + json.dumps(imgs) + ';\n' + open(T + 'round47.js', encoding='utf8').read() + '\n' + mark)
i = t.rindex('</style>')
t = t[:i] + open(T + 'round47.css', encoding='utf8').read() + '\n' + t[i:]
open(path, 'w', encoding='utf8').write(t)
print('patch30 ok')

path = '/home/claude/w3/ledger.html'
t = open(path, encoding='utf8').read()
def rep(old, new, count=1):
    global t
    n = t.count(old)
    if n != count: raise SystemExit('MATCH %d (want %d): %s' % (n, count, old[:110]))
    t = t.replace(old, new)
# decision cards show stat boxes when a proposal carries them
rep("""    const money2 = opts.filter(o => o.fx && (o.fx.cash || o.fx.loss || o.fx.fine)).slice(0, 2);
    if (money2.length) h += """, """    const money2 = opts.filter(o => o.fx && (o.fx.cash || o.fx.loss || o.fx.fine)).slice(0, 2);
    if (m.stats) h += '<div class="duo">' + m.stats.map(x => '<div><span>' + esc(x[0]) + '</span><b class="' + (/^~?−/.test(x[1]) ? 'neg' : /revenue/i.test(x[0]) ? 'pos' : '') + '">' + esc(x[1]) + '</b></div>').join('') + '</div>';
    else if (money2.length) h += """)
# managers can be moved between companies
rep("""btn('Give raise', 'mgrraise', { id: co.id }, 'chip') + btn('Replace', 'mgrfire', { id: co.id }, 'chip ghost danger')""",
    """btn('Give raise', 'mgrraise', { id: co.id }, 'chip') + btn('Move', 'mgrmove', { id: co.id }, 'chip') + btn('Replace', 'mgrfire', { id: co.id }, 'chip ghost danger')""")
# every worker card opens the raise / warn / lay off screen
rep("""'<div class="btnrow">' + btn('Raise', 'raisesheet', { id: co.id, s: s.id }, 'chip')""",
    """'<div class="btnrow">' + btn('Raise, warn, lay off', 'go', { n: 'staffman', p: { id: co.id, s: s.id } }, 'chip primary') + btn('Raise', 'raisesheet', { id: co.id, s: s.id }, 'chip')""")
# problem card: warn or let go, like the mockup
rep("""btn('Talk to them', 'talkstaff', { id: co.id, s: s.id }, 'wide') + btn('Let go', 'firestaff', { id: co.id, s: s.id }, 'wide')""",
    """btn('Warn', 'warnstaff', { id: co.id, s: s.id }, 'wide') + btn('Let go', 'firestaff', { id: co.id, s: s.id }, 'wide')""")
# clients tab links to price moves
rep("""    let h = opsPart(co, bd, 'prices');""", """    let h = opsPart(co, bd, 'prices') + (co.st === 'open' ? btn('Price moves and rivals', 'go', { n: 'pricemoves', p: { id: co.id } }, 'wide') : '');""")
open(path, 'w', encoding='utf8').write(t)
print('patch6 ok')

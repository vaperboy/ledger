# round 48
path = '/home/claude/w3/ledger.html'
T = '/home/claude/w3/tools/'
t = open(path, encoding='utf8').read()
def rep(a, b, n=1):
    global t
    assert t.count(a) == n, a[:70]
    t = t.replace(a, b)
# growth rankings: every firm in the business register has a growth figure (change over the last quarter)
rep("a.sort(); a.reverse();", "a.sort(); a.reverse(); const g = new Float64Array(n); for (let i = 0; i < n; i++) { const z = Math.sqrt(-2 * Math.log(Math.max(1e-9, R()))) * Math.cos(2 * Math.PI * R()); g[i] = Math.max(-0.5, Math.min(0.8, 0.01 + 0.08 * z)); } g.sort(); g.reverse();")
rep("B.push({ cc, t, a, ur, m: Math.max(0.03, bd.m || 0.08) });", "B.push({ cc, t, a, g, ur, m: Math.max(0.03, bd.m || 0.08) });")
rep("const Bk = sort === 'gr' ? [] : crowd()", "const AR = b => sort === 'gr' ? b.g : b.a; const Bk = crowd()")
rep("n += above(Bk[k].a, (x - l[1]) / l[0]);", "n += above(AR(Bk[k]), (x - l[1]) / l[0]);")
rep("for (let i = 0; i < Math.min(50, b.a.length); i++) top.push([b.a[i] * l[0] + l[1], b, i]);", "for (let i = 0; i < Math.min(50, b.a.length); i++) top.push([AR(b)[i] * l[0] + l[1], b, i]);")
rep("j = above(b.a, (x - l[1]) / l[0]); for (let i = Math.max(0, j - 3); i < j; i++) up.push([b.a[i] * l[0] + l[1], b, i]); for (let i = j; i < Math.min(b.a.length, j + 3); i++) dn.push([b.a[i] * l[0] + l[1], b, i]);",
    "j = above(AR(b), (x - l[1]) / l[0]); for (let i = Math.max(0, j - 3); i < j; i++) up.push([AR(b)[i] * l[0] + l[1], b, i]); for (let i = j; i < Math.min(b.a.length, j + 3); i++) dn.push([AR(b)[i] * l[0] + l[1], b, i]);")
rep("types: [b.t], rev: v, profit: pf, val: vl, gr: 0,", "types: [b.t], rev: v, profit: pf, val: vl, gr: b.g ? b.g[i] : 0,")
# part-time staff: market pay for a part-timer is the full-time pay times their share of hours
rep("wageFor(s.role, co)", "(wageFor(s.role, co) * (s.pt || 1))", 7)
rep("d: 'About a quarter of a worker\\'s pay. Go to Find workers.'", "d: 'Half a worker\\'s pay for 20 hours a week. Opens Find workers.'")
mark = '/* ---------- no zooming: pinch, double tap, ctrl+wheel, ctrl +/- ---------- */'
assert t.count(mark) == 1
t = t.replace(mark, open(T + 'round48.js', encoding='utf8').read() + '\n' + mark)
open(path, 'w', encoding='utf8').write(t)
print('patch31 ok')

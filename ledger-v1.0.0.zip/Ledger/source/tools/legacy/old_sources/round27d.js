/* ===== Round 27d: owners who have a say.
   Outside investors have a profile (want dividends, want growth, want a sale, or stay quiet) and a mood that moves
   with results. Unhappy owners make demands. What happens when you say no depends on how many shares they hold:
   over half and they outvote you; over a third and they block big moves; less and they may sell their stake,
   sometimes to a rival group. Each company has a dividend policy, and managers get a yearly review where you can
   promote from inside or hire an expensive executive. ===== */
(function () {
  const R27 = window.R27 = window.R27 || {};
  const U = window.UI, { toast, save, render, svg, row } = U;
  const P = o => esc(JSON.stringify(o));
  const pillp = (t, c) => '<span class="pill ' + (c || '') + '">' + t + '</span>';
  const ini = n => String(n || '?').replace(/[^\p{L}0-9 ]/gu, ' ').trim().split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase() || '?';
  const sumF = (a, f) => a.reduce((t, x) => t + (f(x) || 0), 0);
  const MI = () => monthIdx(S.week);
  const PROF = { div: ['Wants dividends', 'amb'], growth: ['Wants growth', 'blue'], exit: ['Wants a sale', 'red'], quiet: ['Quiet', ''] };
  const PAYOUT = { none: 0, low: 0.25, mid: 0.5, high: 0.8 };
  const PAYN = { none: 'Reinvest everything', low: '25% of profit', mid: '50% of profit', high: '80% of profit' };

  /* ---------- investors ---------- */
  function prof(h) {
    if (!h.k27) {
      const x = hrng(S.seed + ':ip:' + h.name)();
      h.k27 = h.g27 ? 'exit' : /fund|capital|partners|invest|group|equity/i.test(h.name) ? (x < 0.5 ? 'exit' : 'growth') : x < 0.38 ? 'div' : x < 0.66 ? 'growth' : x < 0.78 ? 'exit' : 'quiet';
      h.sat = h.sat != null ? h.sat : 60;
      h.w0 = h.w0 || S.week;
    }
    return h.k27;
  }
  const outside = co => Math.max(0, 100 - (co.own || 100));
  R27.outside = outside;
  function holderSat(co) {
    const H = (co.holders || []).filter(h => h.pct > 0);
    if (!H.length) return 60;
    H.forEach(prof);
    return sumF(H, h => h.sat * h.pct) / Math.max(0.01, sumF(H, h => h.pct));
  }
  R27.holderSat = holderSat;
  const satW = s => s >= 70 ? ['Happy', 'pos'] : s >= 50 ? ['Content', ''] : s >= 35 ? ['Uneasy', 'amb'] : ['Angry', 'neg'];
  /* what the other owners can do, by their share */
  function power(co) {
    const o = outside(co);
    return o > 50 ? { k: 'control', t: 'They can outvote you: dividends, the manager, accepting a takeover bid.' } : o >= 33.4 ? { k: 'block', t: 'They can block big changes: selling the company, new shares, mergers.' } : o > 0 ? { k: 'voice', t: 'They have a voice and board seats, but you decide.' } : { k: 'none', t: 'You own it all.' };
  }
  R27.power = power;

  /* ---------- the quarter: dividends by policy, then the investors' mood ---------- */
  function qProfit(co) { return sumF((co.hist || []).slice(-3), x => x.profit); }
  function yoy(co) {
    const h = co.hist || [];
    if (h.length < 15) return null;
    const a = sumF(h.slice(-3), x => x.rev), b = sumF(h.slice(-15, -12), x => x.rev);
    return b > 0 ? a / b - 1 : null;
  }
  function quarter(co) {
    if (co.st !== 'open' || co.form !== 'AS' || co.type === 'hold') return;
    const pol = co.dp27 || 'none', pr = qProfit(co);
    let paid = 0;
    if (PAYOUT[pol] > 0 && pr > 0) {
      const amt = Math.round(pr * PAYOUT[pol] / 1000) * 1000;
      const r = amt > 0 ? payDividend(co, amt) : 'none';
      if (r === 'ok') { paid = amt; note(co.name + ' paid a dividend of ' + money(amt) + ' (' + PAYN[pol].toLowerCase() + ').', 'good', co.id); }
      else if (r === 'cash') note(co.name + ' skipped its dividend: not enough cash after costs.', 'n', co.id);
    }
    co.dq27 = { w: S.week, paid, pr };
    const H = (co.holders || []).filter(h => h.pct > 0);
    if (!H.length) return;
    const g = yoy(co), below = (window.R27 && R27.links ? R27.links().filter(l => l.s === co.id && l.mode !== 'mkt').length : 0);
    H.forEach(h => {
      const k = prof(h);
      let d = (60 - h.sat) * 0.05;
      if (pr < 0) d -= 4;
      if (k === 'div') d += paid > 0 && paid >= pr * 0.35 ? 6 : pr > 0 ? -6 : -2;
      if (k === 'growth') { d += g == null ? 0 : g > 0.1 ? 7 : g > 0.02 ? 2 : g < 0 ? -6 : -1; if (paid > pr * 0.6 && pr > 0) d -= 2; }
      if (k === 'exit') { const yrs = (S.week - h.w0) / 52; d += yrs > 3 ? -5 : g != null && g > 0.08 ? 3 : 0; }
      if (k === 'quiet') d *= 0.5;
      if (below) d -= 6 * below;
      if (co.mgr && co.mood != null && co.mood < 35) d -= 2;
      h.sat = clamp(Math.round(h.sat + d), 0, 100);
    });
    maybeDemand(co, H);
  }
  R27.quarter = quarter;

  /* ---------- demands ---------- */
  function maybeDemand(co, H) {
    if (S.week < (co.dm27 || 0)) return;
    const unhappy = H.filter(h => h.sat < 38).sort((a, b) => b.pct - a.pct)[0];
    if (!unhappy) return;
    co.dm27 = S.week + 26;
    const k = prof(unhappy), pr = Math.max(0, sumF((co.hist || []).slice(-12), x => x.profit)), V0 = Math.max(0, companyValue(co));
    const pw = power(co), o = outside(co);
    const tail = pw.k === 'control' ? ' Outside owners hold ' + Math.round(o) + '%, so they can push this through without you.' : pw.k === 'block' ? ' They hold ' + Math.round(o) + '% between them and can block your big moves if you refuse.' : ' They hold ' + Math.round(o) + '%. If you refuse, they may sell their stake to someone else.';
    let d;
    if (co.mgr && qProfit(co) < 0 && (k !== 'quiet')) d = { t: 'Replace the manager of ' + co.name, b: unhappy.name + ' says the company keeps losing money under ' + (S.npcs[co.mgr] ? S.npcs[co.mgr].name : 'its manager') + ' and wants a change.', opts: ['Replace the manager', 'Give them six more months', 'Refuse'], kind: 'mgr' };
    else if (k === 'div') d = { t: unhappy.name + ' wants a dividend from ' + co.name, b: 'They want ' + money(Math.round(pr * 0.5 / 1000) * 1000) + ' paid out (half of last year\'s profit) and a policy of regular dividends.', opts: ['Pay it, and set 50% as policy', 'Pay half now', 'Refuse: the money stays in the company'], kind: 'div', amt: Math.round(pr * 0.5 / 1000) * 1000 };
    else if (k === 'growth') d = { t: unhappy.name + ' wants ' + co.name + ' to grow faster', b: 'They want ' + money(Math.round(Math.max(KC(50000), (co.lastW ? co.lastW.rev : 0) * 6) / 1000) * 1000) + ' spent on marketing over the next three months, or a second site.', opts: ['Agree to the marketing push', 'Show them your own plan', 'Refuse'], kind: 'growth', amt: Math.round(Math.max(KC(50000), (co.lastW ? co.lastW.rev : 0) * 6) / 1000) * 1000 };
    else if (k === 'exit') d = { t: unhappy.name + ' wants out of ' + co.name, b: 'They have held their ' + unhappy.pct.toFixed(1) + '% for ' + Math.round((S.week - unhappy.w0) / 52) + ' years and want their money back: sell the company, or buy their stake for about ' + money(Math.round(V0 * unhappy.pct / 100 * 1.1 / 1000) * 1000) + '.', opts: ['Buy their stake', 'Sell the whole company', 'Refuse'], kind: 'exit', amt: Math.round(V0 * unhappy.pct / 100 * 1.1 / 1000) * 1000, hn: unhappy.name };
    else return;
    addMsg({ kind: 'ask', from: unhappy.name + ', shareholder', title: d.t, body: d.b + tail, co: co.id, opts: d.opts.map(l => ({ l, d: '', fx: {} })), act: 'own27', data: { co: co.id, kind: d.kind, amt: d.amt || 0, hn: d.hn || unhappy.name }, exp: S.week + 3, tone: 'bad' });
  }
  ACTS.own27 = (m, idx) => {
    const co = getCo(m.data.co);
    if (!co || co.st !== 'open') return true;
    resolveDemand(co, m.data, idx);
    return true;
  };
  function bump(co, v) { (co.holders || []).forEach(h => { prof(h); h.sat = clamp(h.sat + v, 0, 100); }); }
  function resolveDemand(co, d, idx) {
    const pw = power(co);
    if (d.kind === 'div') {
      if (idx === 0 || idx === 1) {
        const r = payDividend(co, idx === 0 ? d.amt : Math.round(d.amt / 2000) * 1000);
        if (r === 'ok') { if (idx === 0) co.dp27 = 'mid'; bump(co, idx === 0 ? 18 : 8); }
        else { note(co.name + ' could not pay: ' + (r === 'cash' ? 'not enough cash.' : 'not enough equity.'), 'bad', co.id); bump(co, -4); }
        return;
      }
      return refused(co, d, pw);
    }
    if (d.kind === 'growth') {
      if (idx === 0) { if (payCo(co, d.amt, 'mkt', 'Marketing push agreed with the owners') || co.cash > -coOverdraft(co)) { co.aware = Math.min(100, co.aware + 8); addMod(co, 'dem', 1.06, 13); bump(co, 15); } return; }
      if (idx === 1) { bump(co, chance(0.6) ? 8 : -2); co.dm27 = S.week + 26; return; }
      return refused(co, d, pw);
    }
    if (d.kind === 'exit') {
      const h = (co.holders || []).find(x => x.name === d.hn);
      if (idx === 0 && h) {
        if (S.cash < d.amt) { note('You do not have ' + money(d.amt) + ' to buy the stake.', 'bad', co.id); return refused(co, d, pw); }
        payMe(d.amt, 'Bought ' + h.name + '\'s stake in ' + co.name);
        co.own = Math.min(100, co.own + h.pct);
        co.holders = co.holders.filter(x => x !== h);
        note('You bought back ' + h.pct.toFixed(1) + '% of ' + co.name + '. You now own ' + Math.round(co.own) + '%.', 'good', co.id);
        return;
      }
      if (idx === 1) { sellOut(co, 'The owners agreed to sell'); return; }
      return refused(co, d, pw);
    }
    if (d.kind === 'mgr') {
      if (idx === 0) { replaceMgr(co, 'promote', true); bump(co, 12); return; }
      if (idx === 1) { co.mgrT27 = S.week + 26; bump(co, -2); return; }
      return refused(co, d, pw);
    }
  }
  function refused(co, d, pw) {
    bump(co, -10);
    if (pw.k === 'control') {
      note('The other owners of ' + co.name + ' outvoted you.', 'bad', co.id);
      if (d.kind === 'div') { payDividend(co, d.amt); co.dp27 = 'mid'; }
      else if (d.kind === 'growth') { payCo(co, d.amt, 'mkt', 'Marketing push forced by the owners'); co.aware = Math.min(100, co.aware + 8); }
      else if (d.kind === 'exit') sellOut(co, 'The majority owners voted to sell');
      else if (d.kind === 'mgr') replaceMgr(co, 'external', true);
      return;
    }
    if (pw.k === 'block') {
      co.block27 = S.week + 26;
      note('The other owners of ' + co.name + ' will block share sales, a sale of the company and mergers for half a year.', 'bad', co.id);
      return;
    }
    /* a small, unhappy owner sells: sometimes to a rival group */
    const H = (co.holders || []).filter(h => h.sat < 40);
    const h = H.sort((a, b) => b.pct - a.pct)[0];
    if (!h || !chance(0.5)) return;
    const gs = window.R27 && R27.groupsIn ? R27.groupsIn(co.country).filter(g => !g.dist && (g.types.indexOf(co.type) >= 0 || g.strat === 'acq')) : [];
    if (gs.length && chance(0.5)) {
      const g = gs[rint(0, gs.length - 1)];
      const old = h.name;
      h.name = g.name; h.g27 = g.id; h.k27 = 'exit'; h.sat = 45; h.w0 = S.week;
      addMsg({ kind: 'info', from: 'Shareholders of ' + co.name, title: g.name + ' now owns ' + h.pct.toFixed(1) + '% of ' + co.name, body: old + ' sold its stake to ' + g.name + ', a competitor. They will want a say, and may try to buy the rest.', co: co.id, tone: 'bad', status: 'done' });
    } else { const old = h.name; h.name = personName() + ', investor'; h.k27 = null; h.sat = 55; h.w0 = S.week; prof(h); note(old + ' sold its stake in ' + co.name + ' to ' + h.name + '.', 'n', co.id); }
  }
  function sellOut(co, why) {
    if (co.st !== 'open') return;
    const offers = saleOffers(co), o = offers.find(x => x.now) || offers[0];
    const res = acceptSale(co, o);
    if (res === 'ok') addMsg({ kind: 'info', from: 'Shareholders of ' + co.name, title: co.name + ' is sold', body: why + '. ' + o.buyer + ' paid ' + money(o.price) + '; your ' + Math.round(co.own) + '% came to ' + money(o.price * co.own / 100) + '.', co: co.id, tone: 'n', status: 'done' });
  }
  /* blocked moves: a blocking minority stops sales of the company and new shares */
  ['sellco', 'saleacc', 'sellsh'].forEach(a => {
    const f0 = ACT[a];
    if (!f0) return;
    ACT[a] = p => {
      const co = getCo(p && p.id);
      if (co && co.block27 > S.week && (a !== 'sellsh' || p.m === 'primary')) { toast('The other owners of ' + co.name + ' are blocking this until ' + dateStr(co.block27) + '.', true); return; }
      return f0(p);
    };
  });

  /* ---------- managers: the yearly review ---------- */
  function promoteInside(co) {
    const st = co.staff.slice().sort((a, b) => staffSkill(b) - staffSkill(a))[0];
    if (!st) return null;
    const n = S.npcs[st.id];
    if (!n) return null;
    const sk = staffSkill(st);
    n.stats = n.stats || {};
    ['ops', 'people', 'sales', 'fin', 'risk', 'ethic'].forEach(q => { n.stats[q] = clamp(Math.round((q === 'ops' ? sk + 5 : q === 'fin' ? sk - 18 : sk - 8) + rng(-8, 8)), 10, 90); });
    n.claimed = Object.assign({}, n.stats);
    n.mtype = BD[co.type].mgr || 'gen';
    n.role = 'manager';
    n.exp = Math.max(1, Math.round((S.week - (st.w0 || S.week)) / 52));
    co.staff = co.staff.filter(x => x !== st);
    n.hired = 0;
    const wage = Math.round(Math.max(st.wage * 1.3, wageFor(st.role, co) * 1.35) / 500) * 500;
    n.ask = wage;
    if (hireManager(co, n, wage) !== 'ok') return null;
    co.mood = Math.min(100, (co.mood || 60) + 8);
    return n;
  }
  function hireExec(co) {
    const n = genManager(co, BD[co.type].mgr || 'gen');
    ['ops', 'people', 'sales', 'fin', 'risk'].forEach(q => { n.stats[q] = clamp(n.stats[q] + rint(8, 16), 5, 97); });
    n.claimed = Object.assign({}, n.stats);
    n.lie = false;
    n.tier = 'senior';
    n.exp = Math.max(n.exp, 12);
    n.ask = Math.round(n.ask * 1.4 / 500) * 500;
    if (hireManager(co, n, n.ask) !== 'ok') return null;
    co.mood = 50;
    co.flags.exec27 = S.week + 8;
    payCo(co, n.ask * 2, 'oth', 'Executive search fee');
    return n;
  }
  function replaceMgr(co, how, forced) {
    const old = co.mgr && S.npcs[co.mgr];
    if (old) fireManager(co);
    const n = how === 'promote' ? promoteInside(co) || hireExec(co) : hireExec(co);
    addMsg({ kind: 'info', from: co.name, title: n ? n.name + ' now runs ' + co.name : co.name + ' has no manager', body: (old ? old.name + ' has gone. ' : '') + (n ? (how === 'promote' && n.exp < 12 ? n.name + ' was promoted from the team: cheaper, knows the place and the people, but new to running a business.' : n.name + ' is an experienced executive on ' + money(co.mgrWage) + ' a month. Expect a couple of months before it shows.') : 'Hire a new manager.'), co: co.id, tone: 'n', status: 'done' });
  }
  R27.replaceMgr = replaceMgr;
  function review(co) {
    const n = S.npcs[co.mgr];
    if (!n || co.st !== 'open') return;
    const g = yoy(co), pr = sumF((co.hist || []).slice(-12), x => x.profit), rev = sumF((co.hist || []).slice(-12), x => x.rev);
    const mg = rev > 0 ? pr / rev : 0, ind = BD[co.type].m || 0.1, mood = co.mood != null ? co.mood : 60;
    const score = (g == null ? 0 : clamp(g * 4, -1, 1)) + clamp((mg - ind * 0.7) * 8, -1.2, 1) + (mood - 55) / 60;
    const verdict = score > 0.6 ? 'strong' : score > -0.4 ? 'ok' : 'weak';
    const lines = 'Sales ' + (g == null ? 'too new to compare' : (g >= 0 ? 'up ' : 'down ') + Math.abs(Math.round(g * 100)) + '% on last year') + ', margin ' + Math.round(mg * 100) + '% (a typical ' + BD[co.type].n.toLowerCase() + ' makes about ' + Math.round(ind * 100) + '%), team morale ' + (mood >= 65 ? 'good' : mood >= 45 ? 'fair' : 'low') + '.';
    if (verdict !== 'weak' || co.mgrT27 > S.week) { info('Board of ' + co.name, 'Yearly review: ' + n.name + ' (' + (verdict === 'strong' ? 'strong year' : 'solid year') + ')', lines + (verdict === 'strong' ? ' The board suggests a bonus to keep them.' : ''), co.id, verdict === 'strong' ? 'good' : 'n'); if (verdict === 'strong') co.mood = Math.min(100, mood + 3); return; }
    const best = co.staff.slice().sort((a, b) => staffSkill(b) - staffSkill(a))[0], bn = best && S.npcs[best.id];
    addMsg({ kind: 'ask', from: 'Board of ' + co.name, title: 'Yearly review: ' + n.name + ' is falling short', body: lines + (outside(co) > 50 ? ' The other owners hold the majority and want a change.' : ''), co: co.id, opts: [{ l: 'Keep ' + n.name.split(' ')[0] + ', set clear targets', d: 'Another year to turn it around.', fx: {} }, { l: bn ? 'Promote ' + bn.name + ' from the team' : 'Promote from the team', d: 'Cheaper and knows the business, but untested as a manager.', fx: {} }, { l: 'Hire an experienced executive', d: 'About 40% above a normal manager, plus a search fee. Strong, but needs time to settle.', fx: {} }], act: 'rev27', data: { co: co.id }, exp: S.week + 3, tone: 'bad' });
  }
  ACTS.rev27 = (m, idx) => {
    const co = getCo(m.data.co);
    if (!co || !co.mgr) return true;
    if (idx === 0) { if (outside(co) > 50 && holderSat(co) < 45) { note('The majority owners of ' + co.name + ' overruled you.', 'bad', co.id); replaceMgr(co, 'external'); } else { co.mood = Math.max(0, (co.mood || 60) - 4); co.mgrT27 = S.week + 50; } return true; }
    replaceMgr(co, idx === 1 ? 'promote' : 'external');
    return true;
  };

  R7.afterWeek = R7.afterWeek || [];
  R7.afterWeek.push(() => {
    try {
      S.m27d = S.m27d || MI();
      if (S.m27d !== MI()) { S.m27d = MI(); if (MI() % 3 === 0) S.cos.forEach(quarter); }
      S.cos.forEach(co => { if (co.st === 'open' && co.mgr && co.mgrW0 != null && S.week > co.mgrW0 && (S.week - co.mgrW0) % 52 === 0) review(co); });
      S.inbox.forEach(m => {
        if (!m.auto || m.done27) return;
        if (m.act === 'own27') { m.done27 = 1; const co = getCo(m.data.co); if (co && co.st === 'open') refused(co, m.data, power(co)); }
        if (m.act === 'rev27') { m.done27 = 1; const co = getCo(m.data.co); if (co && co.mgr) ACTS.rev27(m, 0); }
      });
    } catch (e) { console.error(e); }
  });

  /* ---------- Owners and dividends screen ---------- */
  V.titles.own27 = 'Owners';
  V.heads = V.heads || {};
  V.heads.own27 = p => { const co = getCo(p.id); return { t: 'Owners and dividends', sub: co ? esc(co.name) : '' }; };
  V.own27 = function (p) {
    const co = getCo(p.id);
    if (!co) return '<div class="calm">Gone.</div>';
    const H = (co.holders || []).filter(h => h.pct > 0);
    H.forEach(prof);
    const pw = power(co), V0 = Math.max(0, companyValue(co));
    let h = '<div class="card"><div class="bhead"><b>You own ' + (Math.round(co.own * 10) / 10) + '%</b>' + pillp(pw.k === 'control' ? 'Minority' : pw.k === 'block' ? 'They can block' : pw.k === 'voice' ? 'You decide' : 'All yours', pw.k === 'control' ? 'red' : pw.k === 'block' ? 'amb' : 'grn') + '</div><span class="tipt">' + esc(pw.t) + (co.block27 > S.week ? ' Right now they are blocking big moves until ' + dateStr(co.block27) + '.' : '') + '</span></div>';
    h += '<h2 class="sec">Owners</h2><div class="lrows"><div class="lrow on"><span class="av me27">' + esc(ini(S.player.name)) + '</span><span class="ctext"><b>' + esc(S.player.name) + ' <small>(you)</small></b><small>' + (Math.round(co.own * 10) / 10) + '% · ' + money(V0 * co.own / 100) + '</small></span></div>' +
      H.map(x => { const s = satW(x.sat), pf = PROF[x.k27]; return '<div class="lrow"><span class="av">' + esc(ini(x.name)) + '</span><span class="ctext"><b>' + esc(x.name) + '</b><small>' + x.pct.toFixed(1) + '%' + (x.pct >= 20 ? ' · board seat' : '') + ' · <span class="' + s[1] + '">' + s[0] + '</span></small></span>' + pillp(pf[0], pf[1]) + '</div>'; }).join('') + '</div>';
    if (co.form === 'AS') {
      const pol = co.dp27 || 'none';
      h += '<h2 class="sec">Dividend policy</h2><div class="card"><div class="chips">' + Object.keys(PAYN).map(k => '<button class="btn chip' + (pol === k ? ' primary' : '') + '" data-a="own27pol" data-p="' + P({ id: co.id, v: k }) + '">' + PAYN[k] + '</button>').join('') + '</div><span class="tipt">Paid every quarter from that quarter\'s profit, if the cash is there. ' + (pol === 'none' ? 'Keeping the money builds a buffer and pays for growth without loans or new owners. ' : 'Dividends give you income (taxed as dividends) and keep income investors happy, but leave less for growth and bad times. ') + (H.some(x => x.k27 === 'div') ? 'Some of your co-owners want dividends.' : H.some(x => x.k27 === 'growth') ? 'Your co-owners would rather you reinvest.' : '') + '</span>' + (co.dq27 ? row('Last quarter', co.dq27.paid ? money(co.dq27.paid) + ' paid' : 'Nothing paid') : '') + '</div>';
    }
    if (H.length) h += '<h2 class="sec">Buy back</h2><div class="lrows">' + H.map(x => { const pr = Math.round(V0 * x.pct / 100 * (x.sat < 40 ? 1.0 : 1.12) / 1000) * 1000; return '<button class="lrow" data-a="own27buy" data-p="' + P({ id: co.id, n: x.name, pr }) + '"><span class="ctext"><b>Buy ' + esc(x.name) + '\'s ' + x.pct.toFixed(1) + '%</b><small>' + (x.sat < 40 ? 'Unhappy, so they would sell at value' : 'They want a premium') + '</small></span><b>' + mshort(pr) + '</b></button>'; }).join('') + '</div>';
    if (co.mgr && S.npcs[co.mgr]) h += '<h2 class="sec">Management</h2><div class="card">' + row('Manager', esc(S.npcs[co.mgr].name)) + row('Next yearly review', co.mgrW0 != null ? dateStr(co.mgrW0 + Math.ceil((S.week - co.mgrW0 + 1) / 52) * 52) : '–') + '</div>';
    return h;
  };
  ACT.own27pol = p => { const co = getCo(p.id); if (!co) return; co.dp27 = p.v; save(); render(); toast('Dividend policy: ' + PAYN[p.v].toLowerCase() + '.'); };
  ACT.own27buy = p => {
    const co = getCo(p.id), x = co && (co.holders || []).find(h => h.name === p.n);
    if (!x) return;
    confirmThen('Buy ' + x.pct.toFixed(1) + '% of ' + co.name + '?', 'You pay ' + money(p.pr) + ' from your own account.', 'Buy', () => {
      if (S.cash < p.pr) { toast('Not enough cash.', true); return; }
      payMe(p.pr, 'Bought ' + x.name + '\'s stake in ' + co.name);
      co.own = Math.min(100, co.own + x.pct);
      co.holders = co.holders.filter(h => h !== x);
      if (x.pct >= 20) co.flags.boardSeat = Math.max(0, (co.flags.boardSeat || 1) - 1);
      save(); render(true); toast('You now own ' + Math.round(co.own) + '% of ' + co.name + '.');
    });
  };
  const ov2 = CT.ov;
  CT.ov = function (co, bd) {
    const h = ov2.apply(this, arguments);
    try {
      if (!co || co.st !== 'open' || co.form !== 'AS' || co.type === 'hold') return h;
      const H = (co.holders || []).filter(x => x.pct > 0), s = holderSat(co);
      return h + '<div class="lrows"><button class="lrow" data-a="go" data-p="' + P({ n: 'own27', p: { id: co.id } }) + '"><span class="lic">' + svg('people', 20) + '</span><span class="ctext"><b>Owners and dividends</b><small>' + (H.length ? 'You ' + Math.round(co.own) + '% · ' + H.length + ' other owner' + (H.length > 1 ? 's' : '') + ' · ' + satW(s)[0].toLowerCase() : 'All yours') + ' · ' + PAYN[co.dp27 || 'none'].toLowerCase() + '</small></span>' + (H.length && s < 38 ? pillp('Unhappy', 'red') : '') + '<i>›</i></button></div>';
    } catch (e) { console.error(e); return h; }
  };
})();

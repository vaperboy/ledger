/* ===== Round 27a: rival groups that play the game too, and a ranking of the biggest companies.
   Each country has about ten named groups. Each has an owner, a strategy, cash, debt, an ambition and a history.
   They own many of the local rivals you meet, and every month some of them make a move: cut prices beside you,
   open next door, buy an independent rival or one of your suppliers, try to hire your manager, go abroad,
   or bid for one of your companies. Groups that overreach get into trouble and sell assets cheaply. ===== */
window.R27 = window.R27 || {};
(function () {
  const R27 = window.R27;
  const U = window.UI, { toast, save, render, svg, row, spark } = U;
  const P = o => esc(JSON.stringify(o));
  const pillp = (t, c) => '<span class="pill ' + (c || '') + '">' + t + '</span>';
  const ini = n => String(n || '?').replace(/[^\p{L}0-9 ]/gu, ' ').trim().split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase() || '?';
  const MI = () => monthIdx(S.week);
  const sumF = (a, f) => a.reduce((t, x) => t + (f(x) || 0), 0);
  const LOCALF = { svc: 1, venue: 1, retail: 1, project: 1, prod: 1, logi: 1 };

  /* ---------- strategies ---------- */
  const STRAT = {
    cost: { n: 'Cost leader', c: 'amb', d: 'Low prices and thin margins. Wins on volume.', m: 0.055, g: 0.006, lev: 0.5, w: { undercut: 6, beside: 2, buyrival: 1, buysup: 2, poach: 1, abroad: 1, bid: 1, campaign: 1 } },
    premium: { n: 'Premium', c: 'blue', d: 'Higher prices, better quality, a strong brand.', m: 0.14, g: 0.005, lev: 0.3, w: { campaign: 4, poach: 1.5, beside: 1, buyrival: 1, abroad: 2, bid: 1, raise: 3 } },
    acq: { n: 'Acquirer', c: 'red', d: 'Grows by buying others, often with borrowed money.', m: 0.08, g: 0.004, lev: 0.9, w: { buyrival: 6, buysup: 3, bid: 5, abroad: 1, poach: 0.5 } },
    expand: { n: 'Aggressive expander', c: 'red', d: 'Opens new sites fast and takes risks.', m: 0.07, g: 0.011, lev: 0.8, w: { beside: 6, undercut: 2, abroad: 3, campaign: 2, poach: 1 } },
    cautious: { n: 'Cautious', c: '', d: 'Slow and steady, with a strong balance sheet.', m: 0.11, g: 0.003, lev: 0.15, w: { campaign: 2, raise: 2, buyrival: 1 } }
  };
  R27.STRAT = STRAT;
  const GRPW = { NO: 'Gruppen', SE: 'Gruppen', DE: 'Gruppe', FR: 'Groupe', ES: 'Grupo', BR: 'Grupo', PL: 'Grupa', LT: 'Grupė', NL: 'Groep' };
  const STOP = /^(AS|ASA|AB|ApS|Oy|GmbH|AG|KG|Ltd|PLC|LLC|Inc\.?|Corp\.?|Co\.?|SA|S\.A\.|SL|SAS|SARL|BV|NV|UAB|Sp\.|z|o\.o\.|Ltda\.?|K\.K\.|&|og|och|und|and|de|da|do|la|le|el|van|der)$/i;

  /* ---------- the world of groups ---------- */
  function W() {
    S.g27 = S.g27 || { g: {}, cc: {}, n: 0, m: MI(), vown: {}, cool: {}, sent: 0, sentM: MI() };
    return S.g27;
  }
  R27.W = W;
  const G = id => W().g[id];
  R27.G = G;
  function okTypes(cc) {
    return Object.keys(BD).filter(t => { const bd = BD[t]; if (!bd || !LOCALF[bd.fam] || !bd.Dc) return false; try { return legalStatus(t, cc).ok; } catch (e) { return true; } });
  }
  function unitRev(t, cc) {
    const bd = BD[t], C = CO[cc] || CC();
    const dem = C.cities && C.cities.length ? sumF(C.cities, c => c.dem) / C.cities.length : 1;
    return (bd.Dc || 1) * bd.ticket * dem * 0.9 * 52 * (C.pl || 1);
  }
  function brandRoot(t, cc, R) {
    const C = CO[cc] || CC(), cities = C.cities.filter(c => c.id !== 'small');
    for (let g = 0; g < 8; g++) {
      const save = S.rs; S.rs = Math.floor(R() * 1e9) | 0;
      let nm = '';
      try { nm = rivalName(BD[t], cities[Math.floor(R() * cities.length)].id, cc); } catch (e) { }
      S.rs = save;
      const w = nm.split(/\s+/).filter(x => x.length >= 3 && x.indexOf('.') < 0 && /^\p{Lu}/u.test(x) && !STOP.test(x));
      if (w.length) return w.slice(0, w[0].length < 5 && w[1] ? 2 : 1).join(' ');
    }
    return C.name;
  }
  /* about ten groups per country, the same every time for this game */
  function ensureCC(cc) {
    const w = W();
    if (w.cc[cc]) return w.cc[cc];
    const C = CO[cc];
    if (!C) return [];
    const types = okTypes(cc), out = [];
    const SK = Object.keys(STRAT);
    for (let i = 0; i < 10; i++) {
      const R = hrng(S.seed + ':g27:' + cc + ':' + i);
      const t0 = types[Math.floor(R() * types.length)];
      const fam = BD[t0].fam;
      const sib = types.filter(t => t !== t0 && (BD[t].fam === fam || R() < 0.12));
      const ts = [t0];
      const nT = 1 + Math.floor(R() * 2.6);
      while (ts.length < nT && sib.length) { const k = sib.splice(Math.floor(R() * sib.length), 1)[0]; ts.push(k); }
      const strat = SK[Math.floor(R() * SK.length)];
      const br = Math.round(Math.exp(1.6 + R() * 3.1));
      const rev = br * sumF(ts, t => unitRev(t, cc)) / ts.length * (0.7 + R() * 0.6);
      const st = STRAT[strat];
      const root = brandRoot(t0, cc, R);
      let name = root + ' ' + (GRPW[cc] || 'Group');
      if (Object.values(w.g).some(o => o.cc === cc && (o.name === name || o.brand === root))) { const r2 = brandRoot(ts[1] || t0, cc, R); name = (r2 !== root ? r2 : root + ' ' + (CO[cc].cities[i % CO[cc].cities.length].name)) + ' ' + (GRPW[cc] || 'Group'); }
      const g = {
        id: 'g' + cc + i, cc, name, brand: root, owner: C.first[Math.floor(R() * C.first.length)] + ' ' + C.last[Math.floor(R() * C.last.length)],
        strat, types: ts, br, rev: Math.round(rev), m: st.m * (0.8 + R() * 0.4),
        cash: Math.round(rev * (0.04 + R() * 0.18)), debt: Math.round(rev * st.lev * (0.4 + R() * 0.9)),
        cs: [cc], amb: null, mv: [], rh: [], prev: null, f0: wYear(S.week) - 5 - Math.floor(R() * 60), dist: 0, mg: 0, listed: R() < 0.3
      };
      g.amb = ambitionFor(g, R);
      out.push(g.id);
      w.g[g.id] = g;
    }
    w.cc[cc] = out;
    return out;
  }
  R27.ensureCC = ensureCC;
  function ambitionFor(g, R) {
    const C = CO[g.cc], city = C.cities[Math.floor(R() * Math.min(3, C.cities.length))];
    const t = g.types[0];
    const k = g.strat === 'acq' ? 'buy' : g.strat === 'expand' ? (R() < 0.5 ? 'abroad' : 'top') : g.strat === 'premium' ? 'brand' : g.strat === 'cost' ? 'top' : 'steady';
    return { k, t, city: city.id, cc: g.cc, txt: k === 'buy' ? 'Buy up ' + BD[t].n.toLowerCase() + ' businesses across ' + C.name : k === 'abroad' ? 'Go international' : k === 'top' ? 'No. 1 in ' + BD[t].n.toLowerCase() + ' in ' + city.name : k === 'brand' ? 'The best-known name in ' + BD[t].n.toLowerCase() : 'Stay independent and profitable' };
  }
  /* groups active in a country: its own, plus any that came from abroad */
  function groupsIn(cc) {
    ensureCC(cc);
    return Object.values(W().g).filter(g => g.cs.indexOf(cc) >= 0 && !g.gone);
  }
  R27.groupsIn = groupsIn;
  function myCountries() {
    const s = {};
    S.cos.forEach(c => { if (c.st === 'open' || c.st === 'setup') s[c.country] = 1; });
    s[S.country] = 1;
    return Object.keys(s);
  }
  R27.myCountries = myCountries;

  /* ---------- which local rivals belong to a group ---------- */
  function assign(co, r) {
    if (r.g27 !== undefined) return;
    const cand = groupsIn(co.country).filter(g => g.types.indexOf(co.type) >= 0);
    const h = hrng(S.seed + ':ga:' + r.id)();
    if (!cand.length) {
      /* nobody covers this trade here yet: sometimes an acquirer or expander already has a foot in it */
      const k = groupsIn(co.country).filter(g => (g.strat === 'acq' || g.strat === 'expand') && g.types.length < 4);
      if (k.length && h < 0.35 && r.size > 0.8) { const g = k[Math.floor(h * 997) % k.length]; g.types.push(co.type); r.g27 = g.id; return; }
      r.g27 = 0;
      return;
    }
    const p = r.size > 1.1 ? 0.62 : r.size > 0.8 ? 0.45 : 0.25;
    r.g27 = h < p ? cand[Math.floor(h * 1009) % cand.length].id : 0;
  }
  const rv0 = window.rivalsOf;
  window.rivalsOf = function (co) {
    const L = rv0.apply(this, arguments);
    try { if (co && co.country && L) L.forEach(r => assign(co, r)); } catch (e) { console.error(e); }
    return L;
  };
  const grpOf = r => r && r.g27 ? G(r.g27) : null;
  R27.grpOf = grpOf;
  /* every rival a group has in your markets */
  function membersInMyMarkets(g) {
    const out = [];
    S.cos.forEach(co => {
      if (co.st !== 'open' || !LOCALF[(BD[co.type] || {}).fam]) return;
      const m = S.mk[mkKey(co)];
      if (!m || !m.riv) return;
      m.riv.forEach(r => { if (r.g27 === g.id && !out.some(o => o.r === r)) out.push({ co, r }); });
    });
    return out;
  }
  R27.membersInMyMarkets = membersInMyMarkets;

  /* ---------- money words ---------- */
  const cashW = g => g.cash > g.rev * 0.15 ? 'Strong' : g.cash > g.rev * 0.05 ? 'Solid' : g.cash > 0 ? 'Tight' : 'Very tight';
  const debtW = g => g.debt > g.rev * 1.1 ? 'Very high' : g.debt > g.rev * 0.6 ? 'High' : g.debt > g.rev * 0.25 ? 'Moderate' : 'Low';
  const profitOf = g => g.rev * g.m - g.debt * (policy() + 0.025);
  const valueOf = g => Math.max(0, profitOf(g) * (g.strat === 'premium' ? 11 : g.strat === 'cautious' ? 10 : 8) + g.cash - g.debt * 0.5);
  R27.profitOf = profitOf; R27.valueOf = valueOf;
  /* weeks they could keep prices low */
  const holdW = g => clamp(Math.round(6 + (g.cash / Math.max(1, g.rev)) * 90 - (g.debt / Math.max(1, g.rev)) * 6), 3, 40);
  R27.holdW = holdW;

  /* ---------- the monthly life of a group ---------- */
  function groupMonth(g, home) {
    const st = STRAT[g.strat], dem = home ? (S.econ.dem || 1) : 1;
    const R = hrng(S.seed + ':gm:' + g.id + ':' + MI());
    g.prev = { rev: g.rev, profit: profitOf(g), val: valueOf(g), m: MI() };
    const grow = st.g * (0.6 + R() * 0.8) + (dem - 1) * 0.08 + (g.dist ? -0.006 : 0);
    g.rev = Math.round(g.rev * (1 + grow));
    g.m = clamp(g.m + (R() - 0.5) * 0.01 + (dem - 1) * 0.02 + (st.m - g.m) * 0.1, -0.08, 0.3);
    const p = profitOf(g) / 12;
    g.cash = Math.round(g.cash + p * (g.listed ? 0.6 : 0.75));
    if (g.cash < 0) { g.debt = Math.round(g.debt - g.cash); g.cash = 0; }
    /* pay down debt when cash piles up */
    if (g.cash > g.rev * 0.25 && g.debt > 0) { const d = Math.min(g.debt, g.cash - g.rev * 0.15); g.debt -= Math.round(d); g.cash -= Math.round(d); }
    g.br = Math.max(1, Math.round(g.br * (1 + grow)));
    g.rh.push(Math.round(g.rev));
    if (g.rh.length > 24) g.rh.shift();
    /* trouble: losses and heavy debt */
    const lev = g.debt / Math.max(1, g.rev);
    if (!g.dist && lev > 1.15 && profitOf(g) < 0) { g.dist = S.week; onDistress(g); }
    else if (g.dist && lev < 0.8 && profitOf(g) > 0) { g.dist = 0; note(g.name + ' has recovered from its money troubles.', 'n'); }
    else if (g.dist && S.week - g.dist > 52 && lev > 1.4) onCollapse(g);
  }
  R27.groupMonth = groupMonth;

  /* ---------- moves ---------- */
  function cooldown(k, w) { const c = W().cool; if (c[k] && S.week < c[k]) return false; c[k] = S.week + w; return true; }
  function canSend() {
    const w = W();
    if (w.sentM !== MI()) { w.sentM = MI(); w.sent = 0; }
    return w.sent < 3;
  }
  function sent() { W().sent++; }
  function logMove(g, t, cc) { g.mv.unshift({ w: S.week, t, cc: cc || g.cc }); if (g.mv.length > 10) g.mv.length = 10; }
  R27.logMove = logMove;
  function pickW(w, R) {
    const ks = Object.keys(w), tot = sumF(ks, k => w[k]);
    let x = R() * tot;
    for (const k of ks) { if (x < w[k]) return k; x -= w[k]; }
    return ks[0];
  }
  /* a market of yours this group competes in (or could) */
  /* round 37: a newcomer is invisible to the big players until it takes a real share of the market */
  function coShare(co) {
    try {
      const mine = window.R26 && R26.annRev ? R26.annRev(co) : ((co.bk && co.bk.w && co.bk.w.rev) || 0) * 52;
      const theirs = (rivalsOf(co) || []).reduce((s, r) => s + R7.truth(co, r).rev, 0);
      return mine > 0 ? mine / (mine + theirs) : 0;
    } catch (e) { return 0; }
  }
  function noticed(co) {
    if (!co || co.st !== 'open') return false;
    const age = S.week - (co.wOpen != null ? co.wOpen : co.w0 != null ? co.w0 : S.week), sh = coShare(co);
    return (age >= 26 && sh >= 0.12) || sh >= 0.22 || !!(co.flags && co.flags.pw);
  }
  R27.coShare = coShare;
  R27.noticed = noticed;
  function targets(g) {
    return S.cos.filter(c => c.st === 'open' && g.cs.indexOf(c.country) >= 0 && g.types.indexOf(c.type) >= 0 && LOCALF[(BD[c.type] || {}).fam] && noticed(c));
  }
  const MOVES = {};
  MOVES.undercut = g => {
    const M = membersInMyMarkets(g).filter(x => !x.r.uc27 && x.co.st === 'open' && noticed(x.co));
    if (!M.length || g.dist) return false;
    const x = M[rint(0, M.length - 1)];
    if (!cooldown('uc:' + mkKey(x.co), 20)) return false;
    const pct = g.strat === 'cost' ? rint(15, 25) : rint(10, 18);
    const wk = Math.min(holdW(g), rint(8, 16));
    initR18(x.r);
    x.r.uc27 = { end: S.week + wk, pct, from: x.r.pm16, co: x.co.id, w: S.week };
    x.r.pm16 = clamp(Math.round(x.r.pm16 * (1 - pct / 100) * 1000) / 1000, 0.6, 1.6);
    x.co.mods.push({ k: 'dem', m: 1 - pct / 300, w: wk, t27: x.r.id });
    x.co.flags.uc27 = { r: x.r.id, end: S.week + wk, pct };
    logMove(g, 'Cut prices ' + pct + '% in ' + cityOf(x.co.city).name + ' (' + x.r.name + ')', x.co.country);
    addMsg({ kind: 'info', from: 'Market', title: x.r.name + ' cut prices ' + pct + '%', body: x.r.name + ', part of ' + g.name + ', cut its prices about ' + pct + '% in ' + cityOf(x.co.city).name + ', right where ' + x.co.name + ' competes. Some of your customers will try them. ' + g.name + ' can probably keep this up for about ' + wk + ' weeks.', co: x.co.id, tone: 'bad', status: 'done', go: { l: 'Respond', a: 'go', p: { n: 'rivmoves', p: { id: x.co.id, r: x.r.id } } } });
    sent();
    return true;
  };
  MOVES.beside = g => {
    const T = targets(g).filter(c => (c.lastW && c.lastW.util > 0.7) || ratingOf(c) >= 3.8);
    if (!T.length || g.dist || g.cash < g.rev * 0.02) return false;
    const co = T[rint(0, T.length - 1)];
    if (!cooldown('bs:' + mkKey(co), 40)) return false;
    const m = ensureMk(co);
    rivalsOf(co);
    const r = { id: uid(), name: g.brand + ' ' + cityOf(co.city).name, owner: g.owner, size: Math.round(rng(0.75, 1.1) * 100) / 100, rel: 35, listed: false, ign: 0, lock: 0, meet: -99, g27: g.id, new27: S.week };
    m.riv.push(r);
    m.n++;
    addMod(co, 'dem', 0.93, 26);
    g.cash -= Math.round(unitRev(co.type, co.country) * 0.25);
    g.br++;
    logMove(g, 'Opened ' + r.name + ' next to ' + co.name, co.country);
    addMsg({ kind: 'info', from: 'Market', title: g.name + ' opens next to ' + co.name, body: g.name + ' opened ' + r.name + ' a few doors from ' + co.name + '. They saw your customers queuing. Expect fewer walk-ins for a while.', co: co.id, tone: 'bad', status: 'done', go: { l: 'See them', a: 'go', p: { n: 'rival', p: { id: co.id, r: r.id } } } });
    sent();
    return true;
  };
  MOVES.buyrival = g => {
    const opts = [];
    targets(g).forEach(co => (rivalsOf(co) || []).forEach(r => { if (!r.g27 && !r.uc27) opts.push({ co, r }); }));
    if (!opts.length || g.dist) return false;
    const x = opts[rint(0, opts.length - 1)];
    const price = rivalValue(x.co, x.r) * rng(1.0, 1.3);
    if (g.cash + g.rev * 0.3 < price) return false;
    if (!cooldown('br:' + mkKey(x.co), 30)) return false;
    x.r.g27 = g.id;
    x.r.size = Math.round(x.r.size * 1.08 * 100) / 100;
    initR18(x.r);
    if (g.strat === 'cost') x.r.pm16 = clamp(x.r.pm16 * 0.94, 0.6, 1.6);
    if (g.strat === 'premium') x.r.pm16 = clamp(x.r.pm16 * 1.06, 0.6, 1.6);
    x.r.listed = false;
    payG(g, price);
    g.br++;
    logMove(g, 'Bought ' + x.r.name + ' in ' + cityOf(x.co.city).name, x.co.country);
    note(g.name + ' bought ' + x.r.name + ' in ' + cityOf(x.co.city).name + '. ' + (g.strat === 'cost' ? 'Expect lower prices there.' : g.strat === 'premium' ? 'They will take it upmarket.' : 'It now has a big group behind it.'), 'bad', x.co.id);
    news(g.name + ' buys ' + x.r.name + '.', 'n');
    return true;
  };
  MOVES.buysup = g => {
    const T = targets(g).filter(c => typeof goodsEff === 'function');
    if (!T.length || g.dist) return false;
    const co = T[rint(0, T.length - 1)];
    let v = null;
    try { v = goodsEff(co).v; } catch (e) { }
    if (!v || W().vown[v.id] || co.int27g) return false;
    if (!cooldown('sup:' + v.id, 80)) return false;
    W().vown[v.id] = g.id;
    payG(g, g.rev * 0.08);
    logMove(g, 'Bought the supplier ' + v.name, co.country);
    const hit = S.cos.filter(c => c.st === 'open' && (() => { try { const e = goodsEff(c); return e.v && e.v.id === v.id; } catch (er) { return false; } })());
    addMsg({ kind: 'info', from: 'Market', title: g.name + ' bought your supplier ' + v.name, body: v.name + ', which supplies ' + hit.map(c => c.name).join(', ') + ', now belongs to ' + g.name + ', a competitor. Prices to you go up about 6% and deliveries come second to their own shops. You can switch supplier in Suppliers, or supply yourself.', co: co.id, tone: 'bad', status: 'done', go: { l: 'Suppliers', a: 'go', p: { n: 'suppliers' } } });
    sent();
    return true;
  };
  MOVES.poach = g => {
    const T = S.cos.filter(c => c.st === 'open' && c.mgr && S.npcs[c.mgr] && g.cs.indexOf(c.country) >= 0 && !(S.npcs[c.mgr].ret27 > S.week) && (g.types.indexOf(c.type) >= 0 || BD[c.type].fam === BD[g.types[0]].fam));
    if (!T.length) return false;
    const co = T.sort((a, b) => mgrQual(b) - mgrQual(a))[0];
    if (mgrQual(co) < 0.45 || (R27.perk && R27.perk('dynasty') >= 0 && chance(0.5)) || !cooldown('po:' + co.id, 78) || !cooldown('po:all', 26)) return false;
    const n = S.npcs[co.mgr], offer = Math.round((co.mgrWage || n.ask) * rng(1.18, 1.35) / 500) * 500;
    logMove(g, 'Tried to hire ' + n.name + ' from ' + co.name, co.country);
    addMsg({ kind: 'ask', from: n.name, title: g.name + ' wants to hire your manager', body: n.name + ', who runs ' + co.name + ', has an offer from ' + g.name + ': ' + money(offer) + ' a month, against ' + money(co.mgrWage || 0) + ' now. ' + n.name.split(' ')[0] + ' likes it here, but the money is good.', co: co.id, opts: [{ l: 'Match it', d: 'Pay ' + money(offer) + ' a month from now on.', fx: {} }, { l: 'A retention bonus', d: 'Three months\' pay now. Most stay for at least a year; some still go.', fx: {} }, { l: 'Let them go', d: 'They leave in two weeks. You need a new manager.', fx: {} }], act: 'g27poach', data: { co: co.id, n: n.id, g: g.id, offer }, exp: S.week + 2, tone: 'bad' });
    sent();
    return true;
  };
  MOVES.abroad = g => {
    if (g.dist || g.cash < g.rev * 0.05 || g.br < 12 || g.cs.length >= 4 || !cooldown('ab:' + g.id, 78)) return false;
    const mine = myCountries().filter(c => g.cs.indexOf(c) < 0 && CO[c]);
    const all = Object.keys(CO).filter(c => g.cs.indexOf(c) < 0);
    const pool = mine.length && chance(0.6) ? mine : all;
    if (!pool.length) return false;
    const cc = pool[rint(0, pool.length - 1)];
    g.cs.push(cc);
    payG(g, g.rev * 0.05);
    logMove(g, 'Entered ' + CO[cc].name, cc);
    const here = myCountries().indexOf(cc) >= 0;
    news(g.name + ' expands into ' + CO[cc].name + '.', here ? 'bad' : 'n');
    if (here && canSend()) { info('Market', g.name + ' enters ' + CO[cc].name, g.name + ' (' + STRAT[g.strat].n.toLowerCase() + ', ' + g.br + ' sites at home) is coming to ' + CO[cc].name + '. In ' + g.types.map(t => BD[t].n.toLowerCase()).join(' and ') + ', expect a new, well-funded competitor.', 0, 'bad'); sent(); }
    return true;
  };
  MOVES.campaign = g => {
    const M = membersInMyMarkets(g).filter(x => !x.r.mkt16);
    if (!M.length) return false;
    const x = M[rint(0, M.length - 1)];
    x.r.mkt16 = S.week + rint(4, 10);
    logMove(g, 'Marketing push for ' + x.r.name, x.co.country);
    note(g.name + ' started a big marketing push for ' + x.r.name + ' in ' + cityOf(x.co.city).name + '.', 'n', x.co.id);
    return true;
  };
  MOVES.raise = g => {
    const M = membersInMyMarkets(g);
    if (!M.length) return false;
    M.forEach(x => { initR18(x.r); x.r.pm16 = clamp(x.r.pm16 * 1.06, 0.6, 1.6); });
    logMove(g, 'Raised prices about 6%', M[0].co.country);
    note(g.name + ' raised its prices about 6%. Price-sensitive customers may look for an alternative, like you.', 'good', M[0].co.id);
    return true;
  };
  MOVES.bid = g => {
    if (g.dist) return false;
    const T = S.cos.filter(c => c.st === 'open' && (c.type !== 'hold' || (c.listed && c.own < 50)) && g.cs.indexOf(c.country) >= 0 && (g.types.indexOf(c.type) >= 0 || g.strat === 'acq') && companyValue(c) > 0 && coEbit12(c) > 0 && S.week - (c.w0 || 0) > 52 && !(c.bid27 > S.week));
    if (!T.length) return false;
    const co = T.sort((a, b) => companyValue(b) - companyValue(a))[0];
    const V0 = companyValue(co), price = Math.round(V0 * (g.strat === 'acq' ? rng(1.1, 1.4) : rng(1.0, 1.25)) / 1000) * 1000;
    if (g.cash + g.rev * 0.6 - g.debt * 0.3 < price) return false;
    if (!cooldown('bid:' + co.id, 52)) return false;
    co.bid27 = S.week + 52;
    logMove(g, 'Bid ' + mshort(price) + ' for ' + co.name, co.country);
    R27.bidFor(co, g, price, V0);
    sent();
    return true;
  };
  function payG(g, amt) { g.cash -= Math.round(amt); if (g.cash < 0) { g.debt += -g.cash; g.cash = 0; } }
  function initR18(r) {
    if (r.pm16 == null) r.pm16 = Math.round((0.82 + hrng(S.seed + ':rp:' + r.id)() * 0.4) * 1000) / 1000;
    if (r.ig16 == null) r.ig16 = 1;
  }

  /* ---------- a bid for one of your companies ---------- */
  R27.bidFor = function (co, g, price, V0) {
    const out = 100 - (co.own || 100);
    addMsg({ kind: 'ask', from: g.owner + ', ' + g.name, title: g.name + ' wants to buy ' + co.name, body: g.name + ' offers ' + money(price) + ' for all of ' + co.name + ' (about ' + Math.round((price / Math.max(1, V0) - 1) * 100) + '% ' + (price >= V0 ? 'above' : 'below') + ' what it is worth today). ' + (co.own < 100 ? 'You own ' + Math.round(co.own) + '%, so you would get ' + money(price * co.own / 100) + '. ' : '') + (out > 50 ? 'Outside owners hold ' + Math.round(out) + '%. If the price is good they can accept without you.' : out >= 33.4 ? 'Outside owners hold ' + Math.round(out) + '% and will want a say.' : ''), co: co.id, opts: [{ l: 'Accept', d: 'Sell now for ' + money(price * co.own / 100) + ' to you.', fx: {} }, { l: 'Ask for more', d: 'They may raise their offer, or walk away.', fx: {} }, { l: 'Refuse', d: 'Keep it. They may come back, or compete harder.', fx: {} }], act: 'g27bid', data: { co: co.id, g: g.id, price, V0, round: 0 }, exp: S.week + 3, tone: 'n' });
  };
  function sellToGroup(co, g, price) {
    const r = acceptSale(co, { buyer: g.name, price, V: price, now: 1 });
    if (r !== 'ok') return r;
    try {
      const m = S.mk[mkKey(co)];
      if (m && LOCALF[(BD[co.type] || {}).fam]) { m.riv = m.riv || []; m.riv.push({ id: uid(), name: co.name, owner: g.owner, size: Math.round(clamp(co.size || 1, 0.5, 2) * 100) / 100, rel: 50, listed: false, ign: 0, lock: 0, meet: -99, g27: g.id }); m.n++; }
    } catch (e) { }
    payG(g, price);
    g.br++;
    logMove(g, 'Bought ' + co.name + ' from you', co.country);
    news(g.name + ' buys ' + co.name + '.', 'n');
    return 'ok';
  }
  R27.sellToGroup = sellToGroup;
  ACTS.g27bid = (m, idx) => {
    const co = getCo(m.data.co), g = G(m.data.g);
    if (!co || !g || co.st !== 'open') return true;
    const d = m.data;
    if (idx === 0) { sellToGroup(co, g, d.price); return true; }
    if (d.fin) { outsideVote(co, g, d.price, d.V0); return true; }
    if (idx === 1) {
      const p2 = Math.round(d.price * 1.15 / 1000) * 1000;
      const yes = d.round < 1 && chance(g.strat === 'acq' ? 0.6 : g.cash > p2 ? 0.45 : 0.25);
      if (yes) {
        addMsg({ kind: 'ask', from: g.owner + ', ' + g.name, title: 'Final offer for ' + co.name, body: g.name + ' raises its bid to ' + money(p2) + '. "This is as far as we go."', co: co.id, opts: [{ l: 'Accept', d: money(p2 * co.own / 100) + ' to you.', fx: {} }, { l: 'Refuse', d: 'They walk away.', fx: {} }], act: 'g27bid', data: Object.assign({}, d, { price: p2, round: 1, fin: 1 }), exp: S.week + 2, tone: 'n' });
      } else { note(g.name + ' would not pay more for ' + co.name + ' and walked away.', 'n', co.id); outsideVote(co, g, d.price, d.V0); }
      return true;
    }
    outsideVote(co, g, d.price, d.V0);
    return true;
  };
  /* with less than half the shares, the other owners decide */
  function outsideVote(co, g, price, V0) {
    if (!co || co.st !== 'open') return;
    const out = 100 - (co.own || 100);
    if (out <= 50) return;
    const sat = window.R27 && R27.holderSat ? R27.holderSat(co) : 50;
    const need = sat < 40 ? 1.0 : 1.12;
    if (price >= V0 * need) {
      sellToGroup(co, g, price);
      addMsg({ kind: 'info', from: 'Shareholders of ' + co.name, title: 'Outvoted: ' + co.name + ' is sold to ' + g.name, body: 'The other owners hold ' + Math.round(out) + '% and accepted ' + money(price) + '. Your ' + Math.round(co.own) + '% was paid out: ' + money(price * co.own / 100) + '.', co: co.id, tone: 'bad', status: 'done' });
    }
  }
  R27.outsideVote = outsideVote;
  ACTS.g27poach = (m, idx) => {
    const co = getCo(m.data.co), n = S.npcs[m.data.n], g = G(m.data.g);
    if (!co || !n || co.mgr !== n.id) return true;
    if (idx === 0) { co.mgrWage = m.data.offer; n.ret27 = S.week + 78; co.mood = Math.min(100, (co.mood || 60) + 6); note(n.name + ' stays at ' + co.name + ' on the new pay.', 'good', co.id); return true; }
    if (idx === 1) {
      payCo(co, (co.mgrWage || 0) * 3, 'wages', 'Retention bonus for ' + n.name);
      if (chance(0.72)) { n.ret27 = S.week + 52; note(n.name + ' takes the bonus and stays.', 'good', co.id); }
      else poachGo(co, n, g);
      return true;
    }
    poachGo(co, n, g);
    return true;
  };
  function poachGo(co, n, g) {
    n.hired = 0;
    co.mgr = null; co.mgrWage = 0; co.ohrs = 40; co.mood = 55;
    if (g) { g.mg = (g.mg || 0) + 1; g.m = Math.min(0.3, g.m + 0.004); logMove(g, 'Hired ' + n.name + ' from ' + co.name, co.country); }
    addMsg({ kind: 'info', from: co.name, title: n.name + ' has left for ' + (g ? g.name : 'a competitor'), body: 'You run ' + co.name + ' yourself until you hire a new manager.', co: co.id, tone: 'bad', status: 'done', go: { l: 'Hire a manager', a: 'go', p: { n: 'mgrhire', p: { id: co.id } } } });
  }
  /* an unanswered poach: they go. An unanswered bid: refused (but the other owners may still sell). */
  R7.afterWeek.push(() => {
    try {
      S.inbox.forEach(m => {
        if (!m.auto || m.done27) return;
        if (m.act === 'g27poach') { m.done27 = 1; const co = getCo(m.data.co), n = S.npcs[m.data.n]; if (co && n && co.mgr === n.id) poachGo(co, n, G(m.data.g)); }
        if (m.act === 'g27bid') { m.done27 = 1; const co = getCo(m.data.co), g = G(m.data.g); if (co && g) outsideVote(co, g, m.data.price, m.data.V0); }
      });
    } catch (e) { console.error(e); }
  });

  /* ---------- trouble ---------- */
  function onDistress(g) {
    const M = membersInMyMarkets(g);
    M.forEach(x => { x.r.listed = true; x.r.dist27 = S.week; });
    logMove(g, 'Money troubles: selling assets', g.cc);
    news(g.name + ' is in financial trouble and looks for buyers for parts of the business.', 'bad');
    if (M.length && canSend()) {
      addMsg({ kind: 'info', from: 'Deal room', title: g.name + ' is selling, cheaply', body: g.name + ' has debts of about ' + mshort(g.debt) + ' and is losing money. It will sell ' + M.map(x => x.r.name).join(', ') + ' in your markets well below normal prices. A buyer may also find surprises in the books.', co: M[0].co.id, tone: 'good', status: 'done', go: { l: 'See ' + M[0].r.name, a: 'go', p: { n: 'rival', p: { id: M[0].co.id, r: M[0].r.id } } } });
      sent();
    }
  }
  function onCollapse(g) {
    g.gone = S.week;
    const M = membersInMyMarkets(g);
    M.forEach(x => {
      const m = S.mk[mkKey(x.co)];
      if (!m) return;
      m.riv = m.riv.filter(r => r !== x.r);
      m.n = Math.max(1, m.n - 1);
      x.co.aware = Math.min(100, x.co.aware + 6);
      addMod(x.co, 'dem', 1.08, 26);
    });
    news(g.name + ' goes bankrupt.', 'bad');
    if (M.length) info('Market', g.name + ' has gone bankrupt', 'Its sites close, including ' + M.map(x => x.r.name).join(', ') + '. Some of their customers will come to you.', M[0].co.id, 'good');
  }
  /* buying from a group: they want more, unless they are in trouble; trouble can hide surprises */
  const pb0 = window.proposeBuy;
  if (pb0) window.proposeBuy = function (co, r, mult) {
    const g = grpOf(r);
    const distI = !g && r.dist27 && !r.succ27 && S.week - r.dist27 < 30;
    if (!g && !distI) return pb0.apply(this, arguments);
    if (distI || (r.dist27 && g.dist)) { const was = r.listed; r.listed = true; const x = pb0.call(this, co, r, mult * 1.45); r.listed = was; return x.price ? Object.assign(x, { price: Math.round(x.price / 1.45 / 1000) * 1000 }) : x; }
    return pb0.call(this, co, r, mult / 1.15);
  };
  const ar0 = window.acquireRival;
  if (ar0) window.acquireRival = function (co, r, price) {
    const g = grpOf(r), dist = r.dist27 && !r.succ27 && (g ? g.dist : S.week - r.dist27 < 30);
    const n = ar0.apply(this, arguments);
    try {
      if (typeof n === 'object') {
        if (g) { g.cash += price; g.br = Math.max(1, g.br - 1); if (g.dist) g.debt = Math.max(0, g.debt - price * 0.8); logMove(g, 'Sold ' + r.name + ' to you', co.country); }
        if (dist && chance(0.35)) {
          const bill = Math.round(price * rng(0.08, 0.25));
          n.pay.other = (n.pay.other || 0) + bill;
          addMsg({ kind: 'info', from: n.name, title: 'Surprise in the books of ' + n.name, body: 'Unpaid supplier bills and a tax claim from before you bought it: ' + money(bill) + '. It is yours to pay now.', co: n.id, tone: 'bad', status: 'done' });
        }
      }
    } catch (e) { console.error(e); }
    return n;
  };

  /* ---------- a rival's price cut runs out ---------- */
  function cutsWeek() {
    S.cos.forEach(co => {
      const m = S.mk[mkKey(co)];
      if (!m || !m.riv) return;
      m.riv.forEach(r => {
        if (r.uc27 && S.week >= r.uc27.end) {
          r.pm16 = Math.max(r.pm16, Math.round(r.uc27.from * 0.97 * 1000) / 1000);
          const g = grpOf(r);
          if (r.uc27.co === co.id && !r.uc27.fin) note(r.name + ' ended its price cut in ' + cityOf(co.city).name + '.', 'n', co.id);
          delete r.uc27;
          if (g) payG(g, unitRev(co.type, co.country) * 0.05);
        }
      });
      if (co.flags.uc27 && S.week >= co.flags.uc27.end) delete co.flags.uc27;
      const mt = co.flags.match27;
      if (mt && S.week >= mt.end) { co.price = mt.prev; delete co.flags.match27; note(co.name + ' is back at its normal prices.', 'n', co.id); }
    });
  }
  /* a supplier owned by a competitor charges you more */
  const ge0 = window.goodsEff;
  if (ge0) window.goodsEff = function (co) {
    const r = ge0.apply(this, arguments);
    try { if (r && r.v && S.g27 && S.g27.vown && S.g27.vown[r.v.id]) r.m = r.m * 1.06; } catch (e) { }
    return r;
  };

  /* ---------- the monthly tick ---------- */
  function monthTick() {
    const mine = myCountries();
    mine.forEach(ensureCC);
    Object.values(W().g).forEach(g => { if (!g.gone) groupMonth(g, g.cc === S.country); });
    /* moves: only groups that compete with you somewhere */
    const act = Object.values(W().g).filter(g => !g.gone && g.cs.some(c => mine.indexOf(c) >= 0));
    act.forEach(g => {
      const R = hrng(S.seed + ':gmv:' + g.id + ':' + MI());
      const p = 0.2 * (g.strat === 'cautious' ? 0.5 : g.strat === 'expand' || g.strat === 'acq' ? 1.25 : 1) * (g.dist ? 0.4 : 1);
      if (R() > p) return;
      const k = pickW(STRAT[g.strat].w, R);
      if (['undercut', 'beside', 'buysup', 'poach', 'bid'].indexOf(k) >= 0 && !canSend()) return;
      try { (MOVES[k] || (() => false))(g); } catch (e) { console.error(e); }
    });
    R27.rankSnap && R27.rankSnap();
  }
  R27.monthTick = monthTick;
  R7.afterWeek = R7.afterWeek || [];
  R7.afterWeek.push(() => {
    try {
      cutsWeek();
      const w = W();
      if (w.m !== MI()) { w.m = MI(); if (!R27.off) monthTick(); }
    } catch (e) { console.error(e); }
  });

  /* ================= UI ================= */
  /* ---------- a group's profile ---------- */
  V.titles.grp27 = 'Group';
  V.heads = V.heads || {};
  V.heads.grp27 = p => { const g = G(p.g); return { t: g ? g.name : 'Group', sub: g ? esc(STRAT[g.strat].n) + ' · ' + esc((CO[g.cc] || CC()).name) : '', right: g ? (g.gone ? pillp('Bankrupt', 'red') : g.dist ? pillp('In trouble', 'red') : '') : '' }; };
  const ana = () => R7.anaInfo && R7.anaInfo();
  function numOrWord(v, w, key) {
    const an = ana();
    if (!an) return w;
    const a = hrng(S.seed + ':' + key + ':' + an.id)(), wd = an.s >= 0.65 ? 0.1 + (1 - an.s) * 0.2 : 0.35;
    return mshort(v * (1 + (a - 0.5) * 0.1) * (1 - wd / 2)) + '–' + mshort(v * (1 + (a - 0.5) * 0.1) * (1 + wd / 2));
  }
  V.grp27 = function (p) {
    const g = G(p.g);
    if (!g) return '<div class="calm">Unknown group.</div>';
    const st = STRAT[g.strat], an = ana();
    let h = '<div class="card"><div class="cchd"><span class="av">' + esc(ini(g.name)) + '</span><span class="ctext"><b>' + esc(g.name) + '</b><small>Owner ' + esc(g.owner) + ' · since ' + g.f0 + (g.listed ? ' · listed' : '') + '</small></span></div><span class="tipt">' + esc(st.d) + ' Ambition: ' + esc(g.amb ? g.amb.txt : '–') + '.</span></div>';
    h += '<h2 class="sec">' + (an ? 'Your analyst\'s estimate' : 'What you can tell') + '</h2><div class="card">' +
      row('Sites', (an ? 'About ' + g.br : g.br > 40 ? 'Many' : g.br > 12 ? 'Quite a few' : 'A handful')) +
      row('Industries', esc(g.types.map(t => BD[t].n).join(', '))) +
      row('Countries', esc(g.cs.map(c => (CO[c] || {}).name).join(', '))) +
      row('Sales a year', numOrWord(g.rev, g.rev > 400e6 ? 'Very large' : g.rev > 100e6 ? 'Large' : 'Mid-sized', 'gr' + g.id)) +
      row('Cash', cashW(g)) + row('Debt', debtW(g)) +
      row('Could keep prices low for', 'About ' + holdW(g) + ' weeks') + '</div>';
    const M = membersInMyMarkets(g);
    if (M.length) h += '<h2 class="sec">Where you meet them</h2><div class="lrows">' + M.map(x => '<button class="lrow" data-a="go" data-p="' + P({ n: 'rival', p: { id: x.co.id, r: x.r.id } }) + '"><span class="av">' + esc(ini(x.r.name)) + '</span><span class="ctext"><b>' + esc(x.r.name) + '</b><small>' + esc(BD[x.co.type].n) + ' · ' + esc(cityOf(x.co.city).name) + ' · against ' + esc(x.co.name) + '</small></span>' + (x.r.uc27 ? pillp('Price cut', 'red') : x.r.listed ? pillp('For sale', 'grn') : '') + '<i>›</i></button>').join('') + '</div>';
    h += '<h2 class="sec">Recent moves</h2><div class="lrows">' + (g.mv.length ? g.mv.slice(0, 8).map(x => '<div class="lrow"><span class="ctext"><b class="wrap">' + esc(x.t) + '</b><small>' + dateStr(x.w) + (x.cc && x.cc !== g.cc ? ' · ' + esc((CO[x.cc] || {}).name || '') : '') + '</small></span></div>').join('') : '<div class="lrow"><small>Nothing new lately.</small></div>') + '</div>';
    if (g.rh.length >= 3 && an) h += '<div class="card"><h3>Sales, month by month</h3><div style="display:flex;justify-content:center">' + spark(g.rh, 280, 52) + '</div></div>';
    return h;
  };

  /* ---------- the rival screen shows its owner ---------- */
  const rvw0 = V.rival;
  V.rival = function (p) {
    let h = rvw0.apply(this, arguments);
    try {
      const co = getCo(p.id), r = co && rivalsOf(co).find(x => x.id === p.r), g = grpOf(r);
      if (!g) {
        if (r) { const c = '<div class="card"><span class="tipt">' + esc(r.name) + ' is independent: one owner, no group behind it.</span></div>'; const i = h.indexOf('<h2 class="sec">'); return i > 0 ? h.slice(0, i) + c + h.slice(i) : h + c; }
        return h;
      }
      const st = STRAT[g.strat];
      let c = '<button class="card opt2" data-a="go" data-p="' + P({ n: 'grp27', p: { g: g.id } }) + '"><div class="bhead"><b>Part of ' + esc(g.name) + '</b>' + (g.dist ? pillp('In trouble', 'red') : pillp(st.n, st.c)) + '</div><span class="tipt">' + g.br + ' sites · ' + esc(g.types.map(t => BD[t].n).join(', ')) + ' · cash ' + cashW(g).toLowerCase() + ', debt ' + debtW(g).toLowerCase() + '. ' + esc(st.d) + '</span>' + (g.mv[0] ? '<span class="tipt">Latest: ' + esc(g.mv[0].t) + '.</span>' : '') + '</button>';
      if (r.uc27) c = '<div class="card probcard"><b>' + esc(r.name) + ' cut prices ' + r.uc27.pct + '%</b><span class="tipt">Until about ' + dateStr(r.uc27.end) + '.</span><button class="btn chip wide" data-a="go" data-p="' + P({ n: 'rivmoves', p: { id: co.id, r: r.id } }) + '">Your response</button></div>' + c;
      if (r.dist27 && g.dist) c += '<div class="card sense"><b>A distressed seller</b><span class="tipt">' + esc(g.name) + ' needs cash. Offers well below normal value can work, but there may be unpaid bills in the books.</span></div>';
      const i = h.indexOf('<h2 class="sec">');
      return i > 0 ? h.slice(0, i) + c + h.slice(i) : h + c;
    } catch (e) { console.error(e); return h; }
  };

  /* ---------- Rival moves: how to answer a price cut ---------- */
  V.titles.rivmoves = 'Rival moves';
  V.heads.rivmoves = p => { const co = getCo(p.id); return { t: 'Rival moves', sub: co ? esc(BD[co.type].n) + ', ' + esc(cityOf(co.city).name) : '' }; };
  const margin = co => { const r = window.R26 && R26.annRev ? R26.annRev(co) : 0; if (r > 0 && (co.hist || []).length >= 2) return coEbit12(co) / r; const b = co.bk.y; return b && b.rev ? (b.rev - sumExp(b)) / b.rev : 0; };
  const wkRev = co => { try { return avgWk(co); } catch (e) { return co.lastW ? co.lastW.rev || 0 : 0; } };
  V.rivmoves = function (p) {
    const co = getCo(p.id), r = co && rivalsOf(co).find(x => x.id === p.r);
    if (!co || !r) return '<div class="calm">This has passed.</div>';
    const g = grpOf(r), uc = r.uc27;
    let h = '';
    if (uc) h += '<div class="card probcard"><b>' + esc(r.name) + ' cut prices ' + uc.pct + '%</b><span class="tipt">' + (g ? 'Backed by ' + esc(g.name) + '. ' : '') + 'Some of the customers of ' + esc(co.name) + ' are trying them. It runs until about ' + dateStr(uc.end) + '.</span></div>';
    else h += '<div class="card"><span class="tipt">' + esc(r.name) + ' is not cutting prices right now.</span></div>';
    let sh = '';
    try { const m = R26.mkOfCo(co), t = m && R26.truthOf(m), x = t && t.riv.find(y => y.id === r.id); if (x) sh = R26.shTxt(R26.est(x.share, 'rv' + x.id, R26.know(m))); } catch (e) { }
    h += '<div class="card"><div class="cchd"><span class="av">' + esc(ini(r.name)) + '</span><span class="ctext"><b>' + esc(r.name) + '</b><small>' + (g ? esc(g.name) + ' · ' + g.br + ' sites' : 'Independent') + (sh ? ' · ' + sh + (/%$/.test(sh) ? ' share' : '') : '') + '</small></span>' + (g ? pillp(g.strat === 'cost' || g.strat === 'expand' ? 'Aggressive' : STRAT[g.strat].n, g.strat === 'cost' || g.strat === 'expand' ? 'red' : STRAT[g.strat].c) : '') + '</div>' + (g ? row('Their cash', cashW(g)) + row('How long can they keep prices low?', '<span class="amb">About ' + holdW(g) + ' weeks</span>') : '') + '</div>';
    if (!uc || uc.resp) return h + (uc && uc.resp ? '<div class="card"><span class="tipt">You answered: ' + esc(uc.resp) + '.</span></div>' : '');
    const m0 = margin(co), pl = pLvl(co), m1 = pl > -3 ? m0 - (1 - PRICE_PM[pl + 2] / PRICE_PM[pl + 3]) : m0;
    const wk = wkRev(co), left = Math.max(1, uc.end - S.week);
    const q = Math.round(wk * 0.03 * Math.min(6, left));
    const est = setupEstimate(co.type, { city: co.city, size: 0.5, country: co.country });
    const opt = (t, d, a, pp, cls) => '<div class="card' + (cls ? ' ' + cls : '') + '"><b>' + t + '</b><span class="tipt">' + d + '</span><button class="btn ' + (cls ? 'primary' : '') + ' wide" data-a="' + a + '" data-p="' + P(pp) + '">' + (cls ? 'Open the deal room' : 'Do it') + '</button></div>';
    h += '<h2 class="sec">Your response</h2>';
    h += opt('Match their price', pl <= -3 ? 'You are already at your lowest price.' : 'Keeps clients. Margin falls from about ' + Math.round(m0 * 100) + '% to ' + Math.round(m1 * 100) + '% until they stop.', 'rm27', { id: co.id, r: r.id, k: 'match' });
    h += opt('Hold prices, sell quality', 'Spend about ' + money(q) + ' telling customers why you are better. You still lose some clients short term; reviews and loyal clients stay.', 'rm27', { id: co.id, r: r.id, k: 'quality' });
    h += opt('Add a cheap second brand', 'A new low-price company in ' + esc(cityOf(co.city).name) + ' fights them at the low end without cutting prices at ' + esc(co.name) + '. Setting it up costs about ' + money(est.total) + '.', 'rm27', { id: co.id, r: r.id, k: 'brand' });
    h += opt('Buy them out', g ? (g.dist ? esc(g.name) + ' is in trouble and may sell cheaply.' : esc(g.name) + ' will want a good price. ') + ' The competition authority looks at big deals.' : 'An independent owner may sell. See the deal room.', 'go', { n: 'rival', p: { id: co.id, r: r.id } }, 'deal');
    h += '<p class="muted small">Doing nothing is also a choice: you lose some customers until the cut ends.</p>';
    return h;
  };
  ACT.rm27 = p => {
    const co = getCo(p.id), r = co && rivalsOf(co).find(x => x.id === p.r);
    if (!co || !r || !r.uc27) return;
    const uc = r.uc27, left = Math.max(1, uc.end - S.week);
    const fm = (co.mods || []).find(x => x.t27 === r.id);
    if (p.k === 'match') {
      if (pLvl(co) <= -3) { toast('You are already at your lowest price.', true); return; }
      co.flags.match27 = { prev: co.price, end: uc.end };
      co.price = pLvl(co) - 1;
      if (fm) fm.m = 1;
      uc.resp = 'matched their price';
      toast('Prices lowered at ' + co.name + ' until about ' + dateStr(uc.end) + '.');
    } else if (p.k === 'quality') {
      const wk = wkRev(co), q = Math.round(wk * 0.03 * Math.min(6, left));
      if (!payCo(co, q, 'mkt', 'Campaign: why we are better') && co.cash < -coOverdraft(co)) { moveCash(co, q); bk(co, 'mkt', -q); toast('Not enough cash in the company.', true); return; }
      if (fm) fm.m = 1 - (1 - fm.m) * 0.5;
      co.rep = Math.min(100, co.rep + 2);
      uc.resp = 'held prices and sold quality';
      toast('Campaign running.');
    } else if (p.k === 'brand') {
      const n = startCompany(co.type, { city: co.city, country: co.country, form: 'AS', name: co.name.split(/\s+/)[0] + ' Express', size: 0.5 });
      if (typeof n === 'string') { U.res(n); return; }
      n.price = -2;
      n.flags.brand27 = co.id;
      uc.resp = 'started a cheap second brand';
      save();
      ui.stack = []; ui.tab = 'cos'; ui.view = { n: 'co', p: { id: n.id, t: 'ov' } };
      render(true);
      toast(n.name + ' is registered. Set it up like any new business.');
      return;
    }
    save();
    render(true);
  };

  /* ================= Rankings, in Stats ================= */
  const myTypes = () => { const s = {}; S.cos.forEach(c => { if (c.st === 'open' || c.st === 'closed') s[c.type] = 1; }); return Object.keys(s); };
  function finPlayers() {
    const out = [];
    if (!window.R26 || !R26.truthOf) return out;
    Object.keys(CO).forEach(cc => {
      const C = CO[cc];
      [['bank', 0.03, 0.4], ['insco', 1, 0.08], ['fund', 0.01, 0.35]].forEach(x => {
        const nat = (C.pop || 5) * 1e6 * ({ bank: 450000, insco: 14000, fund: 300000 })[x[0]] * Math.pow(C.mkt || 1, 2) * (C.pl || 1);
        let riv = [];
        try { riv = R26.truthOf({ kind: 'fin', type: x[0], country: cc, cos: [], k: 'fin|' + x[0] + '|' + cc }).riv || []; } catch (e) { }
        riv.forEach(rv => {
          const rev = rv.share * nat * x[1], H = hrng(S.seed + ':fp:' + rv.id);
          out.push({ id: rv.id, name: rv.name, cc, cs: [cc], types: [x[0]], rev, profit: rev * x[2], val: rev * x[2] * 10, gr: (H() - 0.4) * 0.12, prev: { rev: rev / (1 + (H() - 0.45) * 0.02), profit: rev * x[2], val: rev * x[2] * 10 } });
        });
      });
    });
    return out;
  }
  let finMemo = null, finMemoK = '';
  function entities() {
    Object.keys(CO).forEach(ensureCC);
    const L = Object.values(W().g).filter(g => !g.gone).map(g => ({ id: g.id, g, name: g.name, cc: g.cc, cs: g.cs, types: g.types, rev: g.rev, profit: profitOf(g), val: valueOf(g), gr: g.rh.length >= 13 ? g.rev / g.rh[g.rh.length - 13] - 1 : (STRAT[g.strat].g * 12), prev: g.prev || { rev: g.rev, profit: profitOf(g), val: valueOf(g) } }));
    const k = S.seed + ':' + MI();
    if (finMemoK !== k) { finMemo = finPlayers(); finMemoK = k; }
    L.push.apply(L, finMemo);
    const me = meEntity();
    if (me) L.push(me);
    return L;
  }
  function meEntity() {
    const cos = S.cos.filter(c => c.st === 'open' || c.st === 'closed');
    if (!cos.length) return null;
    const ann = c => window.R26 && R26.annRev ? R26.annRev(c) : (c.lastW ? c.lastW.rev * 52 : 0);
    const rev = sumF(cos, c => ann(c) * (c.own || 100) / 100), profit = sumF(cos, c => coEbit12(c) * (c.own || 100) / 100), val = sumF(cos, c => Math.max(0, companyValue(c)) * (c.own || 100) / 100);
    const H = S.r27me = S.r27me || { rh: [], prev: null };
    const cs = []; cos.forEach(c => { if (cs.indexOf(c.country) < 0) cs.push(c.country); });
    const hold = cos.find(c => c.type === 'hold');
    return { id: 'me', me: 1, name: hold ? hold.name : (S.player.name || 'You'), cc: S.country, cs, types: myTypes(), rev, profit, val, gr: H.rh.length >= 13 && H.rh[H.rh.length - 13] > 0 ? rev / H.rh[H.rh.length - 13] - 1 : 0, prev: H.prev || { rev, profit, val }, n: cos.length };
  }
  R27.rankSnap = function () {
    const me = meEntity();
    if (!me) return;
    const H = S.r27me = S.r27me || { rh: [], prev: null };
    H.prev = { rev: me.rev, profit: me.profit, val: me.val };
    H.rh.push(Math.round(me.rev));
    if (H.rh.length > 24) H.rh.shift();
  };
  const METRIC = { rev: ['Sales', e => e.rev], profit: ['Profit', e => e.profit], val: ['Value', e => e.val], gr: ['Growth', e => e.gr] };
  const PREV = { rev: e => e.prev.rev, profit: e => e.prev.profit, val: e => e.prev.val, gr: e => e.gr };
  /* round 36: every rival you actually face is ranked by name, and the rest of each market is an estimated crowd
     of ordinary firms (sizes only; a name is made up when one is shown), so a newcomer starts near the bottom. */
  function localRivals() {
    const out = [], seen = {};
    if (!window.R7 || !R7.truth) return out;
    S.cos.filter(c => c.st === 'open' && c.type !== 'hold' && BD[c.type] && LOCALF[BD[c.type].fam]).forEach(co => {
      let rs = [];
      try { rs = rivalsOf(co); } catch (e) { }
      rs.forEach(r => {
        if (r.g27 || r.gone || seen[r.id]) return;
        seen[r.id] = 1;
        let tr; try { tr = R7.truth(co, r); } catch (e) { return; }
        const H = hrng(S.seed + ':lr:' + r.id), v = typeof rivalValue === 'function' ? rivalValue(co, r) : tr.profit * 6;
        out.push({ id: 'lr' + r.id, lr: { co: co.id, r: r.id }, name: r.name, cc: co.country, cs: [co.country], types: [co.type], city: co.city, rev: tr.rev, profit: tr.profit, val: v, gr: (H() - 0.45) * 0.1, prev: { rev: tr.rev * (1 - (H() - 0.5) * 0.04), profit: tr.profit, val: v } });
      });
    });
    return out;
  }
  let crowdMemo = null, crowdK = '';
  function crowd() {
    const k = String(S.seed);
    if (crowdK === k && crowdMemo) return crowdMemo;
    const B = [];
    Object.keys(CO).forEach(cc => {
      const C = CO[cc];
      okTypes(cc).forEach(t => {
        const bd = BD[t], ur = unitRev(t, cc);
        if (!(ur > 0)) return;
        const n = Math.max(6, Math.min(1500, Math.round((C.pop || 5) * 1e6 / (8000 * Math.sqrt(Math.max(1, bd.ticket || 100) / 100)))));
        const R = hrng(S.seed + ':crowd:' + cc + ':' + t), a = new Float64Array(n);
        for (let i = 0; i < n; i++) { const g = Math.sqrt(-2 * Math.log(Math.max(1e-9, R()))) * Math.cos(2 * Math.PI * R()); a[i] = ur * Math.exp(-0.45 + 0.8 * g); }
        a.sort(); a.reverse();
        B.push({ cc, t, a, ur, m: Math.max(0.03, bd.m || 0.08) });
      });
    });
    crowdK = k; crowdMemo = B;
    return B;
  }
  R27.crowd = crowd;
  /* how many in a bucket are above x (values sorted high to low) */
  const above = (a, x) => { let lo = 0, hi = a.length; while (lo < hi) { const md = (lo + hi) >> 1; if (a[md] > x) lo = md + 1; else hi = md; } return lo; };
  /* a crowd firm's figure from its sales: a * sales + c (small firms below half the usual size lose money) */
  const lin = (sort, b) => sort === 'profit' ? [b.m, -0.5 * b.ur * b.m] : sort === 'val' ? [b.m * 6 + 0.25, 0] : [1, 0];
  function crowdName(b, i) {
    const save = S.rs;
    S.rs = (fbHash(b.cc + ':' + b.t + ':' + i) * 2654435761 + (S.seed || 1)) | 0;
    let nm = '';
    try { const C = CO[b.cc], cs = C.cities.filter(c => c.id !== 'small'); nm = rivalName(BD[b.t], cs[i % cs.length].id, b.cc); } catch (e) { nm = 'Firm ' + (i + 1); }
    S.rs = save;
    return nm;
  }
  function crowdE(b, i, sort) {
    const v = b.a[i];
    const pf = v * b.m - 0.5 * b.ur * b.m, vl = v * (b.m * 6 + 0.25);
    return { id: 'cw:' + b.cc + ':' + b.t + ':' + i, crowd: 1, name: crowdName(b, i), cc: b.cc, cs: [b.cc], types: [b.t], rev: v, profit: pf, val: vl, gr: 0, prev: { rev: v, profit: pf, val: vl } };
  }
  function ranked(f, sort) {
    const mt = myTypes(), mc = R27.myCountries();
    const L = entities().concat(localRivals()).filter(e => {
      if (e.me) return true;
      if (f === 'ind') return e.types.some(t => mt.indexOf(t) >= 0) && e.cs.some(c => mc.indexOf(c) >= 0);
      if (f === 'cc') return e.cc === S.country || e.cs.indexOf(S.country) >= 0;
      return true;
    });
    const fn = METRIC[sort][1], pv = PREV[sort];
    const Bk = sort === 'gr' ? [] : crowd().filter(b => f === 'ind' ? mt.indexOf(b.t) >= 0 && mc.indexOf(b.cc) >= 0 : f === 'cc' ? b.cc === S.country : true);
    const cAbove = x => { let n = 0; for (let k = 0; k < Bk.length; k++) { const l = lin(sort, Bk[k]); n += above(Bk[k].a, (x - l[1]) / l[0]); } return n; };
    const now = L.slice().sort((a, b) => fn(b) - fn(a));
    const before = L.slice().sort((a, b) => pv(b) - pv(a));
    now.forEach((e, i) => { e.rk = i + 1 + cAbove(fn(e)); e.rk0 = before.indexOf(e) + 1 + cAbove(pv(e)); });
    /* the crowd firms worth showing: the biggest, and the ones just around you */
    const show = [];
    if (Bk.length) {
      const top = [];
      Bk.forEach(b => { const l = lin(sort, b); for (let i = 0; i < Math.min(50, b.a.length); i++) top.push([b.a[i] * l[0] + l[1], b, i]); });
      top.sort((x, y) => y[0] - x[0]);
      top.slice(0, 50).forEach(x => show.push(x));
      const me = now.find(e => e.me);
      if (me) {
        const x = fn(me), up = [], dn = [];
        Bk.forEach(b => { const l = lin(sort, b), j = above(b.a, (x - l[1]) / l[0]); for (let i = Math.max(0, j - 3); i < j; i++) up.push([b.a[i] * l[0] + l[1], b, i]); for (let i = j; i < Math.min(b.a.length, j + 3); i++) dn.push([b.a[i] * l[0] + l[1], b, i]); });
        up.sort((p, q) => p[0] - q[0]); dn.sort((p, q) => q[0] - p[0]);
        up.slice(0, 3).concat(dn.slice(0, 3)).forEach(x => show.push(x));
      }
    }
    const seen = {}, cr = [];
    show.forEach(x => { const id = x[1].cc + x[1].t + x[2]; if (seen[id]) return; seen[id] = 1; const e = crowdE(x[1], x[2], sort); const v = fn(e); e.rk = 1 + now.filter(n => fn(n) > v).length + cAbove(v + Math.abs(v) * 1e-9 + 1e-9); e.rk0 = e.rk; cr.push(e); });
    const out = now.concat(cr).sort((a, b) => a.rk - b.rk || fn(b) - fn(a));
    out.total = L.length + Bk.reduce((t, b) => t + b.a.length, 0);
    return out;
  }
  R27.ranked = ranked;
  R27.myRank = (f, sort) => { const L = ranked(f || 'cc', sort || 'rev'); const e = L.find(x => x.me); return e ? { rank: e.rk, of: L.total || L.length } : null; };
  function rankings() {
    const f = ui.rk27f || 'ind', sort = ui.rk27s || 'rev';
    let h = '<div class="ptabs">' + [['ind', 'Your industries'], ['cc', esc((CO[S.country] || CC()).name)], ['world', 'World']].map(x => '<button class="' + (f === x[0] ? 'on' : '') + '" data-a="rk27f" data-p="' + P({ v: x[0] }) + '">' + x[1] + '</button>').join('') + '</div>';
    h += '<div class="chips">' + Object.keys(METRIC).map(k => '<button class="btn chip' + (sort === k ? ' primary' : '') + '" data-a="rk27s" data-p="' + P({ v: k }) + '">' + METRIC[k][0] + '</button>').join('') + '</div>';
    const L = ranked(f, sort);
    if (!L.some(e => e.me)) return h + '<div class="calm">Rankings show up once you run a business.</div>';
    const me = L.find(e => e.me);
    const fmt = e => sort === 'gr' ? (e.gr >= 0 ? '+' : '−') + Math.abs(Math.round(e.gr * 100)) + '%' : mshort(METRIC[sort][1](e));
    const arrow = e => { const d = e.rk0 - e.rk; return d > 2 ? '<span class="pos">▲▲</span>' : d > 0 ? '<span class="pos">▲</span>' : d < -2 ? '<span class="neg">▼▼</span>' : d < 0 ? '<span class="neg">▼</span>' : '<span class="muted">–</span>'; };
    const rowE = e => {
      const sub = e.me ? 'You · ' + e.n + (e.n === 1 ? ' company' : ' companies') : esc(e.types.slice(0, 2).map(t => BD[t] ? BD[t].n : t).join(', ')) + ' · ' + (e.lr ? esc(cityOf(e.city).name) + ' · your rival' : esc(e.cs.slice(0, 3).map(c => (CO[c] || {}).name).join(', '))) + (e.g ? ' · ' + e.g.br + ' sites' : '');
      const inner = '<span class="rk27n">' + e.rk + '</span><span class="av' + (e.me ? ' me27' : '') + '">' + esc(ini(e.name)) + '</span><span class="ctext"><b>' + esc(e.name) + (e.me ? ' <small>(you)</small>' : '') + '</b><small>' + sub + '</small></span><span class="rt"><b>' + fmt(e) + '</b><small>' + arrow(e) + '</small></span>';
      return e.g ? '<button class="lrow" data-a="go" data-p="' + P({ n: 'grp27', p: { g: e.g.id } }) + '">' + inner + '</button>' : e.lr ? '<button class="lrow riv36" data-a="go" data-p="' + P({ n: 'rival', p: { id: e.lr.co, r: e.lr.r } }) + '">' + inner + '</button>' : '<div class="lrow' + (e.me ? ' on' : '') + '">' + inner + '</div>';
    };
    h += '<div class="card sense"><span class="tipt">You are <b>' + ordinal(me.rk) + '</b> of ' + (L.total || L.length).toLocaleString('en').replace(/,/g, ' ') + ' by ' + METRIC[sort][0].toLowerCase() + (f === 'ind' ? ' among companies in your trades' : f === 'cc' ? ' in ' + esc((CO[S.country] || CC()).name) : ' worldwide') + '. Their figures come from public accounts' + (ana() ? ' and your analyst' : '') + '.</span></div>';
    const top = L.slice(0, 20);
    const near = me.rk > 20 ? L.filter(e => e.rk > 20 && Math.abs(e.rk - me.rk) <= 2 && e !== me).concat([me]).sort((a, b) => a.rk - b.rk) : [];
    h += '<div class="lrows">' + top.map(rowE).join('') + (near.length ? '<div class="lrow"><span class="ctext"><small>…</small></span></div>' + near.map(rowE).join('') : '') + '</div>' + (L.total > L.length ? '<span class="tipt">Small firms come from the business register: names and sizes, no detail. Rivals you meet are marked.</span>' : '');
    return h;
  }
  R27.rankings = rankings;
  const ordinal = n => n + (n % 10 === 1 && n % 100 !== 11 ? 'st' : n % 10 === 2 && n % 100 !== 12 ? 'nd' : n % 10 === 3 && n % 100 !== 13 ? 'rd' : 'th');
  R27.ordinal = ordinal;
  ACT.rk27f = p => { ui.rk27f = p.v; render(true); };
  ACT.rk27s = p => { ui.rk27s = p.v; render(true); };
  ACT.st27 = p => { ui.st27 = p.v; render(true); };
  const stats0 = V.stats;
  V.stats = function () {
    const t = ui.st27 || 'ov';
    const tabs = '<div class="ptabs">' + [['ov', 'Overview'], ['rk', 'Rankings']].map(x => '<button class="' + (t === x[0] ? 'on' : '') + '" data-a="st27" data-p="' + P({ v: x[0] }) + '">' + x[1] + '</button>').join('') + '</div>';
    return tabs + (t === 'rk' ? rankings() : stats0.apply(this, arguments));
  };
})();

/* ===== Round 48: milestones in your own currency, part-time staff, home starts earn their word of mouth.
   (Growth rankings: patch31.py gives every crowd firm a growth figure.) ===== */
window.R48 = window.R48 || {};
(function () {
  'use strict';
  const R48 = window.R48;
  const U = window.UI;
  if (!U) return;
  const { ui, V, ACT, esc, render, go } = U;
  const P = o => esc(JSON.stringify(o));

  /* ================= 1. money milestones are round numbers in your own currency ================= */
  try {
    const A = window.R28 && R28.ACH;
    if (A) {
      const C = () => CO[S.country] || CC();
      const unit = () => ({ JPY: 1e8, KRW: 1e9 }[C().cur] || 1e6);
      const amt = k => unit() * k * fxr(C()); /* local amount → internal */
      const words = v => v >= 1e9 ? (v / 1e9) + ' billion' : (v / 1e6) + ' million';
      const nw = () => { try { return netWorth().total; } catch (e) { return 0; } };
      const set = (id, k, title) => {
        const a = A.find(x => x[0] === id);
        if (!a) return;
        Object.defineProperty(a, 1, { get: title, configurable: true });
        a[3] = () => nw() >= amt(k) && 'Your net worth passed ' + money(amt(k)) + '.';
      };
      set('million', 1, () => unit() === 1e6 ? 'First million' : 'First ' + words(unit()));
      set('tenm', 10, () => 'Net worth of ' + words(10 * unit()));
      set('hm', 100, () => 'Net worth of ' + words(100 * unit()));
      set('bn', 1000, () => unit() === 1e6 ? 'A billionaire' : 'Net worth of ' + words(1000 * unit()));
    }
  } catch (e) { console.error(e); }

  /* ================= 2. part-time staff ================= */
  /* s.pt = 0.5: half the hours, half the pay (s.wage is the real monthly pay; market comparisons use wage × pt) */
  if (typeof staffFTE === 'function') {
    staffFTE = function (co, role) {
      let t = 0;
      co.staff.forEach(s => {
        if (s.role === role) t += (s.pt || 1) * 0.92 * (0.75 + 0.5 * staffSkill(s) / 100) * (s.flag === 'lazy' ? 0.82 : 1) * (s.pay && SALES_ROLES[s.role] ? (s.pay.m === 'mix' ? 1.06 : s.pay.m === 'com' ? 1.12 : 1) : 1);
      });
      return t;
    };
  }
  if (typeof hireWorker === 'function') {
    const hw0 = hireWorker;
    hireWorker = function (co) {
      const n0 = co && co.staff ? co.staff.length : 0;
      const r = hw0.apply(this, arguments);
      if (r === 'ok' && R48.ptHire && co.staff.length > n0) {
        const s = co.staff[co.staff.length - 1];
        s.pt = 0.5;
        s.wage = Math.round(s.wage * 0.5 / 100) * 100;
      }
      return r;
    };
  }
  const pt = id => !!(ui.pt48 && ui.pt48[id]);
  const off0 = ACT.offer;
  if (off0) ACT.offer = function (p) { R48.ptHire = pt(p && p.id); try { return off0.apply(this, arguments); } finally { R48.ptHire = 0; } };
  ACT.pt48 = p => { ui.pt48 = ui.pt48 || {}; ui.pt48[p.id] = p.v ? 1 : 0; render(); };
  const hv0 = V.hire;
  if (hv0) V.hire = function (p) {
    const h = hv0.apply(this, arguments);
    try {
      const co = p && p.id && getCo(p.id);
      const i = h.indexOf('<h3 class="gap">How to search</h3>');
      if (!co || i < 0) return h;
      const on = pt(co.id);
      const c = '<h3 class="gap">Hours</h3>' + U.chips([[0, 'Full time'], [1, 'Part time · 20 h']], on ? 1 : 0, 'pt48', { id: co.id }) + (on ? '<p class="cap47">Half the pay and half the work. Pay shown below is for full time.</p>' : '');
      return h.slice(0, i) + c + h.slice(i);
    } catch (e) { console.error(e); return h; }
  };
  /* the Staff tab says who works part time */
  const co0 = V.co;
  if (co0) V.co = function (p) {
    let h = co0.apply(this, arguments);
    try {
      const co = p && getCo(p.id);
      (co && co.staff || []).forEach(s => {
        const n = S.npcs[s.id];
        if (!s.pt || !n) return;
        h = h.split('<b>' + esc(n.name) + '</b><small>').join('<b>' + esc(n.name) + '</b><small>Part time · ');
      });
    } catch (e) { console.error(e); }
    return h;
  };
  /* "Hire part-time help" when you are burning out opens Find workers, set to part time */
  if (typeof ACTS === 'object' && ACTS.e27) {
    const e0 = ACTS.e27;
    ACTS.e27 = function (m, idx) {
      const r = e0.apply(this, arguments);
      try {
        if (m && m.data && m.data.id === 's_burnout' && idx === 0 && m.data.co) {
          ui.pt48 = ui.pt48 || {};
          ui.pt48[m.data.co] = 1;
          setTimeout(() => { try { ui.sheet = null; go('hire', { id: m.data.co }); } catch (e) { } }, 0);
        }
      } catch (e) { console.error(e); }
      return r;
    };
  }

  /* ================= 3. from home, customers come slowly: word of mouth has to be earned ================= */
  if (typeof demand === 'function') {
    const d0 = demand;
    demand = function (co) {
      const r = d0.apply(this, arguments);
      try {
        if (r && r.D && window.R37 && R37.atHome && R37.atHome(co)) r.D *= Math.max(0.72, Math.min(0.95, 0.72 + (co.aware || 0) * 0.005));
      } catch (e) { }
      return r;
    };
  }
})();

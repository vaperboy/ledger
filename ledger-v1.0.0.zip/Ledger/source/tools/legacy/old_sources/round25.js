/* ===== Round 25: names that fit the business =====
   Company names used to pick an ending from one mixed list per country, so a tutoring company in Lithuania could be
   called "... Statyba" (construction). Now each business type belongs to a sector. Sectors with their own vocabulary
   (tech, finance, construction, retail and hospitality, logistics) use the country's words for that sector; every other
   trade gets a universal name (a surname, two partners' names, a local place or a coined word) with no industry word.
   Name lists come from the user's directory of people and company names by country. */
window.R25 = window.R25 || {};
(function () {
  /* the directory, per country: people, sector words and legal forms ('-' at the end = prefix glued to a root,
     '-' at the start = word that follows the root) */
  const D = {
    LT: { m: 'Jonas,Lukas,Mantas,Dovydas,Karolis,Rokas,Laurynas,Vytautas,Dominykas,Paulius', f: 'Ieva,Emilija,Gabrielė,Austėja,Kamilė,Rugilė,Urtė,Rasa,Viltė,Viktorija', l: 'Kazlauskas,Petrauskas,Jankauskas,Stankevičius,Vasiliauskas,Paulauskas,Žukauskas,Urbonas,Kavaliauskas,Navickas',
      tech: ['Balt-', 'Cyber-', '-Inovacijos', '-Kompiuteriai'], fin: ['Finansai', 'Kapito-', 'Inv-', 'Valdymas'], build: ['Statyba', 'Montažas', 'Inžinerija', 'Stat-'], retail: ['Prekyba', 'Svečiai', 'Maistas'], logi: ['Trans-', 'Logistika', 'Ekspedicija'],
      ent: { any: 'UAB', fin: 'UAB', build: 'UAB', logi: 'UAB', tech: 'UAB', retail: 'UAB', small: 'MB' }, roots: 'Baltijos,Nemuno,Vilniaus,Lietuvos,Neries,Kauno,Žalgirio,Gedimino' },
    CA: { m: 'Liam,Ethan,Lucas,Benjamin,Noah,William,Olivier,Logan,Alexander,Félix', f: 'Olivia,Emma,Charlotte,Ava,Sophia,Chloe,Maya,Léa,Florence,Alice', l: 'Tremblay,Roy,Smith,Macdonald,Bouchard,Gauthier,Morin,Campbell,Johnston,Lavoie',
      tech: ['Can-', 'Tech', 'Northern Digital', 'Cyber-'], fin: ['Capital', 'Financial', 'Trust', 'Wealth'], build: ['Builders', 'Contracting', 'Civil', 'Infra'], retail: ['Brands', 'Goods', 'Outfitters', 'Table'], logi: ['Freight', 'Express', 'Logistics', 'Transit'],
      ent: { any: 'Inc.', fin: 'Inc.', build: 'Ltd.', logi: 'Corp.', tech: 'Inc.', retail: 'Co.' }, roots: 'Great White,Laurentian,Maple Leaf,Northern,Pacific,Prairie,Algonquin,Saint-Laurent' },
    US: { m: 'James,Michael,Robert,John,David,Christopher,Joseph,Matthew,Jackson,Mason', f: 'Mary,Jennifer,Linda,Patricia,Elizabeth,Sarah,Jessica,Ashley,Harper,Evelyn', l: 'Smith,Johnson,Williams,Brown,Jones,Garcia,Miller,Davis,Rodriguez,Martinez',
      tech: ['Cyber-', 'Net-', 'Soft-', 'Systems', 'Cloud'], fin: ['Capital', 'Fiduciary', 'Partners', 'Asset', 'Advisory'], build: ['Structural', 'Civil', 'Heavy Builders', 'Development'], retail: ['Goods', 'Provisions', 'House', 'Retail Group'], logi: ['Express', 'Transit', 'Freight Solutions', 'Intermodal'],
      ent: { any: 'LLC', fin: 'LLC', build: 'Inc.', logi: 'Inc.', tech: 'Inc.', retail: 'Co.' }, roots: 'Tri-State,Apex,Liberty,Summit,Lone Star,Golden Gate,Bayside,Keystone' },
    DE: { m: 'Maximilian,Felix,Lukas,Paul,Jonas,Leon,Finn,Elias,Niklas,Tim', f: 'Hannah,Emma,Mia,Sophia,Lina,Ella,Lea,Marie,Clara,Nele', l: 'Müller,Schmidt,Schneider,Fischer,Weber,Meyer,Wagner,Becker,Schulz,Hoffmann',
      tech: ['Soft-', 'Cyber-', 'Tech', 'Systeme', 'Software'], fin: ['Capital', 'Investment', 'Vermögensverwaltung', 'Bank'], build: ['Bau-', 'Hochbau-', 'Tiefbau-', 'Maschinenbau'], retail: ['Handel', 'Gastro-', 'Bewirtung', 'Markt'], logi: ['Transport', 'Spedition', 'Logistik', 'Fracht'],
      ent: { any: 'GmbH', fin: 'AG', build: 'GmbH', logi: 'GmbH & Co. KG', tech: 'GmbH', retail: 'GmbH' }, roots: 'Nordsee,Rheinland,Hanseatic,Bayrische,Schwarzwald,Elbe,Spree,Alster' },
    FR: { m: 'Gabriel,Louis,Raphaël,Jules,Adam,Lucas,Léo,Hugo,Arthur,Nathan', f: 'Jade,Louise,Ambre,Alice,Rose,Emma,Mila,Lina,Chloé,Inès', l: 'Martin,Bernard,Dubois,Thomas,Robert,Richard,Petit,Durand,Leroy,Moreau',
      tech: ['Digital', 'Numérique', 'Tech', 'Informatique'], fin: ['Finance', 'Patrimoine', 'Investissement', 'Capital'], build: ['BTP', 'Construction', 'Ingénierie', 'Travaux'], retail: ['Maison', 'Gourmet', 'Gastronomie', 'Distribution'], logi: ['Transports', 'Logistique', 'Fret', 'Express'],
      ent: { any: 'SARL', fin: 'SAS', build: 'SAS', logi: 'SAS', tech: 'SAS', retail: 'SARL' }, roots: 'Val de Loire,Hexagone,Nord,Provence,Atlantique,Bretagne,Alpes,Seine' },
    PL: { m: 'Piotr,Jakub,Kacper,Michał,Mateusz,Szymon,Filip,Jan,Adam,Maciej', f: 'Zofia,Julia,Maja,Hanna,Lena,Alicja,Maria,Oliwia,Emilia,Wiktoria', l: 'Nowak,Kowalski,Wiśniewski,Wójcik,Kowalczyk,Kamiński,Lewandowski,Zieliński,Szymański,Woźniak',
      tech: ['Soft-', 'Cyfra-', 'Tech-', 'Systemy'], fin: ['Kapitał', 'Finanse', 'Inwestycje', 'Powiernik'], build: ['Bud-', 'Stal-', 'Inżynieria', 'Konstrukcje'], retail: ['Handel', 'Gastro-', 'Dystrybucja'], logi: ['Trans-', 'Spedycja', 'Logistyka', 'Przewozy'],
      ent: { any: 'Sp. z o.o.', fin: 'S.A.', build: 'Sp. z o.o.', logi: 'Sp. z o.o.', tech: 'Sp. z o.o.', retail: 'Sp. z o.o.' }, roots: 'Polskie,Mazowieckie,Wiślane,Bałtyckie,Śląskie,Krakowskie,Tatrzańskie,Pomorskie' },
    KR: { m: 'Min-jun,Seo-jun,Do-yun,Ye-jun,Joo-won,Ha-joon,Ji-ho,Hyun-woo,Woo-jin,Kun-woo', f: 'Seo-yeon,Seo-yun,Ji-woo,Seo-ah,Ha-eun,Min-seo,Chae-won,Soo-ah,Ji-a,Da-eun', l: 'Kim,Lee,Park,Choi,Jeong,Kang,Cho,Yoon,Jang,Lim',
      tech: ['Soft', 'Systems', 'Information', 'Tech'], fin: ['Capital', 'Financial', 'Asset Management', 'Insurance'], build: ['Development', 'Heavy Industries', 'E&C'], retail: ['Mart', 'Retail', 'Foods', 'Shopping'], logi: ['Express', 'Global Logistics', 'Shipping'],
      ent: { any: 'Co., Ltd.', fin: 'Corp.', build: 'Corp.', logi: 'Co., Ltd.', tech: 'Co., Ltd.', retail: 'Co., Ltd.' }, roots: 'Shinwon,Daehan,Woori,Hanjin,Hanwool,Saebyeok,Hanbit,Mirae' },
    JP: { m: 'Ren,Haruto,Souta,Yuto,Riku,Kaito,Takumi,Daiki,Sora,Ryota', f: 'Yui,Mei,Aoi,Hina,Rin,Yuna,Mio,Kokoa,Misaki,Sakura', l: 'Sato,Suzuki,Takahashi,Tanaka,Watanabe,Ito,Yamamoto,Nakamura,Kobayashi,Kato',
      tech: ['System', 'Electronics', 'Soft', 'Digital'], fin: ['Capital', 'Securities', 'Asset', 'Insurance'], build: ['Kensetsu', 'Gumi', 'Kogyo'], retail: ['Shoji', 'Trading', 'Food'], logi: ['Unyu', 'Unso', 'Maritime'],
      ent: { any: 'K.K.', fin: 'K.K.', build: 'K.K.', logi: 'K.K.', tech: 'K.K.', retail: 'K.K.' }, roots: 'Nippon,Teikoku,Dai-Ichi,Shinsei,Sakura,Fuji,Yamato,Asahi' },
    BR: { m: 'Gabriel,Lucas,Pedro,Matheus,Guilherme,Gustavo,Felipe,Vinícius,João,Enzo', f: 'Alice,Sophia,Beatriz,Julia,Isabella,Manuela,Luiza,Giovanna,Maria,Valentina', l: 'Silva,Santos,Oliveira,Souza,Rodrigues,Ferreira,Alves,Pereira,Lima,Gomes',
      tech: ['Soluções', 'Digital', 'Sistemas', 'Tecnologia'], fin: ['Capital', 'Investimentos', 'Crédito', 'Financeira'], build: ['Construtora', 'Engenharia', 'Obras'], retail: ['Comércio', 'Alimentos', 'Varejo'], logi: ['Transportes', 'Cargas', 'Logística'],
      ent: { any: 'Ltda.', fin: 'S.A.', build: 'Ltda.', logi: 'Ltda.', tech: 'Ltda.', retail: 'Ltda.', small: 'ME' }, roots: 'Real-Sul,Terra Nova,Brasília,Atlântica,Paulista,Carioca,Cerrado,Guanabara' },
    NL: { m: 'Daan,Sem,Lucas,Milan,Levi,Luuk,Bram,Finn,Noud,Mees', f: 'Emma,Julia,Sophie,Lotte,Saar,Lieke,Mila,Tess,Zoë,Fleur', l: 'de Jong,Jansen,de Vries,van den Berg,Bakker,van Dijk,Visser,Smit,Meijer,de Boer',
      tech: ['Digital', 'Software', 'Tech', 'ICT'], fin: ['Capital', 'Beheer', 'Investments', 'Financiën'], build: ['Bouw', 'Infrabouw', 'Installatie', 'Constructie'], retail: ['Handel', 'Horeca', 'Food', 'Retail'], logi: ['Transport', 'Logistiek', 'Expeditie', 'Vracht'],
      ent: { any: 'B.V.', fin: 'B.V.', build: 'B.V.', logi: 'B.V.', tech: 'B.V.', retail: 'B.V.' }, roots: 'Hollandsche,Randstad,NedTech,Zeeuwse,Amstel,Maas,Veluwe,Waddenzee' },
    NO: { m: 'Henrik,Jakob,Emil,Oskar,Oliver,Filip,William,Lucas,Elias,Magnus', f: 'Nora,Emma,Sofie,Olivia,Ella,Maja,Frida,Ingrid,Sara,Ada', l: 'Hansen,Johansen,Olsen,Larsen,Andersen,Pedersen,Nilsen,Kristiansen,Jensen,Karlsen',
      tech: ['Data', 'Systemer', 'Teknologi', 'Digital'], fin: ['Kapital', 'Eiendom', 'Finans', 'Forvaltning'], build: ['Bygg', 'Anlegg', 'Entreprenør', 'Prosjekt'], retail: ['Handel', 'Drift', 'Servering'], logi: ['Transport', 'Frakt', 'Logistikk', 'Havn'],
      ent: { any: 'AS', fin: 'AS', build: 'AS', logi: 'AS', tech: 'AS', retail: 'AS' }, roots: 'Fjord,Kysten,Vestland,Nordic,Fjell,Nordlys,Vik,Hav' },
    SE: { m: 'William,Liam,Hugo,Elias,Oliver,Lucas,Oscar,Alexander,Viktor,Arvid', f: 'Alice,Maja,Elsa,Astrid,Wilma,Freja,Ebba,Agnes,Olivia,Alma', l: 'Andersson,Johansson,Karlsson,Nilsson,Eriksson,Larsson,Olsson,Persson,Svensson,Gustafsson',
      tech: ['Digital', 'System', 'Data', 'Software'], fin: ['Kapital', 'Finans', 'Investering', 'Fastigheter'], build: ['Bygg', 'Anläggning', 'Stål', 'Teknik'], retail: ['Handel', 'Retail', 'Service'], logi: ['Transport', 'Logistik', 'Spedition'],
      ent: { any: 'AB', fin: 'AB', build: 'AB', logi: 'AB', tech: 'AB', retail: 'AB', small: 'HB' }, roots: 'Svenska,Svea,Nordisk,Fjäll,Mälar,Norrlands,Skåne,Vättern' },
    UK: { m: 'Oliver,George,Harry,Noah,Jack,Charlie,Leo,Jacob,Freddie,Alfie', f: 'Olivia,Amelia,Isla,Ava,Mia,Ivy,Lily,Freya,Florence,Rosie', l: 'Smith,Jones,Taylor,Brown,Williams,Wilson,Johnson,Davies,Robinson,Wright',
      tech: ['Systems', 'Solutions', 'Tech', 'Digital'], fin: ['Capital', 'Asset Management', 'Fiduciary', 'Advisory'], build: ['Civil', 'Structural', 'Developments', 'Builders'], retail: ['Goods', 'Brands', 'Provisions', 'Venues'], logi: ['Freight', 'Express', 'Logistics', 'Transit'],
      ent: { any: 'Ltd', fin: 'LLP', build: 'Ltd', logi: 'Ltd', tech: 'Ltd', retail: 'Ltd' }, roots: 'Sovereign,Albion,Britannia,Royal Thames,Pennine,Cotswold,Highland,Mersey' },
    AU: { m: 'Oliver,Noah,William,Jack,Leo,Henry,Charlie,Thomas,Lucas,Ethan', f: 'Charlotte,Amelia,Isla,Mia,Ava,Grace,Willow,Harper,Chloe,Ella', l: 'Smith,Jones,Williams,Brown,Wilson,Taylor,Johnson,White,Martin,Anderson',
      tech: ['Cloud', 'Digital', 'Cyber', 'Soft'], fin: ['Advisory', 'Wealth', 'Capital', 'Financial'], build: ['Civil', 'Constructions', 'Builders', 'Infrastructure'], retail: ['Outlets', 'Brands', 'Traders'], logi: ['Logistics', 'Freight', 'Express', 'Haulage'],
      ent: { any: 'Pty Ltd', fin: 'Pty Ltd', build: 'Pty Ltd', logi: 'Pty Ltd', tech: 'Pty Ltd', retail: 'Pty Ltd' }, roots: 'Outback,SunState,Pacific Cross,Southern Goldfields,Coral,Murray,Kimberley,Harbour' },
    ES: { m: 'Mateo,Lucas,Hugo,Martín,Daniel,Pablo,Alejandro,Álvaro,Adrián,David', f: 'Lucía,Sofía,Martina,María,Julia,Paula,Valeria,Daniela,Alba,Carmen', l: 'García,Rodríguez,González,Fernández,López,Martínez,Sánchez,Pérez,Gómez,Martín',
      tech: ['Soluciones', 'Sistemas', 'Tecnologías', 'Digital'], fin: ['Inversiones', 'Capital', 'Gestión', 'Patrimonio'], build: ['Construcciones', 'Obras', 'Reformas', 'Estructuras'], retail: ['Comercio', 'Hostelería', 'Alimentos', 'Alimentación'], logi: ['Transportes', 'Envíos', 'Logística', 'Envíos Express'],
      ent: { any: 'S.L.', fin: 'S.A.', build: 'S.L.', logi: 'S.L.', tech: 'S.L.', retail: 'S.L.U.' }, roots: 'Hispano,Sol,Nueva Iberia,Ibérica,Levante,Cantábrico,Meseta,Guadalquivir' }
  };
  /* global names from the directory, used now and then for big international players in these trades */
  const GLOBAL = {
    tech: ['AeroLogic Systems', 'Veloce AI', 'BytePulse Labs', 'NexaGrid Cyber', 'QuantumForge Software'],
    fin: ['Meridian Crest Capital', 'Sterling Edge Partners', 'Vanguard Horizon Fiduciary', 'Prism Asset Group', 'Apex Wealth Advisory'],
    build: ['Cornerstone Developments', 'Ironwood Civil Builders', 'UrbanForge Contracting', 'Keystone Architecture Studio'],
    retail: ['Urban Nest Provisions', 'PrimeCart Commerce', 'Silk & Stone Goods', 'OmniShelf Retail', 'Heritage Provisions Co.'],
    logi: ['Atlas Intermodal Services', 'Vector Global Logistics', 'Omni Supply Chain Systems'],
    air: ['TransAtlantic Airways', 'SkyCompass Aviation Group', 'AeroGlobal Express', 'Intercontinental Air Cargo'],
    sea: ['Trident Deepwater Lines', 'Meridian Maritime Corp', 'Crest Ocean Freight', 'Anchor Navigation Group'],
    energy: ['Verdant Power Solutions', 'CleanGrid Systems', 'GreenFlow Biofuels'],
    creative: ['BoldSpectrum Studio', 'Echo Room Media', 'MindSpark Creative', 'Canvas & Ink Agency', 'Catalyst Brand Lab'],
    health: ['Vitalis Life Sciences', 'Aegis Health Tech', 'PurePinnacle Wellness', 'Cura Medtech'],
    hold: ['Omnia Enterprise Group', 'Paradigm Synergy Holdings', 'Polaris Global Ventures', 'Nexus Industrial Corp', 'Sovereign Apex Group']
  };
  /* which trades have their own vocabulary; everything else gets a universal name */
  const SECTOR = {
    webdev: 'tech', webshop: 'retail',
    bank: 'fin', insco: 'fin', fund: 'fin', hold: 'fin', acctfirm: 'fin',
    construction: 'build', electrician: 'build', plumber: 'build', engcons: 'build', realdev: 'build',
    cafe: 'retail', restaurant: 'retail', bakery: 'retail', kiosk: 'retail', boutique: 'retail', grocery: 'retail', hardware: 'retail', hotel: 'retail', nightclub: 'retail', fun: 'retail', foodtruck: 'retail', brewery: 'retail', casino: 'retail',
    courier: 'logi', trucking: 'logi', taxi: 'logi', shipping: 'logi', airline: 'logi',
    power: 'energy', oilgas: 'energy', resrent: 'rent', comrent: 'rent', parking: 'rent', factory: 'prod', furniture: 'prod', salmon: 'prod', farm: 'prod'
  };
  const GLOBAL_FOR = { airline: 'air', shipping: 'sea', mktg: 'creative', physio: 'health', power: 'energy', hold: 'hold', fund: 'fin', bank: 'fin', webdev: 'tech' };
  R25.SECTOR = SECTOR;
  const split = s => String(s || '').split(',').map(x => x.trim()).filter(Boolean);
  /* add the directory's people to the country packs (keeping the names already there) */
  Object.keys(D).forEach(k => {
    const c = CO[k], d = D[k];
    if (!c) return;
    const add = (arr, more) => { more.forEach(n => { if (arr.indexOf(n) < 0) arr.push(n); }); };
    if (Array.isArray(c.first)) add(c.first, split(d.m).concat(split(d.f)));
    if (Array.isArray(c.last)) add(c.last, split(d.l));
  });
  const cap = s => s ? s[0].toUpperCase() + s.slice(1) : s;
  const clean = s => String(s || '').replace(/[^\p{L}]/gu, '');
  const STYLE = { DE: 'de', NL: 'de', US: 'en', CA: 'en', UK: 'en', AU: 'en' };
  /* a coined brand word from a local root and a local ending ("Fjordvik", "Elbeberg"), using whole short words */
  function coin(c) {
    let w = '';
    for (let i = 0; i < 6 && (!w || w.length > 7); i++) w = clean(String(pick(c.nameA)).split(/[\s-]/)[0]);
    if (w.length > 7) w = w.slice(0, 6);
    let e = pick(COIN_END[COIN_LANG[c.code]] || COIN_END.english);
    if (w.slice(-1).toLowerCase() === e[0]) e = e.slice(1);
    return cap(w) + e;
  }
  R25.coin = coin;
  function root(c, d) {
    const r = rng(0, 1);
    if (r < 0.4 && d) return pick(split(d.roots));
    if (r < 0.75) return coin(c);
    return pick(c.nameA);
  }
  /* a sector word: prefixes are joined the way the country does it ("Hochbau Müller", "CyberSummit", "Trans-Bal") */
  function sectorWord(c, d, sec) {
    const w = pick(d[sec]);
    if (/-$/.test(w)) {
      const base = w.slice(0, -1), st = STYLE[c.code];
      if (st === 'de') return base + ' ' + pick(c.last);
      if (st === 'en') return base + cap(clean(String(pick(split(d.roots))).split(/[\s-]/)[0]));
      return base + '-' + cap(clean(String(pick(split(d.roots)))).slice(0, 3).toLowerCase());
    }
    if (/^-/.test(w)) return root(c, d) + ' ' + w.slice(1);
    return root(c, d) + ' ' + w;
  }
  function entity(d, sec, small) { const e = d && d.ent; if (!e) return ''; return (small && e.small && chance(0.4)) ? e.small : (e[sec] || e.any); }
  /* universal: no industry word at all */
  function universal(c, d) {
    const L = c.last && c.last.length ? c.last : ['Nord'];
    const r = rng(0, 1);
    if (r < 0.3) return pick(L);
    if (r < 0.45 && L.length > 1) { const a = pick(L), b = pick(L.filter(x => x !== a)); return a + ' & ' + b; }
    if (r < 0.8) return coin(c);
    return d ? pick(split(d.roots)) : pick(c.nameA);
  }
  /* a company name for a business type in a country */
  /* never hand out the name of a real, well-known company */
  const REAL = /^(american|united|delta|southwest|alaska|air canada|japan|korean|nippon|all nippon|deutsche|british|swiss|qatar|emirates|norwegian|scandinavian|finnair|iberia|lufthansa|klm|polish|latam|azul|gol|qantas|virgin|maersk|hapag)\b.*(air|airways|airlines|aviation|bank|post|shipping|lines|telekom|telecom)/i;
  R25.nameFor = function (type, cc, o) {
    for (let i = 0; i < 12; i++) { const n = nameOnce(type, cc, o); if (!REAL.test(n)) return n; }
    return nameOnce(type, cc, Object.assign({}, o, { global: false }));
  };
  function nameOnce(type, cc, o) {
    o = o || {};
    const c = CO[cc] || CC(), d = D[c.code || cc];
    const bd = BD[type], sec = SECTOR[type] || 'any';
    if (o.global !== false && GLOBAL_FOR[type] && chance(o.big ? 0.35 : 0.08)) return pick(GLOBAL[GLOBAL_FOR[type]]);
    let base;
    const TW = { taxi: ['Taxi', 'Cab', 'Taxi'], airline: ['Air', 'Airways', 'Aviation', 'Airlines'], shipping: ['Shipping', 'Maritime', 'Lines', 'Ocean Freight'] };
    if (TW[type] && chance(0.75)) base = (d && chance(0.6) ? pick(split(d.roots)) : coin(c)) + ' ' + pick(TW[type]);
    else if (d && d[sec] && sec === 'logi' && type !== 'shipping') { const dd = Object.assign({}, d, { logi: d.logi.filter(w => !/havn|maritime|shipping/i.test(w)) }); base = sectorWord(c, dd.logi.length ? dd : d, sec); }
    else if (d && d[sec]) base = sectorWord(c, d, sec);
    else if (sec === 'energy' || sec === 'rent' || sec === 'prod') { const end = pick((c.nameB && c.nameB[sec]) || NAMEB_DEFAULT[sec]); base = (chance(0.35) ? pick(c.last) : coin(c)) + ' ' + end; }
    else base = universal(c, d);
    const ent = chance(0.55) ? entity(d, d && d[sec] ? sec : 'any', bd && (bd.minSize || 1) < 1) : '';
    return (ent && base.indexOf(ent) < 0 ? base + ' ' + ent : base).replace(/\s+/g, ' ').trim();
  }
  /* rivals, default names for your own companies, and business customers (any trade) */
  window.rivalName = function (bd, city, cc) { return R25.nameFor(bd.id, cc || S.country); };
  window.coName = function (fam, city, type) { return type ? R25.nameFor(type, S.country) : R25.nameFor(pick(Object.keys(SECTOR).concat(['cons', 'law', 'staffing', 'estate', 'event', 'mktg'])), S.country, { global: false }); };
})();

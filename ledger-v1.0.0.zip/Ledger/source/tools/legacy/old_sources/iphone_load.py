import sys
from playwright.sync_api import sync_playwright
f_old, f_new = sys.argv[1], sys.argv[2]
with sync_playwright() as p:
    b = p.chromium.launch(args=['--no-sandbox'])
    ctx = b.new_context(viewport={'width':390,'height':844}, is_mobile=True, has_touch=True, device_scale_factor=3,
        user_agent='Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1')
    pg = ctx.new_page(); errs=[]
    pg.on('pageerror', lambda e: errs.append('PAGEERR '+str(e)[:300]))
    pg.on('console', lambda m: errs.append('CONSOLE '+m.text[:300]) if m.type=='error' and 'Failed to load' not in m.text else None)
    # 1 fresh load of new build
    pg.goto('file://'+f_new); pg.wait_for_timeout(1500)
    print('fresh new: body text len', len(pg.inner_text('body')), '| first:', pg.inner_text('body')[:80].replace('\n',' / '))
    print('errors fresh:', errs[:5]); errs.clear()
    # 2 make a save with the OLD build, then open it with the new one
    pg.goto('file://'+f_old); pg.wait_for_timeout(800)
    pg.evaluate(open(sys.argv[3]).read())
    for i in range(30): pg.evaluate('window.dayStep()')
    pg.evaluate('UI.save && UI.save(); 1')
    keys = pg.evaluate('Object.keys(localStorage).map(k=>k+":"+localStorage.getItem(k).length)')
    print('saved keys', keys); errs.clear()
    pg.goto('file://'+f_new); pg.wait_for_timeout(1500)
    print('old save in new build: body len', len(pg.inner_text('body')), '| first:', pg.inner_text('body')[:120].replace('\n',' / '))
    print('errors old-save:', errs[:8])
    pg.screenshot(path=sys.argv[4])
    b.close()

# round 31: the world around you
path = '/home/claude/w3/ledger.html'
T = '/home/claude/w3/tools/'
t = open(path, encoding='utf8').read()
mark = '/* ---------- no zooming: pinch, double tap, ctrl+wheel, ctrl +/- ---------- */'
assert t.count(mark) == 1
t = t.replace(mark, open(T + 'round31.js', encoding='utf8').read() + '\n' + mark)
a = "const paper = () => PAPER[S.country] || 'The Weekly Ledger';"
assert t.count(a) == 1, 'paper'
t = t.replace(a, "const paper = () => (window.R31 && R31.paperName ? R31.paperName() : null) || PAPER[S.country] || 'The Weekly Ledger';")
a = "<p class=\"lead\">' + esc(r.t) + '</p><div class=\"btnrow col\">'"
assert t.count(a) == 1, 'cel'
t = t.replace(a, "<p class=\"lead\">' + esc(r.t) + '</p>' + (window.R31 && R31.celExtra ? R31.celExtra(id, r) : '') + '<div class=\"btnrow col\">'")
i = t.rindex('</style>')
t = t[:i] + open(T + 'round31.css', encoding='utf8').read() + '\n' + t[i:]
open(path, 'w', encoding='utf8').write(t)
print('patch18 ok')

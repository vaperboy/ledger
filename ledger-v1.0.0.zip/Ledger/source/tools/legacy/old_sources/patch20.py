# round 33: every trade sells its own way
path = '/home/claude/w3/ledger.html'
T = '/home/claude/w3/tools/'
t = open(path, encoding='utf8').read()
mark = '/* ---------- no zooming: pinch, double tap, ctrl+wheel, ctrl +/- ---------- */'
assert t.count(mark) == 1
t = t.replace(mark, open(T + 'round33.js', encoding='utf8').read() + '\n' + mark)
i = t.rindex('</style>')
t = t[:i] + open(T + 'round33.css', encoding='utf8').read() + '\n' + t[i:]
open(path, 'w', encoding='utf8').write(t)
print('patch20 ok')

/* ===== Round 35: every menu where you look for it, a one-screen week report.
   Company tabs: Overview · Sales · Staff · Money · Company (Clients and Marketing are one Sales tab, money has its own tab,
   payroll sits with the staff, rarely used paperwork sinks to the bottom).
   Bottom bar: Office is now Group (You · Group · Deals · Office), Meetings is now Inbox (Waiting · Messages · Email · Meetings).
   Phone keeps only phone things: Bank, Investing, News, Reviews, Stats, Tax office, Luxury, Settings.
   Week report: one screen, no scrolling; every box opens the detail. Numbers count up once per week, not on every tap. ===== */
window.R35 = window.R35 || {};
(function () {
  'use strict';
  const R35 = window.R35;
  const U = window.UI;
  if (!U) return;
  const { ui, V, ACT, esc, row, btn, card, go, render, save, svg, openSheet, closeSheet } = U;
  const CT = window.CT;
  const P = o => esc(JSON.stringify(o));
  const live = () => S.cos.filter(c => c.st !== 'sold' && c.st !== 'bust');
  const sgn = v => v > 0 ? 'pos' : v < 0 ? 'neg' : '';
  const plus = v => (v >= 0 ? '+' : '−') + mshort(Math.abs(v));
  const unq = s => String(s || '').replace(/&quot;/g, '"').replace(/&amp;/g, '&').replace(/&#39;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>');
  function blockEnd(h, i) {
    const tag = /^<(\w+)/.exec(h.slice(i))[1];
    const re = new RegExp('<' + tag + '[\\s>]|</' + tag + '>', 'g');
    re.lastIndex = i;
    let d = 0, m;
    while ((m = re.exec(h))) {
      if (m[0][1] === '/') { d--; if (d === 0) return m.index + m[0].length; } else d++;
    }
    return h.length;
  }
  /* cut out the element that opens at the first match of marker; returns [rest, cut] */
  function cut(h, marker) {
    const i = h.indexOf(marker);
    if (i < 0) return [h, ''];
    const j = blockEnd(h, i);
    return [h.slice(0, i) + h.slice(j), h.slice(i, j)];
  }
  const stripTabs = h => cut(h, '<div class="ptabs">')[0];
  /* every tappable row in a piece of html, with what it opens */
  function rowsIn(h) {
    const out = [], re = /<button class="(lrow|contact)[^"]*"[^>]*>/g;
    let m;
    while ((m = re.exec(h))) {
      const e = blockEnd(h, m.index), html = h.slice(m.index, e);
      const a = (/data-a="([^"]*)"/.exec(m[0]) || [])[1] || '';
      let p = {};
      try { p = JSON.parse(unq((/data-p="([^"]*)"/.exec(m[0]) || [])[1] || '{}')); } catch (x) { }
      const title = ((/<b[^>]*>([\s\S]*?)<\/b>/.exec(html) || [])[1] || '').replace(/<[^>]+>/g, '');
      out.push({ a, p, key: p && (p.s || p.n || (typeof p === 'string' ? p : '')), title, html: html.replace('<button class="contact"', '<button class="lrow"').replace(/<span class="cic"[^>]*>/, '<span class="lic">') });
      re.lastIndex = e;
    }
    return out;
  }
  function rowBtn(a, p, ic, title, sub, right) {
    return '<button class="lrow" data-a="' + a + '" data-p="' + P(p) + '"><span class="lic">' + svg(ic, 20) + '</span><span class="ctext"><b>' + title + '</b>' + (sub ? '<small>' + esc(sub) + '</small>' : '') + '</span>' + (right || '<i>›</i>') + '</button>';
  }
  const rename = (html, from, to) => html.replace('<b>' + from + '</b>', '<b>' + to + '</b>');
  /* render with a different view parameter in place (some parts read ui.view.p directly) */
  function withView(p, f) {
    const old = ui.view;
    ui.view = { n: 'co', p: p };
    try { return f(); } finally { ui.view = old; }
  }

  /* ================= company tabs ================= */
  const TABS = { ov: 'Overview', cli: 'Sales', st: 'Staff', money: 'Money', more: 'Company' };
  const order = bd => bd.fam === 'club' ? ['ov', 'st', 'money', 'more'] : ['ov', 'cli', 'st', 'money', 'more'];
  function tabOf(p) {
    const t = p.t || 'ov', s = p.s || '';
    if (t === 'cli' || t === 'mk' || t === 'mkt') return 'cli';
    if (t === 'st' || t === 'ppl') return 'st';
    if (t === 'money' || t === 'mon') return 'money';
    if (t === 'fin') return s === 'close' ? 'more' : 'money';
    if (t === 'ops') return s === 'people' ? 'st' : s === 'marketing' || s === 'prices' ? 'cli' : 'more';
    if (t === 'deal') return s === 'value' || s === 'sell' ? 'money' : s === 'cust' || s === 'rivals' ? 'cli' : 'more';
    if (t === 'more' || t === 'eq' || t === 'doc' || t === 'set' || t === 'ana') return 'more';
    return 'ov';
  }
  function tabBar(co, bd, cur) {
    return '<div class="ptabs tabs35">' + order(bd).map(k => '<button class="' + (k === cur ? 'on' : '') + '" data-a="cotab" data-p="' + P({ id: co.id, v: k }) + '">' + (bd.fam === 'club' && k === 'st' ? 'Squad' : TABS[k]) + '</button>').join('') + '</div>';
  }
  function lockOver(co) {
    const n = S.npcs[co.mgr], nm = n ? n.name : 'your manager';
    return '<div class="lockover"><div class="lockbox"><b>' + esc(titleFor(co, 'mgr')) + ' runs this</b><small>' + esc(nm) + ' handles the day-to-day. Ask for changes instead of doing it yourself.</small>' + btn('Contact ' + nm.split(' ')[0], 'askmgr', { id: co.id }, 'primary wide') + '</div></div>';
  }
  const isLocked = (co, bd, p) => !!co.mgr && co.st === 'open' && bd.fam !== 'club' && !(p && p.f);

  /* --- Sales: prices, ways to sell, marketing, how you sell, agreements, complaints --- */
  function salesTab(base, co, bd, p) {
    let a = stripTabs(base.call(this, { id: co.id, t: 'cli', f: 1 }));
    const m = stripTabs(base.call(this, { id: co.id, t: 'mk', f: 1 }));
    let sw;
    [a, sw] = cut(a, '<details class="card knob30 sw33"');
    const mk = sw + '<h2 class="sec" id="mk35">Marketing</h2>' + m;
    /* competitors sit with the prices they set */
    {
      let n = 0;
      try { n = rivalsOf(co).length; } catch (e) { }
      const row36 = '<div class="lrows">' + rowBtn('codeal', { id: co.id, s: 'rivals' }, 'fire', 'Competitors', n ? n + ' rivals in ' + cityOf(co.city).name + ' · meet them, buy them, watch their prices' : 'Who you compete with') + '</div>';
      const pi = a.indexOf('<div class="card opt2 price30">');
      if (pi >= 0) { const pe = blockEnd(a, pi); a = a.slice(0, pe) + row36 + a.slice(pe); } else a = row36 + a;
    }
    const hy = a.indexOf('<h2 class="sec">How you sell</h2>');
    const cp = a.indexOf('<h2 class="sec" id="compl30">');
    const at = hy >= 0 ? hy : cp >= 0 ? cp : a.length;
    let h = a.slice(0, at) + mk + a.slice(at);
    h = h.replace('<h2 class="sec">How you sell</h2><h2', '<h2'); /* nothing left under it */
    return isLocked(co, bd, p) ? '<div class="lockwrap"><div class="locked">' + h + '</div>' + lockOver(co) + '</div>' : h;
  }

  /* --- rows that used to sit on the overview --- */
  function ovRows(co, bd) {
    let h = '';
    try { h = CT.ov(co, bd); } catch (e) { }
    return rowsIn(h);
  }

  /* --- Money: pay yourself first, then results, bills, loans, transactions, ownership, accountant --- */
  function moneyTab(co, bd) {
    const fin = withView({ id: co.id, t: 'fin', s: '' }, () => CT.fin(co, bd));
    const hub = fin.indexOf('<div class="rowlist hub">');
    const top = hub >= 0 ? fin.slice(0, hub) : '';
    const R = rowsIn(hub >= 0 ? fin.slice(hub) : fin), by = k => R.find(r => r.key === k);
    const L = [];
    /* pay yourself, with its live summary */
    if (bd.fam !== 'club') {
      const val = withView({ id: co.id, t: 'fin', s: 'value' }, () => CT.fin(co, bd));
      const ps = rowsIn(val).find(r => r.key === 'payself');
      L.push(ps ? ps.html : rowBtn('go', { n: 'payself', p: { id: co.id } }, 'coin', 'Pay yourself', co.form === 'AS' ? 'Salary, dividend, put money in' : 'Take money out or put money in'));
    }
    /* one place for every look back at the money: months, accounts, transactions, bills */
    {
      let sub = 'Months, accounts, transactions, bills';
      try { if (window.R30 && R30.monthOf) { const mo = R30.monthOf(co), last = (co.hist || [])[co.hist.length - 1]; sub = 'This month ' + plus(mo.p) + (last ? ' · last month ' + plus(last.profit) : ''); } } catch (e) { }
      L.push(rowBtn('go', { n: 'res36', p: { id: co.id } }, 'chart', 'Results', sub));
    }
    ['loans', 'value', 'legal'].forEach(k => { if (by(k)) L.push(by(k).html); });
    R.filter(r => ['books', 'loans', 'tx', 'value', 'legal', 'close', 'owner', 'sell', 'payroll29'].indexOf(r.key) < 0).forEach(r => L.push(r.html));
    return top + '<div class="lrows">' + L.join('') + '</div>';
  }

  /* --- Company: running and growing first, paperwork and closing at the bottom --- */
  const CO_ORD = ['supply', 'chain27', 'assets', 'grow', 'board12'];
  const CO_LOW = ['docs', 'ins', 'close'];
  const CO_SKIP = ['books', 'value', 'loans', 'legal', 'tx', 'owner', 'sell', 'payroll29', 'cust', 'people', 'marketing', 'prices', 'mktdetail', 'own27', 'month30', 'rivals', 'reach'];
  function companyTab(base, co, bd, p) {
    const more = stripTabs(base.call(this, { id: co.id, t: 'more', f: p.f }));
    const R = rowsIn(more).concat(ovRows(co, bd).filter(r => r.key === 'chain27'));
    /* supply chain lives inside Suppliers when there is a Suppliers page */
    if (R.find(r => r.key === 'supply')) for (let i = R.length - 1; i >= 0; i--) if (R[i].key === 'chain27') R.splice(i, 1);
    /* a board row only once there is a board to sit on */
    for (let i = R.length - 1; i >= 0; i--) if (R[i].key === 'board12' && !boardLive(R[i].p.p && R[i].p.p.k)) R.splice(i, 1);
    R.forEach(r => { if (r.key === 'grow') r.html = r.html.replace(/<b>[^<]*<\/b>/, '<b>Expand</b>'); });
    if (!R.find(r => r.key === 'close')) R.push({ key: 'close', html: rowBtn('cofin', { id: co.id, s: 'close' }, 'check', 'Close down', 'Wind the company down') });
    const seen = {}, take = k => R.filter(r => r.key === k && !seen[k] && (seen[k] = 1)).map(r => r.html).join('');
    let a = CO_ORD.map(take).join('');
    R.forEach(r => { if (!seen[r.key] && CO_SKIP.indexOf(r.key) < 0 && CO_LOW.indexOf(r.key) < 0) { seen[r.key] = 1; a += r.html; } });
    const b = CO_LOW.map(take).join('');
    return '<div class="lrows">' + a + '</div>' + (b ? '<h2 class="sec">Paperwork and closing</h2><div class="lrows">' + b + '</div>' : '');
  }

  function boardLive(key) {
    try {
      if (!key || !window.R12) return false;
      const b = R12.brdOf(key);
      return !!(R12.active && R12.active(key)); /* round 38: an emergency alone does not make a board */
    } catch (e) { return false; }
  }
  R35.boardLive = boardLive;
  R35.anyBoard = () => { try { return live().some(c => c.type !== 'hold' && window.R12 && R12.brdKeyOf && boardLive(R12.brdKeyOf(c))); } catch (e) { return false; } };

  /* --- Overview: no more link list at the bottom; each link lives in its own tab --- */
  const OV_MOVED = ['mktdetail', 'own27', 'chain27', 'payroll29', 'value'];
  function overview(h) {
    const i = h.indexOf('<h2 class="sec">More</h2>');
    if (i < 0) return h;
    const j = h.indexOf('<div class="lrows">', i);
    if (j < 0) return h;
    const e = blockEnd(h, j);
    const keep = rowsIn(h.slice(j, e)).filter(r => OV_MOVED.indexOf(r.key) < 0);
    return h.slice(0, i) + (keep.length ? '<div class="lrows">' + keep.map(r => r.html).join('') + '</div>' : '') + h.slice(e);
  }

  /* --- Staff: payroll and payday sit with the people they pay --- */
  function staffTab(h, co, bd) {
    if (!(window.R29 && R29.on && R29.on()) || !V.payroll29) return h + (V.academy && bd.crs && bd.crs.length ? '<div class="lrows">' + rowBtn('acad36', { id: co.id }, 'grad', 'Courses', 'Train your people') + '</div>' : '');
    let sub = 'Payday, who runs it, who is paid';
    try { const r = rowsIn(R29.rowHtml(co))[0]; if (r) sub = (/<small>([\s\S]*?)<\/small>/.exec(r.html) || [])[1] || sub; } catch (e) { }
    let right = '<i>›</i>';
    try { const r = R29.rowHtml(co), m = /<span class="pill [^"]*">[^<]*<\/span>/.exec(r); if (m) right = m[0]; } catch (e) { }
    if (V.academy && bd.crs && bd.crs.length) h += '<div class="lrows">' + rowBtn('acad36', { id: co.id }, 'grad', 'Courses', 'Train your people: better work, more pay, more loyalty') + '</div>';
    return h + '<h2 class="sec">Payroll</h2><div class="lrows"><button class="lrow" data-a="go" data-p="' + P({ n: 'payroll29', p: { id: co.id, v: 'pay' } }) + '"><span class="lic">' + svg('coin', 20) + '</span><span class="ctext"><b>Payroll and payday</b><small>' + sub + '</small></span>' + right + '</button></div>';
  }

  /* --- Ownership and value: market share and owners here; pay yourself lives in Money --- */
  function valuePage(h, co, bd) {
    const R = rowsIn(h), ps = R.find(r => r.key === 'payself');
    if (ps) {
      const i = h.indexOf(ps.html.replace('<button class="lrow"', '<button class="lrow"'));
      const k = h.lastIndexOf('<div class="lrows">', i);
      if (k >= 0 && blockEnd(h, k) >= i + ps.html.length && rowsIn(h.slice(k, blockEnd(h, k))).length === 1) h = h.slice(0, k) + h.slice(blockEnd(h, k));
      else if (i >= 0) h = h.slice(0, i) + h.slice(i + ps.html.length);
    }
    const add = ovRows(co, bd).filter(r => r.key === 'mktdetail' || r.key === 'own27');
    return add.length ? h + '<div class="lrows">' + add.map(r => r.html).join('') + '</div>' : h;
  }

  const co35 = V.co;
  V.co = function (p) {
    const co = p && getCo(p.id);
    if (!co || co.type === 'hold' || co.st === 'sold' || co.st === 'bust' || !BD[co.type]) return co35.apply(this, arguments);
    const bd = BD[co.type];
    try {
      let cur = tabOf(p);
      if (bd.fam === 'club' && cur === 'cli') cur = 'ov';
      const t = p.t || 'ov', sub = !!p.s && ['ops', 'fin', 'deal'].indexOf(t) >= 0;
      let body;
      if (sub) {
        body = stripTabs(co35.apply(this, arguments));
        /* the back arrow returns to the tab the page belongs to */
        body = body.replace(/<div class="subhead"><button class="iconbtn" data-a="(cofin|cosub|codeal)" data-p="[^"]*"/, '<div class="subhead"><button class="iconbtn" data-a="cotab" data-p="' + P({ id: co.id, v: cur }) + '"');
        if (t === 'fin' && p.s === 'value') body = valuePage(body, co, bd);
        if (t === 'deal' && p.s === 'grow') {
          body = body.replace(/(<div class="subhead">[\s\S]*?<h2>)[^<]*(<\/h2>)/, '$1Expand$2');
          try {
            let reach = withView({ id: co.id, t: 'deal', s: 'reach' }, () => CT.deal(co, bd));
            const sh = reach.indexOf('<div class="subhead">');
            if (sh >= 0) reach = reach.slice(0, sh) + reach.slice(blockEnd(reach, sh));
            const k = body.indexOf('<div class="subhead">'), ke = k >= 0 ? blockEnd(body, k) : 0;
            body = body.slice(0, ke) + reach + body.slice(ke);
          } catch (e) { }
        }
        if (t === 'deal' && p.s === 'supply' && V.chain27) {
          try { const sc = V.chain27({ id: co.id }); if (sc && sc.indexOf('class="calm"') < 0) body += '<h2 class="sec">Supply chain</h2>' + sc; } catch (e) { }
        }
      } else if (cur === 'cli') {
        body = salesTab.call(this, co35, co, bd, p);
        if (t === 'mk' || t === 'mkt') setTimeout(() => { const el = document.getElementById('mk35'); if (el) el.scrollIntoView({ block: 'start' }); }, 60);
      } else if (cur === 'money') body = '<div class="cols">' + moneyTab(co, bd) + '</div>';
      else if (cur === 'more') body = companyTab.call(this, co35, co, bd, p);
      else if (cur === 'st') body = staffTab(stripTabs(co35.call(this, Object.assign({}, p, { t: 'st' }))), co, bd);
      else body = overview(stripTabs(co35.call(this, Object.assign({}, p, { t: 'ov' }))));
      return tabBar(co, bd, cur) + body;
    } catch (e) {
      console.error(e);
      return co35.apply(this, arguments);
    }
  };
  R35.tabOf = tabOf;
  ACT.acad36 = p => { ui.acad = { co: p.id }; go('academy'); };
  V.titles.academy = 'Courses';

  /* ================= Group (was Office) ================= */
  const HQ = [['you', 'You'], ['grp', 'Group'], ['office', 'Office']];
  const LEG = { group: 'grp', managers: 'grp', suppliers: 'grp', dealroom: 'grp', deals: 'grp', office: 'office' };
  const hsub = n => { try { return V.heads[n] ? V.heads[n]().sub || '' : ''; } catch (e) { return ''; } };
  const strip = h => String(h || '').replace(/<[^>]+>/g, '');
  function officeYou() {
    /* the R31 block at the top of the office: Public image, People you know, Maps, Rivals */
    let h = '';
    try { h = V.office(); } catch (e) { }
    const i = h.indexOf('<h2 class="sec first">You</h2>');
    if (i < 0) return { rows: [], rest: h };
    const j = h.indexOf('<div class="lrows">', i), e = blockEnd(h, j);
    return { rows: rowsIn(h.slice(j, e)), rest: h.slice(0, i) + h.slice(e) };
  }
  function youTab() {
    const R = officeYou().rows, by = k => (R.find(r => r.key === k) || {}).html || '';
    let img = '';
    try {
      const pi = R.find(r => r.key === 'img31');
      if (pi && V.img31) { const sub = (/<small>([\s\S]*?)<\/small>/.exec(pi.html) || [])[1] || ''; img = '<button class="card opt2 img36" data-a="go" data-p="' + P({ n: 'img31' }) + '"><div class="bhead"><b>Public image</b><span class="pill blue">How people see you ›</span></div><span class="tipt">' + sub + '</span></button>'; }
    } catch (e) { }
    const L = [];
    L.push(by('net31') || (V.net31 ? rowBtn('go', { n: 'net31', p: {} }, 'people', 'People you know', 'Contacts, favours and promises') : ''));
    if (V.trophies28) L.push(rowBtn('go', { n: 'trophies28' }, 'star', 'Trophies', strip(hsub('trophies28')) || 'Your firsts'));
    if (V.give28) L.push(rowBtn('go', { n: 'give28' }, 'house', 'Giving back', strip(hsub('give28'))));
    if (V.amb27) L.push(rowBtn('go', { n: 'amb27' }, 'star', 'Ambition', strip(hsub('amb27'))));
    return img + '<div class="lrows">' + L.join('') + '</div>';
  }
  const hasMgr = () => live().some(c => c.mgr && S.npcs[c.mgr]);
  R35.hasMgr = hasMgr;
  function grpTab() {
    const R = officeYou().rows, by = k => (R.find(r => r.key === k) || {}).html || '';
    const nCr = window.crisisCount ? window.crisisCount() : 0, boards = R35.anyBoard();
    const L = [];
    L.push(by('map31') || (V.map31 ? rowBtn('go', { n: 'map31', p: {} }, 'chart', 'Maps', 'Ownership, presence, influence') : ''));
    if (V.mkt36) L.push(rowBtn('go', { n: 'mkt36' }, 'fire', 'Market', 'Your share, your rivals, the economy'));
    if (V.suppliers) L.push(rowBtn('go', { n: 'suppliers' }, 'truck', 'Group suppliers', 'Deals that every company buys through'));
    if (V.managers && hasMgr()) L.push(rowBtn('go', { n: 'managers' }, 'people', 'Manager reviews', 'Scorecards and reviews for every manager'));
    if (V.boards12 && boards) L.push(rowBtn('go', { n: 'boards12', p: {} }, 'people', 'Boards', 'Seats, meetings, your left hand'));
    if (V.crisis && nCr) L.push(rowBtn('go', { n: 'crisis' }, 'alert', 'Crisis centre', nCr + ' open', '<span class="pill red">' + nCr + '</span>'));
    let g = V.group ? V.group() : '';
    { const i = g.indexOf('<button class="card opt2" data-a="go" data-p="' + P({ n: 'boards12', p: {} }) + '"'); if (i >= 0) g = g.slice(0, i) + g.slice(blockEnd(g, i)); }
    return '<div class="lrows">' + L.join('') + '</div><h2 class="sec">Structure</h2>' + g;
  }
  function officeTab() {
    let h = officeYou().rest;
    rowsIn(h).filter(r => r.key === 'academy' || r.key === 'reports').forEach(r => { h = h.replace(r.html.replace('<button class="lrow"', '<button class="lrow"'), ''); });
    return h.replace(/<div class="lrows"><\/div>/g, '');
  }
  V.titles.hq = 'Group';
  V.titles.managers = 'Manager reviews';
  V.titles.suppliers = 'Group suppliers';
  V.hq = function (p) {
    let t = (p && p.t) || ui.hqt || 'you';
    const legacy = LEG[t] ? t : null;
    if (legacy) t = LEG[t];
    if (!HQ.find(x => x[0] === t)) t = 'you';
    ui.hqt = t;
    const root = ui.tab === 'hq' && !ui.stack.length;
    const nCr = window.crisisCount ? window.crisisCount() : 0;
    let body;
    if (legacy === 'managers' || legacy === 'suppliers' || legacy === 'dealroom') body = V[legacy]();
    else if (t === 'grp') body = grpTab();
    else if (t === 'office') body = officeTab();
    else body = youTab();
    return (root ? '<header class="hh"><h1>Group</h1>' + (nCr ? '<button class="pill red" data-a="go" data-p="' + P({ n: 'crisis' }) + '">Crisis · ' + nCr + '</button>' : '') + '</header>' : '') + '<div class="ptabs">' + HQ.map(x => '<button class="' + (t === x[0] ? 'on' : '') + '" data-a="hqtab" data-p="' + x[0] + '">' + x[1] + '</button>').join('') + '</div><div class="fill">' + body + '</div>';
  };
  ACT.hqtab = p => {
    const v = typeof p === 'string' ? p : p && p.v;
    ui.hqt = LEG[v] || v;
    ui.view = { n: 'hq', p: { t: ui.hqt } };
    render(true);
  };

  /* ================= Phone: only phone things ================= */
  const TINT = { g: 'tg', a: 'ta', b: 'tb', r: 'tr', n: 'tn' };
  const APPS = [['bank', 'bank', 'Bank', 'g'], ['invest', 'invest', 'Investing', 'b'], ['news', 'news', 'News', 'n'], ['reviews', 'star', 'Reviews', 'a'], ['stats', 'chart', 'Stats', 'n'], ['lux', 'star', 'Luxury', 'a'], ['settings', 'cog', 'Settings', 'n']];
  const ph0 = V.phonehome;
  V.phonehome = function () {
    try {
      let h = '<header class="hh"><h1>Phone</h1><small>' + todayLabel().split(' · ')[1] + '</small></header>';
      h += '<div class="pgrid">' + APPS.filter(a => V[a[0]]).map(a => '<button class="app2" data-a="phapp" data-p="' + P({ n: a[0] }) + '"><span class="tile ' + TINT[a[3]] + '">' + svg(a[1], 24) + '</span><span>' + a[2] + '</span></button>').join('') + '</div>';
      return h;
    } catch (e) { return ph0.apply(this, arguments); }
  };

  /* ================= week report: one screen ================= */
  const COSTN = { cogs: 'Materials and goods', wages: 'Wages and payroll', rent: 'Rent and power', mkt: 'Marketing', ins: 'Insurance', acc: 'Accounting', dep: 'Depreciation', int: 'Interest', oth: 'Leasing and other costs', fine: 'Fines', loss: 'Refunds and losses' };
  function nums() {
    const r = S.lastRep || {}, L = S.wk31 || [], a = L[L.length - 1], b = L[L.length - 2] || null;
    if (a) return { a: 1, nw: a.nw, cash: a.cash, rev: a.rev, profit: a.profit, sh: a.sh, p: b ? { nw: b.nw, cash: b.cash, rev: b.rev, profit: b.profit, sh: b.sh } : null };
    const bw = r.bw || {}, rev = bw.rev || 0, nw = netWorth().total;
    return { a: 0, nw, cash: S.cash, rev, profit: rev - sumExp(bw), sh: 0, p: r.nw0 != null ? { nw: r.nw0 } : null };
  }
  const NUMN = { nw: 'Net worth', cash: 'Cash', rev: 'Revenue', profit: 'Profit', sh: 'Shares' };
  function evTone(e) { return e.tone === 'good' ? 'g' : e.tone === 'bad' ? 'r' : ''; }
  V.weekreport = function () {
    const r = S.lastRep;
    if (!r) return '<div class="calm">The first report arrives at the end of your first full week.</div>';
    const n = nums();
    const key = (r.w || 0) + ':' + Math.round(r.nw0 || 0) + ':' + (S.wk31 ? S.wk31.length : 0);
    const anim = ui.wr35k !== key;
    ui.wr35k = key;
    const val = (k, cls) => anim ? '<b class="cnt28 ' + (cls || '') + '" data-to="' + Math.round(n[k] || 0) + '">' + mshort(0) + '</b>' : '<b class="' + (cls || '') + '">' + mshort(n[k] || 0) + '</b>';
    const dv = k => n.p && n.p[k] != null ? n[k] - n.p[k] : null;
    const tap = k => n.a ? ' data-a="fin31" data-p="' + P({ k }) + '"' : ' data-a="none"';
    const tile = k => { const d = dv(k); return '<button class="card wt35"' + tap(k) + '><span>' + NUMN[k] + '</span>' + val(k, k === 'profit' ? sgn(n.profit) : '') + '<em class="' + (d == null ? '' : sgn(d)) + '">' + (d == null ? '–' : plus(d)) + '</em></button>'; };
    const dnw = dv('nw');
    let h = '<button class="card wnw35"' + tap('nw') + '><span class="lab">Net worth</span>' + val('nw', 'huge') + '<em class="' + (dnw == null ? '' : sgn(dnw)) + '">' + (dnw == null ? 'First week' : plus(dnw) + ' vs last week') + '</em><i>›</i></button>';
    const ks = ['cash', 'rev', 'profit'].concat(n.sh || (n.p && n.p.sh) ? ['sh'] : []);
    h += '<div class="wtiles35 n' + ks.length + '">' + ks.map(tile).join('') + '</div>';
    /* companies, best and worst first */
    const cs = (r.cos || []).slice().sort((x, y) => Math.abs(y.profit) - Math.abs(x.profit));
    h += '<button class="card wbox35" data-a="wr35s" data-p="' + P({ k: 'cos' }) + '"><div class="bhead"><b>Companies</b><small>' + (cs.length ? cs.length + ' · see all ›' : '') + '</small></div>' + (cs.length ? cs.map(c => '<div class="wr35r"><span>' + esc(c.name) + '</span><small>' + mshort(c.rev) + '</small><b class="' + sgn(c.profit) + '">' + plus(c.profit) + '</b></div>').join('') : '<span class="tipt">No company traded this week.</span>') + '</button>';
    /* what happened: problems first */
    const ev = (r.ev || []).slice(), rank = e => e.tone === 'bad' ? 0 : e.tone === 'good' ? 1 : 2;
    ev.sort((x, y) => rank(x) - rank(y));
    const nb = ev.filter(e => e.tone === 'bad').length, ng = ev.filter(e => e.tone === 'good').length;
    h += '<button class="card wbox35" data-a="wr35s" data-p="' + P({ k: 'ev' }) + '"><div class="bhead"><b>What happened</b><small>' + (ev.length ? (nb ? nb + ' problem' + (nb > 1 ? 's' : '') + ' · ' : '') + (ng ? ng + ' good · ' : '') + 'all ' + ev.length + ' ›' : '') + '</small></div>' + (ev.length ? ev.map(e => { const co = e.co ? getCo(e.co) : null; return '<div class="wr35e"><i class="' + evTone(e) + '"></i><span>' + esc(e.t) + (co ? ' <small>' + esc(co.name) + '</small>' : '') + '</span></div>'; }).join('') : '<span class="tipt">A quiet week.</span>') + '</button>';
    h += '<button class="btn primary wide go repgo' + (ui.repLock ? ' wait' : '') + '" data-a="repdone"' + (ui.repLock ? ' disabled' : '') + '>Continue</button>';
    return '<div class="wr35' + (anim ? ' repanim' : '') + '">' + h + '</div>';
  };
  /* the header shows the same change as the big number below it */
  const hw0 = V.heads.weekreport;
  V.heads.weekreport = function () {
    const o = hw0 ? hw0.apply(this, arguments) : { t: 'Week report' };
    try {
      if (!S.lastRep) return o;
      const n = nums(), d = n.p && n.p.nw != null ? n.nw - n.p.nw : null;
      o.right = d == null ? '' : '<span class="pill ' + (d >= 0 ? 'grn' : 'amb') + '">' + plus(d) + '</span>';
    } catch (e) { }
    return o;
  };
  ACT.wr35s = p => {
    const r = S.lastRep;
    if (!r) return;
    let h;
    if (p.k === 'cos') {
      const b = r.bw || {}, lines = Object.keys(COSTN).filter(k => b[k]);
      h = '<h2>Companies this week</h2><div class="lrows">' + (r.cos || []).map(c => '<button class="lrow" data-a="wr35co" data-p="' + P({ id: c.id }) + '"><span class="ctext"><b>' + esc(c.name) + '</b><small>' + esc(window.fmtU ? window.fmtU(c.units || 0, c.unit) : Math.round(c.units || 0) + ' ' + unitPl(c.unit, c.units || 0)) + ' · revenue ' + mshort(c.rev) + '</small></span><b class="num ' + sgn(c.profit) + '">' + plus(c.profit) + '</b></button>').join('') + '</div>';
      if (b.rev || lines.length) h += '<h3>Money in and out</h3>' + row('Revenue', mshort(b.rev || 0)) + lines.map(k => row(COSTN[k], '−' + mshort(b[k]))).join('') + (r.meD ? row('Your private account', '<span class="' + sgn(r.meD) + '">' + plus(r.meD) + '</span>') : '');
    } else {
      const ev = (r.ev || []);
      h = '<h2>What happened</h2><div class="lrows">' + (ev.length ? ev.map(e => { const co = e.co ? getCo(e.co) : null; const tg = e.tone === 'good' ? ['Good', 'green'] : e.tone === 'bad' ? ['Problem', 'red'] : ['Info', '']; return '<div class="lrow"><span class="ctext"><b class="wrap">' + esc(e.t) + '</b>' + (co ? '<small>' + esc(co.name) + '</small>' : '') + '</span><span class="badge ' + tg[1] + '">' + tg[0] + '</span></div>'; }).join('') : '<div class="lrow"><small>A quiet week.</small></div>') + '</div>';
    }
    openSheet(h + btn('Close', 'sheetclose', undefined, 'ghost wide'), 'wr35sh');
  };
  ACT.wr35co = p => { closeSheet(); go('co', { id: p.id }); };
  /* after Continue, problems may pop up one at a time again */
  const rd0 = ACT.repdone;
  ACT.repdone = function () {
    const r = rd0.apply(this, arguments);
    setTimeout(() => { try { if (window.R30 && R30.maybeAlert && !ui.sheet) R30.maybeAlert(); } catch (e) { } }, 300);
    return r;
  };
})();

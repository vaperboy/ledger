/* ===== Round 28c: purpose and short goals.
   Giving back: sponsor the local club, fund a scholarship, build a park or a hospital wing, or start a foundation.
   Each leaves a named mark, raises your standing in that city (people there choose your businesses a little more often)
   and adds to your legacy.
   Goals: every month your managers (or the board) set a target for their company; you can also ask a manager,
   the group CEO or the board for one yourself. They say yes, or tell you what is realistic. A target changes
   what they focus on, and that has a price elsewhere. ===== */
(function () {
  const R28 = window.R28 = window.R28 || {};
  const U = window.UI, { toast, save, render, svg, row } = U;
  const P = o => esc(JSON.stringify(o));
  const pillp = (t, c) => '<span class="pill ' + (c || '') + '">' + t + '</span>';
  const sumF = (a, f) => a.reduce((t, x) => t + (f(x) || 0), 0);
  const MI = () => monthIdx(S.week);
  const sur = () => String(S.player.name || 'You').split(' ').slice(-1)[0];
  const live = () => S.cos.filter(c => c.st === 'open');
  const K = v => v * costIdx(S.country);
  const legacy = (pts, t) => { if (!window.R27 || !R27.amb) return; const a = R27.amb(); a.score += pts; a.hist.unshift({ w: S.week, t, path: 'give', pts }); if (a.hist.length > 40) a.hist.length = 40; };
  const img = (k, d) => { if (S.pr28) S.pr28.img[k] = Math.max(0, Math.min(100, S.pr28.img[k] + d)); };

  /* ================= giving back ================= */
  const G = () => { S.give28 = S.give28 || { marks: [], rep: {}, yearly: [], found: null }; return S.give28; };
  const ck = (cc, city) => cc + '|' + city;
  const GIVE = {
    club: { n: 'Sponsor the local football club', y: 1, c: 250000, rep: 8, leg: 15, img: ['care', 2], mark: (c) => c + ' FC, sponsored by ' + sur(), d: 'Your name on the shirts and around the pitch. Everyone in town sees it every weekend.' },
    fest: { n: 'Sponsor the summer festival', y: 1, c: 400000, rep: 6, leg: 12, img: ['bold', 2], mark: (c) => 'The ' + c + ' summer festival, presented by ' + sur(), d: 'Bars, restaurants and shops in town feel it too.' },
    food: { n: 'Support the food bank', y: 1, c: 120000, rep: 3, leg: 8, img: ['care', 4], mark: (c) => 'Main supporter of the ' + c + ' food bank', d: 'Quiet, steady help. People notice who shows up every year.' },
    schol: { n: 'Found a scholarship', y: 0, c: 2e6, rep: 4, leg: 60, img: ['care', 6], mark: () => 'The ' + sur() + ' Scholarship', d: 'Pays for young people to study. Your staff are proud of it.' },
    park: { n: 'Build a park and playground', y: 0, c: 6e6, rep: 12, leg: 90, img: ['care', 4], mark: (c) => sur() + ' Park, ' + c, d: 'A place families use every day.' },
    gallery: { n: 'Fund a museum gallery', y: 0, c: 15e6, rep: 10, leg: 180, img: ['trust', 3], mark: (c) => 'The ' + sur() + ' Gallery at the ' + c + ' museum', d: 'Art, history, and your name above the door.' },
    wing: { n: 'Build a hospital wing', y: 0, c: 40e6, rep: 25, leg: 400, img: ['trust', 8], mark: (c) => 'The ' + sur() + ' Wing, ' + c + ' Hospital', d: 'The biggest thing most people ever give. It will outlast every company you own.' }
  };
  R28.giveCount = () => G().marks.length + (G().found ? 1 : 0);
  function cities() {
    const s = {};
    live().forEach(c => { s[ck(c.country, c.city)] = { cc: c.country, city: c.city }; });
    if (S.player && S.player.city) s[ck(S.country, S.player.city)] = s[ck(S.country, S.player.city)] || { cc: S.country, city: S.player.city };
    return Object.values(s);
  }
  const cname = (cc, city) => { try { return (CO[cc].cities.find(x => x.id === city) || {}).name || city; } catch (e) { return city; } };
  function giveTo(k, cc, city, fromFound) {
    const g = GIVE[k], cost = Math.round(K(g.c) / 1000) * 1000, nm = cname(cc, city);
    if (!fromFound) { if (S.cash < cost) return 'cash'; payMe(cost, g.n + ' (' + nm + ')'); }
    const R = G().rep, key = ck(cc, city);
    R[key] = Math.min(100, (R[key] || 0) + g.rep);
    if (g.img) img(g.img[0], g.img[1]);
    legacy(g.leg, g.mark(nm));
    if (k === 'schol') live().forEach(c => { c.mood = Math.min(100, (c.mood || 60) + 3); });
    if (k === 'fest') live().filter(c => c.city === city && (BD[c.type].fam === 'venue' || BD[c.type].fam === 'retail')).forEach(c => { c.aware = Math.min(100, (c.aware || 0) + 4); });
    if (k === 'club') live().filter(c => c.city === city).forEach(c => { c.aware = Math.min(100, (c.aware || 0) + 3); });
    const ex = G().marks.find(m => m.k === k && m.key === key);
    if (!ex) G().marks.unshift({ k, key, cc, city, w: S.week, name: g.mark(nm), y: g.y });
    if (g.y && !fromFound && !G().yearly.some(y => y.k === k && y.key === key)) G().yearly.push({ k, key, cc, city, next: S.week + 52 });
    if (window.R28 && R28.press) R28.press(g.y ? 3 : 4.5, g.y ? S.player.name + ' backs ' + g.mark(nm).toLowerCase().replace(/^the /, 'the ') : g.mark(nm) + ' opens', g.y ? '' : 'A gift from ' + S.player.name + ' to ' + nm + '.');
    return 'ok';
  }
  R28.giveTo = giveTo;
  /* standing in a city: a little more demand there */
  const dm0 = window.demand;
  window.demand = function (co, bd) {
    const r = dm0.apply(this, arguments);
    try { const v = S.give28 && S.give28.rep[ck(co.country, co.city)]; if (v > 0 && r && r.D > 0) { const f = 1 + Math.min(0.06, v * 0.0008); r.D *= f; if (r.parts) r.parts.city27 = f; } } catch (e) { }
    return r;
  };
  function giveWeek() {
    const g = G();
    /* yearly sponsorships renew, if you can pay */
    g.yearly = g.yearly.filter(y => {
      if (S.week < y.next) return true;
      const cost = Math.round(K(GIVE[y.k].c) / 1000) * 1000;
      if (S.cash < cost) { note('You could not renew ' + GIVE[y.k].n.toLowerCase() + ' in ' + cname(y.cc, y.city) + '. The sponsorship has ended.', 'bad'); g.marks = g.marks.filter(m => !(m.k === y.k && m.key === y.key)); return false; }
      payMe(cost, GIVE[y.k].n + ' (' + cname(y.cc, y.city) + ')');
      g.rep[y.key] = Math.min(100, (g.rep[y.key] || 0) + GIVE[y.k].rep * 0.6);
      legacy(Math.round(GIVE[y.k].leg * 0.6), GIVE[y.k].mark(cname(y.cc, y.city)) + ', another year');
      y.next = S.week + 52;
      return true;
    });
    /* standing fades slowly unless you keep giving */
    if (S.week % 13 === 0) Object.keys(g.rep).forEach(k => { g.rep[k] = Math.max(0, g.rep[k] * 0.975); });
    /* the foundation gives every year */
    if (g.found && S.week >= g.found.next) {
      const grant = g.found.cap * 0.04;
      const cs = cities();
      cs.forEach(c => { g.rep[ck(c.cc, c.city)] = Math.min(100, (g.rep[ck(c.cc, c.city)] || 0) + Math.min(10, grant / K(1e6) * 1.5 / cs.length)); });
      legacy(Math.round(Math.min(200, grant / K(1e6) * 4)), 'The ' + sur() + ' Foundation gave ' + mshort(grant));
      img('care', 2);
      g.found.given = (g.found.given || 0) + grant;
      g.found.next = S.week + 52;
      info('The ' + sur() + ' Foundation', 'The foundation gave ' + money(grant) + ' this year', 'Grants to schools, clubs and people in need in ' + cs.map(c => cname(c.cc, c.city)).join(', ') + '.', 0, 'good');
    }
  }
  V.titles.give28 = 'Giving back';
  V.heads = V.heads || {};
  V.heads.give28 = () => ({ t: 'Giving back', sub: R28.giveCount() ? R28.giveCount() + ' marks you have left' : 'What your money can do for others' });
  V.give28 = function () {
    const g = G(), cs = cities();
    const cur = ui.gc28 && cs.find(c => ck(c.cc, c.city) === ui.gc28) || cs[0];
    if (!cur) return '<div class="calm">Start a business first.</div>';
    const key = ck(cur.cc, cur.city), rp = g.rep[key] || 0;
    let h = '<div class="card sense"><span class="tipt">Money you give does not come back. It buys standing in a city (people there choose your businesses a little more often), a better name, and a legacy that outlives your companies.</span></div>';
    if (cs.length > 1) h += '<div class="chips">' + cs.map(c => '<button class="btn chip' + (ck(c.cc, c.city) === key ? ' primary' : '') + '" data-a="gc28" data-p="' + P({ v: ck(c.cc, c.city) }) + '">' + esc(cname(c.cc, c.city)) + '</button>').join('') + '</div>';
    h += '<div class="card"><div class="bhead"><b>Your standing in ' + esc(cname(cur.cc, cur.city)) + '</b>' + pillp(rp >= 40 ? 'Loved' : rp >= 20 ? 'Respected' : rp >= 5 ? 'Known' : 'Unknown', rp >= 20 ? 'grn' : '') + '</div><div class="bar"><i style="width:' + Math.max(2, rp) + '%;background:var(--amber)"></i></div><span class="tipt">' + (rp > 0 ? 'Your businesses there get about ' + (Math.min(6, rp * 0.08)).toFixed(1) + '% more customers.' : 'Nobody there knows you outside your shops yet.') + '</span></div>';
    h += '<h2 class="sec">Every year</h2><div class="lrows">' + Object.keys(GIVE).filter(k => GIVE[k].y).map(k => opt(k, cur)).join('') + '</div>';
    h += '<h2 class="sec">Once, for good</h2><div class="lrows">' + Object.keys(GIVE).filter(k => !GIVE[k].y).map(k => opt(k, cur)).join('') + '</div>';
    h += '<h2 class="sec">A foundation</h2><div class="card">' + (g.found ? row('The ' + esc(sur()) + ' Foundation', mshort(g.found.cap)) + row('Given so far', mshort(g.found.given || 0)) + '<span class="tipt">Gives about 4% a year to your cities, for as long as it exists.</span>' : '<span class="tipt">Put money into a foundation once, and it gives about 4% of it away every year, in every city you work in. The money is no longer yours.</span><div class="chips">' + [10e6, 50e6, 200e6].map(v => btn(mshort(K(v)), 'found28', { v: Math.round(K(v)) }, 'chip')).join('') + '</div>') + '</div>';
    if (g.marks.length) h += '<h2 class="sec">Your marks</h2><div class="lrows">' + g.marks.map(m => '<div class="lrow"><span class="lic">' + svg(m.y ? 'star' : 'house', 20) + '</span><span class="ctext"><b class="wrap">' + esc(m.name) + '</b><small>' + (m.y ? 'Every year since ' : 'Since ') + wYear(m.w) + '</small></span></div>').join('') + '</div>';
    return h;
  };
  function opt(k, cur) {
    const g = GIVE[k], cost = Math.round(K(g.c) / 1000) * 1000, key = ck(cur.cc, cur.city);
    const done = G().marks.some(m => m.k === k && m.key === key);
    return '<button class="lrow" data-a="' + (done ? 'none' : 'give28') + '" data-p="' + P({ k, key }) + '"><span class="ctext"><b>' + esc(g.n) + '</b><small>' + esc(g.d) + '</small></span>' + (done ? pillp(g.y ? 'Yours' : 'Done', 'grn') : '<b>' + mshort(cost) + (g.y ? '<small>/yr</small>' : '') + '</b>') + '</button>';
  }
  ACT.gc28 = p => { ui.gc28 = p.v; render(); };
  ACT.give28 = p => {
    const g = GIVE[p.k], [cc, city] = p.key.split('|'), cost = Math.round(K(g.c) / 1000) * 1000;
    confirmThen(g.n + '?', money(cost) + (g.y ? ' a year, from your own money.' : ' from your own money, once.') + ' Your name: "' + g.mark(cname(cc, city)) + '".', 'Give', () => {
      const r = giveTo(p.k, cc, city);
      if (r !== 'ok') { toast('Not enough cash in your own account.', true); return; }
      save(); render(true); toast('Thank you, from ' + cname(cc, city) + '.');
    });
  };
  ACT.found28 = p => {
    confirmThen('Start the ' + sur() + ' Foundation?', 'You put ' + money(p.v) + ' in. It is no longer yours; the foundation gives about ' + money(p.v * 0.04) + ' a year to your cities.', 'Start it', () => {
      if (S.cash < p.v) { toast('Not enough cash.', true); return; }
      payMe(p.v, 'Endowment: the ' + sur() + ' Foundation');
      G().found = { cap: p.v, w: S.week, next: S.week + 4, given: 0 };
      legacy(Math.round(Math.min(500, p.v / K(1e6) * 3)), 'Started the ' + sur() + ' Foundation');
      img('care', 6); img('trust', 4);
      if (R28.press) R28.press(5, 'The ' + sur() + ' Foundation is born', S.player.name + ' gives ' + mshort(p.v) + ' to a new foundation.');
      save(); render(true); toast('The ' + sur() + ' Foundation is started.');
    });
  };
  if (typeof APP !== 'undefined' && typeof FOLD !== 'undefined') { APP.give28 = ['house', 'Giving back', 'g', ['go', { n: 'give28' }]]; if (FOLD.money.apps.indexOf('give28') < 0) FOLD.money.apps.push('give28'); }

  /* ================= goals ================= */
  const GL = () => { S.gl28 = S.gl28 || {}; return S.gl28; };
  const isHotel = co => /room|night/i.test(BD[co.type].unit || '');
  const M = {
    util: { n: co => isHotel(co) ? 'Occupancy' : 'How busy', now: co => { const H = (co.wh22 || []).slice(-4); return H.length ? sumF(H, x => x.u) / H.length : (co.lastW ? co.lastW.util || 0 : 0); }, f: v => Math.round(v * 100) + '%', step: 0.05, up: 1 },
    rating: { n: () => 'Rating', now: co => ratingOf(co), f: v => v.toFixed(1) + ' ★', step: 0.1, up: 1, ok: co => (co.rvN || 0) >= 10 },
    rev: { n: () => 'Monthly sales', now: co => { const h = co.hist || []; return h.length ? h[h.length - 1].rev : (co.bk.m.rev || 0); }, f: v => mshort(v), step: 0.05, up: 1, rel: 1 },
    profit: { n: () => 'Monthly profit', now: co => { const h = co.hist || []; return h.length ? h[h.length - 1].profit : 0; }, f: v => (v >= 0 ? '' : '−') + mshort(Math.abs(v)), step: 0.1, up: 1, rel: 1 },
    aware: { n: () => 'Awareness', now: co => co.aware || 0, f: v => Math.round(v) + ' / 100', step: 4, up: 1 }
  };
  R28.GM = M;
  /* how hard a target is: about how many months of solid work it needs */
  function diff(co, k, target, months) {
    const m = M[k], cur = m.now(co);
    let need;
    if (k === 'rev') need = cur > 0 ? (target / cur - 1) / 0.05 : 3;
    else if (k === 'profit') need = (target - cur) / Math.max(K(5000), Math.abs(cur) * 0.1, (co.hist && co.hist.length ? co.hist[co.hist.length - 1].rev : 0) * 0.02);
    else need = (target - cur) / m.step;
    return Math.max(0, need) / Math.max(1, months);
  }
  function levels(co, k) {
    const m = M[k], cur = m.now(co);
    if (k === 'rating') return [0.1, 0.25, 0.45].map(d => Math.min(5, Math.round((cur + d) * 10) / 10));
    if (k === 'util') return [0.05, 0.12, 0.22].map(d => Math.min(1, Math.round((cur + d) * 20) / 20));
    if (k === 'aware') return [5, 12, 22].map(d => Math.min(100, Math.round(cur + d)));
    if (k === 'rev') return [1.05, 1.12, 1.25].map(f => Math.round(Math.max(cur, K(10000)) * f / 1000) * 1000);
    const base = Math.abs(cur) + Math.max(K(10000), ((co.hist || []).slice(-1)[0] || {}).rev * 0.03 || 0);
    return cur < 0 ? [0, Math.round(base * 0.2 / 1000) * 1000, Math.round(base * 0.5 / 1000) * 1000] : [1.1, 1.25, 1.5].map(f => Math.round(Math.max(cur, K(5000)) * f / 1000) * 1000);
  }
  /* who answers to you for this company */
  function boss(co) {
    if (co.mgr && S.npcs[co.mgr]) return { k: 'mgr', n: S.npcs[co.mgr].name, q: mgrQual(co) };
    if (S.group && S.group.ceo && S.npcs[S.group.ceo.npc]) return { k: 'ceo', n: S.npcs[S.group.ceo.npc].name, q: 0.6 };
    if ((co.holders || []).length || (co.brd && co.brd.seats && co.brd.seats.length)) return { k: 'board', n: 'The board of ' + co.name, q: 0.4 };
    return { k: 'you', n: 'You', q: 0 };
  }
  R28.boss = boss;
  const goalOf = co => { const g = GL()[co.id]; return g && g.st === 'on' ? g : null; };
  R28.goalOf = goalOf;
  function setGoal(co, k, target, months, by, bonus, req) {
    GL()[co.id] = { k, t: target, from: M[k].now(co), w: S.week, endM: MI() + months, by, bonus: bonus || 0, req: req ? 1 : 0, st: 'on' };
  }
  /* each month: results, then a new target from whoever runs the place */
  function monthly() {
    live().forEach(co => {
      const g = GL()[co.id];
      if (g && g.st === 'on' && MI() >= g.endM) {
        const m = M[g.k], v = m.now(co), ok = v >= g.t;
        g.st = ok ? 'won' : 'lost';
        g.res = v;
        const b = boss(co);
        if (ok) {
          co.mood = Math.min(100, (co.mood || 60) + 6);
          co.rep = Math.min(100, (co.rep || 50) + 1);
          if (g.bonus > 0 && co.mgr) payCo(co, g.bonus, 'wages', 'Bonus: target reached');
          if (window.R28.press && g.req) R28.press(1.5, co.name + ' hits its target', '');
          if (window.R27 && R27.amb) { const a = R27.amb(); a.score += 2; }
          addMsg({ kind: 'info', from: b.k === 'you' ? co.name : b.n, title: 'Target reached at ' + co.name + ': ' + m.n(co).toLowerCase() + ' ' + m.f(v), body: (b.k === 'mgr' ? 'The team did it' + (g.bonus ? ', and the bonus is paid' : '') + '. Morale is up.' : 'Well done.') + ' The target was ' + m.f(g.t) + '.', co: co.id, tone: 'good', status: 'done' });
        } else {
          co.mood = Math.max(0, (co.mood || 60) - (g.req && g.hard ? 6 : 3));
          addMsg({ kind: 'info', from: b.k === 'you' ? co.name : b.n, title: 'Target missed at ' + co.name, body: m.n(co) + ' ended at ' + m.f(v) + ', short of ' + m.f(g.t) + '.' + (g.hard ? ' It was always a stretch.' : ''), co: co.id, tone: 'bad', status: 'done' });
        }
      }
      /* a fresh monthly target, proposed by the manager or the board */
      const b = boss(co);
      if (!goalOf(co) && (b.k === 'mgr' || b.k === 'board') && S.week - (co.w0 || 0) > 8) {
        const ks = Object.keys(M).filter(k => !M[k].ok || M[k].ok(co)).filter(k => k !== 'rating' || ratingOf(co) < 4.5).filter(k => k !== 'util' || M.util.now(co) < 0.88).filter(k => k !== 'aware' || (co.aware || 0) < 70);
        if (!ks.length) return;
        const k = ks[Math.floor(Math.random() * ks.length)], t = levels(co, k)[0];
        setGoal(co, k, t, 1, b.k, 0, 0);
        addMsg({ kind: 'info', from: b.n, title: 'This month at ' + co.name + ': ' + M[k].n(co).toLowerCase() + ' ' + M[k].f(t), body: (b.k === 'mgr' ? 'Our target for the month. ' : 'The board\'s target for the month. ') + 'Now: ' + M[k].f(M[k].now(co)) + '.', co: co.id, tone: 'n', status: 'done', go: { l: 'See ' + co.name, a: 'go', p: { n: 'co', p: { id: co.id, t: 'ov' } } } });
      }
    });
  }
  /* what a target makes them focus on, and what it costs */
  function focusWeek() {
    live().forEach(co => {
      const g = goalOf(co);
      if (!g || g.by === 'you' || g.by === 'board' && !co.mgr) return;
      const w = co.lastW ? co.lastW.rev || 0 : 0, push = 1 + (g.bonus > 0 ? 0.5 : 0);
      if (g.k === 'rating') payCo(co, w * 0.012 * push, 'oth', 'Extra care for quality');
      if (g.k === 'util' || g.k === 'rev' || g.k === 'aware') { payCo(co, w * 0.015 * push, 'mkt', 'Push for customers'); co.aware = Math.min(100, (co.aware || 0) + 0.35 * push); }
    });
  }
  const qt1 = window.qualityTarget;
  if (qt1) window.qualityTarget = function (co) {
    let v = qt1.apply(this, arguments);
    try { const g = goalOf(co); if (g && g.by !== 'you') { if (g.k === 'rating') v += g.bonus > 0 ? 5 : 3; if (g.k === 'profit') v -= 2; } } catch (e) { }
    return Math.max(0, Math.min(99, v));
  };
  const dm1 = window.demand;
  window.demand = function (co, bd) {
    const r = dm1.apply(this, arguments);
    try { const g = goalOf(co); if (g && g.by !== 'you' && (g.k === 'util' || g.k === 'rev') && r && r.D > 0) r.D *= g.bonus > 0 ? 1.06 : 1.04; } catch (e) { }
    return r;
  };
  /* profit targets: they cut corners on costs */
  R7.afterWeek = R7.afterWeek || [];
  R7.afterWeek.push(() => {
    try {
      focusWeek();
      live().forEach(co => { const g = goalOf(co); if (g && g.by !== 'you' && g.k === 'profit' && !co.mods.some(x => x.t28 === 'gl')) co.mods.push({ k: 'cogsup', m: g.bonus > 0 ? 0.95 : 0.97, w: 4, t28: 'gl' }); });
      S.m28c = S.m28c == null ? MI() : S.m28c;
      if (S.m28c !== MI()) { S.m28c = MI(); monthly(); }
      giveWeek();
    } catch (e) { console.error(e); }
  });

  /* ---------- the goal card, and asking for a target ---------- */
  const ov0 = CT.ov;
  CT.ov = function (co, bd) {
    const h = ov0.apply(this, arguments);
    try {
      if (!co || co.st !== 'open' || co.type === 'hold' || ['fin', 'energy', 'rent', 'club'].indexOf(BD[co.type].fam) >= 0) return h;
      const g = goalOf(co), b = boss(co);
      if (!g) return h + '<div class="card"><div class="bhead"><b>No target this month</b></div><span class="tipt">' + (b.k === 'you' ? 'You run it yourself. Set a target to keep yourself honest.' : 'Ask ' + esc(b.n) + ' for a target: a rating, how busy, sales, profit or awareness.') + '</span>' + btn('Set a target', 'gl28', { id: co.id }, 'chip wide') + '</div>';
      const m = M[g.k], v = m.now(co), f = g.t === g.from ? (v >= g.t ? 1 : 0) : Math.max(0, Math.min(1, (v - g.from) / (g.t - g.from)));
      return h + '<div class="card"><div class="bhead"><b>Target: ' + esc(m.n(co).toLowerCase()) + ' ' + m.f(g.t) + '</b>' + pillp(v >= g.t ? 'On track' : 'Now ' + m.f(v), v >= g.t ? 'grn' : 'amb') + '</div><div class="bar"><i style="width:' + Math.max(3, f * 100) + '%;background:var(--amber)"></i></div><span class="tipt">' + (g.by === 'you' ? 'Your own target' : 'Set ' + (g.req ? 'at your request' : 'by ' + esc(b.n)) ) + ' · until ' + monthStr(S.week + Math.max(1, (g.endM - MI())) * 4.35).split(' ')[0] + (g.bonus ? ' · bonus ' + mshort(g.bonus) : '') + '. ' + (g.by === 'you' ? '' : g.k === 'rating' ? 'They spend a little more on quality.' : g.k === 'profit' ? 'They cut costs, and quality may slip.' : 'They push for customers with extra marketing.') + '</span>' + (g.by === 'you' || g.req ? btn('Change the target', 'gl28', { id: co.id }, 'chip wide ghost') : '') + '</div>';
    } catch (e) { console.error(e); return h; }
  };
  ACT.gl28 = p => {
    const co = getCo(p.id);
    if (!co) return;
    const b = boss(co), F = ui.gl28f = ui.gl28f && ui.gl28f.id === co.id ? ui.gl28f : { id: co.id, k: 'rating', lv: 1, mo: 3, bo: 0 };
    const ks = Object.keys(M).filter(k => !M[k].ok || M[k].ok(co));
    if (ks.indexOf(F.k) < 0) F.k = ks[0];
    const L = levels(co, F.k), t = L[F.lv], d = diff(co, F.k, t, F.mo);
    const word = d <= 1 ? ['Realistic', 'grn'] : d <= 2 ? ['A stretch', 'amb'] : ['Very hard', 'red'];
    const wage = co.mgrWage || 0;
    let h = '<h2>A target for ' + esc(co.name) + '</h2><p class="muted small">' + (b.k === 'you' ? 'You run it yourself, so this is a promise to yourself.' : 'You ask ' + esc(b.n) + '. ' + (b.k === 'board' && !co.mgr ? 'The board holds you to it.' : 'They decide how to get there.')) + '</p>';
    h += '<div class="chips">' + ks.map(k => '<button class="btn chip' + (F.k === k ? ' primary' : '') + '" data-a="gl28s" data-p="' + P({ id: co.id, f: 'k', v: k }) + '">' + esc(M[k].n(co)) + '</button>').join('') + '</div>';
    h += row('Now', M[F.k].f(M[F.k].now(co)));
    h += '<div class="chips">' + L.map((x, i) => '<button class="btn chip' + (F.lv === i ? ' primary' : '') + '" data-a="gl28s" data-p="' + P({ id: co.id, f: 'lv', v: i }) + '">' + M[F.k].f(x) + '</button>').join('') + '</div>';
    h += '<div class="chips">' + [[1, '1 month'], [3, '3 months'], [6, '6 months']].map(x => '<button class="btn chip' + (F.mo === x[0] ? ' primary' : '') + '" data-a="gl28s" data-p="' + P({ id: co.id, f: 'mo', v: x[0] }) + '">' + x[1] + '</button>').join('') + '</div>';
    if (co.mgr) h += '<div class="chips">' + [[0, 'No bonus'], [1, 'Bonus ' + mshort(wage)], [2, 'Bonus ' + mshort(wage * 2)]].map(x => '<button class="btn chip' + (F.bo === x[0] ? ' primary' : '') + '" data-a="gl28s" data-p="' + P({ id: co.id, f: 'bo', v: x[0] }) + '">' + x[1] + '</button>').join('') + '</div>';
    h += '<div class="card"><div class="bhead"><b>' + esc(M[F.k].n(co)) + ' ' + M[F.k].f(t) + ' within ' + F.mo + (F.mo > 1 ? ' months' : ' month') + '</b>' + pillp(word[0], word[1]) + '</div><span class="tipt">' + (F.k === 'rating' ? 'More care for quality costs a little more each week.' : F.k === 'profit' ? 'Cutting costs to hit it can hurt quality.' : 'Getting there means spending on marketing.') + '</span></div>';
    h += btn(b.k === 'you' ? 'Set it' : 'Ask ' + esc(b.k === 'mgr' ? b.n.split(' ')[0] : b.n), 'gl28go', { id: co.id }, 'primary wide') + btn('Cancel', 'sheetclose', undefined, 'ghost wide');
    openSheet(h);
  };
  ACT.gl28s = p => { const F = ui.gl28f; if (!F) return; F[p.f] = p.v; if (p.f === 'k') F.lv = 1; ACT.gl28({ id: p.id }); };
  ACT.gl28go = p => {
    const co = getCo(p.id), F = ui.gl28f;
    if (!co || !F) return;
    const b = boss(co), t = levels(co, F.k)[F.lv], d = diff(co, F.k, t, F.mo), bonus = co.mgr ? (co.mgrWage || 0) * F.bo : 0;
    closeSheet();
    if (b.k === 'you') { setGoal(co, F.k, t, F.mo, 'you', 0, 1); save(); render(true); toast('Target set.'); return; }
    const capa = 1.1 + b.q * 1.2 + F.bo * 0.45;
    if (d <= capa) {
      setGoal(co, F.k, t, F.mo, b.k, bonus, 1);
      if (d > 2) GL()[co.id].hard = 1;
      co.mood = Math.min(100, (co.mood || 60) + (F.bo ? 3 : 0) - (d > 2 ? 3 : 0));
      addMsg({ kind: 'info', from: b.n, title: 'Target agreed for ' + co.name, body: (d <= 1 ? '"We can do that."' : d <= 2 ? '"It is a stretch, but we will go for it."' : '"Very hard. We will give it everything."') + ' ' + M[F.k].n(co) + ' ' + M[F.k].f(t) + ' within ' + F.mo + (F.mo > 1 ? ' months.' : ' month.'), co: co.id, tone: 'n', status: 'done' });
    } else {
      /* a counter-offer they believe in */
      const L = levels(co, F.k).concat([M[F.k].now(co)]);
      const ok = levels(co, F.k).filter(x => diff(co, F.k, x, F.mo) <= capa).pop();
      const c = ok != null ? ok : levels(co, F.k)[0];
      addMsg({ kind: 'ask', from: b.n, title: 'About the target for ' + co.name, body: '"' + M[F.k].f(t) + ' in ' + F.mo + (F.mo > 1 ? ' months' : ' month') + ' is not realistic. I can promise ' + M[F.k].f(c) + '."', co: co.id, opts: [{ l: 'Agree to ' + M[F.k].f(c), d: '', fx: {} }, { l: 'Insist on ' + M[F.k].f(t), d: 'Morale suffers if it fails, and it probably will.', fx: {} }, { l: 'Drop it', d: '', fx: {} }], act: 'gl28neg', data: { co: co.id, k: F.k, t, c, mo: F.mo, bonus, by: b.k }, exp: S.week + 2, tone: 'n' });
    }
    save();
    render(true);
  };
  ACTS.gl28neg = (m, idx) => {
    const co = getCo(m.data.co), d = m.data;
    if (!co) return true;
    if (idx === 0) setGoal(co, d.k, d.c, d.mo, d.by, d.bonus, 1);
    else if (idx === 1) { setGoal(co, d.k, d.t, d.mo, d.by, d.bonus, 1); GL()[co.id].hard = 1; co.mood = Math.max(0, (co.mood || 60) - 6); }
    return true;
  };
})();

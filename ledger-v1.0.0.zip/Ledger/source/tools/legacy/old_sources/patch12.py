path = '/home/claude/w3/ledger.html'
T = '/home/claude/w3/tools/'
t = open(path, encoding='utf8').read()
def rep(old, new, count=1):
    global t
    n = t.count(old)
    if n != count: raise SystemExit('MATCH %d (want %d): %s' % (n, count, old[:110]))
    t = t.replace(old, new)
js = open(T + 'round12.js', encoding='utf8').read() + '\n'
mark = '/* ---------- no zooming: pinch, double tap, ctrl+wheel, ctrl +/- ---------- */'
rep(mark, js + mark)
css = open(T + 'round12.css', encoding='utf8').read()
i = t.rindex('</style>')
t = t[:i] + css + t[i:]
open(path, 'w', encoding='utf8').write(t)
print('patch12 ok')

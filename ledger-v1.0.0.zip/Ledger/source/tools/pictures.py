# Make the game-size pictures (pictures/<folder>/<name>.webp next to ledger.html) from the full-size ones in
# src/assets/pictures. Run from the project folder:  python3 tools/pictures.py
# Every picture, cars too, is loaded from that folder; without it the game shows its drawings.
import os, glob
from PIL import Image
SRC, OUT = 'src/assets/pictures', 'pictures'
n = 0
for f in sorted(glob.glob(SRC + '/*/*.jpg')):
    cat, name = f.split('/')[-2], os.path.basename(f)[:-4]
    os.makedirs(OUT + '/' + cat, exist_ok=True)
    im = Image.open(f).convert('RGB')
    im.thumbnail((960, 960))
    im.save('%s/%s/%s.webp' % (OUT, cat, name), 'WEBP', quality=72, method=6)
    n += 1
print(n, 'pictures written to', OUT)

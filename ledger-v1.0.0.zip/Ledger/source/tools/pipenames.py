# Cleanup helper (round 53): name the screen pipelines of each screen in load order: X, X:2, X:3 ...
#   python3 tools/pipenames.py      (run from src/js)
# A screen can have several pipelines (pipeView) along its chain. Every step or route belongs to the latest pipeline of
# that screen installed before it in load order, so the names are rewritten from that rule (also for X.route and X.around).
import re
order = [l.strip()[3:] for l in open('../manifest.txt') if l.strip().startswith('js/')]
VIEWS = set(m.group(1).split(':')[0] for f in order for m in re.finditer(r"pipeView\('([^']+)'", open(f, encoding='utf8').read()))
cnt, cur, changed = {}, {}, 0
rx = re.compile(r"pipeView\('([^']+)'|addStep\('([^'.:]+(?:\.[^'.:]+)*?)(:\d+)?(\.route|\.around)?'")
for f in order:
    t = open(f, encoding='utf8').read()
    def sub(m):
        if m.group(1):
            X = m.group(1).split(':')[0]
            cnt[X] = cnt.get(X, 0) + 1
            cur[X] = X if cnt[X] == 1 else '%s:%d' % (X, cnt[X])
            return "pipeView('%s'" % cur[X]
        X = m.group(2)
        if X not in VIEWS or X not in cur: return m.group(0)
        return "addStep('%s%s'" % (cur[X], m.group(4) or '')
    n = rx.sub(sub, t)
    if n != t: open(f, 'w', encoding='utf8').write(n); changed += 1
print('files changed:', changed)

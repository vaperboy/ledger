#!/bin/sh
# Rebuild and check the game still behaves exactly like the reference run.
#   sh tools/same.sh REF_DIR      (REF_DIR made earlier with: node tools/golden.js $PWD/ledger.dev.html REF_DIR)
cd "$(dirname "$0")/.." || exit 1
node tools/build.js || exit 1
OUT=$(mktemp -d)
node tools/golden.js "$PWD/ledger.dev.html" "$OUT" >/dev/null || exit 1
ok=1
for f in state.json screens.txt summary.txt; do
  if cmp -s "$1/$f" "$OUT/$f"; then echo "same: $f"; else echo "DIFFERENT: $f"; ok=0; diff "$1/$f" "$OUT/$f" | head -c 1500; echo; fi
done
[ $ok = 1 ] && echo "SAME BEHAVIOUR" || { echo "BEHAVIOUR CHANGED (output in $OUT)"; exit 1; }

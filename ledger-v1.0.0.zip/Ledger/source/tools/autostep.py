# Cleanup helper (round 52): turn post-wrappers of engine functions into pipeline steps.
#   python3 tools/autostep.py [--dry]        (run from src/js)
# For each engine function F (function F(a, b) in js/engine), its wrappers are listed in load order. A wrapper is
# convertible when it only adds work after F:  const X = F; F = function (...) { const r = X.apply(this, arguments);
# try { BODY } catch (e) { ... } return r; };  The convertible wrappers that come before any other kind are turned
# into  addStep('F', 10/20/.., 'label', (a, b, r) => { BODY })  and F becomes  F(a, b) { return runSteps('F', FCore(a, b), a, b); }
import re, glob, sys
DRY = '--dry' in sys.argv
SKIP = set(a[7:] for a in sys.argv if a.startswith('--skip=') for a in a[7:].split(',') for a in ['--skip=' + a])
def match(t, j):
    d = 0; k = j
    while k < len(t):
        c = t[k]
        if c in '\'"`':
            q = c; k += 1
            while t[k] != q:
                if t[k] == '\\': k += 1
                k += 1
        elif t.startswith('//', k): k = t.index('\n', k)
        elif t.startswith('/*', k): k = t.index('*/', k) + 1
        elif c == '{': d += 1
        elif c == '}':
            d -= 1
            if d == 0: return k
        k += 1
    raise Exception('no match')
eng = {}
for f in glob.glob('engine/**/*.js', recursive=True):
    t = open(f, encoding='utf8').read()
    for m in re.finditer(r'^function (\w+)\(([^)]*)\)', t, re.M):
        eng[m.group(1)] = (f, [p.strip() for p in m.group(2).split(',') if p.strip()])
order = [l.strip()[3:] for l in open('../manifest.txt') if l.strip().startswith('js/')]
wr = {}
for f in order:
    t = open(f, encoding='utf8').read()
    for m in re.finditer(r'^(\s*)const (\w+) = (?:window\.)?(\w+);\n(\s*)(?:window\.)?\3 = function\s*\(([^)]*)\)\s*\{', t, re.M):
        F = m.group(3)
        if F not in eng: continue
        fb = m.end() - 1
        fe = match(t, fb)
        body = t[fb + 1:fe]
        mm = re.match(r'\s*const (\w+) = ' + m.group(2) + r'\.apply\(this, arguments\);\s*try\s*\{', body)
        ok = False; inner = None; res = None; quiet = False
        if mm:
            tb = fb + 1 + mm.end() - 1
            te = match(t, tb)
            rest = t[te + 1:fe]
            mc = re.match(r'\s*catch\s*\(e\)\s*\{\s*(console\.error\(e\);)?\s*\}\s*return ' + mm.group(1) + r';\s*$', rest)
            if mc:
                ok = True; inner = t[tb + 1:te]; res = mm.group(1); quiet = not mc.group(1)
        if not ok and '--value' in sys.argv:
            mv = re.match(r'\s*(?:const|let) (\w+) = ' + m.group(2) + r'(?:\.apply\(this, arguments\)|\(([^)]*)\));', body)
            if mv and (mv.group(2) is None or [x.strip() for x in mv.group(2).split(',') if x.strip()] == [p.strip() for p in m.group(5).split(',') if p.strip()]):
                rest = body[mv.end():]
                last = rest.rstrip().rstrip(';').strip().split('\n')[-1].strip()
                if re.match(r'(return\b|\}\s*catch)', last) or rest.rstrip().endswith('}') is False:
                    if re.search(r'\breturn\b[^;]*;\s*$', rest.strip()) or re.search(r'catch \(e\) \{ return \w+; \}\s*$', rest.strip()):
                        ok = True; inner = rest; res = mv.group(1); quiet = False
        wparams = [p.strip() for p in m.group(5).split(',') if p.strip()]
        # the step body may use the wrapper's own parameter names; they must match the engine's, or be a prefix
        ep = eng[F][1]
        if ok and any(i >= len(ep) or wparams[i] != ep[i] for i in range(len(wparams))): ok = False
        if ok and ('arguments' in inner or 'this' in re.sub(r'\bthis\.\w', '', inner) and re.search(r'\bthis\b', inner)): ok = False
        # comment just above, for the label
        pre = t[:m.start()].rstrip('\n').split('\n')[-1].strip()
        lab = re.sub(r'^/\*\s*|\s*\*/$', '', pre) if pre.startswith('/*') and pre.endswith('*/') else ''
        wr.setdefault(F, []).append(dict(file=f, start=m.start(), ok=ok, inner=inner, res=res, quiet=quiet, lab=lab, var=m.group(2)))
done = []
for F, L in wr.items():
    pref = []
    for w in L:
        if not w['ok']: break
        pref.append(w)
    if not pref or F in SKIP: continue
    ef, ep = eng[F]
    if any(p.startswith('...') or '=' in p for p in ep): continue
    done.append((F, len(pref), len(L)))
    if DRY: continue
    # engine side
    t = open(ef, encoding='utf8').read()
    sig = 'function ' + F + '(' + ', '.join(ep) + ')'
    assert t.count(sig) == 1, sig
    a = ', '.join(ep)
    t = t.replace(sig, "/* " + F + ": the core below, then the steps features add: pipeSteps('" + F + "') */\nfunction " + F + "(" + a + ") {\n  return runSteps('" + F + "', " + F + "Core(" + a + ")" + (', ' + a if a else '') + ");\n}\nfunction " + F + "Core(" + a + ")", 1)
    open(ef, 'w', encoding='utf8').write(t)
    # wrappers, last first so offsets stay valid within a file
    for i, w in sorted(enumerate(pref), key=lambda x: (x[1]['file'], -x[1]['start'])):
        f = w['file']; t = open(f, encoding='utf8').read()
        ms = list(re.finditer(r'const ' + w['var'] + r' = (?:window\.)?' + F + r';', t))
        assert len(ms) == 1, (f, w['var'], F, len(ms))
        s = ms[0].start()
        a0 = t.rindex('\n', 0, s) + 1
        ind = t[a0:s]
        fpos = t.index('function', s)
        fb = t.index('{', fpos); fe = match(t, fb)
        e = fe + 1
        while t[e] in ' ;': e += 1
        if t[e] == '\n': e += 1
        lab = (w['lab'] or (f.split('/')[-1][:-3] + ' ' + F)).replace("'", '’')
        args = ', '.join(ep + [w['res']])
        inner = w['inner']
        if '\n' not in inner.strip():
            step = ind + "addStep('%s', %d, '%s', (%s) => { %s }%s);\n" % (F, (i + 1) * 10, lab, args, inner.strip(), ', true' if w['quiet'] else '')
        else:
            lines = inner.strip('\n').split('\n')
            lines = [l[2:] if l.startswith('  ') else l for l in lines]
            step = ind + "addStep('%s', %d, '%s', (%s) => {\n%s\n%s}%s);\n" % (F, (i + 1) * 10, lab, args, '\n'.join(lines), ind, ', true' if w['quiet'] else '')
        t = t[:a0] + step + t[e:]
        open(f, 'w', encoding='utf8').write(t)
for d in done: print('pipeline %-16s %d of %d wrappers' % d)
left = [(F, sum(1 for w in L if not w['ok'])) for F, L in wr.items()]
print('not convertible:', ', '.join('%s(%d)' % x for x in left if x[1]))

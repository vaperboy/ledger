const puppeteer = require('/opt/npm-tools/node_modules/puppeteer-core');
const fs=require('fs');const [,, file, sf] = process.argv;
(async () => {
  const b = await puppeteer.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--no-sandbox', '--disable-gpu'], headless: 'new', protocolTimeout: 3600000 });
  const p = await b.newPage(); const errs=[]; p.on('pageerror', e => errs.push('PAGEERR ' + e.message)); p.on('console', m => { if (m.type()==='error') errs.push('CONSOLE '+m.text().slice(0,200)); });
  await p.goto('file://' + file, { waitUntil: 'domcontentloaded' }); await new Promise(r => setTimeout(r, 600));
  const r = await p.evaluate(fs.readFileSync(sf,'utf8')); console.log(typeof r==='string'?r:JSON.stringify(r,null,1)); if(errs.length) console.log(errs.slice(0,8).join('\n')); await b.close();
})();

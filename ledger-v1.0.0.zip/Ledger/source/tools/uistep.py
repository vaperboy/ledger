# Cleanup helper (round 53): turn screen-level wrappers (V.x, CT.x, window.x, U.x) into pipeline steps.
#   python3 tools/uistep.py [--dry]      (run from src/js)
# At the first wrapper of X it installs  X = pipeView('X', X, arity);  and each wrapper that only post-processes
# the result becomes  addStep('X', order, 'label', (args..., h) => { ...; return h; });
# A screen that already has a pipeline gets a new one named 'X:2', 'X:3' (steps always belong to the latest one above them).
# A wrapper that only checks first (and may return another screen) before  return X0.apply(this, arguments)  becomes a
# route: addStep('X.route', order, 'label', (args) => { checks }); routes are tried before the screen, outermost first.
# Each run of neighbouring convertible wrappers becomes its own pipeline, so the order of everything stays the same.
import re, glob, sys
DRY = '--dry' in sys.argv
def match(t, j):
    d = 0; k = j
    while k < len(t):
        c = t[k]
        if c in '\'"`':
            q = c; k += 1
            while t[k] != q:
                if t[k] == '\\': k += 1
                k += 1
        elif t.startswith('//', k): k = t.index('\n', k)
        elif t.startswith('/*', k): k = t.index('*/', k) + 1
        elif c == '/' and re.search(r'(?:[=(,:!&|?{};\n]|\breturn)\s*$', t[max(0, k - 12):k]):
            # a regex literal: skip to its end
            k += 1
            while t[k] != '/':
                if t[k] == '\\': k += 1
                elif t[k] == '[':
                    while t[k] != ']':
                        if t[k] == '\\': k += 1
                        k += 1
                k += 1
        elif c == '{': d += 1
        elif c == '}':
            d -= 1
            if d == 0: return k
        k += 1
    raise Exception('no match')
def code(t):
    out = []; k = 0
    while k < len(t):
        c = t[k]
        if c in '\'"`':
            q = c; k += 1
            while t[k] != q:
                if t[k] == '\\': k += 1
                k += 1
            out.append('""')
        elif t.startswith('//', k): k = t.index('\n', k) - 1
        elif t.startswith('/*', k): k = t.index('*/', k) + 1
        elif c == '/' and re.search(r'(?:[=(,:!&|?{};\n]|\breturn)\s*$', t[max(0, k - 12):k]):
            k += 1
            while t[k] != '/':
                if t[k] == '\\': k += 1
                elif t[k] == '[':
                    while t[k] != ']':
                        if t[k] == '\\': k += 1
                        k += 1
                k += 1
            out.append('/r/')
        else: out.append(c)
        k += 1
    return ''.join(out)
def top(s):
    # the statements at the top level only: every nested block becomes {}
    out = []; d = 0
    for c in s:
        if c == '{':
            if d == 0: out.append('{')
            d += 1
        elif c == '}':
            d -= 1
            if d == 0: out.append('}')
        elif d == 0: out.append(c)
    return ''.join(out)
def returns(s):
    # does every path through s end in a return? (s is code() text)
    tp = top(s).rstrip()
    if re.search(r'(^|[;{}\n])\s*return\b[^;]*;$', tp): return True
    m = re.search(r'try\s*\{\}\s*catch\s*\(e\)\s*\{\}$', tp)
    if m:
        # the try block and the catch block must both return
        blocks = []; d = 0; st = None; b = s.rstrip()
        i = len(b) - 1
        # find the last two top-level blocks
        while i >= 0 and len(blocks) < 2:
            if b[i] == '}':
                if d == 0: st = i
                d += 1
            elif b[i] == '{':
                d -= 1
                if d == 0: blocks.insert(0, b[i + 1:st])
            i -= 1
        return all(returns(x) for x in blocks)
    return False
NOROUTE = {'window.proposeBuy', 'window.bankrupt', 'window.rivalCall', 'window.fireEvent', 'window.sheet36', 'window.showPop'}
order = [l.strip()[3:] for l in open('../manifest.txt') if l.strip().startswith('js/')]
W = {}
RX = re.compile(r'^(\s*)const (\w+) = ((?:V|CT|window|U)\.\w+);\n\s*(?:if \(\2\) )?\3 = function\s*\(([^)]*)\)\s*\{', re.M)
for f in order:
    t = open(f, encoding='utf8').read()
    for m in RX.finditer(t):
        X, var = m.group(3), m.group(2)
        params = [p.strip() for p in m.group(4).split(',') if p.strip()]
        fb = m.end() - 1
        try: fe = match(t, fb)
        except Exception: W.setdefault(X, []).append(None); continue
        body = t[fb + 1:fe]
        ok = False; res = None; rest = None
        mm = re.match(r'\s*(?:const|let) (\w+) = (?:' + var + r' \? )?' + var + r'(?:\.apply\(this, arguments\)|\(' + re.escape(', '.join(params)) + r'\))(?: : undefined)?;', body)
        if mm:
            res = mm.group(1); rest = body[mm.end():]
            try: clean = code(rest)
            except Exception: clean = var
            ok = not re.search(r'\b' + var + r'\b', clean) and not re.search(r'\barguments\b', clean) and not re.search(r'\bthis\b', clean) \
                 and not re.search(r'\breturn\s*;', clean)
            # every path must return: a return at the top level, or try { ... return x; } catch (e) { ... return y; }
            if ok: ok = returns(clean)
        route = None
        if not ok and X not in NOROUTE:
            # a route: some checks that may return another screen, then  return X0.apply(this, arguments)  as the last line
            try: c = code(body)
            except Exception: c = ''
            fin = re.search(r'return ' + var + r'(?:\.apply\(this, arguments\)|\(' + re.escape(', '.join(params)) + r'\));$', top(c).rstrip())
            if fin and len(re.findall(r'\b' + var + r'\b', c)) == 1 and not re.search(r'\breturn\s*;', c) and not re.search(r'\bthis\b|\barguments\b', c[:c.rindex('return ' + var)]) \
                    and not any(re.search(r'(?<![.\w])' + q + r'\s*=[^=>]', c) for q in params):
                route = body[:body.rindex('return ' + var)]
                ok = 'route'
        W.setdefault(X, []).append(dict(f=f, var=var, X=X, params=params, res=res, rest=rest, ok=ok, route=route, ind=m.group(1),
                                        lab=(re.sub(r'^/\*\s*|\s*\*/$', '', t[:m.start()].rstrip('\n').split('\n')[-1].strip()) if t[:m.start()].rstrip('\n').split('\n')[-1].strip().startswith('/*') and t[:m.start()].rstrip('\n').split('\n')[-1].strip().endswith('*/') else '')))
done = []
# a screen can already have a pipeline from an earlier run (further up or down the chain): a new one gets its own name
ALL = ''.join(open(f, encoding='utf8').read() for f in order)
for X, L in W.items():
    # every run of convertible wrappers that sit next to each other in the chain becomes one pipeline (a segment);
    # the first segment of a screen is named X, later ones X:2, X:3 ...
    runs, cur = [], []
    for w in L + [None]:
        if w and w['ok'] == 'route' and any(x['ok'] is True for x in cur):
            runs.append(cur); cur = [w]           # a route outside a step starts a new segment
        elif w and w['ok']: cur.append(w)
        else:
            if cur: runs.append(cur)
            cur = []
    for pref in runs:
        if any(w['params'] != pref[0]['params'][:len(w['params'])] and pref[0]['params'] != w['params'][:len(pref[0]['params'])] for w in pref): continue
        params = max((w['params'] for w in pref), key=len)
        if not DRY: ALL = ''.join(open(f, encoding='utf8').read() for f in order)
        k = ALL.count("pipeView('%s'" % X) + ALL.count("pipeView('%s:" % X)
        name = X if not k else '%s:%d' % (X, k + 1)
        done.append((X, len(pref), len(L)))
        if DRY: ALL += "pipeView('%s'" % X; continue
        nr = sum(1 for w in pref if w['ok'] == 'route'); ns = 0
        for i, w in enumerate(pref):
            f = w['f']; t = open(f, encoding='utf8').read()
            ms = list(re.finditer(r'^(\s*)const ' + w['var'] + r' = ' + re.escape(X) + r';\n\s*(?:if \(' + w['var'] + r'\) )?' + re.escape(X) + r' = function\s*\(', t, re.M))
            assert len(ms) == 1, (f, X, len(ms))
            a0 = ms[0].start(); ind = ms[0].group(1)
            fb = t.index('{', ms[0].end()); fe = match(t, fb)
            e = fe + 1
            while e < len(t) and t[e] in ' ;': e += 1
            if e < len(t) and t[e] == '\n': e += 1
            lab = (w['lab'] or (f.split('/')[-1][:-3] + ' ' + X)).replace("'", '’')
            if w['ok'] == 'route':
                # routes are checked outermost first: the one loaded last wrapped the screen last
                lines = w['route'].strip('\n').split('\n')
                lines = [l[2:] if l.startswith('  ') else l for l in lines]
                step = ind + "addStep('%s.route', %d, '%s', (%s) => {\n%s\n%s});\n" % (name, (nr - i) * 10, lab, ', '.join(w['params']), '\n'.join(lines), ind)
            else:
                ns += 1
                args = ', '.join(params + [w['res']])
                lines = w['rest'].strip('\n').split('\n')
                lines = [l[2:] if l.startswith('  ') else l for l in lines]
                step = ind + "addStep('%s', %d, '%s', (%s) => {\n%s\n%s});\n" % (name, ns * 10, lab, args, '\n'.join(lines), ind)
            if i == 0: step = ind + "%s = pipeView('%s', %s, %d); /* %s: the screen above, then the steps below and in later files */\n" % (X, name, X, len(params), X) + step
            t = t[:a0] + step + t[e:]
            open(f, 'w', encoding='utf8').write(t)
for d in done: print('pipeline %-22s %d of %d' % d)
for X, L in W.items():
    for w in L:
        if w and not w['ok'] and '--why' in sys.argv: print('  first blocker', X, w['f'].split('/')[-1], (w['rest'] or '')[:0] if w['res'] else 'call is not the first statement'); break
        if not w: break
print('not converted:', ', '.join('%s(%d)' % (X, sum(1 for w in L if not w or not w['ok'])) for X, L in W.items() if any(not w or not w['ok'] for w in L)))

See STRUCTURE.txt (round 49) for how the code is organised now; the notes below describe earlier rounds.

Ledger test kit (round 28)

ledger.html       = current build
ledger_pre7.html  = base file the build starts from
Needs node + puppeteer-core + Chromium. Edit the chromium path at the top of shot.js, ev.js, crawl.js, audit.js, mgr_ab.js.

Rebuild:          sh tools/build.sh   (paths inside expect /home/claude/w3; edit the cd line)

UI and rule checks (each prints PASS/FAIL or "PROBLEMS: none"):
  node tools/shot.js $PWD/ledger.html out.png 390 844 "$(cat tools/seed2.txt)" "$(cat tools/routes.txt)"
  same for check13..check21 (with seed2); check12 then check12b need the chain globals:
    ... "$(cat tools/check12.txt)" "window.CH1=S.chains[0]; window.ST=S.cos.filter(c=>c.chain===CH1.id); 1" "$(cat tools/check12b.txt)"
  without seed: check22.txt (this round: manager card, hiring impact, bank/insurer capital, refunds, closed label, secured loans)
  systems:      sys1.txt (VAT, income and company tax, loans, bankruptcy), sys2.txt (franchise, investing, deposits,
                startups, bank, insurer, fund, power, oil and gas, rentals, parking, football club, dividends)

Deep crawl:       node tools/crawl.js $PWD/ledger.html tools/rich.js 2500 6

Simulation grids (write JSON; summarise with sum.js):
  node tools/audit.js $PWD/ledger.html tools/jobs_grid_A.json gA.json      (44 types x 9 strategies x 2 seeds, Norway)
  node tools/audit.js $PWD/ledger.html tools/jobs_grid_B.json gB.json
  node tools/sum.js gA.json gB.json
  jobs_country_A/B.json: 44 types in NO, SE, DE, US, PL, BR, LT, JP with marketing, PL and BR without
  strategies: base, mgr, mkt, mktx, p+10, p-10, p+30, disc, maint0/2, oh0/oh60, hire, fire; combine with &

Manager A/B (same business, owner-run vs manager, from a saved snapshot):
  node tools/mgr_ab.js $PWD/ledger.html cafe,hotel 26 52 11,29,47 [good|bad|debt|nomkt] > ab.json
  node tools/absum.js ab.json ; node tools/absum2.js ab.json
  DBG=1 adds weekly staff / demand / capacity / bottleneck to the output

Single scripts:   node tools/ev.js $PWD/ledger.html tools/fin_bank_ins.txt   (bank and insurer, 2 years)
                  node tools/ev.js $PWD/ledger.html tools/country_check.txt  (car dealer and handyman in BR, PL, NO)

Round 24 scripts (run with: node tools/ev.js $PWD/ledger.html tools/<file>):
  franchise_lifecycle.txt  franchisee and franchisor: fees, royalties, arrears, termination, renewal, buyout, bankruptcy
  club_purchase.txt        buying a club with debt, three seasons keeping / selling / buying players
  oil_years.txt            ten years of a producing stake at three oil prices, discoveries, exploration
  oil_discovery.txt        a developed discovery over fourteen years
  bank_years.txt           six-year bank runs: book types, wholesale funding, recession, bank runs
  bank_stress.txt          bank runs of 35% and 60% of deposits
  country_table.txt        wages, prices, rent, VAT, taxes, rates and setup cost in all 15 countries
  country_tax.txt          VAT and company tax checked in all 15 countries
  hiring_mechanics.txt     hiring forecast vs the game's own capacity, demand and payroll, every type and role
  assistant_manager.txt    assistant manager pay and work; manager hands-on hours by size
  hiretest.js + hsum.js    hire vs no hire over 14 weeks for every type and role (node tools/hiretest.js FILE TYPES SEEDS > h.json; node tools/hsum.js h.json)
  jobs_15countries_A/B.json  44 types x 15 countries (A: marketing, seed 11; B: no marketing, seed 29) for audit.js
  names_sample.txt         sample company names per trade in six countries
  names_check.txt          33,000 names: no construction or food word outside those trades

Round 26 scripts (node tools/ev.js $PWD/ledger.html tools/<file>):
  market_share.txt         market shares by sales, what you see with no analyst / HQ data analyst / market analyst,
                           hiring a market analyst, monthly reports, board pack and meeting lines, Market map,
                           reviews of you and your rivals, links between reviews, rivals and markets, old saves
  market_countries.txt     Market map, market details and reviews in all 15 countries; national bank, insurer and fund names

Round 27 scripts (node tools/ev.js $PWD/ledger.html tools/<file>):
  round27_test.txt         group trade (links, capacity, short supply, books), own-bank lending limit, ambitions (every
                           milestone to level V), shareholder demands and voting power, manager review, five-year run
                           with events, screens after five years
  rival_groups.txt         three years with rival groups: moves, bids, poaching, rankings for every filter and sort
  strategy_ab.txt          same companies with no links / market-price links / at-cost links / no rival moves / high dividends
  click27 (UI)             node tools/shot.js $PWD/ledger.html out.png 390 844 "$(cat tools/seed27.txt)" "$(cat tools/click27.txt)"
                           clicks every button on the new screens and their sheets

Round 28 scripts:
  round28_test.txt   (node tools/ev.js $PWD/ledger.html tools/round28_test.txt) firsts and celebrations, trophy wall,
                     storefront stages, the day card, staff anniversaries / promotion / retirement and their stories,
                     the nemesis, the paper (front page, interview, quote, Top 50), giving back (standing, legacy, yearly
                     renewal), goals (proposed monthly, asked for, counter-offer, judged at the deadline, owner-run)
  click28 (UI)       node tools/shot.js $PWD/ledger.html out.png 390 844 "$(cat tools/seed28.txt)" "$(cat tools/click28.txt)"

Round 29 (payday):
  round29.js / round29.css, applied by patch16.py (build.sh runs it after patch15).
  seed29.txt  three companies, a manager at the bistro, 150 days played with every payroll reminder approved;
              defines window.auto29(days, [company ids that never approve]) for tests.
  What to check: paydays on the 25th (a weekend payday moves to the Friday before), rent and supplier bills on the
  last day of the month, the 7-day reminder, an unapproved payroll going late (messages on day 0 and day 3, people
  leaving from day 3, reputation at day 7, wage claim at day 14), a cash-short payroll with automatic back pay,
  the owner's AS salary paid only after staff are paid in full, and Home / company Payroll and bills screens.
  Played week by week (audit.js grids) nothing changes: R29 only acts once the game has been stepped by days.

Rounds 30-32 (patch17.py, patch18.py, patch19.py; build.sh runs them after patch16):
  round30  Clients choices as collapsed menus, inflation inside the price box, complaint alerts open the complaint,
           Find a manager / Find workers swapped, calmer overview, one-time problem popups instead of the
           "needs you" bar, day card only for special moments, recurring costs billed monthly in day mode,
           Monthly results screen, event agency referrals / repeat clients / whole bookings, marketing fixes.
  round31  Milestone clippings and context, rival profiles with memory, public image, people you know
           (by role, web, favours and promises), maps (ownership, presence, influence), local paper names,
           week-in-numbers count-up with tap-to-see sums.
  round32  Wide layout: side menu from 760 px, two-column Home and list-beside-details Companies from 1000 px.
  seed30.txt      five companies incl. an event agency and a consultant, 60 days played; defines window.auto29
  click30.js      every company tab and the new views (python/puppeteer: evaluate after seed30)
  click31.js      every round 31 screen and action after 120 more days
  mk_matrix30.js  expected customers per week and cost per customer, 10 channels x 11 business types (after seed29)
  mk_live30.js    three live 13-week campaigns: spend vs budget, customers per week, still buying (after seed29)
  Marketing sources: WordStream 2024 Google Ads benchmarks (CPC $4.66, CVR 6.96%); JICMAIL 2024 response
  rate tracker (door drops 0.6%, cold mail 0.9%); Lebesgue 2024 Facebook CPM $12.15. Everything else in
  the channel tables is a game estimate.

Round 33 (patch20.py) and the size step:
  round33  every trade sells its own way: 45 business types get three of nine sales mechanics (contracts,
           tenders, one-off orders, referrals, apps/booking sites with commission, memberships, a season of
           their own, on-call service, add-ons). Shown as "Ways to sell" under How you sell on the Clients tab.
  shrink.js  build.sh now removes whitespace and comments from scripts and styles (names and logic untouched).
           The file was 2.14 MB, over the 2 MB some phone viewers accept; it is now about 1.66 MB, and the build
           (no size limit since round 56).
  click33.js      every trade's Clients tab plus a 26-week live run (after seed30 or seed29)
  iphone_load.py  loads the build as an iPhone, fresh and with a save from an older build:
                  python3 tools/iphone_load.py OLD.html NEW.html tools/seed29.txt out.png

Round 34 (patch21.py): hours are hours.
  Trades that sell time get output from real hours: a full-time worker = 37.5 h x the trade's productive share
  (consulting 70%, accounting 75%, cleaning 90%...); the owner's hours count one for one; one set of equipment serves
  one person up to 60 h. Each working day gets its own share of the week's capacity (no whole week sold on Monday).
  Staff work at least 7.5 h on every working day (37.5 h a week). "Fully booked" appears at most every two weeks per
  company. hours34.js: fresh game, 60-hour consultant, cleaning firm with staff, café (no seed needed).

Round 35 (patch22.py, inserted before the round 32 code so the wide split still wraps it): menus where you look.
  Company tabs: Overview · Sales · Staff · Money · Company (clubs: Overview · Squad · Money · Company).
    Sales = prices and rivals, Ways to sell, Marketing, How you sell, agreements, complaints (old t:'mk' scrolls to Marketing).
    Staff ends with Payroll and payday (payroll29 {v:'pay'}). Money: Pay yourself, Monthly results, Accounts, Monthly
    bills (payroll29 {v:'bills'}), Loans, Transactions, Ownership and value, Accountant and legal form.
    Company: suppliers, premises, competitors, expand, chain and reach, supply chain, board; then Paperwork and closing.
    Overview lost its "More" link list. Ownership and value now holds Market share and Owners and dividends.
    Sub-page back arrows return to the tab the page belongs to. Old routes (t: fin/ops/deal/mk/mon...) map via R35.tabOf.
  Bottom bar: Office -> Group (You · Group · Deals · Office; old hq tabs group/managers/suppliers/dealroom still work),
    Meetings -> Inbox (Waiting · Messages · Email · Meetings, Big meeting on top of Meetings).
    Phone: Bank, Investing, News, Reviews, Stats, Tax office, Luxury, Settings. Companies: + New company and Registry.
  Renames: Results and balance -> Accounts, Value and ownership -> Ownership and value, Brand reach -> Chain and reach,
    Recent transactions -> Transactions.
  Week report: one screen, no scrolling (net worth, cash/revenue/profit/shares tiles, Companies box, What happened box,
    Continue). Tiles open the calculation, boxes open the full lists. Numbers count up once per report, not on each tap.
    The round 31 count-up pop-up the day after is gone; problem pop-ups wait until the day has finished and the report
    is closed. Sales choice boxes (Positioning etc.) are cut by nesting depth and keep their rows inside the box.
  round28_test: the trophy link check now looks in Group > You.
  click35.js  every tab, sub-page, row on Money/Company/Staff/Overview, Group sub-tabs and old hq routes, phone apps,
              Inbox tabs, week report and its sheets (after seed30 or seed29; prints "checked N ... bad 0 errors 0").

Round 36 (patch23.py, before the round 32 code; also edits round27a/28b/29/30/31/35 sources):
  Rankings: every rival you face (rivalsOf, not owned by a group) is ranked by name and clickable; the rest of each
    country is an estimated crowd per trade (R27.crowd: sizes only, names made up when shown). ranked() returns the
    named entries, the top 50 and the firms around you; L.total is the full count. A new café ranks ~670 of 700 in
    its trade, ~10 800 of 12 000 in Norway. Growth ranks only companies with public growth figures.
  Pop-ups: tapping outside or Esc no longer closes them; a sheet without its own closing button gets a × (sheet36).
  Unlocks: Manager reviews + Inbox Meetings (first manager), Boards (first real board or board emergency) announce
    themselves once (S.unl36, checked every 1.5 s when no pop-up is open): Take a look / Not now. Old saves start
    with what they already have, silently.
  Money: Pay yourself · Results (res36: Months · Accounts · Transactions · Bills) · Loans · Ownership and value ·
    Accountant and legal form. Company: Suppliers (supply chain inside) · Premises and equipment · Expand (reach on
    top, chain, franchise, abroad, holding) · Board (only when it exists) · Documents · Insurance · Close down.
    Sales gets a Competitors row under the price box; Staff gets Courses (the Academy, preset to that company).
  Group: You (public image card, people, trophies, giving back, ambition) · Group (Maps, Market, Group suppliers,
    Manager reviews*, Boards*, Crisis centre*, then Structure) · Office. Deal room and its tab are gone: selling sits
    in each company, holding companies in Expand, service firms and startups under New company.
  Market (mkt36) = market map with the rivals screen in place of its competitor list.
  New company: "Other ways to start": Join a franchise, Start a startup (found36), Your own service firm (svc36).
  Phone: Bank (Accounts · Loans · Credit · Tax), Investing (Stocks · Crypto · Funds · Startups), News (one page),
    Reviews, Stats, Luxury, Settings (+ Reports and timing). Registry removed from the menus.
  Inbox: Waiting (+ Big meeting row while an offer is open) · Messages (email listed under it) · Meetings (managers).
  click35.js now also covers Results, Market, startups, service firms, bank tax, investing startups and rankings.
  round28_test: news check now expects one page.

Round 37 (patch24.py before the round 32 code; also edits round27a/28a/28b/30/31/36 sources):
  Chains: no "Open a new store" / "More sites" / "Open another site" on chain and Expand screens; New company lists
    "A new store in your chain" (store13 flow). Expand keeps chain registration, franchise, abroad, holding.
  Newcomers: R27.noticed(co) = open 26+ weeks with 12%+ of its market, or 22%+, or a price war. Groups only target
    noticed companies (targets, undercut); the nemesis needs a noticed company or 3 open companies. Rivals (R31) know
    you only from that point or once you cross them (price war, a month under their prices, lunch, buy talk);
    unknown rivals show "Has not noticed you" / "Never met", stay out of People you know, and the public image shows
    "Do not know you yet". Old saves: the automatic "You opened ..." memory is removed once.
  People you know: own scale (40 = Acquaintance): Strained <22, Cool <36, Acquaintance <50, Friendly <64, Close <78, Trusted.
  Pop-ups and inbox cards show the whole title.
  Home trades (consultant, tutor, car cleaning, photo, handyman): Premises tab offers an office (listings sized for
    the team, ~9 m² a head), rent or buy, move back home. 4+ people at home: morale -1 (-2 at 6+) and quality slip
    weekly, and an "Outgrown the home office" alert that opens the Premises tab.
  Overview picture follows the premises: house (+ vans), vehicles only, office block (floors by team, lit windows by
    load), hall with roller doors, sales yard, tall building, or the storefront for walk-in trades. Label = premises
    and size. An open company with no sales shows its name, not "Closed".
  One line: chips() drops ".00" from money and turns into a list when the row would not fit; rows of choices that
    still wrap become 4-wide percent tiles (25%..100%), an even grid, or a column (R37.fitChips, after each render).
    Row subtitles, label/value rows, card headers and buttons cut with … in the main screen (pop-ups keep full text).
    The decision limit is a small box: "Deals that come to you · above 5 M" with 1 M / 5 M / 20 M / 100 M.
  layout37.js: crawls every screen and pop-up and reports rows of choices that wrap, buttons on two lines, label
    text on two lines, tabs that overflow and anything wider than the phone (after seed30).

Round 38 (patch25.py; also edits round12/35/37 sources):
  Short amounts carry the currency sign: kr and zł after the number, $, €, £, ¥, ₩, C$, A$, R$ in front
    (country files' symbol fields changed). No empty decimals ("1 M kr", "4.5 M kr"). Quick-amount chips use
    niceAmt, so presets are round in every currency (€500 / €2 000 / €5 000 / €20 k). The decision-limit box uses mshort.
  Emergencies: a company without a real board (single store, no co-owners) never gets a board meeting. If you run it
    yourself nothing is sent (the problem alerts already show it); if a manager runs it, the manager asks you in a
    normal message (act emg37). Boards only unlock when a board is active.

Round 39 (patch26.py, appended with the other late rounds; also edits round10/31/37 sources):
  Campaign sheet: budget and length choices in rows of three with the custom amount inline; fits one screen.
    Rows of short choices that do not fit become an even grid (one row, or rows of three) instead of a column.
  Owner hours: a company of up to three people covers its support jobs itself (designer, sales, receptionist,
    paralegal...) with 10% less efficiency per empty support job (at most 35% less), instead of an empty job capping
    output. A marketing agency owner on 50 h now bills about 27 h a week (was 7); law 27, accounting 33, web 29.
  Next day takes 650 ms (was 280), Until needed ticks every 150 ms (was 70).
  Equipment, Needed tab: one card per missing item with a recommended model (Standard class by default, best rating
    for the price) and Buy N / Compare; a "When buying" Basic/Standard/Premium choice per company; optional upgrades
    as a short list. Managers buy missing kit at once (also right after a hire) and service or replace worn-out kit
    (past its life and under 35% condition) within the purchase limit: Full control = no limit, Within limits = the
    larger of the manager's, the regional manager's or the CEO's limit, Ask me first = always ask. Above the limit
    they ask in a message (act eq39ask, at most once per item every 4 weeks).
  Business customers: you set each one's discount (0/5/10/15/20/30/40%); it comes off every order, raises their
    orders by up to a third and warms the relationship; full price for long cools it slightly. Old saves start from
    the discount the old automatic terms gave. Tap a customer for what they do, what they bought and paid you, and
    the discount. Customers with a trade your companies buy from (cleaning, IT, marketing, temps, freight...) and a
    familiar-or-closer relationship can supply that input in Supply chain (S.l39): 2% + relationship discount below
    outside prices. Venues (café, restaurant) now show their business customers in Sales too.
  Favours: a contact does not ask again within half a year or while a favour is open; the global gap is 8 weeks.
    Bankers, lawyers and suppliers pay back at once (loans half a point cheaper for six months, shown in the Bank;
    next fine halved; better prices) and say so; the others are owed and can be called in.

Round 40 (patch27.py; also edits round10/29/31/36/37 sources, seed29/seed30/hours34/round28_test):
  Salary talks (fixed pay): each candidate has a private floor (R40.floorOf: ~83% of the ask at 22 or younger, ~87%
    under 28, ~91% mid-career, ~94% from 45; driven/arrogant +4 points, loyal/steady -2). An offer at or above the
    floor gets a counter halfway and patience is kept; just under it gets a counter at the floor; far below costs
    patience. Within 3% of their number, or a second fair offer to a lenient person (24 or younger, loyal, steady),
    is accepted. Commission plans keep the old rules. Pop-ups now sit above the chat (scrim z-index 60).
  Payroll: one "Approve payroll for N companies" prompt (act pay29all) seven days before payday instead of one per
    company. Test seeds approve it like before.
  Until needed: ticks every 320 ms and also stops for a new problem pop-up, a celebration or any open pop-up
    (window.untlStop).
  Prompts: answering closes the card and, when something changed, a "You chose ..." card lists it in words (cash,
    who knows you, reputation, staff mood, how people see you, loan terms) plus the notes it caused. No option is
    highlighted any more. Interviews raise how well known all your companies are; journalists and investors who
    owe you pay back at once.
  News: all headlines first, the local paper as a card that opens it (V.paper40), the economy below.

Round 41 (patch28.py; also edits round17/28a/36/37 sources and the built pop-up fitting and daily cash release):
  Trades in hours (plumber, electrician, construction, engcons; R41.HT): a job has hours (small / medium / big per
    trade, e.g. plumber 4-10, 10-18, 30-45 h = bathroom renovation) and a fixed price (hours x local hourly value).
    The Focus choice sets the size mix; a small firm gets fewer very big requests (classes above 3x its weekly hours
    are rarer). Hours a week = capacity x ticket / hourly value (solo plumber on 50 h about 38 h; + helper 48 h).
    Requests arrive day by day; a job is taken on while you are booked under three weeks ahead (and it is not more
    than 12 weeks of your hours), otherwise turned away. Hours go to the oldest job first. Short jobs are paid when
    finished; big or long jobs (over two weeks of your hours) pay 30% at the start, 40% halfway, 30% at the end.
    Big jobs are announced when they start and finish. lastW.units = whole jobs finished; D and cap are in jobs of
    the current mix, so "turning away" and hire advice compare like with like. Old jobs are converted to hours.
  Overview: "This week so far" for trades (requests, turned away, hours worked of the week's hours, jobs finished,
    paid, last week in one line) and "Jobs on the go" (booked ahead in days, still to be paid, jobs in progress with
    hours done, jobs waiting). Other companies: sold so far, "So far you use N% of your capacity" (weekday shape),
    "Customers asking" in words. All: average review (real), reputation, how well known with a trend arrow, unpaid
    invoices. The cash pill says what moved "so far this week". The event agency's order book uses plain words.
  Reviews: written on the day customers are served (finished jobs for trades); the stars are stored (co.rv41, rvS)
    and the average shown is their average. rvWeek only adds reviews for weeks played without days. The day card
    shows real 5-star and unhappy reviews; the random ones are gone.
  Word of mouth: awareness is pulled up toward a level set by the work done in the last 26 weeks (hours for trades,
    units against capD for others), a little more for good quality, a little less for poor.
  Week report tiles: Your cash, Company cash (what really moved), Sales, Result, with a line that explains why they
    differ; it opens Company cash (per company, wages and bills built up and when they are paid).
  Daily cash: the week's one-off payments (loan instalments, VAT settlement, legal bills) and any negative week
    leave on one day; only positive weeks are released a little each day.
  Pop-ups: forms and long lists scroll instead of being split into pages; anything still too tall scrolls. Found a
    startup is compact (two dropdowns side by side, six small tiles). Card descriptions (insurance cover, warnings)
    wrap instead of being cut. Insurance premiums show per month.
  New company: "Join or build" (franchise, startup) at the top; the service firm row is gone.
  round41_test.txt (node tools/ev.js $PWD/ledger.html tools/round41_test.txt): trades, focus, helper hours, daily
    play, overview text, real reviews, word of mouth, daily cash, week report, insurance, new company, pop-up scroll.
  sheets41.js: opens every reachable pop-up and lists the ones taller than the screen (python wrapper in any
    playwright runner: evaluate "()=>{" + file + "}" after a seed; try 375 x 667).

Round 42 (no new patch file: round41.js/patch28.py extended; also edits round10/round30 sources):
  Checked every business type, set up as the game sets it up, for half a year staffed and (small trades) alone on 50 h
    (audit42.txt: node tools/ev.js $PWD/ledger.html tools/audit42.txt; set window.__only='a,b' first to limit types).
  Event agency now uses the hours model (R41.HT.event, ev:1): a booking has a date (1-4 weeks ahead for small,
    3-8 medium, 6-14 big), preparation hours (12-30 / 40-90 / 150-300) and a 30% deposit when booked; preparation goes
    to the nearest date first; a booking is turned away when the team cannot prepare it and everything before it in
    time; the event happens on its day, ready or not (under 90% prepared: unhappy client, reputation down, no
    recommendations). Booking and delivery messages, recommendations and repeat clients come from round 30 (R30.ev).
    Overview card "Bookings": next date, still to be paid, each event's date and preparation. The old Bookings card
    and the order book are no longer shown for it. Old saves: event jobs get a date from their old due week.
  Engineering office: smaller commissions (12-40 / 60-160 / 400-1000 h, Buildings focus mostly small), so a new
    office gets steady work instead of one job every few months.
  Salmon farm: the start-up estimate includes feed and running costs until the first harvest (about 15 months).
  Wording (window.UNITW in round10.js, used by every "sold" label): Hours billed, Cars cleaned, Shoots done, Jobs done,
    Treatments given, Diners served, Customers served (shops), Paying members, Flats let, Square metres let, Policies in
    force, Customers, Clients, Events delivered, Parcels delivered, ... MWh stays MWh, m²-weeks. Rentals show "Let out"
    instead of capacity; banks, insurers, funds and energy show no capacity bar. Events say "Events delivered".
  round42_test.txt: every type 16 weeks (no errors, whole counts, cash matches books, overview text, own wording),
    event agency rules, engineering office work, salmon estimate.

Round 43 (round41.js/css, round41_test.txt):
  Week report fits above the bottom bar on short phones: the Companies and What happened boxes shrink first (min 54 px),
    the explanation is one line ("Why company cash and result differ ›", opens the Company cash sheet), tighter tiles
    under 720 px height. round41_test checks Continue is above the bottom bar.
  Negative cash: shown as a pill, but only pops up when it matters: deeper than half the overdraft limit, or in the red
    for 7+ days with no invoices due within two weeks to cover it. Low cash never pops up. The pop-up says how deep,
    the overdraft limit, invoices coming in, wages building up (and payday) and bills at month end, with three plain
    choices: Put in X from your cash (rounded up), See payroll and bills, Leave it on the overdraft for now. Leaving
    it holds for four weeks unless it gets clearly worse (50% deeper or a quarter of the overdraft limit more).

Round 44 (patch28.py extended; round17/28a sources): late-game test late43.txt (holding, shares sold, HQ staff, rival
  bought, listing, football club, three years day by day). A holding pays its own costs with dividends from its
  companies; if a holding fails, its companies return to you. Proofread: (fictional) labels, real brand names,
  "Building-supplie" style names (fbNoun map), stale menu paths, prompt-echo explanations shortened.
  text43.js collects every visible text string (crawler) for proofreading.

Round 45 (patch29.py: round45.js/css; also edits round10/28a sources): prompts and milestones wait until the week
  report is closed; a new manager starts "Within limits"; routine news from managed companies is filed as read and
  only money alerts pop up for them; managers re-apply for missing or lapsed documents (VAT, permits) every week;
  with a manager the Staff tab keeps the manager card (pay, authority) and a "You" hours card above the lock;
  Until needed stops only for decisions, serious bad news or new problems, and says why if nothing opens;
  "1 thing happened". Design: tabular numbers, press feedback, active-tab marker; motion only when a screen,
  pop-up or toast first appears (slide in forward/back, fade between tabs, sheets rise, bars fill), off with
  reduced motion. round45_test.txt.

Round 46 (round45.js section 7, round37.js, patch29.py): home starts. Plumber, electrician, construction, marketing,
  web, accounting, law, cleaning, estate agent, engineering consultancy, events, driving school and staffing start
  from home (BD.prem45 keeps the old place; prem ['home',0]). Consultant, tutor, car cleaning, photo and handyman
  already did. Places with customers in the door (shops, venues, clinics, salons, workshops that build things,
  logistics) still need premises. New company estimate when starting solo: one set of required kit, required
  vehicles only, no hires, a quarter of the buffer; "Premises: From home, free". ENK needs no share capital.
  A place of your own (Premises tab: workshop, office...) costs rent but gives: shorter trips for mobile trades
  (+8% working capacity), +6% business demand for B2B-heavy types, and people walking past (awareness +0.15 x
  location a week). From home only word of mouth spreads, stronger when the price is low and the work good.
  A manager rents a place when the team reaches four people. home45_test.txt.

Round 47 (patch30.py: round47.js/css; also edits round37/45 sources): nobody else works from your home. A company
  at home cannot hire workers or a manager ('noplace'); Find workers / Find a manager show "First, a place to work"
  with Find a workshop/office. A manager, or automatic setup, rents a small place (listing 1, "Small neighbourhood
  unit") before the first hire and tells you. Share capital is company cash: setupEstimate no longer adds it to the
  total (two places: base and round22), "Registration fee" row, the money card shows "Share capital, already company
  cash" and the suggested amount is the rest; checked in all 15 countries (round47_test). Swipe left/right on a
  screen with tabs (.ptabs) changes tab; a swipe from the left edge (28 px) goes back (also in phone apps).
  Phone apps open with a short loading screen (own colour, icon, line, progress bar; tap to skip; not inside an
  app). Luxury is the Aurum web shop: address bar with its own link per page (aurum.no/cars/brandt-912-gt-coupe,
  local domain per country), collections, product pages, Purchase, your collection. LUX data exported as
  window.LUX47. Cars: 15 photographed cars (tools/cars47/*.webp, 520 px WebP, embedded as window.CARIMG47 by patch30;
  ids c1-c5 kept for old saves). shrink.js now also minifies local names and syntax to stay under 1.9 MB.
  Tab swipe is a carousel: at the first sideways move the neighbour tab renders, a still copy of the old tab
  (.sw47g) and the new content follow the finger, release finishes or springs back; no top-down tab motion while
  swiping (R47.swiping). The tab marker is a sliding pill (.sw47pill) that follows the finger, and slides on taps.
  Back = the last visible back button on the screen (header, sub-page, conversation, interview); tab rows are
  .ptabs or .subtabs (Bank, Investing, Startups). Touch listeners sit on the touched element because it is replaced mid-swipe.
  Tests: round47_test.txt (ev.js), swipe47.js (node tools/swipe47.js $PWD/ledger.html, touch phone).

Round 48 (patch31.py: round48.js): money milestones (First million, 10 million, 100 million, billionaire) are round
  amounts in the home currency (JPY counts in hundreds of millions, KRW in billions) instead of NOK scaled by price
  level. Growth rankings include every firm in the business register (crowd firms get a quarterly growth figure),
  in all three filters. Part-time staff: Find workers has Hours (Full time / Part time 20 h); s.pt = 0.5, s.wage is
  the real (halved) pay, staffFTE counts pt, and market-pay comparisons use wageFor × pt (7 sites). The burnout
  event's "Hire part-time help" opens Find workers set to part time. Home-run companies (no place) get demand
  × 0.72-0.95 rising with awareness, so a home start builds its clients slowly (solo marketing/web year one sales
  about 430-450k NOK instead of 750-870k). Quick check: tools/round48_check.txt (ev.js).

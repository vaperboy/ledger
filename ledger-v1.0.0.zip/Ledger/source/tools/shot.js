const puppeteer = require('/opt/npm-tools/node_modules/puppeteer-core');
const [,, file, out, w='390', h='844', ...steps] = process.argv;
(async () => {
  const b = await puppeteer.launch({executablePath:'/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args:['--no-sandbox','--disable-gpu'], headless:'new'});
  const p = await b.newPage();
  await p.setViewport({width:+w, height:+h, deviceScaleFactor:2});
  const errs=[]; p.on('pageerror',e=>errs.push('PAGEERR '+e.message)); p.on('console',m=>{ if(m.type()==='error' && !/Failed to load resource/.test(m.text())) errs.push('CONSOLE '+m.text()); });
  await p.goto('file://'+file, {waitUntil:'domcontentloaded'});
  await new Promise(r=>setTimeout(r,500));
  for (const s of steps) { try { const r = await p.evaluate(s); if (r!==undefined && r!==null) console.log('=>', String(typeof r==='string'?r:JSON.stringify(r)).slice(0,20000)); } catch(e){ errs.push('STEP '+s.slice(0,50)+': '+e.message);} await new Promise(r=>setTimeout(r,150)); }
  await p.screenshot({path:out});
  if (errs.length) console.log(errs.slice(0,10).join('\n'));
  await b.close();
})();

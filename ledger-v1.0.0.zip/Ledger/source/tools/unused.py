# Cleanup helper (round 53): list (or remove) helpers that nothing uses any more.
#   python3 tools/unused.py [--remove] FILE...      (run from src/js)
# A helper is  function name(...) {...}  or  const name = ... ;  at the top level of a file's closure (two spaces in)
# whose name appears nowhere else in the whole game. Removing repeats until nothing more falls away.
import re, sys
exec(open(__file__.replace('unused.py', 'uistep.py'), encoding='utf8').read().split('def code(')[0].split('NOROUTE')[0])
REMOVE = '--remove' in sys.argv
files = [a for a in sys.argv[1:] if not a.startswith('--')]
order = [l.strip()[3:] for l in open('../manifest.txt') if l.strip().startswith('js/')]
def endstmt(t, k):
    d = 0
    while k < len(t):
        c = t[k]
        if c in '\'"`':
            q = c; k += 1
            while t[k] != q:
                if t[k] == '\\': k += 1
                k += 1
        elif t.startswith('//', k): k = t.index('\n', k) - 1
        elif t.startswith('/*', k): k = t.index('*/', k) + 1
        elif c in '([{': d += 1
        elif c in ')]}': d -= 1
        elif c == ';' and d == 0: return k + 1
        k += 1
    return k
total = 0
while True:
    ALL = ''.join(open(f, encoding='utf8').read() for f in order)
    found = []
    for f in files:
        t = open(f, encoding='utf8').read()
        for m in re.finditer(r'^  (?:function (\w+)\s*\(|const (\w+) = )', t, re.M):
            name = m.group(1) or m.group(2)
            if len(re.findall(r'(?<![\w$.])' + name + r'\b', ALL)) + len(re.findall(r'\.' + name + r'\b(?!\s*[(:])', ALL)) * 0 > 1: continue
            if re.search(r"['\"]" + name + r"['\"]", ALL): continue
            a = m.start()
            if m.group(1): z = match(t, t.index('{', m.end())) + 1
            else:
                # one declaration only (no  const a = 1, b = 2)
                z = endstmt(t, m.end())
                if re.search(r',\s*\w+\s*=', t[m.end():z]) and not re.search(r'=>|\(', t[m.end():m.end() + 3]): continue
            while z < len(t) and t[z] in ' ;': z += 1
            if z < len(t) and t[z] == '\n': z += 1
            pa = t.rindex('\n', 0, a - 1) + 1 if a > 0 else 0
            if re.match(r'\s*/\*.*\*/\s*$', t[pa:a]): a = pa
            found.append((f, a, z, name))
    if not found: break
    print('\n'.join('%-22s %-20s %3d lines' % (f.split('/')[-1], n, open(f).read()[a:z].count('\n')) for f, a, z, n in found))
    if not REMOVE: break
    by = {}
    for f, a, z, n in found: by.setdefault(f, []).append((a, z))
    for f, L in by.items():
        t = open(f, encoding='utf8').read()
        for a, z in sorted(L, reverse=True):
            total += t[a:z].count('\n'); t = t[:a] + t[z:]
        open(f, 'w', encoding='utf8').write(t)
print(total, 'lines removed' if REMOVE else '')

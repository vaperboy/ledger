# Cleanup helper: turn a post-wrapper into a pipeline step, in place.
#   python3 tools/tostep.py FILE "const dem8 = window.demand;" PIPE ORDER "label" [quiet]
# Handles the common shape:
#   const X = window.f;            (or: const X = f;)
#   window.f = function (a, b) {   (or: f = function (a) {)
#     const r = X.apply(this, arguments);
#     try { BODY } catch (e) { console.error(e); }      (or an empty catch: then the step is quiet)
#     return r;
#   };
# and writes:  addStep('PIPE', ORDER, 'label', (a, b, r) => { BODY });
import sys, re
path, start, pipe, order, label = sys.argv[1:6]
t = open(path, encoding='utf8').read()
assert t.count(start) == 1, 'start found %d times' % t.count(start)
def match(t, j):
    d = 0; k = j; n = len(t)
    while k < n:
        c = t[k]
        if c in '\'"`':
            q = c; k += 1
            while t[k] != q:
                if t[k] == '\\': k += 1
                k += 1
        elif t.startswith('//', k): k = t.index('\n', k)
        elif t.startswith('/*', k): k = t.index('*/', k) + 1
        elif c == '{': d += 1
        elif c == '}':
            d -= 1
            if d == 0: return k
        k += 1
    raise Exception('no match')
s0 = t.index(start)
a = t.rindex('\n', 0, s0) + 1
ind = t[a:s0]
var = re.match(r'const (\w+) = ', start).group(1)
fpos = t.index('function', s0 + len(start))
m = re.match(r'function\s*\(([^)]*)\)\s*\{', t[fpos:])
params = [p.strip() for p in m.group(1).split(',') if p.strip()]
fb = fpos + m.end() - 1
fe = match(t, fb)
body = t[fb + 1:fe]
mm = re.match(r'\s*const (\w+) = ' + var + r'\.apply\(this, arguments\);\s*try\s*\{', body)
assert mm, 'unexpected shape: ' + body[:120]
res = mm.group(1)
tb = fb + 1 + mm.end() - 1
te = match(t, tb)
inner = t[tb + 1:te]
rest = t[te + 1:fe]
mc = re.match(r'\s*catch\s*\(e\)\s*\{\s*(console\.error\(e\);)?\s*\}\s*return ' + res + r';\s*$', rest)
assert mc, 'unexpected tail: ' + rest[:120]
quiet = not mc.group(1) or (len(sys.argv) > 6 and sys.argv[6] == 'quiet')
while len(params) < 2: params.append('_' + str(len(params)))
args = ', '.join(params[:2] + [res])
e = fe + 1
while t[e] in ' ;': e += 1
if t[e] == '\n': e += 1
one = '\n' not in inner.strip()
if one:
    step = ind + "addStep('%s', %s, %s, (%s) => { %s }%s);\n" % (pipe, order, repr(label).replace('"', "'"), args, inner.strip(), ', true' if quiet else '')
else:
    # dedent the body by two spaces (it was inside try within a function)
    lines = inner.strip('\n').split('\n')
    lines = [l[2:] if l.startswith('  ') else l for l in lines]
    step = ind + "addStep('%s', %s, %s, (%s) => {\n%s\n%s}%s);\n" % (pipe, order, repr(label).replace('"', "'"), args, '\n'.join(lines), ind, ', true' if quiet else '')
t = t[:a] + step + t[e:]
open(path, 'w', encoding='utf8').write(t)
print(step[:400])

# Cleanup helper: cut a runtime wrapper out of a source file.
#   python3 tools/cut.py FILE "const se8 = window.setupEstimate;" [--block]
# Removes from the start text (from the beginning of its line) through the end of the function it installs
# (the matching closing brace and the ';' after it). With --block, also removes an enclosing "{ ... }" or
# "if (...) { ... }" or IIFE that is left empty (only comments and whitespace). Prints what it removed.
import sys, re
path, start = sys.argv[1], sys.argv[2]
block = '--block' in sys.argv
t = open(path, encoding='utf8').read()
assert t.count(start) == 1, 'start text found %d times' % t.count(start)
a = t.rindex('\n', 0, t.index(start)) + 1
i = t.index('function', t.index(start))
j = t.index('{', i)
# match braces, skipping strings, template literals, regexes are rare here; comments skipped
def match(t, j):
    d = 0; k = j; n = len(t)
    while k < n:
        c = t[k]
        if c in '\'"`':
            q = c; k += 1
            while t[k] != q:
                if t[k] == '\\': k += 1
                k += 1
        elif t.startswith('//', k): k = t.index('\n', k)
        elif t.startswith('/*', k): k = t.index('*/', k) + 1
        elif c == '{': d += 1
        elif c == '}':
            d -= 1
            if d == 0: return k
        k += 1
    raise Exception('no match')
e = match(t, j) + 1
while t[e] in ' ;': e += 1
if t[e] == '\n': e += 1
removed = t[a:e]
t = t[:a] + t[e:]
if block:
    # find the innermost enclosing block around position a that now holds only comments/whitespace
    k = a
    depth = 0
    s = None
    while k > 0:
        k -= 1
        c = t[k]
        if c == '}': depth += 1
        elif c == '{':
            if depth == 0: s = k; break
            depth -= 1
    if s is not None:
        ee = match(t, s)
        inner = re.sub(r'/\*[\s\S]*?\*/|//[^\n]*', '', t[s + 1:ee]).strip()
        if inner == '' or inner == "'use strict';":
            ls = t.rindex('\n', 0, s) + 1
            head = t[ls:s]
            le = ee + 1
            while le < len(t) and t[le] in ')(;': le += 1
            if le < len(t) and t[le] == '\n': le += 1
            removed = t[ls:le] + '  [+wrapper]'
            t = t[:ls] + t[le:]
open(path, 'w', encoding='utf8').write(t)
print('removed %d chars from %s:\n%s' % (len(removed), path, removed[:300] + ('...' if len(removed) > 300 else '')))

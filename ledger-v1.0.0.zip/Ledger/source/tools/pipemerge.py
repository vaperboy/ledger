# Cleanup helper (round 53): join neighbouring pipelines of the same screen/action into one where that keeps the order.
#   python3 tools/pipemerge.py [--dry]      (run from src/js, after tools/pipenames.py; then run pipenames.py again)
# Segment i+1 wraps segment i:  A2, R2, [A1, R1, base, P1], P2   (A around-steps, R routes, P steps).
# One pipeline runs  A, R, base, P,  so the two can be one when  (R2 is empty or A1 is empty)  and  (P1 is empty or A2 is
# empty), nothing replaces the screen outright between them, and both give their steps the same number of arguments. Around-steps and routes of the outer one get higher orders (they wrap), its steps come after.
import re, sys, math
DRY = '--dry' in sys.argv
order = [l.strip()[3:] for l in open('../manifest.txt') if l.strip().startswith('js/')]
T = {f: open(f, encoding='utf8').read() for f in order}
ALL = ''; OFF = {}
for f in order: OFF[f] = len(ALL); ALL += T[f]
def replaced_between(X, a, b):
    # another plain  X = ...  between two pipelines (a screen replaced outright) keeps them apart
    seg = ALL[OFF[a[0]] + a[1] + 5:OFF[b[0]] + b[1]]
    return any('pipeView(' not in seg[m.start():m.start() + 200].split('\n')[0] for m in re.finditer(r'(?<![\w.$])' + re.escape(X) + r'\s*=(?![=>])', seg))
segs = {}          # name -> dict(X, idx, A, R, P) lists of (file, start, order)
seq = {}           # X -> [names in load order]
rx = re.compile(r"pipeView\('([^']+)', [\w.]+, (\d+)\)|addStep\('([^']+?)(\.route|\.around)?', (\d+),")
for f in order:
    for m in rx.finditer(T[f]):
        if m.group(1):
            name = m.group(1); X = name.split(':')[0]
            segs[name] = dict(X=X, A=[], R=[], P=[], view=(f, m.start()), n=int(m.group(2)))
            seq.setdefault(X, []).append(name)
        elif m.group(3) in segs:
            k = {'.around': 'A', '.route': 'R', None: 'P'}[m.group(4)]
            segs[m.group(3)][k].append((f, m.start(), int(m.group(5))))
edits = {}         # (file, start) -> ('view-remove') or ('step', newname, neworder)
merged = 0
for X, names in seq.items():
    i = 0
    cur = names[0]
    for nxt in names[1:]:
        a, b = segs[cur], segs[nxt]
        if a['n'] == b['n'] and not replaced_between(X, a['view'], b['view']) and (not b['R'] or not a['A']) and (not a['P'] or not b['A']):
            for k in 'ARP':
                off = math.ceil(max([o for _, _, o in a[k]] or [0]) / 10) * 10
                for (f, s, o) in b[k]:
                    edits[(f, s)] = ('step', cur, o + off)
                    a[k].append((f, s, o + off))
            edits[b['view']] = ('view',)
            merged += 1
        else:
            cur = nxt
print('merged', merged, 'pipelines into their neighbours')
if not DRY:
    for f in order:
        t = T[f]; out = []; pos = 0
        for m in rx.finditer(t):
            e = edits.get((f, m.start()))
            if not e: continue
            if e[0] == 'view':
                a = t.rindex('\n', 0, m.start()) + 1; z = t.index('\n', m.start()) + 1
                line = t[a:z]
                assert re.match(r"\s*[\w.]+ = pipeView\('[^']+', [\w.]+, \d+\);( /\*.*\*/)?\n$", line), line
                out.append(t[pos:a]); pos = z
            else:
                out.append(t[pos:m.start()]); out.append("addStep('%s%s', %d," % (e[1], m.group(4) or '', e[2])); pos = m.end()
        out.append(t[pos:])
        n = ''.join(out)
        if n != t: open(f, 'w', encoding='utf8').write(n)

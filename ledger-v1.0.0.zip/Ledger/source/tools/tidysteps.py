# Cleanup helper (round 53): tidy the layout of every addStep body (whitespace only).
#   python3 tools/tidysteps.py      (run from src/js)
# Bodies are indented two spaces under their addStep line; a one-statement body sits on one line; no trailing spaces,
# no blank first or last lines. Bodies with template literals are left as they are.
import re, glob
exec(open(__file__.replace('tidysteps.py', 'uistep.py'), encoding='utf8').read().split('order = [l.strip()[3:]')[0].split('NOROUTE')[0])
order = [l.strip()[3:] for l in open('../manifest.txt') if l.strip().startswith('js/')]
n = 0
for f in order:
    t = open(f, encoding='utf8').read(); out = []; pos = 0
    for m in re.finditer(r"^([ \t]*)addStep\('[^']+', \d+, '[^']*', \([^)]*\) => \{", t, re.M):
        if m.start() < pos: continue
        ind = m.group(1); b = m.end() - 1
        try: e = match(t, b)
        except Exception: continue
        body = t[b + 1:e]
        if '`' in body: continue
        lines = [l.rstrip() for l in body.split('\n')]
        while lines and not lines[0].strip(): lines.pop(0)
        while lines and not lines[-1].strip(): lines.pop()
        if not lines: nb = ' '
        elif len(lines) == 1 and len(m.group(0)) + len(lines[0].strip()) < 170:
            nb = ' ' + lines[0].strip() + ' '
        else:
            if len(lines) == 1: lines = [lines[0]]
            mi = min(len(l) - len(l.lstrip()) for l in lines if l.strip())
            sh = len(ind) + 2 - mi
            lines = [(' ' * sh + l if sh >= 0 else l[-sh:]) if l.strip() else '' for l in lines]
            nb = '\n' + '\n'.join(lines) + '\n' + ind
        if nb != body:
            out.append(t[pos:b + 1]); out.append(nb); pos = e; n += 1
    out.append(t[pos:])
    nt = ''.join(out)
    if nt != t: open(f, 'w', encoding='utf8').write(nt)
print(n, 'step bodies tidied')

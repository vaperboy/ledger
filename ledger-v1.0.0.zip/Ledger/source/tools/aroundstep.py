# Cleanup helper (round 53): turn the remaining overrides (a screen, a button's action or a hook that does its own work
# and calls the one underneath when it needs it) into around-steps:
#   X = pipeView('X', X, n);  addStep('X.around', 10, 'label', (args..., next) => {...})
#   python3 tools/aroundstep.py [--dry] [X ...]      (run from src/js; afterwards run tools/pipenames.py --merge)
# Handles  const VAR = X;  followed by  [if (VAR)] X = function (a, b) {...}  or  X = (a, b) => {...}  or  X = a => expr;
# In the body the captured original becomes next: VAR.apply(this, arguments) -> next(), VAR(same args) -> next(),
# VAR.call(this, a) / VAR(a) -> next(a), VAR() -> next(undefined) when the override has parameters, a bare VAR -> next.
# Overrides that still use this or arguments afterwards, or capture the original anywhere else, are left alone.
import re, sys
exec(open(__file__.replace('aroundstep.py', 'uistep.py'), encoding='utf8').read().split('order = [l.strip()[3:]')[0].split('NOROUTE')[0])
DRY = '--dry' in sys.argv
ONLY = [a for a in sys.argv[1:] if not a.startswith('--')]
order = [l.strip()[3:] for l in open('../manifest.txt') if l.strip().startswith('js/')]
TGT = r'(?:window\.CT|window|V\.heads|V|CT|U|ACT|ACTS|R\d+|FAM\.\w+)\.\w+'
RX = re.compile(r'^([ \t]*)const (\w+) = (' + TGT + r');\n[ \t]*(?:if \(\2\) )?\3 = (?:function\s*\(([^)]*)\)\s*\{|\(([^)]*)\)\s*=>\s*|(\w+)\s*=>\s*)', re.M)
def endexpr(t, k):
    # end of an expression-bodied arrow: the ';' at depth 0
    d = 0
    while k < len(t):
        c = t[k]
        if c in '\'"`':
            q = c; k += 1
            while t[k] != q:
                if t[k] == '\\': k += 1
                k += 1
        elif c in '([{': d += 1
        elif c in ')]}': d -= 1
        elif c == ';' and d == 0: return k
        k += 1
    raise Exception('no end')
n_done = 0
for f in order:
    t = open(f, encoding='utf8').read(); changed = False; skip = set()
    while True:
        found = None
        for m in RX.finditer(t):
            X, var = m.group(3), m.group(2)
            if (ONLY and X not in ONLY) or m.start() in skip: continue
            ps = m.group(4) if m.group(4) is not None else m.group(5) if m.group(5) is not None else m.group(6)
            params = [p.strip() for p in ps.split(',') if p.strip()]
            if any('=' in p or '...' in p or '{' in p for p in params): skip.add(m.start()); continue
            if m.group(4) is not None or t[m.end():m.end() + 1] == '{':
                fb = m.end() - 1 if m.group(4) is not None else m.end(); fe = match(t, fb)
                body = t[fb + 1:fe]; e = fe + 1
            else:
                ee = endexpr(t, m.end()); body = ' return ' + t[m.end():ee].strip() + '; '; e = ee
            nb = body.replace(var + '.apply(this, arguments)', 'next()')
            nb = re.sub(r'\b' + var + r'\.call\(this, ', 'next(', nb)
            nb = re.sub(r'\b' + var + r'\.call\(this\)', 'next(undefined)' if params else 'next()', nb)
            if params: nb = re.sub(r'\b' + var + r'\(' + re.escape(', '.join(params)) + r'\)', 'next()', nb)
            nb = re.sub(r'\b' + var + r'\(\)', 'next(undefined)' if params else 'next()', nb)
            nb = re.sub(r'\b' + var + r'\(', 'next(', nb)
            nb = re.sub(r'(?<![.\w])' + var + r'\b(?!\s*:)', 'next', nb)
            c = code(nb)
            rest_of_file = t[:m.start()] + t[e:]
            if re.search(r'\bnext\s*(\?|&&|\|\|)|!next\b|if \(next\)|typeof next', c):
                print('skip (original may be missing):', X, f.split('/')[-1]); skip.add(m.start()); continue
            if re.search(r'\bthis\b|\barguments\b', c) or re.search(r'(?<![.\w])' + var + r'\b', code(rest_of_file)) or 'next' in code(body):
                print('skip:', X, f.split('/')[-1]); skip.add(m.start()); continue
            pre = t[:m.start()].rstrip('\n').split('\n')[-1].strip()
            lab = re.sub(r'^/\*\s*|\s*\*/$', '', pre) if pre.startswith('/*') and pre.endswith('*/') else (f.split('/')[-1][:-3] + ' ' + X)
            guard = bool(re.match(r'[ \t]*const \w+ = [\w.]+;\n[ \t]*if \(', t[m.start():m.end()]))
            found = (m, X, params, nb, lab.replace("'", '’'), e, guard)
            break
        if not found: break
        m, X, params, nb, lab, e, guard = found
        ind = m.group(1)
        while e < len(t) and t[e] in ' ;': e += 1
        if e < len(t) and t[e] == '\n': e += 1
        if '\n' in nb.strip():
            lines = nb.strip('\n').split('\n')
            lines = [l[2:] if l.startswith('  ') else l for l in lines]
            fn = '{\n%s\n%s}' % ('\n'.join(lines), ind)
        else:
            fn = '{ %s }' % nb.strip()
        name = X.replace('window.CT.', 'CT.')
        new = ind + "%s = pipeView('%s', %s, %d);\n" % (X, name, X, len(params)) + \
              ind + "addStep('%s.around', 10, '%s', (%s) => %s);\n" % (name, lab, ', '.join(params + ['next']), fn)
        if guard: new = ind + 'if (%s) {\n' % X + ''.join('  ' + l + '\n' for l in new.rstrip('\n').split('\n')) + ind + '}\n'
        print('around', X, f.split('/')[-1]); n_done += 1
        if DRY: skip.add(m.start()); continue
        t = t[:m.start()] + new + t[e:]; changed = True
    if changed: open(f, 'w', encoding='utf8').write(t)
print(n_done, 'converted')

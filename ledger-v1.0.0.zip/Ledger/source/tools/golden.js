/* Before/after equality check for the cleanup.
   node tools/golden.js BUILD.html OUT_DIR
   Plays the same seeded games (several countries, every family of business, the late game) with a fixed random
   source and a fake clock, then writes:
     OUT_DIR/state.json   the whole game state after each scenario (JSON, keys in stable order)
     OUT_DIR/screens.txt  the text of every screen visited
     OUT_DIR/summary.txt  one line per company, plus errors
   Two builds that behave the same produce identical files: compare the three files with cmp (or diff for details). */
const puppeteer = require('/opt/npm-tools/node_modules/puppeteer-core');
const fs = require('fs');
const [,, file, outDir] = process.argv;
const SCEN = [
  { cc: 'NO', types: ['cafe', 'plumber', 'mktg', 'cleaning', 'courier', 'kiosk', 'restaurant', 'cardealer', 'bakery', 'resrent', 'gym', 'electrician', 'event'], late: 1 },
  { cc: 'UK', types: ['webdev', 'photo', 'boutique', 'taxi', 'barber', 'construction', 'farm'] },
  { cc: 'JP', types: ['cafe', 'cons', 'grocery', 'trucking'] },
  { cc: 'LT', types: ['cleaning', 'mktg', 'webshop', 'hardware', 'physio'] },
  { cc: 'US', types: ['restaurant', 'acctfirm', 'drivsk', 'brewery', 'parking'] },
  { cc: 'BR', types: ['tutor', 'carclean', 'pets', 'foodtruck'] }
];
(async () => {
  const b = await puppeteer.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--no-sandbox', '--disable-gpu'], headless: 'new', protocolTimeout: 3600000 });
  fs.mkdirSync(outDir, { recursive: true });
  const states = [], screens = [], summary = [];
  for (const sc of SCEN) {
    const p = await b.newPage();
    await p.setViewport({ width: 390, height: 844 });
    const errs = [];
    p.on('pageerror', e => errs.push('PAGEERR ' + e.message));
    p.on('console', m => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errs.push('CONSOLE ' + m.text().slice(0, 200)); });
    await p.evaluateOnNewDocument(() => {
      /* a fixed random source and a clock that only moves when asked */
      let s = 123456789;
      Math.random = () => { s = (s + 0x6D2B79F5) | 0; let t = Math.imul(s ^ (s >>> 15), 1 | s); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
      let now = 1760000000000;
      const RD = Date;
      const tick = () => (now += 7);
      function FD(...a) { if (!(this instanceof FD)) return new RD(tick()).toString(); return a.length ? new RD(...a) : new RD(tick()); }
      FD.prototype = RD.prototype; FD.now = tick; FD.UTC = RD.UTC; FD.parse = RD.parse;
      window.Date = FD;
      performance.now = () => now - 1760000000000;
      try { localStorage.clear(); } catch (e) { }
    });
    await p.goto('file://' + file, { waitUntil: 'domcontentloaded' });
    await new Promise(r => setTimeout(r, 400));
    const res = await p.evaluate(sc => {
      const out = { lines: [], screens: [], errs: [] };
      const ce = console.error; console.error = function () { out.errs.push([...arguments].map(x => x && x.stack ? x.stack.split('\n').slice(0, 2).join(' ') : String(x)).join(' ').slice(0, 200)); return ce.apply(console, arguments); };
      const shot = key => { try { UI.render(true); const m = document.querySelector('#app main') || document.querySelector('#app'); out.screens.push('### ' + key + '\n' + (m ? m.innerText : '').replace(/[ \t]+/g, ' ')); } catch (e) { out.screens.push('### ' + key + '\nERR ' + e.message); } };
      const answer = () => S.inbox.forEach(m => { if (m.status !== 'open') return; try { const n = (m.opts || []).length; resolveMsg(m.id, m.act === 'pay29all' ? 0 : n ? (m.title.length % n) : 0); } catch (e) { out.errs.push('resolve ' + (m.act || m.kind) + ': ' + e.message); } });
      UI.ui.inp.name = 'Golden Test'; UI.ui.sc = sc.cc; UI.ui.city = null; UI.ACT.startgame();
      S.cash += 3e8;
      const cos = [];
      sc.types.forEach((t, i) => {
        try {
          const o = { name: 'G' + i + ' ' + t, form: BD[t].needAS ? 'AS' : (i % 2 ? 'AS' : 'ENK'), acc: S.pool.acc[0].id };
          const co = startCompany(t, o);
          if (typeof co === 'string') { out.lines.push('START ' + t + ' ' + co); return; }
          injectCash(co, Math.round(setupEstimate(t, o).total * 1.6));
          setupAndOpen(co);
          co.staff.forEach(s => onbItems(s.role).forEach(it => { s.onb = s.onb || {}; s.onb[it[0]] = 1; }));
          topUpEq(co);
          if (i % 3 === 0) co.ohrs = 40;
          cos.push(co);
        } catch (e) { out.lines.push('START ' + t + ' ERR ' + e.message); }
      });
      UI.ui.sheet = null;
      for (let d = 0; d < 14; d++) { try { dayStep(); } catch (e) { out.errs.push('dayStep ' + e.message); } answer(); UI.ui.sheet = null; }
      for (let w = 0; w < 24; w++) { try { nextWeek(); } catch (e) { out.errs.push('nextWeek ' + e.message); } answer(); UI.ui.sheet = null; }
      if (sc.late) {
        try {
          const h = createHolding('Golden Holding AS', S.pool.acc[0].id);
          cos.slice(0, 5).forEach(c => { if (c.st === 'open') moveToHolding(c, h.id); });
          sellShares(cos[0], 30, 'primary');
          rentOffice('cow', S.player.city);
          const cl = clubsOf(sc.cc).filter(c => c.owner !== 'you').sort((a, b) => a.val - b.val)[0];
          if (cl) { const x = proposeClub(cl, 3); if (x && x.price && x.r === 'accept') buyClub(cl, x.price); }
        } catch (e) { out.errs.push('late ' + e.message); }
        for (let w = 0; w < 12; w++) { try { nextWeek(); } catch (e) { out.errs.push('nextWeek ' + e.message); } answer(); UI.ui.sheet = null; }
      }
      /* every screen */
      S.cos.filter(c => c.st !== 'sold' && c.st !== 'bust').forEach(c => {
        UI.ui.tab = 'cos'; UI.ui.stack = []; UI.ui.view = { n: 'co', p: { id: c.id } }; UI.render(true);
        const tabs = [...document.querySelectorAll('#app main .ptabs button')];
        tabs.forEach((b, i) => { try { const bb = document.querySelectorAll('#app main .ptabs button')[i]; bb.click(); UI.ui.sheet = null; shot(c.name + ' / ' + bb.textContent); } catch (e) { out.screens.push('### ' + c.name + ' tab ' + i + ' ERR ' + e.message); } });
      });
      /* sub-pages inside the first companies, and the hiring and start screens */
      S.cos.filter(c => c.st === 'open' && c.type !== 'hold').slice(0, 4).forEach(c => {
        UI.ui.tab = 'cos'; UI.ui.stack = []; UI.ui.view = { n: 'co', p: { id: c.id } }; UI.render(true);
        const nt = document.querySelectorAll('#app main .ptabs button').length;
        for (let i = 0; i < nt; i++) {
          UI.ui.view = { n: 'co', p: { id: c.id } }; UI.render(true);
          const tb = document.querySelectorAll('#app main .ptabs button')[i]; if (!tb) continue; tb.click();
          const subs = [...document.querySelectorAll('#app main [data-a="cosub"], #app main [data-a="cofin"], #app main [data-a="codeal"]')].map(b => [b.dataset.a, b.dataset.p]).filter(x => { try { return JSON.parse(x[1]).s; } catch (e) { return false; } });
          subs.forEach(x => { try { const view = UI.ui.view; UI.ACT[x[0]](JSON.parse(x[1])); UI.ui.sheet = null; shot(c.name + ' / ' + tb.textContent + ' / ' + JSON.parse(x[1]).s); UI.ui.view = view; } catch (e) { out.screens.push('### sub ERR ' + e.message); } });
        }
        [['hire', { id: c.id }], ['mgrhire', { id: c.id }]].forEach(v => { try { UI.ui.view = { n: v[0], p: v[1] }; UI.ui.sheet = null; shot(c.name + ' / ' + v[0]); } catch (e) { } });
      });
      ['cafe', 'plumber', 'mktg', 'bank', 'club'].forEach(t => { try { UI.ui.nc = null; UI.ui.tab = 'cos'; UI.go('newco', { bd: t }); UI.ui.sheet = null; shot('newco ' + t); } catch (e) { } });
      try { UI.go('newbiz'); shot('newbiz'); } catch (e) { }
      ['home', 'cos', 'hq', 'meet'].forEach(t => { try { UI.ACT.tab(t); UI.ui.sheet = null; shot('tab ' + t); } catch (e) { } });
      ['bank', 'invest', 'news', 'reviews', 'stats', 'lux', 'tax', 'registry', 'clubs', 'startups', 'settings'].forEach(n => { try { UI.ACT.tab('phone'); UI.go(n); UI.ui.sheet = null; shot('app ' + n); } catch (e) { } });
      try { UI.go('weekreport'); shot('weekreport'); } catch (e) { }
      out.lines.push('NET ' + Math.round(netWorth().total) + ' week ' + S.week + ' cash ' + Math.round(S.cash));
      S.cos.forEach(c => out.lines.push(c.name + ' | ' + c.st + ' | cash ' + Math.round(c.cash) + ' | staff ' + (c.staff || []).length + ' | rev ' + Math.round((c.lastW && c.lastW.rev) || 0) + ' | aware ' + Math.round(c.aware || 0)));
      try { out.gaps = ledgerGaps().filter(g => g[0] !== 'me').map(g => g[0] + ' ' + Math.round(g[1])).join(', '); } catch (e) { out.gaps = 'n/a'; }
      /* stable state: keys sorted, numbers to 9 significant digits */
      const seen = new WeakSet();
      const norm = v => {
        if (typeof v === 'number') return isFinite(v) ? +v.toPrecision(9) : String(v);
        if (!v || typeof v !== 'object') return v;
        if (seen.has(v)) return '[cycle]';
        seen.add(v);
        if (Array.isArray(v)) return v.map(norm);
        const o = {};
        Object.keys(v).sort().forEach(k => { o[k] = norm(v[k]); });
        return o;
      };
      out.state = JSON.stringify(norm(S));
      return out;
    }, sc);
    states.push('=== ' + sc.cc + '\n' + res.state);
    screens.push('=== ' + sc.cc + '\n' + res.screens.join('\n'));
    summary.push('=== ' + sc.cc + '\n' + res.lines.join('\n') + '\nGAPS ' + res.gaps + '\nERRS ' + res.errs.concat(errs).slice(0, 20).join('\n     '));
    await p.close();
  }
  fs.writeFileSync(outDir + '/state.json', states.join('\n'));
  fs.writeFileSync(outDir + '/screens.txt', screens.join('\n'));
  fs.writeFileSync(outDir + '/summary.txt', summary.join('\n'));
  console.log('golden written to ' + outDir);
  await b.close();
})();

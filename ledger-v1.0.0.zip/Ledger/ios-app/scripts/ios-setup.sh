#!/usr/bin/env bash
# Ledger: fits the Xcode project that "npx cap add ios" made to the game. Runs once (npm run ios:add does it), on a Mac.
#  - app icon (one 1024 px image, Xcode makes the rest) and the dark launch screen
#  - iCloud entitlements file, linked to the App target
#  - Info.plist: name, portrait on iPhone, light status bar text, no export-encryption question, arm64
set -euo pipefail
cd "$(dirname "$0")/.."
APP=ios/App/App
[ -d "$APP" ] || { echo "No $APP yet. Run: npx cap add ios"; exit 1; }

# icon and launch screen
rm -rf "$APP/Assets.xcassets/AppIcon.appiconset"
cp -R assets/AppIcon.appiconset "$APP/Assets.xcassets/AppIcon.appiconset"
cp assets/LaunchScreen.storyboard "$APP/Base.lproj/LaunchScreen.storyboard"

# iCloud (the game, its slots and their list): entitlements file on the App target
cp assets/App.entitlements "$APP/App.entitlements"
PBX=ios/App/App.xcodeproj/project.pbxproj
if ! grep -q "CODE_SIGN_ENTITLEMENTS" "$PBX"; then
  sed -i '' 's#INFOPLIST_FILE = App/Info.plist;#INFOPLIST_FILE = App/Info.plist;\
				CODE_SIGN_ENTITLEMENTS = App/App.entitlements;#' "$PBX"
fi

# version 1.0.0 (build 1): what players see as Patch V. 1.0.0
sed -i '' 's/MARKETING_VERSION = [^;]*;/MARKETING_VERSION = 1.0.0;/g; s/CURRENT_PROJECT_VERSION = [^;]*;/CURRENT_PROJECT_VERSION = 1;/g' "$PBX"

# Info.plist
PL="$APP/Info.plist"
pb() { /usr/libexec/PlistBuddy -c "$1" "$PL" 2>/dev/null || true; }
pb "Set :CFBundleDisplayName Ledger"
pb "Delete :ITSAppUsesNonExemptEncryption"; pb "Add :ITSAppUsesNonExemptEncryption bool false"
pb "Delete :UIStatusBarStyle"; pb "Add :UIStatusBarStyle string UIStatusBarStyleLightContent"
pb "Delete :UIViewControllerBasedStatusBarAppearance"; pb "Add :UIViewControllerBasedStatusBarAppearance bool false"
pb "Delete :UIRequiredDeviceCapabilities"; pb "Add :UIRequiredDeviceCapabilities array"; pb "Add :UIRequiredDeviceCapabilities:0 string arm64"
pb "Delete :UISupportedInterfaceOrientations"; pb "Add :UISupportedInterfaceOrientations array"
pb "Add :UISupportedInterfaceOrientations:0 string UIInterfaceOrientationPortrait"
# iPad keeps all four (the game has a wide layout there, and iPad multitasking needs them)
pb "Delete :UISupportedInterfaceOrientations~ipad"; pb "Add :UISupportedInterfaceOrientations~ipad array"
i=0; for o in Portrait PortraitUpsideDown LandscapeLeft LandscapeRight; do pb "Add :UISupportedInterfaceOrientations~ipad:$i string UIInterfaceOrientation$o"; i=$((i+1)); done

echo "ios-setup: icon, launch screen, iCloud entitlements and Info.plist done."
echo "Next: npx cap sync ios, then npx cap open ios (see README.txt: team, iCloud container, in-app purchases)."

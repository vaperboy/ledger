/* Ledger app build: node scripts/build-www.mjs   (npm run build / npm run sync)
   Makes www/ for Capacitor from the game as it is played in the browser:
     ../ledger.html  -> www/index.html, with
        - the Google Fonts links swapped for the fonts bundled in the app (www/fonts/fonts.css), so the app never
          calls a font server and looks the same offline,
        - www/app.js loaded first (native/app-bridge.js bundled with esbuild: LedgerApp for the store, files, iCloud)
     ../pictures     -> www/pictures
   Fonts: the game's own two, Bricolage Grotesque and DM Sans, from the @fontsource-variable packages (npm install). */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const APP = path.join(HERE, '..'), GAME = path.join(APP, '..'), WWW = path.join(APP, 'www');
const require = createRequire(import.meta.url);
const fail = m => { console.error('build-www: ' + m); process.exit(1); };

/* 1. the page */
const src = path.join(GAME, 'ledger.html');
if (!fs.existsSync(src)) fail('no ledger.html next to ios-app. Build the game first: cd ../source && node tools/build.js, then copy ledger.html up one folder.');
let html = fs.readFileSync(src, 'utf8');
const before = html.length;
html = html.replace(/<link rel="preconnect" href="https:\/\/fonts\.(googleapis|gstatic)\.com"[^>]*>\s*/g, '');
html = html.replace(/<link rel="stylesheet" href="https:\/\/fonts\.googleapis\.com\/[^"]*">/, '<link rel="stylesheet" href="fonts/fonts.css">');
if (/fonts\.googleapis|fonts\.gstatic/.test(html)) fail('a Google Fonts link is still in the page; update the pattern in this script.');
if (!html.includes('fonts/fonts.css')) fail('could not find the Google Fonts stylesheet link in ledger.html.');
html = /<meta charset="utf-8">/i.test(html) ? html.replace(/<meta charset="utf-8">/i, m => m + '<script src="app.js"></script>') : html.replace(/<head>/i, '<head><script src="app.js"></script>');
fs.rmSync(WWW, { recursive: true, force: true });
fs.mkdirSync(path.join(WWW, 'fonts', 'files'), { recursive: true });
fs.writeFileSync(path.join(WWW, 'index.html'), html);

/* 2. the fonts: the package's CSS (all its axes when it has them), renamed to the names the game asks for */
const FONTS = [['@fontsource-variable/bricolage-grotesque', 'Bricolage Grotesque'], ['@fontsource-variable/dm-sans', 'DM Sans']];
let css = '/* Bundled fonts (SIL Open Font License), from fontsource. Made by scripts/build-www.mjs. */\n';
for (const [pkg, family] of FONTS) {
  let dir;
  try { dir = path.dirname(require.resolve(pkg + '/package.json')); } catch (e) { fail('font package ' + pkg + ' missing. Run npm install.'); }
  const file = ['full.css', 'opsz.css', 'index.css'].map(f => path.join(dir, f)).find(f => fs.existsSync(f));
  if (!file) fail('no CSS file in ' + pkg);
  let c = fs.readFileSync(file, 'utf8').replace(new RegExp("'" + family + " Variable'|\"" + family + " Variable\"", 'g'), "'" + family + "'");
  c = c.replace(/url\(\.\/files\/([^)]+)\)/g, (m, f) => {
    const from = path.join(dir, 'files', f);
    if (fs.existsSync(from)) fs.copyFileSync(from, path.join(WWW, 'fonts', 'files', f));
    return 'url(./files/' + f + ')';
  });
  c = c.replace(/font-display:\s*swap/g, 'font-display: block'); /* bundled: no flash of a fallback font */
  css += c + '\n';
  const lic = path.join(dir, 'LICENSE');
  if (fs.existsSync(lic)) fs.copyFileSync(lic, path.join(WWW, 'fonts', family.replace(/ /g, '') + '-LICENSE.txt'));
}
fs.writeFileSync(path.join(WWW, 'fonts', 'fonts.css'), css);

/* 3. the bridge to the phone */
const config = JSON.parse(fs.readFileSync(path.join(APP, 'config.json'), 'utf8'));
let esbuild;
try { esbuild = require('esbuild'); } catch (e) { fail('esbuild missing. Run npm install.'); }
esbuild.buildSync({
  entryPoints: [path.join(APP, 'native', 'app-bridge.js')],
  bundle: true, format: 'iife', minify: true, target: 'safari15', legalComments: 'none',
  define: { __LEDGER_CONFIG__: JSON.stringify(config) },
  outfile: path.join(WWW, 'app.js')
});

/* 4. the pictures */
const pics = path.join(GAME, 'pictures');
if (fs.existsSync(pics)) fs.cpSync(pics, path.join(WWW, 'pictures'), { recursive: true });
else console.warn('build-www: no pictures folder next to ledger.html; the game shows its drawings instead.');

if (/PUT_YOUR/.test(config.revenuecatKey)) console.warn('build-www: config.json has no RevenueCat key yet; the store says it is not set up.');
console.log('build-www: www/ ready (' + Math.round(before / 1024) + ' kB game, fonts bundled, app.js ' + Math.round(fs.statSync(path.join(WWW, 'app.js')).size / 1024) + ' kB)');

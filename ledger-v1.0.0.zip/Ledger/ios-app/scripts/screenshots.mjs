/* Ledger App Store screenshots: node scripts/screenshots.mjs   (npm run screenshots builds www first)
   Plays a short game in www/index.html (the app's own page, bundled fonts) and saves real screens at the sizes
   App Store Connect asks for:
     iPhone 6.9"  1320 x 2868   (accepted for every iPhone size)
     iPad 13"     2064 x 2752   (needed because the app also runs on iPad)
   Output: screenshots/iphone-1-home.png ... and screenshots/ipad-1-home.png ... */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const APP = path.join(HERE, '..'), OUT = path.join(APP, 'screenshots');
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const page0 = path.join(APP, 'www', 'index.html');
if (!fs.existsSync(page0)) { console.error('No www/index.html. Run: node scripts/build-www.mjs'); process.exit(1); }
fs.mkdirSync(OUT, { recursive: true });

const DEVICES = [
  { name: 'iphone', width: 440, height: 956, scale: 3 },
  { name: 'ipad', width: 1032, height: 1376, scale: 2 }
];

/* a game most of a year in: a barber shop and a photo studio, both doing well */
function seed() {
  PRO.on = true; PRO.showAll = true;
  localStorage.setItem('ledger-v3:guide', '1'); /* the welcome cards stay away */
  UI.ui.menu = 0; UI.ui.inp.name = 'Ava Clarke'; UI.ui.sc = 'UK'; UI.ui.city = null; UI.ui.story = 'loan';
  UI.ACT.startgame();
  S.cash += KC(9e6);
  const mk = (t, name, hours) => {
    const co = startCompany(t, { name, form: 'AS' });
    if (typeof co === 'string') return null;
    co.ohrs = hours;
    injectCash(co, Math.round(setupEstimate(t, {}).total * 1.6));
    setupAndOpen(co);
    try { topUpEq(co); } catch (e) { }
    co.aware = Math.max(co.aware || 0, 50);
    return co;
  };
  const shop = mk('barber', 'Sharp & Co', 20);
  mk('photo', 'Northlight Studio', 20);
  const answer = () => S.inbox.forEach(m => { if (m.status === 'open') { try { resolveMsg(m.id, 0); } catch (e) { } } });
  const refund = () => S.cos.forEach(co => (co.compl || []).filter(c => c.st === 'open').forEach(c => { try { UI.ACT.complres({ id: co.id, c: c.id, a: 'refund' }); } catch (e) { } }));
  for (let i = 0; i < 40 && !S.over; i++) { nextWeek(); answer(); refund(); UI.ui.sheet = null; }
  window.__shop = shop.id;
  S.cel28q = []; /* the milestone moments wait; screenshots show the game itself */
  return true;
}
/* the screens, in the order they show on the App Store */
const SCENES = [
  ['home', () => { UI.ui.sheet = null; UI.ui.stack = []; UI.ui.tab = 'home'; UI.ui.view = { n: 'home', p: {} }; UI.render(true); }],
  ['company', () => { UI.ui.sheet = null; UI.ACT.go({ n: 'co', p: { id: window.__shop, t: 'ov' } }); }],
  ['companies', () => { UI.ui.sheet = null; UI.ui.stack = []; UI.ACT.tab('cos'); }],
  ['phone', () => { UI.ui.sheet = null; UI.ui.stack = []; UI.ACT.tab('phone'); }],
  ['inbox', () => { UI.ui.sheet = null; UI.ui.stack = []; UI.ACT.tab('meet'); }],
  ['start', () => { S = null; UI.ui.sheet = null; UI.ui.menu = 0; UI.ui.inp = { name: 'Ava Clarke' }; UI.render(true); }]
];

const browser = await chromium.launch();
for (const d of DEVICES) {
  const ctx = await browser.newContext({ viewport: { width: d.width, height: d.height }, deviceScaleFactor: d.scale, isMobile: d.name === 'iphone', hasTouch: true });
  const page = await ctx.newPage();
  await page.goto('file://' + page0, { waitUntil: 'load' });
  await page.waitForTimeout(800);
  await page.evaluate(seed);
  let i = 0;
  for (const [name, show, only] of SCENES) {
    if (only && only !== d.name) continue;
    i++;
    await page.evaluate(show);
    await page.waitForTimeout(300);
    /* a pop-up the game opened on its own (an alert, a milestone) is closed: the screen itself is the picture */
    await page.evaluate(() => { if (S) S.cel28q = []; if (UI.ui.sheet) { UI.ui.sheet = null; UI.render(true); } document.querySelectorAll('.toast').forEach(t => t.remove()); });
    await page.waitForTimeout(700); /* slide-in animations finish */
    const file = path.join(OUT, d.name + '-' + i + '-' + name + '.png');
    await page.screenshot({ path: file, animations: 'disabled' });
    console.log('saved ' + path.relative(APP, file));
  }
  await ctx.close();
}
await browser.close();

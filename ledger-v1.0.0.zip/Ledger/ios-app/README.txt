Ledger | Business Tycoon Simulator · Patch V. 1.0.0 as an iPhone and iPad app

App Store names (Apple's limits): App name, at most 30 characters: "Ledger: Business Tycoon Sim"
("Ledger | Business Tycoon Simulator" is 34, too long). Subtitle (30): "Build companies. Hire. Invest."
Home screen name: Ledger. Version 1.0.0, build 1 (ios-setup.sh sets both).

What is here
  config.json            RevenueCat key, App Store id, product ids, entitlement ids  <- fill in the key and, once
                         App Store Connect has made the app, its Apple ID number (appStoreId: Settings › Rate Ledger)
  capacitor.config.json  app id (app.ledgergame.ios), name, dark background, keyboard
  native/app-bridge.js   the game meets the phone: LedgerApp.store (RevenueCat), LedgerApp.disk (files, iCloud)
  native/ledger-native/  the app's own native plugin (Swift): save files, iCloud, share sheet, links
  assets/                app icon (1024 px, no transparency), icon.svg, dark launch screen, iCloud entitlements
  scripts/build-www.mjs  ../ledger.html + ../pictures -> www/, Google Fonts swapped for bundled fonts, app.js first
  scripts/ios-setup.sh   once after "cap add ios": icon, launch screen, entitlements, Info.plist
  scripts/screenshots.mjs  App Store screenshots from the real game (iPhone 6.9" and iPad 13")
  screenshots/           ready-made screenshots (see note at the end)
  privacy/index.html     the privacy policy page to host; the game shows the same text in Settings › Privacy

One time, on the Mac (Node 20 or newer, the current Xcode)
  1. cd ios-app && npm install
  2. npm run ios:add            (builds www, adds the Xcode project, runs ios-setup.sh, syncs)
  3. npm run open               (opens Xcode)
  4. In Xcode › App target › Signing & Capabilities:
       - Team: your Apple developer team. Change the bundle id here and in capacitor.config.json if you want.
       - + Capability › iCloud: tick "iCloud Documents" and the container iCloud.<bundle id> (press + to make it).
       - + Capability › In-App Purchase.
  5. Run on your iPhone.

App Store Connect and RevenueCat
  - Products (ids in config.json) and launch prices (set the US price; Apple fills in every other country):
      ledger_pro_monthly   $3.99   auto-renewing, 1 month  } one subscription group "Ledger Pro"
      ledger_pro_yearly    $24.99  auto-renewing, 1 year   }
      ledger_pro_lifetime  $49.99  non-consumable
      ledger_pack_world, ledger_pack_tycoon, ledger_pack_estates, ledger_pack_time   $4.99 each, non-consumable
      ledger_skin_midnight $1.99   non-consumable (a look: colours only, not part of Pro)
    A new look later: a block in source/src/styles/05_skins.css, a line in pro.js SKINS and USD, a product here.
    The game shows each player the App Store's price in their own currency. In a browser it shows a close local
    price worked out from these dollar prices (features/player/pro.js USD).
  - RevenueCat: entitlements pro (the three Pro products), world, tycoon, estates, time (one pack each),
    skin_midnight. Put all eight in the current offering. Copy the iOS public API key (appl_...) into config.json.
  - Privacy: host privacy/index.html and paste its address into App Privacy. Support URL / email: matas1114@gmail.com.
    Data types to declare: Purchases and Identifiers (used for app functionality, not linked to you, no tracking).
  - Screenshots: upload screenshots/iphone-*.png (6.9") and ipad-*.png (13").
  - Age rating: the game has business casinos and bars as trades, no gambling by the player: answer "Simulated
    gambling: none", "Alcohol references: infrequent/mild". Category: Games › Simulation.

Every new version of the game
  cd ../source && node tools/build.js && cp ledger.html ..      (as before)
  cd ../ios-app && npm run sync                                 (then Run / Archive in Xcode)

Packs and Pro (features/player/pro.js)
  Ledger Pro (monthly, yearly, lifetime) opens all eight Pro features. Packs, bought once:
    The whole world     every country
    Tycoon              tycoon trades and private equity
    Estates and clubs   estates and football clubs
    Time savers         Until needed, save slots 2 and 3, every trade from the start
  When a subscription ends, everything already bought or built keeps running; only new locked things ask.
  In a browser there is no store: the Settings test switches and test purchases work as before.

Saves (ui/core/base.js, features/player/saves.js)
  The game still saves to web storage first. In the app every save key is also a file on the phone (a moment
  later, and at once when the app goes to the background), and the game, the slots and their list go to iCloud
  (half a minute later, or at once on leaving). A new phone picks the game up from iCloud; a game another device
  sent shows in the main menu as "From iCloud, another device" and never overwrites the one here.
  Save to a file opens the share sheet (Save to Files, AirDrop, Mail).

Note on the screenshots in screenshots/
  Made here without the DM Sans font file (Inter stood in for the body text). "npm run screenshots" on the Mac
  makes them again with the real bundled fonts.

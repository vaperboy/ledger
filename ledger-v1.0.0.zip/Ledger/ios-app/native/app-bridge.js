/* Ledger app bridge: the one place where the game meets the phone. scripts/build-www.mjs bundles this file (with
   esbuild) into www/app.js, which loads before the game. It makes window.LedgerApp, which the game looks for:
     LedgerApp.disk   files on the phone and iCloud (native/ledger-native)    -> ui/core/base.js, features/player/saves.js
     LedgerApp.store  the App Store through RevenueCat                         -> features/player/pro.js
     LedgerApp.open   a link outside the app
   In a normal browser there is no LedgerApp and the game keeps its browser behaviour.
   Product and entitlement names come from config.json (put in by build-www as __LEDGER_CONFIG__). */
import { Capacitor, registerPlugin } from '@capacitor/core';
import { Purchases, LOG_LEVEL, PRODUCT_CATEGORY } from '@revenuecat/purchases-capacitor';

const CFG = __LEDGER_CONFIG__;
const Native = registerPlugin('LedgerNative');

if (Capacitor.isNativePlatform()) {
  const ID = CFG.products;                    /* game id -> App Store product id */
  const ENT = CFG.entitlements;               /* game id -> RevenueCat entitlement id */
  const PLANS = ['monthly', 'yearly', 'lifetime'], PACKS = Object.keys(ENT).filter(k => k !== 'pro'); /* the four packs and the looks */
  const SUBS = 'https://apps.apple.com/account/subscriptions';
  let ready = null;
  const listeners = [];

  /* what the player owns, in the game's words */
  const ownOf = info => {
    const act = (info && info.entitlements && info.entitlements.active) || {};
    const pro = act[ENT.pro];
    const plan = pro ? (PLANS.filter(p => ID[p] === pro.productIdentifier)[0] || (/life/i.test(pro.productIdentifier) ? 'lifetime' : /year|annual/i.test(pro.productIdentifier) ? 'yearly' : 'monthly')) : null;
    const packs = {};
    PACKS.forEach(p => { if (act[ENT[p]]) packs[p] = true; });
    return { pro: plan, packs, renews: pro && pro.willRenew && pro.expirationDate ? Date.parse(pro.expirationDate) : null };
  };
  const tell = info => { const o = ownOf(info); listeners.forEach(cb => { try { cb(o); } catch (e) { } }); return o; };

  /* every package in every offering, by product id */
  let pkgs = {}, prods = {};
  const start = () => ready || (ready = (async () => {
    if (!CFG.revenuecatKey || /PUT_YOUR/.test(CFG.revenuecatKey)) throw new Error('The store is not set up yet.');
    await Purchases.setLogLevel({ level: LOG_LEVEL.WARN });
    await Purchases.configure({ apiKey: CFG.revenuecatKey });
    Purchases.addCustomerInfoUpdateListener(info => tell(info && info.customerInfo ? info.customerInfo : info));
    try {
      const offs = await Purchases.getOfferings();
      Object.values((offs && offs.all) || {}).forEach(o => (o.availablePackages || []).forEach(p => { pkgs[p.product.identifier] = p; prods[p.product.identifier] = p.product; }));
    } catch (e) { }
    /* products not in an offering are fetched on their own */
    const missing = Object.keys(ID).map(k => ID[k]).filter(id => !prods[id]);
    if (missing.length) {
      for (const type of [PRODUCT_CATEGORY.SUBSCRIPTION, PRODUCT_CATEGORY.NON_SUBSCRIPTION]) {
        try { const r = await Purchases.getProducts({ productIdentifiers: missing, type }); ((r && r.products) || []).forEach(p => { prods[p.identifier] = p; }); } catch (e) { }
      }
    }
  })());
  const info = async () => { const r = await Purchases.getCustomerInfo(); return r.customerInfo || r; };
  const cancelled = e => !!(e && (e.userCancelled || e.code === '1' || e.code === 1 || /cancel/i.test(e.message || '')));

  const store = {
    /* prices in the player's currency, and what they own */
    load: async () => {
      await start();
      const items = {};
      Object.keys(ID).forEach(k => { const p = prods[ID[k]]; if (p && p.priceString) items[k] = p.priceString; });
      return { items, own: ownOf(await info()) };
    },
    buy: async id => {
      try {
        await start();
        const pid = ID[id];
        let r;
        if (pkgs[pid]) r = await Purchases.purchasePackage({ aPackage: pkgs[pid] });
        else if (prods[pid]) r = await Purchases.purchaseStoreProduct({ product: prods[pid] });
        else throw new Error('This is not for sale right now. Try again later.');
        return tell(r.customerInfo);
      } catch (e) {
        throw cancelled(e) ? { cancelled: true } : { message: (e && e.message) || 'The purchase did not go through.' };
      }
    },
    restore: async () => { await start(); const r = await Purchases.restorePurchases(); return tell(r.customerInfo || r); },
    manage: async () => {
      try { await start(); const i = await info(); if (i.managementURL) return Native.openUrl({ url: i.managementURL }); } catch (e) { }
      return Native.openUrl({ url: SUBS });
    },
    onChange: cb => { listeners.push(cb); }
  };

  let cloudT = 0;
  const disk = {
    load: () => Native.readAll(),
    write: o => Native.write(o),
    cloud: o => Native.cloud(o),
    share: o => Native.share(o),
    /* iCloud brought something from another device: read it again a moment later */
    onCloud: cb => { Native.addListener('cloudChange', () => { clearTimeout(cloudT); cloudT = setTimeout(() => Native.readAll().then(cb, () => { }), 1500); }); }
  };

  window.LedgerApp = {
    platform: Capacitor.getPlatform(), disk, store, open: url => Native.openUrl({ url }),
    review: () => Native.review().catch(() => { }),              /* Apple's rating prompt after a good moment */
    reviewUrl: CFG.appStoreId ? 'https://apps.apple.com/app/id' + CFG.appStoreId + '?action=write-review' : ''  /* Settings › Rate Ledger */
  };
}

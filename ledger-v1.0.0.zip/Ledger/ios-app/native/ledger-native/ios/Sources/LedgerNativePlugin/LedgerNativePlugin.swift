import Foundation
import UIKit
import Capacitor
import StoreKit

/// Ledger's own native part (used by native/app-bridge.js as LedgerApp.disk and LedgerApp.open):
///  - every save key of the game as a file in Application Support/Saves (survives the system clearing web storage),
///  - the game, its slots and their list in the player's iCloud (the app's private iCloud container, Saves folder),
///  - a share sheet for "Save to a file", and opening links (terms, subscriptions) outside the app.
/// A file is one JSON line ({"k": key, "t": time, "a": about}) and then the save text.
@objc(LedgerNativePlugin)
public class LedgerNativePlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "LedgerNativePlugin"
    public let jsName = "LedgerNative"
    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "readAll", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "write", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "cloud", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "share", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "openUrl", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "review", returnType: CAPPluginReturnPromise)
    ]

    private let disk = DispatchQueue(label: "ledger.disk")          // local files, in order
    private let sky = DispatchQueue(label: "ledger.icloud")         // iCloud, in order
    private var cloudRoot: URL?
    private var cloudChecked = false
    private var query: NSMetadataQuery?
    private var ownWrite = Date.distantPast

    private var localRoot: URL {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Saves", isDirectory: true)
    }

    override public func load() {
        sky.async { self.findCloud() }
        DispatchQueue.main.async { self.watchCloud() }
    }

    // MARK: files

    private func fileName(_ key: String) -> String {
        key.replacingOccurrences(of: ":", with: "_").replacingOccurrences(of: "/", with: "_") + ".txt"
    }

    private func encode(_ key: String, _ value: String, _ t: Double, _ about: [String: Any]?) -> Data? {
        var head: [String: Any] = ["k": key, "t": t]
        if let a = about { head["a"] = a }
        guard var d = try? JSONSerialization.data(withJSONObject: head) else { return nil }
        d.append(0x0A)
        d.append(Data(value.utf8))
        return d
    }

    private func decode(_ data: Data) -> (String, [String: Any])? {
        guard let nl = data.firstIndex(of: 0x0A),
              let head = (try? JSONSerialization.jsonObject(with: data.subdata(in: data.startIndex..<nl))) as? [String: Any],
              let key = head["k"] as? String else { return nil }
        let value = String(decoding: data.subdata(in: data.index(after: nl)..<data.endIndex), as: UTF8.self)
        var o: [String: Any] = ["v": value, "t": head["t"] ?? 0]
        if let a = head["a"] { o["a"] = a }
        return (key, o)
    }

    private func readLocal() -> [String: Any] {
        var out: [String: Any] = [:]
        let urls = (try? FileManager.default.contentsOfDirectory(at: localRoot, includingPropertiesForKeys: nil)) ?? []
        for u in urls where u.pathExtension == "txt" {
            if let d = try? Data(contentsOf: u), let (k, o) = decode(d) { out[k] = o }
        }
        return out
    }

    // MARK: iCloud

    /// The app's iCloud container (nil when the player is signed out or switched iCloud off for Ledger).
    /// Apple asks for this call off the main thread.
    private func findCloud() {
        if cloudChecked { return }
        if let c = FileManager.default.url(forUbiquityContainerIdentifier: nil) {
            let dir = c.appendingPathComponent("Saves", isDirectory: true)
            try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
            cloudRoot = dir
        }
        cloudChecked = true
    }

    private func readCloud() -> [String: Any]? {
        findCloud()
        guard let root = cloudRoot else { return nil }
        var out: [String: Any] = [:]
        let fm = FileManager.default
        let urls = (try? fm.contentsOfDirectory(at: root, includingPropertiesForKeys: [.ubiquitousItemDownloadingStatusKey])) ?? []
        for u in urls {
            let name = u.lastPathComponent
            if name.hasPrefix(".") && name.hasSuffix(".icloud") {   // not downloaded yet (older iOS): fetch it for next time
                let real = root.appendingPathComponent(String(name.dropFirst().dropLast(7)))
                try? fm.startDownloadingUbiquitousItem(at: real)
                continue
            }
            guard u.pathExtension == "txt" else { continue }
            let status = (try? u.resourceValues(forKeys: [.ubiquitousItemDownloadingStatusKey]))?.ubiquitousItemDownloadingStatus
            if status != nil && status != .current { try? fm.startDownloadingUbiquitousItem(at: u) }
            var data: Data?
            var err: NSError?
            NSFileCoordinator(filePresenter: nil).coordinate(readingItemAt: u, options: [], error: &err) { url in
                data = try? Data(contentsOf: url)
            }
            if let d = data, let (k, o) = decode(d) { out[k] = o }
        }
        return out
    }

    /// Watches the container, downloads what other devices sent and tells the game ("cloudChange").
    private func watchCloud() {
        let q = NSMetadataQuery()
        q.searchScopes = [NSMetadataQueryUbiquitousDataScope]
        q.predicate = NSPredicate(format: "%K LIKE '*.txt'", NSMetadataItemFSNameKey)
        NotificationCenter.default.addObserver(self, selector: #selector(cloudMoved(_:)), name: .NSMetadataQueryDidFinishGathering, object: q)
        NotificationCenter.default.addObserver(self, selector: #selector(cloudMoved(_:)), name: .NSMetadataQueryDidUpdate, object: q)
        query = q
        q.start()
    }

    @objc private func cloudMoved(_ note: Notification) {
        guard let q = query else { return }
        q.disableUpdates()
        var ready = false
        for case let item as NSMetadataItem in q.results {
            guard let url = item.value(forAttribute: NSMetadataItemURLKey) as? URL else { continue }
            let status = item.value(forAttribute: NSMetadataUbiquitousItemDownloadingStatusKey) as? String
            if status == NSMetadataUbiquitousItemDownloadingStatusCurrent { ready = true } else { try? FileManager.default.startDownloadingUbiquitousItem(at: url) }
        }
        q.enableUpdates()
        // our own writes come back as updates too; only news from elsewhere is worth a message
        if ready && Date().timeIntervalSince(ownWrite) > 8 { notifyListeners("cloudChange", data: [:]) }
    }

    // MARK: background time, so a save started as the app closes still lands

    private func keepAlive() -> UIBackgroundTaskIdentifier {
        var id = UIBackgroundTaskIdentifier.invalid
        id = UIApplication.shared.beginBackgroundTask(withName: "ledger.save") {
            UIApplication.shared.endBackgroundTask(id)
            id = .invalid
        }
        return id
    }

    private func done(_ id: UIBackgroundTaskIdentifier) {
        if id != .invalid { UIApplication.shared.endBackgroundTask(id) }
    }

    // MARK: calls from the game

    /// { local: {key: {v, t}}, cloud: {key: {v, t, a}} | null }. iCloud gets a few seconds (more on a phone with no
    /// game yet); whatever is late arrives later through "cloudChange".
    @objc func readAll(_ call: CAPPluginCall) {
        disk.async {
            let local = self.readLocal()
            let budget: Double = local.isEmpty ? 8 : 3
            var cloud: [String: Any]?
            var on = false
            let group = DispatchGroup()
            group.enter()
            self.sky.async {
                cloud = self.readCloud()
                on = self.cloudRoot != nil
                group.leave()
            }
            if group.wait(timeout: .now() + budget) == .timedOut {
                on = self.cloudRoot != nil
                cloud = on ? [:] : nil
            }
            let sent: Any = on ? (cloud ?? [:]) as Any : NSNull() as Any
            call.resolve(["local": local, "cloud": sent])
        }
    }

    /// One key to its file; a missing value deletes the file.
    @objc func write(_ call: CAPPluginCall) {
        guard let key = call.getString("key") else { call.reject("No key"); return }
        let value = call.getString("value")
        let t = call.getDouble("t") ?? Date().timeIntervalSince1970 * 1000
        let task = keepAlive()
        disk.async {
            let url = self.localRoot.appendingPathComponent(self.fileName(key))
            do {
                try FileManager.default.createDirectory(at: self.localRoot, withIntermediateDirectories: true)
                if let v = value, let d = self.encode(key, v, t, nil) {
                    try d.write(to: url, options: [.atomic])
                } else if FileManager.default.fileExists(atPath: url.path) {
                    try FileManager.default.removeItem(at: url)
                }
                call.resolve(["ok": true])
            } catch {
                call.reject("Could not save: \(error.localizedDescription)")
            }
            self.done(task)
        }
    }

    /// One key to iCloud (with a line about the game for the other device's menu); a missing value deletes it.
    @objc func cloud(_ call: CAPPluginCall) {
        guard let key = call.getString("key") else { call.reject("No key"); return }
        let value = call.getString("value")
        let t = call.getDouble("t") ?? Date().timeIntervalSince1970 * 1000
        let about = call.getObject("about").map { $0 as [String: Any] }
        let task = keepAlive()
        sky.async {
            self.findCloud()
            guard let root = self.cloudRoot else { call.resolve(["ok": false]); self.done(task); return }
            let url = root.appendingPathComponent(self.fileName(key))
            self.ownWrite = Date()
            var err: NSError?
            var failed: Error?
            let c = NSFileCoordinator(filePresenter: nil)
            if let v = value, let d = self.encode(key, v, t, about) {
                c.coordinate(writingItemAt: url, options: .forReplacing, error: &err) { u in
                    do { try d.write(to: u, options: [.atomic]) } catch { failed = error }
                }
            } else if FileManager.default.fileExists(atPath: url.path) {
                c.coordinate(writingItemAt: url, options: .forDeleting, error: &err) { u in
                    do { try FileManager.default.removeItem(at: u) } catch { failed = error }
                }
            }
            if let e = failed ?? err { call.reject("iCloud: \(e.localizedDescription)") } else { call.resolve(["ok": true]) }
            self.done(task)
        }
    }

    /// "Save to a file": the save as a .txt in the share sheet (Save to Files, AirDrop, Mail ...).
    @objc func share(_ call: CAPPluginCall) {
        guard let name = call.getString("name"), let text = call.getString("text") else { call.reject("Nothing to share"); return }
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(name)
        do { try text.write(to: url, atomically: true, encoding: .utf8) } catch { call.reject(error.localizedDescription); return }
        DispatchQueue.main.async {
            guard let vc = self.bridge?.viewController else { call.reject("No screen"); return }
            let sheet = UIActivityViewController(activityItems: [url], applicationActivities: nil)
            sheet.completionWithItemsHandler = { _, completed, _, _ in call.resolve(["done": completed]) }
            if let pop = sheet.popoverPresentationController {   // iPad: anchor it at the bottom middle
                pop.sourceView = vc.view
                pop.sourceRect = CGRect(x: vc.view.bounds.midX, y: vc.view.bounds.maxY - 90, width: 1, height: 1)
                pop.permittedArrowDirections = []
            }
            vc.present(sheet, animated: true)
        }
    }

    /// Apple's own small "Enjoying Ledger?" rating prompt (Apple decides whether it shows; at most three times a year).
    @objc func review(_ call: CAPPluginCall) {
        Task { @MainActor in
            if let scene = UIApplication.shared.connectedScenes.first(where: { $0.activationState == .foregroundActive }) as? UIWindowScene {
                if #available(iOS 16.0, *) { AppStore.requestReview(in: scene) } else { SKStoreReviewController.requestReview(in: scene) }
            }
            call.resolve()
        }
    }

    /// Links that leave the game: Apple's terms of use, the App Store's subscription page, mail to support.
    @objc func openUrl(_ call: CAPPluginCall) {
        guard let s = call.getString("url"), let u = URL(string: s) else { call.reject("Bad link"); return }
        DispatchQueue.main.async {
            UIApplication.shared.open(u, options: [:]) { ok in call.resolve(["ok": ok]) }
        }
    }
}

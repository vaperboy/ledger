Ledger | Business Tycoon Simulator · Patch V. 1.0.0

To play: open ledger.html in a browser. Keep the pictures folder next to it (the photos load from there;
without it the game still works and shows the drawings).

source/  everything to change and rebuild the game: src (code, styles, full-size pictures in src/assets/pictures),
         tests, tools, STRUCTURE.txt (where everything lives). Rebuild with: node tools/build.js
         (run inside source/; it writes ledger.html and ledger.dev.html), then python3 tools/pictures.py for the
         game-size pictures. Copy the new ledger.html up into this folder.
ios-app/ the iPhone and iPad app around ledger.html (Capacitor): store, iCloud saves, icon, launch screen,
         App Store screenshots and the privacy page. Start with ios-app/README.txt.
